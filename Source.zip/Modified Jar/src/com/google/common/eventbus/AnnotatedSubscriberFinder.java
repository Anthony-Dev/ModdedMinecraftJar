/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Objects;
/*   4:    */ import com.google.common.base.Throwables;
/*   5:    */ import com.google.common.cache.CacheBuilder;
/*   6:    */ import com.google.common.cache.CacheLoader;
/*   7:    */ import com.google.common.cache.LoadingCache;
/*   8:    */ import com.google.common.collect.HashMultimap;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.Maps;
/*  11:    */ import com.google.common.collect.Multimap;
/*  12:    */ import com.google.common.reflect.TypeToken;
/*  13:    */ import com.google.common.reflect.TypeToken.TypeSet;
/*  14:    */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*  15:    */ import java.lang.reflect.Method;
/*  16:    */ import java.util.Arrays;
/*  17:    */ import java.util.List;
/*  18:    */ import java.util.Map;
/*  19:    */ import java.util.Set;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ class AnnotatedSubscriberFinder
/*  23:    */   implements SubscriberFindingStrategy
/*  24:    */ {
/*  25: 53 */   private static final LoadingCache<Class<?>, ImmutableList<Method>> subscriberMethodsCache = CacheBuilder.newBuilder().weakKeys().build(new CacheLoader()
/*  26:    */   {
/*  27:    */     public ImmutableList<Method> load(Class<?> concreteClass)
/*  28:    */       throws Exception
/*  29:    */     {
/*  30: 59 */       return AnnotatedSubscriberFinder.getAnnotatedMethodsInternal(concreteClass);
/*  31:    */     }
/*  32: 53 */   });
/*  33:    */   
/*  34:    */   public Multimap<Class<?>, EventSubscriber> findAllSubscribers(Object listener)
/*  35:    */   {
/*  36: 70 */     Multimap<Class<?>, EventSubscriber> methodsInListener = HashMultimap.create();
/*  37: 71 */     Class<?> clazz = listener.getClass();
/*  38: 72 */     for (Method method : getAnnotatedMethods(clazz))
/*  39:    */     {
/*  40: 73 */       Class<?>[] parameterTypes = method.getParameterTypes();
/*  41: 74 */       Class<?> eventType = parameterTypes[0];
/*  42: 75 */       EventSubscriber subscriber = makeSubscriber(listener, method);
/*  43: 76 */       methodsInListener.put(eventType, subscriber);
/*  44:    */     }
/*  45: 78 */     return methodsInListener;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static ImmutableList<Method> getAnnotatedMethods(Class<?> clazz)
/*  49:    */   {
/*  50:    */     try
/*  51:    */     {
/*  52: 83 */       return (ImmutableList)subscriberMethodsCache.getUnchecked(clazz);
/*  53:    */     }
/*  54:    */     catch (UncheckedExecutionException e)
/*  55:    */     {
/*  56: 85 */       throw Throwables.propagate(e.getCause());
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static final class MethodIdentifier
/*  61:    */   {
/*  62:    */     private final String name;
/*  63:    */     private final List<Class<?>> parameterTypes;
/*  64:    */     
/*  65:    */     MethodIdentifier(Method method)
/*  66:    */     {
/*  67: 94 */       this.name = method.getName();
/*  68: 95 */       this.parameterTypes = Arrays.asList(method.getParameterTypes());
/*  69:    */     }
/*  70:    */     
/*  71:    */     public int hashCode()
/*  72:    */     {
/*  73:100 */       return Objects.hashCode(new Object[] { this.name, this.parameterTypes });
/*  74:    */     }
/*  75:    */     
/*  76:    */     public boolean equals(@Nullable Object o)
/*  77:    */     {
/*  78:105 */       if ((o instanceof MethodIdentifier))
/*  79:    */       {
/*  80:106 */         MethodIdentifier ident = (MethodIdentifier)o;
/*  81:107 */         return (this.name.equals(ident.name)) && (this.parameterTypes.equals(ident.parameterTypes));
/*  82:    */       }
/*  83:109 */       return false;
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static ImmutableList<Method> getAnnotatedMethodsInternal(Class<?> clazz)
/*  88:    */   {
/*  89:114 */     Set<? extends Class<?>> supers = TypeToken.of(clazz).getTypes().rawTypes();
/*  90:115 */     Map<MethodIdentifier, Method> identifiers = Maps.newHashMap();
/*  91:116 */     for (Class<?> superClazz : supers) {
/*  92:117 */       for (Method superClazzMethod : superClazz.getMethods()) {
/*  93:118 */         if (superClazzMethod.isAnnotationPresent(Subscribe.class))
/*  94:    */         {
/*  95:119 */           Class<?>[] parameterTypes = superClazzMethod.getParameterTypes();
/*  96:120 */           if (parameterTypes.length != 1) {
/*  97:121 */             throw new IllegalArgumentException("Method " + superClazzMethod + " has @Subscribe annotation, but requires " + parameterTypes.length + " arguments.  Event subscriber methods must require a single argument.");
/*  98:    */           }
/*  99:126 */           MethodIdentifier ident = new MethodIdentifier(superClazzMethod);
/* 100:127 */           if (!identifiers.containsKey(ident)) {
/* 101:128 */             identifiers.put(ident, superClazzMethod);
/* 102:    */           }
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:133 */     return ImmutableList.copyOf(identifiers.values());
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static EventSubscriber makeSubscriber(Object listener, Method method)
/* 110:    */   {
/* 111:    */     EventSubscriber wrapper;
/* 112:    */     EventSubscriber wrapper;
/* 113:149 */     if (methodIsDeclaredThreadSafe(method)) {
/* 114:150 */       wrapper = new EventSubscriber(listener, method);
/* 115:    */     } else {
/* 116:152 */       wrapper = new SynchronizedEventSubscriber(listener, method);
/* 117:    */     }
/* 118:154 */     return wrapper;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private static boolean methodIsDeclaredThreadSafe(Method method)
/* 122:    */   {
/* 123:166 */     return method.getAnnotation(AllowConcurrentEvents.class) != null;
/* 124:    */   }
/* 125:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.AnnotatedSubscriberFinder
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ class EventSubscriber
/*   9:    */ {
/*  10:    */   private final Object target;
/*  11:    */   private final Method method;
/*  12:    */   
/*  13:    */   EventSubscriber(Object target, Method method)
/*  14:    */   {
/*  15: 54 */     Preconditions.checkNotNull(target, "EventSubscriber target cannot be null.");
/*  16:    */     
/*  17: 56 */     Preconditions.checkNotNull(method, "EventSubscriber method cannot be null.");
/*  18:    */     
/*  19: 58 */     this.target = target;
/*  20: 59 */     this.method = method;
/*  21: 60 */     method.setAccessible(true);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void handleEvent(Object event)
/*  25:    */     throws InvocationTargetException
/*  26:    */   {
/*  27: 72 */     Preconditions.checkNotNull(event);
/*  28:    */     try
/*  29:    */     {
/*  30: 74 */       this.method.invoke(this.target, new Object[] { event });
/*  31:    */     }
/*  32:    */     catch (IllegalArgumentException e)
/*  33:    */     {
/*  34: 76 */       throw new Error("Method rejected target/argument: " + event, e);
/*  35:    */     }
/*  36:    */     catch (IllegalAccessException e)
/*  37:    */     {
/*  38: 78 */       throw new Error("Method became inaccessible: " + event, e);
/*  39:    */     }
/*  40:    */     catch (InvocationTargetException e)
/*  41:    */     {
/*  42: 80 */       if ((e.getCause() instanceof Error)) {
/*  43: 81 */         throw ((Error)e.getCause());
/*  44:    */       }
/*  45: 83 */       throw e;
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public String toString()
/*  50:    */   {
/*  51: 88 */     return "[wrapper " + this.method + "]";
/*  52:    */   }
/*  53:    */   
/*  54:    */   public int hashCode()
/*  55:    */   {
/*  56: 92 */     int PRIME = 31;
/*  57: 93 */     return (31 + this.method.hashCode()) * 31 + System.identityHashCode(this.target);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean equals(@Nullable Object obj)
/*  61:    */   {
/*  62: 98 */     if ((obj instanceof EventSubscriber))
/*  63:    */     {
/*  64: 99 */       EventSubscriber that = (EventSubscriber)obj;
/*  65:    */       
/*  66:    */ 
/*  67:    */ 
/*  68:103 */       return (this.target == that.target) && (this.method.equals(that.method));
/*  69:    */     }
/*  70:105 */     return false;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Object getSubscriber()
/*  74:    */   {
/*  75:109 */     return this.target;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Method getMethod()
/*  79:    */   {
/*  80:113 */     return this.method;
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.EventSubscriber
 * JD-Core Version:    0.7.0.1
 */
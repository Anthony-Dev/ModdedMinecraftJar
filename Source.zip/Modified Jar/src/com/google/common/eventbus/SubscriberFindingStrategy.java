package com.google.common.eventbus;

import com.google.common.collect.Multimap;

abstract interface SubscriberFindingStrategy
{
  public abstract Multimap<Class<?>, EventSubscriber> findAllSubscribers(Object paramObject);
}


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.SubscriberFindingStrategy
 * JD-Core Version:    0.7.0.1
 */
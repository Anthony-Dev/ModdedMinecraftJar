/*  1:   */ package com.google.common.eventbus;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.InvocationTargetException;
/*  4:   */ import java.lang.reflect.Method;
/*  5:   */ 
/*  6:   */ final class SynchronizedEventSubscriber
/*  7:   */   extends EventSubscriber
/*  8:   */ {
/*  9:   */   public SynchronizedEventSubscriber(Object target, Method method)
/* 10:   */   {
/* 11:40 */     super(target, method);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void handleEvent(Object event)
/* 15:   */     throws InvocationTargetException
/* 16:   */   {
/* 17:46 */     synchronized (this)
/* 18:   */     {
/* 19:47 */       super.handleEvent(event);
/* 20:   */     }
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.SynchronizedEventSubscriber
 * JD-Core Version:    0.7.0.1
 */
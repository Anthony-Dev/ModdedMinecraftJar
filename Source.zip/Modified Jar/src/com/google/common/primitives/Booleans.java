/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.AbstractList;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.RandomAccess;
/*  13:    */ 
/*  14:    */ @GwtCompatible
/*  15:    */ public final class Booleans
/*  16:    */ {
/*  17:    */   public static int hashCode(boolean value)
/*  18:    */   {
/*  19: 60 */     return value ? 1231 : 1237;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static int compare(boolean a, boolean b)
/*  23:    */   {
/*  24: 77 */     return a ? 1 : a == b ? 0 : -1;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static boolean contains(boolean[] array, boolean target)
/*  28:    */   {
/*  29: 95 */     for (boolean value : array) {
/*  30: 96 */       if (value == target) {
/*  31: 97 */         return true;
/*  32:    */       }
/*  33:    */     }
/*  34:100 */     return false;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static int indexOf(boolean[] array, boolean target)
/*  38:    */   {
/*  39:117 */     return indexOf(array, target, 0, array.length);
/*  40:    */   }
/*  41:    */   
/*  42:    */   private static int indexOf(boolean[] array, boolean target, int start, int end)
/*  43:    */   {
/*  44:123 */     for (int i = start; i < end; i++) {
/*  45:124 */       if (array[i] == target) {
/*  46:125 */         return i;
/*  47:    */       }
/*  48:    */     }
/*  49:128 */     return -1;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static int indexOf(boolean[] array, boolean[] target)
/*  53:    */   {
/*  54:143 */     Preconditions.checkNotNull(array, "array");
/*  55:144 */     Preconditions.checkNotNull(target, "target");
/*  56:145 */     if (target.length == 0) {
/*  57:146 */       return 0;
/*  58:    */     }
/*  59:    */     label64:
/*  60:150 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  61:    */     {
/*  62:151 */       for (int j = 0; j < target.length; j++) {
/*  63:152 */         if (array[(i + j)] != target[j]) {
/*  64:    */           break label64;
/*  65:    */         }
/*  66:    */       }
/*  67:156 */       return i;
/*  68:    */     }
/*  69:158 */     return -1;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static int lastIndexOf(boolean[] array, boolean target)
/*  73:    */   {
/*  74:171 */     return lastIndexOf(array, target, 0, array.length);
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static int lastIndexOf(boolean[] array, boolean target, int start, int end)
/*  78:    */   {
/*  79:177 */     for (int i = end - 1; i >= start; i--) {
/*  80:178 */       if (array[i] == target) {
/*  81:179 */         return i;
/*  82:    */       }
/*  83:    */     }
/*  84:182 */     return -1;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static boolean[] concat(boolean[]... arrays)
/*  88:    */   {
/*  89:195 */     int length = 0;
/*  90:196 */     for (boolean[] array : arrays) {
/*  91:197 */       length += array.length;
/*  92:    */     }
/*  93:199 */     boolean[] result = new boolean[length];
/*  94:200 */     int pos = 0;
/*  95:201 */     for (boolean[] array : arrays)
/*  96:    */     {
/*  97:202 */       System.arraycopy(array, 0, result, pos, array.length);
/*  98:203 */       pos += array.length;
/*  99:    */     }
/* 100:205 */     return result;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static boolean[] ensureCapacity(boolean[] array, int minLength, int padding)
/* 104:    */   {
/* 105:226 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 106:227 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 107:228 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static boolean[] copyOf(boolean[] original, int length)
/* 111:    */   {
/* 112:235 */     boolean[] copy = new boolean[length];
/* 113:236 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 114:237 */     return copy;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static String join(String separator, boolean... array)
/* 118:    */   {
/* 119:250 */     Preconditions.checkNotNull(separator);
/* 120:251 */     if (array.length == 0) {
/* 121:252 */       return "";
/* 122:    */     }
/* 123:256 */     StringBuilder builder = new StringBuilder(array.length * 7);
/* 124:257 */     builder.append(array[0]);
/* 125:258 */     for (int i = 1; i < array.length; i++) {
/* 126:259 */       builder.append(separator).append(array[i]);
/* 127:    */     }
/* 128:261 */     return builder.toString();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static Comparator<boolean[]> lexicographicalComparator()
/* 132:    */   {
/* 133:281 */     return LexicographicalComparator.INSTANCE;
/* 134:    */   }
/* 135:    */   
/* 136:    */   private static enum LexicographicalComparator
/* 137:    */     implements Comparator<boolean[]>
/* 138:    */   {
/* 139:285 */     INSTANCE;
/* 140:    */     
/* 141:    */     private LexicographicalComparator() {}
/* 142:    */     
/* 143:    */     public int compare(boolean[] left, boolean[] right)
/* 144:    */     {
/* 145:289 */       int minLength = Math.min(left.length, right.length);
/* 146:290 */       for (int i = 0; i < minLength; i++)
/* 147:    */       {
/* 148:291 */         int result = Booleans.compare(left[i], right[i]);
/* 149:292 */         if (result != 0) {
/* 150:293 */           return result;
/* 151:    */         }
/* 152:    */       }
/* 153:296 */       return left.length - right.length;
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static boolean[] toArray(Collection<Boolean> collection)
/* 158:    */   {
/* 159:318 */     if ((collection instanceof BooleanArrayAsList)) {
/* 160:319 */       return ((BooleanArrayAsList)collection).toBooleanArray();
/* 161:    */     }
/* 162:322 */     Object[] boxedArray = collection.toArray();
/* 163:323 */     int len = boxedArray.length;
/* 164:324 */     boolean[] array = new boolean[len];
/* 165:325 */     for (int i = 0; i < len; i++) {
/* 166:327 */       array[i] = ((Boolean)Preconditions.checkNotNull(boxedArray[i])).booleanValue();
/* 167:    */     }
/* 168:329 */     return array;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static List<Boolean> asList(boolean... backingArray)
/* 172:    */   {
/* 173:347 */     if (backingArray.length == 0) {
/* 174:348 */       return Collections.emptyList();
/* 175:    */     }
/* 176:350 */     return new BooleanArrayAsList(backingArray);
/* 177:    */   }
/* 178:    */   
/* 179:    */   @GwtCompatible
/* 180:    */   private static class BooleanArrayAsList
/* 181:    */     extends AbstractList<Boolean>
/* 182:    */     implements RandomAccess, Serializable
/* 183:    */   {
/* 184:    */     final boolean[] array;
/* 185:    */     final int start;
/* 186:    */     final int end;
/* 187:    */     private static final long serialVersionUID = 0L;
/* 188:    */     
/* 189:    */     BooleanArrayAsList(boolean[] array)
/* 190:    */     {
/* 191:361 */       this(array, 0, array.length);
/* 192:    */     }
/* 193:    */     
/* 194:    */     BooleanArrayAsList(boolean[] array, int start, int end)
/* 195:    */     {
/* 196:365 */       this.array = array;
/* 197:366 */       this.start = start;
/* 198:367 */       this.end = end;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public int size()
/* 202:    */     {
/* 203:371 */       return this.end - this.start;
/* 204:    */     }
/* 205:    */     
/* 206:    */     public boolean isEmpty()
/* 207:    */     {
/* 208:375 */       return false;
/* 209:    */     }
/* 210:    */     
/* 211:    */     public Boolean get(int index)
/* 212:    */     {
/* 213:379 */       Preconditions.checkElementIndex(index, size());
/* 214:380 */       return Boolean.valueOf(this.array[(this.start + index)]);
/* 215:    */     }
/* 216:    */     
/* 217:    */     public boolean contains(Object target)
/* 218:    */     {
/* 219:385 */       return ((target instanceof Boolean)) && (Booleans.indexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end) != -1);
/* 220:    */     }
/* 221:    */     
/* 222:    */     public int indexOf(Object target)
/* 223:    */     {
/* 224:391 */       if ((target instanceof Boolean))
/* 225:    */       {
/* 226:392 */         int i = Booleans.indexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end);
/* 227:393 */         if (i >= 0) {
/* 228:394 */           return i - this.start;
/* 229:    */         }
/* 230:    */       }
/* 231:397 */       return -1;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public int lastIndexOf(Object target)
/* 235:    */     {
/* 236:402 */       if ((target instanceof Boolean))
/* 237:    */       {
/* 238:403 */         int i = Booleans.lastIndexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end);
/* 239:404 */         if (i >= 0) {
/* 240:405 */           return i - this.start;
/* 241:    */         }
/* 242:    */       }
/* 243:408 */       return -1;
/* 244:    */     }
/* 245:    */     
/* 246:    */     public Boolean set(int index, Boolean element)
/* 247:    */     {
/* 248:412 */       Preconditions.checkElementIndex(index, size());
/* 249:413 */       boolean oldValue = this.array[(this.start + index)];
/* 250:    */       
/* 251:415 */       this.array[(this.start + index)] = ((Boolean)Preconditions.checkNotNull(element)).booleanValue();
/* 252:416 */       return Boolean.valueOf(oldValue);
/* 253:    */     }
/* 254:    */     
/* 255:    */     public List<Boolean> subList(int fromIndex, int toIndex)
/* 256:    */     {
/* 257:420 */       int size = size();
/* 258:421 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 259:422 */       if (fromIndex == toIndex) {
/* 260:423 */         return Collections.emptyList();
/* 261:    */       }
/* 262:425 */       return new BooleanArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 263:    */     }
/* 264:    */     
/* 265:    */     public boolean equals(Object object)
/* 266:    */     {
/* 267:429 */       if (object == this) {
/* 268:430 */         return true;
/* 269:    */       }
/* 270:432 */       if ((object instanceof BooleanArrayAsList))
/* 271:    */       {
/* 272:433 */         BooleanArrayAsList that = (BooleanArrayAsList)object;
/* 273:434 */         int size = size();
/* 274:435 */         if (that.size() != size) {
/* 275:436 */           return false;
/* 276:    */         }
/* 277:438 */         for (int i = 0; i < size; i++) {
/* 278:439 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 279:440 */             return false;
/* 280:    */           }
/* 281:    */         }
/* 282:443 */         return true;
/* 283:    */       }
/* 284:445 */       return super.equals(object);
/* 285:    */     }
/* 286:    */     
/* 287:    */     public int hashCode()
/* 288:    */     {
/* 289:449 */       int result = 1;
/* 290:450 */       for (int i = this.start; i < this.end; i++) {
/* 291:451 */         result = 31 * result + Booleans.hashCode(this.array[i]);
/* 292:    */       }
/* 293:453 */       return result;
/* 294:    */     }
/* 295:    */     
/* 296:    */     public String toString()
/* 297:    */     {
/* 298:457 */       StringBuilder builder = new StringBuilder(size() * 7);
/* 299:458 */       builder.append(this.array[this.start] != 0 ? "[true" : "[false");
/* 300:459 */       for (int i = this.start + 1; i < this.end; i++) {
/* 301:460 */         builder.append(this.array[i] != 0 ? ", true" : ", false");
/* 302:    */       }
/* 303:462 */       return ']';
/* 304:    */     }
/* 305:    */     
/* 306:    */     boolean[] toBooleanArray()
/* 307:    */     {
/* 308:467 */       int size = size();
/* 309:468 */       boolean[] result = new boolean[size];
/* 310:469 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 311:470 */       return result;
/* 312:    */     }
/* 313:    */   }
/* 314:    */   
/* 315:    */   @Beta
/* 316:    */   public static int countTrue(boolean... values)
/* 317:    */   {
/* 318:483 */     int count = 0;
/* 319:484 */     for (boolean value : values) {
/* 320:485 */       if (value) {
/* 321:486 */         count++;
/* 322:    */       }
/* 323:    */     }
/* 324:489 */     return count;
/* 325:    */   }
/* 326:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Booleans
 * JD-Core Version:    0.7.0.1
 */
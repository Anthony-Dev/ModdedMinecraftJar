/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import java.util.regex.Matcher;
/*  16:    */ import java.util.regex.Pattern;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class Floats
/*  21:    */ {
/*  22:    */   public static final int BYTES = 4;
/*  23:    */   
/*  24:    */   public static int hashCode(float value)
/*  25:    */   {
/*  26: 74 */     return Float.valueOf(value).hashCode();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static int compare(float a, float b)
/*  30:    */   {
/*  31: 92 */     return Float.compare(a, b);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static boolean isFinite(float value)
/*  35:    */   {
/*  36:103 */     return ((1.0F / -1.0F) < value ? 1 : 0) & (value < (1.0F / 1.0F) ? 1 : 0);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static boolean contains(float[] array, float target)
/*  40:    */   {
/*  41:117 */     for (float value : array) {
/*  42:118 */       if (value == target) {
/*  43:119 */         return true;
/*  44:    */       }
/*  45:    */     }
/*  46:122 */     return false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static int indexOf(float[] array, float target)
/*  50:    */   {
/*  51:136 */     return indexOf(array, target, 0, array.length);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static int indexOf(float[] array, float target, int start, int end)
/*  55:    */   {
/*  56:142 */     for (int i = start; i < end; i++) {
/*  57:143 */       if (array[i] == target) {
/*  58:144 */         return i;
/*  59:    */       }
/*  60:    */     }
/*  61:147 */     return -1;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static int indexOf(float[] array, float[] target)
/*  65:    */   {
/*  66:165 */     Preconditions.checkNotNull(array, "array");
/*  67:166 */     Preconditions.checkNotNull(target, "target");
/*  68:167 */     if (target.length == 0) {
/*  69:168 */       return 0;
/*  70:    */     }
/*  71:    */     label65:
/*  72:172 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  73:    */     {
/*  74:173 */       for (int j = 0; j < target.length; j++) {
/*  75:174 */         if (array[(i + j)] != target[j]) {
/*  76:    */           break label65;
/*  77:    */         }
/*  78:    */       }
/*  79:178 */       return i;
/*  80:    */     }
/*  81:180 */     return -1;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static int lastIndexOf(float[] array, float target)
/*  85:    */   {
/*  86:194 */     return lastIndexOf(array, target, 0, array.length);
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static int lastIndexOf(float[] array, float target, int start, int end)
/*  90:    */   {
/*  91:200 */     for (int i = end - 1; i >= start; i--) {
/*  92:201 */       if (array[i] == target) {
/*  93:202 */         return i;
/*  94:    */       }
/*  95:    */     }
/*  96:205 */     return -1;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static float min(float... array)
/* 100:    */   {
/* 101:218 */     Preconditions.checkArgument(array.length > 0);
/* 102:219 */     float min = array[0];
/* 103:220 */     for (int i = 1; i < array.length; i++) {
/* 104:221 */       min = Math.min(min, array[i]);
/* 105:    */     }
/* 106:223 */     return min;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static float max(float... array)
/* 110:    */   {
/* 111:236 */     Preconditions.checkArgument(array.length > 0);
/* 112:237 */     float max = array[0];
/* 113:238 */     for (int i = 1; i < array.length; i++) {
/* 114:239 */       max = Math.max(max, array[i]);
/* 115:    */     }
/* 116:241 */     return max;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static float[] concat(float[]... arrays)
/* 120:    */   {
/* 121:254 */     int length = 0;
/* 122:255 */     for (float[] array : arrays) {
/* 123:256 */       length += array.length;
/* 124:    */     }
/* 125:258 */     float[] result = new float[length];
/* 126:259 */     int pos = 0;
/* 127:260 */     for (float[] array : arrays)
/* 128:    */     {
/* 129:261 */       System.arraycopy(array, 0, result, pos, array.length);
/* 130:262 */       pos += array.length;
/* 131:    */     }
/* 132:264 */     return result;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static final class FloatConverter
/* 136:    */     extends Converter<String, Float>
/* 137:    */     implements Serializable
/* 138:    */   {
/* 139:269 */     static final FloatConverter INSTANCE = new FloatConverter();
/* 140:    */     private static final long serialVersionUID = 1L;
/* 141:    */     
/* 142:    */     protected Float doForward(String value)
/* 143:    */     {
/* 144:273 */       return Float.valueOf(value);
/* 145:    */     }
/* 146:    */     
/* 147:    */     protected String doBackward(Float value)
/* 148:    */     {
/* 149:278 */       return value.toString();
/* 150:    */     }
/* 151:    */     
/* 152:    */     public String toString()
/* 153:    */     {
/* 154:283 */       return "Floats.stringConverter()";
/* 155:    */     }
/* 156:    */     
/* 157:    */     private Object readResolve()
/* 158:    */     {
/* 159:287 */       return INSTANCE;
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   @Beta
/* 164:    */   public static Converter<String, Float> stringConverter()
/* 165:    */   {
/* 166:300 */     return FloatConverter.INSTANCE;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static float[] ensureCapacity(float[] array, int minLength, int padding)
/* 170:    */   {
/* 171:321 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 172:322 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 173:323 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private static float[] copyOf(float[] original, int length)
/* 177:    */   {
/* 178:330 */     float[] copy = new float[length];
/* 179:331 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 180:332 */     return copy;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static String join(String separator, float... array)
/* 184:    */   {
/* 185:350 */     Preconditions.checkNotNull(separator);
/* 186:351 */     if (array.length == 0) {
/* 187:352 */       return "";
/* 188:    */     }
/* 189:356 */     StringBuilder builder = new StringBuilder(array.length * 12);
/* 190:357 */     builder.append(array[0]);
/* 191:358 */     for (int i = 1; i < array.length; i++) {
/* 192:359 */       builder.append(separator).append(array[i]);
/* 193:    */     }
/* 194:361 */     return builder.toString();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static Comparator<float[]> lexicographicalComparator()
/* 198:    */   {
/* 199:381 */     return LexicographicalComparator.INSTANCE;
/* 200:    */   }
/* 201:    */   
/* 202:    */   private static enum LexicographicalComparator
/* 203:    */     implements Comparator<float[]>
/* 204:    */   {
/* 205:385 */     INSTANCE;
/* 206:    */     
/* 207:    */     private LexicographicalComparator() {}
/* 208:    */     
/* 209:    */     public int compare(float[] left, float[] right)
/* 210:    */     {
/* 211:389 */       int minLength = Math.min(left.length, right.length);
/* 212:390 */       for (int i = 0; i < minLength; i++)
/* 213:    */       {
/* 214:391 */         int result = Floats.compare(left[i], right[i]);
/* 215:392 */         if (result != 0) {
/* 216:393 */           return result;
/* 217:    */         }
/* 218:    */       }
/* 219:396 */       return left.length - right.length;
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   public static float[] toArray(Collection<? extends Number> collection)
/* 224:    */   {
/* 225:416 */     if ((collection instanceof FloatArrayAsList)) {
/* 226:417 */       return ((FloatArrayAsList)collection).toFloatArray();
/* 227:    */     }
/* 228:420 */     Object[] boxedArray = collection.toArray();
/* 229:421 */     int len = boxedArray.length;
/* 230:422 */     float[] array = new float[len];
/* 231:423 */     for (int i = 0; i < len; i++) {
/* 232:425 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).floatValue();
/* 233:    */     }
/* 234:427 */     return array;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static List<Float> asList(float... backingArray)
/* 238:    */   {
/* 239:448 */     if (backingArray.length == 0) {
/* 240:449 */       return Collections.emptyList();
/* 241:    */     }
/* 242:451 */     return new FloatArrayAsList(backingArray);
/* 243:    */   }
/* 244:    */   
/* 245:    */   @GwtCompatible
/* 246:    */   private static class FloatArrayAsList
/* 247:    */     extends AbstractList<Float>
/* 248:    */     implements RandomAccess, Serializable
/* 249:    */   {
/* 250:    */     final float[] array;
/* 251:    */     final int start;
/* 252:    */     final int end;
/* 253:    */     private static final long serialVersionUID = 0L;
/* 254:    */     
/* 255:    */     FloatArrayAsList(float[] array)
/* 256:    */     {
/* 257:462 */       this(array, 0, array.length);
/* 258:    */     }
/* 259:    */     
/* 260:    */     FloatArrayAsList(float[] array, int start, int end)
/* 261:    */     {
/* 262:466 */       this.array = array;
/* 263:467 */       this.start = start;
/* 264:468 */       this.end = end;
/* 265:    */     }
/* 266:    */     
/* 267:    */     public int size()
/* 268:    */     {
/* 269:472 */       return this.end - this.start;
/* 270:    */     }
/* 271:    */     
/* 272:    */     public boolean isEmpty()
/* 273:    */     {
/* 274:476 */       return false;
/* 275:    */     }
/* 276:    */     
/* 277:    */     public Float get(int index)
/* 278:    */     {
/* 279:480 */       Preconditions.checkElementIndex(index, size());
/* 280:481 */       return Float.valueOf(this.array[(this.start + index)]);
/* 281:    */     }
/* 282:    */     
/* 283:    */     public boolean contains(Object target)
/* 284:    */     {
/* 285:486 */       return ((target instanceof Float)) && (Floats.indexOf(this.array, ((Float)target).floatValue(), this.start, this.end) != -1);
/* 286:    */     }
/* 287:    */     
/* 288:    */     public int indexOf(Object target)
/* 289:    */     {
/* 290:492 */       if ((target instanceof Float))
/* 291:    */       {
/* 292:493 */         int i = Floats.indexOf(this.array, ((Float)target).floatValue(), this.start, this.end);
/* 293:494 */         if (i >= 0) {
/* 294:495 */           return i - this.start;
/* 295:    */         }
/* 296:    */       }
/* 297:498 */       return -1;
/* 298:    */     }
/* 299:    */     
/* 300:    */     public int lastIndexOf(Object target)
/* 301:    */     {
/* 302:503 */       if ((target instanceof Float))
/* 303:    */       {
/* 304:504 */         int i = Floats.lastIndexOf(this.array, ((Float)target).floatValue(), this.start, this.end);
/* 305:505 */         if (i >= 0) {
/* 306:506 */           return i - this.start;
/* 307:    */         }
/* 308:    */       }
/* 309:509 */       return -1;
/* 310:    */     }
/* 311:    */     
/* 312:    */     public Float set(int index, Float element)
/* 313:    */     {
/* 314:513 */       Preconditions.checkElementIndex(index, size());
/* 315:514 */       float oldValue = this.array[(this.start + index)];
/* 316:    */       
/* 317:516 */       this.array[(this.start + index)] = ((Float)Preconditions.checkNotNull(element)).floatValue();
/* 318:517 */       return Float.valueOf(oldValue);
/* 319:    */     }
/* 320:    */     
/* 321:    */     public List<Float> subList(int fromIndex, int toIndex)
/* 322:    */     {
/* 323:521 */       int size = size();
/* 324:522 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 325:523 */       if (fromIndex == toIndex) {
/* 326:524 */         return Collections.emptyList();
/* 327:    */       }
/* 328:526 */       return new FloatArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 329:    */     }
/* 330:    */     
/* 331:    */     public boolean equals(Object object)
/* 332:    */     {
/* 333:530 */       if (object == this) {
/* 334:531 */         return true;
/* 335:    */       }
/* 336:533 */       if ((object instanceof FloatArrayAsList))
/* 337:    */       {
/* 338:534 */         FloatArrayAsList that = (FloatArrayAsList)object;
/* 339:535 */         int size = size();
/* 340:536 */         if (that.size() != size) {
/* 341:537 */           return false;
/* 342:    */         }
/* 343:539 */         for (int i = 0; i < size; i++) {
/* 344:540 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 345:541 */             return false;
/* 346:    */           }
/* 347:    */         }
/* 348:544 */         return true;
/* 349:    */       }
/* 350:546 */       return super.equals(object);
/* 351:    */     }
/* 352:    */     
/* 353:    */     public int hashCode()
/* 354:    */     {
/* 355:550 */       int result = 1;
/* 356:551 */       for (int i = this.start; i < this.end; i++) {
/* 357:552 */         result = 31 * result + Floats.hashCode(this.array[i]);
/* 358:    */       }
/* 359:554 */       return result;
/* 360:    */     }
/* 361:    */     
/* 362:    */     public String toString()
/* 363:    */     {
/* 364:558 */       StringBuilder builder = new StringBuilder(size() * 12);
/* 365:559 */       builder.append('[').append(this.array[this.start]);
/* 366:560 */       for (int i = this.start + 1; i < this.end; i++) {
/* 367:561 */         builder.append(", ").append(this.array[i]);
/* 368:    */       }
/* 369:563 */       return ']';
/* 370:    */     }
/* 371:    */     
/* 372:    */     float[] toFloatArray()
/* 373:    */     {
/* 374:568 */       int size = size();
/* 375:569 */       float[] result = new float[size];
/* 376:570 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 377:571 */       return result;
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   @Nullable
/* 382:    */   @GwtIncompatible("regular expressions")
/* 383:    */   @Beta
/* 384:    */   public static Float tryParse(String string)
/* 385:    */   {
/* 386:600 */     if (Doubles.FLOATING_POINT_PATTERN.matcher(string).matches()) {
/* 387:    */       try
/* 388:    */       {
/* 389:604 */         return Float.valueOf(Float.parseFloat(string));
/* 390:    */       }
/* 391:    */       catch (NumberFormatException e) {}
/* 392:    */     }
/* 393:610 */     return null;
/* 394:    */   }
/* 395:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Floats
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Comparator;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ @GwtCompatible
/*  10:    */ public final class UnsignedInts
/*  11:    */ {
/*  12:    */   static final long INT_MASK = 4294967295L;
/*  13:    */   
/*  14:    */   static int flip(int value)
/*  15:    */   {
/*  16: 55 */     return value ^ 0x80000000;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public static int compare(int a, int b)
/*  20:    */   {
/*  21: 68 */     return Ints.compare(flip(a), flip(b));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static long toLong(int value)
/*  25:    */   {
/*  26: 75 */     return value & 0xFFFFFFFF;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static int min(int... array)
/*  30:    */   {
/*  31: 87 */     Preconditions.checkArgument(array.length > 0);
/*  32: 88 */     int min = flip(array[0]);
/*  33: 89 */     for (int i = 1; i < array.length; i++)
/*  34:    */     {
/*  35: 90 */       int next = flip(array[i]);
/*  36: 91 */       if (next < min) {
/*  37: 92 */         min = next;
/*  38:    */       }
/*  39:    */     }
/*  40: 95 */     return flip(min);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static int max(int... array)
/*  44:    */   {
/*  45:107 */     Preconditions.checkArgument(array.length > 0);
/*  46:108 */     int max = flip(array[0]);
/*  47:109 */     for (int i = 1; i < array.length; i++)
/*  48:    */     {
/*  49:110 */       int next = flip(array[i]);
/*  50:111 */       if (next > max) {
/*  51:112 */         max = next;
/*  52:    */       }
/*  53:    */     }
/*  54:115 */     return flip(max);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static String join(String separator, int... array)
/*  58:    */   {
/*  59:127 */     Preconditions.checkNotNull(separator);
/*  60:128 */     if (array.length == 0) {
/*  61:129 */       return "";
/*  62:    */     }
/*  63:133 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  64:134 */     builder.append(toString(array[0]));
/*  65:135 */     for (int i = 1; i < array.length; i++) {
/*  66:136 */       builder.append(separator).append(toString(array[i]));
/*  67:    */     }
/*  68:138 */     return builder.toString();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static Comparator<int[]> lexicographicalComparator()
/*  72:    */   {
/*  73:154 */     return LexicographicalComparator.INSTANCE;
/*  74:    */   }
/*  75:    */   
/*  76:    */   static enum LexicographicalComparator
/*  77:    */     implements Comparator<int[]>
/*  78:    */   {
/*  79:158 */     INSTANCE;
/*  80:    */     
/*  81:    */     private LexicographicalComparator() {}
/*  82:    */     
/*  83:    */     public int compare(int[] left, int[] right)
/*  84:    */     {
/*  85:162 */       int minLength = Math.min(left.length, right.length);
/*  86:163 */       for (int i = 0; i < minLength; i++) {
/*  87:164 */         if (left[i] != right[i]) {
/*  88:165 */           return UnsignedInts.compare(left[i], right[i]);
/*  89:    */         }
/*  90:    */       }
/*  91:168 */       return left.length - right.length;
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static int divide(int dividend, int divisor)
/*  96:    */   {
/*  97:181 */     return (int)(toLong(dividend) / toLong(divisor));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static int remainder(int dividend, int divisor)
/* 101:    */   {
/* 102:193 */     return (int)(toLong(dividend) % toLong(divisor));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static int decode(String stringValue)
/* 106:    */   {
/* 107:212 */     ParseRequest request = ParseRequest.fromString(stringValue);
/* 108:    */     try
/* 109:    */     {
/* 110:215 */       return parseUnsignedInt(request.rawValue, request.radix);
/* 111:    */     }
/* 112:    */     catch (NumberFormatException e)
/* 113:    */     {
/* 114:217 */       NumberFormatException decodeException = new NumberFormatException("Error parsing value: " + stringValue);
/* 115:    */       
/* 116:219 */       decodeException.initCause(e);
/* 117:220 */       throw decodeException;
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static int parseUnsignedInt(String s)
/* 122:    */   {
/* 123:232 */     return parseUnsignedInt(s, 10);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static int parseUnsignedInt(String string, int radix)
/* 127:    */   {
/* 128:247 */     Preconditions.checkNotNull(string);
/* 129:248 */     long result = Long.parseLong(string, radix);
/* 130:249 */     if ((result & 0xFFFFFFFF) != result) {
/* 131:250 */       throw new NumberFormatException("Input " + string + " in base " + radix + " is not in the range of an unsigned integer");
/* 132:    */     }
/* 133:253 */     return (int)result;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static String toString(int x)
/* 137:    */   {
/* 138:260 */     return toString(x, 10);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static String toString(int x, int radix)
/* 142:    */   {
/* 143:273 */     long asLong = x & 0xFFFFFFFF;
/* 144:274 */     return Long.toString(asLong, radix);
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.UnsignedInts
 * JD-Core Version:    0.7.0.1
 */
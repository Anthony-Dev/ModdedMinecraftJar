/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ 
/*   9:    */ public final class Primitives
/*  10:    */ {
/*  11:    */   private static final Map<Class<?>, Class<?>> PRIMITIVE_TO_WRAPPER_TYPE;
/*  12:    */   private static final Map<Class<?>, Class<?>> WRAPPER_TO_PRIMITIVE_TYPE;
/*  13:    */   
/*  14:    */   static
/*  15:    */   {
/*  16: 45 */     Map<Class<?>, Class<?>> primToWrap = new HashMap(16);
/*  17: 46 */     Map<Class<?>, Class<?>> wrapToPrim = new HashMap(16);
/*  18:    */     
/*  19: 48 */     add(primToWrap, wrapToPrim, Boolean.TYPE, Boolean.class);
/*  20: 49 */     add(primToWrap, wrapToPrim, Byte.TYPE, Byte.class);
/*  21: 50 */     add(primToWrap, wrapToPrim, Character.TYPE, Character.class);
/*  22: 51 */     add(primToWrap, wrapToPrim, Double.TYPE, Double.class);
/*  23: 52 */     add(primToWrap, wrapToPrim, Float.TYPE, Float.class);
/*  24: 53 */     add(primToWrap, wrapToPrim, Integer.TYPE, Integer.class);
/*  25: 54 */     add(primToWrap, wrapToPrim, Long.TYPE, Long.class);
/*  26: 55 */     add(primToWrap, wrapToPrim, Short.TYPE, Short.class);
/*  27: 56 */     add(primToWrap, wrapToPrim, Void.TYPE, Void.class);
/*  28:    */     
/*  29: 58 */     PRIMITIVE_TO_WRAPPER_TYPE = Collections.unmodifiableMap(primToWrap);
/*  30: 59 */     WRAPPER_TO_PRIMITIVE_TYPE = Collections.unmodifiableMap(wrapToPrim);
/*  31:    */   }
/*  32:    */   
/*  33:    */   private static void add(Map<Class<?>, Class<?>> forward, Map<Class<?>, Class<?>> backward, Class<?> key, Class<?> value)
/*  34:    */   {
/*  35: 64 */     forward.put(key, value);
/*  36: 65 */     backward.put(value, key);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static Set<Class<?>> allPrimitiveTypes()
/*  40:    */   {
/*  41: 76 */     return PRIMITIVE_TO_WRAPPER_TYPE.keySet();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static Set<Class<?>> allWrapperTypes()
/*  45:    */   {
/*  46: 86 */     return WRAPPER_TO_PRIMITIVE_TYPE.keySet();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static boolean isWrapperType(Class<?> type)
/*  50:    */   {
/*  51: 96 */     return WRAPPER_TO_PRIMITIVE_TYPE.containsKey(Preconditions.checkNotNull(type));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <T> Class<T> wrap(Class<T> type)
/*  55:    */   {
/*  56:109 */     Preconditions.checkNotNull(type);
/*  57:    */     
/*  58:    */ 
/*  59:    */ 
/*  60:113 */     Class<T> wrapped = (Class)PRIMITIVE_TO_WRAPPER_TYPE.get(type);
/*  61:114 */     return wrapped == null ? type : wrapped;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static <T> Class<T> unwrap(Class<T> type)
/*  65:    */   {
/*  66:127 */     Preconditions.checkNotNull(type);
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70:131 */     Class<T> unwrapped = (Class)WRAPPER_TO_PRIMITIVE_TYPE.get(type);
/*  71:132 */     return unwrapped == null ? type : unwrapped;
/*  72:    */   }
/*  73:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Primitives
 * JD-Core Version:    0.7.0.1
 */
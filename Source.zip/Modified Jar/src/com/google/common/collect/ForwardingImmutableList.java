package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class ForwardingImmutableList<E> {}


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingImmutableList
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.base.Objects;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import com.google.common.base.Predicate;
/*    8:     */ import com.google.common.base.Predicates;
/*    9:     */ import com.google.common.primitives.Ints;
/*   10:     */ import java.io.Serializable;
/*   11:     */ import java.util.Collection;
/*   12:     */ import java.util.Collections;
/*   13:     */ import java.util.Iterator;
/*   14:     */ import java.util.List;
/*   15:     */ import java.util.NoSuchElementException;
/*   16:     */ import java.util.Set;
/*   17:     */ import javax.annotation.Nullable;
/*   18:     */ 
/*   19:     */ @GwtCompatible
/*   20:     */ public final class Multisets
/*   21:     */ {
/*   22:     */   public static <E> Multiset<E> unmodifiableMultiset(Multiset<? extends E> multiset)
/*   23:     */   {
/*   24:  74 */     if (((multiset instanceof UnmodifiableMultiset)) || ((multiset instanceof ImmutableMultiset)))
/*   25:     */     {
/*   26:  78 */       Multiset<E> result = multiset;
/*   27:  79 */       return result;
/*   28:     */     }
/*   29:  81 */     return new UnmodifiableMultiset((Multiset)Preconditions.checkNotNull(multiset));
/*   30:     */   }
/*   31:     */   
/*   32:     */   @Deprecated
/*   33:     */   public static <E> Multiset<E> unmodifiableMultiset(ImmutableMultiset<E> multiset)
/*   34:     */   {
/*   35:  92 */     return (Multiset)Preconditions.checkNotNull(multiset);
/*   36:     */   }
/*   37:     */   
/*   38:     */   static class UnmodifiableMultiset<E>
/*   39:     */     extends ForwardingMultiset<E>
/*   40:     */     implements Serializable
/*   41:     */   {
/*   42:     */     final Multiset<? extends E> delegate;
/*   43:     */     transient Set<E> elementSet;
/*   44:     */     transient Set<Multiset.Entry<E>> entrySet;
/*   45:     */     private static final long serialVersionUID = 0L;
/*   46:     */     
/*   47:     */     UnmodifiableMultiset(Multiset<? extends E> delegate)
/*   48:     */     {
/*   49: 100 */       this.delegate = delegate;
/*   50:     */     }
/*   51:     */     
/*   52:     */     protected Multiset<E> delegate()
/*   53:     */     {
/*   54: 106 */       return this.delegate;
/*   55:     */     }
/*   56:     */     
/*   57:     */     Set<E> createElementSet()
/*   58:     */     {
/*   59: 112 */       return Collections.unmodifiableSet(this.delegate.elementSet());
/*   60:     */     }
/*   61:     */     
/*   62:     */     public Set<E> elementSet()
/*   63:     */     {
/*   64: 117 */       Set<E> es = this.elementSet;
/*   65: 118 */       return es == null ? (this.elementSet = createElementSet()) : es;
/*   66:     */     }
/*   67:     */     
/*   68:     */     public Set<Multiset.Entry<E>> entrySet()
/*   69:     */     {
/*   70: 125 */       Set<Multiset.Entry<E>> es = this.entrySet;
/*   71: 126 */       return es == null ? (this.entrySet = Collections.unmodifiableSet(this.delegate.entrySet())) : es;
/*   72:     */     }
/*   73:     */     
/*   74:     */     public Iterator<E> iterator()
/*   75:     */     {
/*   76: 136 */       return Iterators.unmodifiableIterator(this.delegate.iterator());
/*   77:     */     }
/*   78:     */     
/*   79:     */     public boolean add(E element)
/*   80:     */     {
/*   81: 140 */       throw new UnsupportedOperationException();
/*   82:     */     }
/*   83:     */     
/*   84:     */     public int add(E element, int occurences)
/*   85:     */     {
/*   86: 144 */       throw new UnsupportedOperationException();
/*   87:     */     }
/*   88:     */     
/*   89:     */     public boolean addAll(Collection<? extends E> elementsToAdd)
/*   90:     */     {
/*   91: 148 */       throw new UnsupportedOperationException();
/*   92:     */     }
/*   93:     */     
/*   94:     */     public boolean remove(Object element)
/*   95:     */     {
/*   96: 152 */       throw new UnsupportedOperationException();
/*   97:     */     }
/*   98:     */     
/*   99:     */     public int remove(Object element, int occurrences)
/*  100:     */     {
/*  101: 156 */       throw new UnsupportedOperationException();
/*  102:     */     }
/*  103:     */     
/*  104:     */     public boolean removeAll(Collection<?> elementsToRemove)
/*  105:     */     {
/*  106: 160 */       throw new UnsupportedOperationException();
/*  107:     */     }
/*  108:     */     
/*  109:     */     public boolean retainAll(Collection<?> elementsToRetain)
/*  110:     */     {
/*  111: 164 */       throw new UnsupportedOperationException();
/*  112:     */     }
/*  113:     */     
/*  114:     */     public void clear()
/*  115:     */     {
/*  116: 168 */       throw new UnsupportedOperationException();
/*  117:     */     }
/*  118:     */     
/*  119:     */     public int setCount(E element, int count)
/*  120:     */     {
/*  121: 172 */       throw new UnsupportedOperationException();
/*  122:     */     }
/*  123:     */     
/*  124:     */     public boolean setCount(E element, int oldCount, int newCount)
/*  125:     */     {
/*  126: 176 */       throw new UnsupportedOperationException();
/*  127:     */     }
/*  128:     */   }
/*  129:     */   
/*  130:     */   @Beta
/*  131:     */   public static <E> SortedMultiset<E> unmodifiableSortedMultiset(SortedMultiset<E> sortedMultiset)
/*  132:     */   {
/*  133: 200 */     return new UnmodifiableSortedMultiset((SortedMultiset)Preconditions.checkNotNull(sortedMultiset));
/*  134:     */   }
/*  135:     */   
/*  136:     */   public static <E> Multiset.Entry<E> immutableEntry(@Nullable E e, int n)
/*  137:     */   {
/*  138: 212 */     return new ImmutableEntry(e, n);
/*  139:     */   }
/*  140:     */   
/*  141:     */   static final class ImmutableEntry<E>
/*  142:     */     extends Multisets.AbstractEntry<E>
/*  143:     */     implements Serializable
/*  144:     */   {
/*  145:     */     @Nullable
/*  146:     */     final E element;
/*  147:     */     final int count;
/*  148:     */     private static final long serialVersionUID = 0L;
/*  149:     */     
/*  150:     */     ImmutableEntry(@Nullable E element, int count)
/*  151:     */     {
/*  152: 221 */       this.element = element;
/*  153: 222 */       this.count = count;
/*  154: 223 */       CollectPreconditions.checkNonnegative(count, "count");
/*  155:     */     }
/*  156:     */     
/*  157:     */     @Nullable
/*  158:     */     public E getElement()
/*  159:     */     {
/*  160: 228 */       return this.element;
/*  161:     */     }
/*  162:     */     
/*  163:     */     public int getCount()
/*  164:     */     {
/*  165: 233 */       return this.count;
/*  166:     */     }
/*  167:     */   }
/*  168:     */   
/*  169:     */   @Beta
/*  170:     */   public static <E> Multiset<E> filter(Multiset<E> unfiltered, Predicate<? super E> predicate)
/*  171:     */   {
/*  172: 267 */     if ((unfiltered instanceof FilteredMultiset))
/*  173:     */     {
/*  174: 270 */       FilteredMultiset<E> filtered = (FilteredMultiset)unfiltered;
/*  175: 271 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  176:     */       
/*  177: 273 */       return new FilteredMultiset(filtered.unfiltered, combinedPredicate);
/*  178:     */     }
/*  179: 275 */     return new FilteredMultiset(unfiltered, predicate);
/*  180:     */   }
/*  181:     */   
/*  182:     */   private static final class FilteredMultiset<E>
/*  183:     */     extends AbstractMultiset<E>
/*  184:     */   {
/*  185:     */     final Multiset<E> unfiltered;
/*  186:     */     final Predicate<? super E> predicate;
/*  187:     */     
/*  188:     */     FilteredMultiset(Multiset<E> unfiltered, Predicate<? super E> predicate)
/*  189:     */     {
/*  190: 283 */       this.unfiltered = ((Multiset)Preconditions.checkNotNull(unfiltered));
/*  191: 284 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*  192:     */     }
/*  193:     */     
/*  194:     */     public UnmodifiableIterator<E> iterator()
/*  195:     */     {
/*  196: 289 */       return Iterators.filter(this.unfiltered.iterator(), this.predicate);
/*  197:     */     }
/*  198:     */     
/*  199:     */     Set<E> createElementSet()
/*  200:     */     {
/*  201: 294 */       return Sets.filter(this.unfiltered.elementSet(), this.predicate);
/*  202:     */     }
/*  203:     */     
/*  204:     */     Set<Multiset.Entry<E>> createEntrySet()
/*  205:     */     {
/*  206: 299 */       Sets.filter(this.unfiltered.entrySet(), new Predicate()
/*  207:     */       {
/*  208:     */         public boolean apply(Multiset.Entry<E> entry)
/*  209:     */         {
/*  210: 302 */           return Multisets.FilteredMultiset.this.predicate.apply(entry.getElement());
/*  211:     */         }
/*  212:     */       });
/*  213:     */     }
/*  214:     */     
/*  215:     */     Iterator<Multiset.Entry<E>> entryIterator()
/*  216:     */     {
/*  217: 309 */       throw new AssertionError("should never be called");
/*  218:     */     }
/*  219:     */     
/*  220:     */     int distinctElements()
/*  221:     */     {
/*  222: 314 */       return elementSet().size();
/*  223:     */     }
/*  224:     */     
/*  225:     */     public int count(@Nullable Object element)
/*  226:     */     {
/*  227: 319 */       int count = this.unfiltered.count(element);
/*  228: 320 */       if (count > 0)
/*  229:     */       {
/*  230: 322 */         E e = element;
/*  231: 323 */         return this.predicate.apply(e) ? count : 0;
/*  232:     */       }
/*  233: 325 */       return 0;
/*  234:     */     }
/*  235:     */     
/*  236:     */     public int add(@Nullable E element, int occurrences)
/*  237:     */     {
/*  238: 330 */       Preconditions.checkArgument(this.predicate.apply(element), "Element %s does not match predicate %s", new Object[] { element, this.predicate });
/*  239:     */       
/*  240: 332 */       return this.unfiltered.add(element, occurrences);
/*  241:     */     }
/*  242:     */     
/*  243:     */     public int remove(@Nullable Object element, int occurrences)
/*  244:     */     {
/*  245: 337 */       CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/*  246: 338 */       if (occurrences == 0) {
/*  247: 339 */         return count(element);
/*  248:     */       }
/*  249: 341 */       return contains(element) ? this.unfiltered.remove(element, occurrences) : 0;
/*  250:     */     }
/*  251:     */     
/*  252:     */     public void clear()
/*  253:     */     {
/*  254: 347 */       elementSet().clear();
/*  255:     */     }
/*  256:     */   }
/*  257:     */   
/*  258:     */   static int inferDistinctElements(Iterable<?> elements)
/*  259:     */   {
/*  260: 358 */     if ((elements instanceof Multiset)) {
/*  261: 359 */       return ((Multiset)elements).elementSet().size();
/*  262:     */     }
/*  263: 361 */     return 11;
/*  264:     */   }
/*  265:     */   
/*  266:     */   @Beta
/*  267:     */   public static <E> Multiset<E> union(Multiset<? extends E> multiset1, final Multiset<? extends E> multiset2)
/*  268:     */   {
/*  269: 382 */     Preconditions.checkNotNull(multiset1);
/*  270: 383 */     Preconditions.checkNotNull(multiset2);
/*  271:     */     
/*  272: 385 */     new AbstractMultiset()
/*  273:     */     {
/*  274:     */       public boolean contains(@Nullable Object element)
/*  275:     */       {
/*  276: 388 */         return (this.val$multiset1.contains(element)) || (multiset2.contains(element));
/*  277:     */       }
/*  278:     */       
/*  279:     */       public boolean isEmpty()
/*  280:     */       {
/*  281: 393 */         return (this.val$multiset1.isEmpty()) && (multiset2.isEmpty());
/*  282:     */       }
/*  283:     */       
/*  284:     */       public int count(Object element)
/*  285:     */       {
/*  286: 398 */         return Math.max(this.val$multiset1.count(element), multiset2.count(element));
/*  287:     */       }
/*  288:     */       
/*  289:     */       Set<E> createElementSet()
/*  290:     */       {
/*  291: 403 */         return Sets.union(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  292:     */       }
/*  293:     */       
/*  294:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  295:     */       {
/*  296: 408 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  297:     */         
/*  298: 410 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator2 = multiset2.entrySet().iterator();
/*  299:     */         
/*  300:     */ 
/*  301: 413 */         new AbstractIterator()
/*  302:     */         {
/*  303:     */           protected Multiset.Entry<E> computeNext()
/*  304:     */           {
/*  305: 416 */             if (iterator1.hasNext())
/*  306:     */             {
/*  307: 417 */               Multiset.Entry<? extends E> entry1 = (Multiset.Entry)iterator1.next();
/*  308: 418 */               E element = entry1.getElement();
/*  309: 419 */               int count = Math.max(entry1.getCount(), Multisets.1.this.val$multiset2.count(element));
/*  310: 420 */               return Multisets.immutableEntry(element, count);
/*  311:     */             }
/*  312: 422 */             while (iterator2.hasNext())
/*  313:     */             {
/*  314: 423 */               Multiset.Entry<? extends E> entry2 = (Multiset.Entry)iterator2.next();
/*  315: 424 */               E element = entry2.getElement();
/*  316: 425 */               if (!Multisets.1.this.val$multiset1.contains(element)) {
/*  317: 426 */                 return Multisets.immutableEntry(element, entry2.getCount());
/*  318:     */               }
/*  319:     */             }
/*  320: 429 */             return (Multiset.Entry)endOfData();
/*  321:     */           }
/*  322:     */         };
/*  323:     */       }
/*  324:     */       
/*  325:     */       int distinctElements()
/*  326:     */       {
/*  327: 436 */         return elementSet().size();
/*  328:     */       }
/*  329:     */     };
/*  330:     */   }
/*  331:     */   
/*  332:     */   public static <E> Multiset<E> intersection(Multiset<E> multiset1, final Multiset<?> multiset2)
/*  333:     */   {
/*  334: 457 */     Preconditions.checkNotNull(multiset1);
/*  335: 458 */     Preconditions.checkNotNull(multiset2);
/*  336:     */     
/*  337: 460 */     new AbstractMultiset()
/*  338:     */     {
/*  339:     */       public int count(Object element)
/*  340:     */       {
/*  341: 463 */         int count1 = this.val$multiset1.count(element);
/*  342: 464 */         return count1 == 0 ? 0 : Math.min(count1, multiset2.count(element));
/*  343:     */       }
/*  344:     */       
/*  345:     */       Set<E> createElementSet()
/*  346:     */       {
/*  347: 469 */         return Sets.intersection(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  348:     */       }
/*  349:     */       
/*  350:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  351:     */       {
/*  352: 475 */         final Iterator<Multiset.Entry<E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  353:     */         
/*  354: 477 */         new AbstractIterator()
/*  355:     */         {
/*  356:     */           protected Multiset.Entry<E> computeNext()
/*  357:     */           {
/*  358: 480 */             while (iterator1.hasNext())
/*  359:     */             {
/*  360: 481 */               Multiset.Entry<E> entry1 = (Multiset.Entry)iterator1.next();
/*  361: 482 */               E element = entry1.getElement();
/*  362: 483 */               int count = Math.min(entry1.getCount(), Multisets.2.this.val$multiset2.count(element));
/*  363: 484 */               if (count > 0) {
/*  364: 485 */                 return Multisets.immutableEntry(element, count);
/*  365:     */               }
/*  366:     */             }
/*  367: 488 */             return (Multiset.Entry)endOfData();
/*  368:     */           }
/*  369:     */         };
/*  370:     */       }
/*  371:     */       
/*  372:     */       int distinctElements()
/*  373:     */       {
/*  374: 495 */         return elementSet().size();
/*  375:     */       }
/*  376:     */     };
/*  377:     */   }
/*  378:     */   
/*  379:     */   @Beta
/*  380:     */   public static <E> Multiset<E> sum(Multiset<? extends E> multiset1, final Multiset<? extends E> multiset2)
/*  381:     */   {
/*  382: 518 */     Preconditions.checkNotNull(multiset1);
/*  383: 519 */     Preconditions.checkNotNull(multiset2);
/*  384:     */     
/*  385:     */ 
/*  386: 522 */     new AbstractMultiset()
/*  387:     */     {
/*  388:     */       public boolean contains(@Nullable Object element)
/*  389:     */       {
/*  390: 525 */         return (this.val$multiset1.contains(element)) || (multiset2.contains(element));
/*  391:     */       }
/*  392:     */       
/*  393:     */       public boolean isEmpty()
/*  394:     */       {
/*  395: 530 */         return (this.val$multiset1.isEmpty()) && (multiset2.isEmpty());
/*  396:     */       }
/*  397:     */       
/*  398:     */       public int size()
/*  399:     */       {
/*  400: 535 */         return this.val$multiset1.size() + multiset2.size();
/*  401:     */       }
/*  402:     */       
/*  403:     */       public int count(Object element)
/*  404:     */       {
/*  405: 540 */         return this.val$multiset1.count(element) + multiset2.count(element);
/*  406:     */       }
/*  407:     */       
/*  408:     */       Set<E> createElementSet()
/*  409:     */       {
/*  410: 545 */         return Sets.union(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  411:     */       }
/*  412:     */       
/*  413:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  414:     */       {
/*  415: 550 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  416:     */         
/*  417: 552 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator2 = multiset2.entrySet().iterator();
/*  418:     */         
/*  419: 554 */         new AbstractIterator()
/*  420:     */         {
/*  421:     */           protected Multiset.Entry<E> computeNext()
/*  422:     */           {
/*  423: 557 */             if (iterator1.hasNext())
/*  424:     */             {
/*  425: 558 */               Multiset.Entry<? extends E> entry1 = (Multiset.Entry)iterator1.next();
/*  426: 559 */               E element = entry1.getElement();
/*  427: 560 */               int count = entry1.getCount() + Multisets.3.this.val$multiset2.count(element);
/*  428: 561 */               return Multisets.immutableEntry(element, count);
/*  429:     */             }
/*  430: 563 */             while (iterator2.hasNext())
/*  431:     */             {
/*  432: 564 */               Multiset.Entry<? extends E> entry2 = (Multiset.Entry)iterator2.next();
/*  433: 565 */               E element = entry2.getElement();
/*  434: 566 */               if (!Multisets.3.this.val$multiset1.contains(element)) {
/*  435: 567 */                 return Multisets.immutableEntry(element, entry2.getCount());
/*  436:     */               }
/*  437:     */             }
/*  438: 570 */             return (Multiset.Entry)endOfData();
/*  439:     */           }
/*  440:     */         };
/*  441:     */       }
/*  442:     */       
/*  443:     */       int distinctElements()
/*  444:     */       {
/*  445: 577 */         return elementSet().size();
/*  446:     */       }
/*  447:     */     };
/*  448:     */   }
/*  449:     */   
/*  450:     */   @Beta
/*  451:     */   public static <E> Multiset<E> difference(Multiset<E> multiset1, final Multiset<?> multiset2)
/*  452:     */   {
/*  453: 600 */     Preconditions.checkNotNull(multiset1);
/*  454: 601 */     Preconditions.checkNotNull(multiset2);
/*  455:     */     
/*  456:     */ 
/*  457: 604 */     new AbstractMultiset()
/*  458:     */     {
/*  459:     */       public int count(@Nullable Object element)
/*  460:     */       {
/*  461: 607 */         int count1 = this.val$multiset1.count(element);
/*  462: 608 */         return count1 == 0 ? 0 : Math.max(0, count1 - multiset2.count(element));
/*  463:     */       }
/*  464:     */       
/*  465:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  466:     */       {
/*  467: 614 */         final Iterator<Multiset.Entry<E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  468: 615 */         new AbstractIterator()
/*  469:     */         {
/*  470:     */           protected Multiset.Entry<E> computeNext()
/*  471:     */           {
/*  472: 618 */             while (iterator1.hasNext())
/*  473:     */             {
/*  474: 619 */               Multiset.Entry<E> entry1 = (Multiset.Entry)iterator1.next();
/*  475: 620 */               E element = entry1.getElement();
/*  476: 621 */               int count = entry1.getCount() - Multisets.4.this.val$multiset2.count(element);
/*  477: 622 */               if (count > 0) {
/*  478: 623 */                 return Multisets.immutableEntry(element, count);
/*  479:     */               }
/*  480:     */             }
/*  481: 626 */             return (Multiset.Entry)endOfData();
/*  482:     */           }
/*  483:     */         };
/*  484:     */       }
/*  485:     */       
/*  486:     */       int distinctElements()
/*  487:     */       {
/*  488: 633 */         return Iterators.size(entryIterator());
/*  489:     */       }
/*  490:     */     };
/*  491:     */   }
/*  492:     */   
/*  493:     */   public static boolean containsOccurrences(Multiset<?> superMultiset, Multiset<?> subMultiset)
/*  494:     */   {
/*  495: 646 */     Preconditions.checkNotNull(superMultiset);
/*  496: 647 */     Preconditions.checkNotNull(subMultiset);
/*  497: 648 */     for (Multiset.Entry<?> entry : subMultiset.entrySet())
/*  498:     */     {
/*  499: 649 */       int superCount = superMultiset.count(entry.getElement());
/*  500: 650 */       if (superCount < entry.getCount()) {
/*  501: 651 */         return false;
/*  502:     */       }
/*  503:     */     }
/*  504: 654 */     return true;
/*  505:     */   }
/*  506:     */   
/*  507:     */   public static boolean retainOccurrences(Multiset<?> multisetToModify, Multiset<?> multisetToRetain)
/*  508:     */   {
/*  509: 678 */     return retainOccurrencesImpl(multisetToModify, multisetToRetain);
/*  510:     */   }
/*  511:     */   
/*  512:     */   private static <E> boolean retainOccurrencesImpl(Multiset<E> multisetToModify, Multiset<?> occurrencesToRetain)
/*  513:     */   {
/*  514: 686 */     Preconditions.checkNotNull(multisetToModify);
/*  515: 687 */     Preconditions.checkNotNull(occurrencesToRetain);
/*  516:     */     
/*  517: 689 */     Iterator<Multiset.Entry<E>> entryIterator = multisetToModify.entrySet().iterator();
/*  518: 690 */     boolean changed = false;
/*  519: 691 */     while (entryIterator.hasNext())
/*  520:     */     {
/*  521: 692 */       Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  522: 693 */       int retainCount = occurrencesToRetain.count(entry.getElement());
/*  523: 694 */       if (retainCount == 0)
/*  524:     */       {
/*  525: 695 */         entryIterator.remove();
/*  526: 696 */         changed = true;
/*  527:     */       }
/*  528: 697 */       else if (retainCount < entry.getCount())
/*  529:     */       {
/*  530: 698 */         multisetToModify.setCount(entry.getElement(), retainCount);
/*  531: 699 */         changed = true;
/*  532:     */       }
/*  533:     */     }
/*  534: 702 */     return changed;
/*  535:     */   }
/*  536:     */   
/*  537:     */   public static boolean removeOccurrences(Multiset<?> multisetToModify, Multiset<?> occurrencesToRemove)
/*  538:     */   {
/*  539: 730 */     return removeOccurrencesImpl(multisetToModify, occurrencesToRemove);
/*  540:     */   }
/*  541:     */   
/*  542:     */   private static <E> boolean removeOccurrencesImpl(Multiset<E> multisetToModify, Multiset<?> occurrencesToRemove)
/*  543:     */   {
/*  544: 739 */     Preconditions.checkNotNull(multisetToModify);
/*  545: 740 */     Preconditions.checkNotNull(occurrencesToRemove);
/*  546:     */     
/*  547: 742 */     boolean changed = false;
/*  548: 743 */     Iterator<Multiset.Entry<E>> entryIterator = multisetToModify.entrySet().iterator();
/*  549: 744 */     while (entryIterator.hasNext())
/*  550:     */     {
/*  551: 745 */       Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  552: 746 */       int removeCount = occurrencesToRemove.count(entry.getElement());
/*  553: 747 */       if (removeCount >= entry.getCount())
/*  554:     */       {
/*  555: 748 */         entryIterator.remove();
/*  556: 749 */         changed = true;
/*  557:     */       }
/*  558: 750 */       else if (removeCount > 0)
/*  559:     */       {
/*  560: 751 */         multisetToModify.remove(entry.getElement(), removeCount);
/*  561: 752 */         changed = true;
/*  562:     */       }
/*  563:     */     }
/*  564: 755 */     return changed;
/*  565:     */   }
/*  566:     */   
/*  567:     */   static abstract class AbstractEntry<E>
/*  568:     */     implements Multiset.Entry<E>
/*  569:     */   {
/*  570:     */     public boolean equals(@Nullable Object object)
/*  571:     */     {
/*  572: 768 */       if ((object instanceof Multiset.Entry))
/*  573:     */       {
/*  574: 769 */         Multiset.Entry<?> that = (Multiset.Entry)object;
/*  575: 770 */         return (getCount() == that.getCount()) && (Objects.equal(getElement(), that.getElement()));
/*  576:     */       }
/*  577: 773 */       return false;
/*  578:     */     }
/*  579:     */     
/*  580:     */     public int hashCode()
/*  581:     */     {
/*  582: 781 */       E e = getElement();
/*  583: 782 */       return (e == null ? 0 : e.hashCode()) ^ getCount();
/*  584:     */     }
/*  585:     */     
/*  586:     */     public String toString()
/*  587:     */     {
/*  588: 793 */       String text = String.valueOf(getElement());
/*  589: 794 */       int n = getCount();
/*  590: 795 */       return text + " x " + n;
/*  591:     */     }
/*  592:     */   }
/*  593:     */   
/*  594:     */   static boolean equalsImpl(Multiset<?> multiset, @Nullable Object object)
/*  595:     */   {
/*  596: 803 */     if (object == multiset) {
/*  597: 804 */       return true;
/*  598:     */     }
/*  599: 806 */     if ((object instanceof Multiset))
/*  600:     */     {
/*  601: 807 */       Multiset<?> that = (Multiset)object;
/*  602: 814 */       if ((multiset.size() != that.size()) || (multiset.entrySet().size() != that.entrySet().size())) {
/*  603: 816 */         return false;
/*  604:     */       }
/*  605: 818 */       for (Multiset.Entry<?> entry : that.entrySet()) {
/*  606: 819 */         if (multiset.count(entry.getElement()) != entry.getCount()) {
/*  607: 820 */           return false;
/*  608:     */         }
/*  609:     */       }
/*  610: 823 */       return true;
/*  611:     */     }
/*  612: 825 */     return false;
/*  613:     */   }
/*  614:     */   
/*  615:     */   static <E> boolean addAllImpl(Multiset<E> self, Collection<? extends E> elements)
/*  616:     */   {
/*  617: 833 */     if (elements.isEmpty()) {
/*  618: 834 */       return false;
/*  619:     */     }
/*  620: 836 */     if ((elements instanceof Multiset))
/*  621:     */     {
/*  622: 837 */       Multiset<? extends E> that = cast(elements);
/*  623: 838 */       for (Multiset.Entry<? extends E> entry : that.entrySet()) {
/*  624: 839 */         self.add(entry.getElement(), entry.getCount());
/*  625:     */       }
/*  626:     */     }
/*  627:     */     else
/*  628:     */     {
/*  629: 842 */       Iterators.addAll(self, elements.iterator());
/*  630:     */     }
/*  631: 844 */     return true;
/*  632:     */   }
/*  633:     */   
/*  634:     */   static boolean removeAllImpl(Multiset<?> self, Collection<?> elementsToRemove)
/*  635:     */   {
/*  636: 852 */     Collection<?> collection = (elementsToRemove instanceof Multiset) ? ((Multiset)elementsToRemove).elementSet() : elementsToRemove;
/*  637:     */     
/*  638:     */ 
/*  639: 855 */     return self.elementSet().removeAll(collection);
/*  640:     */   }
/*  641:     */   
/*  642:     */   static boolean retainAllImpl(Multiset<?> self, Collection<?> elementsToRetain)
/*  643:     */   {
/*  644: 863 */     Preconditions.checkNotNull(elementsToRetain);
/*  645: 864 */     Collection<?> collection = (elementsToRetain instanceof Multiset) ? ((Multiset)elementsToRetain).elementSet() : elementsToRetain;
/*  646:     */     
/*  647:     */ 
/*  648: 867 */     return self.elementSet().retainAll(collection);
/*  649:     */   }
/*  650:     */   
/*  651:     */   static <E> int setCountImpl(Multiset<E> self, E element, int count)
/*  652:     */   {
/*  653: 874 */     CollectPreconditions.checkNonnegative(count, "count");
/*  654:     */     
/*  655: 876 */     int oldCount = self.count(element);
/*  656:     */     
/*  657: 878 */     int delta = count - oldCount;
/*  658: 879 */     if (delta > 0) {
/*  659: 880 */       self.add(element, delta);
/*  660: 881 */     } else if (delta < 0) {
/*  661: 882 */       self.remove(element, -delta);
/*  662:     */     }
/*  663: 885 */     return oldCount;
/*  664:     */   }
/*  665:     */   
/*  666:     */   static <E> boolean setCountImpl(Multiset<E> self, E element, int oldCount, int newCount)
/*  667:     */   {
/*  668: 893 */     CollectPreconditions.checkNonnegative(oldCount, "oldCount");
/*  669: 894 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/*  670: 896 */     if (self.count(element) == oldCount)
/*  671:     */     {
/*  672: 897 */       self.setCount(element, newCount);
/*  673: 898 */       return true;
/*  674:     */     }
/*  675: 900 */     return false;
/*  676:     */   }
/*  677:     */   
/*  678:     */   static abstract class ElementSet<E>
/*  679:     */     extends Sets.ImprovedAbstractSet<E>
/*  680:     */   {
/*  681:     */     abstract Multiset<E> multiset();
/*  682:     */     
/*  683:     */     public void clear()
/*  684:     */     {
/*  685: 908 */       multiset().clear();
/*  686:     */     }
/*  687:     */     
/*  688:     */     public boolean contains(Object o)
/*  689:     */     {
/*  690: 912 */       return multiset().contains(o);
/*  691:     */     }
/*  692:     */     
/*  693:     */     public boolean containsAll(Collection<?> c)
/*  694:     */     {
/*  695: 916 */       return multiset().containsAll(c);
/*  696:     */     }
/*  697:     */     
/*  698:     */     public boolean isEmpty()
/*  699:     */     {
/*  700: 920 */       return multiset().isEmpty();
/*  701:     */     }
/*  702:     */     
/*  703:     */     public Iterator<E> iterator()
/*  704:     */     {
/*  705: 924 */       new TransformedIterator(multiset().entrySet().iterator())
/*  706:     */       {
/*  707:     */         E transform(Multiset.Entry<E> entry)
/*  708:     */         {
/*  709: 927 */           return entry.getElement();
/*  710:     */         }
/*  711:     */       };
/*  712:     */     }
/*  713:     */     
/*  714:     */     public boolean remove(Object o)
/*  715:     */     {
/*  716: 934 */       int count = multiset().count(o);
/*  717: 935 */       if (count > 0)
/*  718:     */       {
/*  719: 936 */         multiset().remove(o, count);
/*  720: 937 */         return true;
/*  721:     */       }
/*  722: 939 */       return false;
/*  723:     */     }
/*  724:     */     
/*  725:     */     public int size()
/*  726:     */     {
/*  727: 943 */       return multiset().entrySet().size();
/*  728:     */     }
/*  729:     */   }
/*  730:     */   
/*  731:     */   static abstract class EntrySet<E>
/*  732:     */     extends Sets.ImprovedAbstractSet<Multiset.Entry<E>>
/*  733:     */   {
/*  734:     */     abstract Multiset<E> multiset();
/*  735:     */     
/*  736:     */     public boolean contains(@Nullable Object o)
/*  737:     */     {
/*  738: 951 */       if ((o instanceof Multiset.Entry))
/*  739:     */       {
/*  740: 956 */         Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  741: 957 */         if (entry.getCount() <= 0) {
/*  742: 958 */           return false;
/*  743:     */         }
/*  744: 960 */         int count = multiset().count(entry.getElement());
/*  745: 961 */         return count == entry.getCount();
/*  746:     */       }
/*  747: 964 */       return false;
/*  748:     */     }
/*  749:     */     
/*  750:     */     public boolean remove(Object object)
/*  751:     */     {
/*  752: 970 */       if ((object instanceof Multiset.Entry))
/*  753:     */       {
/*  754: 971 */         Multiset.Entry<?> entry = (Multiset.Entry)object;
/*  755: 972 */         Object element = entry.getElement();
/*  756: 973 */         int entryCount = entry.getCount();
/*  757: 974 */         if (entryCount != 0)
/*  758:     */         {
/*  759: 977 */           Multiset<Object> multiset = multiset();
/*  760: 978 */           return multiset.setCount(element, entryCount, 0);
/*  761:     */         }
/*  762:     */       }
/*  763: 981 */       return false;
/*  764:     */     }
/*  765:     */     
/*  766:     */     public void clear()
/*  767:     */     {
/*  768: 985 */       multiset().clear();
/*  769:     */     }
/*  770:     */   }
/*  771:     */   
/*  772:     */   static <E> Iterator<E> iteratorImpl(Multiset<E> multiset)
/*  773:     */   {
/*  774: 993 */     return new MultisetIteratorImpl(multiset, multiset.entrySet().iterator());
/*  775:     */   }
/*  776:     */   
/*  777:     */   static final class MultisetIteratorImpl<E>
/*  778:     */     implements Iterator<E>
/*  779:     */   {
/*  780:     */     private final Multiset<E> multiset;
/*  781:     */     private final Iterator<Multiset.Entry<E>> entryIterator;
/*  782:     */     private Multiset.Entry<E> currentEntry;
/*  783:     */     private int laterCount;
/*  784:     */     private int totalCount;
/*  785:     */     private boolean canRemove;
/*  786:     */     
/*  787:     */     MultisetIteratorImpl(Multiset<E> multiset, Iterator<Multiset.Entry<E>> entryIterator)
/*  788:     */     {
/*  789:1009 */       this.multiset = multiset;
/*  790:1010 */       this.entryIterator = entryIterator;
/*  791:     */     }
/*  792:     */     
/*  793:     */     public boolean hasNext()
/*  794:     */     {
/*  795:1015 */       return (this.laterCount > 0) || (this.entryIterator.hasNext());
/*  796:     */     }
/*  797:     */     
/*  798:     */     public E next()
/*  799:     */     {
/*  800:1020 */       if (!hasNext()) {
/*  801:1021 */         throw new NoSuchElementException();
/*  802:     */       }
/*  803:1023 */       if (this.laterCount == 0)
/*  804:     */       {
/*  805:1024 */         this.currentEntry = ((Multiset.Entry)this.entryIterator.next());
/*  806:1025 */         this.totalCount = (this.laterCount = this.currentEntry.getCount());
/*  807:     */       }
/*  808:1027 */       this.laterCount -= 1;
/*  809:1028 */       this.canRemove = true;
/*  810:1029 */       return this.currentEntry.getElement();
/*  811:     */     }
/*  812:     */     
/*  813:     */     public void remove()
/*  814:     */     {
/*  815:1034 */       CollectPreconditions.checkRemove(this.canRemove);
/*  816:1035 */       if (this.totalCount == 1) {
/*  817:1036 */         this.entryIterator.remove();
/*  818:     */       } else {
/*  819:1038 */         this.multiset.remove(this.currentEntry.getElement());
/*  820:     */       }
/*  821:1040 */       this.totalCount -= 1;
/*  822:1041 */       this.canRemove = false;
/*  823:     */     }
/*  824:     */   }
/*  825:     */   
/*  826:     */   static int sizeImpl(Multiset<?> multiset)
/*  827:     */   {
/*  828:1049 */     long size = 0L;
/*  829:1050 */     for (Multiset.Entry<?> entry : multiset.entrySet()) {
/*  830:1051 */       size += entry.getCount();
/*  831:     */     }
/*  832:1053 */     return Ints.saturatedCast(size);
/*  833:     */   }
/*  834:     */   
/*  835:     */   static <T> Multiset<T> cast(Iterable<T> iterable)
/*  836:     */   {
/*  837:1060 */     return (Multiset)iterable;
/*  838:     */   }
/*  839:     */   
/*  840:1063 */   private static final Ordering<Multiset.Entry<?>> DECREASING_COUNT_ORDERING = new Ordering()
/*  841:     */   {
/*  842:     */     public int compare(Multiset.Entry<?> entry1, Multiset.Entry<?> entry2)
/*  843:     */     {
/*  844:1066 */       return Ints.compare(entry2.getCount(), entry1.getCount());
/*  845:     */     }
/*  846:     */   };
/*  847:     */   
/*  848:     */   @Beta
/*  849:     */   public static <E> ImmutableMultiset<E> copyHighestCountFirst(Multiset<E> multiset)
/*  850:     */   {
/*  851:1078 */     List<Multiset.Entry<E>> sortedEntries = DECREASING_COUNT_ORDERING.immutableSortedCopy(multiset.entrySet());
/*  852:     */     
/*  853:1080 */     return ImmutableMultiset.copyFromEntries(sortedEntries);
/*  854:     */   }
/*  855:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Multisets
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Equivalence;
/*   7:    */ import com.google.common.base.Function;
/*   8:    */ import com.google.common.base.Objects;
/*   9:    */ import java.util.concurrent.ConcurrentMap;
/*  10:    */ import java.util.concurrent.TimeUnit;
/*  11:    */ 
/*  12:    */ @Deprecated
/*  13:    */ @Beta
/*  14:    */ @GwtCompatible(emulated=true)
/*  15:    */ abstract class GenericMapMaker<K0, V0>
/*  16:    */ {
/*  17:    */   @GwtIncompatible("To be supported")
/*  18:    */   MapMaker.RemovalListener<K0, V0> removalListener;
/*  19:    */   @GwtIncompatible("To be supported")
/*  20:    */   abstract GenericMapMaker<K0, V0> keyEquivalence(Equivalence<Object> paramEquivalence);
/*  21:    */   
/*  22:    */   public abstract GenericMapMaker<K0, V0> initialCapacity(int paramInt);
/*  23:    */   
/*  24:    */   abstract GenericMapMaker<K0, V0> maximumSize(int paramInt);
/*  25:    */   
/*  26:    */   public abstract GenericMapMaker<K0, V0> concurrencyLevel(int paramInt);
/*  27:    */   
/*  28:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  29:    */   public abstract GenericMapMaker<K0, V0> weakKeys();
/*  30:    */   
/*  31:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  32:    */   public abstract GenericMapMaker<K0, V0> weakValues();
/*  33:    */   
/*  34:    */   @Deprecated
/*  35:    */   @GwtIncompatible("java.lang.ref.SoftReference")
/*  36:    */   public abstract GenericMapMaker<K0, V0> softValues();
/*  37:    */   
/*  38:    */   abstract GenericMapMaker<K0, V0> expireAfterWrite(long paramLong, TimeUnit paramTimeUnit);
/*  39:    */   
/*  40:    */   @GwtIncompatible("To be supported")
/*  41:    */   abstract GenericMapMaker<K0, V0> expireAfterAccess(long paramLong, TimeUnit paramTimeUnit);
/*  42:    */   
/*  43:    */   @GwtIncompatible("To be supported")
/*  44:    */   static enum NullListener
/*  45:    */     implements MapMaker.RemovalListener<Object, Object>
/*  46:    */   {
/*  47: 53 */     INSTANCE;
/*  48:    */     
/*  49:    */     private NullListener() {}
/*  50:    */     
/*  51:    */     public void onRemoval(MapMaker.RemovalNotification<Object, Object> notification) {}
/*  52:    */   }
/*  53:    */   
/*  54:    */   @GwtIncompatible("To be supported")
/*  55:    */   <K extends K0, V extends V0> MapMaker.RemovalListener<K, V> getRemovalListener()
/*  56:    */   {
/*  57:131 */     return (MapMaker.RemovalListener)Objects.firstNonNull(this.removalListener, NullListener.INSTANCE);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public abstract <K extends K0, V extends V0> ConcurrentMap<K, V> makeMap();
/*  61:    */   
/*  62:    */   @GwtIncompatible("MapMakerInternalMap")
/*  63:    */   abstract <K, V> MapMakerInternalMap<K, V> makeCustomMap();
/*  64:    */   
/*  65:    */   @Deprecated
/*  66:    */   abstract <K extends K0, V extends V0> ConcurrentMap<K, V> makeComputingMap(Function<? super K, ? extends V> paramFunction);
/*  67:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.GenericMapMaker
 * JD-Core Version:    0.7.0.1
 */
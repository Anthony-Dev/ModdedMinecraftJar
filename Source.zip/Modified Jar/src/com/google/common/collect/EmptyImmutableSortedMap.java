/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ final class EmptyImmutableSortedMap<K, V>
/*  11:    */   extends ImmutableSortedMap<K, V>
/*  12:    */ {
/*  13:    */   private final transient ImmutableSortedSet<K> keySet;
/*  14:    */   
/*  15:    */   EmptyImmutableSortedMap(Comparator<? super K> comparator)
/*  16:    */   {
/*  17: 37 */     this.keySet = ImmutableSortedSet.emptySet(comparator);
/*  18:    */   }
/*  19:    */   
/*  20:    */   EmptyImmutableSortedMap(Comparator<? super K> comparator, ImmutableSortedMap<K, V> descendingMap)
/*  21:    */   {
/*  22: 42 */     super(descendingMap);
/*  23: 43 */     this.keySet = ImmutableSortedSet.emptySet(comparator);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public V get(@Nullable Object key)
/*  27:    */   {
/*  28: 48 */     return null;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public ImmutableSortedSet<K> keySet()
/*  32:    */   {
/*  33: 53 */     return this.keySet;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int size()
/*  37:    */   {
/*  38: 58 */     return 0;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean isEmpty()
/*  42:    */   {
/*  43: 63 */     return true;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public ImmutableCollection<V> values()
/*  47:    */   {
/*  48: 68 */     return ImmutableList.of();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String toString()
/*  52:    */   {
/*  53: 73 */     return "{}";
/*  54:    */   }
/*  55:    */   
/*  56:    */   boolean isPartialView()
/*  57:    */   {
/*  58: 78 */     return false;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/*  62:    */   {
/*  63: 83 */     return ImmutableSet.of();
/*  64:    */   }
/*  65:    */   
/*  66:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/*  67:    */   {
/*  68: 88 */     throw new AssertionError("should never be called");
/*  69:    */   }
/*  70:    */   
/*  71:    */   public ImmutableSetMultimap<K, V> asMultimap()
/*  72:    */   {
/*  73: 93 */     return ImmutableSetMultimap.of();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public ImmutableSortedMap<K, V> headMap(K toKey, boolean inclusive)
/*  77:    */   {
/*  78: 98 */     Preconditions.checkNotNull(toKey);
/*  79: 99 */     return this;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public ImmutableSortedMap<K, V> tailMap(K fromKey, boolean inclusive)
/*  83:    */   {
/*  84:104 */     Preconditions.checkNotNull(fromKey);
/*  85:105 */     return this;
/*  86:    */   }
/*  87:    */   
/*  88:    */   ImmutableSortedMap<K, V> createDescendingMap()
/*  89:    */   {
/*  90:110 */     return new EmptyImmutableSortedMap(Ordering.from(comparator()).reverse(), this);
/*  91:    */   }
/*  92:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableSortedMap
 * JD-Core Version:    0.7.0.1
 */
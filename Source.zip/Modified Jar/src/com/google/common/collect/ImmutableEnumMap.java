/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.EnumMap;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.Set;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible(serializable=true, emulated=true)
/*  13:    */ final class ImmutableEnumMap<K extends Enum<K>, V>
/*  14:    */   extends ImmutableMap<K, V>
/*  15:    */ {
/*  16:    */   private final transient EnumMap<K, V> delegate;
/*  17:    */   
/*  18:    */   static <K extends Enum<K>, V> ImmutableMap<K, V> asImmutable(EnumMap<K, V> map)
/*  19:    */   {
/*  20: 38 */     switch (map.size())
/*  21:    */     {
/*  22:    */     case 0: 
/*  23: 40 */       return ImmutableMap.of();
/*  24:    */     case 1: 
/*  25: 42 */       Map.Entry<K, V> entry = (Map.Entry)Iterables.getOnlyElement(map.entrySet());
/*  26: 43 */       return ImmutableMap.of(entry.getKey(), entry.getValue());
/*  27:    */     }
/*  28: 46 */     return new ImmutableEnumMap(map);
/*  29:    */   }
/*  30:    */   
/*  31:    */   private ImmutableEnumMap(EnumMap<K, V> delegate)
/*  32:    */   {
/*  33: 53 */     this.delegate = delegate;
/*  34: 54 */     Preconditions.checkArgument(!delegate.isEmpty());
/*  35:    */   }
/*  36:    */   
/*  37:    */   ImmutableSet<K> createKeySet()
/*  38:    */   {
/*  39: 59 */     new ImmutableSet()
/*  40:    */     {
/*  41:    */       public boolean contains(Object object)
/*  42:    */       {
/*  43: 63 */         return ImmutableEnumMap.this.delegate.containsKey(object);
/*  44:    */       }
/*  45:    */       
/*  46:    */       public int size()
/*  47:    */       {
/*  48: 68 */         return ImmutableEnumMap.this.size();
/*  49:    */       }
/*  50:    */       
/*  51:    */       public UnmodifiableIterator<K> iterator()
/*  52:    */       {
/*  53: 73 */         return Iterators.unmodifiableIterator(ImmutableEnumMap.this.delegate.keySet().iterator());
/*  54:    */       }
/*  55:    */       
/*  56:    */       boolean isPartialView()
/*  57:    */       {
/*  58: 78 */         return true;
/*  59:    */       }
/*  60:    */     };
/*  61:    */   }
/*  62:    */   
/*  63:    */   public int size()
/*  64:    */   {
/*  65: 85 */     return this.delegate.size();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean containsKey(@Nullable Object key)
/*  69:    */   {
/*  70: 90 */     return this.delegate.containsKey(key);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public V get(Object key)
/*  74:    */   {
/*  75: 95 */     return this.delegate.get(key);
/*  76:    */   }
/*  77:    */   
/*  78:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/*  79:    */   {
/*  80:100 */     new ImmutableMapEntrySet()
/*  81:    */     {
/*  82:    */       ImmutableMap<K, V> map()
/*  83:    */       {
/*  84:104 */         return ImmutableEnumMap.this;
/*  85:    */       }
/*  86:    */       
/*  87:    */       public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/*  88:    */       {
/*  89:109 */         new UnmodifiableIterator()
/*  90:    */         {
/*  91:110 */           private final Iterator<Map.Entry<K, V>> backingIterator = ImmutableEnumMap.this.delegate.entrySet().iterator();
/*  92:    */           
/*  93:    */           public boolean hasNext()
/*  94:    */           {
/*  95:114 */             return this.backingIterator.hasNext();
/*  96:    */           }
/*  97:    */           
/*  98:    */           public Map.Entry<K, V> next()
/*  99:    */           {
/* 100:119 */             Map.Entry<K, V> entry = (Map.Entry)this.backingIterator.next();
/* 101:120 */             return Maps.immutableEntry(entry.getKey(), entry.getValue());
/* 102:    */           }
/* 103:    */         };
/* 104:    */       }
/* 105:    */     };
/* 106:    */   }
/* 107:    */   
/* 108:    */   boolean isPartialView()
/* 109:    */   {
/* 110:129 */     return false;
/* 111:    */   }
/* 112:    */   
/* 113:    */   Object writeReplace()
/* 114:    */   {
/* 115:134 */     return new EnumSerializedForm(this.delegate);
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static class EnumSerializedForm<K extends Enum<K>, V>
/* 119:    */     implements Serializable
/* 120:    */   {
/* 121:    */     final EnumMap<K, V> delegate;
/* 122:    */     private static final long serialVersionUID = 0L;
/* 123:    */     
/* 124:    */     EnumSerializedForm(EnumMap<K, V> delegate)
/* 125:    */     {
/* 126:144 */       this.delegate = delegate;
/* 127:    */     }
/* 128:    */     
/* 129:    */     Object readResolve()
/* 130:    */     {
/* 131:147 */       return new ImmutableEnumMap(this.delegate, null);
/* 132:    */     }
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableEnumMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.io.InvalidObjectException;
/*   8:    */ import java.io.ObjectStreamException;
/*   9:    */ import java.io.Serializable;
/*  10:    */ import java.util.ConcurrentModificationException;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ abstract class AbstractMapBasedMultiset<E>
/*  19:    */   extends AbstractMultiset<E>
/*  20:    */   implements Serializable
/*  21:    */ {
/*  22:    */   private transient Map<E, Count> backingMap;
/*  23:    */   private transient long size;
/*  24:    */   @GwtIncompatible("not needed in emulated source.")
/*  25:    */   private static final long serialVersionUID = -2250766705698539974L;
/*  26:    */   
/*  27:    */   protected AbstractMapBasedMultiset(Map<E, Count> backingMap)
/*  28:    */   {
/*  29: 62 */     this.backingMap = ((Map)Preconditions.checkNotNull(backingMap));
/*  30: 63 */     this.size = super.size();
/*  31:    */   }
/*  32:    */   
/*  33:    */   void setBackingMap(Map<E, Count> backingMap)
/*  34:    */   {
/*  35: 68 */     this.backingMap = backingMap;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Set<Multiset.Entry<E>> entrySet()
/*  39:    */   {
/*  40: 82 */     return super.entrySet();
/*  41:    */   }
/*  42:    */   
/*  43:    */   Iterator<Multiset.Entry<E>> entryIterator()
/*  44:    */   {
/*  45: 87 */     final Iterator<Map.Entry<E, Count>> backingEntries = this.backingMap.entrySet().iterator();
/*  46:    */     
/*  47: 89 */     new Iterator()
/*  48:    */     {
/*  49:    */       Map.Entry<E, Count> toRemove;
/*  50:    */       
/*  51:    */       public boolean hasNext()
/*  52:    */       {
/*  53: 94 */         return backingEntries.hasNext();
/*  54:    */       }
/*  55:    */       
/*  56:    */       public Multiset.Entry<E> next()
/*  57:    */       {
/*  58: 99 */         final Map.Entry<E, Count> mapEntry = (Map.Entry)backingEntries.next();
/*  59:100 */         this.toRemove = mapEntry;
/*  60:101 */         new Multisets.AbstractEntry()
/*  61:    */         {
/*  62:    */           public E getElement()
/*  63:    */           {
/*  64:104 */             return mapEntry.getKey();
/*  65:    */           }
/*  66:    */           
/*  67:    */           public int getCount()
/*  68:    */           {
/*  69:108 */             Count count = (Count)mapEntry.getValue();
/*  70:109 */             if ((count == null) || (count.get() == 0))
/*  71:    */             {
/*  72:110 */               Count frequency = (Count)AbstractMapBasedMultiset.this.backingMap.get(getElement());
/*  73:111 */               if (frequency != null) {
/*  74:112 */                 return frequency.get();
/*  75:    */               }
/*  76:    */             }
/*  77:115 */             return count == null ? 0 : count.get();
/*  78:    */           }
/*  79:    */         };
/*  80:    */       }
/*  81:    */       
/*  82:    */       public void remove()
/*  83:    */       {
/*  84:122 */         CollectPreconditions.checkRemove(this.toRemove != null);
/*  85:123 */         AbstractMapBasedMultiset.access$122(AbstractMapBasedMultiset.this, ((Count)this.toRemove.getValue()).getAndSet(0));
/*  86:124 */         backingEntries.remove();
/*  87:125 */         this.toRemove = null;
/*  88:    */       }
/*  89:    */     };
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void clear()
/*  93:    */   {
/*  94:132 */     for (Count frequency : this.backingMap.values()) {
/*  95:133 */       frequency.set(0);
/*  96:    */     }
/*  97:135 */     this.backingMap.clear();
/*  98:136 */     this.size = 0L;
/*  99:    */   }
/* 100:    */   
/* 101:    */   int distinctElements()
/* 102:    */   {
/* 103:141 */     return this.backingMap.size();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public int size()
/* 107:    */   {
/* 108:147 */     return Ints.saturatedCast(this.size);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public Iterator<E> iterator()
/* 112:    */   {
/* 113:151 */     return new MapBasedMultisetIterator();
/* 114:    */   }
/* 115:    */   
/* 116:    */   private class MapBasedMultisetIterator
/* 117:    */     implements Iterator<E>
/* 118:    */   {
/* 119:    */     final Iterator<Map.Entry<E, Count>> entryIterator;
/* 120:    */     Map.Entry<E, Count> currentEntry;
/* 121:    */     int occurrencesLeft;
/* 122:    */     boolean canRemove;
/* 123:    */     
/* 124:    */     MapBasedMultisetIterator()
/* 125:    */     {
/* 126:166 */       this.entryIterator = AbstractMapBasedMultiset.this.backingMap.entrySet().iterator();
/* 127:    */     }
/* 128:    */     
/* 129:    */     public boolean hasNext()
/* 130:    */     {
/* 131:171 */       return (this.occurrencesLeft > 0) || (this.entryIterator.hasNext());
/* 132:    */     }
/* 133:    */     
/* 134:    */     public E next()
/* 135:    */     {
/* 136:176 */       if (this.occurrencesLeft == 0)
/* 137:    */       {
/* 138:177 */         this.currentEntry = ((Map.Entry)this.entryIterator.next());
/* 139:178 */         this.occurrencesLeft = ((Count)this.currentEntry.getValue()).get();
/* 140:    */       }
/* 141:180 */       this.occurrencesLeft -= 1;
/* 142:181 */       this.canRemove = true;
/* 143:182 */       return this.currentEntry.getKey();
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void remove()
/* 147:    */     {
/* 148:187 */       CollectPreconditions.checkRemove(this.canRemove);
/* 149:188 */       int frequency = ((Count)this.currentEntry.getValue()).get();
/* 150:189 */       if (frequency <= 0) {
/* 151:190 */         throw new ConcurrentModificationException();
/* 152:    */       }
/* 153:192 */       if (((Count)this.currentEntry.getValue()).addAndGet(-1) == 0) {
/* 154:193 */         this.entryIterator.remove();
/* 155:    */       }
/* 156:195 */       AbstractMapBasedMultiset.access$110(AbstractMapBasedMultiset.this);
/* 157:196 */       this.canRemove = false;
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   public int count(@Nullable Object element)
/* 162:    */   {
/* 163:201 */     Count frequency = (Count)Maps.safeGet(this.backingMap, element);
/* 164:202 */     return frequency == null ? 0 : frequency.get();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public int add(@Nullable E element, int occurrences)
/* 168:    */   {
/* 169:215 */     if (occurrences == 0) {
/* 170:216 */       return count(element);
/* 171:    */     }
/* 172:218 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/* 173:    */     
/* 174:220 */     Count frequency = (Count)this.backingMap.get(element);
/* 175:    */     int oldCount;
/* 176:222 */     if (frequency == null)
/* 177:    */     {
/* 178:223 */       int oldCount = 0;
/* 179:224 */       this.backingMap.put(element, new Count(occurrences));
/* 180:    */     }
/* 181:    */     else
/* 182:    */     {
/* 183:226 */       oldCount = frequency.get();
/* 184:227 */       long newCount = oldCount + occurrences;
/* 185:228 */       Preconditions.checkArgument(newCount <= 2147483647L, "too many occurrences: %s", new Object[] { Long.valueOf(newCount) });
/* 186:    */       
/* 187:230 */       frequency.getAndAdd(occurrences);
/* 188:    */     }
/* 189:232 */     this.size += occurrences;
/* 190:233 */     return oldCount;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public int remove(@Nullable Object element, int occurrences)
/* 194:    */   {
/* 195:237 */     if (occurrences == 0) {
/* 196:238 */       return count(element);
/* 197:    */     }
/* 198:240 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/* 199:    */     
/* 200:242 */     Count frequency = (Count)this.backingMap.get(element);
/* 201:243 */     if (frequency == null) {
/* 202:244 */       return 0;
/* 203:    */     }
/* 204:247 */     int oldCount = frequency.get();
/* 205:    */     int numberRemoved;
/* 206:    */     int numberRemoved;
/* 207:250 */     if (oldCount > occurrences)
/* 208:    */     {
/* 209:251 */       numberRemoved = occurrences;
/* 210:    */     }
/* 211:    */     else
/* 212:    */     {
/* 213:253 */       numberRemoved = oldCount;
/* 214:254 */       this.backingMap.remove(element);
/* 215:    */     }
/* 216:257 */     frequency.addAndGet(-numberRemoved);
/* 217:258 */     this.size -= numberRemoved;
/* 218:259 */     return oldCount;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public int setCount(@Nullable E element, int count)
/* 222:    */   {
/* 223:264 */     CollectPreconditions.checkNonnegative(count, "count");
/* 224:    */     int oldCount;
/* 225:    */     int oldCount;
/* 226:268 */     if (count == 0)
/* 227:    */     {
/* 228:269 */       Count existingCounter = (Count)this.backingMap.remove(element);
/* 229:270 */       oldCount = getAndSet(existingCounter, count);
/* 230:    */     }
/* 231:    */     else
/* 232:    */     {
/* 233:272 */       Count existingCounter = (Count)this.backingMap.get(element);
/* 234:273 */       oldCount = getAndSet(existingCounter, count);
/* 235:275 */       if (existingCounter == null) {
/* 236:276 */         this.backingMap.put(element, new Count(count));
/* 237:    */       }
/* 238:    */     }
/* 239:280 */     this.size += count - oldCount;
/* 240:281 */     return oldCount;
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static int getAndSet(Count i, int count)
/* 244:    */   {
/* 245:285 */     if (i == null) {
/* 246:286 */       return 0;
/* 247:    */     }
/* 248:289 */     return i.getAndSet(count);
/* 249:    */   }
/* 250:    */   
/* 251:    */   @GwtIncompatible("java.io.ObjectStreamException")
/* 252:    */   private void readObjectNoData()
/* 253:    */     throws ObjectStreamException
/* 254:    */   {
/* 255:296 */     throw new InvalidObjectException("Stream data required");
/* 256:    */   }
/* 257:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractMapBasedMultiset
 * JD-Core Version:    0.7.0.1
 */
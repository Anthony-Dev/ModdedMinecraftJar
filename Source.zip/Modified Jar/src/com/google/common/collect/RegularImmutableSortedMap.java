/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible(emulated=true)
/*   9:    */ final class RegularImmutableSortedMap<K, V>
/*  10:    */   extends ImmutableSortedMap<K, V>
/*  11:    */ {
/*  12:    */   private final transient RegularImmutableSortedSet<K> keySet;
/*  13:    */   private final transient ImmutableList<V> valueList;
/*  14:    */   
/*  15:    */   RegularImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList)
/*  16:    */   {
/*  17: 36 */     this.keySet = keySet;
/*  18: 37 */     this.valueList = valueList;
/*  19:    */   }
/*  20:    */   
/*  21:    */   RegularImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList, ImmutableSortedMap<K, V> descendingMap)
/*  22:    */   {
/*  23: 44 */     super(descendingMap);
/*  24: 45 */     this.keySet = keySet;
/*  25: 46 */     this.valueList = valueList;
/*  26:    */   }
/*  27:    */   
/*  28:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/*  29:    */   {
/*  30: 51 */     return new EntrySet(null);
/*  31:    */   }
/*  32:    */   
/*  33:    */   private class EntrySet
/*  34:    */     extends ImmutableMapEntrySet<K, V>
/*  35:    */   {
/*  36:    */     private EntrySet() {}
/*  37:    */     
/*  38:    */     public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/*  39:    */     {
/*  40: 57 */       return asList().iterator();
/*  41:    */     }
/*  42:    */     
/*  43:    */     ImmutableList<Map.Entry<K, V>> createAsList()
/*  44:    */     {
/*  45: 62 */       new ImmutableAsList()
/*  46:    */       {
/*  47: 64 */         private final ImmutableList<K> keyList = RegularImmutableSortedMap.this.keySet().asList();
/*  48:    */         
/*  49:    */         public Map.Entry<K, V> get(int index)
/*  50:    */         {
/*  51: 68 */           return Maps.immutableEntry(this.keyList.get(index), RegularImmutableSortedMap.this.valueList.get(index));
/*  52:    */         }
/*  53:    */         
/*  54:    */         ImmutableCollection<Map.Entry<K, V>> delegateCollection()
/*  55:    */         {
/*  56: 73 */           return RegularImmutableSortedMap.EntrySet.this;
/*  57:    */         }
/*  58:    */       };
/*  59:    */     }
/*  60:    */     
/*  61:    */     ImmutableMap<K, V> map()
/*  62:    */     {
/*  63: 80 */       return RegularImmutableSortedMap.this;
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public ImmutableSortedSet<K> keySet()
/*  68:    */   {
/*  69: 86 */     return this.keySet;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public ImmutableCollection<V> values()
/*  73:    */   {
/*  74: 91 */     return this.valueList;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public V get(@Nullable Object key)
/*  78:    */   {
/*  79: 96 */     int index = this.keySet.indexOf(key);
/*  80: 97 */     return index == -1 ? null : this.valueList.get(index);
/*  81:    */   }
/*  82:    */   
/*  83:    */   private ImmutableSortedMap<K, V> getSubMap(int fromIndex, int toIndex)
/*  84:    */   {
/*  85:101 */     if ((fromIndex == 0) && (toIndex == size())) {
/*  86:102 */       return this;
/*  87:    */     }
/*  88:103 */     if (fromIndex == toIndex) {
/*  89:104 */       return emptyMap(comparator());
/*  90:    */     }
/*  91:106 */     return from(this.keySet.getSubSet(fromIndex, toIndex), this.valueList.subList(fromIndex, toIndex));
/*  92:    */   }
/*  93:    */   
/*  94:    */   public ImmutableSortedMap<K, V> headMap(K toKey, boolean inclusive)
/*  95:    */   {
/*  96:114 */     return getSubMap(0, this.keySet.headIndex(Preconditions.checkNotNull(toKey), inclusive));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public ImmutableSortedMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 100:    */   {
/* 101:119 */     return getSubMap(this.keySet.tailIndex(Preconditions.checkNotNull(fromKey), inclusive), size());
/* 102:    */   }
/* 103:    */   
/* 104:    */   ImmutableSortedMap<K, V> createDescendingMap()
/* 105:    */   {
/* 106:124 */     return new RegularImmutableSortedMap((RegularImmutableSortedSet)this.keySet.descendingSet(), this.valueList.reverse(), this);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSortedMap
 * JD-Core Version:    0.7.0.1
 */
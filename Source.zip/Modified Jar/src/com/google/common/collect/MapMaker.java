/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.Equivalence;
/*   7:    */ import com.google.common.base.Function;
/*   8:    */ import com.google.common.base.Objects;
/*   9:    */ import com.google.common.base.Objects.ToStringHelper;
/*  10:    */ import com.google.common.base.Preconditions;
/*  11:    */ import com.google.common.base.Throwables;
/*  12:    */ import com.google.common.base.Ticker;
/*  13:    */ import java.io.Serializable;
/*  14:    */ import java.util.AbstractMap;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.Map.Entry;
/*  17:    */ import java.util.Set;
/*  18:    */ import java.util.concurrent.ConcurrentHashMap;
/*  19:    */ import java.util.concurrent.ConcurrentMap;
/*  20:    */ import java.util.concurrent.ExecutionException;
/*  21:    */ import java.util.concurrent.TimeUnit;
/*  22:    */ import javax.annotation.Nullable;
/*  23:    */ 
/*  24:    */ @GwtCompatible(emulated=true)
/*  25:    */ public final class MapMaker
/*  26:    */   extends GenericMapMaker<Object, Object>
/*  27:    */ {
/*  28:    */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*  29:    */   private static final int DEFAULT_CONCURRENCY_LEVEL = 4;
/*  30:    */   private static final int DEFAULT_EXPIRATION_NANOS = 0;
/*  31:    */   static final int UNSET_INT = -1;
/*  32:    */   boolean useCustomMap;
/*  33:117 */   int initialCapacity = -1;
/*  34:118 */   int concurrencyLevel = -1;
/*  35:119 */   int maximumSize = -1;
/*  36:    */   MapMakerInternalMap.Strength keyStrength;
/*  37:    */   MapMakerInternalMap.Strength valueStrength;
/*  38:124 */   long expireAfterWriteNanos = -1L;
/*  39:125 */   long expireAfterAccessNanos = -1L;
/*  40:    */   RemovalCause nullRemovalCause;
/*  41:    */   Equivalence<Object> keyEquivalence;
/*  42:    */   Ticker ticker;
/*  43:    */   
/*  44:    */   @GwtIncompatible("To be supported")
/*  45:    */   MapMaker keyEquivalence(Equivalence<Object> equivalence)
/*  46:    */   {
/*  47:149 */     Preconditions.checkState(this.keyEquivalence == null, "key equivalence was already set to %s", new Object[] { this.keyEquivalence });
/*  48:150 */     this.keyEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/*  49:151 */     this.useCustomMap = true;
/*  50:152 */     return this;
/*  51:    */   }
/*  52:    */   
/*  53:    */   Equivalence<Object> getKeyEquivalence()
/*  54:    */   {
/*  55:156 */     return (Equivalence)Objects.firstNonNull(this.keyEquivalence, getKeyStrength().defaultEquivalence());
/*  56:    */   }
/*  57:    */   
/*  58:    */   public MapMaker initialCapacity(int initialCapacity)
/*  59:    */   {
/*  60:171 */     Preconditions.checkState(this.initialCapacity == -1, "initial capacity was already set to %s", new Object[] { Integer.valueOf(this.initialCapacity) });
/*  61:    */     
/*  62:173 */     Preconditions.checkArgument(initialCapacity >= 0);
/*  63:174 */     this.initialCapacity = initialCapacity;
/*  64:175 */     return this;
/*  65:    */   }
/*  66:    */   
/*  67:    */   int getInitialCapacity()
/*  68:    */   {
/*  69:179 */     return this.initialCapacity == -1 ? 16 : this.initialCapacity;
/*  70:    */   }
/*  71:    */   
/*  72:    */   @Deprecated
/*  73:    */   MapMaker maximumSize(int size)
/*  74:    */   {
/*  75:208 */     Preconditions.checkState(this.maximumSize == -1, "maximum size was already set to %s", new Object[] { Integer.valueOf(this.maximumSize) });
/*  76:    */     
/*  77:210 */     Preconditions.checkArgument(size >= 0, "maximum size must not be negative");
/*  78:211 */     this.maximumSize = size;
/*  79:212 */     this.useCustomMap = true;
/*  80:213 */     if (this.maximumSize == 0) {
/*  81:215 */       this.nullRemovalCause = RemovalCause.SIZE;
/*  82:    */     }
/*  83:217 */     return this;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public MapMaker concurrencyLevel(int concurrencyLevel)
/*  87:    */   {
/*  88:241 */     Preconditions.checkState(this.concurrencyLevel == -1, "concurrency level was already set to %s", new Object[] { Integer.valueOf(this.concurrencyLevel) });
/*  89:    */     
/*  90:243 */     Preconditions.checkArgument(concurrencyLevel > 0);
/*  91:244 */     this.concurrencyLevel = concurrencyLevel;
/*  92:245 */     return this;
/*  93:    */   }
/*  94:    */   
/*  95:    */   int getConcurrencyLevel()
/*  96:    */   {
/*  97:249 */     return this.concurrencyLevel == -1 ? 4 : this.concurrencyLevel;
/*  98:    */   }
/*  99:    */   
/* 100:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 101:    */   public MapMaker weakKeys()
/* 102:    */   {
/* 103:266 */     return setKeyStrength(MapMakerInternalMap.Strength.WEAK);
/* 104:    */   }
/* 105:    */   
/* 106:    */   MapMaker setKeyStrength(MapMakerInternalMap.Strength strength)
/* 107:    */   {
/* 108:270 */     Preconditions.checkState(this.keyStrength == null, "Key strength was already set to %s", new Object[] { this.keyStrength });
/* 109:271 */     this.keyStrength = ((MapMakerInternalMap.Strength)Preconditions.checkNotNull(strength));
/* 110:272 */     Preconditions.checkArgument(this.keyStrength != MapMakerInternalMap.Strength.SOFT, "Soft keys are not supported");
/* 111:273 */     if (strength != MapMakerInternalMap.Strength.STRONG) {
/* 112:275 */       this.useCustomMap = true;
/* 113:    */     }
/* 114:277 */     return this;
/* 115:    */   }
/* 116:    */   
/* 117:    */   MapMakerInternalMap.Strength getKeyStrength()
/* 118:    */   {
/* 119:281 */     return (MapMakerInternalMap.Strength)Objects.firstNonNull(this.keyStrength, MapMakerInternalMap.Strength.STRONG);
/* 120:    */   }
/* 121:    */   
/* 122:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 123:    */   public MapMaker weakValues()
/* 124:    */   {
/* 125:304 */     return setValueStrength(MapMakerInternalMap.Strength.WEAK);
/* 126:    */   }
/* 127:    */   
/* 128:    */   @Deprecated
/* 129:    */   @GwtIncompatible("java.lang.ref.SoftReference")
/* 130:    */   public MapMaker softValues()
/* 131:    */   {
/* 132:336 */     return setValueStrength(MapMakerInternalMap.Strength.SOFT);
/* 133:    */   }
/* 134:    */   
/* 135:    */   MapMaker setValueStrength(MapMakerInternalMap.Strength strength)
/* 136:    */   {
/* 137:340 */     Preconditions.checkState(this.valueStrength == null, "Value strength was already set to %s", new Object[] { this.valueStrength });
/* 138:341 */     this.valueStrength = ((MapMakerInternalMap.Strength)Preconditions.checkNotNull(strength));
/* 139:342 */     if (strength != MapMakerInternalMap.Strength.STRONG) {
/* 140:344 */       this.useCustomMap = true;
/* 141:    */     }
/* 142:346 */     return this;
/* 143:    */   }
/* 144:    */   
/* 145:    */   MapMakerInternalMap.Strength getValueStrength()
/* 146:    */   {
/* 147:350 */     return (MapMakerInternalMap.Strength)Objects.firstNonNull(this.valueStrength, MapMakerInternalMap.Strength.STRONG);
/* 148:    */   }
/* 149:    */   
/* 150:    */   @Deprecated
/* 151:    */   MapMaker expireAfterWrite(long duration, TimeUnit unit)
/* 152:    */   {
/* 153:381 */     checkExpiration(duration, unit);
/* 154:382 */     this.expireAfterWriteNanos = unit.toNanos(duration);
/* 155:383 */     if ((duration == 0L) && (this.nullRemovalCause == null)) {
/* 156:385 */       this.nullRemovalCause = RemovalCause.EXPIRED;
/* 157:    */     }
/* 158:387 */     this.useCustomMap = true;
/* 159:388 */     return this;
/* 160:    */   }
/* 161:    */   
/* 162:    */   private void checkExpiration(long duration, TimeUnit unit)
/* 163:    */   {
/* 164:392 */     Preconditions.checkState(this.expireAfterWriteNanos == -1L, "expireAfterWrite was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterWriteNanos) });
/* 165:    */     
/* 166:394 */     Preconditions.checkState(this.expireAfterAccessNanos == -1L, "expireAfterAccess was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterAccessNanos) });
/* 167:    */     
/* 168:396 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 169:    */   }
/* 170:    */   
/* 171:    */   long getExpireAfterWriteNanos()
/* 172:    */   {
/* 173:400 */     return this.expireAfterWriteNanos == -1L ? 0L : this.expireAfterWriteNanos;
/* 174:    */   }
/* 175:    */   
/* 176:    */   @Deprecated
/* 177:    */   @GwtIncompatible("To be supported")
/* 178:    */   MapMaker expireAfterAccess(long duration, TimeUnit unit)
/* 179:    */   {
/* 180:432 */     checkExpiration(duration, unit);
/* 181:433 */     this.expireAfterAccessNanos = unit.toNanos(duration);
/* 182:434 */     if ((duration == 0L) && (this.nullRemovalCause == null)) {
/* 183:436 */       this.nullRemovalCause = RemovalCause.EXPIRED;
/* 184:    */     }
/* 185:438 */     this.useCustomMap = true;
/* 186:439 */     return this;
/* 187:    */   }
/* 188:    */   
/* 189:    */   long getExpireAfterAccessNanos()
/* 190:    */   {
/* 191:443 */     return this.expireAfterAccessNanos == -1L ? 0L : this.expireAfterAccessNanos;
/* 192:    */   }
/* 193:    */   
/* 194:    */   Ticker getTicker()
/* 195:    */   {
/* 196:448 */     return (Ticker)Objects.firstNonNull(this.ticker, Ticker.systemTicker());
/* 197:    */   }
/* 198:    */   
/* 199:    */   @Deprecated
/* 200:    */   @GwtIncompatible("To be supported")
/* 201:    */   <K, V> GenericMapMaker<K, V> removalListener(RemovalListener<K, V> listener)
/* 202:    */   {
/* 203:483 */     Preconditions.checkState(this.removalListener == null);
/* 204:    */     
/* 205:    */ 
/* 206:    */ 
/* 207:487 */     GenericMapMaker<K, V> me = this;
/* 208:488 */     me.removalListener = ((RemovalListener)Preconditions.checkNotNull(listener));
/* 209:489 */     this.useCustomMap = true;
/* 210:490 */     return me;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public <K, V> ConcurrentMap<K, V> makeMap()
/* 214:    */   {
/* 215:507 */     if (!this.useCustomMap) {
/* 216:508 */       return new ConcurrentHashMap(getInitialCapacity(), 0.75F, getConcurrencyLevel());
/* 217:    */     }
/* 218:510 */     return (ConcurrentMap)(this.nullRemovalCause == null ? new MapMakerInternalMap(this) : new NullConcurrentMap(this));
/* 219:    */   }
/* 220:    */   
/* 221:    */   @GwtIncompatible("MapMakerInternalMap")
/* 222:    */   <K, V> MapMakerInternalMap<K, V> makeCustomMap()
/* 223:    */   {
/* 224:522 */     return new MapMakerInternalMap(this);
/* 225:    */   }
/* 226:    */   
/* 227:    */   @Deprecated
/* 228:    */   <K, V> ConcurrentMap<K, V> makeComputingMap(Function<? super K, ? extends V> computingFunction)
/* 229:    */   {
/* 230:586 */     return (ConcurrentMap)(this.nullRemovalCause == null ? new ComputingMapAdapter(this, computingFunction) : new NullComputingConcurrentMap(this, computingFunction));
/* 231:    */   }
/* 232:    */   
/* 233:    */   public String toString()
/* 234:    */   {
/* 235:597 */     Objects.ToStringHelper s = Objects.toStringHelper(this);
/* 236:598 */     if (this.initialCapacity != -1) {
/* 237:599 */       s.add("initialCapacity", this.initialCapacity);
/* 238:    */     }
/* 239:601 */     if (this.concurrencyLevel != -1) {
/* 240:602 */       s.add("concurrencyLevel", this.concurrencyLevel);
/* 241:    */     }
/* 242:604 */     if (this.maximumSize != -1) {
/* 243:605 */       s.add("maximumSize", this.maximumSize);
/* 244:    */     }
/* 245:607 */     if (this.expireAfterWriteNanos != -1L) {
/* 246:608 */       s.add("expireAfterWrite", this.expireAfterWriteNanos + "ns");
/* 247:    */     }
/* 248:610 */     if (this.expireAfterAccessNanos != -1L) {
/* 249:611 */       s.add("expireAfterAccess", this.expireAfterAccessNanos + "ns");
/* 250:    */     }
/* 251:613 */     if (this.keyStrength != null) {
/* 252:614 */       s.add("keyStrength", Ascii.toLowerCase(this.keyStrength.toString()));
/* 253:    */     }
/* 254:616 */     if (this.valueStrength != null) {
/* 255:617 */       s.add("valueStrength", Ascii.toLowerCase(this.valueStrength.toString()));
/* 256:    */     }
/* 257:619 */     if (this.keyEquivalence != null) {
/* 258:620 */       s.addValue("keyEquivalence");
/* 259:    */     }
/* 260:622 */     if (this.removalListener != null) {
/* 261:623 */       s.addValue("removalListener");
/* 262:    */     }
/* 263:625 */     return s.toString();
/* 264:    */   }
/* 265:    */   
/* 266:    */   static final class RemovalNotification<K, V>
/* 267:    */     extends ImmutableEntry<K, V>
/* 268:    */   {
/* 269:    */     private static final long serialVersionUID = 0L;
/* 270:    */     private final MapMaker.RemovalCause cause;
/* 271:    */     
/* 272:    */     RemovalNotification(@Nullable K key, @Nullable V value, MapMaker.RemovalCause cause)
/* 273:    */     {
/* 274:663 */       super(value);
/* 275:664 */       this.cause = cause;
/* 276:    */     }
/* 277:    */     
/* 278:    */     public MapMaker.RemovalCause getCause()
/* 279:    */     {
/* 280:671 */       return this.cause;
/* 281:    */     }
/* 282:    */     
/* 283:    */     public boolean wasEvicted()
/* 284:    */     {
/* 285:679 */       return this.cause.wasEvicted();
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   static abstract interface RemovalListener<K, V>
/* 290:    */   {
/* 291:    */     public abstract void onRemoval(MapMaker.RemovalNotification<K, V> paramRemovalNotification);
/* 292:    */   }
/* 293:    */   
/* 294:    */   static abstract enum RemovalCause
/* 295:    */   {
/* 296:691 */     EXPLICIT,  REPLACED,  COLLECTED,  EXPIRED,  SIZE;
/* 297:    */     
/* 298:    */     private RemovalCause() {}
/* 299:    */     
/* 300:    */     abstract boolean wasEvicted();
/* 301:    */   }
/* 302:    */   
/* 303:    */   static class NullConcurrentMap<K, V>
/* 304:    */     extends AbstractMap<K, V>
/* 305:    */     implements ConcurrentMap<K, V>, Serializable
/* 306:    */   {
/* 307:    */     private static final long serialVersionUID = 0L;
/* 308:    */     private final MapMaker.RemovalListener<K, V> removalListener;
/* 309:    */     private final MapMaker.RemovalCause removalCause;
/* 310:    */     
/* 311:    */     NullConcurrentMap(MapMaker mapMaker)
/* 312:    */     {
/* 313:760 */       this.removalListener = mapMaker.getRemovalListener();
/* 314:761 */       this.removalCause = mapMaker.nullRemovalCause;
/* 315:    */     }
/* 316:    */     
/* 317:    */     public boolean containsKey(@Nullable Object key)
/* 318:    */     {
/* 319:768 */       return false;
/* 320:    */     }
/* 321:    */     
/* 322:    */     public boolean containsValue(@Nullable Object value)
/* 323:    */     {
/* 324:773 */       return false;
/* 325:    */     }
/* 326:    */     
/* 327:    */     public V get(@Nullable Object key)
/* 328:    */     {
/* 329:778 */       return null;
/* 330:    */     }
/* 331:    */     
/* 332:    */     void notifyRemoval(K key, V value)
/* 333:    */     {
/* 334:782 */       MapMaker.RemovalNotification<K, V> notification = new MapMaker.RemovalNotification(key, value, this.removalCause);
/* 335:    */       
/* 336:784 */       this.removalListener.onRemoval(notification);
/* 337:    */     }
/* 338:    */     
/* 339:    */     public V put(K key, V value)
/* 340:    */     {
/* 341:789 */       Preconditions.checkNotNull(key);
/* 342:790 */       Preconditions.checkNotNull(value);
/* 343:791 */       notifyRemoval(key, value);
/* 344:792 */       return null;
/* 345:    */     }
/* 346:    */     
/* 347:    */     public V putIfAbsent(K key, V value)
/* 348:    */     {
/* 349:797 */       return put(key, value);
/* 350:    */     }
/* 351:    */     
/* 352:    */     public V remove(@Nullable Object key)
/* 353:    */     {
/* 354:802 */       return null;
/* 355:    */     }
/* 356:    */     
/* 357:    */     public boolean remove(@Nullable Object key, @Nullable Object value)
/* 358:    */     {
/* 359:807 */       return false;
/* 360:    */     }
/* 361:    */     
/* 362:    */     public V replace(K key, V value)
/* 363:    */     {
/* 364:812 */       Preconditions.checkNotNull(key);
/* 365:813 */       Preconditions.checkNotNull(value);
/* 366:814 */       return null;
/* 367:    */     }
/* 368:    */     
/* 369:    */     public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 370:    */     {
/* 371:819 */       Preconditions.checkNotNull(key);
/* 372:820 */       Preconditions.checkNotNull(newValue);
/* 373:821 */       return false;
/* 374:    */     }
/* 375:    */     
/* 376:    */     public Set<Map.Entry<K, V>> entrySet()
/* 377:    */     {
/* 378:826 */       return Collections.emptySet();
/* 379:    */     }
/* 380:    */   }
/* 381:    */   
/* 382:    */   static final class NullComputingConcurrentMap<K, V>
/* 383:    */     extends MapMaker.NullConcurrentMap<K, V>
/* 384:    */   {
/* 385:    */     private static final long serialVersionUID = 0L;
/* 386:    */     final Function<? super K, ? extends V> computingFunction;
/* 387:    */     
/* 388:    */     NullComputingConcurrentMap(MapMaker mapMaker, Function<? super K, ? extends V> computingFunction)
/* 389:    */     {
/* 390:838 */       super();
/* 391:839 */       this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/* 392:    */     }
/* 393:    */     
/* 394:    */     public V get(Object k)
/* 395:    */     {
/* 396:845 */       K key = k;
/* 397:846 */       V value = compute(key);
/* 398:847 */       Preconditions.checkNotNull(value, "%s returned null for key %s.", new Object[] { this.computingFunction, key });
/* 399:848 */       notifyRemoval(key, value);
/* 400:849 */       return value;
/* 401:    */     }
/* 402:    */     
/* 403:    */     private V compute(K key)
/* 404:    */     {
/* 405:853 */       Preconditions.checkNotNull(key);
/* 406:    */       try
/* 407:    */       {
/* 408:855 */         return this.computingFunction.apply(key);
/* 409:    */       }
/* 410:    */       catch (ComputationException e)
/* 411:    */       {
/* 412:857 */         throw e;
/* 413:    */       }
/* 414:    */       catch (Throwable t)
/* 415:    */       {
/* 416:859 */         throw new ComputationException(t);
/* 417:    */       }
/* 418:    */     }
/* 419:    */   }
/* 420:    */   
/* 421:    */   static final class ComputingMapAdapter<K, V>
/* 422:    */     extends ComputingConcurrentHashMap<K, V>
/* 423:    */     implements Serializable
/* 424:    */   {
/* 425:    */     private static final long serialVersionUID = 0L;
/* 426:    */     
/* 427:    */     ComputingMapAdapter(MapMaker mapMaker, Function<? super K, ? extends V> computingFunction)
/* 428:    */     {
/* 429:878 */       super(computingFunction);
/* 430:    */     }
/* 431:    */     
/* 432:    */     public V get(Object key)
/* 433:    */     {
/* 434:    */       V value;
/* 435:    */       try
/* 436:    */       {
/* 437:886 */         value = getOrCompute(key);
/* 438:    */       }
/* 439:    */       catch (ExecutionException e)
/* 440:    */       {
/* 441:888 */         Throwable cause = e.getCause();
/* 442:889 */         Throwables.propagateIfInstanceOf(cause, ComputationException.class);
/* 443:890 */         throw new ComputationException(cause);
/* 444:    */       }
/* 445:893 */       if (value == null) {
/* 446:894 */         throw new NullPointerException(this.computingFunction + " returned null for key " + key + ".");
/* 447:    */       }
/* 448:896 */       return value;
/* 449:    */     }
/* 450:    */   }
/* 451:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MapMaker
 * JD-Core Version:    0.7.0.1
 */
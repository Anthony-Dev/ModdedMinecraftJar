/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.math.IntMath;
/*   6:    */ import java.util.AbstractList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.ListIterator;
/*   9:    */ import java.util.RandomAccess;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ final class CartesianList<E>
/*  14:    */   extends AbstractList<List<E>>
/*  15:    */   implements RandomAccess
/*  16:    */ {
/*  17:    */   private final transient ImmutableList<List<E>> axes;
/*  18:    */   private final transient int[] axesSizeProduct;
/*  19:    */   
/*  20:    */   static <E> List<List<E>> create(List<? extends List<? extends E>> lists)
/*  21:    */   {
/*  22: 41 */     ImmutableList.Builder<List<E>> axesBuilder = new ImmutableList.Builder(lists.size());
/*  23: 43 */     for (List<? extends E> list : lists)
/*  24:    */     {
/*  25: 44 */       List<E> copy = ImmutableList.copyOf(list);
/*  26: 45 */       if (copy.isEmpty()) {
/*  27: 46 */         return ImmutableList.of();
/*  28:    */       }
/*  29: 48 */       axesBuilder.add(copy);
/*  30:    */     }
/*  31: 50 */     return new CartesianList(axesBuilder.build());
/*  32:    */   }
/*  33:    */   
/*  34:    */   CartesianList(ImmutableList<List<E>> axes)
/*  35:    */   {
/*  36: 54 */     this.axes = axes;
/*  37: 55 */     int[] axesSizeProduct = new int[axes.size() + 1];
/*  38: 56 */     axesSizeProduct[axes.size()] = 1;
/*  39:    */     try
/*  40:    */     {
/*  41: 58 */       for (int i = axes.size() - 1; i >= 0; i--) {
/*  42: 59 */         axesSizeProduct[i] = IntMath.checkedMultiply(axesSizeProduct[(i + 1)], ((List)axes.get(i)).size());
/*  43:    */       }
/*  44:    */     }
/*  45:    */     catch (ArithmeticException e)
/*  46:    */     {
/*  47: 63 */       throw new IllegalArgumentException("Cartesian product too large; must have size at most Integer.MAX_VALUE");
/*  48:    */     }
/*  49: 66 */     this.axesSizeProduct = axesSizeProduct;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private int getAxisIndexForProductIndex(int index, int axis)
/*  53:    */   {
/*  54: 70 */     return index / this.axesSizeProduct[(axis + 1)] % ((List)this.axes.get(axis)).size();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public ImmutableList<E> get(final int index)
/*  58:    */   {
/*  59: 75 */     Preconditions.checkElementIndex(index, size());
/*  60: 76 */     new ImmutableList()
/*  61:    */     {
/*  62:    */       public int size()
/*  63:    */       {
/*  64: 80 */         return CartesianList.this.axes.size();
/*  65:    */       }
/*  66:    */       
/*  67:    */       public E get(int axis)
/*  68:    */       {
/*  69: 85 */         Preconditions.checkElementIndex(axis, size());
/*  70: 86 */         int axisIndex = CartesianList.this.getAxisIndexForProductIndex(index, axis);
/*  71: 87 */         return ((List)CartesianList.this.axes.get(axis)).get(axisIndex);
/*  72:    */       }
/*  73:    */       
/*  74:    */       boolean isPartialView()
/*  75:    */       {
/*  76: 92 */         return true;
/*  77:    */       }
/*  78:    */     };
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int size()
/*  82:    */   {
/*  83: 99 */     return this.axesSizeProduct[0];
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean contains(@Nullable Object o)
/*  87:    */   {
/*  88:104 */     if (!(o instanceof List)) {
/*  89:105 */       return false;
/*  90:    */     }
/*  91:107 */     List<?> list = (List)o;
/*  92:108 */     if (list.size() != this.axes.size()) {
/*  93:109 */       return false;
/*  94:    */     }
/*  95:111 */     ListIterator<?> itr = list.listIterator();
/*  96:112 */     while (itr.hasNext())
/*  97:    */     {
/*  98:113 */       int index = itr.nextIndex();
/*  99:114 */       if (!((List)this.axes.get(index)).contains(itr.next())) {
/* 100:115 */         return false;
/* 101:    */       }
/* 102:    */     }
/* 103:118 */     return true;
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.CartesianList
 * JD-Core Version:    0.7.0.1
 */
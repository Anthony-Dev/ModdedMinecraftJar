package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class ForwardingImmutableMap<K, V> {}


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingImmutableMap
 * JD-Core Version:    0.7.0.1
 */
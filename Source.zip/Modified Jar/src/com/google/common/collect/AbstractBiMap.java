/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.io.Serializable;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ abstract class AbstractBiMap<K, V>
/*  20:    */   extends ForwardingMap<K, V>
/*  21:    */   implements BiMap<K, V>, Serializable
/*  22:    */ {
/*  23:    */   private transient Map<K, V> delegate;
/*  24:    */   transient AbstractBiMap<V, K> inverse;
/*  25:    */   private transient Set<K> keySet;
/*  26:    */   private transient Set<V> valueSet;
/*  27:    */   private transient Set<Map.Entry<K, V>> entrySet;
/*  28:    */   @GwtIncompatible("Not needed in emulated source.")
/*  29:    */   private static final long serialVersionUID = 0L;
/*  30:    */   
/*  31:    */   AbstractBiMap(Map<K, V> forward, Map<V, K> backward)
/*  32:    */   {
/*  33: 57 */     setDelegates(forward, backward);
/*  34:    */   }
/*  35:    */   
/*  36:    */   private AbstractBiMap(Map<K, V> backward, AbstractBiMap<V, K> forward)
/*  37:    */   {
/*  38: 62 */     this.delegate = backward;
/*  39: 63 */     this.inverse = forward;
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected Map<K, V> delegate()
/*  43:    */   {
/*  44: 67 */     return this.delegate;
/*  45:    */   }
/*  46:    */   
/*  47:    */   K checkKey(@Nullable K key)
/*  48:    */   {
/*  49: 74 */     return key;
/*  50:    */   }
/*  51:    */   
/*  52:    */   V checkValue(@Nullable V value)
/*  53:    */   {
/*  54: 81 */     return value;
/*  55:    */   }
/*  56:    */   
/*  57:    */   void setDelegates(Map<K, V> forward, Map<V, K> backward)
/*  58:    */   {
/*  59: 89 */     Preconditions.checkState(this.delegate == null);
/*  60: 90 */     Preconditions.checkState(this.inverse == null);
/*  61: 91 */     Preconditions.checkArgument(forward.isEmpty());
/*  62: 92 */     Preconditions.checkArgument(backward.isEmpty());
/*  63: 93 */     Preconditions.checkArgument(forward != backward);
/*  64: 94 */     this.delegate = forward;
/*  65: 95 */     this.inverse = new Inverse(backward, this, null);
/*  66:    */   }
/*  67:    */   
/*  68:    */   void setInverse(AbstractBiMap<V, K> inverse)
/*  69:    */   {
/*  70: 99 */     this.inverse = inverse;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean containsValue(@Nullable Object value)
/*  74:    */   {
/*  75:105 */     return this.inverse.containsKey(value);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public V put(@Nullable K key, @Nullable V value)
/*  79:    */   {
/*  80:111 */     return putInBothMaps(key, value, false);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public V forcePut(@Nullable K key, @Nullable V value)
/*  84:    */   {
/*  85:116 */     return putInBothMaps(key, value, true);
/*  86:    */   }
/*  87:    */   
/*  88:    */   private V putInBothMaps(@Nullable K key, @Nullable V value, boolean force)
/*  89:    */   {
/*  90:120 */     checkKey(key);
/*  91:121 */     checkValue(value);
/*  92:122 */     boolean containedKey = containsKey(key);
/*  93:123 */     if ((containedKey) && (Objects.equal(value, get(key)))) {
/*  94:124 */       return value;
/*  95:    */     }
/*  96:126 */     if (force) {
/*  97:127 */       inverse().remove(value);
/*  98:    */     } else {
/*  99:129 */       Preconditions.checkArgument(!containsValue(value), "value already present: %s", new Object[] { value });
/* 100:    */     }
/* 101:131 */     V oldValue = this.delegate.put(key, value);
/* 102:132 */     updateInverseMap(key, containedKey, oldValue, value);
/* 103:133 */     return oldValue;
/* 104:    */   }
/* 105:    */   
/* 106:    */   private void updateInverseMap(K key, boolean containedKey, V oldValue, V newValue)
/* 107:    */   {
/* 108:138 */     if (containedKey) {
/* 109:139 */       removeFromInverseMap(oldValue);
/* 110:    */     }
/* 111:141 */     this.inverse.delegate.put(newValue, key);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public V remove(@Nullable Object key)
/* 115:    */   {
/* 116:145 */     return containsKey(key) ? removeFromBothMaps(key) : null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   private V removeFromBothMaps(Object key)
/* 120:    */   {
/* 121:149 */     V oldValue = this.delegate.remove(key);
/* 122:150 */     removeFromInverseMap(oldValue);
/* 123:151 */     return oldValue;
/* 124:    */   }
/* 125:    */   
/* 126:    */   private void removeFromInverseMap(V oldValue)
/* 127:    */   {
/* 128:155 */     this.inverse.delegate.remove(oldValue);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void putAll(Map<? extends K, ? extends V> map)
/* 132:    */   {
/* 133:161 */     for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 134:162 */       put(entry.getKey(), entry.getValue());
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void clear()
/* 139:    */   {
/* 140:167 */     this.delegate.clear();
/* 141:168 */     this.inverse.delegate.clear();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public BiMap<V, K> inverse()
/* 145:    */   {
/* 146:175 */     return this.inverse;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public Set<K> keySet()
/* 150:    */   {
/* 151:181 */     Set<K> result = this.keySet;
/* 152:182 */     return result == null ? (this.keySet = new KeySet(null)) : result;
/* 153:    */   }
/* 154:    */   
/* 155:    */   private class KeySet
/* 156:    */     extends ForwardingSet<K>
/* 157:    */   {
/* 158:    */     private KeySet() {}
/* 159:    */     
/* 160:    */     protected Set<K> delegate()
/* 161:    */     {
/* 162:187 */       return AbstractBiMap.this.delegate.keySet();
/* 163:    */     }
/* 164:    */     
/* 165:    */     public void clear()
/* 166:    */     {
/* 167:191 */       AbstractBiMap.this.clear();
/* 168:    */     }
/* 169:    */     
/* 170:    */     public boolean remove(Object key)
/* 171:    */     {
/* 172:195 */       if (!contains(key)) {
/* 173:196 */         return false;
/* 174:    */       }
/* 175:198 */       AbstractBiMap.this.removeFromBothMaps(key);
/* 176:199 */       return true;
/* 177:    */     }
/* 178:    */     
/* 179:    */     public boolean removeAll(Collection<?> keysToRemove)
/* 180:    */     {
/* 181:203 */       return standardRemoveAll(keysToRemove);
/* 182:    */     }
/* 183:    */     
/* 184:    */     public boolean retainAll(Collection<?> keysToRetain)
/* 185:    */     {
/* 186:207 */       return standardRetainAll(keysToRetain);
/* 187:    */     }
/* 188:    */     
/* 189:    */     public Iterator<K> iterator()
/* 190:    */     {
/* 191:211 */       return Maps.keyIterator(AbstractBiMap.this.entrySet().iterator());
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public Set<V> values()
/* 196:    */   {
/* 197:222 */     Set<V> result = this.valueSet;
/* 198:223 */     return result == null ? (this.valueSet = new ValueSet(null)) : result;
/* 199:    */   }
/* 200:    */   
/* 201:    */   private class ValueSet
/* 202:    */     extends ForwardingSet<V>
/* 203:    */   {
/* 204:227 */     final Set<V> valuesDelegate = AbstractBiMap.this.inverse.keySet();
/* 205:    */     
/* 206:    */     private ValueSet() {}
/* 207:    */     
/* 208:    */     protected Set<V> delegate()
/* 209:    */     {
/* 210:230 */       return this.valuesDelegate;
/* 211:    */     }
/* 212:    */     
/* 213:    */     public Iterator<V> iterator()
/* 214:    */     {
/* 215:234 */       return Maps.valueIterator(AbstractBiMap.this.entrySet().iterator());
/* 216:    */     }
/* 217:    */     
/* 218:    */     public Object[] toArray()
/* 219:    */     {
/* 220:238 */       return standardToArray();
/* 221:    */     }
/* 222:    */     
/* 223:    */     public <T> T[] toArray(T[] array)
/* 224:    */     {
/* 225:242 */       return standardToArray(array);
/* 226:    */     }
/* 227:    */     
/* 228:    */     public String toString()
/* 229:    */     {
/* 230:246 */       return standardToString();
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */   public Set<Map.Entry<K, V>> entrySet()
/* 235:    */   {
/* 236:253 */     Set<Map.Entry<K, V>> result = this.entrySet;
/* 237:254 */     return result == null ? (this.entrySet = new EntrySet(null)) : result;
/* 238:    */   }
/* 239:    */   
/* 240:    */   private class EntrySet
/* 241:    */     extends ForwardingSet<Map.Entry<K, V>>
/* 242:    */   {
/* 243:258 */     final Set<Map.Entry<K, V>> esDelegate = AbstractBiMap.this.delegate.entrySet();
/* 244:    */     
/* 245:    */     private EntrySet() {}
/* 246:    */     
/* 247:    */     protected Set<Map.Entry<K, V>> delegate()
/* 248:    */     {
/* 249:261 */       return this.esDelegate;
/* 250:    */     }
/* 251:    */     
/* 252:    */     public void clear()
/* 253:    */     {
/* 254:265 */       AbstractBiMap.this.clear();
/* 255:    */     }
/* 256:    */     
/* 257:    */     public boolean remove(Object object)
/* 258:    */     {
/* 259:269 */       if (!this.esDelegate.contains(object)) {
/* 260:270 */         return false;
/* 261:    */       }
/* 262:274 */       Map.Entry<?, ?> entry = (Map.Entry)object;
/* 263:275 */       AbstractBiMap.this.inverse.delegate.remove(entry.getValue());
/* 264:    */       
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:281 */       this.esDelegate.remove(entry);
/* 270:282 */       return true;
/* 271:    */     }
/* 272:    */     
/* 273:    */     public Iterator<Map.Entry<K, V>> iterator()
/* 274:    */     {
/* 275:286 */       final Iterator<Map.Entry<K, V>> iterator = this.esDelegate.iterator();
/* 276:287 */       new Iterator()
/* 277:    */       {
/* 278:    */         Map.Entry<K, V> entry;
/* 279:    */         
/* 280:    */         public boolean hasNext()
/* 281:    */         {
/* 282:291 */           return iterator.hasNext();
/* 283:    */         }
/* 284:    */         
/* 285:    */         public Map.Entry<K, V> next()
/* 286:    */         {
/* 287:295 */           this.entry = ((Map.Entry)iterator.next());
/* 288:296 */           final Map.Entry<K, V> finalEntry = this.entry;
/* 289:    */           
/* 290:298 */           new ForwardingMapEntry()
/* 291:    */           {
/* 292:    */             protected Map.Entry<K, V> delegate()
/* 293:    */             {
/* 294:300 */               return finalEntry;
/* 295:    */             }
/* 296:    */             
/* 297:    */             public V setValue(V value)
/* 298:    */             {
/* 299:305 */               Preconditions.checkState(AbstractBiMap.EntrySet.this.contains(this), "entry no longer in map");
/* 300:307 */               if (Objects.equal(value, getValue())) {
/* 301:308 */                 return value;
/* 302:    */               }
/* 303:310 */               Preconditions.checkArgument(!AbstractBiMap.this.containsValue(value), "value already present: %s", new Object[] { value });
/* 304:    */               
/* 305:312 */               V oldValue = finalEntry.setValue(value);
/* 306:313 */               Preconditions.checkState(Objects.equal(value, AbstractBiMap.this.get(getKey())), "entry no longer in map");
/* 307:    */               
/* 308:315 */               AbstractBiMap.this.updateInverseMap(getKey(), true, oldValue, value);
/* 309:316 */               return oldValue;
/* 310:    */             }
/* 311:    */           };
/* 312:    */         }
/* 313:    */         
/* 314:    */         public void remove()
/* 315:    */         {
/* 316:322 */           CollectPreconditions.checkRemove(this.entry != null);
/* 317:323 */           V value = this.entry.getValue();
/* 318:324 */           iterator.remove();
/* 319:325 */           AbstractBiMap.this.removeFromInverseMap(value);
/* 320:    */         }
/* 321:    */       };
/* 322:    */     }
/* 323:    */     
/* 324:    */     public Object[] toArray()
/* 325:    */     {
/* 326:333 */       return standardToArray();
/* 327:    */     }
/* 328:    */     
/* 329:    */     public <T> T[] toArray(T[] array)
/* 330:    */     {
/* 331:336 */       return standardToArray(array);
/* 332:    */     }
/* 333:    */     
/* 334:    */     public boolean contains(Object o)
/* 335:    */     {
/* 336:339 */       return Maps.containsEntryImpl(delegate(), o);
/* 337:    */     }
/* 338:    */     
/* 339:    */     public boolean containsAll(Collection<?> c)
/* 340:    */     {
/* 341:342 */       return standardContainsAll(c);
/* 342:    */     }
/* 343:    */     
/* 344:    */     public boolean removeAll(Collection<?> c)
/* 345:    */     {
/* 346:345 */       return standardRemoveAll(c);
/* 347:    */     }
/* 348:    */     
/* 349:    */     public boolean retainAll(Collection<?> c)
/* 350:    */     {
/* 351:348 */       return standardRetainAll(c);
/* 352:    */     }
/* 353:    */   }
/* 354:    */   
/* 355:    */   private static class Inverse<K, V>
/* 356:    */     extends AbstractBiMap<K, V>
/* 357:    */   {
/* 358:    */     @GwtIncompatible("Not needed in emulated source.")
/* 359:    */     private static final long serialVersionUID = 0L;
/* 360:    */     
/* 361:    */     private Inverse(Map<K, V> backward, AbstractBiMap<V, K> forward)
/* 362:    */     {
/* 363:355 */       super(forward, null);
/* 364:    */     }
/* 365:    */     
/* 366:    */     K checkKey(K key)
/* 367:    */     {
/* 368:369 */       return this.inverse.checkValue(key);
/* 369:    */     }
/* 370:    */     
/* 371:    */     V checkValue(V value)
/* 372:    */     {
/* 373:374 */       return this.inverse.checkKey(value);
/* 374:    */     }
/* 375:    */     
/* 376:    */     @GwtIncompatible("java.io.ObjectOuputStream")
/* 377:    */     private void writeObject(ObjectOutputStream stream)
/* 378:    */       throws IOException
/* 379:    */     {
/* 380:382 */       stream.defaultWriteObject();
/* 381:383 */       stream.writeObject(inverse());
/* 382:    */     }
/* 383:    */     
/* 384:    */     @GwtIncompatible("java.io.ObjectInputStream")
/* 385:    */     private void readObject(ObjectInputStream stream)
/* 386:    */       throws IOException, ClassNotFoundException
/* 387:    */     {
/* 388:390 */       stream.defaultReadObject();
/* 389:391 */       setInverse((AbstractBiMap)stream.readObject());
/* 390:    */     }
/* 391:    */     
/* 392:    */     @GwtIncompatible("Not needed in the emulated source.")
/* 393:    */     Object readResolve()
/* 394:    */     {
/* 395:396 */       return inverse().inverse();
/* 396:    */     }
/* 397:    */   }
/* 398:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractBiMap
 * JD-Core Version:    0.7.0.1
 */
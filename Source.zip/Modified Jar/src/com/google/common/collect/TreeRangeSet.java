/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.NavigableMap;
/*  13:    */ import java.util.NoSuchElementException;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedMap;
/*  16:    */ import java.util.TreeMap;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ @GwtIncompatible("uses NavigableMap")
/*  21:    */ public class TreeRangeSet<C extends Comparable<?>>
/*  22:    */   extends AbstractRangeSet<C>
/*  23:    */ {
/*  24:    */   @VisibleForTesting
/*  25:    */   final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/*  26:    */   private transient Set<Range<C>> asRanges;
/*  27:    */   private transient RangeSet<C> complement;
/*  28:    */   
/*  29:    */   public static <C extends Comparable<?>> TreeRangeSet<C> create()
/*  30:    */   {
/*  31: 54 */     return new TreeRangeSet(new TreeMap());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <C extends Comparable<?>> TreeRangeSet<C> create(RangeSet<C> rangeSet)
/*  35:    */   {
/*  36: 61 */     TreeRangeSet<C> result = create();
/*  37: 62 */     result.addAll(rangeSet);
/*  38: 63 */     return result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private TreeRangeSet(NavigableMap<Cut<C>, Range<C>> rangesByLowerCut)
/*  42:    */   {
/*  43: 67 */     this.rangesByLowerBound = rangesByLowerCut;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Set<Range<C>> asRanges()
/*  47:    */   {
/*  48: 74 */     Set<Range<C>> result = this.asRanges;
/*  49: 75 */     return result == null ? (this.asRanges = new AsRanges()) : result;
/*  50:    */   }
/*  51:    */   
/*  52:    */   final class AsRanges
/*  53:    */     extends ForwardingCollection<Range<C>>
/*  54:    */     implements Set<Range<C>>
/*  55:    */   {
/*  56:    */     AsRanges() {}
/*  57:    */     
/*  58:    */     protected Collection<Range<C>> delegate()
/*  59:    */     {
/*  60: 81 */       return TreeRangeSet.this.rangesByLowerBound.values();
/*  61:    */     }
/*  62:    */     
/*  63:    */     public int hashCode()
/*  64:    */     {
/*  65: 86 */       return Sets.hashCodeImpl(this);
/*  66:    */     }
/*  67:    */     
/*  68:    */     public boolean equals(@Nullable Object o)
/*  69:    */     {
/*  70: 91 */       return Sets.equalsImpl(this, o);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   @Nullable
/*  75:    */   public Range<C> rangeContaining(C value)
/*  76:    */   {
/*  77: 98 */     Preconditions.checkNotNull(value);
/*  78: 99 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(Cut.belowValue(value));
/*  79:100 */     if ((floorEntry != null) && (((Range)floorEntry.getValue()).contains(value))) {
/*  80:101 */       return (Range)floorEntry.getValue();
/*  81:    */     }
/*  82:104 */     return null;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean encloses(Range<C> range)
/*  86:    */   {
/*  87:110 */     Preconditions.checkNotNull(range);
/*  88:111 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
/*  89:112 */     return (floorEntry != null) && (((Range)floorEntry.getValue()).encloses(range));
/*  90:    */   }
/*  91:    */   
/*  92:    */   @Nullable
/*  93:    */   private Range<C> rangeEnclosing(Range<C> range)
/*  94:    */   {
/*  95:117 */     Preconditions.checkNotNull(range);
/*  96:118 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
/*  97:119 */     return (floorEntry != null) && (((Range)floorEntry.getValue()).encloses(range)) ? (Range)floorEntry.getValue() : null;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Range<C> span()
/* 101:    */   {
/* 102:126 */     Map.Entry<Cut<C>, Range<C>> firstEntry = this.rangesByLowerBound.firstEntry();
/* 103:127 */     Map.Entry<Cut<C>, Range<C>> lastEntry = this.rangesByLowerBound.lastEntry();
/* 104:128 */     if (firstEntry == null) {
/* 105:129 */       throw new NoSuchElementException();
/* 106:    */     }
/* 107:131 */     return Range.create(((Range)firstEntry.getValue()).lowerBound, ((Range)lastEntry.getValue()).upperBound);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void add(Range<C> rangeToAdd)
/* 111:    */   {
/* 112:136 */     Preconditions.checkNotNull(rangeToAdd);
/* 113:138 */     if (rangeToAdd.isEmpty()) {
/* 114:139 */       return;
/* 115:    */     }
/* 116:144 */     Cut<C> lbToAdd = rangeToAdd.lowerBound;
/* 117:145 */     Cut<C> ubToAdd = rangeToAdd.upperBound;
/* 118:    */     
/* 119:147 */     Map.Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(lbToAdd);
/* 120:148 */     if (entryBelowLB != null)
/* 121:    */     {
/* 122:150 */       Range<C> rangeBelowLB = (Range)entryBelowLB.getValue();
/* 123:151 */       if (rangeBelowLB.upperBound.compareTo(lbToAdd) >= 0)
/* 124:    */       {
/* 125:153 */         if (rangeBelowLB.upperBound.compareTo(ubToAdd) >= 0) {
/* 126:155 */           ubToAdd = rangeBelowLB.upperBound;
/* 127:    */         }
/* 128:161 */         lbToAdd = rangeBelowLB.lowerBound;
/* 129:    */       }
/* 130:    */     }
/* 131:165 */     Map.Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(ubToAdd);
/* 132:166 */     if (entryBelowUB != null)
/* 133:    */     {
/* 134:168 */       Range<C> rangeBelowUB = (Range)entryBelowUB.getValue();
/* 135:169 */       if (rangeBelowUB.upperBound.compareTo(ubToAdd) >= 0) {
/* 136:171 */         ubToAdd = rangeBelowUB.upperBound;
/* 137:    */       }
/* 138:    */     }
/* 139:176 */     this.rangesByLowerBound.subMap(lbToAdd, ubToAdd).clear();
/* 140:    */     
/* 141:178 */     replaceRangeWithSameLowerBound(Range.create(lbToAdd, ubToAdd));
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void remove(Range<C> rangeToRemove)
/* 145:    */   {
/* 146:183 */     Preconditions.checkNotNull(rangeToRemove);
/* 147:185 */     if (rangeToRemove.isEmpty()) {
/* 148:186 */       return;
/* 149:    */     }
/* 150:192 */     Map.Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(rangeToRemove.lowerBound);
/* 151:193 */     if (entryBelowLB != null)
/* 152:    */     {
/* 153:195 */       Range<C> rangeBelowLB = (Range)entryBelowLB.getValue();
/* 154:196 */       if (rangeBelowLB.upperBound.compareTo(rangeToRemove.lowerBound) >= 0)
/* 155:    */       {
/* 156:198 */         if ((rangeToRemove.hasUpperBound()) && (rangeBelowLB.upperBound.compareTo(rangeToRemove.upperBound) >= 0)) {
/* 157:201 */           replaceRangeWithSameLowerBound(Range.create(rangeToRemove.upperBound, rangeBelowLB.upperBound));
/* 158:    */         }
/* 159:204 */         replaceRangeWithSameLowerBound(Range.create(rangeBelowLB.lowerBound, rangeToRemove.lowerBound));
/* 160:    */       }
/* 161:    */     }
/* 162:209 */     Map.Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(rangeToRemove.upperBound);
/* 163:210 */     if (entryBelowUB != null)
/* 164:    */     {
/* 165:212 */       Range<C> rangeBelowUB = (Range)entryBelowUB.getValue();
/* 166:213 */       if ((rangeToRemove.hasUpperBound()) && (rangeBelowUB.upperBound.compareTo(rangeToRemove.upperBound) >= 0)) {
/* 167:216 */         replaceRangeWithSameLowerBound(Range.create(rangeToRemove.upperBound, rangeBelowUB.upperBound));
/* 168:    */       }
/* 169:    */     }
/* 170:221 */     this.rangesByLowerBound.subMap(rangeToRemove.lowerBound, rangeToRemove.upperBound).clear();
/* 171:    */   }
/* 172:    */   
/* 173:    */   private void replaceRangeWithSameLowerBound(Range<C> range)
/* 174:    */   {
/* 175:225 */     if (range.isEmpty()) {
/* 176:226 */       this.rangesByLowerBound.remove(range.lowerBound);
/* 177:    */     } else {
/* 178:228 */       this.rangesByLowerBound.put(range.lowerBound, range);
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   public RangeSet<C> complement()
/* 183:    */   {
/* 184:236 */     RangeSet<C> result = this.complement;
/* 185:237 */     return result == null ? (this.complement = new Complement()) : result;
/* 186:    */   }
/* 187:    */   
/* 188:    */   @VisibleForTesting
/* 189:    */   static final class RangesByUpperBound<C extends Comparable<?>>
/* 190:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 191:    */   {
/* 192:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/* 193:    */     private final Range<Cut<C>> upperBoundWindow;
/* 194:    */     
/* 195:    */     RangesByUpperBound(NavigableMap<Cut<C>, Range<C>> rangesByLowerBound)
/* 196:    */     {
/* 197:252 */       this.rangesByLowerBound = rangesByLowerBound;
/* 198:253 */       this.upperBoundWindow = Range.all();
/* 199:    */     }
/* 200:    */     
/* 201:    */     private RangesByUpperBound(NavigableMap<Cut<C>, Range<C>> rangesByLowerBound, Range<Cut<C>> upperBoundWindow)
/* 202:    */     {
/* 203:258 */       this.rangesByLowerBound = rangesByLowerBound;
/* 204:259 */       this.upperBoundWindow = upperBoundWindow;
/* 205:    */     }
/* 206:    */     
/* 207:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> window)
/* 208:    */     {
/* 209:263 */       if (window.isConnected(this.upperBoundWindow)) {
/* 210:264 */         return new RangesByUpperBound(this.rangesByLowerBound, window.intersection(this.upperBoundWindow));
/* 211:    */       }
/* 212:266 */       return ImmutableSortedMap.of();
/* 213:    */     }
/* 214:    */     
/* 215:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 216:    */     {
/* 217:273 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 218:    */     }
/* 219:    */     
/* 220:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 221:    */     {
/* 222:280 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 223:    */     }
/* 224:    */     
/* 225:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 226:    */     {
/* 227:285 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 228:    */     }
/* 229:    */     
/* 230:    */     public Comparator<? super Cut<C>> comparator()
/* 231:    */     {
/* 232:290 */       return Ordering.natural();
/* 233:    */     }
/* 234:    */     
/* 235:    */     public boolean containsKey(@Nullable Object key)
/* 236:    */     {
/* 237:295 */       return get(key) != null;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public Range<C> get(@Nullable Object key)
/* 241:    */     {
/* 242:300 */       if ((key instanceof Cut)) {
/* 243:    */         try
/* 244:    */         {
/* 245:303 */           Cut<C> cut = (Cut)key;
/* 246:304 */           if (!this.upperBoundWindow.contains(cut)) {
/* 247:305 */             return null;
/* 248:    */           }
/* 249:307 */           Map.Entry<Cut<C>, Range<C>> candidate = this.rangesByLowerBound.lowerEntry(cut);
/* 250:308 */           if ((candidate != null) && (((Range)candidate.getValue()).upperBound.equals(cut))) {
/* 251:309 */             return (Range)candidate.getValue();
/* 252:    */           }
/* 253:    */         }
/* 254:    */         catch (ClassCastException e)
/* 255:    */         {
/* 256:312 */           return null;
/* 257:    */         }
/* 258:    */       }
/* 259:315 */       return null;
/* 260:    */     }
/* 261:    */     
/* 262:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 263:    */     {
/* 264:    */       Iterator<Range<C>> backingItr;
/* 265:    */       final Iterator<Range<C>> backingItr;
/* 266:325 */       if (!this.upperBoundWindow.hasLowerBound())
/* 267:    */       {
/* 268:326 */         backingItr = this.rangesByLowerBound.values().iterator();
/* 269:    */       }
/* 270:    */       else
/* 271:    */       {
/* 272:328 */         Map.Entry<Cut<C>, Range<C>> lowerEntry = this.rangesByLowerBound.lowerEntry(this.upperBoundWindow.lowerEndpoint());
/* 273:    */         Iterator<Range<C>> backingItr;
/* 274:330 */         if (lowerEntry == null)
/* 275:    */         {
/* 276:331 */           backingItr = this.rangesByLowerBound.values().iterator();
/* 277:    */         }
/* 278:    */         else
/* 279:    */         {
/* 280:    */           Iterator<Range<C>> backingItr;
/* 281:332 */           if (this.upperBoundWindow.lowerBound.isLessThan(((Range)lowerEntry.getValue()).upperBound)) {
/* 282:333 */             backingItr = this.rangesByLowerBound.tailMap(lowerEntry.getKey(), true).values().iterator();
/* 283:    */           } else {
/* 284:335 */             backingItr = this.rangesByLowerBound.tailMap(this.upperBoundWindow.lowerEndpoint(), true).values().iterator();
/* 285:    */           }
/* 286:    */         }
/* 287:    */       }
/* 288:339 */       new AbstractIterator()
/* 289:    */       {
/* 290:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 291:    */         {
/* 292:342 */           if (!backingItr.hasNext()) {
/* 293:343 */             return (Map.Entry)endOfData();
/* 294:    */           }
/* 295:345 */           Range<C> range = (Range)backingItr.next();
/* 296:346 */           if (TreeRangeSet.RangesByUpperBound.this.upperBoundWindow.upperBound.isLessThan(range.upperBound)) {
/* 297:347 */             return (Map.Entry)endOfData();
/* 298:    */           }
/* 299:349 */           return Maps.immutableEntry(range.upperBound, range);
/* 300:    */         }
/* 301:    */       };
/* 302:    */     }
/* 303:    */     
/* 304:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 305:    */     {
/* 306:    */       Collection<Range<C>> candidates;
/* 307:    */       Collection<Range<C>> candidates;
/* 308:358 */       if (this.upperBoundWindow.hasUpperBound()) {
/* 309:359 */         candidates = this.rangesByLowerBound.headMap(this.upperBoundWindow.upperEndpoint(), false).descendingMap().values();
/* 310:    */       } else {
/* 311:362 */         candidates = this.rangesByLowerBound.descendingMap().values();
/* 312:    */       }
/* 313:364 */       final PeekingIterator<Range<C>> backingItr = Iterators.peekingIterator(candidates.iterator());
/* 314:365 */       if ((backingItr.hasNext()) && (this.upperBoundWindow.upperBound.isLessThan(((Range)backingItr.peek()).upperBound))) {
/* 315:367 */         backingItr.next();
/* 316:    */       }
/* 317:369 */       new AbstractIterator()
/* 318:    */       {
/* 319:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 320:    */         {
/* 321:372 */           if (!backingItr.hasNext()) {
/* 322:373 */             return (Map.Entry)endOfData();
/* 323:    */           }
/* 324:375 */           Range<C> range = (Range)backingItr.next();
/* 325:376 */           return TreeRangeSet.RangesByUpperBound.this.upperBoundWindow.lowerBound.isLessThan(range.upperBound) ? Maps.immutableEntry(range.upperBound, range) : (Map.Entry)endOfData();
/* 326:    */         }
/* 327:    */       };
/* 328:    */     }
/* 329:    */     
/* 330:    */     public int size()
/* 331:    */     {
/* 332:385 */       if (this.upperBoundWindow.equals(Range.all())) {
/* 333:386 */         return this.rangesByLowerBound.size();
/* 334:    */       }
/* 335:388 */       return Iterators.size(entryIterator());
/* 336:    */     }
/* 337:    */     
/* 338:    */     public boolean isEmpty()
/* 339:    */     {
/* 340:393 */       return !entryIterator().hasNext() ? true : this.upperBoundWindow.equals(Range.all()) ? this.rangesByLowerBound.isEmpty() : false;
/* 341:    */     }
/* 342:    */   }
/* 343:    */   
/* 344:    */   private static final class ComplementRangesByLowerBound<C extends Comparable<?>>
/* 345:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 346:    */   {
/* 347:    */     private final NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound;
/* 348:    */     private final NavigableMap<Cut<C>, Range<C>> positiveRangesByUpperBound;
/* 349:    */     private final Range<Cut<C>> complementLowerBoundWindow;
/* 350:    */     
/* 351:    */     ComplementRangesByLowerBound(NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound)
/* 352:    */     {
/* 353:412 */       this(positiveRangesByLowerBound, Range.all());
/* 354:    */     }
/* 355:    */     
/* 356:    */     private ComplementRangesByLowerBound(NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound, Range<Cut<C>> window)
/* 357:    */     {
/* 358:417 */       this.positiveRangesByLowerBound = positiveRangesByLowerBound;
/* 359:418 */       this.positiveRangesByUpperBound = new TreeRangeSet.RangesByUpperBound(positiveRangesByLowerBound);
/* 360:419 */       this.complementLowerBoundWindow = window;
/* 361:    */     }
/* 362:    */     
/* 363:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> subWindow)
/* 364:    */     {
/* 365:423 */       if (!this.complementLowerBoundWindow.isConnected(subWindow)) {
/* 366:424 */         return ImmutableSortedMap.of();
/* 367:    */       }
/* 368:426 */       subWindow = subWindow.intersection(this.complementLowerBoundWindow);
/* 369:427 */       return new ComplementRangesByLowerBound(this.positiveRangesByLowerBound, subWindow);
/* 370:    */     }
/* 371:    */     
/* 372:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 373:    */     {
/* 374:434 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 375:    */     }
/* 376:    */     
/* 377:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 378:    */     {
/* 379:441 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 380:    */     }
/* 381:    */     
/* 382:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 383:    */     {
/* 384:446 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 385:    */     }
/* 386:    */     
/* 387:    */     public Comparator<? super Cut<C>> comparator()
/* 388:    */     {
/* 389:451 */       return Ordering.natural();
/* 390:    */     }
/* 391:    */     
/* 392:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 393:    */     {
/* 394:    */       Collection<Range<C>> positiveRanges;
/* 395:    */       Collection<Range<C>> positiveRanges;
/* 396:466 */       if (this.complementLowerBoundWindow.hasLowerBound()) {
/* 397:467 */         positiveRanges = this.positiveRangesByUpperBound.tailMap(this.complementLowerBoundWindow.lowerEndpoint(), this.complementLowerBoundWindow.lowerBoundType() == BoundType.CLOSED).values();
/* 398:    */       } else {
/* 399:471 */         positiveRanges = this.positiveRangesByUpperBound.values();
/* 400:    */       }
/* 401:473 */       final PeekingIterator<Range<C>> positiveItr = Iterators.peekingIterator(positiveRanges.iterator());
/* 402:    */       Cut<C> firstComplementRangeLowerBound;
/* 403:476 */       if ((this.complementLowerBoundWindow.contains(Cut.belowAll())) && ((!positiveItr.hasNext()) || (((Range)positiveItr.peek()).lowerBound != Cut.belowAll())))
/* 404:    */       {
/* 405:478 */         firstComplementRangeLowerBound = Cut.belowAll();
/* 406:    */       }
/* 407:    */       else
/* 408:    */       {
/* 409:    */         Cut<C> firstComplementRangeLowerBound;
/* 410:479 */         if (positiveItr.hasNext()) {
/* 411:480 */           firstComplementRangeLowerBound = ((Range)positiveItr.next()).upperBound;
/* 412:    */         } else {
/* 413:482 */           return Iterators.emptyIterator();
/* 414:    */         }
/* 415:    */       }
/* 416:    */       final Cut<C> firstComplementRangeLowerBound;
/* 417:484 */       new AbstractIterator()
/* 418:    */       {
/* 419:485 */         Cut<C> nextComplementRangeLowerBound = firstComplementRangeLowerBound;
/* 420:    */         
/* 421:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 422:    */         {
/* 423:489 */           if ((TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.upperBound.isLessThan(this.nextComplementRangeLowerBound)) || (this.nextComplementRangeLowerBound == Cut.aboveAll())) {
/* 424:491 */             return (Map.Entry)endOfData();
/* 425:    */           }
/* 426:    */           Range<C> negativeRange;
/* 427:494 */           if (positiveItr.hasNext())
/* 428:    */           {
/* 429:495 */             Range<C> positiveRange = (Range)positiveItr.next();
/* 430:496 */             Range<C> negativeRange = Range.create(this.nextComplementRangeLowerBound, positiveRange.lowerBound);
/* 431:497 */             this.nextComplementRangeLowerBound = positiveRange.upperBound;
/* 432:    */           }
/* 433:    */           else
/* 434:    */           {
/* 435:499 */             negativeRange = Range.create(this.nextComplementRangeLowerBound, Cut.aboveAll());
/* 436:500 */             this.nextComplementRangeLowerBound = Cut.aboveAll();
/* 437:    */           }
/* 438:502 */           return Maps.immutableEntry(negativeRange.lowerBound, negativeRange);
/* 439:    */         }
/* 440:    */       };
/* 441:    */     }
/* 442:    */     
/* 443:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 444:    */     {
/* 445:518 */       Cut<C> startingPoint = this.complementLowerBoundWindow.hasUpperBound() ? (Cut)this.complementLowerBoundWindow.upperEndpoint() : Cut.aboveAll();
/* 446:    */       
/* 447:    */ 
/* 448:521 */       boolean inclusive = (this.complementLowerBoundWindow.hasUpperBound()) && (this.complementLowerBoundWindow.upperBoundType() == BoundType.CLOSED);
/* 449:    */       
/* 450:523 */       final PeekingIterator<Range<C>> positiveItr = Iterators.peekingIterator(this.positiveRangesByUpperBound.headMap(startingPoint, inclusive).descendingMap().values().iterator());
/* 451:    */       Cut<C> cut;
/* 452:    */       Cut<C> cut;
/* 453:527 */       if (positiveItr.hasNext())
/* 454:    */       {
/* 455:528 */         cut = ((Range)positiveItr.peek()).upperBound == Cut.aboveAll() ? ((Range)positiveItr.next()).lowerBound : (Cut)this.positiveRangesByLowerBound.higherKey(((Range)positiveItr.peek()).upperBound);
/* 456:    */       }
/* 457:    */       else
/* 458:    */       {
/* 459:531 */         if ((!this.complementLowerBoundWindow.contains(Cut.belowAll())) || (this.positiveRangesByLowerBound.containsKey(Cut.belowAll()))) {
/* 460:533 */           return Iterators.emptyIterator();
/* 461:    */         }
/* 462:535 */         cut = (Cut)this.positiveRangesByLowerBound.higherKey(Cut.belowAll());
/* 463:    */       }
/* 464:537 */       final Cut<C> firstComplementRangeUpperBound = (Cut)Objects.firstNonNull(cut, Cut.aboveAll());
/* 465:538 */       new AbstractIterator()
/* 466:    */       {
/* 467:539 */         Cut<C> nextComplementRangeUpperBound = firstComplementRangeUpperBound;
/* 468:    */         
/* 469:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 470:    */         {
/* 471:543 */           if (this.nextComplementRangeUpperBound == Cut.belowAll()) {
/* 472:544 */             return (Map.Entry)endOfData();
/* 473:    */           }
/* 474:545 */           if (positiveItr.hasNext())
/* 475:    */           {
/* 476:546 */             Range<C> positiveRange = (Range)positiveItr.next();
/* 477:547 */             Range<C> negativeRange = Range.create(positiveRange.upperBound, this.nextComplementRangeUpperBound);
/* 478:    */             
/* 479:549 */             this.nextComplementRangeUpperBound = positiveRange.lowerBound;
/* 480:550 */             if (TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.lowerBound.isLessThan(negativeRange.lowerBound)) {
/* 481:551 */               return Maps.immutableEntry(negativeRange.lowerBound, negativeRange);
/* 482:    */             }
/* 483:    */           }
/* 484:553 */           else if (TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.lowerBound.isLessThan(Cut.belowAll()))
/* 485:    */           {
/* 486:554 */             Range<C> negativeRange = Range.create(Cut.belowAll(), this.nextComplementRangeUpperBound);
/* 487:    */             
/* 488:556 */             this.nextComplementRangeUpperBound = Cut.belowAll();
/* 489:557 */             return Maps.immutableEntry(Cut.belowAll(), negativeRange);
/* 490:    */           }
/* 491:559 */           return (Map.Entry)endOfData();
/* 492:    */         }
/* 493:    */       };
/* 494:    */     }
/* 495:    */     
/* 496:    */     public int size()
/* 497:    */     {
/* 498:566 */       return Iterators.size(entryIterator());
/* 499:    */     }
/* 500:    */     
/* 501:    */     @Nullable
/* 502:    */     public Range<C> get(Object key)
/* 503:    */     {
/* 504:572 */       if ((key instanceof Cut)) {
/* 505:    */         try
/* 506:    */         {
/* 507:575 */           Cut<C> cut = (Cut)key;
/* 508:    */           
/* 509:577 */           Map.Entry<Cut<C>, Range<C>> firstEntry = tailMap(cut, true).firstEntry();
/* 510:578 */           if ((firstEntry != null) && (((Cut)firstEntry.getKey()).equals(cut))) {
/* 511:579 */             return (Range)firstEntry.getValue();
/* 512:    */           }
/* 513:    */         }
/* 514:    */         catch (ClassCastException e)
/* 515:    */         {
/* 516:582 */           return null;
/* 517:    */         }
/* 518:    */       }
/* 519:585 */       return null;
/* 520:    */     }
/* 521:    */     
/* 522:    */     public boolean containsKey(Object key)
/* 523:    */     {
/* 524:590 */       return get(key) != null;
/* 525:    */     }
/* 526:    */   }
/* 527:    */   
/* 528:    */   private final class Complement
/* 529:    */     extends TreeRangeSet<C>
/* 530:    */   {
/* 531:    */     Complement()
/* 532:    */     {
/* 533:596 */       super(null);
/* 534:    */     }
/* 535:    */     
/* 536:    */     public void add(Range<C> rangeToAdd)
/* 537:    */     {
/* 538:601 */       TreeRangeSet.this.remove(rangeToAdd);
/* 539:    */     }
/* 540:    */     
/* 541:    */     public void remove(Range<C> rangeToRemove)
/* 542:    */     {
/* 543:606 */       TreeRangeSet.this.add(rangeToRemove);
/* 544:    */     }
/* 545:    */     
/* 546:    */     public boolean contains(C value)
/* 547:    */     {
/* 548:611 */       return !TreeRangeSet.this.contains(value);
/* 549:    */     }
/* 550:    */     
/* 551:    */     public RangeSet<C> complement()
/* 552:    */     {
/* 553:616 */       return TreeRangeSet.this;
/* 554:    */     }
/* 555:    */   }
/* 556:    */   
/* 557:    */   private static final class SubRangeSetRangesByLowerBound<C extends Comparable<?>>
/* 558:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 559:    */   {
/* 560:    */     private final Range<Cut<C>> lowerBoundWindow;
/* 561:    */     private final Range<C> restriction;
/* 562:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/* 563:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByUpperBound;
/* 564:    */     
/* 565:    */     private SubRangeSetRangesByLowerBound(Range<Cut<C>> lowerBoundWindow, Range<C> restriction, NavigableMap<Cut<C>, Range<C>> rangesByLowerBound)
/* 566:    */     {
/* 567:639 */       this.lowerBoundWindow = ((Range)Preconditions.checkNotNull(lowerBoundWindow));
/* 568:640 */       this.restriction = ((Range)Preconditions.checkNotNull(restriction));
/* 569:641 */       this.rangesByLowerBound = ((NavigableMap)Preconditions.checkNotNull(rangesByLowerBound));
/* 570:642 */       this.rangesByUpperBound = new TreeRangeSet.RangesByUpperBound(rangesByLowerBound);
/* 571:    */     }
/* 572:    */     
/* 573:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> window)
/* 574:    */     {
/* 575:646 */       if (!window.isConnected(this.lowerBoundWindow)) {
/* 576:647 */         return ImmutableSortedMap.of();
/* 577:    */       }
/* 578:649 */       return new SubRangeSetRangesByLowerBound(this.lowerBoundWindow.intersection(window), this.restriction, this.rangesByLowerBound);
/* 579:    */     }
/* 580:    */     
/* 581:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 582:    */     {
/* 583:657 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 584:    */     }
/* 585:    */     
/* 586:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 587:    */     {
/* 588:663 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 589:    */     }
/* 590:    */     
/* 591:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 592:    */     {
/* 593:668 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 594:    */     }
/* 595:    */     
/* 596:    */     public Comparator<? super Cut<C>> comparator()
/* 597:    */     {
/* 598:673 */       return Ordering.natural();
/* 599:    */     }
/* 600:    */     
/* 601:    */     public boolean containsKey(@Nullable Object key)
/* 602:    */     {
/* 603:678 */       return get(key) != null;
/* 604:    */     }
/* 605:    */     
/* 606:    */     @Nullable
/* 607:    */     public Range<C> get(@Nullable Object key)
/* 608:    */     {
/* 609:684 */       if ((key instanceof Cut)) {
/* 610:    */         try
/* 611:    */         {
/* 612:687 */           Cut<C> cut = (Cut)key;
/* 613:688 */           if ((!this.lowerBoundWindow.contains(cut)) || (cut.compareTo(this.restriction.lowerBound) < 0) || (cut.compareTo(this.restriction.upperBound) >= 0)) {
/* 614:690 */             return null;
/* 615:    */           }
/* 616:691 */           if (cut.equals(this.restriction.lowerBound))
/* 617:    */           {
/* 618:693 */             Range<C> candidate = (Range)Maps.valueOrNull(this.rangesByLowerBound.floorEntry(cut));
/* 619:694 */             if ((candidate != null) && (candidate.upperBound.compareTo(this.restriction.lowerBound) > 0)) {
/* 620:695 */               return candidate.intersection(this.restriction);
/* 621:    */             }
/* 622:    */           }
/* 623:    */           else
/* 624:    */           {
/* 625:698 */             Range<C> result = (Range)this.rangesByLowerBound.get(cut);
/* 626:699 */             if (result != null) {
/* 627:700 */               return result.intersection(this.restriction);
/* 628:    */             }
/* 629:    */           }
/* 630:    */         }
/* 631:    */         catch (ClassCastException e)
/* 632:    */         {
/* 633:704 */           return null;
/* 634:    */         }
/* 635:    */       }
/* 636:707 */       return null;
/* 637:    */     }
/* 638:    */     
/* 639:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 640:    */     {
/* 641:712 */       if (this.restriction.isEmpty()) {
/* 642:713 */         return Iterators.emptyIterator();
/* 643:    */       }
/* 644:716 */       if (this.lowerBoundWindow.upperBound.isLessThan(this.restriction.lowerBound)) {
/* 645:717 */         return Iterators.emptyIterator();
/* 646:    */       }
/* 647:    */       Iterator<Range<C>> completeRangeItr;
/* 648:    */       final Iterator<Range<C>> completeRangeItr;
/* 649:718 */       if (this.lowerBoundWindow.lowerBound.isLessThan(this.restriction.lowerBound)) {
/* 650:720 */         completeRangeItr = this.rangesByUpperBound.tailMap(this.restriction.lowerBound, false).values().iterator();
/* 651:    */       } else {
/* 652:724 */         completeRangeItr = this.rangesByLowerBound.tailMap(this.lowerBoundWindow.lowerBound.endpoint(), this.lowerBoundWindow.lowerBoundType() == BoundType.CLOSED).values().iterator();
/* 653:    */       }
/* 654:727 */       final Cut<Cut<C>> upperBoundOnLowerBounds = (Cut)Ordering.natural().min(this.lowerBoundWindow.upperBound, Cut.belowValue(this.restriction.upperBound));
/* 655:    */       
/* 656:729 */       new AbstractIterator()
/* 657:    */       {
/* 658:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 659:    */         {
/* 660:732 */           if (!completeRangeItr.hasNext()) {
/* 661:733 */             return (Map.Entry)endOfData();
/* 662:    */           }
/* 663:735 */           Range<C> nextRange = (Range)completeRangeItr.next();
/* 664:736 */           if (upperBoundOnLowerBounds.isLessThan(nextRange.lowerBound)) {
/* 665:737 */             return (Map.Entry)endOfData();
/* 666:    */           }
/* 667:739 */           nextRange = nextRange.intersection(TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction);
/* 668:740 */           return Maps.immutableEntry(nextRange.lowerBound, nextRange);
/* 669:    */         }
/* 670:    */       };
/* 671:    */     }
/* 672:    */     
/* 673:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 674:    */     {
/* 675:748 */       if (this.restriction.isEmpty()) {
/* 676:749 */         return Iterators.emptyIterator();
/* 677:    */       }
/* 678:751 */       Cut<Cut<C>> upperBoundOnLowerBounds = (Cut)Ordering.natural().min(this.lowerBoundWindow.upperBound, Cut.belowValue(this.restriction.upperBound));
/* 679:    */       
/* 680:753 */       final Iterator<Range<C>> completeRangeItr = this.rangesByLowerBound.headMap(upperBoundOnLowerBounds.endpoint(), upperBoundOnLowerBounds.typeAsUpperBound() == BoundType.CLOSED).descendingMap().values().iterator();
/* 681:    */       
/* 682:    */ 
/* 683:    */ 
/* 684:757 */       new AbstractIterator()
/* 685:    */       {
/* 686:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 687:    */         {
/* 688:760 */           if (!completeRangeItr.hasNext()) {
/* 689:761 */             return (Map.Entry)endOfData();
/* 690:    */           }
/* 691:763 */           Range<C> nextRange = (Range)completeRangeItr.next();
/* 692:764 */           if (TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction.lowerBound.compareTo(nextRange.upperBound) >= 0) {
/* 693:765 */             return (Map.Entry)endOfData();
/* 694:    */           }
/* 695:767 */           nextRange = nextRange.intersection(TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction);
/* 696:768 */           if (TreeRangeSet.SubRangeSetRangesByLowerBound.this.lowerBoundWindow.contains(nextRange.lowerBound)) {
/* 697:769 */             return Maps.immutableEntry(nextRange.lowerBound, nextRange);
/* 698:    */           }
/* 699:771 */           return (Map.Entry)endOfData();
/* 700:    */         }
/* 701:    */       };
/* 702:    */     }
/* 703:    */     
/* 704:    */     public int size()
/* 705:    */     {
/* 706:779 */       return Iterators.size(entryIterator());
/* 707:    */     }
/* 708:    */   }
/* 709:    */   
/* 710:    */   public RangeSet<C> subRangeSet(Range<C> view)
/* 711:    */   {
/* 712:785 */     return view.equals(Range.all()) ? this : new SubRangeSet(view);
/* 713:    */   }
/* 714:    */   
/* 715:    */   private final class SubRangeSet
/* 716:    */     extends TreeRangeSet<C>
/* 717:    */   {
/* 718:    */     private final Range<C> restriction;
/* 719:    */     
/* 720:    */     SubRangeSet()
/* 721:    */     {
/* 722:792 */       super(null);
/* 723:    */       
/* 724:794 */       this.restriction = restriction;
/* 725:    */     }
/* 726:    */     
/* 727:    */     public boolean encloses(Range<C> range)
/* 728:    */     {
/* 729:799 */       if ((!this.restriction.isEmpty()) && (this.restriction.encloses(range)))
/* 730:    */       {
/* 731:800 */         Range<C> enclosing = TreeRangeSet.this.rangeEnclosing(range);
/* 732:801 */         return (enclosing != null) && (!enclosing.intersection(this.restriction).isEmpty());
/* 733:    */       }
/* 734:803 */       return false;
/* 735:    */     }
/* 736:    */     
/* 737:    */     @Nullable
/* 738:    */     public Range<C> rangeContaining(C value)
/* 739:    */     {
/* 740:809 */       if (!this.restriction.contains(value)) {
/* 741:810 */         return null;
/* 742:    */       }
/* 743:812 */       Range<C> result = TreeRangeSet.this.rangeContaining(value);
/* 744:813 */       return result == null ? null : result.intersection(this.restriction);
/* 745:    */     }
/* 746:    */     
/* 747:    */     public void add(Range<C> rangeToAdd)
/* 748:    */     {
/* 749:818 */       Preconditions.checkArgument(this.restriction.encloses(rangeToAdd), "Cannot add range %s to subRangeSet(%s)", new Object[] { rangeToAdd, this.restriction });
/* 750:    */       
/* 751:820 */       super.add(rangeToAdd);
/* 752:    */     }
/* 753:    */     
/* 754:    */     public void remove(Range<C> rangeToRemove)
/* 755:    */     {
/* 756:825 */       if (rangeToRemove.isConnected(this.restriction)) {
/* 757:826 */         TreeRangeSet.this.remove(rangeToRemove.intersection(this.restriction));
/* 758:    */       }
/* 759:    */     }
/* 760:    */     
/* 761:    */     public boolean contains(C value)
/* 762:    */     {
/* 763:832 */       return (this.restriction.contains(value)) && (TreeRangeSet.this.contains(value));
/* 764:    */     }
/* 765:    */     
/* 766:    */     public void clear()
/* 767:    */     {
/* 768:837 */       TreeRangeSet.this.remove(this.restriction);
/* 769:    */     }
/* 770:    */     
/* 771:    */     public RangeSet<C> subRangeSet(Range<C> view)
/* 772:    */     {
/* 773:842 */       if (view.encloses(this.restriction)) {
/* 774:843 */         return this;
/* 775:    */       }
/* 776:844 */       if (view.isConnected(this.restriction)) {
/* 777:845 */         return new SubRangeSet(this, this.restriction.intersection(view));
/* 778:    */       }
/* 779:847 */       return ImmutableRangeSet.of();
/* 780:    */     }
/* 781:    */   }
/* 782:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.TreeRangeSet
 * JD-Core Version:    0.7.0.1
 */
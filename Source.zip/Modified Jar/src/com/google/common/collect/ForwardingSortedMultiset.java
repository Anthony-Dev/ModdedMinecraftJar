/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.NavigableSet;
/*   8:    */ import java.util.Set;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ForwardingSortedMultiset<E>
/*  13:    */   extends ForwardingMultiset<E>
/*  14:    */   implements SortedMultiset<E>
/*  15:    */ {
/*  16:    */   protected abstract SortedMultiset<E> delegate();
/*  17:    */   
/*  18:    */   public NavigableSet<E> elementSet()
/*  19:    */   {
/*  20: 54 */     return (NavigableSet)super.elementSet();
/*  21:    */   }
/*  22:    */   
/*  23:    */   protected class StandardElementSet
/*  24:    */     extends SortedMultisets.NavigableElementSet<E>
/*  25:    */   {
/*  26:    */     public StandardElementSet()
/*  27:    */     {
/*  28: 71 */       super();
/*  29:    */     }
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Comparator<? super E> comparator()
/*  33:    */   {
/*  34: 77 */     return delegate().comparator();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public SortedMultiset<E> descendingMultiset()
/*  38:    */   {
/*  39: 82 */     return delegate().descendingMultiset();
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected abstract class StandardDescendingMultiset
/*  43:    */     extends DescendingMultiset<E>
/*  44:    */   {
/*  45:    */     public StandardDescendingMultiset() {}
/*  46:    */     
/*  47:    */     SortedMultiset<E> forwardMultiset()
/*  48:    */     {
/*  49:102 */       return ForwardingSortedMultiset.this;
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Multiset.Entry<E> firstEntry()
/*  54:    */   {
/*  55:108 */     return delegate().firstEntry();
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected Multiset.Entry<E> standardFirstEntry()
/*  59:    */   {
/*  60:118 */     Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/*  61:119 */     if (!entryIterator.hasNext()) {
/*  62:120 */       return null;
/*  63:    */     }
/*  64:122 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  65:123 */     return Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Multiset.Entry<E> lastEntry()
/*  69:    */   {
/*  70:128 */     return delegate().lastEntry();
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected Multiset.Entry<E> standardLastEntry()
/*  74:    */   {
/*  75:139 */     Iterator<Multiset.Entry<E>> entryIterator = descendingMultiset().entrySet().iterator();
/*  76:142 */     if (!entryIterator.hasNext()) {
/*  77:143 */       return null;
/*  78:    */     }
/*  79:145 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  80:146 */     return Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Multiset.Entry<E> pollFirstEntry()
/*  84:    */   {
/*  85:151 */     return delegate().pollFirstEntry();
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected Multiset.Entry<E> standardPollFirstEntry()
/*  89:    */   {
/*  90:161 */     Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/*  91:162 */     if (!entryIterator.hasNext()) {
/*  92:163 */       return null;
/*  93:    */     }
/*  94:165 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  95:166 */     entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  96:167 */     entryIterator.remove();
/*  97:168 */     return entry;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Multiset.Entry<E> pollLastEntry()
/* 101:    */   {
/* 102:173 */     return delegate().pollLastEntry();
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected Multiset.Entry<E> standardPollLastEntry()
/* 106:    */   {
/* 107:184 */     Iterator<Multiset.Entry<E>> entryIterator = descendingMultiset().entrySet().iterator();
/* 108:187 */     if (!entryIterator.hasNext()) {
/* 109:188 */       return null;
/* 110:    */     }
/* 111:190 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/* 112:191 */     entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
/* 113:192 */     entryIterator.remove();
/* 114:193 */     return entry;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public SortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/* 118:    */   {
/* 119:198 */     return delegate().headMultiset(upperBound, boundType);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public SortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 123:    */   {
/* 124:204 */     return delegate().subMultiset(lowerBound, lowerBoundType, upperBound, upperBoundType);
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected SortedMultiset<E> standardSubMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 128:    */   {
/* 129:217 */     return tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public SortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/* 133:    */   {
/* 134:222 */     return delegate().tailMultiset(lowerBound, boundType);
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingSortedMultiset
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.SortedSet;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @GwtCompatible
/*  14:    */ public final class Range<C extends Comparable>
/*  15:    */   implements Predicate<C>, Serializable
/*  16:    */ {
/*  17:117 */   private static final Function<Range, Cut> LOWER_BOUND_FN = new Function()
/*  18:    */   {
/*  19:    */     public Cut apply(Range range)
/*  20:    */     {
/*  21:120 */       return range.lowerBound;
/*  22:    */     }
/*  23:    */   };
/*  24:    */   
/*  25:    */   static <C extends Comparable<?>> Function<Range<C>, Cut<C>> lowerBoundFn()
/*  26:    */   {
/*  27:126 */     return LOWER_BOUND_FN;
/*  28:    */   }
/*  29:    */   
/*  30:129 */   private static final Function<Range, Cut> UPPER_BOUND_FN = new Function()
/*  31:    */   {
/*  32:    */     public Cut apply(Range range)
/*  33:    */     {
/*  34:132 */       return range.upperBound;
/*  35:    */     }
/*  36:    */   };
/*  37:    */   
/*  38:    */   static <C extends Comparable<?>> Function<Range<C>, Cut<C>> upperBoundFn()
/*  39:    */   {
/*  40:138 */     return UPPER_BOUND_FN;
/*  41:    */   }
/*  42:    */   
/*  43:141 */   static final Ordering<Range<?>> RANGE_LEX_ORDERING = new Ordering()
/*  44:    */   {
/*  45:    */     public int compare(Range<?> left, Range<?> right)
/*  46:    */     {
/*  47:144 */       return ComparisonChain.start().compare(left.lowerBound, right.lowerBound).compare(left.upperBound, right.upperBound).result();
/*  48:    */     }
/*  49:    */   };
/*  50:    */   
/*  51:    */   static <C extends Comparable<?>> Range<C> create(Cut<C> lowerBound, Cut<C> upperBound)
/*  52:    */   {
/*  53:153 */     return new Range(lowerBound, upperBound);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <C extends Comparable<?>> Range<C> open(C lower, C upper)
/*  57:    */   {
/*  58:165 */     return create(Cut.aboveValue(lower), Cut.belowValue(upper));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <C extends Comparable<?>> Range<C> closed(C lower, C upper)
/*  62:    */   {
/*  63:177 */     return create(Cut.belowValue(lower), Cut.aboveValue(upper));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <C extends Comparable<?>> Range<C> closedOpen(C lower, C upper)
/*  67:    */   {
/*  68:190 */     return create(Cut.belowValue(lower), Cut.belowValue(upper));
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <C extends Comparable<?>> Range<C> openClosed(C lower, C upper)
/*  72:    */   {
/*  73:203 */     return create(Cut.aboveValue(lower), Cut.aboveValue(upper));
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <C extends Comparable<?>> Range<C> range(C lower, BoundType lowerType, C upper, BoundType upperType)
/*  77:    */   {
/*  78:217 */     Preconditions.checkNotNull(lowerType);
/*  79:218 */     Preconditions.checkNotNull(upperType);
/*  80:    */     
/*  81:220 */     Cut<C> lowerBound = lowerType == BoundType.OPEN ? Cut.aboveValue(lower) : Cut.belowValue(lower);
/*  82:    */     
/*  83:    */ 
/*  84:223 */     Cut<C> upperBound = upperType == BoundType.OPEN ? Cut.belowValue(upper) : Cut.aboveValue(upper);
/*  85:    */     
/*  86:    */ 
/*  87:226 */     return create(lowerBound, upperBound);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static <C extends Comparable<?>> Range<C> lessThan(C endpoint)
/*  91:    */   {
/*  92:236 */     return create(Cut.belowAll(), Cut.belowValue(endpoint));
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static <C extends Comparable<?>> Range<C> atMost(C endpoint)
/*  96:    */   {
/*  97:246 */     return create(Cut.belowAll(), Cut.aboveValue(endpoint));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static <C extends Comparable<?>> Range<C> upTo(C endpoint, BoundType boundType)
/* 101:    */   {
/* 102:257 */     switch (4.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 103:    */     {
/* 104:    */     case 1: 
/* 105:259 */       return lessThan(endpoint);
/* 106:    */     case 2: 
/* 107:261 */       return atMost(endpoint);
/* 108:    */     }
/* 109:263 */     throw new AssertionError();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static <C extends Comparable<?>> Range<C> greaterThan(C endpoint)
/* 113:    */   {
/* 114:274 */     return create(Cut.aboveValue(endpoint), Cut.aboveAll());
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static <C extends Comparable<?>> Range<C> atLeast(C endpoint)
/* 118:    */   {
/* 119:284 */     return create(Cut.belowValue(endpoint), Cut.aboveAll());
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static <C extends Comparable<?>> Range<C> downTo(C endpoint, BoundType boundType)
/* 123:    */   {
/* 124:295 */     switch (4.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 125:    */     {
/* 126:    */     case 1: 
/* 127:297 */       return greaterThan(endpoint);
/* 128:    */     case 2: 
/* 129:299 */       return atLeast(endpoint);
/* 130:    */     }
/* 131:301 */     throw new AssertionError();
/* 132:    */   }
/* 133:    */   
/* 134:305 */   private static final Range<Comparable> ALL = new Range(Cut.belowAll(), Cut.aboveAll());
/* 135:    */   final Cut<C> lowerBound;
/* 136:    */   final Cut<C> upperBound;
/* 137:    */   private static final long serialVersionUID = 0L;
/* 138:    */   
/* 139:    */   public static <C extends Comparable<?>> Range<C> all()
/* 140:    */   {
/* 141:315 */     return ALL;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public static <C extends Comparable<?>> Range<C> singleton(C value)
/* 145:    */   {
/* 146:326 */     return closed(value, value);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static <C extends Comparable<?>> Range<C> encloseAll(Iterable<C> values)
/* 150:    */   {
/* 151:342 */     Preconditions.checkNotNull(values);
/* 152:343 */     if ((values instanceof ContiguousSet)) {
/* 153:344 */       return ((ContiguousSet)values).range();
/* 154:    */     }
/* 155:346 */     Iterator<C> valueIterator = values.iterator();
/* 156:347 */     C min = (Comparable)Preconditions.checkNotNull(valueIterator.next());
/* 157:348 */     C max = min;
/* 158:349 */     while (valueIterator.hasNext())
/* 159:    */     {
/* 160:350 */       C value = (Comparable)Preconditions.checkNotNull(valueIterator.next());
/* 161:351 */       min = (Comparable)Ordering.natural().min(min, value);
/* 162:352 */       max = (Comparable)Ordering.natural().max(max, value);
/* 163:    */     }
/* 164:354 */     return closed(min, max);
/* 165:    */   }
/* 166:    */   
/* 167:    */   private Range(Cut<C> lowerBound, Cut<C> upperBound)
/* 168:    */   {
/* 169:361 */     if ((lowerBound.compareTo(upperBound) > 0) || (lowerBound == Cut.aboveAll()) || (upperBound == Cut.belowAll())) {
/* 170:363 */       throw new IllegalArgumentException("Invalid range: " + toString(lowerBound, upperBound));
/* 171:    */     }
/* 172:365 */     this.lowerBound = ((Cut)Preconditions.checkNotNull(lowerBound));
/* 173:366 */     this.upperBound = ((Cut)Preconditions.checkNotNull(upperBound));
/* 174:    */   }
/* 175:    */   
/* 176:    */   public boolean hasLowerBound()
/* 177:    */   {
/* 178:373 */     return this.lowerBound != Cut.belowAll();
/* 179:    */   }
/* 180:    */   
/* 181:    */   public C lowerEndpoint()
/* 182:    */   {
/* 183:383 */     return this.lowerBound.endpoint();
/* 184:    */   }
/* 185:    */   
/* 186:    */   public BoundType lowerBoundType()
/* 187:    */   {
/* 188:394 */     return this.lowerBound.typeAsLowerBound();
/* 189:    */   }
/* 190:    */   
/* 191:    */   public boolean hasUpperBound()
/* 192:    */   {
/* 193:401 */     return this.upperBound != Cut.aboveAll();
/* 194:    */   }
/* 195:    */   
/* 196:    */   public C upperEndpoint()
/* 197:    */   {
/* 198:411 */     return this.upperBound.endpoint();
/* 199:    */   }
/* 200:    */   
/* 201:    */   public BoundType upperBoundType()
/* 202:    */   {
/* 203:422 */     return this.upperBound.typeAsUpperBound();
/* 204:    */   }
/* 205:    */   
/* 206:    */   public boolean isEmpty()
/* 207:    */   {
/* 208:435 */     return this.lowerBound.equals(this.upperBound);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public boolean contains(C value)
/* 212:    */   {
/* 213:444 */     Preconditions.checkNotNull(value);
/* 214:    */     
/* 215:446 */     return (this.lowerBound.isLessThan(value)) && (!this.upperBound.isLessThan(value));
/* 216:    */   }
/* 217:    */   
/* 218:    */   @Deprecated
/* 219:    */   public boolean apply(C input)
/* 220:    */   {
/* 221:456 */     return contains(input);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public boolean containsAll(Iterable<? extends C> values)
/* 225:    */   {
/* 226:464 */     if (Iterables.isEmpty(values)) {
/* 227:465 */       return true;
/* 228:    */     }
/* 229:469 */     if ((values instanceof SortedSet))
/* 230:    */     {
/* 231:470 */       SortedSet<? extends C> set = cast(values);
/* 232:471 */       Comparator<?> comparator = set.comparator();
/* 233:472 */       if ((Ordering.natural().equals(comparator)) || (comparator == null)) {
/* 234:473 */         return (contains((Comparable)set.first())) && (contains((Comparable)set.last()));
/* 235:    */       }
/* 236:    */     }
/* 237:477 */     for (C value : values) {
/* 238:478 */       if (!contains(value)) {
/* 239:479 */         return false;
/* 240:    */       }
/* 241:    */     }
/* 242:482 */     return true;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean encloses(Range<C> other)
/* 246:    */   {
/* 247:510 */     return (this.lowerBound.compareTo(other.lowerBound) <= 0) && (this.upperBound.compareTo(other.upperBound) >= 0);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean isConnected(Range<C> other)
/* 251:    */   {
/* 252:539 */     return (this.lowerBound.compareTo(other.upperBound) <= 0) && (other.lowerBound.compareTo(this.upperBound) <= 0);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public Range<C> intersection(Range<C> connectedRange)
/* 256:    */   {
/* 257:560 */     int lowerCmp = this.lowerBound.compareTo(connectedRange.lowerBound);
/* 258:561 */     int upperCmp = this.upperBound.compareTo(connectedRange.upperBound);
/* 259:562 */     if ((lowerCmp >= 0) && (upperCmp <= 0)) {
/* 260:563 */       return this;
/* 261:    */     }
/* 262:564 */     if ((lowerCmp <= 0) && (upperCmp >= 0)) {
/* 263:565 */       return connectedRange;
/* 264:    */     }
/* 265:567 */     Cut<C> newLower = lowerCmp >= 0 ? this.lowerBound : connectedRange.lowerBound;
/* 266:568 */     Cut<C> newUpper = upperCmp <= 0 ? this.upperBound : connectedRange.upperBound;
/* 267:569 */     return create(newLower, newUpper);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public Range<C> span(Range<C> other)
/* 271:    */   {
/* 272:585 */     int lowerCmp = this.lowerBound.compareTo(other.lowerBound);
/* 273:586 */     int upperCmp = this.upperBound.compareTo(other.upperBound);
/* 274:587 */     if ((lowerCmp <= 0) && (upperCmp >= 0)) {
/* 275:588 */       return this;
/* 276:    */     }
/* 277:589 */     if ((lowerCmp >= 0) && (upperCmp <= 0)) {
/* 278:590 */       return other;
/* 279:    */     }
/* 280:592 */     Cut<C> newLower = lowerCmp <= 0 ? this.lowerBound : other.lowerBound;
/* 281:593 */     Cut<C> newUpper = upperCmp >= 0 ? this.upperBound : other.upperBound;
/* 282:594 */     return create(newLower, newUpper);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public Range<C> canonical(DiscreteDomain<C> domain)
/* 286:    */   {
/* 287:623 */     Preconditions.checkNotNull(domain);
/* 288:624 */     Cut<C> lower = this.lowerBound.canonical(domain);
/* 289:625 */     Cut<C> upper = this.upperBound.canonical(domain);
/* 290:626 */     return (lower == this.lowerBound) && (upper == this.upperBound) ? this : create(lower, upper);
/* 291:    */   }
/* 292:    */   
/* 293:    */   public boolean equals(@Nullable Object object)
/* 294:    */   {
/* 295:637 */     if ((object instanceof Range))
/* 296:    */     {
/* 297:638 */       Range<?> other = (Range)object;
/* 298:639 */       return (this.lowerBound.equals(other.lowerBound)) && (this.upperBound.equals(other.upperBound));
/* 299:    */     }
/* 300:642 */     return false;
/* 301:    */   }
/* 302:    */   
/* 303:    */   public int hashCode()
/* 304:    */   {
/* 305:647 */     return this.lowerBound.hashCode() * 31 + this.upperBound.hashCode();
/* 306:    */   }
/* 307:    */   
/* 308:    */   public String toString()
/* 309:    */   {
/* 310:655 */     return toString(this.lowerBound, this.upperBound);
/* 311:    */   }
/* 312:    */   
/* 313:    */   private static String toString(Cut<?> lowerBound, Cut<?> upperBound)
/* 314:    */   {
/* 315:659 */     StringBuilder sb = new StringBuilder(16);
/* 316:660 */     lowerBound.describeAsLowerBound(sb);
/* 317:661 */     sb.append('‥');
/* 318:662 */     upperBound.describeAsUpperBound(sb);
/* 319:663 */     return sb.toString();
/* 320:    */   }
/* 321:    */   
/* 322:    */   private static <T> SortedSet<T> cast(Iterable<T> iterable)
/* 323:    */   {
/* 324:670 */     return (SortedSet)iterable;
/* 325:    */   }
/* 326:    */   
/* 327:    */   Object readResolve()
/* 328:    */   {
/* 329:674 */     if (equals(ALL)) {
/* 330:675 */       return all();
/* 331:    */     }
/* 332:677 */     return this;
/* 333:    */   }
/* 334:    */   
/* 335:    */   static int compareOrThrow(Comparable left, Comparable right)
/* 336:    */   {
/* 337:683 */     return left.compareTo(right);
/* 338:    */   }
/* 339:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Range
 * JD-Core Version:    0.7.0.1
 */
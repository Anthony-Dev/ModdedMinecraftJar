/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Supplier;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.NoSuchElementException;
/*  13:    */ import java.util.Set;
/*  14:    */ import java.util.SortedMap;
/*  15:    */ import java.util.SortedSet;
/*  16:    */ import java.util.TreeMap;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(serializable=true)
/*  20:    */ @Beta
/*  21:    */ public class TreeBasedTable<R, C, V>
/*  22:    */   extends StandardRowSortedTable<R, C, V>
/*  23:    */ {
/*  24:    */   private final Comparator<? super C> columnComparator;
/*  25:    */   private static final long serialVersionUID = 0L;
/*  26:    */   
/*  27:    */   private static class Factory<C, V>
/*  28:    */     implements Supplier<TreeMap<C, V>>, Serializable
/*  29:    */   {
/*  30:    */     final Comparator<? super C> comparator;
/*  31:    */     private static final long serialVersionUID = 0L;
/*  32:    */     
/*  33:    */     Factory(Comparator<? super C> comparator)
/*  34:    */     {
/*  35: 86 */       this.comparator = comparator;
/*  36:    */     }
/*  37:    */     
/*  38:    */     public TreeMap<C, V> get()
/*  39:    */     {
/*  40: 90 */       return new TreeMap(this.comparator);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <R extends Comparable, C extends Comparable, V> TreeBasedTable<R, C, V> create()
/*  45:    */   {
/*  46:106 */     return new TreeBasedTable(Ordering.natural(), Ordering.natural());
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <R, C, V> TreeBasedTable<R, C, V> create(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*  50:    */   {
/*  51:120 */     Preconditions.checkNotNull(rowComparator);
/*  52:121 */     Preconditions.checkNotNull(columnComparator);
/*  53:122 */     return new TreeBasedTable(rowComparator, columnComparator);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <R, C, V> TreeBasedTable<R, C, V> create(TreeBasedTable<R, C, ? extends V> table)
/*  57:    */   {
/*  58:131 */     TreeBasedTable<R, C, V> result = new TreeBasedTable(table.rowComparator(), table.columnComparator());
/*  59:    */     
/*  60:    */ 
/*  61:134 */     result.putAll(table);
/*  62:135 */     return result;
/*  63:    */   }
/*  64:    */   
/*  65:    */   TreeBasedTable(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*  66:    */   {
/*  67:140 */     super(new TreeMap(rowComparator), new Factory(columnComparator));
/*  68:    */     
/*  69:142 */     this.columnComparator = columnComparator;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Comparator<? super R> rowComparator()
/*  73:    */   {
/*  74:152 */     return rowKeySet().comparator();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Comparator<? super C> columnComparator()
/*  78:    */   {
/*  79:160 */     return this.columnComparator;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public SortedMap<C, V> row(R rowKey)
/*  83:    */   {
/*  84:177 */     return new TreeRow(rowKey);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private class TreeRow
/*  88:    */     extends StandardTable<R, C, V>.Row
/*  89:    */     implements SortedMap<C, V>
/*  90:    */   {
/*  91:    */     @Nullable
/*  92:    */     final C lowerBound;
/*  93:    */     @Nullable
/*  94:    */     final C upperBound;
/*  95:    */     transient SortedMap<C, V> wholeRow;
/*  96:    */     
/*  97:    */     TreeRow()
/*  98:    */     {
/*  99:185 */       this(rowKey, null, null);
/* 100:    */     }
/* 101:    */     
/* 102:    */     TreeRow(@Nullable C rowKey, @Nullable C lowerBound)
/* 103:    */     {
/* 104:189 */       super(rowKey);
/* 105:190 */       this.lowerBound = lowerBound;
/* 106:191 */       this.upperBound = upperBound;
/* 107:192 */       Preconditions.checkArgument((lowerBound == null) || (upperBound == null) || (compare(lowerBound, upperBound) <= 0));
/* 108:    */     }
/* 109:    */     
/* 110:    */     public SortedSet<C> keySet()
/* 111:    */     {
/* 112:197 */       return new Maps.SortedKeySet(this);
/* 113:    */     }
/* 114:    */     
/* 115:    */     public Comparator<? super C> comparator()
/* 116:    */     {
/* 117:201 */       return TreeBasedTable.this.columnComparator();
/* 118:    */     }
/* 119:    */     
/* 120:    */     int compare(Object a, Object b)
/* 121:    */     {
/* 122:207 */       Comparator<Object> cmp = comparator();
/* 123:208 */       return cmp.compare(a, b);
/* 124:    */     }
/* 125:    */     
/* 126:    */     boolean rangeContains(@Nullable Object o)
/* 127:    */     {
/* 128:212 */       return (o != null) && ((this.lowerBound == null) || (compare(this.lowerBound, o) <= 0)) && ((this.upperBound == null) || (compare(this.upperBound, o) > 0));
/* 129:    */     }
/* 130:    */     
/* 131:    */     public SortedMap<C, V> subMap(C fromKey, C toKey)
/* 132:    */     {
/* 133:217 */       Preconditions.checkArgument((rangeContains(Preconditions.checkNotNull(fromKey))) && (rangeContains(Preconditions.checkNotNull(toKey))));
/* 134:    */       
/* 135:219 */       return new TreeRow(TreeBasedTable.this, this.rowKey, fromKey, toKey);
/* 136:    */     }
/* 137:    */     
/* 138:    */     public SortedMap<C, V> headMap(C toKey)
/* 139:    */     {
/* 140:223 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(toKey)));
/* 141:224 */       return new TreeRow(TreeBasedTable.this, this.rowKey, this.lowerBound, toKey);
/* 142:    */     }
/* 143:    */     
/* 144:    */     public SortedMap<C, V> tailMap(C fromKey)
/* 145:    */     {
/* 146:228 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(fromKey)));
/* 147:229 */       return new TreeRow(TreeBasedTable.this, this.rowKey, fromKey, this.upperBound);
/* 148:    */     }
/* 149:    */     
/* 150:    */     public C firstKey()
/* 151:    */     {
/* 152:233 */       SortedMap<C, V> backing = backingRowMap();
/* 153:234 */       if (backing == null) {
/* 154:235 */         throw new NoSuchElementException();
/* 155:    */       }
/* 156:237 */       return backingRowMap().firstKey();
/* 157:    */     }
/* 158:    */     
/* 159:    */     public C lastKey()
/* 160:    */     {
/* 161:241 */       SortedMap<C, V> backing = backingRowMap();
/* 162:242 */       if (backing == null) {
/* 163:243 */         throw new NoSuchElementException();
/* 164:    */       }
/* 165:245 */       return backingRowMap().lastKey();
/* 166:    */     }
/* 167:    */     
/* 168:    */     SortedMap<C, V> wholeRow()
/* 169:    */     {
/* 170:255 */       if ((this.wholeRow == null) || ((this.wholeRow.isEmpty()) && (TreeBasedTable.this.backingMap.containsKey(this.rowKey)))) {
/* 171:257 */         this.wholeRow = ((SortedMap)TreeBasedTable.this.backingMap.get(this.rowKey));
/* 172:    */       }
/* 173:259 */       return this.wholeRow;
/* 174:    */     }
/* 175:    */     
/* 176:    */     SortedMap<C, V> backingRowMap()
/* 177:    */     {
/* 178:264 */       return (SortedMap)super.backingRowMap();
/* 179:    */     }
/* 180:    */     
/* 181:    */     SortedMap<C, V> computeBackingRowMap()
/* 182:    */     {
/* 183:269 */       SortedMap<C, V> map = wholeRow();
/* 184:270 */       if (map != null)
/* 185:    */       {
/* 186:271 */         if (this.lowerBound != null) {
/* 187:272 */           map = map.tailMap(this.lowerBound);
/* 188:    */         }
/* 189:274 */         if (this.upperBound != null) {
/* 190:275 */           map = map.headMap(this.upperBound);
/* 191:    */         }
/* 192:277 */         return map;
/* 193:    */       }
/* 194:279 */       return null;
/* 195:    */     }
/* 196:    */     
/* 197:    */     void maintainEmptyInvariant()
/* 198:    */     {
/* 199:284 */       if ((wholeRow() != null) && (this.wholeRow.isEmpty()))
/* 200:    */       {
/* 201:285 */         TreeBasedTable.this.backingMap.remove(this.rowKey);
/* 202:286 */         this.wholeRow = null;
/* 203:287 */         this.backingRowMap = null;
/* 204:    */       }
/* 205:    */     }
/* 206:    */     
/* 207:    */     public boolean containsKey(Object key)
/* 208:    */     {
/* 209:292 */       return (rangeContains(key)) && (super.containsKey(key));
/* 210:    */     }
/* 211:    */     
/* 212:    */     public V put(C key, V value)
/* 213:    */     {
/* 214:296 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(key)));
/* 215:297 */       return super.put(key, value);
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   public SortedSet<R> rowKeySet()
/* 220:    */   {
/* 221:304 */     return super.rowKeySet();
/* 222:    */   }
/* 223:    */   
/* 224:    */   public SortedMap<R, Map<C, V>> rowMap()
/* 225:    */   {
/* 226:308 */     return super.rowMap();
/* 227:    */   }
/* 228:    */   
/* 229:    */   Iterator<C> createColumnKeyIterator()
/* 230:    */   {
/* 231:317 */     final Comparator<? super C> comparator = columnComparator();
/* 232:    */     
/* 233:319 */     final Iterator<C> merged = Iterators.mergeSorted(Iterables.transform(this.backingMap.values(), new Function()
/* 234:    */     {
/* 235:    */       public Iterator<C> apply(Map<C, V> input)
/* 236:    */       {
/* 237:324 */         return input.keySet().iterator();
/* 238:    */       }
/* 239:324 */     }), comparator);
/* 240:    */     
/* 241:    */ 
/* 242:    */ 
/* 243:328 */     new AbstractIterator()
/* 244:    */     {
/* 245:    */       C lastValue;
/* 246:    */       
/* 247:    */       protected C computeNext()
/* 248:    */       {
/* 249:333 */         while (merged.hasNext())
/* 250:    */         {
/* 251:334 */           C next = merged.next();
/* 252:335 */           boolean duplicate = (this.lastValue != null) && (comparator.compare(next, this.lastValue) == 0);
/* 253:339 */           if (!duplicate)
/* 254:    */           {
/* 255:340 */             this.lastValue = next;
/* 256:341 */             return this.lastValue;
/* 257:    */           }
/* 258:    */         }
/* 259:345 */         this.lastValue = null;
/* 260:346 */         return endOfData();
/* 261:    */       }
/* 262:    */     };
/* 263:    */   }
/* 264:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.TreeBasedTable
 * JD-Core Version:    0.7.0.1
 */
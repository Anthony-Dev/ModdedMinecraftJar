/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true)
/*  8:   */ class RegularImmutableMultiset<E>
/*  9:   */   extends ImmutableMultiset<E>
/* 10:   */ {
/* 11:   */   private final transient ImmutableMap<E, Integer> map;
/* 12:   */   private final transient int size;
/* 13:   */   
/* 14:   */   RegularImmutableMultiset(ImmutableMap<E, Integer> map, int size)
/* 15:   */   {
/* 16:39 */     this.map = map;
/* 17:40 */     this.size = size;
/* 18:   */   }
/* 19:   */   
/* 20:   */   boolean isPartialView()
/* 21:   */   {
/* 22:45 */     return this.map.isPartialView();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int count(@Nullable Object element)
/* 26:   */   {
/* 27:50 */     Integer value = (Integer)this.map.get(element);
/* 28:51 */     return value == null ? 0 : value.intValue();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int size()
/* 32:   */   {
/* 33:56 */     return this.size;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean contains(@Nullable Object element)
/* 37:   */   {
/* 38:61 */     return this.map.containsKey(element);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public ImmutableSet<E> elementSet()
/* 42:   */   {
/* 43:66 */     return this.map.keySet();
/* 44:   */   }
/* 45:   */   
/* 46:   */   Multiset.Entry<E> getEntry(int index)
/* 47:   */   {
/* 48:71 */     Map.Entry<E, Integer> mapEntry = (Map.Entry)this.map.entrySet().asList().get(index);
/* 49:72 */     return Multisets.immutableEntry(mapEntry.getKey(), ((Integer)mapEntry.getValue()).intValue());
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int hashCode()
/* 53:   */   {
/* 54:77 */     return this.map.hashCode();
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableMultiset
 * JD-Core Version:    0.7.0.1
 */
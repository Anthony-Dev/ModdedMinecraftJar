/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.ListIterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class ForwardingListIterator<E>
/*  8:   */   extends ForwardingIterator<E>
/*  9:   */   implements ListIterator<E>
/* 10:   */ {
/* 11:   */   protected abstract ListIterator<E> delegate();
/* 12:   */   
/* 13:   */   public void add(E element)
/* 14:   */   {
/* 15:43 */     delegate().add(element);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean hasPrevious()
/* 19:   */   {
/* 20:48 */     return delegate().hasPrevious();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int nextIndex()
/* 24:   */   {
/* 25:53 */     return delegate().nextIndex();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public E previous()
/* 29:   */   {
/* 30:58 */     return delegate().previous();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public int previousIndex()
/* 34:   */   {
/* 35:63 */     return delegate().previousIndex();
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void set(E element)
/* 39:   */   {
/* 40:68 */     delegate().set(element);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingListIterator
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ @GwtCompatible(serializable=true, emulated=true)
/*   8:    */ class RegularImmutableList<E>
/*   9:    */   extends ImmutableList<E>
/*  10:    */ {
/*  11:    */   private final transient int offset;
/*  12:    */   private final transient int size;
/*  13:    */   private final transient Object[] array;
/*  14:    */   
/*  15:    */   RegularImmutableList(Object[] array, int offset, int size)
/*  16:    */   {
/*  17: 37 */     this.offset = offset;
/*  18: 38 */     this.size = size;
/*  19: 39 */     this.array = array;
/*  20:    */   }
/*  21:    */   
/*  22:    */   RegularImmutableList(Object[] array)
/*  23:    */   {
/*  24: 43 */     this(array, 0, array.length);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public int size()
/*  28:    */   {
/*  29: 48 */     return this.size;
/*  30:    */   }
/*  31:    */   
/*  32:    */   boolean isPartialView()
/*  33:    */   {
/*  34: 52 */     return this.size != this.array.length;
/*  35:    */   }
/*  36:    */   
/*  37:    */   int copyIntoArray(Object[] dst, int dstOff)
/*  38:    */   {
/*  39: 57 */     System.arraycopy(this.array, this.offset, dst, dstOff, this.size);
/*  40: 58 */     return dstOff + this.size;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public E get(int index)
/*  44:    */   {
/*  45: 65 */     Preconditions.checkElementIndex(index, this.size);
/*  46: 66 */     return this.array[(index + this.offset)];
/*  47:    */   }
/*  48:    */   
/*  49:    */   public int indexOf(@Nullable Object object)
/*  50:    */   {
/*  51: 71 */     if (object == null) {
/*  52: 72 */       return -1;
/*  53:    */     }
/*  54: 74 */     for (int i = 0; i < this.size; i++) {
/*  55: 75 */       if (this.array[(this.offset + i)].equals(object)) {
/*  56: 76 */         return i;
/*  57:    */       }
/*  58:    */     }
/*  59: 79 */     return -1;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public int lastIndexOf(@Nullable Object object)
/*  63:    */   {
/*  64: 84 */     if (object == null) {
/*  65: 85 */       return -1;
/*  66:    */     }
/*  67: 87 */     for (int i = this.size - 1; i >= 0; i--) {
/*  68: 88 */       if (this.array[(this.offset + i)].equals(object)) {
/*  69: 89 */         return i;
/*  70:    */       }
/*  71:    */     }
/*  72: 92 */     return -1;
/*  73:    */   }
/*  74:    */   
/*  75:    */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/*  76:    */   {
/*  77: 97 */     return new RegularImmutableList(this.array, this.offset + fromIndex, toIndex - fromIndex);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public UnmodifiableListIterator<E> listIterator(int index)
/*  81:    */   {
/*  82:106 */     return Iterators.forArray(this.array, this.offset, this.size, index);
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableList
 * JD-Core Version:    0.7.0.1
 */
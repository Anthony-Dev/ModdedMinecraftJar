/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.RandomAccess;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ @Beta
/*  14:    */ final class SortedLists
/*  15:    */ {
/*  16:    */   public static abstract enum KeyPresentBehavior
/*  17:    */   {
/*  18: 53 */     ANY_PRESENT,  LAST_PRESENT,  FIRST_PRESENT,  FIRST_AFTER,  LAST_BEFORE;
/*  19:    */     
/*  20:    */     private KeyPresentBehavior() {}
/*  21:    */     
/*  22:    */     abstract <E> int resultIndex(Comparator<? super E> paramComparator, E paramE, List<? extends E> paramList, int paramInt);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static abstract enum KeyAbsentBehavior
/*  26:    */   {
/*  27:144 */     NEXT_LOWER,  NEXT_HIGHER,  INVERTED_INSERTION_INDEX;
/*  28:    */     
/*  29:    */     private KeyAbsentBehavior() {}
/*  30:    */     
/*  31:    */     abstract int resultIndex(int paramInt);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E extends Comparable> int binarySearch(List<? extends E> list, E e, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  35:    */   {
/*  36:191 */     Preconditions.checkNotNull(e);
/*  37:192 */     return binarySearch(list, Preconditions.checkNotNull(e), Ordering.natural(), presentBehavior, absentBehavior);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E, K extends Comparable> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  41:    */   {
/*  42:205 */     return binarySearch(list, keyFunction, key, Ordering.natural(), presentBehavior, absentBehavior);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <E, K> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key, Comparator<? super K> keyComparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  46:    */   {
/*  47:228 */     return binarySearch(Lists.transform(list, keyFunction), key, keyComparator, presentBehavior, absentBehavior);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static <E> int binarySearch(List<? extends E> list, @Nullable E key, Comparator<? super E> comparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  51:    */   {
/*  52:258 */     Preconditions.checkNotNull(comparator);
/*  53:259 */     Preconditions.checkNotNull(list);
/*  54:260 */     Preconditions.checkNotNull(presentBehavior);
/*  55:261 */     Preconditions.checkNotNull(absentBehavior);
/*  56:262 */     if (!(list instanceof RandomAccess)) {
/*  57:263 */       list = Lists.newArrayList(list);
/*  58:    */     }
/*  59:267 */     int lower = 0;
/*  60:268 */     int upper = list.size() - 1;
/*  61:270 */     while (lower <= upper)
/*  62:    */     {
/*  63:271 */       int middle = lower + upper >>> 1;
/*  64:272 */       int c = comparator.compare(key, list.get(middle));
/*  65:273 */       if (c < 0) {
/*  66:274 */         upper = middle - 1;
/*  67:275 */       } else if (c > 0) {
/*  68:276 */         lower = middle + 1;
/*  69:    */       } else {
/*  70:278 */         return lower + presentBehavior.resultIndex(comparator, key, list.subList(lower, upper + 1), middle - lower);
/*  71:    */       }
/*  72:    */     }
/*  73:282 */     return absentBehavior.resultIndex(lower);
/*  74:    */   }
/*  75:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SortedLists
 * JD-Core Version:    0.7.0.1
 */
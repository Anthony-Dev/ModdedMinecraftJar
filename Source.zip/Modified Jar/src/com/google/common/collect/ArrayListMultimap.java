/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Set;
/*  15:    */ 
/*  16:    */ @GwtCompatible(serializable=true, emulated=true)
/*  17:    */ public final class ArrayListMultimap<K, V>
/*  18:    */   extends AbstractListMultimap<K, V>
/*  19:    */ {
/*  20:    */   private static final int DEFAULT_VALUES_PER_KEY = 3;
/*  21:    */   @VisibleForTesting
/*  22:    */   transient int expectedValuesPerKey;
/*  23:    */   @GwtIncompatible("Not needed in emulated source.")
/*  24:    */   private static final long serialVersionUID = 0L;
/*  25:    */   
/*  26:    */   public static <K, V> ArrayListMultimap<K, V> create()
/*  27:    */   {
/*  28: 78 */     return new ArrayListMultimap();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <K, V> ArrayListMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  32:    */   {
/*  33: 92 */     return new ArrayListMultimap(expectedKeys, expectedValuesPerKey);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <K, V> ArrayListMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  37:    */   {
/*  38:103 */     return new ArrayListMultimap(multimap);
/*  39:    */   }
/*  40:    */   
/*  41:    */   private ArrayListMultimap()
/*  42:    */   {
/*  43:107 */     super(new HashMap());
/*  44:108 */     this.expectedValuesPerKey = 3;
/*  45:    */   }
/*  46:    */   
/*  47:    */   private ArrayListMultimap(int expectedKeys, int expectedValuesPerKey)
/*  48:    */   {
/*  49:112 */     super(Maps.newHashMapWithExpectedSize(expectedKeys));
/*  50:113 */     CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/*  51:114 */     this.expectedValuesPerKey = expectedValuesPerKey;
/*  52:    */   }
/*  53:    */   
/*  54:    */   private ArrayListMultimap(Multimap<? extends K, ? extends V> multimap)
/*  55:    */   {
/*  56:118 */     this(multimap.keySet().size(), (multimap instanceof ArrayListMultimap) ? ((ArrayListMultimap)multimap).expectedValuesPerKey : 3);
/*  57:    */     
/*  58:    */ 
/*  59:    */ 
/*  60:122 */     putAll(multimap);
/*  61:    */   }
/*  62:    */   
/*  63:    */   List<V> createCollection()
/*  64:    */   {
/*  65:130 */     return new ArrayList(this.expectedValuesPerKey);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void trimToSize()
/*  69:    */   {
/*  70:137 */     for (Collection<V> collection : backingMap().values())
/*  71:    */     {
/*  72:138 */       ArrayList<V> arrayList = (ArrayList)collection;
/*  73:139 */       arrayList.trimToSize();
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  78:    */   private void writeObject(ObjectOutputStream stream)
/*  79:    */     throws IOException
/*  80:    */   {
/*  81:150 */     stream.defaultWriteObject();
/*  82:151 */     stream.writeInt(this.expectedValuesPerKey);
/*  83:152 */     Serialization.writeMultimap(this, stream);
/*  84:    */   }
/*  85:    */   
/*  86:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  87:    */   private void readObject(ObjectInputStream stream)
/*  88:    */     throws IOException, ClassNotFoundException
/*  89:    */   {
/*  90:158 */     stream.defaultReadObject();
/*  91:159 */     this.expectedValuesPerKey = stream.readInt();
/*  92:160 */     int distinctKeys = Serialization.readCount(stream);
/*  93:161 */     Map<K, Collection<V>> map = Maps.newHashMapWithExpectedSize(distinctKeys);
/*  94:162 */     setMap(map);
/*  95:163 */     Serialization.populateMultimap(this, stream, distinctKeys);
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ArrayListMultimap
 * JD-Core Version:    0.7.0.1
 */
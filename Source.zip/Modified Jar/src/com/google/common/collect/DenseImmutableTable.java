/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ import javax.annotation.concurrent.Immutable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ @Immutable
/*  12:    */ final class DenseImmutableTable<R, C, V>
/*  13:    */   extends RegularImmutableTable<R, C, V>
/*  14:    */ {
/*  15:    */   private final ImmutableMap<R, Integer> rowKeyToIndex;
/*  16:    */   private final ImmutableMap<C, Integer> columnKeyToIndex;
/*  17:    */   private final ImmutableMap<R, Map<C, V>> rowMap;
/*  18:    */   private final ImmutableMap<C, Map<R, V>> columnMap;
/*  19:    */   private final int[] rowCounts;
/*  20:    */   private final int[] columnCounts;
/*  21:    */   private final V[][] values;
/*  22:    */   private final int[] iterationOrderRow;
/*  23:    */   private final int[] iterationOrderColumn;
/*  24:    */   
/*  25:    */   private static <E> ImmutableMap<E, Integer> makeIndex(ImmutableSet<E> set)
/*  26:    */   {
/*  27: 44 */     ImmutableMap.Builder<E, Integer> indexBuilder = ImmutableMap.builder();
/*  28: 45 */     int i = 0;
/*  29: 46 */     for (E key : set)
/*  30:    */     {
/*  31: 47 */       indexBuilder.put(key, Integer.valueOf(i));
/*  32: 48 */       i++;
/*  33:    */     }
/*  34: 50 */     return indexBuilder.build();
/*  35:    */   }
/*  36:    */   
/*  37:    */   DenseImmutableTable(ImmutableList<Table.Cell<R, C, V>> cellList, ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace)
/*  38:    */   {
/*  39: 56 */     V[][] array = (Object[][])new Object[rowSpace.size()][columnSpace.size()];
/*  40: 57 */     this.values = array;
/*  41: 58 */     this.rowKeyToIndex = makeIndex(rowSpace);
/*  42: 59 */     this.columnKeyToIndex = makeIndex(columnSpace);
/*  43: 60 */     this.rowCounts = new int[this.rowKeyToIndex.size()];
/*  44: 61 */     this.columnCounts = new int[this.columnKeyToIndex.size()];
/*  45: 62 */     int[] iterationOrderRow = new int[cellList.size()];
/*  46: 63 */     int[] iterationOrderColumn = new int[cellList.size()];
/*  47: 64 */     for (int i = 0; i < cellList.size(); i++)
/*  48:    */     {
/*  49: 65 */       Table.Cell<R, C, V> cell = (Table.Cell)cellList.get(i);
/*  50: 66 */       R rowKey = cell.getRowKey();
/*  51: 67 */       C columnKey = cell.getColumnKey();
/*  52: 68 */       int rowIndex = ((Integer)this.rowKeyToIndex.get(rowKey)).intValue();
/*  53: 69 */       int columnIndex = ((Integer)this.columnKeyToIndex.get(columnKey)).intValue();
/*  54: 70 */       V existingValue = this.values[rowIndex][columnIndex];
/*  55: 71 */       Preconditions.checkArgument(existingValue == null, "duplicate key: (%s, %s)", new Object[] { rowKey, columnKey });
/*  56: 72 */       this.values[rowIndex][columnIndex] = cell.getValue();
/*  57: 73 */       this.rowCounts[rowIndex] += 1;
/*  58: 74 */       this.columnCounts[columnIndex] += 1;
/*  59: 75 */       iterationOrderRow[i] = rowIndex;
/*  60: 76 */       iterationOrderColumn[i] = columnIndex;
/*  61:    */     }
/*  62: 78 */     this.iterationOrderRow = iterationOrderRow;
/*  63: 79 */     this.iterationOrderColumn = iterationOrderColumn;
/*  64: 80 */     this.rowMap = new RowMap(null);
/*  65: 81 */     this.columnMap = new ColumnMap(null);
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static abstract class ImmutableArrayMap<K, V>
/*  69:    */     extends ImmutableMap<K, V>
/*  70:    */   {
/*  71:    */     private final int size;
/*  72:    */     
/*  73:    */     ImmutableArrayMap(int size)
/*  74:    */     {
/*  75: 91 */       this.size = size;
/*  76:    */     }
/*  77:    */     
/*  78:    */     abstract ImmutableMap<K, Integer> keyToIndex();
/*  79:    */     
/*  80:    */     private boolean isFull()
/*  81:    */     {
/*  82: 98 */       return this.size == keyToIndex().size();
/*  83:    */     }
/*  84:    */     
/*  85:    */     K getKey(int index)
/*  86:    */     {
/*  87:102 */       return keyToIndex().keySet().asList().get(index);
/*  88:    */     }
/*  89:    */     
/*  90:    */     @Nullable
/*  91:    */     abstract V getValue(int paramInt);
/*  92:    */     
/*  93:    */     ImmutableSet<K> createKeySet()
/*  94:    */     {
/*  95:109 */       return isFull() ? keyToIndex().keySet() : super.createKeySet();
/*  96:    */     }
/*  97:    */     
/*  98:    */     public int size()
/*  99:    */     {
/* 100:114 */       return this.size;
/* 101:    */     }
/* 102:    */     
/* 103:    */     public V get(@Nullable Object key)
/* 104:    */     {
/* 105:119 */       Integer keyIndex = (Integer)keyToIndex().get(key);
/* 106:120 */       return keyIndex == null ? null : getValue(keyIndex.intValue());
/* 107:    */     }
/* 108:    */     
/* 109:    */     ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 110:    */     {
/* 111:125 */       new ImmutableMapEntrySet()
/* 112:    */       {
/* 113:    */         ImmutableMap<K, V> map()
/* 114:    */         {
/* 115:127 */           return DenseImmutableTable.ImmutableArrayMap.this;
/* 116:    */         }
/* 117:    */         
/* 118:    */         public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 119:    */         {
/* 120:132 */           new AbstractIterator()
/* 121:    */           {
/* 122:133 */             private int index = -1;
/* 123:134 */             private final int maxIndex = DenseImmutableTable.ImmutableArrayMap.this.keyToIndex().size();
/* 124:    */             
/* 125:    */             protected Map.Entry<K, V> computeNext()
/* 126:    */             {
/* 127:138 */               for (this.index += 1; this.index < this.maxIndex; this.index += 1)
/* 128:    */               {
/* 129:139 */                 V value = DenseImmutableTable.ImmutableArrayMap.this.getValue(this.index);
/* 130:140 */                 if (value != null) {
/* 131:141 */                   return Maps.immutableEntry(DenseImmutableTable.ImmutableArrayMap.this.getKey(this.index), value);
/* 132:    */                 }
/* 133:    */               }
/* 134:144 */               return (Map.Entry)endOfData();
/* 135:    */             }
/* 136:    */           };
/* 137:    */         }
/* 138:    */       };
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   private final class Row
/* 143:    */     extends DenseImmutableTable.ImmutableArrayMap<C, V>
/* 144:    */   {
/* 145:    */     private final int rowIndex;
/* 146:    */     
/* 147:    */     Row(int rowIndex)
/* 148:    */     {
/* 149:156 */       super();
/* 150:157 */       this.rowIndex = rowIndex;
/* 151:    */     }
/* 152:    */     
/* 153:    */     ImmutableMap<C, Integer> keyToIndex()
/* 154:    */     {
/* 155:162 */       return DenseImmutableTable.this.columnKeyToIndex;
/* 156:    */     }
/* 157:    */     
/* 158:    */     V getValue(int keyIndex)
/* 159:    */     {
/* 160:167 */       return DenseImmutableTable.this.values[this.rowIndex][keyIndex];
/* 161:    */     }
/* 162:    */     
/* 163:    */     boolean isPartialView()
/* 164:    */     {
/* 165:172 */       return true;
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */   private final class Column
/* 170:    */     extends DenseImmutableTable.ImmutableArrayMap<R, V>
/* 171:    */   {
/* 172:    */     private final int columnIndex;
/* 173:    */     
/* 174:    */     Column(int columnIndex)
/* 175:    */     {
/* 176:180 */       super();
/* 177:181 */       this.columnIndex = columnIndex;
/* 178:    */     }
/* 179:    */     
/* 180:    */     ImmutableMap<R, Integer> keyToIndex()
/* 181:    */     {
/* 182:186 */       return DenseImmutableTable.this.rowKeyToIndex;
/* 183:    */     }
/* 184:    */     
/* 185:    */     V getValue(int keyIndex)
/* 186:    */     {
/* 187:191 */       return DenseImmutableTable.this.values[keyIndex][this.columnIndex];
/* 188:    */     }
/* 189:    */     
/* 190:    */     boolean isPartialView()
/* 191:    */     {
/* 192:196 */       return true;
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   private final class RowMap
/* 197:    */     extends DenseImmutableTable.ImmutableArrayMap<R, Map<C, V>>
/* 198:    */   {
/* 199:    */     private RowMap()
/* 200:    */     {
/* 201:202 */       super();
/* 202:    */     }
/* 203:    */     
/* 204:    */     ImmutableMap<R, Integer> keyToIndex()
/* 205:    */     {
/* 206:207 */       return DenseImmutableTable.this.rowKeyToIndex;
/* 207:    */     }
/* 208:    */     
/* 209:    */     Map<C, V> getValue(int keyIndex)
/* 210:    */     {
/* 211:212 */       return new DenseImmutableTable.Row(DenseImmutableTable.this, keyIndex);
/* 212:    */     }
/* 213:    */     
/* 214:    */     boolean isPartialView()
/* 215:    */     {
/* 216:217 */       return false;
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   private final class ColumnMap
/* 221:    */     extends DenseImmutableTable.ImmutableArrayMap<C, Map<R, V>>
/* 222:    */   {
/* 223:    */     private ColumnMap()
/* 224:    */     {
/* 225:223 */       super();
/* 226:    */     }
/* 227:    */     
/* 228:    */     ImmutableMap<C, Integer> keyToIndex()
/* 229:    */     {
/* 230:228 */       return DenseImmutableTable.this.columnKeyToIndex;
/* 231:    */     }
/* 232:    */     
/* 233:    */     Map<R, V> getValue(int keyIndex)
/* 234:    */     {
/* 235:233 */       return new DenseImmutableTable.Column(DenseImmutableTable.this, keyIndex);
/* 236:    */     }
/* 237:    */     
/* 238:    */     boolean isPartialView()
/* 239:    */     {
/* 240:238 */       return false;
/* 241:    */     }
/* 242:    */   }
/* 243:    */   
/* 244:    */   public ImmutableMap<C, Map<R, V>> columnMap()
/* 245:    */   {
/* 246:243 */     return this.columnMap;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public ImmutableMap<R, Map<C, V>> rowMap()
/* 250:    */   {
/* 251:248 */     return this.rowMap;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/* 255:    */   {
/* 256:253 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 257:254 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 258:255 */     return (rowIndex == null) || (columnIndex == null) ? null : this.values[rowIndex.intValue()][columnIndex.intValue()];
/* 259:    */   }
/* 260:    */   
/* 261:    */   public int size()
/* 262:    */   {
/* 263:261 */     return this.iterationOrderRow.length;
/* 264:    */   }
/* 265:    */   
/* 266:    */   Table.Cell<R, C, V> getCell(int index)
/* 267:    */   {
/* 268:266 */     int rowIndex = this.iterationOrderRow[index];
/* 269:267 */     int columnIndex = this.iterationOrderColumn[index];
/* 270:268 */     R rowKey = rowKeySet().asList().get(rowIndex);
/* 271:269 */     C columnKey = columnKeySet().asList().get(columnIndex);
/* 272:270 */     V value = this.values[rowIndex][columnIndex];
/* 273:271 */     return cellOf(rowKey, columnKey, value);
/* 274:    */   }
/* 275:    */   
/* 276:    */   V getValue(int index)
/* 277:    */   {
/* 278:276 */     return this.values[this.iterationOrderRow[index]][this.iterationOrderColumn[index]];
/* 279:    */   }
/* 280:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.DenseImmutableTable
 * JD-Core Version:    0.7.0.1
 */
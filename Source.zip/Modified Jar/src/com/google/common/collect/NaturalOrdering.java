/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.Serializable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true)
/*  8:   */ final class NaturalOrdering
/*  9:   */   extends Ordering<Comparable>
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:30 */   static final NaturalOrdering INSTANCE = new NaturalOrdering();
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   public int compare(Comparable left, Comparable right)
/* 16:   */   {
/* 17:33 */     Preconditions.checkNotNull(left);
/* 18:34 */     Preconditions.checkNotNull(right);
/* 19:35 */     return left.compareTo(right);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public <S extends Comparable> Ordering<S> reverse()
/* 23:   */   {
/* 24:39 */     return ReverseNaturalOrdering.INSTANCE;
/* 25:   */   }
/* 26:   */   
/* 27:   */   private Object readResolve()
/* 28:   */   {
/* 29:44 */     return INSTANCE;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:48 */     return "Ordering.natural()";
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.NaturalOrdering
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ public abstract class ForwardingMultimap<K, V>
/*  12:    */   extends ForwardingObject
/*  13:    */   implements Multimap<K, V>
/*  14:    */ {
/*  15:    */   protected abstract Multimap<K, V> delegate();
/*  16:    */   
/*  17:    */   public Map<K, Collection<V>> asMap()
/*  18:    */   {
/*  19: 48 */     return delegate().asMap();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void clear()
/*  23:    */   {
/*  24: 53 */     delegate().clear();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public boolean containsEntry(@Nullable Object key, @Nullable Object value)
/*  28:    */   {
/*  29: 58 */     return delegate().containsEntry(key, value);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public boolean containsKey(@Nullable Object key)
/*  33:    */   {
/*  34: 63 */     return delegate().containsKey(key);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean containsValue(@Nullable Object value)
/*  38:    */   {
/*  39: 68 */     return delegate().containsValue(value);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Collection<Map.Entry<K, V>> entries()
/*  43:    */   {
/*  44: 73 */     return delegate().entries();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Collection<V> get(@Nullable K key)
/*  48:    */   {
/*  49: 78 */     return delegate().get(key);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isEmpty()
/*  53:    */   {
/*  54: 83 */     return delegate().isEmpty();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Multiset<K> keys()
/*  58:    */   {
/*  59: 88 */     return delegate().keys();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Set<K> keySet()
/*  63:    */   {
/*  64: 93 */     return delegate().keySet();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean put(K key, V value)
/*  68:    */   {
/*  69: 98 */     return delegate().put(key, value);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean putAll(K key, Iterable<? extends V> values)
/*  73:    */   {
/*  74:103 */     return delegate().putAll(key, values);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  78:    */   {
/*  79:108 */     return delegate().putAll(multimap);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean remove(@Nullable Object key, @Nullable Object value)
/*  83:    */   {
/*  84:113 */     return delegate().remove(key, value);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Collection<V> removeAll(@Nullable Object key)
/*  88:    */   {
/*  89:118 */     return delegate().removeAll(key);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*  93:    */   {
/*  94:123 */     return delegate().replaceValues(key, values);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int size()
/*  98:    */   {
/*  99:128 */     return delegate().size();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Collection<V> values()
/* 103:    */   {
/* 104:133 */     return delegate().values();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean equals(@Nullable Object object)
/* 108:    */   {
/* 109:137 */     return (object == this) || (delegate().equals(object));
/* 110:    */   }
/* 111:    */   
/* 112:    */   public int hashCode()
/* 113:    */   {
/* 114:141 */     return delegate().hashCode();
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingMultimap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.lang.reflect.Array;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.Set;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ @GwtCompatible(emulated=true)
/*  21:    */ public final class ArrayTable<R, C, V>
/*  22:    */   extends AbstractTable<R, C, V>
/*  23:    */   implements Serializable
/*  24:    */ {
/*  25:    */   private final ImmutableList<R> rowList;
/*  26:    */   private final ImmutableList<C> columnList;
/*  27:    */   private final ImmutableMap<R, Integer> rowKeyToIndex;
/*  28:    */   private final ImmutableMap<C, Integer> columnKeyToIndex;
/*  29:    */   private final V[][] array;
/*  30:    */   private transient ArrayTable<R, C, V>.ColumnMap columnMap;
/*  31:    */   private transient ArrayTable<R, C, V>.RowMap rowMap;
/*  32:    */   private static final long serialVersionUID = 0L;
/*  33:    */   
/*  34:    */   public static <R, C, V> ArrayTable<R, C, V> create(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*  35:    */   {
/*  36: 99 */     return new ArrayTable(rowKeys, columnKeys);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <R, C, V> ArrayTable<R, C, V> create(Table<R, C, V> table)
/*  40:    */   {
/*  41:131 */     return (table instanceof ArrayTable) ? new ArrayTable((ArrayTable)table) : new ArrayTable(table);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private ArrayTable(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*  45:    */   {
/*  46:146 */     this.rowList = ImmutableList.copyOf(rowKeys);
/*  47:147 */     this.columnList = ImmutableList.copyOf(columnKeys);
/*  48:148 */     Preconditions.checkArgument(!this.rowList.isEmpty());
/*  49:149 */     Preconditions.checkArgument(!this.columnList.isEmpty());
/*  50:    */     
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:156 */     this.rowKeyToIndex = index(this.rowList);
/*  57:157 */     this.columnKeyToIndex = index(this.columnList);
/*  58:    */     
/*  59:    */ 
/*  60:160 */     V[][] tmpArray = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/*  61:    */     
/*  62:162 */     this.array = tmpArray;
/*  63:    */     
/*  64:164 */     eraseAll();
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static <E> ImmutableMap<E, Integer> index(List<E> list)
/*  68:    */   {
/*  69:168 */     ImmutableMap.Builder<E, Integer> columnBuilder = ImmutableMap.builder();
/*  70:169 */     for (int i = 0; i < list.size(); i++) {
/*  71:170 */       columnBuilder.put(list.get(i), Integer.valueOf(i));
/*  72:    */     }
/*  73:172 */     return columnBuilder.build();
/*  74:    */   }
/*  75:    */   
/*  76:    */   private ArrayTable(Table<R, C, V> table)
/*  77:    */   {
/*  78:176 */     this(table.rowKeySet(), table.columnKeySet());
/*  79:177 */     putAll(table);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private ArrayTable(ArrayTable<R, C, V> table)
/*  83:    */   {
/*  84:181 */     this.rowList = table.rowList;
/*  85:182 */     this.columnList = table.columnList;
/*  86:183 */     this.rowKeyToIndex = table.rowKeyToIndex;
/*  87:184 */     this.columnKeyToIndex = table.columnKeyToIndex;
/*  88:    */     
/*  89:186 */     V[][] copy = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/*  90:187 */     this.array = copy;
/*  91:    */     
/*  92:189 */     eraseAll();
/*  93:190 */     for (int i = 0; i < this.rowList.size(); i++) {
/*  94:191 */       System.arraycopy(table.array[i], 0, copy[i], 0, table.array[i].length);
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   private static abstract class ArrayMap<K, V>
/*  99:    */     extends Maps.ImprovedAbstractMap<K, V>
/* 100:    */   {
/* 101:    */     private final ImmutableMap<K, Integer> keyIndex;
/* 102:    */     
/* 103:    */     private ArrayMap(ImmutableMap<K, Integer> keyIndex)
/* 104:    */     {
/* 105:199 */       this.keyIndex = keyIndex;
/* 106:    */     }
/* 107:    */     
/* 108:    */     public Set<K> keySet()
/* 109:    */     {
/* 110:204 */       return this.keyIndex.keySet();
/* 111:    */     }
/* 112:    */     
/* 113:    */     K getKey(int index)
/* 114:    */     {
/* 115:208 */       return this.keyIndex.keySet().asList().get(index);
/* 116:    */     }
/* 117:    */     
/* 118:    */     abstract String getKeyRole();
/* 119:    */     
/* 120:    */     @Nullable
/* 121:    */     abstract V getValue(int paramInt);
/* 122:    */     
/* 123:    */     @Nullable
/* 124:    */     abstract V setValue(int paramInt, V paramV);
/* 125:    */     
/* 126:    */     public int size()
/* 127:    */     {
/* 128:219 */       return this.keyIndex.size();
/* 129:    */     }
/* 130:    */     
/* 131:    */     public boolean isEmpty()
/* 132:    */     {
/* 133:224 */       return this.keyIndex.isEmpty();
/* 134:    */     }
/* 135:    */     
/* 136:    */     protected Set<Map.Entry<K, V>> createEntrySet()
/* 137:    */     {
/* 138:229 */       new Maps.EntrySet()
/* 139:    */       {
/* 140:    */         Map<K, V> map()
/* 141:    */         {
/* 142:232 */           return ArrayTable.ArrayMap.this;
/* 143:    */         }
/* 144:    */         
/* 145:    */         public Iterator<Map.Entry<K, V>> iterator()
/* 146:    */         {
/* 147:237 */           new AbstractIndexedListIterator(size())
/* 148:    */           {
/* 149:    */             protected Map.Entry<K, V> get(final int index)
/* 150:    */             {
/* 151:240 */               new AbstractMapEntry()
/* 152:    */               {
/* 153:    */                 public K getKey()
/* 154:    */                 {
/* 155:243 */                   return ArrayTable.ArrayMap.this.getKey(index);
/* 156:    */                 }
/* 157:    */                 
/* 158:    */                 public V getValue()
/* 159:    */                 {
/* 160:248 */                   return ArrayTable.ArrayMap.this.getValue(index);
/* 161:    */                 }
/* 162:    */                 
/* 163:    */                 public V setValue(V value)
/* 164:    */                 {
/* 165:253 */                   return ArrayTable.ArrayMap.this.setValue(index, value);
/* 166:    */                 }
/* 167:    */               };
/* 168:    */             }
/* 169:    */           };
/* 170:    */         }
/* 171:    */       };
/* 172:    */     }
/* 173:    */     
/* 174:    */     public boolean containsKey(@Nullable Object key)
/* 175:    */     {
/* 176:266 */       return this.keyIndex.containsKey(key);
/* 177:    */     }
/* 178:    */     
/* 179:    */     public V get(@Nullable Object key)
/* 180:    */     {
/* 181:271 */       Integer index = (Integer)this.keyIndex.get(key);
/* 182:272 */       if (index == null) {
/* 183:273 */         return null;
/* 184:    */       }
/* 185:275 */       return getValue(index.intValue());
/* 186:    */     }
/* 187:    */     
/* 188:    */     public V put(K key, V value)
/* 189:    */     {
/* 190:281 */       Integer index = (Integer)this.keyIndex.get(key);
/* 191:282 */       if (index == null) {
/* 192:283 */         throw new IllegalArgumentException(getKeyRole() + " " + key + " not in " + this.keyIndex.keySet());
/* 193:    */       }
/* 194:286 */       return setValue(index.intValue(), value);
/* 195:    */     }
/* 196:    */     
/* 197:    */     public V remove(Object key)
/* 198:    */     {
/* 199:291 */       throw new UnsupportedOperationException();
/* 200:    */     }
/* 201:    */     
/* 202:    */     public void clear()
/* 203:    */     {
/* 204:296 */       throw new UnsupportedOperationException();
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public ImmutableList<R> rowKeyList()
/* 209:    */   {
/* 210:305 */     return this.rowList;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public ImmutableList<C> columnKeyList()
/* 214:    */   {
/* 215:313 */     return this.columnList;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public V at(int rowIndex, int columnIndex)
/* 219:    */   {
/* 220:332 */     Preconditions.checkElementIndex(rowIndex, this.rowList.size());
/* 221:333 */     Preconditions.checkElementIndex(columnIndex, this.columnList.size());
/* 222:334 */     return this.array[rowIndex][columnIndex];
/* 223:    */   }
/* 224:    */   
/* 225:    */   public V set(int rowIndex, int columnIndex, @Nullable V value)
/* 226:    */   {
/* 227:354 */     Preconditions.checkElementIndex(rowIndex, this.rowList.size());
/* 228:355 */     Preconditions.checkElementIndex(columnIndex, this.columnList.size());
/* 229:356 */     V oldValue = this.array[rowIndex][columnIndex];
/* 230:357 */     this.array[rowIndex][columnIndex] = value;
/* 231:358 */     return oldValue;
/* 232:    */   }
/* 233:    */   
/* 234:    */   @GwtIncompatible("reflection")
/* 235:    */   public V[][] toArray(Class<V> valueClass)
/* 236:    */   {
/* 237:375 */     V[][] copy = (Object[][])Array.newInstance(valueClass, new int[] { this.rowList.size(), this.columnList.size() });
/* 238:377 */     for (int i = 0; i < this.rowList.size(); i++) {
/* 239:378 */       System.arraycopy(this.array[i], 0, copy[i], 0, this.array[i].length);
/* 240:    */     }
/* 241:380 */     return copy;
/* 242:    */   }
/* 243:    */   
/* 244:    */   @Deprecated
/* 245:    */   public void clear()
/* 246:    */   {
/* 247:391 */     throw new UnsupportedOperationException();
/* 248:    */   }
/* 249:    */   
/* 250:    */   public void eraseAll()
/* 251:    */   {
/* 252:399 */     for (V[] row : this.array) {
/* 253:400 */       Arrays.fill(row, null);
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/* 258:    */   {
/* 259:410 */     return (containsRow(rowKey)) && (containsColumn(columnKey));
/* 260:    */   }
/* 261:    */   
/* 262:    */   public boolean containsColumn(@Nullable Object columnKey)
/* 263:    */   {
/* 264:419 */     return this.columnKeyToIndex.containsKey(columnKey);
/* 265:    */   }
/* 266:    */   
/* 267:    */   public boolean containsRow(@Nullable Object rowKey)
/* 268:    */   {
/* 269:428 */     return this.rowKeyToIndex.containsKey(rowKey);
/* 270:    */   }
/* 271:    */   
/* 272:    */   public boolean containsValue(@Nullable Object value)
/* 273:    */   {
/* 274:433 */     for (V[] row : this.array) {
/* 275:434 */       for (V element : row) {
/* 276:435 */         if (Objects.equal(value, element)) {
/* 277:436 */           return true;
/* 278:    */         }
/* 279:    */       }
/* 280:    */     }
/* 281:440 */     return false;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/* 285:    */   {
/* 286:445 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 287:446 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 288:447 */     return (rowIndex == null) || (columnIndex == null) ? null : at(rowIndex.intValue(), columnIndex.intValue());
/* 289:    */   }
/* 290:    */   
/* 291:    */   public boolean isEmpty()
/* 292:    */   {
/* 293:456 */     return false;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public V put(R rowKey, C columnKey, @Nullable V value)
/* 297:    */   {
/* 298:467 */     Preconditions.checkNotNull(rowKey);
/* 299:468 */     Preconditions.checkNotNull(columnKey);
/* 300:469 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 301:470 */     Preconditions.checkArgument(rowIndex != null, "Row %s not in %s", new Object[] { rowKey, this.rowList });
/* 302:471 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 303:472 */     Preconditions.checkArgument(columnIndex != null, "Column %s not in %s", new Object[] { columnKey, this.columnList });
/* 304:    */     
/* 305:474 */     return set(rowIndex.intValue(), columnIndex.intValue(), value);
/* 306:    */   }
/* 307:    */   
/* 308:    */   public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 309:    */   {
/* 310:495 */     super.putAll(table);
/* 311:    */   }
/* 312:    */   
/* 313:    */   @Deprecated
/* 314:    */   public V remove(Object rowKey, Object columnKey)
/* 315:    */   {
/* 316:506 */     throw new UnsupportedOperationException();
/* 317:    */   }
/* 318:    */   
/* 319:    */   public V erase(@Nullable Object rowKey, @Nullable Object columnKey)
/* 320:    */   {
/* 321:523 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 322:524 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 323:525 */     if ((rowIndex == null) || (columnIndex == null)) {
/* 324:526 */       return null;
/* 325:    */     }
/* 326:528 */     return set(rowIndex.intValue(), columnIndex.intValue(), null);
/* 327:    */   }
/* 328:    */   
/* 329:    */   public int size()
/* 330:    */   {
/* 331:535 */     return this.rowList.size() * this.columnList.size();
/* 332:    */   }
/* 333:    */   
/* 334:    */   public Set<Table.Cell<R, C, V>> cellSet()
/* 335:    */   {
/* 336:553 */     return super.cellSet();
/* 337:    */   }
/* 338:    */   
/* 339:    */   Iterator<Table.Cell<R, C, V>> cellIterator()
/* 340:    */   {
/* 341:558 */     new AbstractIndexedListIterator(size())
/* 342:    */     {
/* 343:    */       protected Table.Cell<R, C, V> get(final int index)
/* 344:    */       {
/* 345:560 */         new Tables.AbstractCell()
/* 346:    */         {
/* 347:561 */           final int rowIndex = index / ArrayTable.this.columnList.size();
/* 348:562 */           final int columnIndex = index % ArrayTable.this.columnList.size();
/* 349:    */           
/* 350:    */           public R getRowKey()
/* 351:    */           {
/* 352:565 */             return ArrayTable.this.rowList.get(this.rowIndex);
/* 353:    */           }
/* 354:    */           
/* 355:    */           public C getColumnKey()
/* 356:    */           {
/* 357:569 */             return ArrayTable.this.columnList.get(this.columnIndex);
/* 358:    */           }
/* 359:    */           
/* 360:    */           public V getValue()
/* 361:    */           {
/* 362:573 */             return ArrayTable.this.at(this.rowIndex, this.columnIndex);
/* 363:    */           }
/* 364:    */         };
/* 365:    */       }
/* 366:    */     };
/* 367:    */   }
/* 368:    */   
/* 369:    */   public Map<R, V> column(C columnKey)
/* 370:    */   {
/* 371:594 */     Preconditions.checkNotNull(columnKey);
/* 372:595 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 373:596 */     return columnIndex == null ? ImmutableMap.of() : new Column(columnIndex.intValue());
/* 374:    */   }
/* 375:    */   
/* 376:    */   private class Column
/* 377:    */     extends ArrayTable.ArrayMap<R, V>
/* 378:    */   {
/* 379:    */     final int columnIndex;
/* 380:    */     
/* 381:    */     Column(int columnIndex)
/* 382:    */     {
/* 383:604 */       super(null);
/* 384:605 */       this.columnIndex = columnIndex;
/* 385:    */     }
/* 386:    */     
/* 387:    */     String getKeyRole()
/* 388:    */     {
/* 389:610 */       return "Row";
/* 390:    */     }
/* 391:    */     
/* 392:    */     V getValue(int index)
/* 393:    */     {
/* 394:615 */       return ArrayTable.this.at(index, this.columnIndex);
/* 395:    */     }
/* 396:    */     
/* 397:    */     V setValue(int index, V newValue)
/* 398:    */     {
/* 399:620 */       return ArrayTable.this.set(index, this.columnIndex, newValue);
/* 400:    */     }
/* 401:    */   }
/* 402:    */   
/* 403:    */   public ImmutableSet<C> columnKeySet()
/* 404:    */   {
/* 405:632 */     return this.columnKeyToIndex.keySet();
/* 406:    */   }
/* 407:    */   
/* 408:    */   public Map<C, Map<R, V>> columnMap()
/* 409:    */   {
/* 410:639 */     ArrayTable<R, C, V>.ColumnMap map = this.columnMap;
/* 411:640 */     return map == null ? (this.columnMap = new ColumnMap(null)) : map;
/* 412:    */   }
/* 413:    */   
/* 414:    */   private class ColumnMap
/* 415:    */     extends ArrayTable.ArrayMap<C, Map<R, V>>
/* 416:    */   {
/* 417:    */     private ColumnMap()
/* 418:    */     {
/* 419:645 */       super(null);
/* 420:    */     }
/* 421:    */     
/* 422:    */     String getKeyRole()
/* 423:    */     {
/* 424:650 */       return "Column";
/* 425:    */     }
/* 426:    */     
/* 427:    */     Map<R, V> getValue(int index)
/* 428:    */     {
/* 429:655 */       return new ArrayTable.Column(ArrayTable.this, index);
/* 430:    */     }
/* 431:    */     
/* 432:    */     Map<R, V> setValue(int index, Map<R, V> newValue)
/* 433:    */     {
/* 434:660 */       throw new UnsupportedOperationException();
/* 435:    */     }
/* 436:    */     
/* 437:    */     public Map<R, V> put(C key, Map<R, V> value)
/* 438:    */     {
/* 439:665 */       throw new UnsupportedOperationException();
/* 440:    */     }
/* 441:    */   }
/* 442:    */   
/* 443:    */   public Map<C, V> row(R rowKey)
/* 444:    */   {
/* 445:684 */     Preconditions.checkNotNull(rowKey);
/* 446:685 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 447:686 */     return rowIndex == null ? ImmutableMap.of() : new Row(rowIndex.intValue());
/* 448:    */   }
/* 449:    */   
/* 450:    */   private class Row
/* 451:    */     extends ArrayTable.ArrayMap<C, V>
/* 452:    */   {
/* 453:    */     final int rowIndex;
/* 454:    */     
/* 455:    */     Row(int rowIndex)
/* 456:    */     {
/* 457:693 */       super(null);
/* 458:694 */       this.rowIndex = rowIndex;
/* 459:    */     }
/* 460:    */     
/* 461:    */     String getKeyRole()
/* 462:    */     {
/* 463:699 */       return "Column";
/* 464:    */     }
/* 465:    */     
/* 466:    */     V getValue(int index)
/* 467:    */     {
/* 468:704 */       return ArrayTable.this.at(this.rowIndex, index);
/* 469:    */     }
/* 470:    */     
/* 471:    */     V setValue(int index, V newValue)
/* 472:    */     {
/* 473:709 */       return ArrayTable.this.set(this.rowIndex, index, newValue);
/* 474:    */     }
/* 475:    */   }
/* 476:    */   
/* 477:    */   public ImmutableSet<R> rowKeySet()
/* 478:    */   {
/* 479:721 */     return this.rowKeyToIndex.keySet();
/* 480:    */   }
/* 481:    */   
/* 482:    */   public Map<R, Map<C, V>> rowMap()
/* 483:    */   {
/* 484:728 */     ArrayTable<R, C, V>.RowMap map = this.rowMap;
/* 485:729 */     return map == null ? (this.rowMap = new RowMap(null)) : map;
/* 486:    */   }
/* 487:    */   
/* 488:    */   private class RowMap
/* 489:    */     extends ArrayTable.ArrayMap<R, Map<C, V>>
/* 490:    */   {
/* 491:    */     private RowMap()
/* 492:    */     {
/* 493:734 */       super(null);
/* 494:    */     }
/* 495:    */     
/* 496:    */     String getKeyRole()
/* 497:    */     {
/* 498:739 */       return "Row";
/* 499:    */     }
/* 500:    */     
/* 501:    */     Map<C, V> getValue(int index)
/* 502:    */     {
/* 503:744 */       return new ArrayTable.Row(ArrayTable.this, index);
/* 504:    */     }
/* 505:    */     
/* 506:    */     Map<C, V> setValue(int index, Map<C, V> newValue)
/* 507:    */     {
/* 508:749 */       throw new UnsupportedOperationException();
/* 509:    */     }
/* 510:    */     
/* 511:    */     public Map<C, V> put(R key, Map<C, V> value)
/* 512:    */     {
/* 513:754 */       throw new UnsupportedOperationException();
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   public Collection<V> values()
/* 518:    */   {
/* 519:769 */     return super.values();
/* 520:    */   }
/* 521:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ArrayTable
 * JD-Core Version:    0.7.0.1
 */
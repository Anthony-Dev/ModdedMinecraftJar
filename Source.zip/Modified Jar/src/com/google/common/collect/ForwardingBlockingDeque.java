/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.concurrent.BlockingDeque;
/*   5:    */ import java.util.concurrent.TimeUnit;
/*   6:    */ 
/*   7:    */ public abstract class ForwardingBlockingDeque<E>
/*   8:    */   extends ForwardingDeque<E>
/*   9:    */   implements BlockingDeque<E>
/*  10:    */ {
/*  11:    */   protected abstract BlockingDeque<E> delegate();
/*  12:    */   
/*  13:    */   public int remainingCapacity()
/*  14:    */   {
/*  15: 51 */     return delegate().remainingCapacity();
/*  16:    */   }
/*  17:    */   
/*  18:    */   public void putFirst(E e)
/*  19:    */     throws InterruptedException
/*  20:    */   {
/*  21: 56 */     delegate().putFirst(e);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void putLast(E e)
/*  25:    */     throws InterruptedException
/*  26:    */   {
/*  27: 61 */     delegate().putLast(e);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean offerFirst(E e, long timeout, TimeUnit unit)
/*  31:    */     throws InterruptedException
/*  32:    */   {
/*  33: 66 */     return delegate().offerFirst(e, timeout, unit);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean offerLast(E e, long timeout, TimeUnit unit)
/*  37:    */     throws InterruptedException
/*  38:    */   {
/*  39: 71 */     return delegate().offerLast(e, timeout, unit);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public E takeFirst()
/*  43:    */     throws InterruptedException
/*  44:    */   {
/*  45: 76 */     return delegate().takeFirst();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public E takeLast()
/*  49:    */     throws InterruptedException
/*  50:    */   {
/*  51: 81 */     return delegate().takeLast();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public E pollFirst(long timeout, TimeUnit unit)
/*  55:    */     throws InterruptedException
/*  56:    */   {
/*  57: 86 */     return delegate().pollFirst(timeout, unit);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public E pollLast(long timeout, TimeUnit unit)
/*  61:    */     throws InterruptedException
/*  62:    */   {
/*  63: 91 */     return delegate().pollLast(timeout, unit);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void put(E e)
/*  67:    */     throws InterruptedException
/*  68:    */   {
/*  69: 96 */     delegate().put(e);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean offer(E e, long timeout, TimeUnit unit)
/*  73:    */     throws InterruptedException
/*  74:    */   {
/*  75:101 */     return delegate().offer(e, timeout, unit);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public E take()
/*  79:    */     throws InterruptedException
/*  80:    */   {
/*  81:106 */     return delegate().take();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public E poll(long timeout, TimeUnit unit)
/*  85:    */     throws InterruptedException
/*  86:    */   {
/*  87:111 */     return delegate().poll(timeout, unit);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public int drainTo(Collection<? super E> c)
/*  91:    */   {
/*  92:116 */     return delegate().drainTo(c);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public int drainTo(Collection<? super E> c, int maxElements)
/*  96:    */   {
/*  97:121 */     return delegate().drainTo(c, maxElements);
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingBlockingDeque
 * JD-Core Version:    0.7.0.1
 */
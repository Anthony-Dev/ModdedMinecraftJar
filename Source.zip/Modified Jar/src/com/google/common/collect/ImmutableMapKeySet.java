/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Map.Entry;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(emulated=true)
/* 10:   */ final class ImmutableMapKeySet<K, V>
/* 11:   */   extends ImmutableSet<K>
/* 12:   */ {
/* 13:   */   private final ImmutableMap<K, V> map;
/* 14:   */   
/* 15:   */   ImmutableMapKeySet(ImmutableMap<K, V> map)
/* 16:   */   {
/* 17:38 */     this.map = map;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int size()
/* 21:   */   {
/* 22:43 */     return this.map.size();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public UnmodifiableIterator<K> iterator()
/* 26:   */   {
/* 27:48 */     return asList().iterator();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean contains(@Nullable Object object)
/* 31:   */   {
/* 32:53 */     return this.map.containsKey(object);
/* 33:   */   }
/* 34:   */   
/* 35:   */   ImmutableList<K> createAsList()
/* 36:   */   {
/* 37:58 */     final ImmutableList<Map.Entry<K, V>> entryList = this.map.entrySet().asList();
/* 38:59 */     new ImmutableAsList()
/* 39:   */     {
/* 40:   */       public K get(int index)
/* 41:   */       {
/* 42:63 */         return ((Map.Entry)entryList.get(index)).getKey();
/* 43:   */       }
/* 44:   */       
/* 45:   */       ImmutableCollection<K> delegateCollection()
/* 46:   */       {
/* 47:68 */         return ImmutableMapKeySet.this;
/* 48:   */       }
/* 49:   */     };
/* 50:   */   }
/* 51:   */   
/* 52:   */   boolean isPartialView()
/* 53:   */   {
/* 54:76 */     return true;
/* 55:   */   }
/* 56:   */   
/* 57:   */   @GwtIncompatible("serialization")
/* 58:   */   Object writeReplace()
/* 59:   */   {
/* 60:81 */     return new KeySetSerializedForm(this.map);
/* 61:   */   }
/* 62:   */   
/* 63:   */   @GwtIncompatible("serialization")
/* 64:   */   private static class KeySetSerializedForm<K>
/* 65:   */     implements Serializable
/* 66:   */   {
/* 67:   */     final ImmutableMap<K, ?> map;
/* 68:   */     private static final long serialVersionUID = 0L;
/* 69:   */     
/* 70:   */     KeySetSerializedForm(ImmutableMap<K, ?> map)
/* 71:   */     {
/* 72:88 */       this.map = map;
/* 73:   */     }
/* 74:   */     
/* 75:   */     Object readResolve()
/* 76:   */     {
/* 77:91 */       return this.map.keySet();
/* 78:   */     }
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapKeySet
 * JD-Core Version:    0.7.0.1
 */
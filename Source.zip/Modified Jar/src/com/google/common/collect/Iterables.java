/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Optional;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.base.Predicate;
/*   10:     */ import java.util.Collection;
/*   11:     */ import java.util.Comparator;
/*   12:     */ import java.util.Iterator;
/*   13:     */ import java.util.List;
/*   14:     */ import java.util.NoSuchElementException;
/*   15:     */ import java.util.Queue;
/*   16:     */ import java.util.RandomAccess;
/*   17:     */ import java.util.Set;
/*   18:     */ import javax.annotation.Nullable;
/*   19:     */ 
/*   20:     */ @GwtCompatible(emulated=true)
/*   21:     */ public final class Iterables
/*   22:     */ {
/*   23:     */   public static <T> Iterable<T> unmodifiableIterable(Iterable<T> iterable)
/*   24:     */   {
/*   25:  66 */     Preconditions.checkNotNull(iterable);
/*   26:  67 */     if (((iterable instanceof UnmodifiableIterable)) || ((iterable instanceof ImmutableCollection))) {
/*   27:  69 */       return iterable;
/*   28:     */     }
/*   29:  71 */     return new UnmodifiableIterable(iterable, null);
/*   30:     */   }
/*   31:     */   
/*   32:     */   @Deprecated
/*   33:     */   public static <E> Iterable<E> unmodifiableIterable(ImmutableCollection<E> iterable)
/*   34:     */   {
/*   35:  82 */     return (Iterable)Preconditions.checkNotNull(iterable);
/*   36:     */   }
/*   37:     */   
/*   38:     */   private static final class UnmodifiableIterable<T>
/*   39:     */     extends FluentIterable<T>
/*   40:     */   {
/*   41:     */     private final Iterable<T> iterable;
/*   42:     */     
/*   43:     */     private UnmodifiableIterable(Iterable<T> iterable)
/*   44:     */     {
/*   45:  89 */       this.iterable = iterable;
/*   46:     */     }
/*   47:     */     
/*   48:     */     public Iterator<T> iterator()
/*   49:     */     {
/*   50:  94 */       return Iterators.unmodifiableIterator(this.iterable.iterator());
/*   51:     */     }
/*   52:     */     
/*   53:     */     public String toString()
/*   54:     */     {
/*   55:  99 */       return this.iterable.toString();
/*   56:     */     }
/*   57:     */   }
/*   58:     */   
/*   59:     */   public static int size(Iterable<?> iterable)
/*   60:     */   {
/*   61: 108 */     return (iterable instanceof Collection) ? ((Collection)iterable).size() : Iterators.size(iterable.iterator());
/*   62:     */   }
/*   63:     */   
/*   64:     */   public static boolean contains(Iterable<?> iterable, @Nullable Object element)
/*   65:     */   {
/*   66: 118 */     if ((iterable instanceof Collection))
/*   67:     */     {
/*   68: 119 */       Collection<?> collection = (Collection)iterable;
/*   69: 120 */       return Collections2.safeContains(collection, element);
/*   70:     */     }
/*   71: 122 */     return Iterators.contains(iterable.iterator(), element);
/*   72:     */   }
/*   73:     */   
/*   74:     */   public static boolean removeAll(Iterable<?> removeFrom, Collection<?> elementsToRemove)
/*   75:     */   {
/*   76: 138 */     return (removeFrom instanceof Collection) ? ((Collection)removeFrom).removeAll((Collection)Preconditions.checkNotNull(elementsToRemove)) : Iterators.removeAll(removeFrom.iterator(), elementsToRemove);
/*   77:     */   }
/*   78:     */   
/*   79:     */   public static boolean retainAll(Iterable<?> removeFrom, Collection<?> elementsToRetain)
/*   80:     */   {
/*   81: 156 */     return (removeFrom instanceof Collection) ? ((Collection)removeFrom).retainAll((Collection)Preconditions.checkNotNull(elementsToRetain)) : Iterators.retainAll(removeFrom.iterator(), elementsToRetain);
/*   82:     */   }
/*   83:     */   
/*   84:     */   public static <T> boolean removeIf(Iterable<T> removeFrom, Predicate<? super T> predicate)
/*   85:     */   {
/*   86: 176 */     if (((removeFrom instanceof RandomAccess)) && ((removeFrom instanceof List))) {
/*   87: 177 */       return removeIfFromRandomAccessList((List)removeFrom, (Predicate)Preconditions.checkNotNull(predicate));
/*   88:     */     }
/*   89: 180 */     return Iterators.removeIf(removeFrom.iterator(), predicate);
/*   90:     */   }
/*   91:     */   
/*   92:     */   private static <T> boolean removeIfFromRandomAccessList(List<T> list, Predicate<? super T> predicate)
/*   93:     */   {
/*   94: 187 */     int from = 0;
/*   95: 188 */     int to = 0;
/*   96: 190 */     for (; from < list.size(); from++)
/*   97:     */     {
/*   98: 191 */       T element = list.get(from);
/*   99: 192 */       if (!predicate.apply(element))
/*  100:     */       {
/*  101: 193 */         if (from > to) {
/*  102:     */           try
/*  103:     */           {
/*  104: 195 */             list.set(to, element);
/*  105:     */           }
/*  106:     */           catch (UnsupportedOperationException e)
/*  107:     */           {
/*  108: 197 */             slowRemoveIfForRemainingElements(list, predicate, to, from);
/*  109: 198 */             return true;
/*  110:     */           }
/*  111:     */         }
/*  112: 201 */         to++;
/*  113:     */       }
/*  114:     */     }
/*  115: 206 */     list.subList(to, list.size()).clear();
/*  116: 207 */     return from != to;
/*  117:     */   }
/*  118:     */   
/*  119:     */   private static <T> void slowRemoveIfForRemainingElements(List<T> list, Predicate<? super T> predicate, int to, int from)
/*  120:     */   {
/*  121: 222 */     for (int n = list.size() - 1; n > from; n--) {
/*  122: 223 */       if (predicate.apply(list.get(n))) {
/*  123: 224 */         list.remove(n);
/*  124:     */       }
/*  125:     */     }
/*  126: 228 */     for (int n = from - 1; n >= to; n--) {
/*  127: 229 */       list.remove(n);
/*  128:     */     }
/*  129:     */   }
/*  130:     */   
/*  131:     */   @Nullable
/*  132:     */   static <T> T removeFirstMatching(Iterable<T> removeFrom, Predicate<? super T> predicate)
/*  133:     */   {
/*  134: 238 */     Preconditions.checkNotNull(predicate);
/*  135: 239 */     Iterator<T> iterator = removeFrom.iterator();
/*  136: 240 */     while (iterator.hasNext())
/*  137:     */     {
/*  138: 241 */       T next = iterator.next();
/*  139: 242 */       if (predicate.apply(next))
/*  140:     */       {
/*  141: 243 */         iterator.remove();
/*  142: 244 */         return next;
/*  143:     */       }
/*  144:     */     }
/*  145: 247 */     return null;
/*  146:     */   }
/*  147:     */   
/*  148:     */   public static boolean elementsEqual(Iterable<?> iterable1, Iterable<?> iterable2)
/*  149:     */   {
/*  150: 259 */     if (((iterable1 instanceof Collection)) && ((iterable2 instanceof Collection)))
/*  151:     */     {
/*  152: 260 */       Collection<?> collection1 = (Collection)iterable1;
/*  153: 261 */       Collection<?> collection2 = (Collection)iterable2;
/*  154: 262 */       if (collection1.size() != collection2.size()) {
/*  155: 263 */         return false;
/*  156:     */       }
/*  157:     */     }
/*  158: 266 */     return Iterators.elementsEqual(iterable1.iterator(), iterable2.iterator());
/*  159:     */   }
/*  160:     */   
/*  161:     */   public static String toString(Iterable<?> iterable)
/*  162:     */   {
/*  163: 278 */     return Iterators.toString(iterable.iterator());
/*  164:     */   }
/*  165:     */   
/*  166:     */   public static <T> T getOnlyElement(Iterable<T> iterable)
/*  167:     */   {
/*  168: 289 */     return Iterators.getOnlyElement(iterable.iterator());
/*  169:     */   }
/*  170:     */   
/*  171:     */   @Nullable
/*  172:     */   public static <T> T getOnlyElement(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  173:     */   {
/*  174: 302 */     return Iterators.getOnlyElement(iterable.iterator(), defaultValue);
/*  175:     */   }
/*  176:     */   
/*  177:     */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  178:     */   public static <T> T[] toArray(Iterable<? extends T> iterable, Class<T> type)
/*  179:     */   {
/*  180: 315 */     Collection<? extends T> collection = toCollection(iterable);
/*  181: 316 */     T[] array = ObjectArrays.newArray(type, collection.size());
/*  182: 317 */     return collection.toArray(array);
/*  183:     */   }
/*  184:     */   
/*  185:     */   static Object[] toArray(Iterable<?> iterable)
/*  186:     */   {
/*  187: 328 */     return toCollection(iterable).toArray();
/*  188:     */   }
/*  189:     */   
/*  190:     */   private static <E> Collection<E> toCollection(Iterable<E> iterable)
/*  191:     */   {
/*  192: 337 */     return (iterable instanceof Collection) ? (Collection)iterable : Lists.newArrayList(iterable.iterator());
/*  193:     */   }
/*  194:     */   
/*  195:     */   public static <T> boolean addAll(Collection<T> addTo, Iterable<? extends T> elementsToAdd)
/*  196:     */   {
/*  197: 350 */     if ((elementsToAdd instanceof Collection))
/*  198:     */     {
/*  199: 351 */       Collection<? extends T> c = Collections2.cast(elementsToAdd);
/*  200: 352 */       return addTo.addAll(c);
/*  201:     */     }
/*  202: 354 */     return Iterators.addAll(addTo, ((Iterable)Preconditions.checkNotNull(elementsToAdd)).iterator());
/*  203:     */   }
/*  204:     */   
/*  205:     */   public static int frequency(Iterable<?> iterable, @Nullable Object element)
/*  206:     */   {
/*  207: 365 */     if ((iterable instanceof Multiset)) {
/*  208: 366 */       return ((Multiset)iterable).count(element);
/*  209:     */     }
/*  210: 367 */     if ((iterable instanceof Set)) {
/*  211: 368 */       return ((Set)iterable).contains(element) ? 1 : 0;
/*  212:     */     }
/*  213: 370 */     return Iterators.frequency(iterable.iterator(), element);
/*  214:     */   }
/*  215:     */   
/*  216:     */   public static <T> Iterable<T> cycle(Iterable<T> iterable)
/*  217:     */   {
/*  218: 391 */     Preconditions.checkNotNull(iterable);
/*  219: 392 */     new FluentIterable()
/*  220:     */     {
/*  221:     */       public Iterator<T> iterator()
/*  222:     */       {
/*  223: 395 */         return Iterators.cycle(this.val$iterable);
/*  224:     */       }
/*  225:     */       
/*  226:     */       public String toString()
/*  227:     */       {
/*  228: 398 */         return this.val$iterable.toString() + " (cycled)";
/*  229:     */       }
/*  230:     */     };
/*  231:     */   }
/*  232:     */   
/*  233:     */   public static <T> Iterable<T> cycle(T... elements)
/*  234:     */   {
/*  235: 422 */     return cycle(Lists.newArrayList(elements));
/*  236:     */   }
/*  237:     */   
/*  238:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b)
/*  239:     */   {
/*  240: 435 */     return concat(ImmutableList.of(a, b));
/*  241:     */   }
/*  242:     */   
/*  243:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b, Iterable<? extends T> c)
/*  244:     */   {
/*  245: 449 */     return concat(ImmutableList.of(a, b, c));
/*  246:     */   }
/*  247:     */   
/*  248:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b, Iterable<? extends T> c, Iterable<? extends T> d)
/*  249:     */   {
/*  250: 465 */     return concat(ImmutableList.of(a, b, c, d));
/*  251:     */   }
/*  252:     */   
/*  253:     */   public static <T> Iterable<T> concat(Iterable<? extends T>... inputs)
/*  254:     */   {
/*  255: 479 */     return concat(ImmutableList.copyOf(inputs));
/*  256:     */   }
/*  257:     */   
/*  258:     */   public static <T> Iterable<T> concat(Iterable<? extends Iterable<? extends T>> inputs)
/*  259:     */   {
/*  260: 494 */     Preconditions.checkNotNull(inputs);
/*  261: 495 */     new FluentIterable()
/*  262:     */     {
/*  263:     */       public Iterator<T> iterator()
/*  264:     */       {
/*  265: 498 */         return Iterators.concat(Iterables.iterators(this.val$inputs));
/*  266:     */       }
/*  267:     */     };
/*  268:     */   }
/*  269:     */   
/*  270:     */   private static <T> Iterator<Iterator<? extends T>> iterators(Iterable<? extends Iterable<? extends T>> iterables)
/*  271:     */   {
/*  272: 508 */     new TransformedIterator(iterables.iterator())
/*  273:     */     {
/*  274:     */       Iterator<? extends T> transform(Iterable<? extends T> from)
/*  275:     */       {
/*  276: 512 */         return from.iterator();
/*  277:     */       }
/*  278:     */     };
/*  279:     */   }
/*  280:     */   
/*  281:     */   public static <T> Iterable<List<T>> partition(Iterable<T> iterable, final int size)
/*  282:     */   {
/*  283: 539 */     Preconditions.checkNotNull(iterable);
/*  284: 540 */     Preconditions.checkArgument(size > 0);
/*  285: 541 */     new FluentIterable()
/*  286:     */     {
/*  287:     */       public Iterator<List<T>> iterator()
/*  288:     */       {
/*  289: 544 */         return Iterators.partition(this.val$iterable.iterator(), size);
/*  290:     */       }
/*  291:     */     };
/*  292:     */   }
/*  293:     */   
/*  294:     */   public static <T> Iterable<List<T>> paddedPartition(Iterable<T> iterable, final int size)
/*  295:     */   {
/*  296: 568 */     Preconditions.checkNotNull(iterable);
/*  297: 569 */     Preconditions.checkArgument(size > 0);
/*  298: 570 */     new FluentIterable()
/*  299:     */     {
/*  300:     */       public Iterator<List<T>> iterator()
/*  301:     */       {
/*  302: 573 */         return Iterators.paddedPartition(this.val$iterable.iterator(), size);
/*  303:     */       }
/*  304:     */     };
/*  305:     */   }
/*  306:     */   
/*  307:     */   public static <T> Iterable<T> filter(Iterable<T> unfiltered, final Predicate<? super T> predicate)
/*  308:     */   {
/*  309: 584 */     Preconditions.checkNotNull(unfiltered);
/*  310: 585 */     Preconditions.checkNotNull(predicate);
/*  311: 586 */     new FluentIterable()
/*  312:     */     {
/*  313:     */       public Iterator<T> iterator()
/*  314:     */       {
/*  315: 589 */         return Iterators.filter(this.val$unfiltered.iterator(), predicate);
/*  316:     */       }
/*  317:     */     };
/*  318:     */   }
/*  319:     */   
/*  320:     */   @GwtIncompatible("Class.isInstance")
/*  321:     */   public static <T> Iterable<T> filter(Iterable<?> unfiltered, final Class<T> type)
/*  322:     */   {
/*  323: 608 */     Preconditions.checkNotNull(unfiltered);
/*  324: 609 */     Preconditions.checkNotNull(type);
/*  325: 610 */     new FluentIterable()
/*  326:     */     {
/*  327:     */       public Iterator<T> iterator()
/*  328:     */       {
/*  329: 613 */         return Iterators.filter(this.val$unfiltered.iterator(), type);
/*  330:     */       }
/*  331:     */     };
/*  332:     */   }
/*  333:     */   
/*  334:     */   public static <T> boolean any(Iterable<T> iterable, Predicate<? super T> predicate)
/*  335:     */   {
/*  336: 623 */     return Iterators.any(iterable.iterator(), predicate);
/*  337:     */   }
/*  338:     */   
/*  339:     */   public static <T> boolean all(Iterable<T> iterable, Predicate<? super T> predicate)
/*  340:     */   {
/*  341: 632 */     return Iterators.all(iterable.iterator(), predicate);
/*  342:     */   }
/*  343:     */   
/*  344:     */   public static <T> T find(Iterable<T> iterable, Predicate<? super T> predicate)
/*  345:     */   {
/*  346: 646 */     return Iterators.find(iterable.iterator(), predicate);
/*  347:     */   }
/*  348:     */   
/*  349:     */   @Nullable
/*  350:     */   public static <T> T find(Iterable<? extends T> iterable, Predicate<? super T> predicate, @Nullable T defaultValue)
/*  351:     */   {
/*  352: 660 */     return Iterators.find(iterable.iterator(), predicate, defaultValue);
/*  353:     */   }
/*  354:     */   
/*  355:     */   public static <T> Optional<T> tryFind(Iterable<T> iterable, Predicate<? super T> predicate)
/*  356:     */   {
/*  357: 675 */     return Iterators.tryFind(iterable.iterator(), predicate);
/*  358:     */   }
/*  359:     */   
/*  360:     */   public static <T> int indexOf(Iterable<T> iterable, Predicate<? super T> predicate)
/*  361:     */   {
/*  362: 691 */     return Iterators.indexOf(iterable.iterator(), predicate);
/*  363:     */   }
/*  364:     */   
/*  365:     */   public static <F, T> Iterable<T> transform(Iterable<F> fromIterable, final Function<? super F, ? extends T> function)
/*  366:     */   {
/*  367: 708 */     Preconditions.checkNotNull(fromIterable);
/*  368: 709 */     Preconditions.checkNotNull(function);
/*  369: 710 */     new FluentIterable()
/*  370:     */     {
/*  371:     */       public Iterator<T> iterator()
/*  372:     */       {
/*  373: 713 */         return Iterators.transform(this.val$fromIterable.iterator(), function);
/*  374:     */       }
/*  375:     */     };
/*  376:     */   }
/*  377:     */   
/*  378:     */   public static <T> T get(Iterable<T> iterable, int position)
/*  379:     */   {
/*  380: 727 */     Preconditions.checkNotNull(iterable);
/*  381: 728 */     return (iterable instanceof List) ? ((List)iterable).get(position) : Iterators.get(iterable.iterator(), position);
/*  382:     */   }
/*  383:     */   
/*  384:     */   @Nullable
/*  385:     */   public static <T> T get(Iterable<? extends T> iterable, int position, @Nullable T defaultValue)
/*  386:     */   {
/*  387: 748 */     Preconditions.checkNotNull(iterable);
/*  388: 749 */     Iterators.checkNonnegative(position);
/*  389: 750 */     if ((iterable instanceof List))
/*  390:     */     {
/*  391: 751 */       List<? extends T> list = Lists.cast(iterable);
/*  392: 752 */       return position < list.size() ? list.get(position) : defaultValue;
/*  393:     */     }
/*  394: 754 */     Iterator<? extends T> iterator = iterable.iterator();
/*  395: 755 */     Iterators.advance(iterator, position);
/*  396: 756 */     return Iterators.getNext(iterator, defaultValue);
/*  397:     */   }
/*  398:     */   
/*  399:     */   @Nullable
/*  400:     */   public static <T> T getFirst(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  401:     */   {
/*  402: 775 */     return Iterators.getNext(iterable.iterator(), defaultValue);
/*  403:     */   }
/*  404:     */   
/*  405:     */   public static <T> T getLast(Iterable<T> iterable)
/*  406:     */   {
/*  407: 786 */     if ((iterable instanceof List))
/*  408:     */     {
/*  409: 787 */       List<T> list = (List)iterable;
/*  410: 788 */       if (list.isEmpty()) {
/*  411: 789 */         throw new NoSuchElementException();
/*  412:     */       }
/*  413: 791 */       return getLastInNonemptyList(list);
/*  414:     */     }
/*  415: 794 */     return Iterators.getLast(iterable.iterator());
/*  416:     */   }
/*  417:     */   
/*  418:     */   @Nullable
/*  419:     */   public static <T> T getLast(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  420:     */   {
/*  421: 807 */     if ((iterable instanceof Collection))
/*  422:     */     {
/*  423: 808 */       Collection<? extends T> c = Collections2.cast(iterable);
/*  424: 809 */       if (c.isEmpty()) {
/*  425: 810 */         return defaultValue;
/*  426:     */       }
/*  427: 811 */       if ((iterable instanceof List)) {
/*  428: 812 */         return getLastInNonemptyList(Lists.cast(iterable));
/*  429:     */       }
/*  430:     */     }
/*  431: 816 */     return Iterators.getLast(iterable.iterator(), defaultValue);
/*  432:     */   }
/*  433:     */   
/*  434:     */   private static <T> T getLastInNonemptyList(List<T> list)
/*  435:     */   {
/*  436: 820 */     return list.get(list.size() - 1);
/*  437:     */   }
/*  438:     */   
/*  439:     */   public static <T> Iterable<T> skip(Iterable<T> iterable, final int numberToSkip)
/*  440:     */   {
/*  441: 845 */     Preconditions.checkNotNull(iterable);
/*  442: 846 */     Preconditions.checkArgument(numberToSkip >= 0, "number to skip cannot be negative");
/*  443: 848 */     if ((iterable instanceof List))
/*  444:     */     {
/*  445: 849 */       List<T> list = (List)iterable;
/*  446: 850 */       new FluentIterable()
/*  447:     */       {
/*  448:     */         public Iterator<T> iterator()
/*  449:     */         {
/*  450: 854 */           int toSkip = Math.min(this.val$list.size(), numberToSkip);
/*  451: 855 */           return this.val$list.subList(toSkip, this.val$list.size()).iterator();
/*  452:     */         }
/*  453:     */       };
/*  454:     */     }
/*  455: 860 */     new FluentIterable()
/*  456:     */     {
/*  457:     */       public Iterator<T> iterator()
/*  458:     */       {
/*  459: 863 */         final Iterator<T> iterator = this.val$iterable.iterator();
/*  460:     */         
/*  461: 865 */         Iterators.advance(iterator, numberToSkip);
/*  462:     */         
/*  463:     */ 
/*  464:     */ 
/*  465:     */ 
/*  466:     */ 
/*  467:     */ 
/*  468: 872 */         new Iterator()
/*  469:     */         {
/*  470: 873 */           boolean atStart = true;
/*  471:     */           
/*  472:     */           public boolean hasNext()
/*  473:     */           {
/*  474: 877 */             return iterator.hasNext();
/*  475:     */           }
/*  476:     */           
/*  477:     */           public T next()
/*  478:     */           {
/*  479: 882 */             T result = iterator.next();
/*  480: 883 */             this.atStart = false;
/*  481: 884 */             return result;
/*  482:     */           }
/*  483:     */           
/*  484:     */           public void remove()
/*  485:     */           {
/*  486: 889 */             CollectPreconditions.checkRemove(!this.atStart);
/*  487: 890 */             iterator.remove();
/*  488:     */           }
/*  489:     */         };
/*  490:     */       }
/*  491:     */     };
/*  492:     */   }
/*  493:     */   
/*  494:     */   public static <T> Iterable<T> limit(Iterable<T> iterable, final int limitSize)
/*  495:     */   {
/*  496: 911 */     Preconditions.checkNotNull(iterable);
/*  497: 912 */     Preconditions.checkArgument(limitSize >= 0, "limit is negative");
/*  498: 913 */     new FluentIterable()
/*  499:     */     {
/*  500:     */       public Iterator<T> iterator()
/*  501:     */       {
/*  502: 916 */         return Iterators.limit(this.val$iterable.iterator(), limitSize);
/*  503:     */       }
/*  504:     */     };
/*  505:     */   }
/*  506:     */   
/*  507:     */   public static <T> Iterable<T> consumingIterable(Iterable<T> iterable)
/*  508:     */   {
/*  509: 941 */     if ((iterable instanceof Queue)) {
/*  510: 942 */       new FluentIterable()
/*  511:     */       {
/*  512:     */         public Iterator<T> iterator()
/*  513:     */         {
/*  514: 945 */           return new Iterables.ConsumingQueueIterator((Queue)this.val$iterable, null);
/*  515:     */         }
/*  516:     */         
/*  517:     */         public String toString()
/*  518:     */         {
/*  519: 950 */           return "Iterables.consumingIterable(...)";
/*  520:     */         }
/*  521:     */       };
/*  522:     */     }
/*  523: 955 */     Preconditions.checkNotNull(iterable);
/*  524:     */     
/*  525: 957 */     new FluentIterable()
/*  526:     */     {
/*  527:     */       public Iterator<T> iterator()
/*  528:     */       {
/*  529: 960 */         return Iterators.consumingIterator(this.val$iterable.iterator());
/*  530:     */       }
/*  531:     */       
/*  532:     */       public String toString()
/*  533:     */       {
/*  534: 965 */         return "Iterables.consumingIterable(...)";
/*  535:     */       }
/*  536:     */     };
/*  537:     */   }
/*  538:     */   
/*  539:     */   private static class ConsumingQueueIterator<T>
/*  540:     */     extends AbstractIterator<T>
/*  541:     */   {
/*  542:     */     private final Queue<T> queue;
/*  543:     */     
/*  544:     */     private ConsumingQueueIterator(Queue<T> queue)
/*  545:     */     {
/*  546: 974 */       this.queue = queue;
/*  547:     */     }
/*  548:     */     
/*  549:     */     public T computeNext()
/*  550:     */     {
/*  551:     */       try
/*  552:     */       {
/*  553: 979 */         return this.queue.remove();
/*  554:     */       }
/*  555:     */       catch (NoSuchElementException e) {}
/*  556: 981 */       return endOfData();
/*  557:     */     }
/*  558:     */   }
/*  559:     */   
/*  560:     */   public static boolean isEmpty(Iterable<?> iterable)
/*  561:     */   {
/*  562: 998 */     if ((iterable instanceof Collection)) {
/*  563: 999 */       return ((Collection)iterable).isEmpty();
/*  564:     */     }
/*  565:1001 */     return !iterable.iterator().hasNext();
/*  566:     */   }
/*  567:     */   
/*  568:     */   @Beta
/*  569:     */   public static <T> Iterable<T> mergeSorted(Iterable<? extends Iterable<? extends T>> iterables, final Comparator<? super T> comparator)
/*  570:     */   {
/*  571:1020 */     Preconditions.checkNotNull(iterables, "iterables");
/*  572:1021 */     Preconditions.checkNotNull(comparator, "comparator");
/*  573:1022 */     Iterable<T> iterable = new FluentIterable()
/*  574:     */     {
/*  575:     */       public Iterator<T> iterator()
/*  576:     */       {
/*  577:1025 */         return Iterators.mergeSorted(Iterables.transform(this.val$iterables, Iterables.access$300()), comparator);
/*  578:     */       }
/*  579:1029 */     };
/*  580:1030 */     return new UnmodifiableIterable(iterable, null);
/*  581:     */   }
/*  582:     */   
/*  583:     */   private static <T> Function<Iterable<? extends T>, Iterator<? extends T>> toIterator()
/*  584:     */   {
/*  585:1037 */     new Function()
/*  586:     */     {
/*  587:     */       public Iterator<? extends T> apply(Iterable<? extends T> iterable)
/*  588:     */       {
/*  589:1040 */         return iterable.iterator();
/*  590:     */       }
/*  591:     */     };
/*  592:     */   }
/*  593:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Iterables
 * JD-Core Version:    0.7.0.1
 */
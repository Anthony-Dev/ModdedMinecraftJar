/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.ConcurrentModificationException;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.LinkedHashMap;
/*  15:    */ import java.util.LinkedHashSet;
/*  16:    */ import java.util.Map;
/*  17:    */ import java.util.Map.Entry;
/*  18:    */ import java.util.NoSuchElementException;
/*  19:    */ import java.util.Set;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ @GwtCompatible(serializable=true, emulated=true)
/*  23:    */ public final class LinkedHashMultimap<K, V>
/*  24:    */   extends AbstractSetMultimap<K, V>
/*  25:    */ {
/*  26:    */   private static final int DEFAULT_KEY_CAPACITY = 16;
/*  27:    */   private static final int DEFAULT_VALUE_SET_CAPACITY = 2;
/*  28:    */   @VisibleForTesting
/*  29:    */   static final double VALUE_SET_LOAD_FACTOR = 1.0D;
/*  30:    */   
/*  31:    */   public static <K, V> LinkedHashMultimap<K, V> create()
/*  32:    */   {
/*  33: 89 */     return new LinkedHashMultimap(16, 2);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  37:    */   {
/*  38:103 */     return new LinkedHashMultimap(Maps.capacity(expectedKeys), Maps.capacity(expectedValuesPerKey));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  42:    */   {
/*  43:119 */     LinkedHashMultimap<K, V> result = create(multimap.keySet().size(), 2);
/*  44:120 */     result.putAll(multimap);
/*  45:121 */     return result;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static <K, V> void succeedsInValueSet(ValueSetLink<K, V> pred, ValueSetLink<K, V> succ)
/*  49:    */   {
/*  50:133 */     pred.setSuccessorInValueSet(succ);
/*  51:134 */     succ.setPredecessorInValueSet(pred);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static <K, V> void succeedsInMultimap(ValueEntry<K, V> pred, ValueEntry<K, V> succ)
/*  55:    */   {
/*  56:139 */     pred.setSuccessorInMultimap(succ);
/*  57:140 */     succ.setPredecessorInMultimap(pred);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static <K, V> void deleteFromValueSet(ValueSetLink<K, V> entry)
/*  61:    */   {
/*  62:144 */     succeedsInValueSet(entry.getPredecessorInValueSet(), entry.getSuccessorInValueSet());
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static <K, V> void deleteFromMultimap(ValueEntry<K, V> entry)
/*  66:    */   {
/*  67:148 */     succeedsInMultimap(entry.getPredecessorInMultimap(), entry.getSuccessorInMultimap());
/*  68:    */   }
/*  69:    */   
/*  70:    */   @VisibleForTesting
/*  71:    */   static final class ValueEntry<K, V>
/*  72:    */     extends ImmutableEntry<K, V>
/*  73:    */     implements LinkedHashMultimap.ValueSetLink<K, V>
/*  74:    */   {
/*  75:    */     final int smearedValueHash;
/*  76:    */     @Nullable
/*  77:    */     ValueEntry<K, V> nextInValueBucket;
/*  78:    */     LinkedHashMultimap.ValueSetLink<K, V> predecessorInValueSet;
/*  79:    */     LinkedHashMultimap.ValueSetLink<K, V> successorInValueSet;
/*  80:    */     ValueEntry<K, V> predecessorInMultimap;
/*  81:    */     ValueEntry<K, V> successorInMultimap;
/*  82:    */     
/*  83:    */     ValueEntry(@Nullable K key, @Nullable V value, int smearedValueHash, @Nullable ValueEntry<K, V> nextInValueBucket)
/*  84:    */     {
/*  85:172 */       super(value);
/*  86:173 */       this.smearedValueHash = smearedValueHash;
/*  87:174 */       this.nextInValueBucket = nextInValueBucket;
/*  88:    */     }
/*  89:    */     
/*  90:    */     boolean matchesValue(@Nullable Object v, int smearedVHash)
/*  91:    */     {
/*  92:178 */       return (this.smearedValueHash == smearedVHash) && (Objects.equal(getValue(), v));
/*  93:    */     }
/*  94:    */     
/*  95:    */     public LinkedHashMultimap.ValueSetLink<K, V> getPredecessorInValueSet()
/*  96:    */     {
/*  97:183 */       return this.predecessorInValueSet;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public LinkedHashMultimap.ValueSetLink<K, V> getSuccessorInValueSet()
/* 101:    */     {
/* 102:188 */       return this.successorInValueSet;
/* 103:    */     }
/* 104:    */     
/* 105:    */     public void setPredecessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 106:    */     {
/* 107:193 */       this.predecessorInValueSet = entry;
/* 108:    */     }
/* 109:    */     
/* 110:    */     public void setSuccessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 111:    */     {
/* 112:198 */       this.successorInValueSet = entry;
/* 113:    */     }
/* 114:    */     
/* 115:    */     public ValueEntry<K, V> getPredecessorInMultimap()
/* 116:    */     {
/* 117:202 */       return this.predecessorInMultimap;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public ValueEntry<K, V> getSuccessorInMultimap()
/* 121:    */     {
/* 122:206 */       return this.successorInMultimap;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public void setSuccessorInMultimap(ValueEntry<K, V> multimapSuccessor)
/* 126:    */     {
/* 127:210 */       this.successorInMultimap = multimapSuccessor;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public void setPredecessorInMultimap(ValueEntry<K, V> multimapPredecessor)
/* 131:    */     {
/* 132:214 */       this.predecessorInMultimap = multimapPredecessor;
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   @VisibleForTesting
/* 137:222 */   transient int valueSetCapacity = 2;
/* 138:    */   private transient ValueEntry<K, V> multimapHeaderEntry;
/* 139:    */   @GwtIncompatible("java serialization not supported")
/* 140:    */   private static final long serialVersionUID = 1L;
/* 141:    */   
/* 142:    */   private LinkedHashMultimap(int keyCapacity, int valueSetCapacity)
/* 143:    */   {
/* 144:226 */     super(new LinkedHashMap(keyCapacity));
/* 145:227 */     CollectPreconditions.checkNonnegative(valueSetCapacity, "expectedValuesPerKey");
/* 146:    */     
/* 147:229 */     this.valueSetCapacity = valueSetCapacity;
/* 148:230 */     this.multimapHeaderEntry = new ValueEntry(null, null, 0, null);
/* 149:231 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 150:    */   }
/* 151:    */   
/* 152:    */   Set<V> createCollection()
/* 153:    */   {
/* 154:245 */     return new LinkedHashSet(this.valueSetCapacity);
/* 155:    */   }
/* 156:    */   
/* 157:    */   Collection<V> createCollection(K key)
/* 158:    */   {
/* 159:259 */     return new ValueSet(key, this.valueSetCapacity);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public Set<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/* 163:    */   {
/* 164:272 */     return super.replaceValues(key, values);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public Set<Map.Entry<K, V>> entries()
/* 168:    */   {
/* 169:288 */     return super.entries();
/* 170:    */   }
/* 171:    */   
/* 172:    */   public Collection<V> values()
/* 173:    */   {
/* 174:299 */     return super.values();
/* 175:    */   }
/* 176:    */   
/* 177:    */   @VisibleForTesting
/* 178:    */   final class ValueSet
/* 179:    */     extends Sets.ImprovedAbstractSet<V>
/* 180:    */     implements LinkedHashMultimap.ValueSetLink<K, V>
/* 181:    */   {
/* 182:    */     private final K key;
/* 183:    */     @VisibleForTesting
/* 184:    */     LinkedHashMultimap.ValueEntry<K, V>[] hashTable;
/* 185:311 */     private int size = 0;
/* 186:312 */     private int modCount = 0;
/* 187:    */     private LinkedHashMultimap.ValueSetLink<K, V> firstEntry;
/* 188:    */     private LinkedHashMultimap.ValueSetLink<K, V> lastEntry;
/* 189:    */     
/* 190:    */     ValueSet(int key)
/* 191:    */     {
/* 192:320 */       this.key = key;
/* 193:321 */       this.firstEntry = this;
/* 194:322 */       this.lastEntry = this;
/* 195:    */       
/* 196:324 */       int tableSize = Hashing.closedTableSize(expectedValues, 1.0D);
/* 197:    */       
/* 198:    */ 
/* 199:327 */       LinkedHashMultimap.ValueEntry<K, V>[] hashTable = new LinkedHashMultimap.ValueEntry[tableSize];
/* 200:328 */       this.hashTable = hashTable;
/* 201:    */     }
/* 202:    */     
/* 203:    */     private int mask()
/* 204:    */     {
/* 205:332 */       return this.hashTable.length - 1;
/* 206:    */     }
/* 207:    */     
/* 208:    */     public LinkedHashMultimap.ValueSetLink<K, V> getPredecessorInValueSet()
/* 209:    */     {
/* 210:337 */       return this.lastEntry;
/* 211:    */     }
/* 212:    */     
/* 213:    */     public LinkedHashMultimap.ValueSetLink<K, V> getSuccessorInValueSet()
/* 214:    */     {
/* 215:342 */       return this.firstEntry;
/* 216:    */     }
/* 217:    */     
/* 218:    */     public void setPredecessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 219:    */     {
/* 220:347 */       this.lastEntry = entry;
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void setSuccessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 224:    */     {
/* 225:352 */       this.firstEntry = entry;
/* 226:    */     }
/* 227:    */     
/* 228:    */     public Iterator<V> iterator()
/* 229:    */     {
/* 230:357 */       new Iterator()
/* 231:    */       {
/* 232:358 */         LinkedHashMultimap.ValueSetLink<K, V> nextEntry = LinkedHashMultimap.ValueSet.this.firstEntry;
/* 233:    */         LinkedHashMultimap.ValueEntry<K, V> toRemove;
/* 234:360 */         int expectedModCount = LinkedHashMultimap.ValueSet.this.modCount;
/* 235:    */         
/* 236:    */         private void checkForComodification()
/* 237:    */         {
/* 238:363 */           if (LinkedHashMultimap.ValueSet.this.modCount != this.expectedModCount) {
/* 239:364 */             throw new ConcurrentModificationException();
/* 240:    */           }
/* 241:    */         }
/* 242:    */         
/* 243:    */         public boolean hasNext()
/* 244:    */         {
/* 245:370 */           checkForComodification();
/* 246:371 */           return this.nextEntry != LinkedHashMultimap.ValueSet.this;
/* 247:    */         }
/* 248:    */         
/* 249:    */         public V next()
/* 250:    */         {
/* 251:376 */           if (!hasNext()) {
/* 252:377 */             throw new NoSuchElementException();
/* 253:    */           }
/* 254:379 */           LinkedHashMultimap.ValueEntry<K, V> entry = (LinkedHashMultimap.ValueEntry)this.nextEntry;
/* 255:380 */           V result = entry.getValue();
/* 256:381 */           this.toRemove = entry;
/* 257:382 */           this.nextEntry = entry.getSuccessorInValueSet();
/* 258:383 */           return result;
/* 259:    */         }
/* 260:    */         
/* 261:    */         public void remove()
/* 262:    */         {
/* 263:388 */           checkForComodification();
/* 264:389 */           CollectPreconditions.checkRemove(this.toRemove != null);
/* 265:390 */           LinkedHashMultimap.ValueSet.this.remove(this.toRemove.getValue());
/* 266:391 */           this.expectedModCount = LinkedHashMultimap.ValueSet.this.modCount;
/* 267:392 */           this.toRemove = null;
/* 268:    */         }
/* 269:    */       };
/* 270:    */     }
/* 271:    */     
/* 272:    */     public int size()
/* 273:    */     {
/* 274:399 */       return this.size;
/* 275:    */     }
/* 276:    */     
/* 277:    */     public boolean contains(@Nullable Object o)
/* 278:    */     {
/* 279:404 */       int smearedHash = Hashing.smearedHash(o);
/* 280:405 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = this.hashTable[(smearedHash & mask())]; entry != null; entry = entry.nextInValueBucket) {
/* 281:407 */         if (entry.matchesValue(o, smearedHash)) {
/* 282:408 */           return true;
/* 283:    */         }
/* 284:    */       }
/* 285:411 */       return false;
/* 286:    */     }
/* 287:    */     
/* 288:    */     public boolean add(@Nullable V value)
/* 289:    */     {
/* 290:416 */       int smearedHash = Hashing.smearedHash(value);
/* 291:417 */       int bucket = smearedHash & mask();
/* 292:418 */       LinkedHashMultimap.ValueEntry<K, V> rowHead = this.hashTable[bucket];
/* 293:419 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = rowHead; entry != null; entry = entry.nextInValueBucket) {
/* 294:421 */         if (entry.matchesValue(value, smearedHash)) {
/* 295:422 */           return false;
/* 296:    */         }
/* 297:    */       }
/* 298:426 */       LinkedHashMultimap.ValueEntry<K, V> newEntry = new LinkedHashMultimap.ValueEntry(this.key, value, smearedHash, rowHead);
/* 299:427 */       LinkedHashMultimap.succeedsInValueSet(this.lastEntry, newEntry);
/* 300:428 */       LinkedHashMultimap.succeedsInValueSet(newEntry, this);
/* 301:429 */       LinkedHashMultimap.succeedsInMultimap(LinkedHashMultimap.this.multimapHeaderEntry.getPredecessorInMultimap(), newEntry);
/* 302:430 */       LinkedHashMultimap.succeedsInMultimap(newEntry, LinkedHashMultimap.this.multimapHeaderEntry);
/* 303:431 */       this.hashTable[bucket] = newEntry;
/* 304:432 */       this.size += 1;
/* 305:433 */       this.modCount += 1;
/* 306:434 */       rehashIfNecessary();
/* 307:435 */       return true;
/* 308:    */     }
/* 309:    */     
/* 310:    */     private void rehashIfNecessary()
/* 311:    */     {
/* 312:439 */       if (Hashing.needsResizing(this.size, this.hashTable.length, 1.0D))
/* 313:    */       {
/* 314:441 */         LinkedHashMultimap.ValueEntry<K, V>[] hashTable = new LinkedHashMultimap.ValueEntry[this.hashTable.length * 2];
/* 315:442 */         this.hashTable = hashTable;
/* 316:443 */         int mask = hashTable.length - 1;
/* 317:444 */         for (LinkedHashMultimap.ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry.getSuccessorInValueSet())
/* 318:    */         {
/* 319:446 */           LinkedHashMultimap.ValueEntry<K, V> valueEntry = (LinkedHashMultimap.ValueEntry)entry;
/* 320:447 */           int bucket = valueEntry.smearedValueHash & mask;
/* 321:448 */           valueEntry.nextInValueBucket = hashTable[bucket];
/* 322:449 */           hashTable[bucket] = valueEntry;
/* 323:    */         }
/* 324:    */       }
/* 325:    */     }
/* 326:    */     
/* 327:    */     public boolean remove(@Nullable Object o)
/* 328:    */     {
/* 329:456 */       int smearedHash = Hashing.smearedHash(o);
/* 330:457 */       int bucket = smearedHash & mask();
/* 331:458 */       LinkedHashMultimap.ValueEntry<K, V> prev = null;
/* 332:459 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = this.hashTable[bucket]; entry != null; entry = entry.nextInValueBucket)
/* 333:    */       {
/* 334:461 */         if (entry.matchesValue(o, smearedHash))
/* 335:    */         {
/* 336:462 */           if (prev == null) {
/* 337:464 */             this.hashTable[bucket] = entry.nextInValueBucket;
/* 338:    */           } else {
/* 339:466 */             prev.nextInValueBucket = entry.nextInValueBucket;
/* 340:    */           }
/* 341:468 */           LinkedHashMultimap.deleteFromValueSet(entry);
/* 342:469 */           LinkedHashMultimap.deleteFromMultimap(entry);
/* 343:470 */           this.size -= 1;
/* 344:471 */           this.modCount += 1;
/* 345:472 */           return true;
/* 346:    */         }
/* 347:460 */         prev = entry;
/* 348:    */       }
/* 349:475 */       return false;
/* 350:    */     }
/* 351:    */     
/* 352:    */     public void clear()
/* 353:    */     {
/* 354:480 */       Arrays.fill(this.hashTable, null);
/* 355:481 */       this.size = 0;
/* 356:482 */       for (LinkedHashMultimap.ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry.getSuccessorInValueSet())
/* 357:    */       {
/* 358:484 */         LinkedHashMultimap.ValueEntry<K, V> valueEntry = (LinkedHashMultimap.ValueEntry)entry;
/* 359:485 */         LinkedHashMultimap.deleteFromMultimap(valueEntry);
/* 360:    */       }
/* 361:487 */       LinkedHashMultimap.succeedsInValueSet(this, this);
/* 362:488 */       this.modCount += 1;
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   Iterator<Map.Entry<K, V>> entryIterator()
/* 367:    */   {
/* 368:494 */     new Iterator()
/* 369:    */     {
/* 370:495 */       LinkedHashMultimap.ValueEntry<K, V> nextEntry = LinkedHashMultimap.this.multimapHeaderEntry.successorInMultimap;
/* 371:    */       LinkedHashMultimap.ValueEntry<K, V> toRemove;
/* 372:    */       
/* 373:    */       public boolean hasNext()
/* 374:    */       {
/* 375:500 */         return this.nextEntry != LinkedHashMultimap.this.multimapHeaderEntry;
/* 376:    */       }
/* 377:    */       
/* 378:    */       public Map.Entry<K, V> next()
/* 379:    */       {
/* 380:505 */         if (!hasNext()) {
/* 381:506 */           throw new NoSuchElementException();
/* 382:    */         }
/* 383:508 */         LinkedHashMultimap.ValueEntry<K, V> result = this.nextEntry;
/* 384:509 */         this.toRemove = result;
/* 385:510 */         this.nextEntry = this.nextEntry.successorInMultimap;
/* 386:511 */         return result;
/* 387:    */       }
/* 388:    */       
/* 389:    */       public void remove()
/* 390:    */       {
/* 391:516 */         CollectPreconditions.checkRemove(this.toRemove != null);
/* 392:517 */         LinkedHashMultimap.this.remove(this.toRemove.getKey(), this.toRemove.getValue());
/* 393:518 */         this.toRemove = null;
/* 394:    */       }
/* 395:    */     };
/* 396:    */   }
/* 397:    */   
/* 398:    */   Iterator<V> valueIterator()
/* 399:    */   {
/* 400:525 */     return Maps.valueIterator(entryIterator());
/* 401:    */   }
/* 402:    */   
/* 403:    */   public void clear()
/* 404:    */   {
/* 405:530 */     super.clear();
/* 406:531 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 407:    */   }
/* 408:    */   
/* 409:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 410:    */   private void writeObject(ObjectOutputStream stream)
/* 411:    */     throws IOException
/* 412:    */   {
/* 413:540 */     stream.defaultWriteObject();
/* 414:541 */     stream.writeInt(this.valueSetCapacity);
/* 415:542 */     stream.writeInt(keySet().size());
/* 416:543 */     for (K key : keySet()) {
/* 417:544 */       stream.writeObject(key);
/* 418:    */     }
/* 419:546 */     stream.writeInt(size());
/* 420:547 */     for (Map.Entry<K, V> entry : entries())
/* 421:    */     {
/* 422:548 */       stream.writeObject(entry.getKey());
/* 423:549 */       stream.writeObject(entry.getValue());
/* 424:    */     }
/* 425:    */   }
/* 426:    */   
/* 427:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 428:    */   private void readObject(ObjectInputStream stream)
/* 429:    */     throws IOException, ClassNotFoundException
/* 430:    */   {
/* 431:556 */     stream.defaultReadObject();
/* 432:557 */     this.multimapHeaderEntry = new ValueEntry(null, null, 0, null);
/* 433:558 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 434:559 */     this.valueSetCapacity = stream.readInt();
/* 435:560 */     int distinctKeys = stream.readInt();
/* 436:561 */     Map<K, Collection<V>> map = new LinkedHashMap(Maps.capacity(distinctKeys));
/* 437:563 */     for (int i = 0; i < distinctKeys; i++)
/* 438:    */     {
/* 439:565 */       K key = stream.readObject();
/* 440:566 */       map.put(key, createCollection(key));
/* 441:    */     }
/* 442:568 */     int entries = stream.readInt();
/* 443:569 */     for (int i = 0; i < entries; i++)
/* 444:    */     {
/* 445:571 */       K key = stream.readObject();
/* 446:    */       
/* 447:573 */       V value = stream.readObject();
/* 448:574 */       ((Collection)map.get(key)).add(value);
/* 449:    */     }
/* 450:576 */     setMap(map);
/* 451:    */   }
/* 452:    */   
/* 453:    */   private static abstract interface ValueSetLink<K, V>
/* 454:    */   {
/* 455:    */     public abstract ValueSetLink<K, V> getPredecessorInValueSet();
/* 456:    */     
/* 457:    */     public abstract ValueSetLink<K, V> getSuccessorInValueSet();
/* 458:    */     
/* 459:    */     public abstract void setPredecessorInValueSet(ValueSetLink<K, V> paramValueSetLink);
/* 460:    */     
/* 461:    */     public abstract void setSuccessorInValueSet(ValueSetLink<K, V> paramValueSetLink);
/* 462:    */   }
/* 463:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.LinkedHashMultimap
 * JD-Core Version:    0.7.0.1
 */
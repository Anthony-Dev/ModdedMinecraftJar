/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true)
/*  8:   */ class ImmutableEntry<K, V>
/*  9:   */   extends AbstractMapEntry<K, V>
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:   */   final K key;
/* 13:   */   final V value;
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   ImmutableEntry(@Nullable K key, @Nullable V value)
/* 17:   */   {
/* 18:35 */     this.key = key;
/* 19:36 */     this.value = value;
/* 20:   */   }
/* 21:   */   
/* 22:   */   @Nullable
/* 23:   */   public final K getKey()
/* 24:   */   {
/* 25:40 */     return this.key;
/* 26:   */   }
/* 27:   */   
/* 28:   */   @Nullable
/* 29:   */   public final V getValue()
/* 30:   */   {
/* 31:44 */     return this.value;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public final V setValue(V value)
/* 35:   */   {
/* 36:48 */     throw new UnsupportedOperationException();
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableEntry
 * JD-Core Version:    0.7.0.1
 */
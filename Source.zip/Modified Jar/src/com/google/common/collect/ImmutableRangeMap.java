/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.NoSuchElementException;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ @GwtIncompatible("NavigableMap")
/*  13:    */ public class ImmutableRangeMap<K extends Comparable<?>, V>
/*  14:    */   implements RangeMap<K, V>
/*  15:    */ {
/*  16: 44 */   private static final ImmutableRangeMap<Comparable<?>, Object> EMPTY = new ImmutableRangeMap(ImmutableList.of(), ImmutableList.of());
/*  17:    */   private final ImmutableList<Range<K>> ranges;
/*  18:    */   private final ImmutableList<V> values;
/*  19:    */   
/*  20:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of()
/*  21:    */   {
/*  22: 53 */     return EMPTY;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of(Range<K> range, V value)
/*  26:    */   {
/*  27: 61 */     return new ImmutableRangeMap(ImmutableList.of(range), ImmutableList.of(value));
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> copyOf(RangeMap<K, ? extends V> rangeMap)
/*  31:    */   {
/*  32: 67 */     if ((rangeMap instanceof ImmutableRangeMap)) {
/*  33: 68 */       return (ImmutableRangeMap)rangeMap;
/*  34:    */     }
/*  35: 70 */     Map<Range<K>, ? extends V> map = rangeMap.asMapOfRanges();
/*  36: 71 */     ImmutableList.Builder<Range<K>> rangesBuilder = new ImmutableList.Builder(map.size());
/*  37: 72 */     ImmutableList.Builder<V> valuesBuilder = new ImmutableList.Builder(map.size());
/*  38: 73 */     for (Map.Entry<Range<K>, ? extends V> entry : map.entrySet())
/*  39:    */     {
/*  40: 74 */       rangesBuilder.add(entry.getKey());
/*  41: 75 */       valuesBuilder.add(entry.getValue());
/*  42:    */     }
/*  43: 77 */     return new ImmutableRangeMap(rangesBuilder.build(), valuesBuilder.build());
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <K extends Comparable<?>, V> Builder<K, V> builder()
/*  47:    */   {
/*  48: 84 */     return new Builder();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static final class Builder<K extends Comparable<?>, V>
/*  52:    */   {
/*  53:    */     private final RangeSet<K> keyRanges;
/*  54:    */     private final RangeMap<K, V> rangeMap;
/*  55:    */     
/*  56:    */     public Builder()
/*  57:    */     {
/*  58: 95 */       this.keyRanges = TreeRangeSet.create();
/*  59: 96 */       this.rangeMap = TreeRangeMap.create();
/*  60:    */     }
/*  61:    */     
/*  62:    */     public Builder<K, V> put(Range<K> range, V value)
/*  63:    */     {
/*  64:106 */       Preconditions.checkNotNull(range);
/*  65:107 */       Preconditions.checkNotNull(value);
/*  66:108 */       Preconditions.checkArgument(!range.isEmpty(), "Range must not be empty, but was %s", new Object[] { range });
/*  67:109 */       if (!this.keyRanges.complement().encloses(range)) {
/*  68:111 */         for (Map.Entry<Range<K>, V> entry : this.rangeMap.asMapOfRanges().entrySet())
/*  69:    */         {
/*  70:112 */           Range<K> key = (Range)entry.getKey();
/*  71:113 */           if ((key.isConnected(range)) && (!key.intersection(range).isEmpty())) {
/*  72:114 */             throw new IllegalArgumentException("Overlapping ranges: range " + range + " overlaps with entry " + entry);
/*  73:    */           }
/*  74:    */         }
/*  75:    */       }
/*  76:119 */       this.keyRanges.add(range);
/*  77:120 */       this.rangeMap.put(range, value);
/*  78:121 */       return this;
/*  79:    */     }
/*  80:    */     
/*  81:    */     public Builder<K, V> putAll(RangeMap<K, ? extends V> rangeMap)
/*  82:    */     {
/*  83:131 */       for (Map.Entry<Range<K>, ? extends V> entry : rangeMap.asMapOfRanges().entrySet()) {
/*  84:132 */         put((Range)entry.getKey(), entry.getValue());
/*  85:    */       }
/*  86:134 */       return this;
/*  87:    */     }
/*  88:    */     
/*  89:    */     public ImmutableRangeMap<K, V> build()
/*  90:    */     {
/*  91:142 */       Map<Range<K>, V> map = this.rangeMap.asMapOfRanges();
/*  92:143 */       ImmutableList.Builder<Range<K>> rangesBuilder = new ImmutableList.Builder(map.size());
/*  93:    */       
/*  94:145 */       ImmutableList.Builder<V> valuesBuilder = new ImmutableList.Builder(map.size());
/*  95:146 */       for (Map.Entry<Range<K>, V> entry : map.entrySet())
/*  96:    */       {
/*  97:147 */         rangesBuilder.add(entry.getKey());
/*  98:148 */         valuesBuilder.add(entry.getValue());
/*  99:    */       }
/* 100:150 */       return new ImmutableRangeMap(rangesBuilder.build(), valuesBuilder.build());
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   ImmutableRangeMap(ImmutableList<Range<K>> ranges, ImmutableList<V> values)
/* 105:    */   {
/* 106:158 */     this.ranges = ranges;
/* 107:159 */     this.values = values;
/* 108:    */   }
/* 109:    */   
/* 110:    */   @Nullable
/* 111:    */   public V get(K key)
/* 112:    */   {
/* 113:165 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/* 114:167 */     if (index == -1) {
/* 115:168 */       return null;
/* 116:    */     }
/* 117:170 */     Range<K> range = (Range)this.ranges.get(index);
/* 118:171 */     return range.contains(key) ? this.values.get(index) : null;
/* 119:    */   }
/* 120:    */   
/* 121:    */   @Nullable
/* 122:    */   public Map.Entry<Range<K>, V> getEntry(K key)
/* 123:    */   {
/* 124:178 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/* 125:180 */     if (index == -1) {
/* 126:181 */       return null;
/* 127:    */     }
/* 128:183 */     Range<K> range = (Range)this.ranges.get(index);
/* 129:184 */     return range.contains(key) ? Maps.immutableEntry(range, this.values.get(index)) : null;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public Range<K> span()
/* 133:    */   {
/* 134:190 */     if (this.ranges.isEmpty()) {
/* 135:191 */       throw new NoSuchElementException();
/* 136:    */     }
/* 137:193 */     Range<K> firstRange = (Range)this.ranges.get(0);
/* 138:194 */     Range<K> lastRange = (Range)this.ranges.get(this.ranges.size() - 1);
/* 139:195 */     return Range.create(firstRange.lowerBound, lastRange.upperBound);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void put(Range<K> range, V value)
/* 143:    */   {
/* 144:200 */     throw new UnsupportedOperationException();
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void putAll(RangeMap<K, V> rangeMap)
/* 148:    */   {
/* 149:205 */     throw new UnsupportedOperationException();
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void clear()
/* 153:    */   {
/* 154:210 */     throw new UnsupportedOperationException();
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void remove(Range<K> range)
/* 158:    */   {
/* 159:215 */     throw new UnsupportedOperationException();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public ImmutableMap<Range<K>, V> asMapOfRanges()
/* 163:    */   {
/* 164:220 */     if (this.ranges.isEmpty()) {
/* 165:221 */       return ImmutableMap.of();
/* 166:    */     }
/* 167:223 */     RegularImmutableSortedSet<Range<K>> rangeSet = new RegularImmutableSortedSet(this.ranges, Range.RANGE_LEX_ORDERING);
/* 168:    */     
/* 169:225 */     return new RegularImmutableSortedMap(rangeSet, this.values);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public ImmutableRangeMap<K, V> subRangeMap(final Range<K> range)
/* 173:    */   {
/* 174:230 */     if (((Range)Preconditions.checkNotNull(range)).isEmpty()) {
/* 175:231 */       return of();
/* 176:    */     }
/* 177:232 */     if ((this.ranges.isEmpty()) || (range.encloses(span()))) {
/* 178:233 */       return this;
/* 179:    */     }
/* 180:235 */     int lowerIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 181:    */     
/* 182:    */ 
/* 183:238 */     int upperIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 184:241 */     if (lowerIndex >= upperIndex) {
/* 185:242 */       return of();
/* 186:    */     }
/* 187:244 */     final int off = lowerIndex;
/* 188:245 */     final int len = upperIndex - lowerIndex;
/* 189:246 */     ImmutableList<Range<K>> subRanges = new ImmutableList()
/* 190:    */     {
/* 191:    */       public int size()
/* 192:    */       {
/* 193:249 */         return len;
/* 194:    */       }
/* 195:    */       
/* 196:    */       public Range<K> get(int index)
/* 197:    */       {
/* 198:254 */         Preconditions.checkElementIndex(index, len);
/* 199:255 */         if ((index == 0) || (index == len - 1)) {
/* 200:256 */           return ((Range)ImmutableRangeMap.this.ranges.get(index + off)).intersection(range);
/* 201:    */         }
/* 202:258 */         return (Range)ImmutableRangeMap.this.ranges.get(index + off);
/* 203:    */       }
/* 204:    */       
/* 205:    */       boolean isPartialView()
/* 206:    */       {
/* 207:264 */         return true;
/* 208:    */       }
/* 209:266 */     };
/* 210:267 */     final ImmutableRangeMap<K, V> outer = this;
/* 211:268 */     new ImmutableRangeMap(subRanges, this.values.subList(lowerIndex, upperIndex))
/* 212:    */     {
/* 213:    */       public ImmutableRangeMap<K, V> subRangeMap(Range<K> subRange)
/* 214:    */       {
/* 215:272 */         if (range.isConnected(subRange)) {
/* 216:273 */           return outer.subRangeMap(subRange.intersection(range));
/* 217:    */         }
/* 218:275 */         return ImmutableRangeMap.of();
/* 219:    */       }
/* 220:    */     };
/* 221:    */   }
/* 222:    */   
/* 223:    */   public int hashCode()
/* 224:    */   {
/* 225:283 */     return asMapOfRanges().hashCode();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public boolean equals(@Nullable Object o)
/* 229:    */   {
/* 230:288 */     if ((o instanceof RangeMap))
/* 231:    */     {
/* 232:289 */       RangeMap<?, ?> rangeMap = (RangeMap)o;
/* 233:290 */       return asMapOfRanges().equals(rangeMap.asMapOfRanges());
/* 234:    */     }
/* 235:292 */     return false;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public String toString()
/* 239:    */   {
/* 240:297 */     return asMapOfRanges().toString();
/* 241:    */   }
/* 242:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableRangeMap
 * JD-Core Version:    0.7.0.1
 */
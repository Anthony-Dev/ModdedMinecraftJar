/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import com.google.common.base.Predicates;
/*   8:    */ import com.google.common.base.Supplier;
/*   9:    */ import java.io.Serializable;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.LinkedHashMap;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible
/*  19:    */ class StandardTable<R, C, V>
/*  20:    */   extends AbstractTable<R, C, V>
/*  21:    */   implements Serializable
/*  22:    */ {
/*  23:    */   @GwtTransient
/*  24:    */   final Map<R, Map<C, V>> backingMap;
/*  25:    */   @GwtTransient
/*  26:    */   final Supplier<? extends Map<C, V>> factory;
/*  27:    */   private transient Set<C> columnKeySet;
/*  28:    */   private transient Map<R, Map<C, V>> rowMap;
/*  29:    */   private transient StandardTable<R, C, V>.ColumnMap columnMap;
/*  30:    */   private static final long serialVersionUID = 0L;
/*  31:    */   
/*  32:    */   StandardTable(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*  33:    */   {
/*  34: 73 */     this.backingMap = backingMap;
/*  35: 74 */     this.factory = factory;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*  39:    */   {
/*  40: 81 */     return (rowKey != null) && (columnKey != null) && (super.contains(rowKey, columnKey));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean containsColumn(@Nullable Object columnKey)
/*  44:    */   {
/*  45: 85 */     if (columnKey == null) {
/*  46: 86 */       return false;
/*  47:    */     }
/*  48: 88 */     for (Map<C, V> map : this.backingMap.values()) {
/*  49: 89 */       if (Maps.safeContainsKey(map, columnKey)) {
/*  50: 90 */         return true;
/*  51:    */       }
/*  52:    */     }
/*  53: 93 */     return false;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean containsRow(@Nullable Object rowKey)
/*  57:    */   {
/*  58: 97 */     return (rowKey != null) && (Maps.safeContainsKey(this.backingMap, rowKey));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean containsValue(@Nullable Object value)
/*  62:    */   {
/*  63:101 */     return (value != null) && (super.containsValue(value));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/*  67:    */   {
/*  68:105 */     return (rowKey == null) || (columnKey == null) ? null : super.get(rowKey, columnKey);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isEmpty()
/*  72:    */   {
/*  73:111 */     return this.backingMap.isEmpty();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public int size()
/*  77:    */   {
/*  78:115 */     int size = 0;
/*  79:116 */     for (Map<C, V> map : this.backingMap.values()) {
/*  80:117 */       size += map.size();
/*  81:    */     }
/*  82:119 */     return size;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void clear()
/*  86:    */   {
/*  87:125 */     this.backingMap.clear();
/*  88:    */   }
/*  89:    */   
/*  90:    */   private Map<C, V> getOrCreate(R rowKey)
/*  91:    */   {
/*  92:129 */     Map<C, V> map = (Map)this.backingMap.get(rowKey);
/*  93:130 */     if (map == null)
/*  94:    */     {
/*  95:131 */       map = (Map)this.factory.get();
/*  96:132 */       this.backingMap.put(rowKey, map);
/*  97:    */     }
/*  98:134 */     return map;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public V put(R rowKey, C columnKey, V value)
/* 102:    */   {
/* 103:138 */     Preconditions.checkNotNull(rowKey);
/* 104:139 */     Preconditions.checkNotNull(columnKey);
/* 105:140 */     Preconditions.checkNotNull(value);
/* 106:141 */     return getOrCreate(rowKey).put(columnKey, value);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/* 110:    */   {
/* 111:146 */     if ((rowKey == null) || (columnKey == null)) {
/* 112:147 */       return null;
/* 113:    */     }
/* 114:149 */     Map<C, V> map = (Map)Maps.safeGet(this.backingMap, rowKey);
/* 115:150 */     if (map == null) {
/* 116:151 */       return null;
/* 117:    */     }
/* 118:153 */     V value = map.remove(columnKey);
/* 119:154 */     if (map.isEmpty()) {
/* 120:155 */       this.backingMap.remove(rowKey);
/* 121:    */     }
/* 122:157 */     return value;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private Map<R, V> removeColumn(Object column)
/* 126:    */   {
/* 127:161 */     Map<R, V> output = new LinkedHashMap();
/* 128:162 */     Iterator<Map.Entry<R, Map<C, V>>> iterator = this.backingMap.entrySet().iterator();
/* 129:164 */     while (iterator.hasNext())
/* 130:    */     {
/* 131:165 */       Map.Entry<R, Map<C, V>> entry = (Map.Entry)iterator.next();
/* 132:166 */       V value = ((Map)entry.getValue()).remove(column);
/* 133:167 */       if (value != null)
/* 134:    */       {
/* 135:168 */         output.put(entry.getKey(), value);
/* 136:169 */         if (((Map)entry.getValue()).isEmpty()) {
/* 137:170 */           iterator.remove();
/* 138:    */         }
/* 139:    */       }
/* 140:    */     }
/* 141:174 */     return output;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private boolean containsMapping(Object rowKey, Object columnKey, Object value)
/* 145:    */   {
/* 146:179 */     return (value != null) && (value.equals(get(rowKey, columnKey)));
/* 147:    */   }
/* 148:    */   
/* 149:    */   private boolean removeMapping(Object rowKey, Object columnKey, Object value)
/* 150:    */   {
/* 151:184 */     if (containsMapping(rowKey, columnKey, value))
/* 152:    */     {
/* 153:185 */       remove(rowKey, columnKey);
/* 154:186 */       return true;
/* 155:    */     }
/* 156:188 */     return false;
/* 157:    */   }
/* 158:    */   
/* 159:    */   private abstract class TableSet<T>
/* 160:    */     extends Sets.ImprovedAbstractSet<T>
/* 161:    */   {
/* 162:    */     private TableSet() {}
/* 163:    */     
/* 164:    */     public boolean isEmpty()
/* 165:    */     {
/* 166:199 */       return StandardTable.this.backingMap.isEmpty();
/* 167:    */     }
/* 168:    */     
/* 169:    */     public void clear()
/* 170:    */     {
/* 171:203 */       StandardTable.this.backingMap.clear();
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public Set<Table.Cell<R, C, V>> cellSet()
/* 176:    */   {
/* 177:218 */     return super.cellSet();
/* 178:    */   }
/* 179:    */   
/* 180:    */   Iterator<Table.Cell<R, C, V>> cellIterator()
/* 181:    */   {
/* 182:222 */     return new CellIterator(null);
/* 183:    */   }
/* 184:    */   
/* 185:    */   private class CellIterator
/* 186:    */     implements Iterator<Table.Cell<R, C, V>>
/* 187:    */   {
/* 188:226 */     final Iterator<Map.Entry<R, Map<C, V>>> rowIterator = StandardTable.this.backingMap.entrySet().iterator();
/* 189:    */     Map.Entry<R, Map<C, V>> rowEntry;
/* 190:229 */     Iterator<Map.Entry<C, V>> columnIterator = Iterators.emptyModifiableIterator();
/* 191:    */     
/* 192:    */     private CellIterator() {}
/* 193:    */     
/* 194:    */     public boolean hasNext()
/* 195:    */     {
/* 196:233 */       return (this.rowIterator.hasNext()) || (this.columnIterator.hasNext());
/* 197:    */     }
/* 198:    */     
/* 199:    */     public Table.Cell<R, C, V> next()
/* 200:    */     {
/* 201:237 */       if (!this.columnIterator.hasNext())
/* 202:    */       {
/* 203:238 */         this.rowEntry = ((Map.Entry)this.rowIterator.next());
/* 204:239 */         this.columnIterator = ((Map)this.rowEntry.getValue()).entrySet().iterator();
/* 205:    */       }
/* 206:241 */       Map.Entry<C, V> columnEntry = (Map.Entry)this.columnIterator.next();
/* 207:242 */       return Tables.immutableCell(this.rowEntry.getKey(), columnEntry.getKey(), columnEntry.getValue());
/* 208:    */     }
/* 209:    */     
/* 210:    */     public void remove()
/* 211:    */     {
/* 212:247 */       this.columnIterator.remove();
/* 213:248 */       if (((Map)this.rowEntry.getValue()).isEmpty()) {
/* 214:249 */         this.rowIterator.remove();
/* 215:    */       }
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   public Map<C, V> row(R rowKey)
/* 220:    */   {
/* 221:255 */     return new Row(rowKey);
/* 222:    */   }
/* 223:    */   
/* 224:    */   class Row
/* 225:    */     extends Maps.ImprovedAbstractMap<C, V>
/* 226:    */   {
/* 227:    */     final R rowKey;
/* 228:    */     Map<C, V> backingRowMap;
/* 229:    */     
/* 230:    */     Row()
/* 231:    */     {
/* 232:262 */       this.rowKey = Preconditions.checkNotNull(rowKey);
/* 233:    */     }
/* 234:    */     
/* 235:    */     Map<C, V> backingRowMap()
/* 236:    */     {
/* 237:268 */       return (this.backingRowMap == null) || ((this.backingRowMap.isEmpty()) && (StandardTable.this.backingMap.containsKey(this.rowKey))) ? (this.backingRowMap = computeBackingRowMap()) : this.backingRowMap;
/* 238:    */     }
/* 239:    */     
/* 240:    */     Map<C, V> computeBackingRowMap()
/* 241:    */     {
/* 242:275 */       return (Map)StandardTable.this.backingMap.get(this.rowKey);
/* 243:    */     }
/* 244:    */     
/* 245:    */     void maintainEmptyInvariant()
/* 246:    */     {
/* 247:280 */       if ((backingRowMap() != null) && (this.backingRowMap.isEmpty()))
/* 248:    */       {
/* 249:281 */         StandardTable.this.backingMap.remove(this.rowKey);
/* 250:282 */         this.backingRowMap = null;
/* 251:    */       }
/* 252:    */     }
/* 253:    */     
/* 254:    */     public boolean containsKey(Object key)
/* 255:    */     {
/* 256:288 */       Map<C, V> backingRowMap = backingRowMap();
/* 257:289 */       return (key != null) && (backingRowMap != null) && (Maps.safeContainsKey(backingRowMap, key));
/* 258:    */     }
/* 259:    */     
/* 260:    */     public V get(Object key)
/* 261:    */     {
/* 262:295 */       Map<C, V> backingRowMap = backingRowMap();
/* 263:296 */       return (key != null) && (backingRowMap != null) ? Maps.safeGet(backingRowMap, key) : null;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public V put(C key, V value)
/* 267:    */     {
/* 268:303 */       Preconditions.checkNotNull(key);
/* 269:304 */       Preconditions.checkNotNull(value);
/* 270:305 */       if ((this.backingRowMap != null) && (!this.backingRowMap.isEmpty())) {
/* 271:306 */         return this.backingRowMap.put(key, value);
/* 272:    */       }
/* 273:308 */       return StandardTable.this.put(this.rowKey, key, value);
/* 274:    */     }
/* 275:    */     
/* 276:    */     public V remove(Object key)
/* 277:    */     {
/* 278:313 */       Map<C, V> backingRowMap = backingRowMap();
/* 279:314 */       if (backingRowMap == null) {
/* 280:315 */         return null;
/* 281:    */       }
/* 282:317 */       V result = Maps.safeRemove(backingRowMap, key);
/* 283:318 */       maintainEmptyInvariant();
/* 284:319 */       return result;
/* 285:    */     }
/* 286:    */     
/* 287:    */     public void clear()
/* 288:    */     {
/* 289:324 */       Map<C, V> backingRowMap = backingRowMap();
/* 290:325 */       if (backingRowMap != null) {
/* 291:326 */         backingRowMap.clear();
/* 292:    */       }
/* 293:328 */       maintainEmptyInvariant();
/* 294:    */     }
/* 295:    */     
/* 296:    */     protected Set<Map.Entry<C, V>> createEntrySet()
/* 297:    */     {
/* 298:333 */       return new RowEntrySet(null);
/* 299:    */     }
/* 300:    */     
/* 301:    */     private final class RowEntrySet
/* 302:    */       extends Maps.EntrySet<C, V>
/* 303:    */     {
/* 304:    */       private RowEntrySet() {}
/* 305:    */       
/* 306:    */       Map<C, V> map()
/* 307:    */       {
/* 308:339 */         return StandardTable.Row.this;
/* 309:    */       }
/* 310:    */       
/* 311:    */       public int size()
/* 312:    */       {
/* 313:344 */         Map<C, V> map = StandardTable.Row.this.backingRowMap();
/* 314:345 */         return map == null ? 0 : map.size();
/* 315:    */       }
/* 316:    */       
/* 317:    */       public Iterator<Map.Entry<C, V>> iterator()
/* 318:    */       {
/* 319:350 */         Map<C, V> map = StandardTable.Row.this.backingRowMap();
/* 320:351 */         if (map == null) {
/* 321:352 */           return Iterators.emptyModifiableIterator();
/* 322:    */         }
/* 323:354 */         final Iterator<Map.Entry<C, V>> iterator = map.entrySet().iterator();
/* 324:355 */         new Iterator()
/* 325:    */         {
/* 326:    */           public boolean hasNext()
/* 327:    */           {
/* 328:357 */             return iterator.hasNext();
/* 329:    */           }
/* 330:    */           
/* 331:    */           public Map.Entry<C, V> next()
/* 332:    */           {
/* 333:360 */             final Map.Entry<C, V> entry = (Map.Entry)iterator.next();
/* 334:361 */             new ForwardingMapEntry()
/* 335:    */             {
/* 336:    */               protected Map.Entry<C, V> delegate()
/* 337:    */               {
/* 338:363 */                 return entry;
/* 339:    */               }
/* 340:    */               
/* 341:    */               public V setValue(V value)
/* 342:    */               {
/* 343:366 */                 return super.setValue(Preconditions.checkNotNull(value));
/* 344:    */               }
/* 345:    */               
/* 346:    */               public boolean equals(Object object)
/* 347:    */               {
/* 348:371 */                 return standardEquals(object);
/* 349:    */               }
/* 350:    */             };
/* 351:    */           }
/* 352:    */           
/* 353:    */           public void remove()
/* 354:    */           {
/* 355:378 */             iterator.remove();
/* 356:379 */             StandardTable.Row.this.maintainEmptyInvariant();
/* 357:    */           }
/* 358:    */         };
/* 359:    */       }
/* 360:    */     }
/* 361:    */   }
/* 362:    */   
/* 363:    */   public Map<R, V> column(C columnKey)
/* 364:    */   {
/* 365:393 */     return new Column(columnKey);
/* 366:    */   }
/* 367:    */   
/* 368:    */   private class Column
/* 369:    */     extends Maps.ImprovedAbstractMap<R, V>
/* 370:    */   {
/* 371:    */     final C columnKey;
/* 372:    */     
/* 373:    */     Column()
/* 374:    */     {
/* 375:400 */       this.columnKey = Preconditions.checkNotNull(columnKey);
/* 376:    */     }
/* 377:    */     
/* 378:    */     public V put(R key, V value)
/* 379:    */     {
/* 380:404 */       return StandardTable.this.put(key, this.columnKey, value);
/* 381:    */     }
/* 382:    */     
/* 383:    */     public V get(Object key)
/* 384:    */     {
/* 385:408 */       return StandardTable.this.get(key, this.columnKey);
/* 386:    */     }
/* 387:    */     
/* 388:    */     public boolean containsKey(Object key)
/* 389:    */     {
/* 390:412 */       return StandardTable.this.contains(key, this.columnKey);
/* 391:    */     }
/* 392:    */     
/* 393:    */     public V remove(Object key)
/* 394:    */     {
/* 395:416 */       return StandardTable.this.remove(key, this.columnKey);
/* 396:    */     }
/* 397:    */     
/* 398:    */     boolean removeFromColumnIf(Predicate<? super Map.Entry<R, V>> predicate)
/* 399:    */     {
/* 400:424 */       boolean changed = false;
/* 401:425 */       Iterator<Map.Entry<R, Map<C, V>>> iterator = StandardTable.this.backingMap.entrySet().iterator();
/* 402:427 */       while (iterator.hasNext())
/* 403:    */       {
/* 404:428 */         Map.Entry<R, Map<C, V>> entry = (Map.Entry)iterator.next();
/* 405:429 */         Map<C, V> map = (Map)entry.getValue();
/* 406:430 */         V value = map.get(this.columnKey);
/* 407:431 */         if ((value != null) && (predicate.apply(Maps.immutableEntry(entry.getKey(), value))))
/* 408:    */         {
/* 409:433 */           map.remove(this.columnKey);
/* 410:434 */           changed = true;
/* 411:435 */           if (map.isEmpty()) {
/* 412:436 */             iterator.remove();
/* 413:    */           }
/* 414:    */         }
/* 415:    */       }
/* 416:440 */       return changed;
/* 417:    */     }
/* 418:    */     
/* 419:    */     Set<Map.Entry<R, V>> createEntrySet()
/* 420:    */     {
/* 421:444 */       return new EntrySet(null);
/* 422:    */     }
/* 423:    */     
/* 424:    */     private class EntrySet
/* 425:    */       extends Sets.ImprovedAbstractSet<Map.Entry<R, V>>
/* 426:    */     {
/* 427:    */       private EntrySet() {}
/* 428:    */       
/* 429:    */       public Iterator<Map.Entry<R, V>> iterator()
/* 430:    */       {
/* 431:449 */         return new StandardTable.Column.EntrySetIterator(StandardTable.Column.this, null);
/* 432:    */       }
/* 433:    */       
/* 434:    */       public int size()
/* 435:    */       {
/* 436:453 */         int size = 0;
/* 437:454 */         for (Map<C, V> map : StandardTable.this.backingMap.values()) {
/* 438:455 */           if (map.containsKey(StandardTable.Column.this.columnKey)) {
/* 439:456 */             size++;
/* 440:    */           }
/* 441:    */         }
/* 442:459 */         return size;
/* 443:    */       }
/* 444:    */       
/* 445:    */       public boolean isEmpty()
/* 446:    */       {
/* 447:463 */         return !StandardTable.this.containsColumn(StandardTable.Column.this.columnKey);
/* 448:    */       }
/* 449:    */       
/* 450:    */       public void clear()
/* 451:    */       {
/* 452:467 */         StandardTable.Column.this.removeFromColumnIf(Predicates.alwaysTrue());
/* 453:    */       }
/* 454:    */       
/* 455:    */       public boolean contains(Object o)
/* 456:    */       {
/* 457:471 */         if ((o instanceof Map.Entry))
/* 458:    */         {
/* 459:472 */           Map.Entry<?, ?> entry = (Map.Entry)o;
/* 460:473 */           return StandardTable.this.containsMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/* 461:    */         }
/* 462:475 */         return false;
/* 463:    */       }
/* 464:    */       
/* 465:    */       public boolean remove(Object obj)
/* 466:    */       {
/* 467:479 */         if ((obj instanceof Map.Entry))
/* 468:    */         {
/* 469:480 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 470:481 */           return StandardTable.this.removeMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/* 471:    */         }
/* 472:483 */         return false;
/* 473:    */       }
/* 474:    */       
/* 475:    */       public boolean retainAll(Collection<?> c)
/* 476:    */       {
/* 477:487 */         return StandardTable.Column.this.removeFromColumnIf(Predicates.not(Predicates.in(c)));
/* 478:    */       }
/* 479:    */     }
/* 480:    */     
/* 481:    */     private class EntrySetIterator
/* 482:    */       extends AbstractIterator<Map.Entry<R, V>>
/* 483:    */     {
/* 484:492 */       final Iterator<Map.Entry<R, Map<C, V>>> iterator = StandardTable.this.backingMap.entrySet().iterator();
/* 485:    */       
/* 486:    */       private EntrySetIterator() {}
/* 487:    */       
/* 488:    */       protected Map.Entry<R, V> computeNext()
/* 489:    */       {
/* 490:495 */         while (this.iterator.hasNext())
/* 491:    */         {
/* 492:496 */           final Map.Entry<R, Map<C, V>> entry = (Map.Entry)this.iterator.next();
/* 493:497 */           if (((Map)entry.getValue()).containsKey(StandardTable.Column.this.columnKey)) {
/* 494:498 */             new AbstractMapEntry()
/* 495:    */             {
/* 496:    */               public R getKey()
/* 497:    */               {
/* 498:500 */                 return entry.getKey();
/* 499:    */               }
/* 500:    */               
/* 501:    */               public V getValue()
/* 502:    */               {
/* 503:503 */                 return ((Map)entry.getValue()).get(StandardTable.Column.this.columnKey);
/* 504:    */               }
/* 505:    */               
/* 506:    */               public V setValue(V value)
/* 507:    */               {
/* 508:506 */                 return ((Map)entry.getValue()).put(StandardTable.Column.this.columnKey, Preconditions.checkNotNull(value));
/* 509:    */               }
/* 510:    */             };
/* 511:    */           }
/* 512:    */         }
/* 513:511 */         return (Map.Entry)endOfData();
/* 514:    */       }
/* 515:    */     }
/* 516:    */     
/* 517:    */     Set<R> createKeySet()
/* 518:    */     {
/* 519:516 */       return new KeySet();
/* 520:    */     }
/* 521:    */     
/* 522:    */     private class KeySet
/* 523:    */       extends Maps.KeySet<R, V>
/* 524:    */     {
/* 525:    */       KeySet()
/* 526:    */       {
/* 527:521 */         super();
/* 528:    */       }
/* 529:    */       
/* 530:    */       public boolean contains(Object obj)
/* 531:    */       {
/* 532:525 */         return StandardTable.this.contains(obj, StandardTable.Column.this.columnKey);
/* 533:    */       }
/* 534:    */       
/* 535:    */       public boolean remove(Object obj)
/* 536:    */       {
/* 537:529 */         return StandardTable.this.remove(obj, StandardTable.Column.this.columnKey) != null;
/* 538:    */       }
/* 539:    */       
/* 540:    */       public boolean retainAll(Collection<?> c)
/* 541:    */       {
/* 542:533 */         return StandardTable.Column.this.removeFromColumnIf(Maps.keyPredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 543:    */       }
/* 544:    */     }
/* 545:    */     
/* 546:    */     Collection<V> createValues()
/* 547:    */     {
/* 548:539 */       return new Values();
/* 549:    */     }
/* 550:    */     
/* 551:    */     private class Values
/* 552:    */       extends Maps.Values<R, V>
/* 553:    */     {
/* 554:    */       Values()
/* 555:    */       {
/* 556:544 */         super();
/* 557:    */       }
/* 558:    */       
/* 559:    */       public boolean remove(Object obj)
/* 560:    */       {
/* 561:548 */         return (obj != null) && (StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.equalTo(obj))));
/* 562:    */       }
/* 563:    */       
/* 564:    */       public boolean removeAll(Collection<?> c)
/* 565:    */       {
/* 566:552 */         return StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.in(c)));
/* 567:    */       }
/* 568:    */       
/* 569:    */       public boolean retainAll(Collection<?> c)
/* 570:    */       {
/* 571:556 */         return StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 572:    */       }
/* 573:    */     }
/* 574:    */   }
/* 575:    */   
/* 576:    */   public Set<R> rowKeySet()
/* 577:    */   {
/* 578:562 */     return rowMap().keySet();
/* 579:    */   }
/* 580:    */   
/* 581:    */   public Set<C> columnKeySet()
/* 582:    */   {
/* 583:578 */     Set<C> result = this.columnKeySet;
/* 584:579 */     return result == null ? (this.columnKeySet = new ColumnKeySet(null)) : result;
/* 585:    */   }
/* 586:    */   
/* 587:    */   private class ColumnKeySet
/* 588:    */     extends StandardTable<R, C, V>.TableSet<C>
/* 589:    */   {
/* 590:    */     private ColumnKeySet()
/* 591:    */     {
/* 592:582 */       super(null);
/* 593:    */     }
/* 594:    */     
/* 595:    */     public Iterator<C> iterator()
/* 596:    */     {
/* 597:584 */       return StandardTable.this.createColumnKeyIterator();
/* 598:    */     }
/* 599:    */     
/* 600:    */     public int size()
/* 601:    */     {
/* 602:588 */       return Iterators.size(iterator());
/* 603:    */     }
/* 604:    */     
/* 605:    */     public boolean remove(Object obj)
/* 606:    */     {
/* 607:592 */       if (obj == null) {
/* 608:593 */         return false;
/* 609:    */       }
/* 610:595 */       boolean changed = false;
/* 611:596 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 612:597 */       while (iterator.hasNext())
/* 613:    */       {
/* 614:598 */         Map<C, V> map = (Map)iterator.next();
/* 615:599 */         if (map.keySet().remove(obj))
/* 616:    */         {
/* 617:600 */           changed = true;
/* 618:601 */           if (map.isEmpty()) {
/* 619:602 */             iterator.remove();
/* 620:    */           }
/* 621:    */         }
/* 622:    */       }
/* 623:606 */       return changed;
/* 624:    */     }
/* 625:    */     
/* 626:    */     public boolean removeAll(Collection<?> c)
/* 627:    */     {
/* 628:610 */       Preconditions.checkNotNull(c);
/* 629:611 */       boolean changed = false;
/* 630:612 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 631:613 */       while (iterator.hasNext())
/* 632:    */       {
/* 633:614 */         Map<C, V> map = (Map)iterator.next();
/* 634:617 */         if (Iterators.removeAll(map.keySet().iterator(), c))
/* 635:    */         {
/* 636:618 */           changed = true;
/* 637:619 */           if (map.isEmpty()) {
/* 638:620 */             iterator.remove();
/* 639:    */           }
/* 640:    */         }
/* 641:    */       }
/* 642:624 */       return changed;
/* 643:    */     }
/* 644:    */     
/* 645:    */     public boolean retainAll(Collection<?> c)
/* 646:    */     {
/* 647:628 */       Preconditions.checkNotNull(c);
/* 648:629 */       boolean changed = false;
/* 649:630 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 650:631 */       while (iterator.hasNext())
/* 651:    */       {
/* 652:632 */         Map<C, V> map = (Map)iterator.next();
/* 653:633 */         if (map.keySet().retainAll(c))
/* 654:    */         {
/* 655:634 */           changed = true;
/* 656:635 */           if (map.isEmpty()) {
/* 657:636 */             iterator.remove();
/* 658:    */           }
/* 659:    */         }
/* 660:    */       }
/* 661:640 */       return changed;
/* 662:    */     }
/* 663:    */     
/* 664:    */     public boolean contains(Object obj)
/* 665:    */     {
/* 666:644 */       return StandardTable.this.containsColumn(obj);
/* 667:    */     }
/* 668:    */   }
/* 669:    */   
/* 670:    */   Iterator<C> createColumnKeyIterator()
/* 671:    */   {
/* 672:653 */     return new ColumnKeyIterator(null);
/* 673:    */   }
/* 674:    */   
/* 675:    */   private class ColumnKeyIterator
/* 676:    */     extends AbstractIterator<C>
/* 677:    */   {
/* 678:659 */     final Map<C, V> seen = (Map)StandardTable.this.factory.get();
/* 679:660 */     final Iterator<Map<C, V>> mapIterator = StandardTable.this.backingMap.values().iterator();
/* 680:661 */     Iterator<Map.Entry<C, V>> entryIterator = Iterators.emptyIterator();
/* 681:    */     
/* 682:    */     private ColumnKeyIterator() {}
/* 683:    */     
/* 684:    */     protected C computeNext()
/* 685:    */     {
/* 686:    */       for (;;)
/* 687:    */       {
/* 688:665 */         if (this.entryIterator.hasNext())
/* 689:    */         {
/* 690:666 */           Map.Entry<C, V> entry = (Map.Entry)this.entryIterator.next();
/* 691:667 */           if (!this.seen.containsKey(entry.getKey()))
/* 692:    */           {
/* 693:668 */             this.seen.put(entry.getKey(), entry.getValue());
/* 694:669 */             return entry.getKey();
/* 695:    */           }
/* 696:    */         }
/* 697:    */         else
/* 698:    */         {
/* 699:671 */           if (!this.mapIterator.hasNext()) {
/* 700:    */             break;
/* 701:    */           }
/* 702:672 */           this.entryIterator = ((Map)this.mapIterator.next()).entrySet().iterator();
/* 703:    */         }
/* 704:    */       }
/* 705:674 */       return endOfData();
/* 706:    */     }
/* 707:    */   }
/* 708:    */   
/* 709:    */   public Collection<V> values()
/* 710:    */   {
/* 711:687 */     return super.values();
/* 712:    */   }
/* 713:    */   
/* 714:    */   public Map<R, Map<C, V>> rowMap()
/* 715:    */   {
/* 716:693 */     Map<R, Map<C, V>> result = this.rowMap;
/* 717:694 */     return result == null ? (this.rowMap = createRowMap()) : result;
/* 718:    */   }
/* 719:    */   
/* 720:    */   Map<R, Map<C, V>> createRowMap()
/* 721:    */   {
/* 722:698 */     return new RowMap();
/* 723:    */   }
/* 724:    */   
/* 725:    */   class RowMap
/* 726:    */     extends Maps.ImprovedAbstractMap<R, Map<C, V>>
/* 727:    */   {
/* 728:    */     RowMap() {}
/* 729:    */     
/* 730:    */     public boolean containsKey(Object key)
/* 731:    */     {
/* 732:703 */       return StandardTable.this.containsRow(key);
/* 733:    */     }
/* 734:    */     
/* 735:    */     public Map<C, V> get(Object key)
/* 736:    */     {
/* 737:709 */       return StandardTable.this.containsRow(key) ? StandardTable.this.row(key) : null;
/* 738:    */     }
/* 739:    */     
/* 740:    */     public Map<C, V> remove(Object key)
/* 741:    */     {
/* 742:713 */       return key == null ? null : (Map)StandardTable.this.backingMap.remove(key);
/* 743:    */     }
/* 744:    */     
/* 745:    */     protected Set<Map.Entry<R, Map<C, V>>> createEntrySet()
/* 746:    */     {
/* 747:717 */       return new EntrySet();
/* 748:    */     }
/* 749:    */     
/* 750:    */     class EntrySet
/* 751:    */       extends StandardTable<R, C, V>.TableSet<Map.Entry<R, Map<C, V>>>
/* 752:    */     {
/* 753:    */       EntrySet()
/* 754:    */       {
/* 755:720 */         super(null);
/* 756:    */       }
/* 757:    */       
/* 758:    */       public Iterator<Map.Entry<R, Map<C, V>>> iterator()
/* 759:    */       {
/* 760:722 */         Maps.asMapEntryIterator(StandardTable.this.backingMap.keySet(), new Function()
/* 761:    */         {
/* 762:    */           public Map<C, V> apply(R rowKey)
/* 763:    */           {
/* 764:725 */             return StandardTable.this.row(rowKey);
/* 765:    */           }
/* 766:    */         });
/* 767:    */       }
/* 768:    */       
/* 769:    */       public int size()
/* 770:    */       {
/* 771:731 */         return StandardTable.this.backingMap.size();
/* 772:    */       }
/* 773:    */       
/* 774:    */       public boolean contains(Object obj)
/* 775:    */       {
/* 776:735 */         if ((obj instanceof Map.Entry))
/* 777:    */         {
/* 778:736 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 779:737 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (Collections2.safeContains(StandardTable.this.backingMap.entrySet(), entry));
/* 780:    */         }
/* 781:741 */         return false;
/* 782:    */       }
/* 783:    */       
/* 784:    */       public boolean remove(Object obj)
/* 785:    */       {
/* 786:745 */         if ((obj instanceof Map.Entry))
/* 787:    */         {
/* 788:746 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 789:747 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (StandardTable.this.backingMap.entrySet().remove(entry));
/* 790:    */         }
/* 791:751 */         return false;
/* 792:    */       }
/* 793:    */     }
/* 794:    */   }
/* 795:    */   
/* 796:    */   public Map<C, Map<R, V>> columnMap()
/* 797:    */   {
/* 798:759 */     StandardTable<R, C, V>.ColumnMap result = this.columnMap;
/* 799:760 */     return result == null ? (this.columnMap = new ColumnMap(null)) : result;
/* 800:    */   }
/* 801:    */   
/* 802:    */   private class ColumnMap
/* 803:    */     extends Maps.ImprovedAbstractMap<C, Map<R, V>>
/* 804:    */   {
/* 805:    */     private ColumnMap() {}
/* 806:    */     
/* 807:    */     public Map<R, V> get(Object key)
/* 808:    */     {
/* 809:768 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.column(key) : null;
/* 810:    */     }
/* 811:    */     
/* 812:    */     public boolean containsKey(Object key)
/* 813:    */     {
/* 814:772 */       return StandardTable.this.containsColumn(key);
/* 815:    */     }
/* 816:    */     
/* 817:    */     public Map<R, V> remove(Object key)
/* 818:    */     {
/* 819:776 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.removeColumn(key) : null;
/* 820:    */     }
/* 821:    */     
/* 822:    */     public Set<Map.Entry<C, Map<R, V>>> createEntrySet()
/* 823:    */     {
/* 824:780 */       return new ColumnMapEntrySet();
/* 825:    */     }
/* 826:    */     
/* 827:    */     public Set<C> keySet()
/* 828:    */     {
/* 829:784 */       return StandardTable.this.columnKeySet();
/* 830:    */     }
/* 831:    */     
/* 832:    */     Collection<Map<R, V>> createValues()
/* 833:    */     {
/* 834:788 */       return new ColumnMapValues();
/* 835:    */     }
/* 836:    */     
/* 837:    */     class ColumnMapEntrySet
/* 838:    */       extends StandardTable<R, C, V>.TableSet<Map.Entry<C, Map<R, V>>>
/* 839:    */     {
/* 840:    */       ColumnMapEntrySet()
/* 841:    */       {
/* 842:791 */         super(null);
/* 843:    */       }
/* 844:    */       
/* 845:    */       public Iterator<Map.Entry<C, Map<R, V>>> iterator()
/* 846:    */       {
/* 847:793 */         Maps.asMapEntryIterator(StandardTable.this.columnKeySet(), new Function()
/* 848:    */         {
/* 849:    */           public Map<R, V> apply(C columnKey)
/* 850:    */           {
/* 851:796 */             return StandardTable.this.column(columnKey);
/* 852:    */           }
/* 853:    */         });
/* 854:    */       }
/* 855:    */       
/* 856:    */       public int size()
/* 857:    */       {
/* 858:802 */         return StandardTable.this.columnKeySet().size();
/* 859:    */       }
/* 860:    */       
/* 861:    */       public boolean contains(Object obj)
/* 862:    */       {
/* 863:806 */         if ((obj instanceof Map.Entry))
/* 864:    */         {
/* 865:807 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 866:808 */           if (StandardTable.this.containsColumn(entry.getKey()))
/* 867:    */           {
/* 868:812 */             C columnKey = entry.getKey();
/* 869:813 */             return StandardTable.ColumnMap.this.get(columnKey).equals(entry.getValue());
/* 870:    */           }
/* 871:    */         }
/* 872:816 */         return false;
/* 873:    */       }
/* 874:    */       
/* 875:    */       public boolean remove(Object obj)
/* 876:    */       {
/* 877:820 */         if (contains(obj))
/* 878:    */         {
/* 879:821 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 880:822 */           StandardTable.this.removeColumn(entry.getKey());
/* 881:823 */           return true;
/* 882:    */         }
/* 883:825 */         return false;
/* 884:    */       }
/* 885:    */       
/* 886:    */       public boolean removeAll(Collection<?> c)
/* 887:    */       {
/* 888:835 */         Preconditions.checkNotNull(c);
/* 889:836 */         return Sets.removeAllImpl(this, c.iterator());
/* 890:    */       }
/* 891:    */       
/* 892:    */       public boolean retainAll(Collection<?> c)
/* 893:    */       {
/* 894:840 */         Preconditions.checkNotNull(c);
/* 895:841 */         boolean changed = false;
/* 896:842 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 897:843 */           if (!c.contains(Maps.immutableEntry(columnKey, StandardTable.this.column(columnKey))))
/* 898:    */           {
/* 899:844 */             StandardTable.this.removeColumn(columnKey);
/* 900:845 */             changed = true;
/* 901:    */           }
/* 902:    */         }
/* 903:848 */         return changed;
/* 904:    */       }
/* 905:    */     }
/* 906:    */     
/* 907:    */     private class ColumnMapValues
/* 908:    */       extends Maps.Values<C, Map<R, V>>
/* 909:    */     {
/* 910:    */       ColumnMapValues()
/* 911:    */       {
/* 912:854 */         super();
/* 913:    */       }
/* 914:    */       
/* 915:    */       public boolean remove(Object obj)
/* 916:    */       {
/* 917:858 */         for (Map.Entry<C, Map<R, V>> entry : StandardTable.ColumnMap.this.entrySet()) {
/* 918:859 */           if (((Map)entry.getValue()).equals(obj))
/* 919:    */           {
/* 920:860 */             StandardTable.this.removeColumn(entry.getKey());
/* 921:861 */             return true;
/* 922:    */           }
/* 923:    */         }
/* 924:864 */         return false;
/* 925:    */       }
/* 926:    */       
/* 927:    */       public boolean removeAll(Collection<?> c)
/* 928:    */       {
/* 929:868 */         Preconditions.checkNotNull(c);
/* 930:869 */         boolean changed = false;
/* 931:870 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 932:871 */           if (c.contains(StandardTable.this.column(columnKey)))
/* 933:    */           {
/* 934:872 */             StandardTable.this.removeColumn(columnKey);
/* 935:873 */             changed = true;
/* 936:    */           }
/* 937:    */         }
/* 938:876 */         return changed;
/* 939:    */       }
/* 940:    */       
/* 941:    */       public boolean retainAll(Collection<?> c)
/* 942:    */       {
/* 943:880 */         Preconditions.checkNotNull(c);
/* 944:881 */         boolean changed = false;
/* 945:882 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 946:883 */           if (!c.contains(StandardTable.this.column(columnKey)))
/* 947:    */           {
/* 948:884 */             StandardTable.this.removeColumn(columnKey);
/* 949:885 */             changed = true;
/* 950:    */           }
/* 951:    */         }
/* 952:888 */         return changed;
/* 953:    */       }
/* 954:    */     }
/* 955:    */   }
/* 956:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.StandardTable
 * JD-Core Version:    0.7.0.1
 */
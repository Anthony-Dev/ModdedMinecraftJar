/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import java.util.AbstractCollection;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ abstract class AbstractMultiset<E>
/*  13:    */   extends AbstractCollection<E>
/*  14:    */   implements Multiset<E>
/*  15:    */ {
/*  16:    */   private transient Set<E> elementSet;
/*  17:    */   private transient Set<Multiset.Entry<E>> entrySet;
/*  18:    */   
/*  19:    */   public int size()
/*  20:    */   {
/*  21: 52 */     return Multisets.sizeImpl(this);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public boolean isEmpty()
/*  25:    */   {
/*  26: 56 */     return entrySet().isEmpty();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public boolean contains(@Nullable Object element)
/*  30:    */   {
/*  31: 60 */     return count(element) > 0;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Iterator<E> iterator()
/*  35:    */   {
/*  36: 64 */     return Multisets.iteratorImpl(this);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public int count(@Nullable Object element)
/*  40:    */   {
/*  41: 69 */     for (Multiset.Entry<E> entry : entrySet()) {
/*  42: 70 */       if (Objects.equal(entry.getElement(), element)) {
/*  43: 71 */         return entry.getCount();
/*  44:    */       }
/*  45:    */     }
/*  46: 74 */     return 0;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean add(@Nullable E element)
/*  50:    */   {
/*  51: 80 */     add(element, 1);
/*  52: 81 */     return true;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public int add(@Nullable E element, int occurrences)
/*  56:    */   {
/*  57: 86 */     throw new UnsupportedOperationException();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean remove(@Nullable Object element)
/*  61:    */   {
/*  62: 90 */     return remove(element, 1) > 0;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int remove(@Nullable Object element, int occurrences)
/*  66:    */   {
/*  67: 95 */     throw new UnsupportedOperationException();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public int setCount(@Nullable E element, int count)
/*  71:    */   {
/*  72:100 */     return Multisets.setCountImpl(this, element, count);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean setCount(@Nullable E element, int oldCount, int newCount)
/*  76:    */   {
/*  77:105 */     return Multisets.setCountImpl(this, element, oldCount, newCount);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean addAll(Collection<? extends E> elementsToAdd)
/*  81:    */   {
/*  82:117 */     return Multisets.addAllImpl(this, elementsToAdd);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean removeAll(Collection<?> elementsToRemove)
/*  86:    */   {
/*  87:121 */     return Multisets.removeAllImpl(this, elementsToRemove);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean retainAll(Collection<?> elementsToRetain)
/*  91:    */   {
/*  92:125 */     return Multisets.retainAllImpl(this, elementsToRetain);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void clear()
/*  96:    */   {
/*  97:129 */     Iterators.clear(entryIterator());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Set<E> elementSet()
/* 101:    */   {
/* 102:138 */     Set<E> result = this.elementSet;
/* 103:139 */     if (result == null) {
/* 104:140 */       this.elementSet = (result = createElementSet());
/* 105:    */     }
/* 106:142 */     return result;
/* 107:    */   }
/* 108:    */   
/* 109:    */   Set<E> createElementSet()
/* 110:    */   {
/* 111:150 */     return new ElementSet();
/* 112:    */   }
/* 113:    */   
/* 114:    */   abstract Iterator<Multiset.Entry<E>> entryIterator();
/* 115:    */   
/* 116:    */   abstract int distinctElements();
/* 117:    */   
/* 118:    */   class ElementSet
/* 119:    */     extends Multisets.ElementSet<E>
/* 120:    */   {
/* 121:    */     ElementSet() {}
/* 122:    */     
/* 123:    */     Multiset<E> multiset()
/* 124:    */     {
/* 125:156 */       return AbstractMultiset.this;
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Set<Multiset.Entry<E>> entrySet()
/* 130:    */   {
/* 131:167 */     Set<Multiset.Entry<E>> result = this.entrySet;
/* 132:168 */     return result == null ? (this.entrySet = createEntrySet()) : result;
/* 133:    */   }
/* 134:    */   
/* 135:    */   class EntrySet
/* 136:    */     extends Multisets.EntrySet<E>
/* 137:    */   {
/* 138:    */     EntrySet() {}
/* 139:    */     
/* 140:    */     Multiset<E> multiset()
/* 141:    */     {
/* 142:173 */       return AbstractMultiset.this;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public Iterator<Multiset.Entry<E>> iterator()
/* 146:    */     {
/* 147:177 */       return AbstractMultiset.this.entryIterator();
/* 148:    */     }
/* 149:    */     
/* 150:    */     public int size()
/* 151:    */     {
/* 152:181 */       return AbstractMultiset.this.distinctElements();
/* 153:    */     }
/* 154:    */   }
/* 155:    */   
/* 156:    */   Set<Multiset.Entry<E>> createEntrySet()
/* 157:    */   {
/* 158:186 */     return new EntrySet();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean equals(@Nullable Object object)
/* 162:    */   {
/* 163:199 */     return Multisets.equalsImpl(this, object);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public int hashCode()
/* 167:    */   {
/* 168:209 */     return entrySet().hashCode();
/* 169:    */   }
/* 170:    */   
/* 171:    */   public String toString()
/* 172:    */   {
/* 173:219 */     return entrySet().toString();
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractMultiset
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.concurrent.Immutable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ @Immutable
/*  11:    */ final class SparseImmutableTable<R, C, V>
/*  12:    */   extends RegularImmutableTable<R, C, V>
/*  13:    */ {
/*  14:    */   private final ImmutableMap<R, Map<C, V>> rowMap;
/*  15:    */   private final ImmutableMap<C, Map<R, V>> columnMap;
/*  16:    */   private final int[] iterationOrderRow;
/*  17:    */   private final int[] iterationOrderColumn;
/*  18:    */   
/*  19:    */   SparseImmutableTable(ImmutableList<Table.Cell<R, C, V>> cellList, ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace)
/*  20:    */   {
/*  21: 39 */     Map<R, Integer> rowIndex = Maps.newHashMap();
/*  22: 40 */     Map<R, Map<C, V>> rows = Maps.newLinkedHashMap();
/*  23: 41 */     for (R row : rowSpace)
/*  24:    */     {
/*  25: 42 */       rowIndex.put(row, Integer.valueOf(rows.size()));
/*  26: 43 */       rows.put(row, new LinkedHashMap());
/*  27:    */     }
/*  28: 45 */     Map<C, Map<R, V>> columns = Maps.newLinkedHashMap();
/*  29: 46 */     for (C col : columnSpace) {
/*  30: 47 */       columns.put(col, new LinkedHashMap());
/*  31:    */     }
/*  32: 49 */     int[] iterationOrderRow = new int[cellList.size()];
/*  33: 50 */     int[] iterationOrderColumn = new int[cellList.size()];
/*  34: 51 */     for (int i = 0; i < cellList.size(); i++)
/*  35:    */     {
/*  36: 52 */       Table.Cell<R, C, V> cell = (Table.Cell)cellList.get(i);
/*  37: 53 */       R rowKey = cell.getRowKey();
/*  38: 54 */       C columnKey = cell.getColumnKey();
/*  39: 55 */       V value = cell.getValue();
/*  40:    */       
/*  41: 57 */       iterationOrderRow[i] = ((Integer)rowIndex.get(rowKey)).intValue();
/*  42: 58 */       Map<C, V> thisRow = (Map)rows.get(rowKey);
/*  43: 59 */       iterationOrderColumn[i] = thisRow.size();
/*  44: 60 */       V oldValue = thisRow.put(columnKey, value);
/*  45: 61 */       if (oldValue != null) {
/*  46: 62 */         throw new IllegalArgumentException("Duplicate value for row=" + rowKey + ", column=" + columnKey + ": " + value + ", " + oldValue);
/*  47:    */       }
/*  48: 65 */       ((Map)columns.get(columnKey)).put(rowKey, value);
/*  49:    */     }
/*  50: 67 */     this.iterationOrderRow = iterationOrderRow;
/*  51: 68 */     this.iterationOrderColumn = iterationOrderColumn;
/*  52: 69 */     ImmutableMap.Builder<R, Map<C, V>> rowBuilder = ImmutableMap.builder();
/*  53: 70 */     for (Map.Entry<R, Map<C, V>> row : rows.entrySet()) {
/*  54: 71 */       rowBuilder.put(row.getKey(), ImmutableMap.copyOf((Map)row.getValue()));
/*  55:    */     }
/*  56: 73 */     this.rowMap = rowBuilder.build();
/*  57:    */     
/*  58: 75 */     ImmutableMap.Builder<C, Map<R, V>> columnBuilder = ImmutableMap.builder();
/*  59: 76 */     for (Map.Entry<C, Map<R, V>> col : columns.entrySet()) {
/*  60: 77 */       columnBuilder.put(col.getKey(), ImmutableMap.copyOf((Map)col.getValue()));
/*  61:    */     }
/*  62: 79 */     this.columnMap = columnBuilder.build();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public ImmutableMap<C, Map<R, V>> columnMap()
/*  66:    */   {
/*  67: 83 */     return this.columnMap;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public ImmutableMap<R, Map<C, V>> rowMap()
/*  71:    */   {
/*  72: 87 */     return this.rowMap;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int size()
/*  76:    */   {
/*  77: 92 */     return this.iterationOrderRow.length;
/*  78:    */   }
/*  79:    */   
/*  80:    */   Table.Cell<R, C, V> getCell(int index)
/*  81:    */   {
/*  82: 97 */     int rowIndex = this.iterationOrderRow[index];
/*  83: 98 */     Map.Entry<R, Map<C, V>> rowEntry = (Map.Entry)this.rowMap.entrySet().asList().get(rowIndex);
/*  84: 99 */     ImmutableMap<C, V> row = (ImmutableMap)rowEntry.getValue();
/*  85:100 */     int columnIndex = this.iterationOrderColumn[index];
/*  86:101 */     Map.Entry<C, V> colEntry = (Map.Entry)row.entrySet().asList().get(columnIndex);
/*  87:102 */     return cellOf(rowEntry.getKey(), colEntry.getKey(), colEntry.getValue());
/*  88:    */   }
/*  89:    */   
/*  90:    */   V getValue(int index)
/*  91:    */   {
/*  92:107 */     int rowIndex = this.iterationOrderRow[index];
/*  93:108 */     ImmutableMap<C, V> row = (ImmutableMap)this.rowMap.values().asList().get(rowIndex);
/*  94:109 */     int columnIndex = this.iterationOrderColumn[index];
/*  95:110 */     return row.values().asList().get(columnIndex);
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SparseImmutableTable
 * JD-Core Version:    0.7.0.1
 */
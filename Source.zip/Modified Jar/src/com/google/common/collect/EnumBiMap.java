/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.EnumMap;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @GwtCompatible(emulated=true)
/*  16:    */ public final class EnumBiMap<K extends Enum<K>, V extends Enum<V>>
/*  17:    */   extends AbstractBiMap<K, V>
/*  18:    */ {
/*  19:    */   private transient Class<K> keyType;
/*  20:    */   private transient Class<V> valueType;
/*  21:    */   @GwtIncompatible("not needed in emulated source.")
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   public static <K extends Enum<K>, V extends Enum<V>> EnumBiMap<K, V> create(Class<K> keyType, Class<V> valueType)
/*  25:    */   {
/*  26: 58 */     return new EnumBiMap(keyType, valueType);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <K extends Enum<K>, V extends Enum<V>> EnumBiMap<K, V> create(Map<K, V> map)
/*  30:    */   {
/*  31: 73 */     EnumBiMap<K, V> bimap = create(inferKeyType(map), inferValueType(map));
/*  32: 74 */     bimap.putAll(map);
/*  33: 75 */     return bimap;
/*  34:    */   }
/*  35:    */   
/*  36:    */   private EnumBiMap(Class<K> keyType, Class<V> valueType)
/*  37:    */   {
/*  38: 79 */     super(WellBehavedMap.wrap(new EnumMap(keyType)), WellBehavedMap.wrap(new EnumMap(valueType)));
/*  39:    */     
/*  40: 81 */     this.keyType = keyType;
/*  41: 82 */     this.valueType = valueType;
/*  42:    */   }
/*  43:    */   
/*  44:    */   static <K extends Enum<K>> Class<K> inferKeyType(Map<K, ?> map)
/*  45:    */   {
/*  46: 86 */     if ((map instanceof EnumBiMap)) {
/*  47: 87 */       return ((EnumBiMap)map).keyType();
/*  48:    */     }
/*  49: 89 */     if ((map instanceof EnumHashBiMap)) {
/*  50: 90 */       return ((EnumHashBiMap)map).keyType();
/*  51:    */     }
/*  52: 92 */     Preconditions.checkArgument(!map.isEmpty());
/*  53: 93 */     return ((Enum)map.keySet().iterator().next()).getDeclaringClass();
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static <V extends Enum<V>> Class<V> inferValueType(Map<?, V> map)
/*  57:    */   {
/*  58: 97 */     if ((map instanceof EnumBiMap)) {
/*  59: 98 */       return ((EnumBiMap)map).valueType;
/*  60:    */     }
/*  61:100 */     Preconditions.checkArgument(!map.isEmpty());
/*  62:101 */     return ((Enum)map.values().iterator().next()).getDeclaringClass();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Class<K> keyType()
/*  66:    */   {
/*  67:106 */     return this.keyType;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Class<V> valueType()
/*  71:    */   {
/*  72:111 */     return this.valueType;
/*  73:    */   }
/*  74:    */   
/*  75:    */   K checkKey(K key)
/*  76:    */   {
/*  77:116 */     return (Enum)Preconditions.checkNotNull(key);
/*  78:    */   }
/*  79:    */   
/*  80:    */   V checkValue(V value)
/*  81:    */   {
/*  82:121 */     return (Enum)Preconditions.checkNotNull(value);
/*  83:    */   }
/*  84:    */   
/*  85:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  86:    */   private void writeObject(ObjectOutputStream stream)
/*  87:    */     throws IOException
/*  88:    */   {
/*  89:130 */     stream.defaultWriteObject();
/*  90:131 */     stream.writeObject(this.keyType);
/*  91:132 */     stream.writeObject(this.valueType);
/*  92:133 */     Serialization.writeMap(this, stream);
/*  93:    */   }
/*  94:    */   
/*  95:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  96:    */   private void readObject(ObjectInputStream stream)
/*  97:    */     throws IOException, ClassNotFoundException
/*  98:    */   {
/*  99:140 */     stream.defaultReadObject();
/* 100:141 */     this.keyType = ((Class)stream.readObject());
/* 101:142 */     this.valueType = ((Class)stream.readObject());
/* 102:143 */     setDelegates(WellBehavedMap.wrap(new EnumMap(this.keyType)), WellBehavedMap.wrap(new EnumMap(this.valueType)));
/* 103:    */     
/* 104:    */ 
/* 105:146 */     Serialization.populateMap(this, stream);
/* 106:    */   }
/* 107:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EnumBiMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.EnumMap;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableMap<K, V>
/*  16:    */   implements Map<K, V>, Serializable
/*  17:    */ {
/*  18:    */   public static <K, V> ImmutableMap<K, V> of()
/*  19:    */   {
/*  20: 70 */     return ImmutableBiMap.of();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1)
/*  24:    */   {
/*  25: 80 */     return ImmutableBiMap.of(k1, v1);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2)
/*  29:    */   {
/*  30: 89 */     return new RegularImmutableMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  34:    */   {
/*  35: 99 */     return new RegularImmutableMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  39:    */   {
/*  40:110 */     return new RegularImmutableMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  44:    */   {
/*  45:121 */     return new RegularImmutableMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  46:    */   }
/*  47:    */   
/*  48:    */   static <K, V> ImmutableMapEntry.TerminalEntry<K, V> entryOf(K key, V value)
/*  49:    */   {
/*  50:135 */     CollectPreconditions.checkEntryNotNull(key, value);
/*  51:136 */     return new ImmutableMapEntry.TerminalEntry(key, value);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <K, V> Builder<K, V> builder()
/*  55:    */   {
/*  56:144 */     return new Builder();
/*  57:    */   }
/*  58:    */   
/*  59:    */   static void checkNoConflict(boolean safe, String conflictDescription, Map.Entry<?, ?> entry1, Map.Entry<?, ?> entry2)
/*  60:    */   {
/*  61:149 */     if (!safe) {
/*  62:150 */       throw new IllegalArgumentException("Multiple entries with same " + conflictDescription + ": " + entry1 + " and " + entry2);
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static class Builder<K, V>
/*  67:    */   {
/*  68:    */     ImmutableMapEntry.TerminalEntry<K, V>[] entries;
/*  69:    */     int size;
/*  70:    */     
/*  71:    */     public Builder()
/*  72:    */     {
/*  73:184 */       this(4);
/*  74:    */     }
/*  75:    */     
/*  76:    */     Builder(int initialCapacity)
/*  77:    */     {
/*  78:189 */       this.entries = new ImmutableMapEntry.TerminalEntry[initialCapacity];
/*  79:190 */       this.size = 0;
/*  80:    */     }
/*  81:    */     
/*  82:    */     private void ensureCapacity(int minCapacity)
/*  83:    */     {
/*  84:194 */       if (minCapacity > this.entries.length) {
/*  85:195 */         this.entries = ((ImmutableMapEntry.TerminalEntry[])ObjectArrays.arraysCopyOf(this.entries, ImmutableCollection.Builder.expandedCapacity(this.entries.length, minCapacity)));
/*  86:    */       }
/*  87:    */     }
/*  88:    */     
/*  89:    */     public Builder<K, V> put(K key, V value)
/*  90:    */     {
/*  91:205 */       ensureCapacity(this.size + 1);
/*  92:206 */       ImmutableMapEntry.TerminalEntry<K, V> entry = ImmutableMap.entryOf(key, value);
/*  93:    */       
/*  94:208 */       this.entries[(this.size++)] = entry;
/*  95:209 */       return this;
/*  96:    */     }
/*  97:    */     
/*  98:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/*  99:    */     {
/* 100:220 */       return put(entry.getKey(), entry.getValue());
/* 101:    */     }
/* 102:    */     
/* 103:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/* 104:    */     {
/* 105:230 */       ensureCapacity(this.size + map.size());
/* 106:231 */       for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 107:232 */         put(entry);
/* 108:    */       }
/* 109:234 */       return this;
/* 110:    */     }
/* 111:    */     
/* 112:    */     public ImmutableMap<K, V> build()
/* 113:    */     {
/* 114:248 */       switch (this.size)
/* 115:    */       {
/* 116:    */       case 0: 
/* 117:250 */         return ImmutableMap.of();
/* 118:    */       case 1: 
/* 119:252 */         return ImmutableMap.of(this.entries[0].getKey(), this.entries[0].getValue());
/* 120:    */       }
/* 121:254 */       return new RegularImmutableMap(this.size, this.entries);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/* 126:    */   {
/* 127:273 */     if (((map instanceof ImmutableMap)) && (!(map instanceof ImmutableSortedMap)))
/* 128:    */     {
/* 129:278 */       ImmutableMap<K, V> kvMap = (ImmutableMap)map;
/* 130:279 */       if (!kvMap.isPartialView()) {
/* 131:280 */         return kvMap;
/* 132:    */       }
/* 133:    */     }
/* 134:282 */     else if ((map instanceof EnumMap))
/* 135:    */     {
/* 136:283 */       return copyOfEnumMapUnsafe(map);
/* 137:    */     }
/* 138:285 */     Map.Entry<?, ?>[] entries = (Map.Entry[])map.entrySet().toArray(EMPTY_ENTRY_ARRAY);
/* 139:286 */     switch (entries.length)
/* 140:    */     {
/* 141:    */     case 0: 
/* 142:288 */       return of();
/* 143:    */     case 1: 
/* 144:291 */       Map.Entry<K, V> onlyEntry = entries[0];
/* 145:292 */       return of(onlyEntry.getKey(), onlyEntry.getValue());
/* 146:    */     }
/* 147:294 */     return new RegularImmutableMap(entries);
/* 148:    */   }
/* 149:    */   
/* 150:    */   private static <K, V> ImmutableMap<K, V> copyOfEnumMapUnsafe(Map<? extends K, ? extends V> map)
/* 151:    */   {
/* 152:301 */     return copyOfEnumMap((EnumMap)map);
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static <K extends Enum<K>, V> ImmutableMap<K, V> copyOfEnumMap(Map<K, ? extends V> original)
/* 156:    */   {
/* 157:306 */     EnumMap<K, V> copy = new EnumMap(original);
/* 158:307 */     for (Map.Entry<?, ?> entry : copy.entrySet()) {
/* 159:308 */       CollectPreconditions.checkEntryNotNull(entry.getKey(), entry.getValue());
/* 160:    */     }
/* 161:310 */     return ImmutableEnumMap.asImmutable(copy);
/* 162:    */   }
/* 163:    */   
/* 164:313 */   private static final Map.Entry<?, ?>[] EMPTY_ENTRY_ARRAY = new Map.Entry[0];
/* 165:    */   private transient ImmutableSet<Map.Entry<K, V>> entrySet;
/* 166:    */   private transient ImmutableSet<K> keySet;
/* 167:    */   private transient ImmutableCollection<V> values;
/* 168:    */   private transient ImmutableSetMultimap<K, V> multimapView;
/* 169:    */   
/* 170:    */   @Deprecated
/* 171:    */   public final V put(K k, V v)
/* 172:    */   {
/* 173:326 */     throw new UnsupportedOperationException();
/* 174:    */   }
/* 175:    */   
/* 176:    */   @Deprecated
/* 177:    */   public final V remove(Object o)
/* 178:    */   {
/* 179:338 */     throw new UnsupportedOperationException();
/* 180:    */   }
/* 181:    */   
/* 182:    */   @Deprecated
/* 183:    */   public final void putAll(Map<? extends K, ? extends V> map)
/* 184:    */   {
/* 185:350 */     throw new UnsupportedOperationException();
/* 186:    */   }
/* 187:    */   
/* 188:    */   @Deprecated
/* 189:    */   public final void clear()
/* 190:    */   {
/* 191:362 */     throw new UnsupportedOperationException();
/* 192:    */   }
/* 193:    */   
/* 194:    */   public boolean isEmpty()
/* 195:    */   {
/* 196:367 */     return size() == 0;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public boolean containsKey(@Nullable Object key)
/* 200:    */   {
/* 201:372 */     return get(key) != null;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean containsValue(@Nullable Object value)
/* 205:    */   {
/* 206:377 */     return values().contains(value);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public abstract V get(@Nullable Object paramObject);
/* 210:    */   
/* 211:    */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/* 212:    */   {
/* 213:392 */     ImmutableSet<Map.Entry<K, V>> result = this.entrySet;
/* 214:393 */     return result == null ? (this.entrySet = createEntrySet()) : result;
/* 215:    */   }
/* 216:    */   
/* 217:    */   abstract ImmutableSet<Map.Entry<K, V>> createEntrySet();
/* 218:    */   
/* 219:    */   public ImmutableSet<K> keySet()
/* 220:    */   {
/* 221:406 */     ImmutableSet<K> result = this.keySet;
/* 222:407 */     return result == null ? (this.keySet = createKeySet()) : result;
/* 223:    */   }
/* 224:    */   
/* 225:    */   ImmutableSet<K> createKeySet()
/* 226:    */   {
/* 227:411 */     return new ImmutableMapKeySet(this);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public ImmutableCollection<V> values()
/* 231:    */   {
/* 232:422 */     ImmutableCollection<V> result = this.values;
/* 233:423 */     return result == null ? (this.values = new ImmutableMapValues(this)) : result;
/* 234:    */   }
/* 235:    */   
/* 236:    */   @Beta
/* 237:    */   public ImmutableSetMultimap<K, V> asMultimap()
/* 238:    */   {
/* 239:436 */     ImmutableSetMultimap<K, V> result = this.multimapView;
/* 240:437 */     return result == null ? (this.multimapView = createMultimapView()) : result;
/* 241:    */   }
/* 242:    */   
/* 243:    */   private ImmutableSetMultimap<K, V> createMultimapView()
/* 244:    */   {
/* 245:441 */     ImmutableMap<K, ImmutableSet<V>> map = viewMapValuesAsSingletonSets();
/* 246:442 */     return new ImmutableSetMultimap(map, map.size(), null);
/* 247:    */   }
/* 248:    */   
/* 249:    */   private ImmutableMap<K, ImmutableSet<V>> viewMapValuesAsSingletonSets()
/* 250:    */   {
/* 251:446 */     return new MapViewOfValuesAsSingletonSets(this);
/* 252:    */   }
/* 253:    */   
/* 254:    */   private static final class MapViewOfValuesAsSingletonSets<K, V>
/* 255:    */     extends ImmutableMap<K, ImmutableSet<V>>
/* 256:    */   {
/* 257:    */     private final ImmutableMap<K, V> delegate;
/* 258:    */     
/* 259:    */     MapViewOfValuesAsSingletonSets(ImmutableMap<K, V> delegate)
/* 260:    */     {
/* 261:454 */       this.delegate = ((ImmutableMap)Preconditions.checkNotNull(delegate));
/* 262:    */     }
/* 263:    */     
/* 264:    */     public int size()
/* 265:    */     {
/* 266:458 */       return this.delegate.size();
/* 267:    */     }
/* 268:    */     
/* 269:    */     public boolean containsKey(@Nullable Object key)
/* 270:    */     {
/* 271:462 */       return this.delegate.containsKey(key);
/* 272:    */     }
/* 273:    */     
/* 274:    */     public ImmutableSet<V> get(@Nullable Object key)
/* 275:    */     {
/* 276:466 */       V outerValue = this.delegate.get(key);
/* 277:467 */       return outerValue == null ? null : ImmutableSet.of(outerValue);
/* 278:    */     }
/* 279:    */     
/* 280:    */     boolean isPartialView()
/* 281:    */     {
/* 282:471 */       return false;
/* 283:    */     }
/* 284:    */     
/* 285:    */     ImmutableSet<Map.Entry<K, ImmutableSet<V>>> createEntrySet()
/* 286:    */     {
/* 287:475 */       new ImmutableMapEntrySet()
/* 288:    */       {
/* 289:    */         ImmutableMap<K, ImmutableSet<V>> map()
/* 290:    */         {
/* 291:477 */           return ImmutableMap.MapViewOfValuesAsSingletonSets.this;
/* 292:    */         }
/* 293:    */         
/* 294:    */         public UnmodifiableIterator<Map.Entry<K, ImmutableSet<V>>> iterator()
/* 295:    */         {
/* 296:482 */           final Iterator<Map.Entry<K, V>> backingIterator = ImmutableMap.this.entrySet().iterator();
/* 297:483 */           new UnmodifiableIterator()
/* 298:    */           {
/* 299:    */             public boolean hasNext()
/* 300:    */             {
/* 301:485 */               return backingIterator.hasNext();
/* 302:    */             }
/* 303:    */             
/* 304:    */             public Map.Entry<K, ImmutableSet<V>> next()
/* 305:    */             {
/* 306:489 */               final Map.Entry<K, V> backingEntry = (Map.Entry)backingIterator.next();
/* 307:490 */               new AbstractMapEntry()
/* 308:    */               {
/* 309:    */                 public K getKey()
/* 310:    */                 {
/* 311:492 */                   return backingEntry.getKey();
/* 312:    */                 }
/* 313:    */                 
/* 314:    */                 public ImmutableSet<V> getValue()
/* 315:    */                 {
/* 316:496 */                   return ImmutableSet.of(backingEntry.getValue());
/* 317:    */                 }
/* 318:    */               };
/* 319:    */             }
/* 320:    */           };
/* 321:    */         }
/* 322:    */       };
/* 323:    */     }
/* 324:    */   }
/* 325:    */   
/* 326:    */   public boolean equals(@Nullable Object object)
/* 327:    */   {
/* 328:507 */     return Maps.equalsImpl(this, object);
/* 329:    */   }
/* 330:    */   
/* 331:    */   abstract boolean isPartialView();
/* 332:    */   
/* 333:    */   public int hashCode()
/* 334:    */   {
/* 335:515 */     return entrySet().hashCode();
/* 336:    */   }
/* 337:    */   
/* 338:    */   public String toString()
/* 339:    */   {
/* 340:519 */     return Maps.toStringImpl(this);
/* 341:    */   }
/* 342:    */   
/* 343:    */   static class SerializedForm
/* 344:    */     implements Serializable
/* 345:    */   {
/* 346:    */     private final Object[] keys;
/* 347:    */     private final Object[] values;
/* 348:    */     private static final long serialVersionUID = 0L;
/* 349:    */     
/* 350:    */     SerializedForm(ImmutableMap<?, ?> map)
/* 351:    */     {
/* 352:531 */       this.keys = new Object[map.size()];
/* 353:532 */       this.values = new Object[map.size()];
/* 354:533 */       int i = 0;
/* 355:534 */       for (Map.Entry<?, ?> entry : map.entrySet())
/* 356:    */       {
/* 357:535 */         this.keys[i] = entry.getKey();
/* 358:536 */         this.values[i] = entry.getValue();
/* 359:537 */         i++;
/* 360:    */       }
/* 361:    */     }
/* 362:    */     
/* 363:    */     Object readResolve()
/* 364:    */     {
/* 365:541 */       ImmutableMap.Builder<Object, Object> builder = new ImmutableMap.Builder();
/* 366:542 */       return createMap(builder);
/* 367:    */     }
/* 368:    */     
/* 369:    */     Object createMap(ImmutableMap.Builder<Object, Object> builder)
/* 370:    */     {
/* 371:545 */       for (int i = 0; i < this.keys.length; i++) {
/* 372:546 */         builder.put(this.keys[i], this.values[i]);
/* 373:    */       }
/* 374:548 */       return builder.build();
/* 375:    */     }
/* 376:    */   }
/* 377:    */   
/* 378:    */   Object writeReplace()
/* 379:    */   {
/* 380:554 */     return new SerializedForm(this);
/* 381:    */   }
/* 382:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMap
 * JD-Core Version:    0.7.0.1
 */
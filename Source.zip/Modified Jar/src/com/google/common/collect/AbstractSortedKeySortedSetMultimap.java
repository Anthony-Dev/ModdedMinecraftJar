/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Collection;
/*  5:   */ import java.util.SortedMap;
/*  6:   */ import java.util.SortedSet;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ abstract class AbstractSortedKeySortedSetMultimap<K, V>
/* 10:   */   extends AbstractSortedSetMultimap<K, V>
/* 11:   */ {
/* 12:   */   AbstractSortedKeySortedSetMultimap(SortedMap<K, Collection<V>> map)
/* 13:   */   {
/* 14:38 */     super(map);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public SortedMap<K, Collection<V>> asMap()
/* 18:   */   {
/* 19:43 */     return (SortedMap)super.asMap();
/* 20:   */   }
/* 21:   */   
/* 22:   */   SortedMap<K, Collection<V>> backingMap()
/* 23:   */   {
/* 24:48 */     return (SortedMap)super.backingMap();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public SortedSet<K> keySet()
/* 28:   */   {
/* 29:53 */     return (SortedSet)super.keySet();
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractSortedKeySortedSetMultimap
 * JD-Core Version:    0.7.0.1
 */
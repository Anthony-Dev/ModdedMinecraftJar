/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.NavigableMap;
/*  12:    */ import java.util.NavigableSet;
/*  13:    */ import java.util.SortedSet;
/*  14:    */ import java.util.TreeMap;
/*  15:    */ import java.util.TreeSet;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible(serializable=true, emulated=true)
/*  19:    */ public class TreeMultimap<K, V>
/*  20:    */   extends AbstractSortedKeySortedSetMultimap<K, V>
/*  21:    */ {
/*  22:    */   private transient Comparator<? super K> keyComparator;
/*  23:    */   private transient Comparator<? super V> valueComparator;
/*  24:    */   @GwtIncompatible("not needed in emulated source")
/*  25:    */   private static final long serialVersionUID = 0L;
/*  26:    */   
/*  27:    */   public static <K extends Comparable, V extends Comparable> TreeMultimap<K, V> create()
/*  28:    */   {
/*  29: 89 */     return new TreeMultimap(Ordering.natural(), Ordering.natural());
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <K, V> TreeMultimap<K, V> create(Comparator<? super K> keyComparator, Comparator<? super V> valueComparator)
/*  33:    */   {
/*  34:103 */     return new TreeMultimap((Comparator)Preconditions.checkNotNull(keyComparator), (Comparator)Preconditions.checkNotNull(valueComparator));
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K extends Comparable, V extends Comparable> TreeMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  38:    */   {
/*  39:115 */     return new TreeMultimap(Ordering.natural(), Ordering.natural(), multimap);
/*  40:    */   }
/*  41:    */   
/*  42:    */   TreeMultimap(Comparator<? super K> keyComparator, Comparator<? super V> valueComparator)
/*  43:    */   {
/*  44:121 */     super(new TreeMap(keyComparator));
/*  45:122 */     this.keyComparator = keyComparator;
/*  46:123 */     this.valueComparator = valueComparator;
/*  47:    */   }
/*  48:    */   
/*  49:    */   private TreeMultimap(Comparator<? super K> keyComparator, Comparator<? super V> valueComparator, Multimap<? extends K, ? extends V> multimap)
/*  50:    */   {
/*  51:129 */     this(keyComparator, valueComparator);
/*  52:130 */     putAll(multimap);
/*  53:    */   }
/*  54:    */   
/*  55:    */   SortedSet<V> createCollection()
/*  56:    */   {
/*  57:142 */     return new TreeSet(this.valueComparator);
/*  58:    */   }
/*  59:    */   
/*  60:    */   Collection<V> createCollection(@Nullable K key)
/*  61:    */   {
/*  62:147 */     if (key == null) {
/*  63:148 */       keyComparator().compare(key, key);
/*  64:    */     }
/*  65:150 */     return super.createCollection(key);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Comparator<? super K> keyComparator()
/*  69:    */   {
/*  70:157 */     return this.keyComparator;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Comparator<? super V> valueComparator()
/*  74:    */   {
/*  75:162 */     return this.valueComparator;
/*  76:    */   }
/*  77:    */   
/*  78:    */   @GwtIncompatible("NavigableMap")
/*  79:    */   NavigableMap<K, Collection<V>> backingMap()
/*  80:    */   {
/*  81:174 */     return (NavigableMap)super.backingMap();
/*  82:    */   }
/*  83:    */   
/*  84:    */   @GwtIncompatible("NavigableSet")
/*  85:    */   public NavigableSet<V> get(@Nullable K key)
/*  86:    */   {
/*  87:183 */     return (NavigableSet)super.get(key);
/*  88:    */   }
/*  89:    */   
/*  90:    */   @GwtIncompatible("NavigableSet")
/*  91:    */   Collection<V> unmodifiableCollectionSubclass(Collection<V> collection)
/*  92:    */   {
/*  93:189 */     return Sets.unmodifiableNavigableSet((NavigableSet)collection);
/*  94:    */   }
/*  95:    */   
/*  96:    */   @GwtIncompatible("NavigableSet")
/*  97:    */   Collection<V> wrapCollection(K key, Collection<V> collection)
/*  98:    */   {
/*  99:195 */     return new AbstractMapBasedMultimap.WrappedNavigableSet(this, key, (NavigableSet)collection, null);
/* 100:    */   }
/* 101:    */   
/* 102:    */   @GwtIncompatible("NavigableSet")
/* 103:    */   public NavigableSet<K> keySet()
/* 104:    */   {
/* 105:210 */     return (NavigableSet)super.keySet();
/* 106:    */   }
/* 107:    */   
/* 108:    */   @GwtIncompatible("NavigableSet")
/* 109:    */   NavigableSet<K> createKeySet()
/* 110:    */   {
/* 111:216 */     return new AbstractMapBasedMultimap.NavigableKeySet(this, backingMap());
/* 112:    */   }
/* 113:    */   
/* 114:    */   @GwtIncompatible("NavigableMap")
/* 115:    */   public NavigableMap<K, Collection<V>> asMap()
/* 116:    */   {
/* 117:231 */     return (NavigableMap)super.asMap();
/* 118:    */   }
/* 119:    */   
/* 120:    */   @GwtIncompatible("NavigableMap")
/* 121:    */   NavigableMap<K, Collection<V>> createAsMap()
/* 122:    */   {
/* 123:237 */     return new AbstractMapBasedMultimap.NavigableAsMap(this, backingMap());
/* 124:    */   }
/* 125:    */   
/* 126:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 127:    */   private void writeObject(ObjectOutputStream stream)
/* 128:    */     throws IOException
/* 129:    */   {
/* 130:247 */     stream.defaultWriteObject();
/* 131:248 */     stream.writeObject(keyComparator());
/* 132:249 */     stream.writeObject(valueComparator());
/* 133:250 */     Serialization.writeMultimap(this, stream);
/* 134:    */   }
/* 135:    */   
/* 136:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 137:    */   private void readObject(ObjectInputStream stream)
/* 138:    */     throws IOException, ClassNotFoundException
/* 139:    */   {
/* 140:257 */     stream.defaultReadObject();
/* 141:258 */     this.keyComparator = ((Comparator)Preconditions.checkNotNull((Comparator)stream.readObject()));
/* 142:259 */     this.valueComparator = ((Comparator)Preconditions.checkNotNull((Comparator)stream.readObject()));
/* 143:260 */     setMap(new TreeMap(this.keyComparator));
/* 144:261 */     Serialization.populateMultimap(this, stream);
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.TreeMultimap
 * JD-Core Version:    0.7.0.1
 */
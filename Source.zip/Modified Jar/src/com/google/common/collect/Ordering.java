/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible
/*  20:    */ public abstract class Ordering<T>
/*  21:    */   implements Comparator<T>
/*  22:    */ {
/*  23:    */   static final int LEFT_IS_GREATER = 1;
/*  24:    */   static final int RIGHT_IS_GREATER = -1;
/*  25:    */   
/*  26:    */   @GwtCompatible(serializable=true)
/*  27:    */   public static <C extends Comparable> Ordering<C> natural()
/*  28:    */   {
/*  29:106 */     return NaturalOrdering.INSTANCE;
/*  30:    */   }
/*  31:    */   
/*  32:    */   @GwtCompatible(serializable=true)
/*  33:    */   public static <T> Ordering<T> from(Comparator<T> comparator)
/*  34:    */   {
/*  35:124 */     return (comparator instanceof Ordering) ? (Ordering)comparator : new ComparatorOrdering(comparator);
/*  36:    */   }
/*  37:    */   
/*  38:    */   @Deprecated
/*  39:    */   @GwtCompatible(serializable=true)
/*  40:    */   public static <T> Ordering<T> from(Ordering<T> ordering)
/*  41:    */   {
/*  42:136 */     return (Ordering)Preconditions.checkNotNull(ordering);
/*  43:    */   }
/*  44:    */   
/*  45:    */   @GwtCompatible(serializable=true)
/*  46:    */   public static <T> Ordering<T> explicit(List<T> valuesInOrder)
/*  47:    */   {
/*  48:162 */     return new ExplicitOrdering(valuesInOrder);
/*  49:    */   }
/*  50:    */   
/*  51:    */   @GwtCompatible(serializable=true)
/*  52:    */   public static <T> Ordering<T> explicit(T leastValue, T... remainingValuesInOrder)
/*  53:    */   {
/*  54:191 */     return explicit(Lists.asList(leastValue, remainingValuesInOrder));
/*  55:    */   }
/*  56:    */   
/*  57:    */   @GwtCompatible(serializable=true)
/*  58:    */   public static Ordering<Object> allEqual()
/*  59:    */   {
/*  60:223 */     return AllEqualOrdering.INSTANCE;
/*  61:    */   }
/*  62:    */   
/*  63:    */   @GwtCompatible(serializable=true)
/*  64:    */   public static Ordering<Object> usingToString()
/*  65:    */   {
/*  66:235 */     return UsingToStringOrdering.INSTANCE;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static Ordering<Object> arbitrary()
/*  70:    */   {
/*  71:255 */     return ArbitraryOrderingHolder.ARBITRARY_ORDERING;
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static class ArbitraryOrderingHolder
/*  75:    */   {
/*  76:259 */     static final Ordering<Object> ARBITRARY_ORDERING = new Ordering.ArbitraryOrdering();
/*  77:    */   }
/*  78:    */   
/*  79:    */   @VisibleForTesting
/*  80:    */   static class ArbitraryOrdering
/*  81:    */     extends Ordering<Object>
/*  82:    */   {
/*  83:263 */     private Map<Object, Integer> uids = Platform.tryWeakKeys(new MapMaker()).makeComputingMap(new Function()
/*  84:    */     {
/*  85:267 */       final AtomicInteger counter = new AtomicInteger(0);
/*  86:    */       
/*  87:    */       public Integer apply(Object from)
/*  88:    */       {
/*  89:270 */         return Integer.valueOf(this.counter.getAndIncrement());
/*  90:    */       }
/*  91:263 */     });
/*  92:    */     
/*  93:    */     public int compare(Object left, Object right)
/*  94:    */     {
/*  95:275 */       if (left == right) {
/*  96:276 */         return 0;
/*  97:    */       }
/*  98:277 */       if (left == null) {
/*  99:278 */         return -1;
/* 100:    */       }
/* 101:279 */       if (right == null) {
/* 102:280 */         return 1;
/* 103:    */       }
/* 104:282 */       int leftCode = identityHashCode(left);
/* 105:283 */       int rightCode = identityHashCode(right);
/* 106:284 */       if (leftCode != rightCode) {
/* 107:285 */         return leftCode < rightCode ? -1 : 1;
/* 108:    */       }
/* 109:289 */       int result = ((Integer)this.uids.get(left)).compareTo((Integer)this.uids.get(right));
/* 110:290 */       if (result == 0) {
/* 111:291 */         throw new AssertionError();
/* 112:    */       }
/* 113:293 */       return result;
/* 114:    */     }
/* 115:    */     
/* 116:    */     public String toString()
/* 117:    */     {
/* 118:297 */       return "Ordering.arbitrary()";
/* 119:    */     }
/* 120:    */     
/* 121:    */     int identityHashCode(Object object)
/* 122:    */     {
/* 123:309 */       return System.identityHashCode(object);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   @GwtCompatible(serializable=true)
/* 128:    */   public <S extends T> Ordering<S> reverse()
/* 129:    */   {
/* 130:331 */     return new ReverseOrdering(this);
/* 131:    */   }
/* 132:    */   
/* 133:    */   @GwtCompatible(serializable=true)
/* 134:    */   public <S extends T> Ordering<S> nullsFirst()
/* 135:    */   {
/* 136:342 */     return new NullsFirstOrdering(this);
/* 137:    */   }
/* 138:    */   
/* 139:    */   @GwtCompatible(serializable=true)
/* 140:    */   public <S extends T> Ordering<S> nullsLast()
/* 141:    */   {
/* 142:353 */     return new NullsLastOrdering(this);
/* 143:    */   }
/* 144:    */   
/* 145:    */   @GwtCompatible(serializable=true)
/* 146:    */   public <F> Ordering<F> onResultOf(Function<F, ? extends T> function)
/* 147:    */   {
/* 148:367 */     return new ByFunctionOrdering(function, this);
/* 149:    */   }
/* 150:    */   
/* 151:    */   <T2 extends T> Ordering<Map.Entry<T2, ?>> onKeys()
/* 152:    */   {
/* 153:371 */     return onResultOf(Maps.keyFunction());
/* 154:    */   }
/* 155:    */   
/* 156:    */   @GwtCompatible(serializable=true)
/* 157:    */   public <U extends T> Ordering<U> compound(Comparator<? super U> secondaryComparator)
/* 158:    */   {
/* 159:388 */     return new CompoundOrdering(this, (Comparator)Preconditions.checkNotNull(secondaryComparator));
/* 160:    */   }
/* 161:    */   
/* 162:    */   @GwtCompatible(serializable=true)
/* 163:    */   public static <T> Ordering<T> compound(Iterable<? extends Comparator<? super T>> comparators)
/* 164:    */   {
/* 165:409 */     return new CompoundOrdering(comparators);
/* 166:    */   }
/* 167:    */   
/* 168:    */   @GwtCompatible(serializable=true)
/* 169:    */   public <S extends T> Ordering<Iterable<S>> lexicographical()
/* 170:    */   {
/* 171:438 */     return new LexicographicalOrdering(this);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public abstract int compare(@Nullable T paramT1, @Nullable T paramT2);
/* 175:    */   
/* 176:    */   public <E extends T> E min(Iterator<E> iterator)
/* 177:    */   {
/* 178:461 */     E minSoFar = iterator.next();
/* 179:463 */     while (iterator.hasNext()) {
/* 180:464 */       minSoFar = min(minSoFar, iterator.next());
/* 181:    */     }
/* 182:467 */     return minSoFar;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public <E extends T> E min(Iterable<E> iterable)
/* 186:    */   {
/* 187:480 */     return min(iterable.iterator());
/* 188:    */   }
/* 189:    */   
/* 190:    */   public <E extends T> E min(@Nullable E a, @Nullable E b)
/* 191:    */   {
/* 192:497 */     return compare(a, b) <= 0 ? a : b;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public <E extends T> E min(@Nullable E a, @Nullable E b, @Nullable E c, E... rest)
/* 196:    */   {
/* 197:513 */     E minSoFar = min(min(a, b), c);
/* 198:515 */     for (E r : rest) {
/* 199:516 */       minSoFar = min(minSoFar, r);
/* 200:    */     }
/* 201:519 */     return minSoFar;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public <E extends T> E max(Iterator<E> iterator)
/* 205:    */   {
/* 206:537 */     E maxSoFar = iterator.next();
/* 207:539 */     while (iterator.hasNext()) {
/* 208:540 */       maxSoFar = max(maxSoFar, iterator.next());
/* 209:    */     }
/* 210:543 */     return maxSoFar;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public <E extends T> E max(Iterable<E> iterable)
/* 214:    */   {
/* 215:556 */     return max(iterable.iterator());
/* 216:    */   }
/* 217:    */   
/* 218:    */   public <E extends T> E max(@Nullable E a, @Nullable E b)
/* 219:    */   {
/* 220:573 */     return compare(a, b) >= 0 ? a : b;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public <E extends T> E max(@Nullable E a, @Nullable E b, @Nullable E c, E... rest)
/* 224:    */   {
/* 225:589 */     E maxSoFar = max(max(a, b), c);
/* 226:591 */     for (E r : rest) {
/* 227:592 */       maxSoFar = max(maxSoFar, r);
/* 228:    */     }
/* 229:595 */     return maxSoFar;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public <E extends T> List<E> leastOf(Iterable<E> iterable, int k)
/* 233:    */   {
/* 234:613 */     if ((iterable instanceof Collection))
/* 235:    */     {
/* 236:614 */       Collection<E> collection = (Collection)iterable;
/* 237:615 */       if (collection.size() <= 2L * k)
/* 238:    */       {
/* 239:621 */         E[] array = (Object[])collection.toArray();
/* 240:622 */         Arrays.sort(array, this);
/* 241:623 */         if (array.length > k) {
/* 242:624 */           array = ObjectArrays.arraysCopyOf(array, k);
/* 243:    */         }
/* 244:626 */         return Collections.unmodifiableList(Arrays.asList(array));
/* 245:    */       }
/* 246:    */     }
/* 247:629 */     return leastOf(iterable.iterator(), k);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public <E extends T> List<E> leastOf(Iterator<E> elements, int k)
/* 251:    */   {
/* 252:647 */     Preconditions.checkNotNull(elements);
/* 253:648 */     CollectPreconditions.checkNonnegative(k, "k");
/* 254:650 */     if ((k == 0) || (!elements.hasNext())) {
/* 255:651 */       return ImmutableList.of();
/* 256:    */     }
/* 257:652 */     if (k >= 1073741823)
/* 258:    */     {
/* 259:654 */       ArrayList<E> list = Lists.newArrayList(elements);
/* 260:655 */       Collections.sort(list, this);
/* 261:656 */       if (list.size() > k) {
/* 262:657 */         list.subList(k, list.size()).clear();
/* 263:    */       }
/* 264:659 */       list.trimToSize();
/* 265:660 */       return Collections.unmodifiableList(list);
/* 266:    */     }
/* 267:677 */     int bufferCap = k * 2;
/* 268:    */     
/* 269:679 */     E[] buffer = (Object[])new Object[bufferCap];
/* 270:680 */     E threshold = elements.next();
/* 271:681 */     buffer[0] = threshold;
/* 272:682 */     int bufferSize = 1;
/* 273:686 */     while ((bufferSize < k) && (elements.hasNext()))
/* 274:    */     {
/* 275:687 */       E e = elements.next();
/* 276:688 */       buffer[(bufferSize++)] = e;
/* 277:689 */       threshold = max(threshold, e);
/* 278:    */     }
/* 279:692 */     while (elements.hasNext())
/* 280:    */     {
/* 281:693 */       E e = elements.next();
/* 282:694 */       if (compare(e, threshold) < 0)
/* 283:    */       {
/* 284:698 */         buffer[(bufferSize++)] = e;
/* 285:699 */         if (bufferSize == bufferCap)
/* 286:    */         {
/* 287:702 */           int left = 0;
/* 288:703 */           int right = bufferCap - 1;
/* 289:    */           
/* 290:705 */           int minThresholdPosition = 0;
/* 291:709 */           while (left < right)
/* 292:    */           {
/* 293:710 */             int pivotIndex = left + right + 1 >>> 1;
/* 294:711 */             int pivotNewIndex = partition(buffer, left, right, pivotIndex);
/* 295:712 */             if (pivotNewIndex > k)
/* 296:    */             {
/* 297:713 */               right = pivotNewIndex - 1;
/* 298:    */             }
/* 299:    */             else
/* 300:    */             {
/* 301:714 */               if (pivotNewIndex >= k) {
/* 302:    */                 break;
/* 303:    */               }
/* 304:715 */               left = Math.max(pivotNewIndex, left + 1);
/* 305:716 */               minThresholdPosition = pivotNewIndex;
/* 306:    */             }
/* 307:    */           }
/* 308:721 */           bufferSize = k;
/* 309:    */           
/* 310:723 */           threshold = buffer[minThresholdPosition];
/* 311:724 */           for (int i = minThresholdPosition + 1; i < bufferSize; i++) {
/* 312:725 */             threshold = max(threshold, buffer[i]);
/* 313:    */           }
/* 314:    */         }
/* 315:    */       }
/* 316:    */     }
/* 317:730 */     Arrays.sort(buffer, 0, bufferSize, this);
/* 318:    */     
/* 319:732 */     bufferSize = Math.min(bufferSize, k);
/* 320:733 */     return Collections.unmodifiableList(Arrays.asList(ObjectArrays.arraysCopyOf(buffer, bufferSize)));
/* 321:    */   }
/* 322:    */   
/* 323:    */   private <E extends T> int partition(E[] values, int left, int right, int pivotIndex)
/* 324:    */   {
/* 325:740 */     E pivotValue = values[pivotIndex];
/* 326:    */     
/* 327:742 */     values[pivotIndex] = values[right];
/* 328:743 */     values[right] = pivotValue;
/* 329:    */     
/* 330:745 */     int storeIndex = left;
/* 331:746 */     for (int i = left; i < right; i++) {
/* 332:747 */       if (compare(values[i], pivotValue) < 0)
/* 333:    */       {
/* 334:748 */         ObjectArrays.swap(values, storeIndex, i);
/* 335:749 */         storeIndex++;
/* 336:    */       }
/* 337:    */     }
/* 338:752 */     ObjectArrays.swap(values, right, storeIndex);
/* 339:753 */     return storeIndex;
/* 340:    */   }
/* 341:    */   
/* 342:    */   public <E extends T> List<E> greatestOf(Iterable<E> iterable, int k)
/* 343:    */   {
/* 344:773 */     return reverse().leastOf(iterable, k);
/* 345:    */   }
/* 346:    */   
/* 347:    */   public <E extends T> List<E> greatestOf(Iterator<E> iterator, int k)
/* 348:    */   {
/* 349:791 */     return reverse().leastOf(iterator, k);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public <E extends T> List<E> sortedCopy(Iterable<E> elements)
/* 353:    */   {
/* 354:814 */     E[] array = (Object[])Iterables.toArray(elements);
/* 355:815 */     Arrays.sort(array, this);
/* 356:816 */     return Lists.newArrayList(Arrays.asList(array));
/* 357:    */   }
/* 358:    */   
/* 359:    */   public <E extends T> ImmutableList<E> immutableSortedCopy(Iterable<E> elements)
/* 360:    */   {
/* 361:840 */     E[] array = (Object[])Iterables.toArray(elements);
/* 362:841 */     for (E e : array) {
/* 363:842 */       Preconditions.checkNotNull(e);
/* 364:    */     }
/* 365:844 */     Arrays.sort(array, this);
/* 366:845 */     return ImmutableList.asImmutableList(array);
/* 367:    */   }
/* 368:    */   
/* 369:    */   public boolean isOrdered(Iterable<? extends T> iterable)
/* 370:    */   {
/* 371:855 */     Iterator<? extends T> it = iterable.iterator();
/* 372:856 */     if (it.hasNext())
/* 373:    */     {
/* 374:857 */       T prev = it.next();
/* 375:858 */       while (it.hasNext())
/* 376:    */       {
/* 377:859 */         T next = it.next();
/* 378:860 */         if (compare(prev, next) > 0) {
/* 379:861 */           return false;
/* 380:    */         }
/* 381:863 */         prev = next;
/* 382:    */       }
/* 383:    */     }
/* 384:866 */     return true;
/* 385:    */   }
/* 386:    */   
/* 387:    */   public boolean isStrictlyOrdered(Iterable<? extends T> iterable)
/* 388:    */   {
/* 389:876 */     Iterator<? extends T> it = iterable.iterator();
/* 390:877 */     if (it.hasNext())
/* 391:    */     {
/* 392:878 */       T prev = it.next();
/* 393:879 */       while (it.hasNext())
/* 394:    */       {
/* 395:880 */         T next = it.next();
/* 396:881 */         if (compare(prev, next) >= 0) {
/* 397:882 */           return false;
/* 398:    */         }
/* 399:884 */         prev = next;
/* 400:    */       }
/* 401:    */     }
/* 402:887 */     return true;
/* 403:    */   }
/* 404:    */   
/* 405:    */   public int binarySearch(List<? extends T> sortedList, @Nullable T key)
/* 406:    */   {
/* 407:899 */     return Collections.binarySearch(sortedList, key, this);
/* 408:    */   }
/* 409:    */   
/* 410:    */   @VisibleForTesting
/* 411:    */   static class IncomparableValueException
/* 412:    */     extends ClassCastException
/* 413:    */   {
/* 414:    */     final Object value;
/* 415:    */     private static final long serialVersionUID = 0L;
/* 416:    */     
/* 417:    */     IncomparableValueException(Object value)
/* 418:    */     {
/* 419:914 */       super();
/* 420:915 */       this.value = value;
/* 421:    */     }
/* 422:    */   }
/* 423:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Ordering
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.NoSuchElementException;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ final class EmptyContiguousSet<C extends Comparable>
/*  12:    */   extends ContiguousSet<C>
/*  13:    */ {
/*  14:    */   EmptyContiguousSet(DiscreteDomain<C> domain)
/*  15:    */   {
/*  16: 34 */     super(domain);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public C first()
/*  20:    */   {
/*  21: 38 */     throw new NoSuchElementException();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public C last()
/*  25:    */   {
/*  26: 42 */     throw new NoSuchElementException();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public int size()
/*  30:    */   {
/*  31: 46 */     return 0;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public ContiguousSet<C> intersection(ContiguousSet<C> other)
/*  35:    */   {
/*  36: 50 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Range<C> range()
/*  40:    */   {
/*  41: 54 */     throw new NoSuchElementException();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Range<C> range(BoundType lowerBoundType, BoundType upperBoundType)
/*  45:    */   {
/*  46: 58 */     throw new NoSuchElementException();
/*  47:    */   }
/*  48:    */   
/*  49:    */   ContiguousSet<C> headSetImpl(C toElement, boolean inclusive)
/*  50:    */   {
/*  51: 62 */     return this;
/*  52:    */   }
/*  53:    */   
/*  54:    */   ContiguousSet<C> subSetImpl(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/*  55:    */   {
/*  56: 67 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   ContiguousSet<C> tailSetImpl(C fromElement, boolean fromInclusive)
/*  60:    */   {
/*  61: 71 */     return this;
/*  62:    */   }
/*  63:    */   
/*  64:    */   @GwtIncompatible("not used by GWT emulation")
/*  65:    */   int indexOf(Object target)
/*  66:    */   {
/*  67: 76 */     return -1;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public UnmodifiableIterator<C> iterator()
/*  71:    */   {
/*  72: 80 */     return Iterators.emptyIterator();
/*  73:    */   }
/*  74:    */   
/*  75:    */   @GwtIncompatible("NavigableSet")
/*  76:    */   public UnmodifiableIterator<C> descendingIterator()
/*  77:    */   {
/*  78: 85 */     return Iterators.emptyIterator();
/*  79:    */   }
/*  80:    */   
/*  81:    */   boolean isPartialView()
/*  82:    */   {
/*  83: 89 */     return false;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean isEmpty()
/*  87:    */   {
/*  88: 93 */     return true;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public ImmutableList<C> asList()
/*  92:    */   {
/*  93: 97 */     return ImmutableList.of();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String toString()
/*  97:    */   {
/*  98:101 */     return "[]";
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean equals(@Nullable Object object)
/* 102:    */   {
/* 103:105 */     if ((object instanceof Set))
/* 104:    */     {
/* 105:106 */       Set<?> that = (Set)object;
/* 106:107 */       return that.isEmpty();
/* 107:    */     }
/* 108:109 */     return false;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int hashCode()
/* 112:    */   {
/* 113:113 */     return 0;
/* 114:    */   }
/* 115:    */   
/* 116:    */   @GwtIncompatible("serialization")
/* 117:    */   private static final class SerializedForm<C extends Comparable>
/* 118:    */     implements Serializable
/* 119:    */   {
/* 120:    */     private final DiscreteDomain<C> domain;
/* 121:    */     private static final long serialVersionUID = 0L;
/* 122:    */     
/* 123:    */     private SerializedForm(DiscreteDomain<C> domain)
/* 124:    */     {
/* 125:121 */       this.domain = domain;
/* 126:    */     }
/* 127:    */     
/* 128:    */     private Object readResolve()
/* 129:    */     {
/* 130:125 */       return new EmptyContiguousSet(this.domain);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   @GwtIncompatible("serialization")
/* 135:    */   Object writeReplace()
/* 136:    */   {
/* 137:134 */     return new SerializedForm(this.domain, null);
/* 138:    */   }
/* 139:    */   
/* 140:    */   @GwtIncompatible("NavigableSet")
/* 141:    */   ImmutableSortedSet<C> createDescendingSet()
/* 142:    */   {
/* 143:139 */     return new EmptyImmutableSortedSet(Ordering.natural().reverse());
/* 144:    */   }
/* 145:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyContiguousSet
 * JD-Core Version:    0.7.0.1
 */
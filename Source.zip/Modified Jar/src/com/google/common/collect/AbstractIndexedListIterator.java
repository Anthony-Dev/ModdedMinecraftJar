/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.NoSuchElementException;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ abstract class AbstractIndexedListIterator<E>
/*   9:    */   extends UnmodifiableListIterator<E>
/*  10:    */ {
/*  11:    */   private final int size;
/*  12:    */   private int position;
/*  13:    */   
/*  14:    */   protected abstract E get(int paramInt);
/*  15:    */   
/*  16:    */   protected AbstractIndexedListIterator(int size)
/*  17:    */   {
/*  18: 54 */     this(size, 0);
/*  19:    */   }
/*  20:    */   
/*  21:    */   protected AbstractIndexedListIterator(int size, int position)
/*  22:    */   {
/*  23: 69 */     Preconditions.checkPositionIndex(position, size);
/*  24: 70 */     this.size = size;
/*  25: 71 */     this.position = position;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public final boolean hasNext()
/*  29:    */   {
/*  30: 76 */     return this.position < this.size;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public final E next()
/*  34:    */   {
/*  35: 81 */     if (!hasNext()) {
/*  36: 82 */       throw new NoSuchElementException();
/*  37:    */     }
/*  38: 84 */     return get(this.position++);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public final int nextIndex()
/*  42:    */   {
/*  43: 89 */     return this.position;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public final boolean hasPrevious()
/*  47:    */   {
/*  48: 94 */     return this.position > 0;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public final E previous()
/*  52:    */   {
/*  53: 99 */     if (!hasPrevious()) {
/*  54:100 */       throw new NoSuchElementException();
/*  55:    */     }
/*  56:102 */     return get(--this.position);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public final int previousIndex()
/*  60:    */   {
/*  61:107 */     return this.position - 1;
/*  62:    */   }
/*  63:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractIndexedListIterator
 * JD-Core Version:    0.7.0.1
 */
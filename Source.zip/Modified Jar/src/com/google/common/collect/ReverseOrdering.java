/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Iterator;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(serializable=true)
/* 10:   */ final class ReverseOrdering<T>
/* 11:   */   extends Ordering<T>
/* 12:   */   implements Serializable
/* 13:   */ {
/* 14:   */   final Ordering<? super T> forwardOrder;
/* 15:   */   private static final long serialVersionUID = 0L;
/* 16:   */   
/* 17:   */   ReverseOrdering(Ordering<? super T> forwardOrder)
/* 18:   */   {
/* 19:34 */     this.forwardOrder = ((Ordering)Preconditions.checkNotNull(forwardOrder));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int compare(T a, T b)
/* 23:   */   {
/* 24:38 */     return this.forwardOrder.compare(b, a);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public <S extends T> Ordering<S> reverse()
/* 28:   */   {
/* 29:43 */     return this.forwardOrder;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public <E extends T> E min(E a, E b)
/* 33:   */   {
/* 34:49 */     return this.forwardOrder.max(a, b);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public <E extends T> E min(E a, E b, E c, E... rest)
/* 38:   */   {
/* 39:53 */     return this.forwardOrder.max(a, b, c, rest);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public <E extends T> E min(Iterator<E> iterator)
/* 43:   */   {
/* 44:57 */     return this.forwardOrder.max(iterator);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public <E extends T> E min(Iterable<E> iterable)
/* 48:   */   {
/* 49:61 */     return this.forwardOrder.max(iterable);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public <E extends T> E max(E a, E b)
/* 53:   */   {
/* 54:65 */     return this.forwardOrder.min(a, b);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public <E extends T> E max(E a, E b, E c, E... rest)
/* 58:   */   {
/* 59:69 */     return this.forwardOrder.min(a, b, c, rest);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public <E extends T> E max(Iterator<E> iterator)
/* 63:   */   {
/* 64:73 */     return this.forwardOrder.min(iterator);
/* 65:   */   }
/* 66:   */   
/* 67:   */   public <E extends T> E max(Iterable<E> iterable)
/* 68:   */   {
/* 69:77 */     return this.forwardOrder.min(iterable);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public int hashCode()
/* 73:   */   {
/* 74:81 */     return -this.forwardOrder.hashCode();
/* 75:   */   }
/* 76:   */   
/* 77:   */   public boolean equals(@Nullable Object object)
/* 78:   */   {
/* 79:85 */     if (object == this) {
/* 80:86 */       return true;
/* 81:   */     }
/* 82:88 */     if ((object instanceof ReverseOrdering))
/* 83:   */     {
/* 84:89 */       ReverseOrdering<?> that = (ReverseOrdering)object;
/* 85:90 */       return this.forwardOrder.equals(that.forwardOrder);
/* 86:   */     }
/* 87:92 */     return false;
/* 88:   */   }
/* 89:   */   
/* 90:   */   public String toString()
/* 91:   */   {
/* 92:96 */     return this.forwardOrder + ".reverse()";
/* 93:   */   }
/* 94:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ReverseOrdering
 * JD-Core Version:    0.7.0.1
 */
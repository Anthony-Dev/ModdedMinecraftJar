/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible(serializable=true, emulated=true)
/*  12:    */ class EmptyImmutableSortedSet<E>
/*  13:    */   extends ImmutableSortedSet<E>
/*  14:    */ {
/*  15:    */   EmptyImmutableSortedSet(Comparator<? super E> comparator)
/*  16:    */   {
/*  17: 38 */     super(comparator);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public int size()
/*  21:    */   {
/*  22: 43 */     return 0;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public boolean isEmpty()
/*  26:    */   {
/*  27: 47 */     return true;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean contains(@Nullable Object target)
/*  31:    */   {
/*  32: 51 */     return false;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public boolean containsAll(Collection<?> targets)
/*  36:    */   {
/*  37: 55 */     return targets.isEmpty();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public UnmodifiableIterator<E> iterator()
/*  41:    */   {
/*  42: 59 */     return Iterators.emptyIterator();
/*  43:    */   }
/*  44:    */   
/*  45:    */   @GwtIncompatible("NavigableSet")
/*  46:    */   public UnmodifiableIterator<E> descendingIterator()
/*  47:    */   {
/*  48: 64 */     return Iterators.emptyIterator();
/*  49:    */   }
/*  50:    */   
/*  51:    */   boolean isPartialView()
/*  52:    */   {
/*  53: 68 */     return false;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public ImmutableList<E> asList()
/*  57:    */   {
/*  58: 72 */     return ImmutableList.of();
/*  59:    */   }
/*  60:    */   
/*  61:    */   int copyIntoArray(Object[] dst, int offset)
/*  62:    */   {
/*  63: 77 */     return offset;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean equals(@Nullable Object object)
/*  67:    */   {
/*  68: 81 */     if ((object instanceof Set))
/*  69:    */     {
/*  70: 82 */       Set<?> that = (Set)object;
/*  71: 83 */       return that.isEmpty();
/*  72:    */     }
/*  73: 85 */     return false;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public int hashCode()
/*  77:    */   {
/*  78: 89 */     return 0;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String toString()
/*  82:    */   {
/*  83: 93 */     return "[]";
/*  84:    */   }
/*  85:    */   
/*  86:    */   public E first()
/*  87:    */   {
/*  88: 98 */     throw new NoSuchElementException();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public E last()
/*  92:    */   {
/*  93:103 */     throw new NoSuchElementException();
/*  94:    */   }
/*  95:    */   
/*  96:    */   ImmutableSortedSet<E> headSetImpl(E toElement, boolean inclusive)
/*  97:    */   {
/*  98:108 */     return this;
/*  99:    */   }
/* 100:    */   
/* 101:    */   ImmutableSortedSet<E> subSetImpl(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 102:    */   {
/* 103:114 */     return this;
/* 104:    */   }
/* 105:    */   
/* 106:    */   ImmutableSortedSet<E> tailSetImpl(E fromElement, boolean inclusive)
/* 107:    */   {
/* 108:119 */     return this;
/* 109:    */   }
/* 110:    */   
/* 111:    */   int indexOf(@Nullable Object target)
/* 112:    */   {
/* 113:123 */     return -1;
/* 114:    */   }
/* 115:    */   
/* 116:    */   ImmutableSortedSet<E> createDescendingSet()
/* 117:    */   {
/* 118:128 */     return new EmptyImmutableSortedSet(Ordering.from(this.comparator).reverse());
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */
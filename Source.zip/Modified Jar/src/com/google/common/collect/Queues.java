/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.ArrayDeque;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Deque;
/*   8:    */ import java.util.PriorityQueue;
/*   9:    */ import java.util.Queue;
/*  10:    */ import java.util.concurrent.ArrayBlockingQueue;
/*  11:    */ import java.util.concurrent.BlockingQueue;
/*  12:    */ import java.util.concurrent.ConcurrentLinkedQueue;
/*  13:    */ import java.util.concurrent.LinkedBlockingDeque;
/*  14:    */ import java.util.concurrent.LinkedBlockingQueue;
/*  15:    */ import java.util.concurrent.PriorityBlockingQueue;
/*  16:    */ import java.util.concurrent.SynchronousQueue;
/*  17:    */ import java.util.concurrent.TimeUnit;
/*  18:    */ 
/*  19:    */ public final class Queues
/*  20:    */ {
/*  21:    */   public static <E> ArrayBlockingQueue<E> newArrayBlockingQueue(int capacity)
/*  22:    */   {
/*  23: 51 */     return new ArrayBlockingQueue(capacity);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static <E> ArrayDeque<E> newArrayDeque()
/*  27:    */   {
/*  28: 62 */     return new ArrayDeque();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <E> ArrayDeque<E> newArrayDeque(Iterable<? extends E> elements)
/*  32:    */   {
/*  33: 72 */     if ((elements instanceof Collection)) {
/*  34: 73 */       return new ArrayDeque(Collections2.cast(elements));
/*  35:    */     }
/*  36: 75 */     ArrayDeque<E> deque = new ArrayDeque();
/*  37: 76 */     Iterables.addAll(deque, elements);
/*  38: 77 */     return deque;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <E> ConcurrentLinkedQueue<E> newConcurrentLinkedQueue()
/*  42:    */   {
/*  43: 86 */     return new ConcurrentLinkedQueue();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <E> ConcurrentLinkedQueue<E> newConcurrentLinkedQueue(Iterable<? extends E> elements)
/*  47:    */   {
/*  48: 95 */     if ((elements instanceof Collection)) {
/*  49: 96 */       return new ConcurrentLinkedQueue(Collections2.cast(elements));
/*  50:    */     }
/*  51: 98 */     ConcurrentLinkedQueue<E> queue = new ConcurrentLinkedQueue();
/*  52: 99 */     Iterables.addAll(queue, elements);
/*  53:100 */     return queue;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <E> LinkedBlockingDeque<E> newLinkedBlockingDeque()
/*  57:    */   {
/*  58:111 */     return new LinkedBlockingDeque();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <E> LinkedBlockingDeque<E> newLinkedBlockingDeque(int capacity)
/*  62:    */   {
/*  63:121 */     return new LinkedBlockingDeque(capacity);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <E> LinkedBlockingDeque<E> newLinkedBlockingDeque(Iterable<? extends E> elements)
/*  67:    */   {
/*  68:132 */     if ((elements instanceof Collection)) {
/*  69:133 */       return new LinkedBlockingDeque(Collections2.cast(elements));
/*  70:    */     }
/*  71:135 */     LinkedBlockingDeque<E> deque = new LinkedBlockingDeque();
/*  72:136 */     Iterables.addAll(deque, elements);
/*  73:137 */     return deque;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <E> LinkedBlockingQueue<E> newLinkedBlockingQueue()
/*  77:    */   {
/*  78:146 */     return new LinkedBlockingQueue();
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static <E> LinkedBlockingQueue<E> newLinkedBlockingQueue(int capacity)
/*  82:    */   {
/*  83:155 */     return new LinkedBlockingQueue(capacity);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static <E> LinkedBlockingQueue<E> newLinkedBlockingQueue(Iterable<? extends E> elements)
/*  87:    */   {
/*  88:167 */     if ((elements instanceof Collection)) {
/*  89:168 */       return new LinkedBlockingQueue(Collections2.cast(elements));
/*  90:    */     }
/*  91:170 */     LinkedBlockingQueue<E> queue = new LinkedBlockingQueue();
/*  92:171 */     Iterables.addAll(queue, elements);
/*  93:172 */     return queue;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static <E extends Comparable> PriorityBlockingQueue<E> newPriorityBlockingQueue()
/*  97:    */   {
/*  98:186 */     return new PriorityBlockingQueue();
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static <E extends Comparable> PriorityBlockingQueue<E> newPriorityBlockingQueue(Iterable<? extends E> elements)
/* 102:    */   {
/* 103:199 */     if ((elements instanceof Collection)) {
/* 104:200 */       return new PriorityBlockingQueue(Collections2.cast(elements));
/* 105:    */     }
/* 106:202 */     PriorityBlockingQueue<E> queue = new PriorityBlockingQueue();
/* 107:203 */     Iterables.addAll(queue, elements);
/* 108:204 */     return queue;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static <E extends Comparable> PriorityQueue<E> newPriorityQueue()
/* 112:    */   {
/* 113:216 */     return new PriorityQueue();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static <E extends Comparable> PriorityQueue<E> newPriorityQueue(Iterable<? extends E> elements)
/* 117:    */   {
/* 118:229 */     if ((elements instanceof Collection)) {
/* 119:230 */       return new PriorityQueue(Collections2.cast(elements));
/* 120:    */     }
/* 121:232 */     PriorityQueue<E> queue = new PriorityQueue();
/* 122:233 */     Iterables.addAll(queue, elements);
/* 123:234 */     return queue;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static <E> SynchronousQueue<E> newSynchronousQueue()
/* 127:    */   {
/* 128:243 */     return new SynchronousQueue();
/* 129:    */   }
/* 130:    */   
/* 131:    */   @Beta
/* 132:    */   public static <E> int drain(BlockingQueue<E> q, Collection<? super E> buffer, int numElements, long timeout, TimeUnit unit)
/* 133:    */     throws InterruptedException
/* 134:    */   {
/* 135:262 */     Preconditions.checkNotNull(buffer);
/* 136:    */     
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:268 */     long deadline = System.nanoTime() + unit.toNanos(timeout);
/* 142:269 */     int added = 0;
/* 143:270 */     while (added < numElements)
/* 144:    */     {
/* 145:273 */       added += q.drainTo(buffer, numElements - added);
/* 146:274 */       if (added < numElements)
/* 147:    */       {
/* 148:275 */         E e = q.poll(deadline - System.nanoTime(), TimeUnit.NANOSECONDS);
/* 149:276 */         if (e == null) {
/* 150:    */           break;
/* 151:    */         }
/* 152:279 */         buffer.add(e);
/* 153:280 */         added++;
/* 154:    */       }
/* 155:    */     }
/* 156:283 */     return added;
/* 157:    */   }
/* 158:    */   
/* 159:    */   @Beta
/* 160:    */   public static <E> int drainUninterruptibly(BlockingQueue<E> q, Collection<? super E> buffer, int numElements, long timeout, TimeUnit unit)
/* 161:    */   {
/* 162:302 */     Preconditions.checkNotNull(buffer);
/* 163:303 */     long deadline = System.nanoTime() + unit.toNanos(timeout);
/* 164:304 */     int added = 0;
/* 165:305 */     boolean interrupted = false;
/* 166:    */     try
/* 167:    */     {
/* 168:307 */       while (added < numElements)
/* 169:    */       {
/* 170:310 */         added += q.drainTo(buffer, numElements - added);
/* 171:311 */         if (added < numElements)
/* 172:    */         {
/* 173:    */           E e;
/* 174:    */           for (;;)
/* 175:    */           {
/* 176:    */             try
/* 177:    */             {
/* 178:315 */               e = q.poll(deadline - System.nanoTime(), TimeUnit.NANOSECONDS);
/* 179:    */             }
/* 180:    */             catch (InterruptedException ex)
/* 181:    */             {
/* 182:318 */               interrupted = true;
/* 183:    */             }
/* 184:    */           }
/* 185:321 */           if (e == null) {
/* 186:    */             break;
/* 187:    */           }
/* 188:324 */           buffer.add(e);
/* 189:325 */           added++;
/* 190:    */         }
/* 191:    */       }
/* 192:    */     }
/* 193:    */     finally
/* 194:    */     {
/* 195:329 */       if (interrupted) {
/* 196:330 */         Thread.currentThread().interrupt();
/* 197:    */       }
/* 198:    */     }
/* 199:333 */     return added;
/* 200:    */   }
/* 201:    */   
/* 202:    */   @Beta
/* 203:    */   public static <E> Queue<E> synchronizedQueue(Queue<E> queue)
/* 204:    */   {
/* 205:365 */     return Synchronized.queue(queue, null);
/* 206:    */   }
/* 207:    */   
/* 208:    */   @Beta
/* 209:    */   public static <E> Deque<E> synchronizedDeque(Deque<E> deque)
/* 210:    */   {
/* 211:397 */     return Synchronized.deque(deque, null);
/* 212:    */   }
/* 213:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Queues
 * JD-Core Version:    0.7.0.1
 */
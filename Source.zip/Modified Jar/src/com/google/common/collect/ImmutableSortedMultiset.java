/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ @GwtIncompatible("hasn't been tested yet")
/*  17:    */ public abstract class ImmutableSortedMultiset<E>
/*  18:    */   extends ImmutableSortedMultisetFauxverideShim<E>
/*  19:    */   implements SortedMultiset<E>
/*  20:    */ {
/*  21: 86 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  22: 88 */   private static final ImmutableSortedMultiset<Comparable> NATURAL_EMPTY_MULTISET = new EmptyImmutableSortedMultiset(NATURAL_ORDER);
/*  23:    */   transient ImmutableSortedMultiset<E> descendingMultiset;
/*  24:    */   
/*  25:    */   public static <E> ImmutableSortedMultiset<E> of()
/*  26:    */   {
/*  27: 96 */     return NATURAL_EMPTY_MULTISET;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E element)
/*  31:    */   {
/*  32:103 */     RegularImmutableSortedSet<E> elementSet = (RegularImmutableSortedSet)ImmutableSortedSet.of(element);
/*  33:    */     
/*  34:105 */     int[] counts = { 1 };
/*  35:106 */     long[] cumulativeCounts = { 0L, 1L };
/*  36:107 */     return new RegularImmutableSortedMultiset(elementSet, counts, cumulativeCounts, 0, 1);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2)
/*  40:    */   {
/*  41:118 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2 }));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3)
/*  45:    */   {
/*  46:129 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3 }));
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4)
/*  50:    */   {
/*  51:141 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3, e4 }));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5)
/*  55:    */   {
/*  56:153 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3, e4, e5 }));
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... remaining)
/*  60:    */   {
/*  61:165 */     int size = remaining.length + 6;
/*  62:166 */     List<E> all = Lists.newArrayListWithCapacity(size);
/*  63:167 */     Collections.addAll(all, new Comparable[] { e1, e2, e3, e4, e5, e6 });
/*  64:168 */     Collections.addAll(all, remaining);
/*  65:169 */     return copyOf(Ordering.natural(), all);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> copyOf(E[] elements)
/*  69:    */   {
/*  70:179 */     return copyOf(Ordering.natural(), Arrays.asList(elements));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Iterable<? extends E> elements)
/*  74:    */   {
/*  75:208 */     Ordering<E> naturalOrder = Ordering.natural();
/*  76:209 */     return copyOf(naturalOrder, elements);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Iterator<? extends E> elements)
/*  80:    */   {
/*  81:226 */     Ordering<E> naturalOrder = Ordering.natural();
/*  82:227 */     return copyOf(naturalOrder, elements);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator, Iterator<? extends E> elements)
/*  86:    */   {
/*  87:238 */     Preconditions.checkNotNull(comparator);
/*  88:239 */     return new Builder(comparator).addAll(elements).build();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator, Iterable<? extends E> elements)
/*  92:    */   {
/*  93:254 */     if ((elements instanceof ImmutableSortedMultiset))
/*  94:    */     {
/*  95:256 */       ImmutableSortedMultiset<E> multiset = (ImmutableSortedMultiset)elements;
/*  96:257 */       if (comparator.equals(multiset.comparator()))
/*  97:    */       {
/*  98:258 */         if (multiset.isPartialView()) {
/*  99:259 */           return copyOfSortedEntries(comparator, multiset.entrySet().asList());
/* 100:    */         }
/* 101:261 */         return multiset;
/* 102:    */       }
/* 103:    */     }
/* 104:265 */     elements = Lists.newArrayList(elements);
/* 105:266 */     TreeMultiset<E> sortedCopy = TreeMultiset.create((Comparator)Preconditions.checkNotNull(comparator));
/* 106:267 */     Iterables.addAll(sortedCopy, elements);
/* 107:268 */     return copyOfSortedEntries(comparator, sortedCopy.entrySet());
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static <E> ImmutableSortedMultiset<E> copyOfSorted(SortedMultiset<E> sortedMultiset)
/* 111:    */   {
/* 112:286 */     return copyOfSortedEntries(sortedMultiset.comparator(), Lists.newArrayList(sortedMultiset.entrySet()));
/* 113:    */   }
/* 114:    */   
/* 115:    */   private static <E> ImmutableSortedMultiset<E> copyOfSortedEntries(Comparator<? super E> comparator, Collection<Multiset.Entry<E>> entries)
/* 116:    */   {
/* 117:292 */     if (entries.isEmpty()) {
/* 118:293 */       return emptyMultiset(comparator);
/* 119:    */     }
/* 120:295 */     ImmutableList.Builder<E> elementsBuilder = new ImmutableList.Builder(entries.size());
/* 121:296 */     int[] counts = new int[entries.size()];
/* 122:297 */     long[] cumulativeCounts = new long[entries.size() + 1];
/* 123:298 */     int i = 0;
/* 124:299 */     for (Multiset.Entry<E> entry : entries)
/* 125:    */     {
/* 126:300 */       elementsBuilder.add(entry.getElement());
/* 127:301 */       counts[i] = entry.getCount();
/* 128:302 */       cumulativeCounts[(i + 1)] = (cumulativeCounts[i] + counts[i]);
/* 129:303 */       i++;
/* 130:    */     }
/* 131:305 */     return new RegularImmutableSortedMultiset(new RegularImmutableSortedSet(elementsBuilder.build(), comparator), counts, cumulativeCounts, 0, entries.size());
/* 132:    */   }
/* 133:    */   
/* 134:    */   static <E> ImmutableSortedMultiset<E> emptyMultiset(Comparator<? super E> comparator)
/* 135:    */   {
/* 136:312 */     if (NATURAL_ORDER.equals(comparator)) {
/* 137:313 */       return NATURAL_EMPTY_MULTISET;
/* 138:    */     }
/* 139:315 */     return new EmptyImmutableSortedMultiset(comparator);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public final Comparator<? super E> comparator()
/* 143:    */   {
/* 144:322 */     return elementSet().comparator();
/* 145:    */   }
/* 146:    */   
/* 147:    */   public abstract ImmutableSortedSet<E> elementSet();
/* 148:    */   
/* 149:    */   public ImmutableSortedMultiset<E> descendingMultiset()
/* 150:    */   {
/* 151:332 */     ImmutableSortedMultiset<E> result = this.descendingMultiset;
/* 152:333 */     if (result == null) {
/* 153:334 */       return this.descendingMultiset = new DescendingImmutableSortedMultiset(this);
/* 154:    */     }
/* 155:336 */     return result;
/* 156:    */   }
/* 157:    */   
/* 158:    */   @Deprecated
/* 159:    */   public final Multiset.Entry<E> pollFirstEntry()
/* 160:    */   {
/* 161:350 */     throw new UnsupportedOperationException();
/* 162:    */   }
/* 163:    */   
/* 164:    */   @Deprecated
/* 165:    */   public final Multiset.Entry<E> pollLastEntry()
/* 166:    */   {
/* 167:364 */     throw new UnsupportedOperationException();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public abstract ImmutableSortedMultiset<E> headMultiset(E paramE, BoundType paramBoundType);
/* 171:    */   
/* 172:    */   public ImmutableSortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 173:    */   {
/* 174:373 */     Preconditions.checkArgument(comparator().compare(lowerBound, upperBound) <= 0, "Expected lowerBound <= upperBound but %s > %s", new Object[] { lowerBound, upperBound });
/* 175:    */     
/* 176:375 */     return tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public abstract ImmutableSortedMultiset<E> tailMultiset(E paramE, BoundType paramBoundType);
/* 180:    */   
/* 181:    */   public static <E> Builder<E> orderedBy(Comparator<E> comparator)
/* 182:    */   {
/* 183:390 */     return new Builder(comparator);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static <E extends Comparable<E>> Builder<E> reverseOrder()
/* 187:    */   {
/* 188:402 */     return new Builder(Ordering.natural().reverse());
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static <E extends Comparable<E>> Builder<E> naturalOrder()
/* 192:    */   {
/* 193:416 */     return new Builder(Ordering.natural());
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static class Builder<E>
/* 197:    */     extends ImmutableMultiset.Builder<E>
/* 198:    */   {
/* 199:    */     public Builder(Comparator<? super E> comparator)
/* 200:    */     {
/* 201:444 */       super();
/* 202:    */     }
/* 203:    */     
/* 204:    */     public Builder<E> add(E element)
/* 205:    */     {
/* 206:456 */       super.add(element);
/* 207:457 */       return this;
/* 208:    */     }
/* 209:    */     
/* 210:    */     public Builder<E> addCopies(E element, int occurrences)
/* 211:    */     {
/* 212:473 */       super.addCopies(element, occurrences);
/* 213:474 */       return this;
/* 214:    */     }
/* 215:    */     
/* 216:    */     public Builder<E> setCount(E element, int count)
/* 217:    */     {
/* 218:489 */       super.setCount(element, count);
/* 219:490 */       return this;
/* 220:    */     }
/* 221:    */     
/* 222:    */     public Builder<E> add(E... elements)
/* 223:    */     {
/* 224:502 */       super.add(elements);
/* 225:503 */       return this;
/* 226:    */     }
/* 227:    */     
/* 228:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 229:    */     {
/* 230:515 */       super.addAll(elements);
/* 231:516 */       return this;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 235:    */     {
/* 236:528 */       super.addAll(elements);
/* 237:529 */       return this;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public ImmutableSortedMultiset<E> build()
/* 241:    */     {
/* 242:538 */       return ImmutableSortedMultiset.copyOfSorted((SortedMultiset)this.contents);
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   private static final class SerializedForm<E>
/* 247:    */     implements Serializable
/* 248:    */   {
/* 249:    */     Comparator<? super E> comparator;
/* 250:    */     E[] elements;
/* 251:    */     int[] counts;
/* 252:    */     
/* 253:    */     SerializedForm(SortedMultiset<E> multiset)
/* 254:    */     {
/* 255:549 */       this.comparator = multiset.comparator();
/* 256:550 */       int n = multiset.entrySet().size();
/* 257:551 */       this.elements = ((Object[])new Object[n]);
/* 258:552 */       this.counts = new int[n];
/* 259:553 */       int i = 0;
/* 260:554 */       for (Multiset.Entry<E> entry : multiset.entrySet())
/* 261:    */       {
/* 262:555 */         this.elements[i] = entry.getElement();
/* 263:556 */         this.counts[i] = entry.getCount();
/* 264:557 */         i++;
/* 265:    */       }
/* 266:    */     }
/* 267:    */     
/* 268:    */     Object readResolve()
/* 269:    */     {
/* 270:562 */       int n = this.elements.length;
/* 271:563 */       ImmutableSortedMultiset.Builder<E> builder = new ImmutableSortedMultiset.Builder(this.comparator);
/* 272:564 */       for (int i = 0; i < n; i++) {
/* 273:565 */         builder.addCopies(this.elements[i], this.counts[i]);
/* 274:    */       }
/* 275:567 */       return builder.build();
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   Object writeReplace()
/* 280:    */   {
/* 281:573 */     return new SerializedForm(this);
/* 282:    */   }
/* 283:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */
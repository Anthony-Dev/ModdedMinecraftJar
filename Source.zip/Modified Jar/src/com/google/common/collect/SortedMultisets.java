/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.NavigableSet;
/*   8:    */ import java.util.NoSuchElementException;
/*   9:    */ import java.util.SortedSet;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible(emulated=true)
/*  13:    */ final class SortedMultisets
/*  14:    */ {
/*  15:    */   static class ElementSet<E>
/*  16:    */     extends Multisets.ElementSet<E>
/*  17:    */     implements SortedSet<E>
/*  18:    */   {
/*  19:    */     private final SortedMultiset<E> multiset;
/*  20:    */     
/*  21:    */     ElementSet(SortedMultiset<E> multiset)
/*  22:    */     {
/*  23: 53 */       this.multiset = multiset;
/*  24:    */     }
/*  25:    */     
/*  26:    */     final SortedMultiset<E> multiset()
/*  27:    */     {
/*  28: 57 */       return this.multiset;
/*  29:    */     }
/*  30:    */     
/*  31:    */     public Comparator<? super E> comparator()
/*  32:    */     {
/*  33: 61 */       return multiset().comparator();
/*  34:    */     }
/*  35:    */     
/*  36:    */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  37:    */     {
/*  38: 65 */       return multiset().subMultiset(fromElement, BoundType.CLOSED, toElement, BoundType.OPEN).elementSet();
/*  39:    */     }
/*  40:    */     
/*  41:    */     public SortedSet<E> headSet(E toElement)
/*  42:    */     {
/*  43: 69 */       return multiset().headMultiset(toElement, BoundType.OPEN).elementSet();
/*  44:    */     }
/*  45:    */     
/*  46:    */     public SortedSet<E> tailSet(E fromElement)
/*  47:    */     {
/*  48: 73 */       return multiset().tailMultiset(fromElement, BoundType.CLOSED).elementSet();
/*  49:    */     }
/*  50:    */     
/*  51:    */     public E first()
/*  52:    */     {
/*  53: 77 */       return SortedMultisets.getElementOrThrow(multiset().firstEntry());
/*  54:    */     }
/*  55:    */     
/*  56:    */     public E last()
/*  57:    */     {
/*  58: 81 */       return SortedMultisets.getElementOrThrow(multiset().lastEntry());
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   @GwtIncompatible("Navigable")
/*  63:    */   static class NavigableElementSet<E>
/*  64:    */     extends SortedMultisets.ElementSet<E>
/*  65:    */     implements NavigableSet<E>
/*  66:    */   {
/*  67:    */     NavigableElementSet(SortedMultiset<E> multiset)
/*  68:    */     {
/*  69: 91 */       super();
/*  70:    */     }
/*  71:    */     
/*  72:    */     public E lower(E e)
/*  73:    */     {
/*  74: 96 */       return SortedMultisets.getElementOrNull(multiset().headMultiset(e, BoundType.OPEN).lastEntry());
/*  75:    */     }
/*  76:    */     
/*  77:    */     public E floor(E e)
/*  78:    */     {
/*  79:101 */       return SortedMultisets.getElementOrNull(multiset().headMultiset(e, BoundType.CLOSED).lastEntry());
/*  80:    */     }
/*  81:    */     
/*  82:    */     public E ceiling(E e)
/*  83:    */     {
/*  84:106 */       return SortedMultisets.getElementOrNull(multiset().tailMultiset(e, BoundType.CLOSED).firstEntry());
/*  85:    */     }
/*  86:    */     
/*  87:    */     public E higher(E e)
/*  88:    */     {
/*  89:111 */       return SortedMultisets.getElementOrNull(multiset().tailMultiset(e, BoundType.OPEN).firstEntry());
/*  90:    */     }
/*  91:    */     
/*  92:    */     public NavigableSet<E> descendingSet()
/*  93:    */     {
/*  94:116 */       return new NavigableElementSet(multiset().descendingMultiset());
/*  95:    */     }
/*  96:    */     
/*  97:    */     public Iterator<E> descendingIterator()
/*  98:    */     {
/*  99:121 */       return descendingSet().iterator();
/* 100:    */     }
/* 101:    */     
/* 102:    */     public E pollFirst()
/* 103:    */     {
/* 104:126 */       return SortedMultisets.getElementOrNull(multiset().pollFirstEntry());
/* 105:    */     }
/* 106:    */     
/* 107:    */     public E pollLast()
/* 108:    */     {
/* 109:131 */       return SortedMultisets.getElementOrNull(multiset().pollLastEntry());
/* 110:    */     }
/* 111:    */     
/* 112:    */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 113:    */     {
/* 114:137 */       return new NavigableElementSet(multiset().subMultiset(fromElement, BoundType.forBoolean(fromInclusive), toElement, BoundType.forBoolean(toInclusive)));
/* 115:    */     }
/* 116:    */     
/* 117:    */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 118:    */     {
/* 119:144 */       return new NavigableElementSet(multiset().headMultiset(toElement, BoundType.forBoolean(inclusive)));
/* 120:    */     }
/* 121:    */     
/* 122:    */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 123:    */     {
/* 124:150 */       return new NavigableElementSet(multiset().tailMultiset(fromElement, BoundType.forBoolean(inclusive)));
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   private static <E> E getElementOrThrow(Multiset.Entry<E> entry)
/* 129:    */   {
/* 130:156 */     if (entry == null) {
/* 131:157 */       throw new NoSuchElementException();
/* 132:    */     }
/* 133:159 */     return entry.getElement();
/* 134:    */   }
/* 135:    */   
/* 136:    */   private static <E> E getElementOrNull(@Nullable Multiset.Entry<E> entry)
/* 137:    */   {
/* 138:163 */     return entry == null ? null : entry.getElement();
/* 139:    */   }
/* 140:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SortedMultisets
 * JD-Core Version:    0.7.0.1
 */
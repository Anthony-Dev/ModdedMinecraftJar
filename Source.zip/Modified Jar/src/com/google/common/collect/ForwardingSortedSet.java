/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ import java.util.SortedSet;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ public abstract class ForwardingSortedSet<E>
/*  13:    */   extends ForwardingSet<E>
/*  14:    */   implements SortedSet<E>
/*  15:    */ {
/*  16:    */   protected abstract SortedSet<E> delegate();
/*  17:    */   
/*  18:    */   public Comparator<? super E> comparator()
/*  19:    */   {
/*  20: 67 */     return delegate().comparator();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public E first()
/*  24:    */   {
/*  25: 72 */     return delegate().first();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SortedSet<E> headSet(E toElement)
/*  29:    */   {
/*  30: 77 */     return delegate().headSet(toElement);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public E last()
/*  34:    */   {
/*  35: 82 */     return delegate().last();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public SortedSet<E> subSet(E fromElement, E toElement)
/*  39:    */   {
/*  40: 87 */     return delegate().subSet(fromElement, toElement);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public SortedSet<E> tailSet(E fromElement)
/*  44:    */   {
/*  45: 92 */     return delegate().tailSet(fromElement);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private int unsafeCompare(Object o1, Object o2)
/*  49:    */   {
/*  50: 98 */     Comparator<? super E> comparator = comparator();
/*  51: 99 */     return comparator == null ? ((Comparable)o1).compareTo(o2) : comparator.compare(o1, o2);
/*  52:    */   }
/*  53:    */   
/*  54:    */   @Beta
/*  55:    */   protected boolean standardContains(@Nullable Object object)
/*  56:    */   {
/*  57:    */     try
/*  58:    */     {
/*  59:115 */       SortedSet<Object> self = this;
/*  60:116 */       Object ceiling = self.tailSet(object).first();
/*  61:117 */       return unsafeCompare(ceiling, object) == 0;
/*  62:    */     }
/*  63:    */     catch (ClassCastException e)
/*  64:    */     {
/*  65:119 */       return false;
/*  66:    */     }
/*  67:    */     catch (NoSuchElementException e)
/*  68:    */     {
/*  69:121 */       return false;
/*  70:    */     }
/*  71:    */     catch (NullPointerException e) {}
/*  72:123 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   @Beta
/*  76:    */   protected boolean standardRemove(@Nullable Object object)
/*  77:    */   {
/*  78:    */     try
/*  79:    */     {
/*  80:138 */       SortedSet<Object> self = this;
/*  81:139 */       Iterator<Object> iterator = self.tailSet(object).iterator();
/*  82:140 */       if (iterator.hasNext())
/*  83:    */       {
/*  84:141 */         Object ceiling = iterator.next();
/*  85:142 */         if (unsafeCompare(ceiling, object) == 0)
/*  86:    */         {
/*  87:143 */           iterator.remove();
/*  88:144 */           return true;
/*  89:    */         }
/*  90:    */       }
/*  91:    */     }
/*  92:    */     catch (ClassCastException e)
/*  93:    */     {
/*  94:148 */       return false;
/*  95:    */     }
/*  96:    */     catch (NullPointerException e)
/*  97:    */     {
/*  98:150 */       return false;
/*  99:    */     }
/* 100:152 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   @Beta
/* 104:    */   protected SortedSet<E> standardSubSet(E fromElement, E toElement)
/* 105:    */   {
/* 106:164 */     return tailSet(fromElement).headSet(toElement);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingSortedSet
 * JD-Core Version:    0.7.0.1
 */
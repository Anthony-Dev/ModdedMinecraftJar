/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.ObjectInputStream;
/*  7:   */ import java.io.ObjectOutputStream;
/*  8:   */ import java.util.HashMap;
/*  9:   */ 
/* 10:   */ @GwtCompatible(serializable=true, emulated=true)
/* 11:   */ public final class HashMultiset<E>
/* 12:   */   extends AbstractMapBasedMultiset<E>
/* 13:   */ {
/* 14:   */   @GwtIncompatible("Not needed in emulated source.")
/* 15:   */   private static final long serialVersionUID = 0L;
/* 16:   */   
/* 17:   */   public static <E> HashMultiset<E> create()
/* 18:   */   {
/* 19:42 */     return new HashMultiset();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static <E> HashMultiset<E> create(int distinctElements)
/* 23:   */   {
/* 24:53 */     return new HashMultiset(distinctElements);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static <E> HashMultiset<E> create(Iterable<? extends E> elements)
/* 28:   */   {
/* 29:65 */     HashMultiset<E> multiset = create(Multisets.inferDistinctElements(elements));
/* 30:   */     
/* 31:67 */     Iterables.addAll(multiset, elements);
/* 32:68 */     return multiset;
/* 33:   */   }
/* 34:   */   
/* 35:   */   private HashMultiset()
/* 36:   */   {
/* 37:72 */     super(new HashMap());
/* 38:   */   }
/* 39:   */   
/* 40:   */   private HashMultiset(int distinctElements)
/* 41:   */   {
/* 42:76 */     super(Maps.newHashMapWithExpectedSize(distinctElements));
/* 43:   */   }
/* 44:   */   
/* 45:   */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 46:   */   private void writeObject(ObjectOutputStream stream)
/* 47:   */     throws IOException
/* 48:   */   {
/* 49:85 */     stream.defaultWriteObject();
/* 50:86 */     Serialization.writeMultiset(this, stream);
/* 51:   */   }
/* 52:   */   
/* 53:   */   @GwtIncompatible("java.io.ObjectInputStream")
/* 54:   */   private void readObject(ObjectInputStream stream)
/* 55:   */     throws IOException, ClassNotFoundException
/* 56:   */   {
/* 57:92 */     stream.defaultReadObject();
/* 58:93 */     int distinctElements = Serialization.readCount(stream);
/* 59:94 */     setBackingMap(Maps.newHashMapWithExpectedSize(distinctElements));
/* 60:   */     
/* 61:96 */     Serialization.populateMultiset(this, stream, distinctElements);
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.HashMultiset
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Predicate;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import java.util.Set;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible
/* 10:   */ final class FilteredKeySetMultimap<K, V>
/* 11:   */   extends FilteredKeyMultimap<K, V>
/* 12:   */   implements FilteredSetMultimap<K, V>
/* 13:   */ {
/* 14:   */   FilteredKeySetMultimap(SetMultimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 15:   */   {
/* 16:37 */     super(unfiltered, keyPredicate);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public SetMultimap<K, V> unfiltered()
/* 20:   */   {
/* 21:42 */     return (SetMultimap)this.unfiltered;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Set<V> get(K key)
/* 25:   */   {
/* 26:47 */     return (Set)super.get(key);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Set<V> removeAll(Object key)
/* 30:   */   {
/* 31:52 */     return (Set)super.removeAll(key);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Set<V> replaceValues(K key, Iterable<? extends V> values)
/* 35:   */   {
/* 36:57 */     return (Set)super.replaceValues(key, values);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Set<Map.Entry<K, V>> entries()
/* 40:   */   {
/* 41:62 */     return (Set)super.entries();
/* 42:   */   }
/* 43:   */   
/* 44:   */   Set<Map.Entry<K, V>> createEntries()
/* 45:   */   {
/* 46:67 */     return new EntrySet();
/* 47:   */   }
/* 48:   */   
/* 49:   */   class EntrySet
/* 50:   */     extends FilteredKeyMultimap<K, V>.Entries
/* 51:   */     implements Set<Map.Entry<K, V>>
/* 52:   */   {
/* 53:   */     EntrySet()
/* 54:   */     {
/* 55:70 */       super();
/* 56:   */     }
/* 57:   */     
/* 58:   */     public int hashCode()
/* 59:   */     {
/* 60:73 */       return Sets.hashCodeImpl(this);
/* 61:   */     }
/* 62:   */     
/* 63:   */     public boolean equals(@Nullable Object o)
/* 64:   */     {
/* 65:78 */       return Sets.equalsImpl(this, o);
/* 66:   */     }
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.FilteredKeySetMultimap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @GwtCompatible
/*  14:    */ public abstract class ForwardingMap<K, V>
/*  15:    */   extends ForwardingObject
/*  16:    */   implements Map<K, V>
/*  17:    */ {
/*  18:    */   protected abstract Map<K, V> delegate();
/*  19:    */   
/*  20:    */   public int size()
/*  21:    */   {
/*  22: 70 */     return delegate().size();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public boolean isEmpty()
/*  26:    */   {
/*  27: 75 */     return delegate().isEmpty();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public V remove(Object object)
/*  31:    */   {
/*  32: 80 */     return delegate().remove(object);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void clear()
/*  36:    */   {
/*  37: 85 */     delegate().clear();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean containsKey(@Nullable Object key)
/*  41:    */   {
/*  42: 90 */     return delegate().containsKey(key);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean containsValue(@Nullable Object value)
/*  46:    */   {
/*  47: 95 */     return delegate().containsValue(value);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public V get(@Nullable Object key)
/*  51:    */   {
/*  52:100 */     return delegate().get(key);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public V put(K key, V value)
/*  56:    */   {
/*  57:105 */     return delegate().put(key, value);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void putAll(Map<? extends K, ? extends V> map)
/*  61:    */   {
/*  62:110 */     delegate().putAll(map);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Set<K> keySet()
/*  66:    */   {
/*  67:115 */     return delegate().keySet();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Collection<V> values()
/*  71:    */   {
/*  72:120 */     return delegate().values();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Set<Map.Entry<K, V>> entrySet()
/*  76:    */   {
/*  77:125 */     return delegate().entrySet();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean equals(@Nullable Object object)
/*  81:    */   {
/*  82:129 */     return (object == this) || (delegate().equals(object));
/*  83:    */   }
/*  84:    */   
/*  85:    */   public int hashCode()
/*  86:    */   {
/*  87:133 */     return delegate().hashCode();
/*  88:    */   }
/*  89:    */   
/*  90:    */   protected void standardPutAll(Map<? extends K, ? extends V> map)
/*  91:    */   {
/*  92:145 */     Maps.putAllImpl(this, map);
/*  93:    */   }
/*  94:    */   
/*  95:    */   @Beta
/*  96:    */   protected V standardRemove(@Nullable Object key)
/*  97:    */   {
/*  98:161 */     Iterator<Map.Entry<K, V>> entryIterator = entrySet().iterator();
/*  99:162 */     while (entryIterator.hasNext())
/* 100:    */     {
/* 101:163 */       Map.Entry<K, V> entry = (Map.Entry)entryIterator.next();
/* 102:164 */       if (Objects.equal(entry.getKey(), key))
/* 103:    */       {
/* 104:165 */         V value = entry.getValue();
/* 105:166 */         entryIterator.remove();
/* 106:167 */         return value;
/* 107:    */       }
/* 108:    */     }
/* 109:170 */     return null;
/* 110:    */   }
/* 111:    */   
/* 112:    */   protected void standardClear()
/* 113:    */   {
/* 114:181 */     Iterators.clear(entrySet().iterator());
/* 115:    */   }
/* 116:    */   
/* 117:    */   @Beta
/* 118:    */   protected class StandardKeySet
/* 119:    */     extends Maps.KeySet<K, V>
/* 120:    */   {
/* 121:    */     public StandardKeySet()
/* 122:    */     {
/* 123:199 */       super();
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   @Beta
/* 128:    */   protected boolean standardContainsKey(@Nullable Object key)
/* 129:    */   {
/* 130:212 */     return Maps.containsKeyImpl(this, key);
/* 131:    */   }
/* 132:    */   
/* 133:    */   @Beta
/* 134:    */   protected class StandardValues
/* 135:    */     extends Maps.Values<K, V>
/* 136:    */   {
/* 137:    */     public StandardValues()
/* 138:    */     {
/* 139:229 */       super();
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */   protected boolean standardContainsValue(@Nullable Object value)
/* 144:    */   {
/* 145:242 */     return Maps.containsValueImpl(this, value);
/* 146:    */   }
/* 147:    */   
/* 148:    */   @Beta
/* 149:    */   protected abstract class StandardEntrySet
/* 150:    */     extends Maps.EntrySet<K, V>
/* 151:    */   {
/* 152:    */     public StandardEntrySet() {}
/* 153:    */     
/* 154:    */     Map<K, V> map()
/* 155:    */     {
/* 156:262 */       return ForwardingMap.this;
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   protected boolean standardIsEmpty()
/* 161:    */   {
/* 162:274 */     return !entrySet().iterator().hasNext();
/* 163:    */   }
/* 164:    */   
/* 165:    */   protected boolean standardEquals(@Nullable Object object)
/* 166:    */   {
/* 167:285 */     return Maps.equalsImpl(this, object);
/* 168:    */   }
/* 169:    */   
/* 170:    */   protected int standardHashCode()
/* 171:    */   {
/* 172:296 */     return Sets.hashCodeImpl(entrySet());
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected String standardToString()
/* 176:    */   {
/* 177:307 */     return Maps.toStringImpl(this);
/* 178:    */   }
/* 179:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingMap
 * JD-Core Version:    0.7.0.1
 */
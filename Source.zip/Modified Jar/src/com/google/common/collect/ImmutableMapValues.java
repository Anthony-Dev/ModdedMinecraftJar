/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Map.Entry;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(emulated=true)
/* 10:   */ final class ImmutableMapValues<K, V>
/* 11:   */   extends ImmutableCollection<V>
/* 12:   */ {
/* 13:   */   private final ImmutableMap<K, V> map;
/* 14:   */   
/* 15:   */   ImmutableMapValues(ImmutableMap<K, V> map)
/* 16:   */   {
/* 17:38 */     this.map = map;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int size()
/* 21:   */   {
/* 22:43 */     return this.map.size();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public UnmodifiableIterator<V> iterator()
/* 26:   */   {
/* 27:48 */     return Maps.valueIterator(this.map.entrySet().iterator());
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean contains(@Nullable Object object)
/* 31:   */   {
/* 32:53 */     return (object != null) && (Iterators.contains(iterator(), object));
/* 33:   */   }
/* 34:   */   
/* 35:   */   boolean isPartialView()
/* 36:   */   {
/* 37:58 */     return true;
/* 38:   */   }
/* 39:   */   
/* 40:   */   ImmutableList<V> createAsList()
/* 41:   */   {
/* 42:63 */     final ImmutableList<Map.Entry<K, V>> entryList = this.map.entrySet().asList();
/* 43:64 */     new ImmutableAsList()
/* 44:   */     {
/* 45:   */       public V get(int index)
/* 46:   */       {
/* 47:67 */         return ((Map.Entry)entryList.get(index)).getValue();
/* 48:   */       }
/* 49:   */       
/* 50:   */       ImmutableCollection<V> delegateCollection()
/* 51:   */       {
/* 52:72 */         return ImmutableMapValues.this;
/* 53:   */       }
/* 54:   */     };
/* 55:   */   }
/* 56:   */   
/* 57:   */   @GwtIncompatible("serialization")
/* 58:   */   Object writeReplace()
/* 59:   */   {
/* 60:79 */     return new SerializedForm(this.map);
/* 61:   */   }
/* 62:   */   
/* 63:   */   @GwtIncompatible("serialization")
/* 64:   */   private static class SerializedForm<V>
/* 65:   */     implements Serializable
/* 66:   */   {
/* 67:   */     final ImmutableMap<?, V> map;
/* 68:   */     private static final long serialVersionUID = 0L;
/* 69:   */     
/* 70:   */     SerializedForm(ImmutableMap<?, V> map)
/* 71:   */     {
/* 72:86 */       this.map = map;
/* 73:   */     }
/* 74:   */     
/* 75:   */     Object readResolve()
/* 76:   */     {
/* 77:89 */       return this.map.values();
/* 78:   */     }
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapValues
 * JD-Core Version:    0.7.0.1
 */
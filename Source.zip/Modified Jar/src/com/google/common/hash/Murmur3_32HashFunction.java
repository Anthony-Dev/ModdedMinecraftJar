/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.primitives.UnsignedBytes;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ final class Murmur3_32HashFunction
/*   9:    */   extends AbstractStreamingHashFunction
/*  10:    */   implements Serializable
/*  11:    */ {
/*  12:    */   private static final int C1 = -862048943;
/*  13:    */   private static final int C2 = 461845907;
/*  14:    */   private final int seed;
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   Murmur3_32HashFunction(int seed)
/*  18:    */   {
/*  19: 54 */     this.seed = seed;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public int bits()
/*  23:    */   {
/*  24: 58 */     return 32;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public Hasher newHasher()
/*  28:    */   {
/*  29: 62 */     return new Murmur3_32Hasher(this.seed);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String toString()
/*  33:    */   {
/*  34: 67 */     return "Hashing.murmur3_32(" + this.seed + ")";
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean equals(@Nullable Object object)
/*  38:    */   {
/*  39: 72 */     if ((object instanceof Murmur3_32HashFunction))
/*  40:    */     {
/*  41: 73 */       Murmur3_32HashFunction other = (Murmur3_32HashFunction)object;
/*  42: 74 */       return this.seed == other.seed;
/*  43:    */     }
/*  44: 76 */     return false;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int hashCode()
/*  48:    */   {
/*  49: 81 */     return getClass().hashCode() ^ this.seed;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public HashCode hashInt(int input)
/*  53:    */   {
/*  54: 85 */     int k1 = mixK1(input);
/*  55: 86 */     int h1 = mixH1(this.seed, k1);
/*  56:    */     
/*  57: 88 */     return fmix(h1, 4);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public HashCode hashLong(long input)
/*  61:    */   {
/*  62: 92 */     int low = (int)input;
/*  63: 93 */     int high = (int)(input >>> 32);
/*  64:    */     
/*  65: 95 */     int k1 = mixK1(low);
/*  66: 96 */     int h1 = mixH1(this.seed, k1);
/*  67:    */     
/*  68: 98 */     k1 = mixK1(high);
/*  69: 99 */     h1 = mixH1(h1, k1);
/*  70:    */     
/*  71:101 */     return fmix(h1, 8);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public HashCode hashUnencodedChars(CharSequence input)
/*  75:    */   {
/*  76:106 */     int h1 = this.seed;
/*  77:109 */     for (int i = 1; i < input.length(); i += 2)
/*  78:    */     {
/*  79:110 */       int k1 = input.charAt(i - 1) | input.charAt(i) << '\020';
/*  80:111 */       k1 = mixK1(k1);
/*  81:112 */       h1 = mixH1(h1, k1);
/*  82:    */     }
/*  83:116 */     if ((input.length() & 0x1) == 1)
/*  84:    */     {
/*  85:117 */       int k1 = input.charAt(input.length() - 1);
/*  86:118 */       k1 = mixK1(k1);
/*  87:119 */       h1 ^= k1;
/*  88:    */     }
/*  89:122 */     return fmix(h1, 2 * input.length());
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static int mixK1(int k1)
/*  93:    */   {
/*  94:126 */     k1 *= -862048943;
/*  95:127 */     k1 = Integer.rotateLeft(k1, 15);
/*  96:128 */     k1 *= 461845907;
/*  97:129 */     return k1;
/*  98:    */   }
/*  99:    */   
/* 100:    */   private static int mixH1(int h1, int k1)
/* 101:    */   {
/* 102:133 */     h1 ^= k1;
/* 103:134 */     h1 = Integer.rotateLeft(h1, 13);
/* 104:135 */     h1 = h1 * 5 + -430675100;
/* 105:136 */     return h1;
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static HashCode fmix(int h1, int length)
/* 109:    */   {
/* 110:141 */     h1 ^= length;
/* 111:142 */     h1 ^= h1 >>> 16;
/* 112:143 */     h1 *= -2048144789;
/* 113:144 */     h1 ^= h1 >>> 13;
/* 114:145 */     h1 *= -1028477387;
/* 115:146 */     h1 ^= h1 >>> 16;
/* 116:147 */     return HashCode.fromInt(h1);
/* 117:    */   }
/* 118:    */   
/* 119:    */   private static final class Murmur3_32Hasher
/* 120:    */     extends AbstractStreamingHashFunction.AbstractStreamingHasher
/* 121:    */   {
/* 122:    */     private static final int CHUNK_SIZE = 4;
/* 123:    */     private int h1;
/* 124:    */     private int length;
/* 125:    */     
/* 126:    */     Murmur3_32Hasher(int seed)
/* 127:    */     {
/* 128:156 */       super();
/* 129:157 */       this.h1 = seed;
/* 130:158 */       this.length = 0;
/* 131:    */     }
/* 132:    */     
/* 133:    */     protected void process(ByteBuffer bb)
/* 134:    */     {
/* 135:162 */       int k1 = Murmur3_32HashFunction.mixK1(bb.getInt());
/* 136:163 */       this.h1 = Murmur3_32HashFunction.mixH1(this.h1, k1);
/* 137:164 */       this.length += 4;
/* 138:    */     }
/* 139:    */     
/* 140:    */     protected void processRemaining(ByteBuffer bb)
/* 141:    */     {
/* 142:168 */       this.length += bb.remaining();
/* 143:169 */       int k1 = 0;
/* 144:170 */       for (int i = 0; bb.hasRemaining(); i += 8) {
/* 145:171 */         k1 ^= UnsignedBytes.toInt(bb.get()) << i;
/* 146:    */       }
/* 147:173 */       this.h1 ^= Murmur3_32HashFunction.mixK1(k1);
/* 148:    */     }
/* 149:    */     
/* 150:    */     public HashCode makeHash()
/* 151:    */     {
/* 152:177 */       return Murmur3_32HashFunction.fmix(this.h1, this.length);
/* 153:    */     }
/* 154:    */   }
/* 155:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.Murmur3_32HashFunction
 * JD-Core Version:    0.7.0.1
 */
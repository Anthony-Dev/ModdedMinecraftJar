/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Supplier;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.zip.Adler32;
/*   9:    */ import java.util.zip.CRC32;
/*  10:    */ import java.util.zip.Checksum;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @Beta
/*  14:    */ public final class Hashing
/*  15:    */ {
/*  16:    */   public static HashFunction goodFastHash(int minimumBits)
/*  17:    */   {
/*  18: 61 */     int bits = checkPositiveAndMakeMultipleOf32(minimumBits);
/*  19: 63 */     if (bits == 32) {
/*  20: 64 */       return Murmur3_32Holder.GOOD_FAST_HASH_FUNCTION_32;
/*  21:    */     }
/*  22: 66 */     if (bits <= 128) {
/*  23: 67 */       return Murmur3_128Holder.GOOD_FAST_HASH_FUNCTION_128;
/*  24:    */     }
/*  25: 71 */     int hashFunctionsNeeded = (bits + 127) / 128;
/*  26: 72 */     HashFunction[] hashFunctions = new HashFunction[hashFunctionsNeeded];
/*  27: 73 */     hashFunctions[0] = Murmur3_128Holder.GOOD_FAST_HASH_FUNCTION_128;
/*  28: 74 */     int seed = GOOD_FAST_HASH_SEED;
/*  29: 75 */     for (int i = 1; i < hashFunctionsNeeded; i++)
/*  30:    */     {
/*  31: 76 */       seed += 1500450271;
/*  32: 77 */       hashFunctions[i] = murmur3_128(seed);
/*  33:    */     }
/*  34: 79 */     return new ConcatenatedHashFunction(hashFunctions);
/*  35:    */   }
/*  36:    */   
/*  37: 86 */   private static final int GOOD_FAST_HASH_SEED = (int)System.currentTimeMillis();
/*  38:    */   
/*  39:    */   public static HashFunction murmur3_32(int seed)
/*  40:    */   {
/*  41: 97 */     return new Murmur3_32HashFunction(seed);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static HashFunction murmur3_32()
/*  45:    */   {
/*  46:109 */     return Murmur3_32Holder.MURMUR3_32;
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static class Murmur3_32Holder
/*  50:    */   {
/*  51:113 */     static final HashFunction MURMUR3_32 = new Murmur3_32HashFunction(0);
/*  52:116 */     static final HashFunction GOOD_FAST_HASH_FUNCTION_32 = Hashing.murmur3_32(Hashing.GOOD_FAST_HASH_SEED);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static HashFunction murmur3_128(int seed)
/*  56:    */   {
/*  57:128 */     return new Murmur3_128HashFunction(seed);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static HashFunction murmur3_128()
/*  61:    */   {
/*  62:140 */     return Murmur3_128Holder.MURMUR3_128;
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static class Murmur3_128Holder
/*  66:    */   {
/*  67:144 */     static final HashFunction MURMUR3_128 = new Murmur3_128HashFunction(0);
/*  68:147 */     static final HashFunction GOOD_FAST_HASH_FUNCTION_128 = Hashing.murmur3_128(Hashing.GOOD_FAST_HASH_SEED);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static HashFunction sipHash24()
/*  72:    */   {
/*  73:158 */     return SipHash24Holder.SIP_HASH_24;
/*  74:    */   }
/*  75:    */   
/*  76:    */   private static class SipHash24Holder
/*  77:    */   {
/*  78:162 */     static final HashFunction SIP_HASH_24 = new SipHashFunction(2, 4, 506097522914230528L, 1084818905618843912L);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static HashFunction sipHash24(long k0, long k1)
/*  82:    */   {
/*  83:174 */     return new SipHashFunction(2, 4, k0, k1);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static HashFunction md5()
/*  87:    */   {
/*  88:182 */     return Md5Holder.MD5;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static class Md5Holder
/*  92:    */   {
/*  93:186 */     static final HashFunction MD5 = new MessageDigestHashFunction("MD5", "Hashing.md5()");
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static HashFunction sha1()
/*  97:    */   {
/*  98:194 */     return Sha1Holder.SHA_1;
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static class Sha1Holder
/* 102:    */   {
/* 103:198 */     static final HashFunction SHA_1 = new MessageDigestHashFunction("SHA-1", "Hashing.sha1()");
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static HashFunction sha256()
/* 107:    */   {
/* 108:207 */     return Sha256Holder.SHA_256;
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static class Sha256Holder
/* 112:    */   {
/* 113:211 */     static final HashFunction SHA_256 = new MessageDigestHashFunction("SHA-256", "Hashing.sha256()");
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static HashFunction sha512()
/* 117:    */   {
/* 118:220 */     return Sha512Holder.SHA_512;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private static class Sha512Holder
/* 122:    */   {
/* 123:224 */     static final HashFunction SHA_512 = new MessageDigestHashFunction("SHA-512", "Hashing.sha512()");
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static HashFunction crc32()
/* 127:    */   {
/* 128:238 */     return Crc32Holder.CRC_32;
/* 129:    */   }
/* 130:    */   
/* 131:    */   private static class Crc32Holder
/* 132:    */   {
/* 133:242 */     static final HashFunction CRC_32 = Hashing.checksumHashFunction(Hashing.ChecksumType.CRC_32, "Hashing.crc32()");
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static HashFunction adler32()
/* 137:    */   {
/* 138:256 */     return Adler32Holder.ADLER_32;
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static class Adler32Holder
/* 142:    */   {
/* 143:260 */     static final HashFunction ADLER_32 = Hashing.checksumHashFunction(Hashing.ChecksumType.ADLER_32, "Hashing.adler32()");
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static HashFunction checksumHashFunction(ChecksumType type, String toString)
/* 147:    */   {
/* 148:265 */     return new ChecksumHashFunction(type, type.bits, toString);
/* 149:    */   }
/* 150:    */   
/* 151:    */   static abstract enum ChecksumType
/* 152:    */     implements Supplier<Checksum>
/* 153:    */   {
/* 154:269 */     CRC_32(32),  ADLER_32(32);
/* 155:    */     
/* 156:    */     private final int bits;
/* 157:    */     
/* 158:    */     private ChecksumType(int bits)
/* 159:    */     {
/* 160:285 */       this.bits = bits;
/* 161:    */     }
/* 162:    */     
/* 163:    */     public abstract Checksum get();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static int consistentHash(HashCode hashCode, int buckets)
/* 167:    */   {
/* 168:306 */     return consistentHash(hashCode.padToLong(), buckets);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static int consistentHash(long input, int buckets)
/* 172:    */   {
/* 173:323 */     Preconditions.checkArgument(buckets > 0, "buckets must be positive: %s", new Object[] { Integer.valueOf(buckets) });
/* 174:324 */     LinearCongruentialGenerator generator = new LinearCongruentialGenerator(input);
/* 175:325 */     int candidate = 0;
/* 176:    */     for (;;)
/* 177:    */     {
/* 178:330 */       int next = (int)((candidate + 1) / generator.nextDouble());
/* 179:331 */       if ((next < 0) || (next >= buckets)) {
/* 180:    */         break;
/* 181:    */       }
/* 182:332 */       candidate = next;
/* 183:    */     }
/* 184:334 */     return candidate;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static HashCode combineOrdered(Iterable<HashCode> hashCodes)
/* 188:    */   {
/* 189:350 */     Iterator<HashCode> iterator = hashCodes.iterator();
/* 190:351 */     Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
/* 191:352 */     int bits = ((HashCode)iterator.next()).bits();
/* 192:353 */     byte[] resultBytes = new byte[bits / 8];
/* 193:354 */     for (HashCode hashCode : hashCodes)
/* 194:    */     {
/* 195:355 */       byte[] nextBytes = hashCode.asBytes();
/* 196:356 */       Preconditions.checkArgument(nextBytes.length == resultBytes.length, "All hashcodes must have the same bit length.");
/* 197:358 */       for (int i = 0; i < nextBytes.length; i++) {
/* 198:359 */         resultBytes[i] = ((byte)(resultBytes[i] * 37 ^ nextBytes[i]));
/* 199:    */       }
/* 200:    */     }
/* 201:362 */     return HashCode.fromBytesNoCopy(resultBytes);
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static HashCode combineUnordered(Iterable<HashCode> hashCodes)
/* 205:    */   {
/* 206:376 */     Iterator<HashCode> iterator = hashCodes.iterator();
/* 207:377 */     Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
/* 208:378 */     byte[] resultBytes = new byte[((HashCode)iterator.next()).bits() / 8];
/* 209:379 */     for (HashCode hashCode : hashCodes)
/* 210:    */     {
/* 211:380 */       byte[] nextBytes = hashCode.asBytes();
/* 212:381 */       Preconditions.checkArgument(nextBytes.length == resultBytes.length, "All hashcodes must have the same bit length.");
/* 213:383 */       for (int i = 0; i < nextBytes.length; tmp102_100++)
/* 214:    */       {
/* 215:384 */         int tmp102_100 = i; byte[] tmp102_99 = resultBytes;tmp102_99[tmp102_100] = ((byte)(tmp102_99[tmp102_100] + nextBytes[tmp102_100]));
/* 216:    */       }
/* 217:    */     }
/* 218:387 */     return HashCode.fromBytesNoCopy(resultBytes);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static int checkPositiveAndMakeMultipleOf32(int bits)
/* 222:    */   {
/* 223:394 */     Preconditions.checkArgument(bits > 0, "Number of bits must be positive");
/* 224:395 */     return bits + 31 & 0xFFFFFFE0;
/* 225:    */   }
/* 226:    */   
/* 227:    */   @VisibleForTesting
/* 228:    */   static final class ConcatenatedHashFunction
/* 229:    */     extends AbstractCompositeHashFunction
/* 230:    */   {
/* 231:    */     private final int bits;
/* 232:    */     
/* 233:    */     ConcatenatedHashFunction(HashFunction... functions)
/* 234:    */     {
/* 235:404 */       super();
/* 236:405 */       int bitSum = 0;
/* 237:406 */       for (HashFunction function : functions) {
/* 238:407 */         bitSum += function.bits();
/* 239:    */       }
/* 240:409 */       this.bits = bitSum;
/* 241:    */     }
/* 242:    */     
/* 243:    */     HashCode makeHash(Hasher[] hashers)
/* 244:    */     {
/* 245:414 */       byte[] bytes = new byte[this.bits / 8];
/* 246:415 */       int i = 0;
/* 247:416 */       for (Hasher hasher : hashers)
/* 248:    */       {
/* 249:417 */         HashCode newHash = hasher.hash();
/* 250:418 */         i += newHash.writeBytesTo(bytes, i, newHash.bits() / 8);
/* 251:    */       }
/* 252:420 */       return HashCode.fromBytesNoCopy(bytes);
/* 253:    */     }
/* 254:    */     
/* 255:    */     public int bits()
/* 256:    */     {
/* 257:425 */       return this.bits;
/* 258:    */     }
/* 259:    */     
/* 260:    */     public boolean equals(@Nullable Object object)
/* 261:    */     {
/* 262:430 */       if ((object instanceof ConcatenatedHashFunction))
/* 263:    */       {
/* 264:431 */         ConcatenatedHashFunction other = (ConcatenatedHashFunction)object;
/* 265:432 */         if ((this.bits != other.bits) || (this.functions.length != other.functions.length)) {
/* 266:433 */           return false;
/* 267:    */         }
/* 268:435 */         for (int i = 0; i < this.functions.length; i++) {
/* 269:436 */           if (!this.functions[i].equals(other.functions[i])) {
/* 270:437 */             return false;
/* 271:    */           }
/* 272:    */         }
/* 273:440 */         return true;
/* 274:    */       }
/* 275:442 */       return false;
/* 276:    */     }
/* 277:    */     
/* 278:    */     public int hashCode()
/* 279:    */     {
/* 280:447 */       int hash = this.bits;
/* 281:448 */       for (HashFunction function : this.functions) {
/* 282:449 */         hash ^= function.hashCode();
/* 283:    */       }
/* 284:451 */       return hash;
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:    */   private static final class LinearCongruentialGenerator
/* 289:    */   {
/* 290:    */     private long state;
/* 291:    */     
/* 292:    */     public LinearCongruentialGenerator(long seed)
/* 293:    */     {
/* 294:463 */       this.state = seed;
/* 295:    */     }
/* 296:    */     
/* 297:    */     public double nextDouble()
/* 298:    */     {
/* 299:467 */       this.state = (2862933555777941757L * this.state + 1L);
/* 300:468 */       return ((int)(this.state >>> 33) + 1) / 2147483648.0D;
/* 301:    */     }
/* 302:    */   }
/* 303:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.Hashing
 * JD-Core Version:    0.7.0.1
 */
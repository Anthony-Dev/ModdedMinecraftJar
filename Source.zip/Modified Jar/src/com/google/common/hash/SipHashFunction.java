/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ final class SipHashFunction
/*   9:    */   extends AbstractStreamingHashFunction
/*  10:    */   implements Serializable
/*  11:    */ {
/*  12:    */   private final int c;
/*  13:    */   private final int d;
/*  14:    */   private final long k0;
/*  15:    */   private final long k1;
/*  16:    */   private static final long serialVersionUID = 0L;
/*  17:    */   
/*  18:    */   SipHashFunction(int c, int d, long k0, long k1)
/*  19:    */   {
/*  20: 53 */     Preconditions.checkArgument(c > 0, "The number of SipRound iterations (c=%s) during Compression must be positive.", new Object[] { Integer.valueOf(c) });
/*  21:    */     
/*  22: 55 */     Preconditions.checkArgument(d > 0, "The number of SipRound iterations (d=%s) during Finalization must be positive.", new Object[] { Integer.valueOf(d) });
/*  23:    */     
/*  24: 57 */     this.c = c;
/*  25: 58 */     this.d = d;
/*  26: 59 */     this.k0 = k0;
/*  27: 60 */     this.k1 = k1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public int bits()
/*  31:    */   {
/*  32: 64 */     return 64;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Hasher newHasher()
/*  36:    */   {
/*  37: 68 */     return new SipHasher(this.c, this.d, this.k0, this.k1);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String toString()
/*  41:    */   {
/*  42: 74 */     return "Hashing.sipHash" + this.c + "" + this.d + "(" + this.k0 + ", " + this.k1 + ")";
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean equals(@Nullable Object object)
/*  46:    */   {
/*  47: 79 */     if ((object instanceof SipHashFunction))
/*  48:    */     {
/*  49: 80 */       SipHashFunction other = (SipHashFunction)object;
/*  50: 81 */       return (this.c == other.c) && (this.d == other.d) && (this.k0 == other.k0) && (this.k1 == other.k1);
/*  51:    */     }
/*  52: 86 */     return false;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public int hashCode()
/*  56:    */   {
/*  57: 91 */     return (int)(getClass().hashCode() ^ this.c ^ this.d ^ this.k0 ^ this.k1);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static final class SipHasher
/*  61:    */     extends AbstractStreamingHashFunction.AbstractStreamingHasher
/*  62:    */   {
/*  63:    */     private static final int CHUNK_SIZE = 8;
/*  64:    */     private final int c;
/*  65:    */     private final int d;
/*  66:106 */     private long v0 = 8317987319222330741L;
/*  67:107 */     private long v1 = 7237128888997146477L;
/*  68:108 */     private long v2 = 7816392313619706465L;
/*  69:109 */     private long v3 = 8387220255154660723L;
/*  70:112 */     private long b = 0L;
/*  71:116 */     private long finalM = 0L;
/*  72:    */     
/*  73:    */     SipHasher(int c, int d, long k0, long k1)
/*  74:    */     {
/*  75:119 */       super();
/*  76:120 */       this.c = c;
/*  77:121 */       this.d = d;
/*  78:122 */       this.v0 ^= k0;
/*  79:123 */       this.v1 ^= k1;
/*  80:124 */       this.v2 ^= k0;
/*  81:125 */       this.v3 ^= k1;
/*  82:    */     }
/*  83:    */     
/*  84:    */     protected void process(ByteBuffer buffer)
/*  85:    */     {
/*  86:129 */       this.b += 8L;
/*  87:130 */       processM(buffer.getLong());
/*  88:    */     }
/*  89:    */     
/*  90:    */     protected void processRemaining(ByteBuffer buffer)
/*  91:    */     {
/*  92:134 */       this.b += buffer.remaining();
/*  93:135 */       for (int i = 0; buffer.hasRemaining(); i += 8) {
/*  94:136 */         this.finalM ^= (buffer.get() & 0xFF) << i;
/*  95:    */       }
/*  96:    */     }
/*  97:    */     
/*  98:    */     public HashCode makeHash()
/*  99:    */     {
/* 100:142 */       this.finalM ^= this.b << 56;
/* 101:143 */       processM(this.finalM);
/* 102:    */       
/* 103:    */ 
/* 104:146 */       this.v2 ^= 0xFF;
/* 105:147 */       sipRound(this.d);
/* 106:148 */       return HashCode.fromLong(this.v0 ^ this.v1 ^ this.v2 ^ this.v3);
/* 107:    */     }
/* 108:    */     
/* 109:    */     private void processM(long m)
/* 110:    */     {
/* 111:152 */       this.v3 ^= m;
/* 112:153 */       sipRound(this.c);
/* 113:154 */       this.v0 ^= m;
/* 114:    */     }
/* 115:    */     
/* 116:    */     private void sipRound(int iterations)
/* 117:    */     {
/* 118:158 */       for (int i = 0; i < iterations; i++)
/* 119:    */       {
/* 120:159 */         this.v0 += this.v1;
/* 121:160 */         this.v2 += this.v3;
/* 122:161 */         this.v1 = Long.rotateLeft(this.v1, 13);
/* 123:162 */         this.v3 = Long.rotateLeft(this.v3, 16);
/* 124:163 */         this.v1 ^= this.v0;
/* 125:164 */         this.v3 ^= this.v2;
/* 126:165 */         this.v0 = Long.rotateLeft(this.v0, 32);
/* 127:166 */         this.v2 += this.v1;
/* 128:167 */         this.v0 += this.v3;
/* 129:168 */         this.v1 = Long.rotateLeft(this.v1, 17);
/* 130:169 */         this.v3 = Long.rotateLeft(this.v3, 21);
/* 131:170 */         this.v1 ^= this.v2;
/* 132:171 */         this.v3 ^= this.v0;
/* 133:172 */         this.v2 = Long.rotateLeft(this.v2, 32);
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.SipHashFunction
 * JD-Core Version:    0.7.0.1
 */
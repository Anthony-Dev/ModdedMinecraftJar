/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.primitives.Ints;
/*   6:    */ import com.google.common.primitives.UnsignedInts;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.security.MessageDigest;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ public abstract class HashCode
/*  13:    */ {
/*  14:    */   public abstract int bits();
/*  15:    */   
/*  16:    */   public abstract int asInt();
/*  17:    */   
/*  18:    */   public abstract long asLong();
/*  19:    */   
/*  20:    */   public abstract long padToLong();
/*  21:    */   
/*  22:    */   public abstract byte[] asBytes();
/*  23:    */   
/*  24:    */   public int writeBytesTo(byte[] dest, int offset, int maxLength)
/*  25:    */   {
/*  26: 90 */     maxLength = Ints.min(new int[] { maxLength, bits() / 8 });
/*  27: 91 */     Preconditions.checkPositionIndexes(offset, offset + maxLength, dest.length);
/*  28: 92 */     writeBytesToImpl(dest, offset, maxLength);
/*  29: 93 */     return maxLength;
/*  30:    */   }
/*  31:    */   
/*  32:    */   abstract void writeBytesToImpl(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*  33:    */   
/*  34:    */   byte[] getBytesInternal()
/*  35:    */   {
/*  36:104 */     return asBytes();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static HashCode fromInt(int hash)
/*  40:    */   {
/*  41:114 */     return new IntHashCode(hash);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static final class IntHashCode
/*  45:    */     extends HashCode
/*  46:    */     implements Serializable
/*  47:    */   {
/*  48:    */     final int hash;
/*  49:    */     private static final long serialVersionUID = 0L;
/*  50:    */     
/*  51:    */     IntHashCode(int hash)
/*  52:    */     {
/*  53:121 */       this.hash = hash;
/*  54:    */     }
/*  55:    */     
/*  56:    */     public int bits()
/*  57:    */     {
/*  58:126 */       return 32;
/*  59:    */     }
/*  60:    */     
/*  61:    */     public byte[] asBytes()
/*  62:    */     {
/*  63:131 */       return new byte[] { (byte)this.hash, (byte)(this.hash >> 8), (byte)(this.hash >> 16), (byte)(this.hash >> 24) };
/*  64:    */     }
/*  65:    */     
/*  66:    */     public int asInt()
/*  67:    */     {
/*  68:140 */       return this.hash;
/*  69:    */     }
/*  70:    */     
/*  71:    */     public long asLong()
/*  72:    */     {
/*  73:145 */       throw new IllegalStateException("this HashCode only has 32 bits; cannot create a long");
/*  74:    */     }
/*  75:    */     
/*  76:    */     public long padToLong()
/*  77:    */     {
/*  78:150 */       return UnsignedInts.toLong(this.hash);
/*  79:    */     }
/*  80:    */     
/*  81:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/*  82:    */     {
/*  83:155 */       for (int i = 0; i < maxLength; i++) {
/*  84:156 */         dest[(offset + i)] = ((byte)(this.hash >> i * 8));
/*  85:    */       }
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static HashCode fromLong(long hash)
/*  90:    */   {
/*  91:170 */     return new LongHashCode(hash);
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static final class LongHashCode
/*  95:    */     extends HashCode
/*  96:    */     implements Serializable
/*  97:    */   {
/*  98:    */     final long hash;
/*  99:    */     private static final long serialVersionUID = 0L;
/* 100:    */     
/* 101:    */     LongHashCode(long hash)
/* 102:    */     {
/* 103:177 */       this.hash = hash;
/* 104:    */     }
/* 105:    */     
/* 106:    */     public int bits()
/* 107:    */     {
/* 108:182 */       return 64;
/* 109:    */     }
/* 110:    */     
/* 111:    */     public byte[] asBytes()
/* 112:    */     {
/* 113:187 */       return new byte[] { (byte)(int)this.hash, (byte)(int)(this.hash >> 8), (byte)(int)(this.hash >> 16), (byte)(int)(this.hash >> 24), (byte)(int)(this.hash >> 32), (byte)(int)(this.hash >> 40), (byte)(int)(this.hash >> 48), (byte)(int)(this.hash >> 56) };
/* 114:    */     }
/* 115:    */     
/* 116:    */     public int asInt()
/* 117:    */     {
/* 118:200 */       return (int)this.hash;
/* 119:    */     }
/* 120:    */     
/* 121:    */     public long asLong()
/* 122:    */     {
/* 123:205 */       return this.hash;
/* 124:    */     }
/* 125:    */     
/* 126:    */     public long padToLong()
/* 127:    */     {
/* 128:210 */       return this.hash;
/* 129:    */     }
/* 130:    */     
/* 131:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/* 132:    */     {
/* 133:215 */       for (int i = 0; i < maxLength; i++) {
/* 134:216 */         dest[(offset + i)] = ((byte)(int)(this.hash >> i * 8));
/* 135:    */       }
/* 136:    */     }
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static HashCode fromBytes(byte[] bytes)
/* 140:    */   {
/* 141:230 */     Preconditions.checkArgument(bytes.length >= 1, "A HashCode must contain at least 1 byte.");
/* 142:231 */     return fromBytesNoCopy((byte[])bytes.clone());
/* 143:    */   }
/* 144:    */   
/* 145:    */   static HashCode fromBytesNoCopy(byte[] bytes)
/* 146:    */   {
/* 147:239 */     return new BytesHashCode(bytes);
/* 148:    */   }
/* 149:    */   
/* 150:    */   private static final class BytesHashCode
/* 151:    */     extends HashCode
/* 152:    */     implements Serializable
/* 153:    */   {
/* 154:    */     final byte[] bytes;
/* 155:    */     private static final long serialVersionUID = 0L;
/* 156:    */     
/* 157:    */     BytesHashCode(byte[] bytes)
/* 158:    */     {
/* 159:246 */       this.bytes = ((byte[])Preconditions.checkNotNull(bytes));
/* 160:    */     }
/* 161:    */     
/* 162:    */     public int bits()
/* 163:    */     {
/* 164:251 */       return this.bytes.length * 8;
/* 165:    */     }
/* 166:    */     
/* 167:    */     public byte[] asBytes()
/* 168:    */     {
/* 169:256 */       return (byte[])this.bytes.clone();
/* 170:    */     }
/* 171:    */     
/* 172:    */     public int asInt()
/* 173:    */     {
/* 174:261 */       Preconditions.checkState(this.bytes.length >= 4, "HashCode#asInt() requires >= 4 bytes (it only has %s bytes).", new Object[] { Integer.valueOf(this.bytes.length) });
/* 175:    */       
/* 176:263 */       return this.bytes[0] & 0xFF | (this.bytes[1] & 0xFF) << 8 | (this.bytes[2] & 0xFF) << 16 | (this.bytes[3] & 0xFF) << 24;
/* 177:    */     }
/* 178:    */     
/* 179:    */     public long asLong()
/* 180:    */     {
/* 181:271 */       Preconditions.checkState(this.bytes.length >= 8, "HashCode#asLong() requires >= 8 bytes (it only has %s bytes).", new Object[] { Integer.valueOf(this.bytes.length) });
/* 182:    */       
/* 183:273 */       return padToLong();
/* 184:    */     }
/* 185:    */     
/* 186:    */     public long padToLong()
/* 187:    */     {
/* 188:278 */       long retVal = this.bytes[0] & 0xFF;
/* 189:279 */       for (int i = 1; i < Math.min(this.bytes.length, 8); i++) {
/* 190:280 */         retVal |= (this.bytes[i] & 0xFF) << i * 8;
/* 191:    */       }
/* 192:282 */       return retVal;
/* 193:    */     }
/* 194:    */     
/* 195:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/* 196:    */     {
/* 197:287 */       System.arraycopy(this.bytes, 0, dest, offset, maxLength);
/* 198:    */     }
/* 199:    */     
/* 200:    */     byte[] getBytesInternal()
/* 201:    */     {
/* 202:292 */       return this.bytes;
/* 203:    */     }
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static HashCode fromString(String string)
/* 207:    */   {
/* 208:309 */     Preconditions.checkArgument(string.length() >= 2, "input string (%s) must have at least 2 characters", new Object[] { string });
/* 209:    */     
/* 210:311 */     Preconditions.checkArgument(string.length() % 2 == 0, "input string (%s) must have an even number of characters", new Object[] { string });
/* 211:    */     
/* 212:    */ 
/* 213:314 */     byte[] bytes = new byte[string.length() / 2];
/* 214:315 */     for (int i = 0; i < string.length(); i += 2)
/* 215:    */     {
/* 216:316 */       int ch1 = decode(string.charAt(i)) << 4;
/* 217:317 */       int ch2 = decode(string.charAt(i + 1));
/* 218:318 */       bytes[(i / 2)] = ((byte)(ch1 + ch2));
/* 219:    */     }
/* 220:320 */     return fromBytesNoCopy(bytes);
/* 221:    */   }
/* 222:    */   
/* 223:    */   private static int decode(char ch)
/* 224:    */   {
/* 225:324 */     if ((ch >= '0') && (ch <= '9')) {
/* 226:325 */       return ch - '0';
/* 227:    */     }
/* 228:327 */     if ((ch >= 'a') && (ch <= 'f')) {
/* 229:328 */       return ch - 'a' + 10;
/* 230:    */     }
/* 231:330 */     throw new IllegalArgumentException("Illegal hexadecimal character: " + ch);
/* 232:    */   }
/* 233:    */   
/* 234:    */   public final boolean equals(@Nullable Object object)
/* 235:    */   {
/* 236:335 */     if ((object instanceof HashCode))
/* 237:    */     {
/* 238:336 */       HashCode that = (HashCode)object;
/* 239:    */       
/* 240:    */ 
/* 241:339 */       return MessageDigest.isEqual(asBytes(), that.asBytes());
/* 242:    */     }
/* 243:341 */     return false;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public final int hashCode()
/* 247:    */   {
/* 248:353 */     if (bits() >= 32) {
/* 249:354 */       return asInt();
/* 250:    */     }
/* 251:357 */     byte[] bytes = asBytes();
/* 252:358 */     int val = bytes[0] & 0xFF;
/* 253:359 */     for (int i = 1; i < bytes.length; i++) {
/* 254:360 */       val |= (bytes[i] & 0xFF) << i * 8;
/* 255:    */     }
/* 256:362 */     return val;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public final String toString()
/* 260:    */   {
/* 261:378 */     byte[] bytes = asBytes();
/* 262:379 */     StringBuilder sb = new StringBuilder(2 * bytes.length);
/* 263:380 */     for (byte b : bytes) {
/* 264:381 */       sb.append(hexDigits[(b >> 4 & 0xF)]).append(hexDigits[(b & 0xF)]);
/* 265:    */     }
/* 266:383 */     return sb.toString();
/* 267:    */   }
/* 268:    */   
/* 269:386 */   private static final char[] hexDigits = "0123456789abcdef".toCharArray();
/* 270:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.HashCode
 * JD-Core Version:    0.7.0.1
 */
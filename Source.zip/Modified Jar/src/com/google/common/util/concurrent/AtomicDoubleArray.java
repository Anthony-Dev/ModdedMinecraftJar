/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.ObjectInputStream;
/*   5:    */ import java.io.ObjectOutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.concurrent.atomic.AtomicLongArray;
/*   8:    */ 
/*   9:    */ public class AtomicDoubleArray
/*  10:    */   implements Serializable
/*  11:    */ {
/*  12:    */   private static final long serialVersionUID = 0L;
/*  13:    */   private transient AtomicLongArray longs;
/*  14:    */   
/*  15:    */   public AtomicDoubleArray(int length)
/*  16:    */   {
/*  17: 56 */     this.longs = new AtomicLongArray(length);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public AtomicDoubleArray(double[] array)
/*  21:    */   {
/*  22: 67 */     int len = array.length;
/*  23: 68 */     long[] longArray = new long[len];
/*  24: 69 */     for (int i = 0; i < len; i++) {
/*  25: 70 */       longArray[i] = Double.doubleToRawLongBits(array[i]);
/*  26:    */     }
/*  27: 72 */     this.longs = new AtomicLongArray(longArray);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public final int length()
/*  31:    */   {
/*  32: 81 */     return this.longs.length();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public final double get(int i)
/*  36:    */   {
/*  37: 91 */     return Double.longBitsToDouble(this.longs.get(i));
/*  38:    */   }
/*  39:    */   
/*  40:    */   public final void set(int i, double newValue)
/*  41:    */   {
/*  42:101 */     long next = Double.doubleToRawLongBits(newValue);
/*  43:102 */     this.longs.set(i, next);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public final void lazySet(int i, double newValue)
/*  47:    */   {
/*  48:112 */     set(i, newValue);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public final double getAndSet(int i, double newValue)
/*  52:    */   {
/*  53:127 */     long next = Double.doubleToRawLongBits(newValue);
/*  54:128 */     return Double.longBitsToDouble(this.longs.getAndSet(i, next));
/*  55:    */   }
/*  56:    */   
/*  57:    */   public final boolean compareAndSet(int i, double expect, double update)
/*  58:    */   {
/*  59:144 */     return this.longs.compareAndSet(i, Double.doubleToRawLongBits(expect), Double.doubleToRawLongBits(update));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public final boolean weakCompareAndSet(int i, double expect, double update)
/*  63:    */   {
/*  64:167 */     return this.longs.weakCompareAndSet(i, Double.doubleToRawLongBits(expect), Double.doubleToRawLongBits(update));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public final double getAndAdd(int i, double delta)
/*  68:    */   {
/*  69:    */     for (;;)
/*  70:    */     {
/*  71:181 */       long current = this.longs.get(i);
/*  72:182 */       double currentVal = Double.longBitsToDouble(current);
/*  73:183 */       double nextVal = currentVal + delta;
/*  74:184 */       long next = Double.doubleToRawLongBits(nextVal);
/*  75:185 */       if (this.longs.compareAndSet(i, current, next)) {
/*  76:186 */         return currentVal;
/*  77:    */       }
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public double addAndGet(int i, double delta)
/*  82:    */   {
/*  83:    */     for (;;)
/*  84:    */     {
/*  85:200 */       long current = this.longs.get(i);
/*  86:201 */       double currentVal = Double.longBitsToDouble(current);
/*  87:202 */       double nextVal = currentVal + delta;
/*  88:203 */       long next = Double.doubleToRawLongBits(nextVal);
/*  89:204 */       if (this.longs.compareAndSet(i, current, next)) {
/*  90:205 */         return nextVal;
/*  91:    */       }
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   public String toString()
/*  96:    */   {
/*  97:215 */     int iMax = length() - 1;
/*  98:216 */     if (iMax == -1) {
/*  99:217 */       return "[]";
/* 100:    */     }
/* 101:221 */     StringBuilder b = new StringBuilder(19 * (iMax + 1));
/* 102:222 */     b.append('[');
/* 103:223 */     for (int i = 0;; i++)
/* 104:    */     {
/* 105:224 */       b.append(Double.longBitsToDouble(this.longs.get(i)));
/* 106:225 */       if (i == iMax) {
/* 107:226 */         return ']';
/* 108:    */       }
/* 109:228 */       b.append(',').append(' ');
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private void writeObject(ObjectOutputStream s)
/* 114:    */     throws IOException
/* 115:    */   {
/* 116:240 */     s.defaultWriteObject();
/* 117:    */     
/* 118:    */ 
/* 119:243 */     int length = length();
/* 120:244 */     s.writeInt(length);
/* 121:247 */     for (int i = 0; i < length; i++) {
/* 122:248 */       s.writeDouble(get(i));
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private void readObject(ObjectInputStream s)
/* 127:    */     throws IOException, ClassNotFoundException
/* 128:    */   {
/* 129:257 */     s.defaultReadObject();
/* 130:    */     
/* 131:    */ 
/* 132:260 */     int length = s.readInt();
/* 133:261 */     this.longs = new AtomicLongArray(length);
/* 134:264 */     for (int i = 0; i < length; i++) {
/* 135:265 */       set(i, s.readDouble());
/* 136:    */     }
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AtomicDoubleArray
 * JD-Core Version:    0.7.0.1
 */
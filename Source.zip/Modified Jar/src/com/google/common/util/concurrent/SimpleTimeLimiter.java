/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.collect.ObjectArrays;
/*   6:    */ import com.google.common.collect.Sets;
/*   7:    */ import java.lang.reflect.InvocationHandler;
/*   8:    */ import java.lang.reflect.InvocationTargetException;
/*   9:    */ import java.lang.reflect.Method;
/*  10:    */ import java.lang.reflect.Proxy;
/*  11:    */ import java.util.Set;
/*  12:    */ import java.util.concurrent.Callable;
/*  13:    */ import java.util.concurrent.ExecutionException;
/*  14:    */ import java.util.concurrent.ExecutorService;
/*  15:    */ import java.util.concurrent.Executors;
/*  16:    */ import java.util.concurrent.Future;
/*  17:    */ import java.util.concurrent.TimeUnit;
/*  18:    */ import java.util.concurrent.TimeoutException;
/*  19:    */ 
/*  20:    */ @Beta
/*  21:    */ public final class SimpleTimeLimiter
/*  22:    */   implements TimeLimiter
/*  23:    */ {
/*  24:    */   private final ExecutorService executor;
/*  25:    */   
/*  26:    */   public SimpleTimeLimiter(ExecutorService executor)
/*  27:    */   {
/*  28: 67 */     this.executor = ((ExecutorService)Preconditions.checkNotNull(executor));
/*  29:    */   }
/*  30:    */   
/*  31:    */   public SimpleTimeLimiter()
/*  32:    */   {
/*  33: 80 */     this(Executors.newCachedThreadPool());
/*  34:    */   }
/*  35:    */   
/*  36:    */   public <T> T newProxy(final T target, Class<T> interfaceType, final long timeoutDuration, TimeUnit timeoutUnit)
/*  37:    */   {
/*  38: 86 */     Preconditions.checkNotNull(target);
/*  39: 87 */     Preconditions.checkNotNull(interfaceType);
/*  40: 88 */     Preconditions.checkNotNull(timeoutUnit);
/*  41: 89 */     Preconditions.checkArgument(timeoutDuration > 0L, "bad timeout: %s", new Object[] { Long.valueOf(timeoutDuration) });
/*  42: 90 */     Preconditions.checkArgument(interfaceType.isInterface(), "interfaceType must be an interface type");
/*  43:    */     
/*  44:    */ 
/*  45: 93 */     final Set<Method> interruptibleMethods = findInterruptibleMethods(interfaceType);
/*  46:    */     
/*  47:    */ 
/*  48: 96 */     InvocationHandler handler = new InvocationHandler()
/*  49:    */     {
/*  50:    */       public Object invoke(Object obj, final Method method, final Object[] args)
/*  51:    */         throws Throwable
/*  52:    */       {
/*  53:100 */         Callable<Object> callable = new Callable()
/*  54:    */         {
/*  55:    */           public Object call()
/*  56:    */             throws Exception
/*  57:    */           {
/*  58:    */             try
/*  59:    */             {
/*  60:104 */               return method.invoke(SimpleTimeLimiter.1.this.val$target, args);
/*  61:    */             }
/*  62:    */             catch (InvocationTargetException e)
/*  63:    */             {
/*  64:106 */               SimpleTimeLimiter.throwCause(e, false);
/*  65:107 */               throw new AssertionError("can't get here");
/*  66:    */             }
/*  67:    */           }
/*  68:110 */         };
/*  69:111 */         return SimpleTimeLimiter.this.callWithTimeout(callable, timeoutDuration, interruptibleMethods, this.val$interruptibleMethods.contains(method));
/*  70:    */       }
/*  71:114 */     };
/*  72:115 */     return newProxy(interfaceType, handler);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public <T> T callWithTimeout(Callable<T> callable, long timeoutDuration, TimeUnit timeoutUnit, boolean amInterruptible)
/*  76:    */     throws Exception
/*  77:    */   {
/*  78:122 */     Preconditions.checkNotNull(callable);
/*  79:123 */     Preconditions.checkNotNull(timeoutUnit);
/*  80:124 */     Preconditions.checkArgument(timeoutDuration > 0L, "timeout must be positive: %s", new Object[] { Long.valueOf(timeoutDuration) });
/*  81:    */     
/*  82:126 */     Future<T> future = this.executor.submit(callable);
/*  83:    */     try
/*  84:    */     {
/*  85:128 */       if (amInterruptible) {
/*  86:    */         try
/*  87:    */         {
/*  88:130 */           return future.get(timeoutDuration, timeoutUnit);
/*  89:    */         }
/*  90:    */         catch (InterruptedException e)
/*  91:    */         {
/*  92:132 */           future.cancel(true);
/*  93:133 */           throw e;
/*  94:    */         }
/*  95:    */       }
/*  96:136 */       return Uninterruptibles.getUninterruptibly(future, timeoutDuration, timeoutUnit);
/*  97:    */     }
/*  98:    */     catch (ExecutionException e)
/*  99:    */     {
/* 100:140 */       throw throwCause(e, true);
/* 101:    */     }
/* 102:    */     catch (TimeoutException e)
/* 103:    */     {
/* 104:142 */       future.cancel(true);
/* 105:143 */       throw new UncheckedTimeoutException(e);
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static Exception throwCause(Exception e, boolean combineStackTraces)
/* 110:    */     throws Exception
/* 111:    */   {
/* 112:149 */     Throwable cause = e.getCause();
/* 113:150 */     if (cause == null) {
/* 114:151 */       throw e;
/* 115:    */     }
/* 116:153 */     if (combineStackTraces)
/* 117:    */     {
/* 118:154 */       StackTraceElement[] combined = (StackTraceElement[])ObjectArrays.concat(cause.getStackTrace(), e.getStackTrace(), StackTraceElement.class);
/* 119:    */       
/* 120:156 */       cause.setStackTrace(combined);
/* 121:    */     }
/* 122:158 */     if ((cause instanceof Exception)) {
/* 123:159 */       throw ((Exception)cause);
/* 124:    */     }
/* 125:161 */     if ((cause instanceof Error)) {
/* 126:162 */       throw ((Error)cause);
/* 127:    */     }
/* 128:165 */     throw e;
/* 129:    */   }
/* 130:    */   
/* 131:    */   private static Set<Method> findInterruptibleMethods(Class<?> interfaceType)
/* 132:    */   {
/* 133:169 */     Set<Method> set = Sets.newHashSet();
/* 134:170 */     for (Method m : interfaceType.getMethods()) {
/* 135:171 */       if (declaresInterruptedEx(m)) {
/* 136:172 */         set.add(m);
/* 137:    */       }
/* 138:    */     }
/* 139:175 */     return set;
/* 140:    */   }
/* 141:    */   
/* 142:    */   private static boolean declaresInterruptedEx(Method method)
/* 143:    */   {
/* 144:179 */     for (Class<?> exType : method.getExceptionTypes()) {
/* 145:181 */       if (exType == InterruptedException.class) {
/* 146:182 */         return true;
/* 147:    */       }
/* 148:    */     }
/* 149:185 */     return false;
/* 150:    */   }
/* 151:    */   
/* 152:    */   private static <T> T newProxy(Class<T> interfaceType, InvocationHandler handler)
/* 153:    */   {
/* 154:191 */     Object object = Proxy.newProxyInstance(interfaceType.getClassLoader(), new Class[] { interfaceType }, handler);
/* 155:    */     
/* 156:193 */     return interfaceType.cast(object);
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.SimpleTimeLimiter
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Function;
/*    5:     */ import com.google.common.base.Optional;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import com.google.common.collect.ImmutableCollection;
/*    8:     */ import com.google.common.collect.ImmutableList;
/*    9:     */ import com.google.common.collect.ImmutableList.Builder;
/*   10:     */ import com.google.common.collect.Lists;
/*   11:     */ import com.google.common.collect.Ordering;
/*   12:     */ import com.google.common.collect.Queues;
/*   13:     */ import com.google.common.collect.Sets;
/*   14:     */ import java.lang.reflect.Constructor;
/*   15:     */ import java.lang.reflect.InvocationTargetException;
/*   16:     */ import java.lang.reflect.UndeclaredThrowableException;
/*   17:     */ import java.util.Arrays;
/*   18:     */ import java.util.Collections;
/*   19:     */ import java.util.List;
/*   20:     */ import java.util.Set;
/*   21:     */ import java.util.concurrent.CancellationException;
/*   22:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   23:     */ import java.util.concurrent.CountDownLatch;
/*   24:     */ import java.util.concurrent.ExecutionException;
/*   25:     */ import java.util.concurrent.Executor;
/*   26:     */ import java.util.concurrent.Future;
/*   27:     */ import java.util.concurrent.TimeUnit;
/*   28:     */ import java.util.concurrent.TimeoutException;
/*   29:     */ import java.util.concurrent.atomic.AtomicInteger;
/*   30:     */ import java.util.logging.Level;
/*   31:     */ import java.util.logging.Logger;
/*   32:     */ import javax.annotation.Nullable;
/*   33:     */ 
/*   34:     */ @Beta
/*   35:     */ public final class Futures
/*   36:     */ {
/*   37:     */   public static <V, X extends Exception> CheckedFuture<V, X> makeChecked(ListenableFuture<V> future, Function<Exception, X> mapper)
/*   38:     */   {
/*   39:  90 */     return new MappingCheckedFuture((ListenableFuture)Preconditions.checkNotNull(future), mapper);
/*   40:     */   }
/*   41:     */   
/*   42:     */   private static abstract class ImmediateFuture<V>
/*   43:     */     implements ListenableFuture<V>
/*   44:     */   {
/*   45:  96 */     private static final Logger log = Logger.getLogger(ImmediateFuture.class.getName());
/*   46:     */     
/*   47:     */     public void addListener(Runnable listener, Executor executor)
/*   48:     */     {
/*   49: 101 */       Preconditions.checkNotNull(listener, "Runnable was null.");
/*   50: 102 */       Preconditions.checkNotNull(executor, "Executor was null.");
/*   51:     */       try
/*   52:     */       {
/*   53: 104 */         executor.execute(listener);
/*   54:     */       }
/*   55:     */       catch (RuntimeException e)
/*   56:     */       {
/*   57: 108 */         log.log(Level.SEVERE, "RuntimeException while executing runnable " + listener + " with executor " + executor, e);
/*   58:     */       }
/*   59:     */     }
/*   60:     */     
/*   61:     */     public boolean cancel(boolean mayInterruptIfRunning)
/*   62:     */     {
/*   63: 115 */       return false;
/*   64:     */     }
/*   65:     */     
/*   66:     */     public abstract V get()
/*   67:     */       throws ExecutionException;
/*   68:     */     
/*   69:     */     public V get(long timeout, TimeUnit unit)
/*   70:     */       throws ExecutionException
/*   71:     */     {
/*   72: 123 */       Preconditions.checkNotNull(unit);
/*   73: 124 */       return get();
/*   74:     */     }
/*   75:     */     
/*   76:     */     public boolean isCancelled()
/*   77:     */     {
/*   78: 129 */       return false;
/*   79:     */     }
/*   80:     */     
/*   81:     */     public boolean isDone()
/*   82:     */     {
/*   83: 134 */       return true;
/*   84:     */     }
/*   85:     */   }
/*   86:     */   
/*   87:     */   private static class ImmediateSuccessfulFuture<V>
/*   88:     */     extends Futures.ImmediateFuture<V>
/*   89:     */   {
/*   90:     */     @Nullable
/*   91:     */     private final V value;
/*   92:     */     
/*   93:     */     ImmediateSuccessfulFuture(@Nullable V value)
/*   94:     */     {
/*   95: 142 */       super();
/*   96: 143 */       this.value = value;
/*   97:     */     }
/*   98:     */     
/*   99:     */     public V get()
/*  100:     */     {
/*  101: 148 */       return this.value;
/*  102:     */     }
/*  103:     */   }
/*  104:     */   
/*  105:     */   private static class ImmediateSuccessfulCheckedFuture<V, X extends Exception>
/*  106:     */     extends Futures.ImmediateFuture<V>
/*  107:     */     implements CheckedFuture<V, X>
/*  108:     */   {
/*  109:     */     @Nullable
/*  110:     */     private final V value;
/*  111:     */     
/*  112:     */     ImmediateSuccessfulCheckedFuture(@Nullable V value)
/*  113:     */     {
/*  114: 157 */       super();
/*  115: 158 */       this.value = value;
/*  116:     */     }
/*  117:     */     
/*  118:     */     public V get()
/*  119:     */     {
/*  120: 163 */       return this.value;
/*  121:     */     }
/*  122:     */     
/*  123:     */     public V checkedGet()
/*  124:     */     {
/*  125: 168 */       return this.value;
/*  126:     */     }
/*  127:     */     
/*  128:     */     public V checkedGet(long timeout, TimeUnit unit)
/*  129:     */     {
/*  130: 173 */       Preconditions.checkNotNull(unit);
/*  131: 174 */       return this.value;
/*  132:     */     }
/*  133:     */   }
/*  134:     */   
/*  135:     */   private static class ImmediateFailedFuture<V>
/*  136:     */     extends Futures.ImmediateFuture<V>
/*  137:     */   {
/*  138:     */     private final Throwable thrown;
/*  139:     */     
/*  140:     */     ImmediateFailedFuture(Throwable thrown)
/*  141:     */     {
/*  142: 182 */       super();
/*  143: 183 */       this.thrown = thrown;
/*  144:     */     }
/*  145:     */     
/*  146:     */     public V get()
/*  147:     */       throws ExecutionException
/*  148:     */     {
/*  149: 188 */       throw new ExecutionException(this.thrown);
/*  150:     */     }
/*  151:     */   }
/*  152:     */   
/*  153:     */   private static class ImmediateCancelledFuture<V>
/*  154:     */     extends Futures.ImmediateFuture<V>
/*  155:     */   {
/*  156:     */     private final CancellationException thrown;
/*  157:     */     
/*  158:     */     ImmediateCancelledFuture()
/*  159:     */     {
/*  160: 196 */       super();
/*  161: 197 */       this.thrown = new CancellationException("Immediate cancelled future.");
/*  162:     */     }
/*  163:     */     
/*  164:     */     public boolean isCancelled()
/*  165:     */     {
/*  166: 202 */       return true;
/*  167:     */     }
/*  168:     */     
/*  169:     */     public V get()
/*  170:     */     {
/*  171: 207 */       throw AbstractFuture.cancellationExceptionWithCause("Task was cancelled.", this.thrown);
/*  172:     */     }
/*  173:     */   }
/*  174:     */   
/*  175:     */   private static class ImmediateFailedCheckedFuture<V, X extends Exception>
/*  176:     */     extends Futures.ImmediateFuture<V>
/*  177:     */     implements CheckedFuture<V, X>
/*  178:     */   {
/*  179:     */     private final X thrown;
/*  180:     */     
/*  181:     */     ImmediateFailedCheckedFuture(X thrown)
/*  182:     */     {
/*  183: 217 */       super();
/*  184: 218 */       this.thrown = thrown;
/*  185:     */     }
/*  186:     */     
/*  187:     */     public V get()
/*  188:     */       throws ExecutionException
/*  189:     */     {
/*  190: 223 */       throw new ExecutionException(this.thrown);
/*  191:     */     }
/*  192:     */     
/*  193:     */     public V checkedGet()
/*  194:     */       throws Exception
/*  195:     */     {
/*  196: 228 */       throw this.thrown;
/*  197:     */     }
/*  198:     */     
/*  199:     */     public V checkedGet(long timeout, TimeUnit unit)
/*  200:     */       throws Exception
/*  201:     */     {
/*  202: 233 */       Preconditions.checkNotNull(unit);
/*  203: 234 */       throw this.thrown;
/*  204:     */     }
/*  205:     */   }
/*  206:     */   
/*  207:     */   public static <V> ListenableFuture<V> immediateFuture(@Nullable V value)
/*  208:     */   {
/*  209: 245 */     return new ImmediateSuccessfulFuture(value);
/*  210:     */   }
/*  211:     */   
/*  212:     */   public static <V, X extends Exception> CheckedFuture<V, X> immediateCheckedFuture(@Nullable V value)
/*  213:     */   {
/*  214: 258 */     return new ImmediateSuccessfulCheckedFuture(value);
/*  215:     */   }
/*  216:     */   
/*  217:     */   public static <V> ListenableFuture<V> immediateFailedFuture(Throwable throwable)
/*  218:     */   {
/*  219: 272 */     Preconditions.checkNotNull(throwable);
/*  220: 273 */     return new ImmediateFailedFuture(throwable);
/*  221:     */   }
/*  222:     */   
/*  223:     */   public static <V> ListenableFuture<V> immediateCancelledFuture()
/*  224:     */   {
/*  225: 283 */     return new ImmediateCancelledFuture();
/*  226:     */   }
/*  227:     */   
/*  228:     */   public static <V, X extends Exception> CheckedFuture<V, X> immediateFailedCheckedFuture(X exception)
/*  229:     */   {
/*  230: 298 */     Preconditions.checkNotNull(exception);
/*  231: 299 */     return new ImmediateFailedCheckedFuture(exception);
/*  232:     */   }
/*  233:     */   
/*  234:     */   public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input, FutureFallback<? extends V> fallback)
/*  235:     */   {
/*  236: 377 */     return withFallback(input, fallback, MoreExecutors.sameThreadExecutor());
/*  237:     */   }
/*  238:     */   
/*  239:     */   public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input, FutureFallback<? extends V> fallback, Executor executor)
/*  240:     */   {
/*  241: 441 */     Preconditions.checkNotNull(fallback);
/*  242: 442 */     return new FallbackFuture(input, fallback, executor);
/*  243:     */   }
/*  244:     */   
/*  245:     */   private static class FallbackFuture<V>
/*  246:     */     extends AbstractFuture<V>
/*  247:     */   {
/*  248:     */     private volatile ListenableFuture<? extends V> running;
/*  249:     */     
/*  250:     */     FallbackFuture(ListenableFuture<? extends V> input, final FutureFallback<? extends V> fallback, Executor executor)
/*  251:     */     {
/*  252: 456 */       this.running = input;
/*  253: 457 */       Futures.addCallback(this.running, new FutureCallback()
/*  254:     */       {
/*  255:     */         public void onSuccess(V value)
/*  256:     */         {
/*  257: 460 */           Futures.FallbackFuture.this.set(value);
/*  258:     */         }
/*  259:     */         
/*  260:     */         public void onFailure(Throwable t)
/*  261:     */         {
/*  262: 465 */           if (Futures.FallbackFuture.this.isCancelled()) {
/*  263: 466 */             return;
/*  264:     */           }
/*  265:     */           try
/*  266:     */           {
/*  267: 469 */             Futures.FallbackFuture.this.running = fallback.create(t);
/*  268: 470 */             if (Futures.FallbackFuture.this.isCancelled())
/*  269:     */             {
/*  270: 471 */               Futures.FallbackFuture.this.running.cancel(Futures.FallbackFuture.this.wasInterrupted());
/*  271: 472 */               return;
/*  272:     */             }
/*  273: 474 */             Futures.addCallback(Futures.FallbackFuture.this.running, new FutureCallback()
/*  274:     */             {
/*  275:     */               public void onSuccess(V value)
/*  276:     */               {
/*  277: 477 */                 Futures.FallbackFuture.this.set(value);
/*  278:     */               }
/*  279:     */               
/*  280:     */               public void onFailure(Throwable t)
/*  281:     */               {
/*  282: 482 */                 if (Futures.FallbackFuture.this.running.isCancelled()) {
/*  283: 483 */                   Futures.FallbackFuture.this.cancel(false);
/*  284:     */                 } else {
/*  285: 485 */                   Futures.FallbackFuture.this.setException(t);
/*  286:     */                 }
/*  287:     */               }
/*  288: 485 */             }, MoreExecutors.sameThreadExecutor());
/*  289:     */           }
/*  290:     */           catch (Throwable e)
/*  291:     */           {
/*  292: 490 */             Futures.FallbackFuture.this.setException(e);
/*  293:     */           }
/*  294:     */         }
/*  295: 490 */       }, executor);
/*  296:     */     }
/*  297:     */     
/*  298:     */     public boolean cancel(boolean mayInterruptIfRunning)
/*  299:     */     {
/*  300: 498 */       if (super.cancel(mayInterruptIfRunning))
/*  301:     */       {
/*  302: 499 */         this.running.cancel(mayInterruptIfRunning);
/*  303: 500 */         return true;
/*  304:     */       }
/*  305: 502 */       return false;
/*  306:     */     }
/*  307:     */   }
/*  308:     */   
/*  309:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function)
/*  310:     */   {
/*  311: 563 */     return transform(input, function, MoreExecutors.sameThreadExecutor());
/*  312:     */   }
/*  313:     */   
/*  314:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function, Executor executor)
/*  315:     */   {
/*  316: 608 */     ChainingListenableFuture<I, O> output = new ChainingListenableFuture(function, input, null);
/*  317:     */     
/*  318: 610 */     input.addListener(output, executor);
/*  319: 611 */     return output;
/*  320:     */   }
/*  321:     */   
/*  322:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, Function<? super I, ? extends O> function)
/*  323:     */   {
/*  324: 669 */     return transform(input, function, MoreExecutors.sameThreadExecutor());
/*  325:     */   }
/*  326:     */   
/*  327:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, Function<? super I, ? extends O> function, Executor executor)
/*  328:     */   {
/*  329: 711 */     Preconditions.checkNotNull(function);
/*  330: 712 */     AsyncFunction<I, O> wrapperFunction = new AsyncFunction()
/*  331:     */     {
/*  332:     */       public ListenableFuture<O> apply(I input)
/*  333:     */       {
/*  334: 715 */         O output = this.val$function.apply(input);
/*  335: 716 */         return Futures.immediateFuture(output);
/*  336:     */       }
/*  337: 718 */     };
/*  338: 719 */     return transform(input, wrapperFunction, executor);
/*  339:     */   }
/*  340:     */   
/*  341:     */   public static <I, O> Future<O> lazyTransform(Future<I> input, final Function<? super I, ? extends O> function)
/*  342:     */   {
/*  343: 747 */     Preconditions.checkNotNull(input);
/*  344: 748 */     Preconditions.checkNotNull(function);
/*  345: 749 */     new Future()
/*  346:     */     {
/*  347:     */       public boolean cancel(boolean mayInterruptIfRunning)
/*  348:     */       {
/*  349: 753 */         return this.val$input.cancel(mayInterruptIfRunning);
/*  350:     */       }
/*  351:     */       
/*  352:     */       public boolean isCancelled()
/*  353:     */       {
/*  354: 758 */         return this.val$input.isCancelled();
/*  355:     */       }
/*  356:     */       
/*  357:     */       public boolean isDone()
/*  358:     */       {
/*  359: 763 */         return this.val$input.isDone();
/*  360:     */       }
/*  361:     */       
/*  362:     */       public O get()
/*  363:     */         throws InterruptedException, ExecutionException
/*  364:     */       {
/*  365: 768 */         return applyTransformation(this.val$input.get());
/*  366:     */       }
/*  367:     */       
/*  368:     */       public O get(long timeout, TimeUnit unit)
/*  369:     */         throws InterruptedException, ExecutionException, TimeoutException
/*  370:     */       {
/*  371: 774 */         return applyTransformation(this.val$input.get(timeout, unit));
/*  372:     */       }
/*  373:     */       
/*  374:     */       private O applyTransformation(I input)
/*  375:     */         throws ExecutionException
/*  376:     */       {
/*  377:     */         try
/*  378:     */         {
/*  379: 779 */           return function.apply(input);
/*  380:     */         }
/*  381:     */         catch (Throwable t)
/*  382:     */         {
/*  383: 781 */           throw new ExecutionException(t);
/*  384:     */         }
/*  385:     */       }
/*  386:     */     };
/*  387:     */   }
/*  388:     */   
/*  389:     */   private static class ChainingListenableFuture<I, O>
/*  390:     */     extends AbstractFuture<O>
/*  391:     */     implements Runnable
/*  392:     */   {
/*  393:     */     private AsyncFunction<? super I, ? extends O> function;
/*  394:     */     private ListenableFuture<? extends I> inputFuture;
/*  395:     */     private volatile ListenableFuture<? extends O> outputFuture;
/*  396: 813 */     private final CountDownLatch outputCreated = new CountDownLatch(1);
/*  397:     */     
/*  398:     */     private ChainingListenableFuture(AsyncFunction<? super I, ? extends O> function, ListenableFuture<? extends I> inputFuture)
/*  399:     */     {
/*  400: 818 */       this.function = ((AsyncFunction)Preconditions.checkNotNull(function));
/*  401: 819 */       this.inputFuture = ((ListenableFuture)Preconditions.checkNotNull(inputFuture));
/*  402:     */     }
/*  403:     */     
/*  404:     */     public boolean cancel(boolean mayInterruptIfRunning)
/*  405:     */     {
/*  406: 828 */       if (super.cancel(mayInterruptIfRunning))
/*  407:     */       {
/*  408: 831 */         cancel(this.inputFuture, mayInterruptIfRunning);
/*  409: 832 */         cancel(this.outputFuture, mayInterruptIfRunning);
/*  410: 833 */         return true;
/*  411:     */       }
/*  412: 835 */       return false;
/*  413:     */     }
/*  414:     */     
/*  415:     */     private void cancel(@Nullable Future<?> future, boolean mayInterruptIfRunning)
/*  416:     */     {
/*  417: 840 */       if (future != null) {
/*  418: 841 */         future.cancel(mayInterruptIfRunning);
/*  419:     */       }
/*  420:     */     }
/*  421:     */     
/*  422:     */     public void run()
/*  423:     */     {
/*  424:     */       try
/*  425:     */       {
/*  426:     */         I sourceResult;
/*  427:     */         try
/*  428:     */         {
/*  429: 850 */           sourceResult = Uninterruptibles.getUninterruptibly(this.inputFuture);
/*  430:     */         }
/*  431:     */         catch (CancellationException e)
/*  432:     */         {
/*  433: 855 */           cancel(false); return;
/*  434:     */         }
/*  435:     */         catch (ExecutionException e)
/*  436:     */         {
/*  437: 859 */           setException(e.getCause()); return;
/*  438:     */         }
/*  439: 863 */         final ListenableFuture<? extends O> outputFuture = this.outputFuture = (ListenableFuture)Preconditions.checkNotNull(this.function.apply(sourceResult), "AsyncFunction may not return null.");
/*  440: 866 */         if (isCancelled())
/*  441:     */         {
/*  442: 867 */           outputFuture.cancel(wasInterrupted());
/*  443: 868 */           this.outputFuture = null;
/*  444:     */         }
/*  445:     */         else
/*  446:     */         {
/*  447: 871 */           outputFuture.addListener(new Runnable()
/*  448:     */           {
/*  449:     */             public void run()
/*  450:     */             {
/*  451:     */               try
/*  452:     */               {
/*  453: 875 */                 Futures.ChainingListenableFuture.this.set(Uninterruptibles.getUninterruptibly(outputFuture));
/*  454:     */               }
/*  455:     */               catch (CancellationException e)
/*  456:     */               {
/*  457: 880 */                 Futures.ChainingListenableFuture.this.cancel(false);
/*  458:     */               }
/*  459:     */               catch (ExecutionException e)
/*  460:     */               {
/*  461: 884 */                 Futures.ChainingListenableFuture.this.setException(e.getCause());
/*  462:     */               }
/*  463:     */               finally
/*  464:     */               {
/*  465: 887 */                 Futures.ChainingListenableFuture.this.outputFuture = null;
/*  466:     */               }
/*  467:     */             }
/*  468: 887 */           }, MoreExecutors.sameThreadExecutor());
/*  469:     */         }
/*  470:     */       }
/*  471:     */       catch (UndeclaredThrowableException e)
/*  472:     */       {
/*  473: 893 */         setException(e.getCause());
/*  474:     */       }
/*  475:     */       catch (Throwable t)
/*  476:     */       {
/*  477: 897 */         setException(t);
/*  478:     */       }
/*  479:     */       finally
/*  480:     */       {
/*  481: 900 */         this.function = null;
/*  482: 901 */         this.inputFuture = null;
/*  483:     */         
/*  484: 903 */         this.outputCreated.countDown();
/*  485:     */       }
/*  486:     */     }
/*  487:     */   }
/*  488:     */   
/*  489:     */   public static <V> ListenableFuture<V> dereference(ListenableFuture<? extends ListenableFuture<? extends V>> nested)
/*  490:     */   {
/*  491: 932 */     return transform(nested, DEREFERENCER);
/*  492:     */   }
/*  493:     */   
/*  494: 938 */   private static final AsyncFunction<ListenableFuture<Object>, Object> DEREFERENCER = new AsyncFunction()
/*  495:     */   {
/*  496:     */     public ListenableFuture<Object> apply(ListenableFuture<Object> input)
/*  497:     */     {
/*  498: 941 */       return input;
/*  499:     */     }
/*  500:     */   };
/*  501:     */   
/*  502:     */   @Beta
/*  503:     */   public static <V> ListenableFuture<List<V>> allAsList(ListenableFuture<? extends V>... futures)
/*  504:     */   {
/*  505: 964 */     return listFuture(ImmutableList.copyOf(futures), true, MoreExecutors.sameThreadExecutor());
/*  506:     */   }
/*  507:     */   
/*  508:     */   @Beta
/*  509:     */   public static <V> ListenableFuture<List<V>> allAsList(Iterable<? extends ListenableFuture<? extends V>> futures)
/*  510:     */   {
/*  511: 987 */     return listFuture(ImmutableList.copyOf(futures), true, MoreExecutors.sameThreadExecutor());
/*  512:     */   }
/*  513:     */   
/*  514:     */   public static <V> ListenableFuture<V> nonCancellationPropagating(ListenableFuture<V> future)
/*  515:     */   {
/*  516:1001 */     return new NonCancellationPropagatingFuture(future);
/*  517:     */   }
/*  518:     */   
/*  519:     */   private static class NonCancellationPropagatingFuture<V>
/*  520:     */     extends AbstractFuture<V>
/*  521:     */   {
/*  522:     */     NonCancellationPropagatingFuture(final ListenableFuture<V> delegate)
/*  523:     */     {
/*  524:1010 */       Preconditions.checkNotNull(delegate);
/*  525:1011 */       Futures.addCallback(delegate, new FutureCallback()
/*  526:     */       {
/*  527:     */         public void onSuccess(V result)
/*  528:     */         {
/*  529:1014 */           Futures.NonCancellationPropagatingFuture.this.set(result);
/*  530:     */         }
/*  531:     */         
/*  532:     */         public void onFailure(Throwable t)
/*  533:     */         {
/*  534:1019 */           if (delegate.isCancelled()) {
/*  535:1020 */             Futures.NonCancellationPropagatingFuture.this.cancel(false);
/*  536:     */           } else {
/*  537:1022 */             Futures.NonCancellationPropagatingFuture.this.setException(t);
/*  538:     */           }
/*  539:     */         }
/*  540:1022 */       }, MoreExecutors.sameThreadExecutor());
/*  541:     */     }
/*  542:     */   }
/*  543:     */   
/*  544:     */   @Beta
/*  545:     */   public static <V> ListenableFuture<List<V>> successfulAsList(ListenableFuture<? extends V>... futures)
/*  546:     */   {
/*  547:1047 */     return listFuture(ImmutableList.copyOf(futures), false, MoreExecutors.sameThreadExecutor());
/*  548:     */   }
/*  549:     */   
/*  550:     */   @Beta
/*  551:     */   public static <V> ListenableFuture<List<V>> successfulAsList(Iterable<? extends ListenableFuture<? extends V>> futures)
/*  552:     */   {
/*  553:1069 */     return listFuture(ImmutableList.copyOf(futures), false, MoreExecutors.sameThreadExecutor());
/*  554:     */   }
/*  555:     */   
/*  556:     */   @Beta
/*  557:     */   public static <T> ImmutableList<ListenableFuture<T>> inCompletionOrder(Iterable<? extends ListenableFuture<? extends T>> futures)
/*  558:     */   {
/*  559:1091 */     ConcurrentLinkedQueue<AsyncSettableFuture<T>> delegates = Queues.newConcurrentLinkedQueue();
/*  560:     */     
/*  561:1093 */     ImmutableList.Builder<ListenableFuture<T>> listBuilder = ImmutableList.builder();
/*  562:     */     
/*  563:     */ 
/*  564:     */ 
/*  565:     */ 
/*  566:     */ 
/*  567:     */ 
/*  568:     */ 
/*  569:     */ 
/*  570:     */ 
/*  571:     */ 
/*  572:1104 */     SerializingExecutor executor = new SerializingExecutor(MoreExecutors.sameThreadExecutor());
/*  573:1105 */     for (final ListenableFuture<? extends T> future : futures)
/*  574:     */     {
/*  575:1106 */       AsyncSettableFuture<T> delegate = AsyncSettableFuture.create();
/*  576:     */       
/*  577:1108 */       delegates.add(delegate);
/*  578:1109 */       future.addListener(new Runnable()
/*  579:     */       {
/*  580:     */         public void run()
/*  581:     */         {
/*  582:1111 */           ((AsyncSettableFuture)this.val$delegates.remove()).setFuture(future);
/*  583:     */         }
/*  584:1111 */       }, executor);
/*  585:     */       
/*  586:     */ 
/*  587:1114 */       listBuilder.add(delegate);
/*  588:     */     }
/*  589:1116 */     return listBuilder.build();
/*  590:     */   }
/*  591:     */   
/*  592:     */   public static <V> void addCallback(ListenableFuture<V> future, FutureCallback<? super V> callback)
/*  593:     */   {
/*  594:1170 */     addCallback(future, callback, MoreExecutors.sameThreadExecutor());
/*  595:     */   }
/*  596:     */   
/*  597:     */   public static <V> void addCallback(ListenableFuture<V> future, final FutureCallback<? super V> callback, Executor executor)
/*  598:     */   {
/*  599:1212 */     Preconditions.checkNotNull(callback);
/*  600:1213 */     Runnable callbackListener = new Runnable()
/*  601:     */     {
/*  602:     */       public void run()
/*  603:     */       {
/*  604:     */         V value;
/*  605:     */         try
/*  606:     */         {
/*  607:1220 */           value = Uninterruptibles.getUninterruptibly(this.val$future);
/*  608:     */         }
/*  609:     */         catch (ExecutionException e)
/*  610:     */         {
/*  611:1222 */           callback.onFailure(e.getCause());
/*  612:1223 */           return;
/*  613:     */         }
/*  614:     */         catch (RuntimeException e)
/*  615:     */         {
/*  616:1225 */           callback.onFailure(e);
/*  617:1226 */           return;
/*  618:     */         }
/*  619:     */         catch (Error e)
/*  620:     */         {
/*  621:1228 */           callback.onFailure(e);
/*  622:1229 */           return;
/*  623:     */         }
/*  624:1231 */         callback.onSuccess(value);
/*  625:     */       }
/*  626:1233 */     };
/*  627:1234 */     future.addListener(callbackListener, executor);
/*  628:     */   }
/*  629:     */   
/*  630:     */   public static <V, X extends Exception> V get(Future<V> future, Class<X> exceptionClass)
/*  631:     */     throws Exception
/*  632:     */   {
/*  633:1286 */     Preconditions.checkNotNull(future);
/*  634:1287 */     Preconditions.checkArgument(!RuntimeException.class.isAssignableFrom(exceptionClass), "Futures.get exception type (%s) must not be a RuntimeException", new Object[] { exceptionClass });
/*  635:     */     try
/*  636:     */     {
/*  637:1291 */       return future.get();
/*  638:     */     }
/*  639:     */     catch (InterruptedException e)
/*  640:     */     {
/*  641:1293 */       Thread.currentThread().interrupt();
/*  642:1294 */       throw newWithCause(exceptionClass, e);
/*  643:     */     }
/*  644:     */     catch (ExecutionException e)
/*  645:     */     {
/*  646:1296 */       wrapAndThrowExceptionOrError(e.getCause(), exceptionClass);
/*  647:1297 */       throw new AssertionError();
/*  648:     */     }
/*  649:     */   }
/*  650:     */   
/*  651:     */   public static <V, X extends Exception> V get(Future<V> future, long timeout, TimeUnit unit, Class<X> exceptionClass)
/*  652:     */     throws Exception
/*  653:     */   {
/*  654:1352 */     Preconditions.checkNotNull(future);
/*  655:1353 */     Preconditions.checkNotNull(unit);
/*  656:1354 */     Preconditions.checkArgument(!RuntimeException.class.isAssignableFrom(exceptionClass), "Futures.get exception type (%s) must not be a RuntimeException", new Object[] { exceptionClass });
/*  657:     */     try
/*  658:     */     {
/*  659:1358 */       return future.get(timeout, unit);
/*  660:     */     }
/*  661:     */     catch (InterruptedException e)
/*  662:     */     {
/*  663:1360 */       Thread.currentThread().interrupt();
/*  664:1361 */       throw newWithCause(exceptionClass, e);
/*  665:     */     }
/*  666:     */     catch (TimeoutException e)
/*  667:     */     {
/*  668:1363 */       throw newWithCause(exceptionClass, e);
/*  669:     */     }
/*  670:     */     catch (ExecutionException e)
/*  671:     */     {
/*  672:1365 */       wrapAndThrowExceptionOrError(e.getCause(), exceptionClass);
/*  673:1366 */       throw new AssertionError();
/*  674:     */     }
/*  675:     */   }
/*  676:     */   
/*  677:     */   private static <X extends Exception> void wrapAndThrowExceptionOrError(Throwable cause, Class<X> exceptionClass)
/*  678:     */     throws Exception
/*  679:     */   {
/*  680:1372 */     if ((cause instanceof Error)) {
/*  681:1373 */       throw new ExecutionError((Error)cause);
/*  682:     */     }
/*  683:1375 */     if ((cause instanceof RuntimeException)) {
/*  684:1376 */       throw new UncheckedExecutionException(cause);
/*  685:     */     }
/*  686:1378 */     throw newWithCause(exceptionClass, cause);
/*  687:     */   }
/*  688:     */   
/*  689:     */   public static <V> V getUnchecked(Future<V> future)
/*  690:     */   {
/*  691:1419 */     Preconditions.checkNotNull(future);
/*  692:     */     try
/*  693:     */     {
/*  694:1421 */       return Uninterruptibles.getUninterruptibly(future);
/*  695:     */     }
/*  696:     */     catch (ExecutionException e)
/*  697:     */     {
/*  698:1423 */       wrapAndThrowUnchecked(e.getCause());
/*  699:1424 */       throw new AssertionError();
/*  700:     */     }
/*  701:     */   }
/*  702:     */   
/*  703:     */   private static void wrapAndThrowUnchecked(Throwable cause)
/*  704:     */   {
/*  705:1429 */     if ((cause instanceof Error)) {
/*  706:1430 */       throw new ExecutionError((Error)cause);
/*  707:     */     }
/*  708:1437 */     throw new UncheckedExecutionException(cause);
/*  709:     */   }
/*  710:     */   
/*  711:     */   private static <X extends Exception> X newWithCause(Class<X> exceptionClass, Throwable cause)
/*  712:     */   {
/*  713:1461 */     List<Constructor<X>> constructors = Arrays.asList(exceptionClass.getConstructors());
/*  714:1463 */     for (Constructor<X> constructor : preferringStrings(constructors))
/*  715:     */     {
/*  716:1464 */       X instance = (Exception)newFromConstructor(constructor, cause);
/*  717:1465 */       if (instance != null)
/*  718:     */       {
/*  719:1466 */         if (instance.getCause() == null) {
/*  720:1467 */           instance.initCause(cause);
/*  721:     */         }
/*  722:1469 */         return instance;
/*  723:     */       }
/*  724:     */     }
/*  725:1472 */     throw new IllegalArgumentException("No appropriate constructor for exception of type " + exceptionClass + " in response to chained exception", cause);
/*  726:     */   }
/*  727:     */   
/*  728:     */   private static <X extends Exception> List<Constructor<X>> preferringStrings(List<Constructor<X>> constructors)
/*  729:     */   {
/*  730:1479 */     return WITH_STRING_PARAM_FIRST.sortedCopy(constructors);
/*  731:     */   }
/*  732:     */   
/*  733:1482 */   private static final Ordering<Constructor<?>> WITH_STRING_PARAM_FIRST = Ordering.natural().onResultOf(new Function()
/*  734:     */   {
/*  735:     */     public Boolean apply(Constructor<?> input)
/*  736:     */     {
/*  737:1485 */       return Boolean.valueOf(Arrays.asList(input.getParameterTypes()).contains(String.class));
/*  738:     */     }
/*  739:1482 */   }).reverse();
/*  740:     */   
/*  741:     */   @Nullable
/*  742:     */   private static <X> X newFromConstructor(Constructor<X> constructor, Throwable cause)
/*  743:     */   {
/*  744:1491 */     Class<?>[] paramTypes = constructor.getParameterTypes();
/*  745:1492 */     Object[] params = new Object[paramTypes.length];
/*  746:1493 */     for (int i = 0; i < paramTypes.length; i++)
/*  747:     */     {
/*  748:1494 */       Class<?> paramType = paramTypes[i];
/*  749:1495 */       if (paramType.equals(String.class)) {
/*  750:1496 */         params[i] = cause.toString();
/*  751:1497 */       } else if (paramType.equals(Throwable.class)) {
/*  752:1498 */         params[i] = cause;
/*  753:     */       } else {
/*  754:1500 */         return null;
/*  755:     */       }
/*  756:     */     }
/*  757:     */     try
/*  758:     */     {
/*  759:1504 */       return constructor.newInstance(params);
/*  760:     */     }
/*  761:     */     catch (IllegalArgumentException e)
/*  762:     */     {
/*  763:1506 */       return null;
/*  764:     */     }
/*  765:     */     catch (InstantiationException e)
/*  766:     */     {
/*  767:1508 */       return null;
/*  768:     */     }
/*  769:     */     catch (IllegalAccessException e)
/*  770:     */     {
/*  771:1510 */       return null;
/*  772:     */     }
/*  773:     */     catch (InvocationTargetException e) {}
/*  774:1512 */     return null;
/*  775:     */   }
/*  776:     */   
/*  777:     */   private static class CombinedFuture<V, C>
/*  778:     */     extends AbstractFuture<C>
/*  779:     */   {
/*  780:1521 */     private static final Logger logger = Logger.getLogger(CombinedFuture.class.getName());
/*  781:     */     ImmutableCollection<? extends ListenableFuture<? extends V>> futures;
/*  782:     */     final boolean allMustSucceed;
/*  783:     */     final AtomicInteger remaining;
/*  784:     */     Futures.FutureCombiner<V, C> combiner;
/*  785:     */     List<Optional<V>> values;
/*  786:1529 */     final Object seenExceptionsLock = new Object();
/*  787:     */     Set<Throwable> seenExceptions;
/*  788:     */     
/*  789:     */     CombinedFuture(ImmutableCollection<? extends ListenableFuture<? extends V>> futures, boolean allMustSucceed, Executor listenerExecutor, Futures.FutureCombiner<V, C> combiner)
/*  790:     */     {
/*  791:1536 */       this.futures = futures;
/*  792:1537 */       this.allMustSucceed = allMustSucceed;
/*  793:1538 */       this.remaining = new AtomicInteger(futures.size());
/*  794:1539 */       this.combiner = combiner;
/*  795:1540 */       this.values = Lists.newArrayListWithCapacity(futures.size());
/*  796:1541 */       init(listenerExecutor);
/*  797:     */     }
/*  798:     */     
/*  799:     */     protected void init(Executor listenerExecutor)
/*  800:     */     {
/*  801:1549 */       addListener(new Runnable()
/*  802:     */       {
/*  803:     */         public void run()
/*  804:     */         {
/*  805:1553 */           if (Futures.CombinedFuture.this.isCancelled()) {
/*  806:1554 */             for (ListenableFuture<?> future : Futures.CombinedFuture.this.futures) {
/*  807:1555 */               future.cancel(Futures.CombinedFuture.this.wasInterrupted());
/*  808:     */             }
/*  809:     */           }
/*  810:1560 */           Futures.CombinedFuture.this.futures = null;
/*  811:     */           
/*  812:     */ 
/*  813:     */ 
/*  814:1564 */           Futures.CombinedFuture.this.values = null;
/*  815:     */           
/*  816:     */ 
/*  817:1567 */           Futures.CombinedFuture.this.combiner = null;
/*  818:     */         }
/*  819:1567 */       }, MoreExecutors.sameThreadExecutor());
/*  820:1574 */       if (this.futures.isEmpty())
/*  821:     */       {
/*  822:1575 */         set(this.combiner.combine(ImmutableList.of()));
/*  823:1576 */         return;
/*  824:     */       }
/*  825:1580 */       for (int i = 0; i < this.futures.size(); i++) {
/*  826:1581 */         this.values.add(null);
/*  827:     */       }
/*  828:1592 */       int i = 0;
/*  829:1593 */       for (final ListenableFuture<? extends V> listenable : this.futures)
/*  830:     */       {
/*  831:1594 */         final int index = i++;
/*  832:1595 */         listenable.addListener(new Runnable()
/*  833:     */         {
/*  834:     */           public void run()
/*  835:     */           {
/*  836:1598 */             Futures.CombinedFuture.this.setOneValue(index, listenable);
/*  837:     */           }
/*  838:1598 */         }, listenerExecutor);
/*  839:     */       }
/*  840:     */     }
/*  841:     */     
/*  842:     */     private void setExceptionAndMaybeLog(Throwable throwable)
/*  843:     */     {
/*  844:1611 */       boolean visibleFromOutputFuture = false;
/*  845:1612 */       boolean firstTimeSeeingThisException = true;
/*  846:1613 */       if (this.allMustSucceed)
/*  847:     */       {
/*  848:1616 */         visibleFromOutputFuture = super.setException(throwable);
/*  849:1618 */         synchronized (this.seenExceptionsLock)
/*  850:     */         {
/*  851:1619 */           if (this.seenExceptions == null) {
/*  852:1620 */             this.seenExceptions = Sets.newHashSet();
/*  853:     */           }
/*  854:1622 */           firstTimeSeeingThisException = this.seenExceptions.add(throwable);
/*  855:     */         }
/*  856:     */       }
/*  857:1626 */       if (((throwable instanceof Error)) || ((this.allMustSucceed) && (!visibleFromOutputFuture) && (firstTimeSeeingThisException))) {
/*  858:1628 */         logger.log(Level.SEVERE, "input future failed.", throwable);
/*  859:     */       }
/*  860:     */     }
/*  861:     */     
/*  862:     */     private void setOneValue(int index, Future<? extends V> future)
/*  863:     */     {
/*  864:1636 */       List<Optional<V>> localValues = this.values;
/*  865:1644 */       if ((isDone()) || (localValues == null)) {
/*  866:1649 */         Preconditions.checkState((this.allMustSucceed) || (isCancelled()), "Future was done before all dependencies completed");
/*  867:     */       }
/*  868:     */       try
/*  869:     */       {
/*  870:1654 */         Preconditions.checkState(future.isDone(), "Tried to set value from future which is not done");
/*  871:     */         
/*  872:1656 */         V returnValue = Uninterruptibles.getUninterruptibly(future);
/*  873:1657 */         if (localValues != null) {
/*  874:1658 */           localValues.set(index, Optional.fromNullable(returnValue));
/*  875:     */         }
/*  876:     */       }
/*  877:     */       catch (CancellationException e)
/*  878:     */       {
/*  879:     */         int newRemaining;
/*  880:     */         Futures.FutureCombiner<V, C> localCombiner;
/*  881:1661 */         if (this.allMustSucceed) {
/*  882:1664 */           cancel(false);
/*  883:     */         }
/*  884:     */       }
/*  885:     */       catch (ExecutionException e)
/*  886:     */       {
/*  887:     */         int newRemaining;
/*  888:     */         Futures.FutureCombiner<V, C> localCombiner;
/*  889:1667 */         setExceptionAndMaybeLog(e.getCause());
/*  890:     */       }
/*  891:     */       catch (Throwable t)
/*  892:     */       {
/*  893:     */         int newRemaining;
/*  894:     */         Futures.FutureCombiner<V, C> localCombiner;
/*  895:1669 */         setExceptionAndMaybeLog(t);
/*  896:     */       }
/*  897:     */       finally
/*  898:     */       {
/*  899:     */         int newRemaining;
/*  900:     */         Futures.FutureCombiner<V, C> localCombiner;
/*  901:1671 */         int newRemaining = this.remaining.decrementAndGet();
/*  902:1672 */         Preconditions.checkState(newRemaining >= 0, "Less than 0 remaining futures");
/*  903:1673 */         if (newRemaining == 0)
/*  904:     */         {
/*  905:1674 */           Futures.FutureCombiner<V, C> localCombiner = this.combiner;
/*  906:1675 */           if ((localCombiner != null) && (localValues != null)) {
/*  907:1676 */             set(localCombiner.combine(localValues));
/*  908:     */           } else {
/*  909:1678 */             Preconditions.checkState(isDone());
/*  910:     */           }
/*  911:     */         }
/*  912:     */       }
/*  913:     */     }
/*  914:     */   }
/*  915:     */   
/*  916:     */   private static <V> ListenableFuture<List<V>> listFuture(ImmutableList<ListenableFuture<? extends V>> futures, boolean allMustSucceed, Executor listenerExecutor)
/*  917:     */   {
/*  918:1690 */     new CombinedFuture(futures, allMustSucceed, listenerExecutor, new FutureCombiner()
/*  919:     */     {
/*  920:     */       public List<V> combine(List<Optional<V>> values)
/*  921:     */       {
/*  922:1695 */         List<V> result = Lists.newArrayList();
/*  923:1696 */         for (Optional<V> element : values) {
/*  924:1697 */           result.add(element != null ? element.orNull() : null);
/*  925:     */         }
/*  926:1699 */         return Collections.unmodifiableList(result);
/*  927:     */       }
/*  928:     */     });
/*  929:     */   }
/*  930:     */   
/*  931:     */   private static class MappingCheckedFuture<V, X extends Exception>
/*  932:     */     extends AbstractCheckedFuture<V, X>
/*  933:     */   {
/*  934:     */     final Function<Exception, X> mapper;
/*  935:     */     
/*  936:     */     MappingCheckedFuture(ListenableFuture<V> delegate, Function<Exception, X> mapper)
/*  937:     */     {
/*  938:1715 */       super();
/*  939:     */       
/*  940:1717 */       this.mapper = ((Function)Preconditions.checkNotNull(mapper));
/*  941:     */     }
/*  942:     */     
/*  943:     */     protected X mapException(Exception e)
/*  944:     */     {
/*  945:1722 */       return (Exception)this.mapper.apply(e);
/*  946:     */     }
/*  947:     */   }
/*  948:     */   
/*  949:     */   private static abstract interface FutureCombiner<V, C>
/*  950:     */   {
/*  951:     */     public abstract C combine(List<Optional<V>> paramList);
/*  952:     */   }
/*  953:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Futures
 * JD-Core Version:    0.7.0.1
 */
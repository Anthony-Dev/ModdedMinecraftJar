/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.concurrent.Executors;
/*   5:    */ import java.util.concurrent.ThreadFactory;
/*   6:    */ import java.util.concurrent.atomic.AtomicLong;
/*   7:    */ 
/*   8:    */ public final class ThreadFactoryBuilder
/*   9:    */ {
/*  10: 46 */   private String nameFormat = null;
/*  11: 47 */   private Boolean daemon = null;
/*  12: 48 */   private Integer priority = null;
/*  13: 49 */   private Thread.UncaughtExceptionHandler uncaughtExceptionHandler = null;
/*  14: 50 */   private ThreadFactory backingThreadFactory = null;
/*  15:    */   
/*  16:    */   public ThreadFactoryBuilder setNameFormat(String nameFormat)
/*  17:    */   {
/*  18: 71 */     String.format(nameFormat, new Object[] { Integer.valueOf(0) });
/*  19: 72 */     this.nameFormat = nameFormat;
/*  20: 73 */     return this;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public ThreadFactoryBuilder setDaemon(boolean daemon)
/*  24:    */   {
/*  25: 84 */     this.daemon = Boolean.valueOf(daemon);
/*  26: 85 */     return this;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public ThreadFactoryBuilder setPriority(int priority)
/*  30:    */   {
/*  31: 98 */     Preconditions.checkArgument(priority >= 1, "Thread priority (%s) must be >= %s", new Object[] { Integer.valueOf(priority), Integer.valueOf(1) });
/*  32:    */     
/*  33:100 */     Preconditions.checkArgument(priority <= 10, "Thread priority (%s) must be <= %s", new Object[] { Integer.valueOf(priority), Integer.valueOf(10) });
/*  34:    */     
/*  35:102 */     this.priority = Integer.valueOf(priority);
/*  36:103 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public ThreadFactoryBuilder setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler)
/*  40:    */   {
/*  41:116 */     this.uncaughtExceptionHandler = ((Thread.UncaughtExceptionHandler)Preconditions.checkNotNull(uncaughtExceptionHandler));
/*  42:117 */     return this;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public ThreadFactoryBuilder setThreadFactory(ThreadFactory backingThreadFactory)
/*  46:    */   {
/*  47:133 */     this.backingThreadFactory = ((ThreadFactory)Preconditions.checkNotNull(backingThreadFactory));
/*  48:134 */     return this;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public ThreadFactory build()
/*  52:    */   {
/*  53:146 */     return build(this);
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static ThreadFactory build(ThreadFactoryBuilder builder)
/*  57:    */   {
/*  58:150 */     final String nameFormat = builder.nameFormat;
/*  59:151 */     final Boolean daemon = builder.daemon;
/*  60:152 */     final Integer priority = builder.priority;
/*  61:153 */     final Thread.UncaughtExceptionHandler uncaughtExceptionHandler = builder.uncaughtExceptionHandler;
/*  62:    */     
/*  63:155 */     ThreadFactory backingThreadFactory = builder.backingThreadFactory != null ? builder.backingThreadFactory : Executors.defaultThreadFactory();
/*  64:    */     
/*  65:    */ 
/*  66:    */ 
/*  67:159 */     final AtomicLong count = nameFormat != null ? new AtomicLong(0L) : null;
/*  68:160 */     new ThreadFactory()
/*  69:    */     {
/*  70:    */       public Thread newThread(Runnable runnable)
/*  71:    */       {
/*  72:162 */         Thread thread = this.val$backingThreadFactory.newThread(runnable);
/*  73:163 */         if (nameFormat != null) {
/*  74:164 */           thread.setName(String.format(nameFormat, new Object[] { Long.valueOf(count.getAndIncrement()) }));
/*  75:    */         }
/*  76:166 */         if (daemon != null) {
/*  77:167 */           thread.setDaemon(daemon.booleanValue());
/*  78:    */         }
/*  79:169 */         if (priority != null) {
/*  80:170 */           thread.setPriority(priority.intValue());
/*  81:    */         }
/*  82:172 */         if (uncaughtExceptionHandler != null) {
/*  83:173 */           thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
/*  84:    */         }
/*  85:175 */         return thread;
/*  86:    */       }
/*  87:    */     };
/*  88:    */   }
/*  89:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.ThreadFactoryBuilder
 * JD-Core Version:    0.7.0.1
 */
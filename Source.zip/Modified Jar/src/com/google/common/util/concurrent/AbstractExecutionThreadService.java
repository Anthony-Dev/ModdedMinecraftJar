/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import com.google.common.base.Throwables;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import java.util.concurrent.TimeoutException;
/*   9:    */ import java.util.logging.Level;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ public abstract class AbstractExecutionThreadService
/*  14:    */   implements Service
/*  15:    */ {
/*  16: 40 */   private static final Logger logger = Logger.getLogger(AbstractExecutionThreadService.class.getName());
/*  17: 44 */   private final Service delegate = new AbstractService()
/*  18:    */   {
/*  19:    */     protected final void doStart()
/*  20:    */     {
/*  21: 46 */       Executor executor = MoreExecutors.renamingDecorator(AbstractExecutionThreadService.this.executor(), new Supplier()
/*  22:    */       {
/*  23:    */         public String get()
/*  24:    */         {
/*  25: 48 */           return AbstractExecutionThreadService.this.serviceName();
/*  26:    */         }
/*  27: 50 */       });
/*  28: 51 */       executor.execute(new Runnable()
/*  29:    */       {
/*  30:    */         public void run()
/*  31:    */         {
/*  32:    */           try
/*  33:    */           {
/*  34: 55 */             AbstractExecutionThreadService.this.startUp();
/*  35: 56 */             AbstractExecutionThreadService.1.this.notifyStarted();
/*  36: 58 */             if (AbstractExecutionThreadService.1.this.isRunning()) {
/*  37:    */               try
/*  38:    */               {
/*  39: 60 */                 AbstractExecutionThreadService.this.run();
/*  40:    */               }
/*  41:    */               catch (Throwable t)
/*  42:    */               {
/*  43:    */                 try
/*  44:    */                 {
/*  45: 63 */                   AbstractExecutionThreadService.this.shutDown();
/*  46:    */                 }
/*  47:    */                 catch (Exception ignored)
/*  48:    */                 {
/*  49: 65 */                   AbstractExecutionThreadService.logger.log(Level.WARNING, "Error while attempting to shut down the service after failure.", ignored);
/*  50:    */                 }
/*  51: 69 */                 throw t;
/*  52:    */               }
/*  53:    */             }
/*  54: 73 */             AbstractExecutionThreadService.this.shutDown();
/*  55: 74 */             AbstractExecutionThreadService.1.this.notifyStopped();
/*  56:    */           }
/*  57:    */           catch (Throwable t)
/*  58:    */           {
/*  59: 76 */             AbstractExecutionThreadService.1.this.notifyFailed(t);
/*  60: 77 */             throw Throwables.propagate(t);
/*  61:    */           }
/*  62:    */         }
/*  63:    */       });
/*  64:    */     }
/*  65:    */     
/*  66:    */     protected void doStop()
/*  67:    */     {
/*  68: 84 */       AbstractExecutionThreadService.this.triggerShutdown();
/*  69:    */     }
/*  70:    */   };
/*  71:    */   
/*  72:    */   protected void startUp()
/*  73:    */     throws Exception
/*  74:    */   {}
/*  75:    */   
/*  76:    */   protected abstract void run()
/*  77:    */     throws Exception;
/*  78:    */   
/*  79:    */   protected void shutDown()
/*  80:    */     throws Exception
/*  81:    */   {}
/*  82:    */   
/*  83:    */   protected void triggerShutdown() {}
/*  84:    */   
/*  85:    */   protected Executor executor()
/*  86:    */   {
/*  87:143 */     new Executor()
/*  88:    */     {
/*  89:    */       public void execute(Runnable command)
/*  90:    */       {
/*  91:146 */         MoreExecutors.newThread(AbstractExecutionThreadService.this.serviceName(), command).start();
/*  92:    */       }
/*  93:    */     };
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String toString()
/*  97:    */   {
/*  98:152 */     return serviceName() + " [" + state() + "]";
/*  99:    */   }
/* 100:    */   
/* 101:    */   public final boolean isRunning()
/* 102:    */   {
/* 103:156 */     return this.delegate.isRunning();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public final Service.State state()
/* 107:    */   {
/* 108:160 */     return this.delegate.state();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 112:    */   {
/* 113:167 */     this.delegate.addListener(listener, executor);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public final Throwable failureCause()
/* 117:    */   {
/* 118:174 */     return this.delegate.failureCause();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public final Service startAsync()
/* 122:    */   {
/* 123:181 */     this.delegate.startAsync();
/* 124:182 */     return this;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public final Service stopAsync()
/* 128:    */   {
/* 129:189 */     this.delegate.stopAsync();
/* 130:190 */     return this;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public final void awaitRunning()
/* 134:    */   {
/* 135:197 */     this.delegate.awaitRunning();
/* 136:    */   }
/* 137:    */   
/* 138:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 139:    */     throws TimeoutException
/* 140:    */   {
/* 141:204 */     this.delegate.awaitRunning(timeout, unit);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public final void awaitTerminated()
/* 145:    */   {
/* 146:211 */     this.delegate.awaitTerminated();
/* 147:    */   }
/* 148:    */   
/* 149:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 150:    */     throws TimeoutException
/* 151:    */   {
/* 152:218 */     this.delegate.awaitTerminated(timeout, unit);
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected String serviceName()
/* 156:    */   {
/* 157:230 */     return getClass().getSimpleName();
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractExecutionThreadService
 * JD-Core Version:    0.7.0.1
 */
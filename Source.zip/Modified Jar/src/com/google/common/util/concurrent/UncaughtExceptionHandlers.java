/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.VisibleForTesting;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import java.util.logging.Level;
/*  6:   */ import java.util.logging.Logger;
/*  7:   */ 
/*  8:   */ public final class UncaughtExceptionHandlers
/*  9:   */ {
/* 10:   */   public static Thread.UncaughtExceptionHandler systemExit()
/* 11:   */   {
/* 12:50 */     return new Exiter(Runtime.getRuntime());
/* 13:   */   }
/* 14:   */   
/* 15:   */   @VisibleForTesting
/* 16:   */   static final class Exiter
/* 17:   */     implements Thread.UncaughtExceptionHandler
/* 18:   */   {
/* 19:54 */     private static final Logger logger = Logger.getLogger(Exiter.class.getName());
/* 20:   */     private final Runtime runtime;
/* 21:   */     
/* 22:   */     Exiter(Runtime runtime)
/* 23:   */     {
/* 24:59 */       this.runtime = runtime;
/* 25:   */     }
/* 26:   */     
/* 27:   */     public void uncaughtException(Thread t, Throwable e)
/* 28:   */     {
/* 29:   */       try
/* 30:   */       {
/* 31:65 */         logger.log(Level.SEVERE, String.format("Caught an exception in %s.  Shutting down.", new Object[] { t }), e);
/* 32:   */       }
/* 33:   */       catch (Throwable errorInLogging)
/* 34:   */       {
/* 35:69 */         System.err.println(e.getMessage());
/* 36:70 */         System.err.println(errorInLogging.getMessage());
/* 37:   */       }
/* 38:   */       finally
/* 39:   */       {
/* 40:72 */         this.runtime.exit(1);
/* 41:   */       }
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.UncaughtExceptionHandlers
 * JD-Core Version:    0.7.0.1
 */
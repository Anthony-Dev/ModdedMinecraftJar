/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Objects.ToStringHelper;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicates;
/*   9:    */ import com.google.common.base.Stopwatch;
/*  10:    */ import com.google.common.base.Supplier;
/*  11:    */ import com.google.common.collect.Collections2;
/*  12:    */ import com.google.common.collect.ImmutableCollection;
/*  13:    */ import com.google.common.collect.ImmutableList;
/*  14:    */ import com.google.common.collect.ImmutableMap;
/*  15:    */ import com.google.common.collect.ImmutableMap.Builder;
/*  16:    */ import com.google.common.collect.ImmutableMultimap;
/*  17:    */ import com.google.common.collect.ImmutableSet;
/*  18:    */ import com.google.common.collect.ImmutableSetMultimap;
/*  19:    */ import com.google.common.collect.ImmutableSetMultimap.Builder;
/*  20:    */ import com.google.common.collect.Lists;
/*  21:    */ import com.google.common.collect.Maps;
/*  22:    */ import com.google.common.collect.Multimaps;
/*  23:    */ import com.google.common.collect.Multiset;
/*  24:    */ import com.google.common.collect.Ordering;
/*  25:    */ import com.google.common.collect.SetMultimap;
/*  26:    */ import com.google.common.collect.Sets;
/*  27:    */ import java.lang.ref.WeakReference;
/*  28:    */ import java.util.ArrayList;
/*  29:    */ import java.util.Collections;
/*  30:    */ import java.util.EnumMap;
/*  31:    */ import java.util.List;
/*  32:    */ import java.util.Map;
/*  33:    */ import java.util.Map.Entry;
/*  34:    */ import java.util.Set;
/*  35:    */ import java.util.concurrent.Executor;
/*  36:    */ import java.util.concurrent.TimeUnit;
/*  37:    */ import java.util.concurrent.TimeoutException;
/*  38:    */ import java.util.logging.Level;
/*  39:    */ import java.util.logging.Logger;
/*  40:    */ import javax.annotation.concurrent.GuardedBy;
/*  41:    */ 
/*  42:    */ @Beta
/*  43:    */ public final class ServiceManager
/*  44:    */ {
/*  45:126 */   private static final Logger logger = Logger.getLogger(ServiceManager.class.getName());
/*  46:127 */   private static final ListenerCallQueue.Callback<Listener> HEALTHY_CALLBACK = new ListenerCallQueue.Callback("healthy()")
/*  47:    */   {
/*  48:    */     void call(ServiceManager.Listener listener)
/*  49:    */     {
/*  50:129 */       listener.healthy();
/*  51:    */     }
/*  52:    */   };
/*  53:132 */   private static final ListenerCallQueue.Callback<Listener> STOPPED_CALLBACK = new ListenerCallQueue.Callback("stopped()")
/*  54:    */   {
/*  55:    */     void call(ServiceManager.Listener listener)
/*  56:    */     {
/*  57:134 */       listener.stopped();
/*  58:    */     }
/*  59:    */   };
/*  60:    */   private final ServiceManagerState state;
/*  61:    */   private final ImmutableList<Service> services;
/*  62:    */   
/*  63:    */   public ServiceManager(Iterable<? extends Service> services)
/*  64:    */   {
/*  65:192 */     ImmutableList<Service> copy = ImmutableList.copyOf(services);
/*  66:193 */     if (copy.isEmpty())
/*  67:    */     {
/*  68:196 */       logger.log(Level.WARNING, "ServiceManager configured with no services.  Is your application configured properly?", new EmptyServiceManagerWarning(null));
/*  69:    */       
/*  70:    */ 
/*  71:199 */       copy = ImmutableList.of(new NoOpService(null));
/*  72:    */     }
/*  73:201 */     this.state = new ServiceManagerState(copy);
/*  74:202 */     this.services = copy;
/*  75:203 */     WeakReference<ServiceManagerState> stateReference = new WeakReference(this.state);
/*  76:    */     
/*  77:205 */     Executor sameThreadExecutor = MoreExecutors.sameThreadExecutor();
/*  78:206 */     for (Service service : copy)
/*  79:    */     {
/*  80:215 */       service.addListener(new ServiceListener(service, stateReference), sameThreadExecutor);
/*  81:    */       
/*  82:    */ 
/*  83:218 */       Preconditions.checkArgument(service.state() == Service.State.NEW, "Can only manage NEW services, %s", new Object[] { service });
/*  84:    */     }
/*  85:222 */     this.state.markReady();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void addListener(Listener listener, Executor executor)
/*  89:    */   {
/*  90:249 */     this.state.addListener(listener, executor);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void addListener(Listener listener)
/*  94:    */   {
/*  95:269 */     this.state.addListener(listener, MoreExecutors.sameThreadExecutor());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public ServiceManager startAsync()
/*  99:    */   {
/* 100:281 */     for (Service service : this.services)
/* 101:    */     {
/* 102:282 */       Service.State state = service.state();
/* 103:283 */       Preconditions.checkState(state == Service.State.NEW, "Service %s is %s, cannot start it.", new Object[] { service, state });
/* 104:    */     }
/* 105:285 */     for (Service service : this.services) {
/* 106:    */       try
/* 107:    */       {
/* 108:287 */         service.startAsync();
/* 109:    */       }
/* 110:    */       catch (IllegalStateException e)
/* 111:    */       {
/* 112:293 */         logger.log(Level.WARNING, "Unable to start Service " + service, e);
/* 113:    */       }
/* 114:    */     }
/* 115:296 */     return this;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void awaitHealthy()
/* 119:    */   {
/* 120:308 */     this.state.awaitHealthy();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void awaitHealthy(long timeout, TimeUnit unit)
/* 124:    */     throws TimeoutException
/* 125:    */   {
/* 126:323 */     this.state.awaitHealthy(timeout, unit);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public ServiceManager stopAsync()
/* 130:    */   {
/* 131:333 */     for (Service service : this.services) {
/* 132:334 */       service.stopAsync();
/* 133:    */     }
/* 134:336 */     return this;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void awaitStopped()
/* 138:    */   {
/* 139:345 */     this.state.awaitStopped();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void awaitStopped(long timeout, TimeUnit unit)
/* 143:    */     throws TimeoutException
/* 144:    */   {
/* 145:358 */     this.state.awaitStopped(timeout, unit);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isHealthy()
/* 149:    */   {
/* 150:368 */     for (Service service : this.services) {
/* 151:369 */       if (!service.isRunning()) {
/* 152:370 */         return false;
/* 153:    */       }
/* 154:    */     }
/* 155:373 */     return true;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public ImmutableMultimap<Service.State, Service> servicesByState()
/* 159:    */   {
/* 160:383 */     return this.state.servicesByState();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public ImmutableMap<Service, Long> startupTimes()
/* 164:    */   {
/* 165:394 */     return this.state.startupTimes();
/* 166:    */   }
/* 167:    */   
/* 168:    */   public String toString()
/* 169:    */   {
/* 170:398 */     return Objects.toStringHelper(ServiceManager.class).add("services", Collections2.filter(this.services, Predicates.not(Predicates.instanceOf(NoOpService.class)))).toString();
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static final class ServiceManagerState
/* 174:    */   {
/* 175:408 */     final Monitor monitor = new Monitor();
/* 176:    */     @GuardedBy("monitor")
/* 177:410 */     final SetMultimap<Service.State, Service> servicesByState = Multimaps.newSetMultimap(new EnumMap(Service.State.class), new Supplier()
/* 178:    */     {
/* 179:    */       public Set<Service> get()
/* 180:    */       {
/* 181:415 */         return Sets.newLinkedHashSet();
/* 182:    */       }
/* 183:410 */     });
/* 184:    */     @GuardedBy("monitor")
/* 185:419 */     final Multiset<Service.State> states = this.servicesByState.keys();
/* 186:    */     @GuardedBy("monitor")
/* 187:422 */     final Map<Service, Stopwatch> startupTimers = Maps.newIdentityHashMap();
/* 188:    */     @GuardedBy("monitor")
/* 189:    */     boolean ready;
/* 190:    */     @GuardedBy("monitor")
/* 191:    */     boolean transitioned;
/* 192:    */     final int numberOfServices;
/* 193:448 */     final Monitor.Guard awaitHealthGuard = new Monitor.Guard(this.monitor)
/* 194:    */     {
/* 195:    */       public boolean isSatisfied()
/* 196:    */       {
/* 197:451 */         return (ServiceManager.ServiceManagerState.this.states.count(Service.State.RUNNING) == ServiceManager.ServiceManagerState.this.numberOfServices) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.STOPPING)) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.TERMINATED)) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.FAILED));
/* 198:    */       }
/* 199:    */     };
/* 200:461 */     final Monitor.Guard stoppedGuard = new Monitor.Guard(this.monitor)
/* 201:    */     {
/* 202:    */       public boolean isSatisfied()
/* 203:    */       {
/* 204:463 */         return ServiceManager.ServiceManagerState.this.states.count(Service.State.TERMINATED) + ServiceManager.ServiceManagerState.this.states.count(Service.State.FAILED) == ServiceManager.ServiceManagerState.this.numberOfServices;
/* 205:    */       }
/* 206:    */     };
/* 207:    */     @GuardedBy("monitor")
/* 208:468 */     final List<ListenerCallQueue<ServiceManager.Listener>> listeners = Collections.synchronizedList(new ArrayList());
/* 209:    */     
/* 210:    */     ServiceManagerState(ImmutableCollection<Service> services)
/* 211:    */     {
/* 212:479 */       this.numberOfServices = services.size();
/* 213:480 */       this.servicesByState.putAll(Service.State.NEW, services);
/* 214:481 */       for (Service service : services) {
/* 215:482 */         this.startupTimers.put(service, Stopwatch.createUnstarted());
/* 216:    */       }
/* 217:    */     }
/* 218:    */     
/* 219:    */     void markReady()
/* 220:    */     {
/* 221:491 */       this.monitor.enter();
/* 222:    */       try
/* 223:    */       {
/* 224:493 */         if (!this.transitioned)
/* 225:    */         {
/* 226:495 */           this.ready = true;
/* 227:    */         }
/* 228:    */         else
/* 229:    */         {
/* 230:498 */           List<Service> servicesInBadStates = Lists.newArrayList();
/* 231:499 */           for (Service service : servicesByState().values()) {
/* 232:500 */             if (service.state() != Service.State.NEW) {
/* 233:501 */               servicesInBadStates.add(service);
/* 234:    */             }
/* 235:    */           }
/* 236:504 */           throw new IllegalArgumentException("Services started transitioning asynchronously before the ServiceManager was constructed: " + servicesInBadStates);
/* 237:    */         }
/* 238:    */       }
/* 239:    */       finally
/* 240:    */       {
/* 241:508 */         this.monitor.leave();
/* 242:    */       }
/* 243:    */     }
/* 244:    */     
/* 245:    */     void addListener(ServiceManager.Listener listener, Executor executor)
/* 246:    */     {
/* 247:513 */       Preconditions.checkNotNull(listener, "listener");
/* 248:514 */       Preconditions.checkNotNull(executor, "executor");
/* 249:515 */       this.monitor.enter();
/* 250:    */       try
/* 251:    */       {
/* 252:518 */         if (!this.stoppedGuard.isSatisfied()) {
/* 253:519 */           this.listeners.add(new ListenerCallQueue(listener, executor));
/* 254:    */         }
/* 255:    */       }
/* 256:    */       finally
/* 257:    */       {
/* 258:522 */         this.monitor.leave();
/* 259:    */       }
/* 260:    */     }
/* 261:    */     
/* 262:    */     void awaitHealthy()
/* 263:    */     {
/* 264:527 */       this.monitor.enterWhenUninterruptibly(this.awaitHealthGuard);
/* 265:    */       try
/* 266:    */       {
/* 267:529 */         checkHealthy();
/* 268:    */       }
/* 269:    */       finally
/* 270:    */       {
/* 271:531 */         this.monitor.leave();
/* 272:    */       }
/* 273:    */     }
/* 274:    */     
/* 275:    */     void awaitHealthy(long timeout, TimeUnit unit)
/* 276:    */       throws TimeoutException
/* 277:    */     {
/* 278:536 */       this.monitor.enter();
/* 279:    */       try
/* 280:    */       {
/* 281:538 */         if (!this.monitor.waitForUninterruptibly(this.awaitHealthGuard, timeout, unit)) {
/* 282:539 */           throw new TimeoutException("Timeout waiting for the services to become healthy. The following services have not started: " + Multimaps.filterKeys(this.servicesByState, Predicates.in(ImmutableSet.of(Service.State.NEW, Service.State.STARTING))));
/* 283:    */         }
/* 284:543 */         checkHealthy();
/* 285:    */       }
/* 286:    */       finally
/* 287:    */       {
/* 288:545 */         this.monitor.leave();
/* 289:    */       }
/* 290:    */     }
/* 291:    */     
/* 292:    */     void awaitStopped()
/* 293:    */     {
/* 294:550 */       this.monitor.enterWhenUninterruptibly(this.stoppedGuard);
/* 295:551 */       this.monitor.leave();
/* 296:    */     }
/* 297:    */     
/* 298:    */     void awaitStopped(long timeout, TimeUnit unit)
/* 299:    */       throws TimeoutException
/* 300:    */     {
/* 301:555 */       this.monitor.enter();
/* 302:    */       try
/* 303:    */       {
/* 304:557 */         if (!this.monitor.waitForUninterruptibly(this.stoppedGuard, timeout, unit)) {
/* 305:558 */           throw new TimeoutException("Timeout waiting for the services to stop. The following services have not stopped: " + Multimaps.filterKeys(this.servicesByState, Predicates.not(Predicates.in(ImmutableSet.of(Service.State.TERMINATED, Service.State.FAILED)))));
/* 306:    */         }
/* 307:    */       }
/* 308:    */       finally
/* 309:    */       {
/* 310:564 */         this.monitor.leave();
/* 311:    */       }
/* 312:    */     }
/* 313:    */     
/* 314:    */     ImmutableMultimap<Service.State, Service> servicesByState()
/* 315:    */     {
/* 316:569 */       ImmutableSetMultimap.Builder<Service.State, Service> builder = ImmutableSetMultimap.builder();
/* 317:570 */       this.monitor.enter();
/* 318:    */       try
/* 319:    */       {
/* 320:572 */         for (Map.Entry<Service.State, Service> entry : this.servicesByState.entries()) {
/* 321:573 */           if (!(entry.getValue() instanceof ServiceManager.NoOpService)) {
/* 322:574 */             builder.put(entry.getKey(), entry.getValue());
/* 323:    */           }
/* 324:    */         }
/* 325:    */       }
/* 326:    */       finally
/* 327:    */       {
/* 328:578 */         this.monitor.leave();
/* 329:    */       }
/* 330:580 */       return builder.build();
/* 331:    */     }
/* 332:    */     
/* 333:    */     ImmutableMap<Service, Long> startupTimes()
/* 334:    */     {
/* 335:585 */       this.monitor.enter();
/* 336:    */       List<Map.Entry<Service, Long>> loadTimes;
/* 337:    */       try
/* 338:    */       {
/* 339:587 */         loadTimes = Lists.newArrayListWithCapacity(this.states.size() - this.states.count(Service.State.NEW) + this.states.count(Service.State.STARTING));
/* 340:589 */         for (Map.Entry<Service, Stopwatch> entry : this.startupTimers.entrySet())
/* 341:    */         {
/* 342:590 */           Service service = (Service)entry.getKey();
/* 343:591 */           Stopwatch stopWatch = (Stopwatch)entry.getValue();
/* 344:596 */           if ((!stopWatch.isRunning()) && (!this.servicesByState.containsEntry(Service.State.NEW, service)) && (!(service instanceof ServiceManager.NoOpService))) {
/* 345:598 */             loadTimes.add(Maps.immutableEntry(service, Long.valueOf(stopWatch.elapsed(TimeUnit.MILLISECONDS))));
/* 346:    */           }
/* 347:    */         }
/* 348:    */       }
/* 349:    */       finally
/* 350:    */       {
/* 351:602 */         this.monitor.leave();
/* 352:    */       }
/* 353:604 */       Collections.sort(loadTimes, Ordering.natural().onResultOf(new Function()
/* 354:    */       {
/* 355:    */         public Long apply(Map.Entry<Service, Long> input)
/* 356:    */         {
/* 357:607 */           return (Long)input.getValue();
/* 358:    */         }
/* 359:609 */       }));
/* 360:610 */       ImmutableMap.Builder<Service, Long> builder = ImmutableMap.builder();
/* 361:611 */       for (Map.Entry<Service, Long> entry : loadTimes) {
/* 362:612 */         builder.put(entry);
/* 363:    */       }
/* 364:614 */       return builder.build();
/* 365:    */     }
/* 366:    */     
/* 367:    */     void transitionService(Service service, Service.State from, Service.State to)
/* 368:    */     {
/* 369:629 */       Preconditions.checkNotNull(service);
/* 370:630 */       Preconditions.checkArgument(from != to);
/* 371:631 */       this.monitor.enter();
/* 372:    */       try
/* 373:    */       {
/* 374:633 */         this.transitioned = true;
/* 375:634 */         if (!this.ready) {
/* 376:    */           return;
/* 377:    */         }
/* 378:638 */         Preconditions.checkState(this.servicesByState.remove(from, service), "Service %s not at the expected location in the state map %s", new Object[] { service, from });
/* 379:    */         
/* 380:640 */         Preconditions.checkState(this.servicesByState.put(to, service), "Service %s in the state map unexpectedly at %s", new Object[] { service, to });
/* 381:    */         
/* 382:    */ 
/* 383:643 */         Stopwatch stopwatch = (Stopwatch)this.startupTimers.get(service);
/* 384:644 */         if (from == Service.State.NEW) {
/* 385:645 */           stopwatch.start();
/* 386:    */         }
/* 387:647 */         if ((to.compareTo(Service.State.RUNNING) >= 0) && (stopwatch.isRunning()))
/* 388:    */         {
/* 389:649 */           stopwatch.stop();
/* 390:650 */           if (!(service instanceof ServiceManager.NoOpService)) {
/* 391:651 */             ServiceManager.logger.log(Level.FINE, "Started {0} in {1}.", new Object[] { service, stopwatch });
/* 392:    */           }
/* 393:    */         }
/* 394:657 */         if (to == Service.State.FAILED) {
/* 395:658 */           fireFailedListeners(service);
/* 396:    */         }
/* 397:661 */         if (this.states.count(Service.State.RUNNING) == this.numberOfServices) {
/* 398:664 */           fireHealthyListeners();
/* 399:665 */         } else if (this.states.count(Service.State.TERMINATED) + this.states.count(Service.State.FAILED) == this.numberOfServices) {
/* 400:666 */           fireStoppedListeners();
/* 401:    */         }
/* 402:    */       }
/* 403:    */       finally
/* 404:    */       {
/* 405:669 */         this.monitor.leave();
/* 406:    */         
/* 407:671 */         executeListeners();
/* 408:    */       }
/* 409:    */     }
/* 410:    */     
/* 411:    */     @GuardedBy("monitor")
/* 412:    */     void fireStoppedListeners()
/* 413:    */     {
/* 414:677 */       ServiceManager.STOPPED_CALLBACK.enqueueOn(this.listeners);
/* 415:    */     }
/* 416:    */     
/* 417:    */     @GuardedBy("monitor")
/* 418:    */     void fireHealthyListeners()
/* 419:    */     {
/* 420:682 */       ServiceManager.HEALTHY_CALLBACK.enqueueOn(this.listeners);
/* 421:    */     }
/* 422:    */     
/* 423:    */     @GuardedBy("monitor")
/* 424:    */     void fireFailedListeners(final Service service)
/* 425:    */     {
/* 426:687 */       new ListenerCallQueue.Callback("failed({service=" + service + "})")
/* 427:    */       {
/* 428:    */         void call(ServiceManager.Listener listener)
/* 429:    */         {
/* 430:689 */           listener.failure(service);
/* 431:    */         }
/* 432:689 */       }.enqueueOn(this.listeners);
/* 433:    */     }
/* 434:    */     
/* 435:    */     void executeListeners()
/* 436:    */     {
/* 437:696 */       Preconditions.checkState(!this.monitor.isOccupiedByCurrentThread(), "It is incorrect to execute listeners with the monitor held.");
/* 438:699 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 439:700 */         ((ListenerCallQueue)this.listeners.get(i)).execute();
/* 440:    */       }
/* 441:    */     }
/* 442:    */     
/* 443:    */     @GuardedBy("monitor")
/* 444:    */     void checkHealthy()
/* 445:    */     {
/* 446:706 */       if (this.states.count(Service.State.RUNNING) != this.numberOfServices) {
/* 447:707 */         throw new IllegalStateException("Expected to be healthy after starting. The following services are not running: " + Multimaps.filterKeys(this.servicesByState, Predicates.not(Predicates.equalTo(Service.State.RUNNING))));
/* 448:    */       }
/* 449:    */     }
/* 450:    */   }
/* 451:    */   
/* 452:    */   private static final class ServiceListener
/* 453:    */     extends Service.Listener
/* 454:    */   {
/* 455:    */     final Service service;
/* 456:    */     final WeakReference<ServiceManager.ServiceManagerState> state;
/* 457:    */     
/* 458:    */     ServiceListener(Service service, WeakReference<ServiceManager.ServiceManagerState> state)
/* 459:    */     {
/* 460:726 */       this.service = service;
/* 461:727 */       this.state = state;
/* 462:    */     }
/* 463:    */     
/* 464:    */     public void starting()
/* 465:    */     {
/* 466:731 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 467:732 */       if (state != null)
/* 468:    */       {
/* 469:733 */         state.transitionService(this.service, Service.State.NEW, Service.State.STARTING);
/* 470:734 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 471:735 */           ServiceManager.logger.log(Level.FINE, "Starting {0}.", this.service);
/* 472:    */         }
/* 473:    */       }
/* 474:    */     }
/* 475:    */     
/* 476:    */     public void running()
/* 477:    */     {
/* 478:741 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 479:742 */       if (state != null) {
/* 480:743 */         state.transitionService(this.service, Service.State.STARTING, Service.State.RUNNING);
/* 481:    */       }
/* 482:    */     }
/* 483:    */     
/* 484:    */     public void stopping(Service.State from)
/* 485:    */     {
/* 486:748 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 487:749 */       if (state != null) {
/* 488:750 */         state.transitionService(this.service, from, Service.State.STOPPING);
/* 489:    */       }
/* 490:    */     }
/* 491:    */     
/* 492:    */     public void terminated(Service.State from)
/* 493:    */     {
/* 494:755 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 495:756 */       if (state != null)
/* 496:    */       {
/* 497:757 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 498:758 */           ServiceManager.logger.log(Level.FINE, "Service {0} has terminated. Previous state was: {1}", new Object[] { this.service, from });
/* 499:    */         }
/* 500:761 */         state.transitionService(this.service, from, Service.State.TERMINATED);
/* 501:    */       }
/* 502:    */     }
/* 503:    */     
/* 504:    */     public void failed(Service.State from, Throwable failure)
/* 505:    */     {
/* 506:766 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 507:767 */       if (state != null)
/* 508:    */       {
/* 509:770 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 510:771 */           ServiceManager.logger.log(Level.SEVERE, "Service " + this.service + " has failed in the " + from + " state.", failure);
/* 511:    */         }
/* 512:774 */         state.transitionService(this.service, from, Service.State.FAILED);
/* 513:    */       }
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   private static final class NoOpService
/* 518:    */     extends AbstractService
/* 519:    */   {
/* 520:    */     protected void doStart()
/* 521:    */     {
/* 522:788 */       notifyStarted();
/* 523:    */     }
/* 524:    */     
/* 525:    */     protected void doStop()
/* 526:    */     {
/* 527:789 */       notifyStopped();
/* 528:    */     }
/* 529:    */   }
/* 530:    */   
/* 531:    */   @Beta
/* 532:    */   public static abstract class Listener
/* 533:    */   {
/* 534:    */     public void healthy() {}
/* 535:    */     
/* 536:    */     public void stopped() {}
/* 537:    */     
/* 538:    */     public void failure(Service service) {}
/* 539:    */   }
/* 540:    */   
/* 541:    */   private static final class EmptyServiceManagerWarning
/* 542:    */     extends Throwable
/* 543:    */   {}
/* 544:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.ServiceManager
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Preconditions;
/*    5:     */ import com.google.common.base.Throwables;
/*    6:     */ import java.util.concurrent.TimeUnit;
/*    7:     */ import java.util.concurrent.locks.Condition;
/*    8:     */ import java.util.concurrent.locks.ReentrantLock;
/*    9:     */ import javax.annotation.concurrent.GuardedBy;
/*   10:     */ 
/*   11:     */ @Beta
/*   12:     */ public final class Monitor
/*   13:     */ {
/*   14:     */   private final boolean fair;
/*   15:     */   private final ReentrantLock lock;
/*   16:     */   
/*   17:     */   @Beta
/*   18:     */   public static abstract class Guard
/*   19:     */   {
/*   20:     */     final Monitor monitor;
/*   21:     */     final Condition condition;
/*   22:     */     @GuardedBy("monitor.lock")
/*   23: 296 */     int waiterCount = 0;
/*   24:     */     @GuardedBy("monitor.lock")
/*   25:     */     Guard next;
/*   26:     */     
/*   27:     */     protected Guard(Monitor monitor)
/*   28:     */     {
/*   29: 304 */       this.monitor = ((Monitor)Preconditions.checkNotNull(monitor, "monitor"));
/*   30: 305 */       this.condition = monitor.lock.newCondition();
/*   31:     */     }
/*   32:     */     
/*   33:     */     public abstract boolean isSatisfied();
/*   34:     */   }
/*   35:     */   
/*   36:     */   @GuardedBy("lock")
/*   37: 331 */   private Guard activeGuards = null;
/*   38:     */   
/*   39:     */   public Monitor()
/*   40:     */   {
/*   41: 339 */     this(false);
/*   42:     */   }
/*   43:     */   
/*   44:     */   public Monitor(boolean fair)
/*   45:     */   {
/*   46: 349 */     this.fair = fair;
/*   47: 350 */     this.lock = new ReentrantLock(fair);
/*   48:     */   }
/*   49:     */   
/*   50:     */   public void enter()
/*   51:     */   {
/*   52: 357 */     this.lock.lock();
/*   53:     */   }
/*   54:     */   
/*   55:     */   public void enterInterruptibly()
/*   56:     */     throws InterruptedException
/*   57:     */   {
/*   58: 364 */     this.lock.lockInterruptibly();
/*   59:     */   }
/*   60:     */   
/*   61:     */   public boolean enter(long time, TimeUnit unit)
/*   62:     */   {
/*   63: 373 */     long timeoutNanos = unit.toNanos(time);
/*   64: 374 */     ReentrantLock lock = this.lock;
/*   65: 375 */     if ((!this.fair) && (lock.tryLock())) {
/*   66: 376 */       return true;
/*   67:     */     }
/*   68: 378 */     long deadline = System.nanoTime() + timeoutNanos;
/*   69: 379 */     boolean interrupted = Thread.interrupted();
/*   70:     */     try
/*   71:     */     {
/*   72: 383 */       return lock.tryLock(timeoutNanos, TimeUnit.NANOSECONDS);
/*   73:     */     }
/*   74:     */     catch (InterruptedException interrupt)
/*   75:     */     {
/*   76:     */       for (;;)
/*   77:     */       {
/*   78: 385 */         interrupted = true;
/*   79: 386 */         timeoutNanos = deadline - System.nanoTime();
/*   80:     */       }
/*   81:     */     }
/*   82:     */     finally
/*   83:     */     {
/*   84: 390 */       if (interrupted) {
/*   85: 391 */         Thread.currentThread().interrupt();
/*   86:     */       }
/*   87:     */     }
/*   88:     */   }
/*   89:     */   
/*   90:     */   public boolean enterInterruptibly(long time, TimeUnit unit)
/*   91:     */     throws InterruptedException
/*   92:     */   {
/*   93: 402 */     return this.lock.tryLock(time, unit);
/*   94:     */   }
/*   95:     */   
/*   96:     */   public boolean tryEnter()
/*   97:     */   {
/*   98: 413 */     return this.lock.tryLock();
/*   99:     */   }
/*  100:     */   
/*  101:     */   public void enterWhen(Guard guard)
/*  102:     */     throws InterruptedException
/*  103:     */   {
/*  104: 420 */     if (guard.monitor != this) {
/*  105: 421 */       throw new IllegalMonitorStateException();
/*  106:     */     }
/*  107: 423 */     ReentrantLock lock = this.lock;
/*  108: 424 */     boolean signalBeforeWaiting = lock.isHeldByCurrentThread();
/*  109: 425 */     lock.lockInterruptibly();
/*  110:     */     
/*  111: 427 */     boolean satisfied = false;
/*  112:     */     try
/*  113:     */     {
/*  114: 429 */       if (!guard.isSatisfied()) {
/*  115: 430 */         await(guard, signalBeforeWaiting);
/*  116:     */       }
/*  117: 432 */       satisfied = true;
/*  118:     */     }
/*  119:     */     finally
/*  120:     */     {
/*  121: 434 */       if (!satisfied) {
/*  122: 435 */         leave();
/*  123:     */       }
/*  124:     */     }
/*  125:     */   }
/*  126:     */   
/*  127:     */   public void enterWhenUninterruptibly(Guard guard)
/*  128:     */   {
/*  129: 444 */     if (guard.monitor != this) {
/*  130: 445 */       throw new IllegalMonitorStateException();
/*  131:     */     }
/*  132: 447 */     ReentrantLock lock = this.lock;
/*  133: 448 */     boolean signalBeforeWaiting = lock.isHeldByCurrentThread();
/*  134: 449 */     lock.lock();
/*  135:     */     
/*  136: 451 */     boolean satisfied = false;
/*  137:     */     try
/*  138:     */     {
/*  139: 453 */       if (!guard.isSatisfied()) {
/*  140: 454 */         awaitUninterruptibly(guard, signalBeforeWaiting);
/*  141:     */       }
/*  142: 456 */       satisfied = true;
/*  143:     */     }
/*  144:     */     finally
/*  145:     */     {
/*  146: 458 */       if (!satisfied) {
/*  147: 459 */         leave();
/*  148:     */       }
/*  149:     */     }
/*  150:     */   }
/*  151:     */   
/*  152:     */   public boolean enterWhen(Guard guard, long time, TimeUnit unit)
/*  153:     */     throws InterruptedException
/*  154:     */   {
/*  155: 472 */     long timeoutNanos = unit.toNanos(time);
/*  156: 473 */     if (guard.monitor != this) {
/*  157: 474 */       throw new IllegalMonitorStateException();
/*  158:     */     }
/*  159: 476 */     ReentrantLock lock = this.lock;
/*  160: 477 */     boolean reentrant = lock.isHeldByCurrentThread();
/*  161: 478 */     if ((this.fair) || (!lock.tryLock()))
/*  162:     */     {
/*  163: 479 */       long deadline = System.nanoTime() + timeoutNanos;
/*  164: 480 */       if (!lock.tryLock(time, unit)) {
/*  165: 481 */         return false;
/*  166:     */       }
/*  167: 483 */       timeoutNanos = deadline - System.nanoTime();
/*  168:     */     }
/*  169: 486 */     boolean satisfied = false;
/*  170: 487 */     boolean threw = true;
/*  171:     */     try
/*  172:     */     {
/*  173: 489 */       satisfied = (guard.isSatisfied()) || (awaitNanos(guard, timeoutNanos, reentrant));
/*  174: 490 */       threw = false;
/*  175: 491 */       return satisfied;
/*  176:     */     }
/*  177:     */     finally
/*  178:     */     {
/*  179: 493 */       if (!satisfied) {
/*  180:     */         try
/*  181:     */         {
/*  182: 496 */           if ((threw) && (!reentrant)) {
/*  183: 497 */             signalNextWaiter();
/*  184:     */           }
/*  185:     */         }
/*  186:     */         finally
/*  187:     */         {
/*  188: 500 */           lock.unlock();
/*  189:     */         }
/*  190:     */       }
/*  191:     */     }
/*  192:     */   }
/*  193:     */   
/*  194:     */   /* Error */
/*  195:     */   public boolean enterWhenUninterruptibly(Guard guard, long time, TimeUnit unit)
/*  196:     */   {
/*  197:     */     // Byte code:
/*  198:     */     //   0: aload 4
/*  199:     */     //   2: lload_2
/*  200:     */     //   3: invokevirtual 198	java/util/concurrent/TimeUnit:toNanos	(J)J
/*  201:     */     //   6: lstore 5
/*  202:     */     //   8: aload_1
/*  203:     */     //   9: getfield 174	com/google/common/util/concurrent/Monitor$Guard:monitor	Lcom/google/common/util/concurrent/Monitor;
/*  204:     */     //   12: aload_0
/*  205:     */     //   13: if_acmpeq +11 -> 24
/*  206:     */     //   16: new 96	java/lang/IllegalMonitorStateException
/*  207:     */     //   19: dup
/*  208:     */     //   20: invokespecial 192	java/lang/IllegalMonitorStateException:<init>	()V
/*  209:     */     //   23: athrow
/*  210:     */     //   24: aload_0
/*  211:     */     //   25: getfield 172	com/google/common/util/concurrent/Monitor:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*  212:     */     //   28: astore 7
/*  213:     */     //   30: invokestatic 194	java/lang/System:nanoTime	()J
/*  214:     */     //   33: lload 5
/*  215:     */     //   35: ladd
/*  216:     */     //   36: lstore 8
/*  217:     */     //   38: aload 7
/*  218:     */     //   40: invokevirtual 205	java/util/concurrent/locks/ReentrantLock:isHeldByCurrentThread	()Z
/*  219:     */     //   43: istore 10
/*  220:     */     //   45: invokestatic 196	java/lang/Thread:interrupted	()Z
/*  221:     */     //   48: istore 11
/*  222:     */     //   50: aload_0
/*  223:     */     //   51: getfield 170	com/google/common/util/concurrent/Monitor:fair	Z
/*  224:     */     //   54: ifne +11 -> 65
/*  225:     */     //   57: aload 7
/*  226:     */     //   59: invokevirtual 207	java/util/concurrent/locks/ReentrantLock:tryLock	()Z
/*  227:     */     //   62: ifne +61 -> 123
/*  228:     */     //   65: iconst_0
/*  229:     */     //   66: istore 12
/*  230:     */     //   68: aload 7
/*  231:     */     //   70: lload 5
/*  232:     */     //   72: getstatic 177	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/*  233:     */     //   75: invokevirtual 210	java/util/concurrent/locks/ReentrantLock:tryLock	(JLjava/util/concurrent/TimeUnit;)Z
/*  234:     */     //   78: istore 12
/*  235:     */     //   80: iload 12
/*  236:     */     //   82: ifne +20 -> 102
/*  237:     */     //   85: iconst_0
/*  238:     */     //   86: istore 13
/*  239:     */     //   88: iload 11
/*  240:     */     //   90: ifeq +9 -> 99
/*  241:     */     //   93: invokestatic 197	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  242:     */     //   96: invokevirtual 195	java/lang/Thread:interrupt	()V
/*  243:     */     //   99: iload 13
/*  244:     */     //   101: ireturn
/*  245:     */     //   102: goto +8 -> 110
/*  246:     */     //   105: astore 13
/*  247:     */     //   107: iconst_1
/*  248:     */     //   108: istore 11
/*  249:     */     //   110: lload 8
/*  250:     */     //   112: invokestatic 194	java/lang/System:nanoTime	()J
/*  251:     */     //   115: lsub
/*  252:     */     //   116: lstore 5
/*  253:     */     //   118: iload 12
/*  254:     */     //   120: ifeq -52 -> 68
/*  255:     */     //   123: iconst_0
/*  256:     */     //   124: istore 12
/*  257:     */     //   126: aload_1
/*  258:     */     //   127: invokevirtual 191	com/google/common/util/concurrent/Monitor$Guard:isSatisfied	()Z
/*  259:     */     //   130: ifne +15 -> 145
/*  260:     */     //   133: aload_0
/*  261:     */     //   134: aload_1
/*  262:     */     //   135: lload 5
/*  263:     */     //   137: iload 10
/*  264:     */     //   139: invokespecial 187	com/google/common/util/concurrent/Monitor:awaitNanos	(Lcom/google/common/util/concurrent/Monitor$Guard;JZ)Z
/*  265:     */     //   142: ifeq +7 -> 149
/*  266:     */     //   145: iconst_1
/*  267:     */     //   146: goto +4 -> 150
/*  268:     */     //   149: iconst_0
/*  269:     */     //   150: dup
/*  270:     */     //   151: istore 12
/*  271:     */     //   153: istore 13
/*  272:     */     //   155: iload 12
/*  273:     */     //   157: ifne +8 -> 165
/*  274:     */     //   160: aload 7
/*  275:     */     //   162: invokevirtual 203	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*  276:     */     //   165: iload 11
/*  277:     */     //   167: ifeq +9 -> 176
/*  278:     */     //   170: invokestatic 197	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  279:     */     //   173: invokevirtual 195	java/lang/Thread:interrupt	()V
/*  280:     */     //   176: iload 13
/*  281:     */     //   178: ireturn
/*  282:     */     //   179: astore 13
/*  283:     */     //   181: iconst_1
/*  284:     */     //   182: istore 11
/*  285:     */     //   184: iconst_0
/*  286:     */     //   185: istore 10
/*  287:     */     //   187: lload 8
/*  288:     */     //   189: invokestatic 194	java/lang/System:nanoTime	()J
/*  289:     */     //   192: lsub
/*  290:     */     //   193: lstore 5
/*  291:     */     //   195: goto -69 -> 126
/*  292:     */     //   198: astore 14
/*  293:     */     //   200: iload 12
/*  294:     */     //   202: ifne +8 -> 210
/*  295:     */     //   205: aload 7
/*  296:     */     //   207: invokevirtual 203	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*  297:     */     //   210: aload 14
/*  298:     */     //   212: athrow
/*  299:     */     //   213: astore 15
/*  300:     */     //   215: iload 11
/*  301:     */     //   217: ifeq +9 -> 226
/*  302:     */     //   220: invokestatic 197	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  303:     */     //   223: invokevirtual 195	java/lang/Thread:interrupt	()V
/*  304:     */     //   226: aload 15
/*  305:     */     //   228: athrow
/*  306:     */     // Line number table:
/*  307:     */     //   Java source line #513	-> byte code offset #0
/*  308:     */     //   Java source line #514	-> byte code offset #8
/*  309:     */     //   Java source line #515	-> byte code offset #16
/*  310:     */     //   Java source line #517	-> byte code offset #24
/*  311:     */     //   Java source line #518	-> byte code offset #30
/*  312:     */     //   Java source line #519	-> byte code offset #38
/*  313:     */     //   Java source line #520	-> byte code offset #45
/*  314:     */     //   Java source line #522	-> byte code offset #50
/*  315:     */     //   Java source line #523	-> byte code offset #65
/*  316:     */     //   Java source line #526	-> byte code offset #68
/*  317:     */     //   Java source line #527	-> byte code offset #80
/*  318:     */     //   Java source line #528	-> byte code offset #85
/*  319:     */     //   Java source line #555	-> byte code offset #88
/*  320:     */     //   Java source line #556	-> byte code offset #93
/*  321:     */     //   Java source line #532	-> byte code offset #102
/*  322:     */     //   Java source line #530	-> byte code offset #105
/*  323:     */     //   Java source line #531	-> byte code offset #107
/*  324:     */     //   Java source line #533	-> byte code offset #110
/*  325:     */     //   Java source line #534	-> byte code offset #118
/*  326:     */     //   Java source line #537	-> byte code offset #123
/*  327:     */     //   Java source line #541	-> byte code offset #126
/*  328:     */     //   Java source line #550	-> byte code offset #155
/*  329:     */     //   Java source line #551	-> byte code offset #160
/*  330:     */     //   Java source line #555	-> byte code offset #165
/*  331:     */     //   Java source line #556	-> byte code offset #170
/*  332:     */     //   Java source line #543	-> byte code offset #179
/*  333:     */     //   Java source line #544	-> byte code offset #181
/*  334:     */     //   Java source line #545	-> byte code offset #184
/*  335:     */     //   Java source line #546	-> byte code offset #187
/*  336:     */     //   Java source line #547	-> byte code offset #195
/*  337:     */     //   Java source line #550	-> byte code offset #198
/*  338:     */     //   Java source line #551	-> byte code offset #205
/*  339:     */     //   Java source line #555	-> byte code offset #213
/*  340:     */     //   Java source line #556	-> byte code offset #220
/*  341:     */     // Local variable table:
/*  342:     */     //   start	length	slot	name	signature
/*  343:     */     //   0	229	0	this	Monitor
/*  344:     */     //   0	229	1	guard	Guard
/*  345:     */     //   0	229	2	time	long
/*  346:     */     //   0	229	4	unit	TimeUnit
/*  347:     */     //   6	188	5	timeoutNanos	long
/*  348:     */     //   28	178	7	lock	ReentrantLock
/*  349:     */     //   36	152	8	deadline	long
/*  350:     */     //   43	143	10	signalBeforeWaiting	boolean
/*  351:     */     //   48	168	11	interrupted	boolean
/*  352:     */     //   66	53	12	locked	boolean
/*  353:     */     //   124	77	12	satisfied	boolean
/*  354:     */     //   86	14	13	bool1	boolean
/*  355:     */     //   105	72	13	interrupt	InterruptedException
/*  356:     */     //   153	24	13	bool2	boolean
/*  357:     */     //   179	3	13	interrupt	InterruptedException
/*  358:     */     //   198	13	14	localObject1	Object
/*  359:     */     //   213	14	15	localObject2	Object
/*  360:     */     // Exception table:
/*  361:     */     //   from	to	target	type
/*  362:     */     //   68	88	105	java/lang/InterruptedException
/*  363:     */     //   126	155	179	java/lang/InterruptedException
/*  364:     */     //   126	155	198	finally
/*  365:     */     //   179	200	198	finally
/*  366:     */     //   50	88	213	finally
/*  367:     */     //   102	165	213	finally
/*  368:     */     //   179	215	213	finally
/*  369:     */   }
/*  370:     */   
/*  371:     */   public boolean enterIf(Guard guard)
/*  372:     */   {
/*  373: 568 */     if (guard.monitor != this) {
/*  374: 569 */       throw new IllegalMonitorStateException();
/*  375:     */     }
/*  376: 571 */     ReentrantLock lock = this.lock;
/*  377: 572 */     lock.lock();
/*  378:     */     
/*  379: 574 */     boolean satisfied = false;
/*  380:     */     try
/*  381:     */     {
/*  382: 576 */       return satisfied = guard.isSatisfied();
/*  383:     */     }
/*  384:     */     finally
/*  385:     */     {
/*  386: 578 */       if (!satisfied) {
/*  387: 579 */         lock.unlock();
/*  388:     */       }
/*  389:     */     }
/*  390:     */   }
/*  391:     */   
/*  392:     */   public boolean enterIfInterruptibly(Guard guard)
/*  393:     */     throws InterruptedException
/*  394:     */   {
/*  395: 591 */     if (guard.monitor != this) {
/*  396: 592 */       throw new IllegalMonitorStateException();
/*  397:     */     }
/*  398: 594 */     ReentrantLock lock = this.lock;
/*  399: 595 */     lock.lockInterruptibly();
/*  400:     */     
/*  401: 597 */     boolean satisfied = false;
/*  402:     */     try
/*  403:     */     {
/*  404: 599 */       return satisfied = guard.isSatisfied();
/*  405:     */     }
/*  406:     */     finally
/*  407:     */     {
/*  408: 601 */       if (!satisfied) {
/*  409: 602 */         lock.unlock();
/*  410:     */       }
/*  411:     */     }
/*  412:     */   }
/*  413:     */   
/*  414:     */   public boolean enterIf(Guard guard, long time, TimeUnit unit)
/*  415:     */   {
/*  416: 614 */     if (guard.monitor != this) {
/*  417: 615 */       throw new IllegalMonitorStateException();
/*  418:     */     }
/*  419: 617 */     if (!enter(time, unit)) {
/*  420: 618 */       return false;
/*  421:     */     }
/*  422: 621 */     boolean satisfied = false;
/*  423:     */     try
/*  424:     */     {
/*  425: 623 */       return satisfied = guard.isSatisfied();
/*  426:     */     }
/*  427:     */     finally
/*  428:     */     {
/*  429: 625 */       if (!satisfied) {
/*  430: 626 */         this.lock.unlock();
/*  431:     */       }
/*  432:     */     }
/*  433:     */   }
/*  434:     */   
/*  435:     */   public boolean enterIfInterruptibly(Guard guard, long time, TimeUnit unit)
/*  436:     */     throws InterruptedException
/*  437:     */   {
/*  438: 639 */     if (guard.monitor != this) {
/*  439: 640 */       throw new IllegalMonitorStateException();
/*  440:     */     }
/*  441: 642 */     ReentrantLock lock = this.lock;
/*  442: 643 */     if (!lock.tryLock(time, unit)) {
/*  443: 644 */       return false;
/*  444:     */     }
/*  445: 647 */     boolean satisfied = false;
/*  446:     */     try
/*  447:     */     {
/*  448: 649 */       return satisfied = guard.isSatisfied();
/*  449:     */     }
/*  450:     */     finally
/*  451:     */     {
/*  452: 651 */       if (!satisfied) {
/*  453: 652 */         lock.unlock();
/*  454:     */       }
/*  455:     */     }
/*  456:     */   }
/*  457:     */   
/*  458:     */   public boolean tryEnterIf(Guard guard)
/*  459:     */   {
/*  460: 666 */     if (guard.monitor != this) {
/*  461: 667 */       throw new IllegalMonitorStateException();
/*  462:     */     }
/*  463: 669 */     ReentrantLock lock = this.lock;
/*  464: 670 */     if (!lock.tryLock()) {
/*  465: 671 */       return false;
/*  466:     */     }
/*  467: 674 */     boolean satisfied = false;
/*  468:     */     try
/*  469:     */     {
/*  470: 676 */       return satisfied = guard.isSatisfied();
/*  471:     */     }
/*  472:     */     finally
/*  473:     */     {
/*  474: 678 */       if (!satisfied) {
/*  475: 679 */         lock.unlock();
/*  476:     */       }
/*  477:     */     }
/*  478:     */   }
/*  479:     */   
/*  480:     */   public void waitFor(Guard guard)
/*  481:     */     throws InterruptedException
/*  482:     */   {
/*  483: 689 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  484: 690 */       throw new IllegalMonitorStateException();
/*  485:     */     }
/*  486: 692 */     if (!guard.isSatisfied()) {
/*  487: 693 */       await(guard, true);
/*  488:     */     }
/*  489:     */   }
/*  490:     */   
/*  491:     */   public void waitForUninterruptibly(Guard guard)
/*  492:     */   {
/*  493: 702 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  494: 703 */       throw new IllegalMonitorStateException();
/*  495:     */     }
/*  496: 705 */     if (!guard.isSatisfied()) {
/*  497: 706 */       awaitUninterruptibly(guard, true);
/*  498:     */     }
/*  499:     */   }
/*  500:     */   
/*  501:     */   public boolean waitFor(Guard guard, long time, TimeUnit unit)
/*  502:     */     throws InterruptedException
/*  503:     */   {
/*  504: 717 */     long timeoutNanos = unit.toNanos(time);
/*  505: 718 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  506: 719 */       throw new IllegalMonitorStateException();
/*  507:     */     }
/*  508: 721 */     return (guard.isSatisfied()) || (awaitNanos(guard, timeoutNanos, true));
/*  509:     */   }
/*  510:     */   
/*  511:     */   public boolean waitForUninterruptibly(Guard guard, long time, TimeUnit unit)
/*  512:     */   {
/*  513: 731 */     long timeoutNanos = unit.toNanos(time);
/*  514: 732 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  515: 733 */       throw new IllegalMonitorStateException();
/*  516:     */     }
/*  517: 735 */     if (guard.isSatisfied()) {
/*  518: 736 */       return true;
/*  519:     */     }
/*  520: 738 */     boolean signalBeforeWaiting = true;
/*  521: 739 */     long deadline = System.nanoTime() + timeoutNanos;
/*  522: 740 */     boolean interrupted = Thread.interrupted();
/*  523:     */     try
/*  524:     */     {
/*  525: 744 */       return awaitNanos(guard, timeoutNanos, signalBeforeWaiting);
/*  526:     */     }
/*  527:     */     catch (InterruptedException interrupt)
/*  528:     */     {
/*  529:     */       for (;;)
/*  530:     */       {
/*  531: 746 */         interrupted = true;
/*  532: 747 */         if (guard.isSatisfied()) {
/*  533: 748 */           return true;
/*  534:     */         }
/*  535: 750 */         signalBeforeWaiting = false;
/*  536: 751 */         timeoutNanos = deadline - System.nanoTime();
/*  537:     */       }
/*  538:     */     }
/*  539:     */     finally
/*  540:     */     {
/*  541: 755 */       if (interrupted) {
/*  542: 756 */         Thread.currentThread().interrupt();
/*  543:     */       }
/*  544:     */     }
/*  545:     */   }
/*  546:     */   
/*  547:     */   public void leave()
/*  548:     */   {
/*  549: 765 */     ReentrantLock lock = this.lock;
/*  550:     */     try
/*  551:     */     {
/*  552: 768 */       if (lock.getHoldCount() == 1) {
/*  553: 769 */         signalNextWaiter();
/*  554:     */       }
/*  555:     */     }
/*  556:     */     finally
/*  557:     */     {
/*  558: 772 */       lock.unlock();
/*  559:     */     }
/*  560:     */   }
/*  561:     */   
/*  562:     */   public boolean isFair()
/*  563:     */   {
/*  564: 780 */     return this.fair;
/*  565:     */   }
/*  566:     */   
/*  567:     */   public boolean isOccupied()
/*  568:     */   {
/*  569: 788 */     return this.lock.isLocked();
/*  570:     */   }
/*  571:     */   
/*  572:     */   public boolean isOccupiedByCurrentThread()
/*  573:     */   {
/*  574: 796 */     return this.lock.isHeldByCurrentThread();
/*  575:     */   }
/*  576:     */   
/*  577:     */   public int getOccupiedDepth()
/*  578:     */   {
/*  579: 804 */     return this.lock.getHoldCount();
/*  580:     */   }
/*  581:     */   
/*  582:     */   public int getQueueLength()
/*  583:     */   {
/*  584: 814 */     return this.lock.getQueueLength();
/*  585:     */   }
/*  586:     */   
/*  587:     */   public boolean hasQueuedThreads()
/*  588:     */   {
/*  589: 824 */     return this.lock.hasQueuedThreads();
/*  590:     */   }
/*  591:     */   
/*  592:     */   public boolean hasQueuedThread(Thread thread)
/*  593:     */   {
/*  594: 834 */     return this.lock.hasQueuedThread(thread);
/*  595:     */   }
/*  596:     */   
/*  597:     */   public boolean hasWaiters(Guard guard)
/*  598:     */   {
/*  599: 844 */     return getWaitQueueLength(guard) > 0;
/*  600:     */   }
/*  601:     */   
/*  602:     */   public int getWaitQueueLength(Guard guard)
/*  603:     */   {
/*  604: 854 */     if (guard.monitor != this) {
/*  605: 855 */       throw new IllegalMonitorStateException();
/*  606:     */     }
/*  607: 857 */     this.lock.lock();
/*  608:     */     try
/*  609:     */     {
/*  610: 859 */       return guard.waiterCount;
/*  611:     */     }
/*  612:     */     finally
/*  613:     */     {
/*  614: 861 */       this.lock.unlock();
/*  615:     */     }
/*  616:     */   }
/*  617:     */   
/*  618:     */   @GuardedBy("lock")
/*  619:     */   private void signalNextWaiter()
/*  620:     */   {
/*  621: 891 */     for (Guard guard = this.activeGuards; guard != null; guard = guard.next) {
/*  622: 892 */       if (isSatisfied(guard))
/*  623:     */       {
/*  624: 893 */         guard.condition.signal();
/*  625: 894 */         break;
/*  626:     */       }
/*  627:     */     }
/*  628:     */   }
/*  629:     */   
/*  630:     */   @GuardedBy("lock")
/*  631:     */   private boolean isSatisfied(Guard guard)
/*  632:     */   {
/*  633:     */     try
/*  634:     */     {
/*  635: 924 */       return guard.isSatisfied();
/*  636:     */     }
/*  637:     */     catch (Throwable throwable)
/*  638:     */     {
/*  639: 926 */       signalAllWaiters();
/*  640: 927 */       throw Throwables.propagate(throwable);
/*  641:     */     }
/*  642:     */   }
/*  643:     */   
/*  644:     */   @GuardedBy("lock")
/*  645:     */   private void signalAllWaiters()
/*  646:     */   {
/*  647: 936 */     for (Guard guard = this.activeGuards; guard != null; guard = guard.next) {
/*  648: 937 */       guard.condition.signalAll();
/*  649:     */     }
/*  650:     */   }
/*  651:     */   
/*  652:     */   @GuardedBy("lock")
/*  653:     */   private void beginWaitingFor(Guard guard)
/*  654:     */   {
/*  655: 946 */     int waiters = guard.waiterCount++;
/*  656: 947 */     if (waiters == 0)
/*  657:     */     {
/*  658: 949 */       guard.next = this.activeGuards;
/*  659: 950 */       this.activeGuards = guard;
/*  660:     */     }
/*  661:     */   }
/*  662:     */   
/*  663:     */   @GuardedBy("lock")
/*  664:     */   private void endWaitingFor(Guard guard)
/*  665:     */   {
/*  666: 959 */     int waiters = --guard.waiterCount;
/*  667: 960 */     if (waiters == 0)
/*  668:     */     {
/*  669: 962 */       Guard p = this.activeGuards;
/*  670: 962 */       for (Guard pred = null;; p = p.next)
/*  671:     */       {
/*  672: 963 */         if (p == guard)
/*  673:     */         {
/*  674: 964 */           if (pred == null) {
/*  675: 965 */             this.activeGuards = p.next;
/*  676:     */           } else {
/*  677: 967 */             pred.next = p.next;
/*  678:     */           }
/*  679: 969 */           p.next = null;
/*  680: 970 */           break;
/*  681:     */         }
/*  682: 962 */         pred = p;
/*  683:     */       }
/*  684:     */     }
/*  685:     */   }
/*  686:     */   
/*  687:     */   @GuardedBy("lock")
/*  688:     */   private void await(Guard guard, boolean signalBeforeWaiting)
/*  689:     */     throws InterruptedException
/*  690:     */   {
/*  691: 985 */     if (signalBeforeWaiting) {
/*  692: 986 */       signalNextWaiter();
/*  693:     */     }
/*  694: 988 */     beginWaitingFor(guard);
/*  695:     */     try
/*  696:     */     {
/*  697:     */       do
/*  698:     */       {
/*  699: 991 */         guard.condition.await();
/*  700: 992 */       } while (!guard.isSatisfied());
/*  701:     */     }
/*  702:     */     finally
/*  703:     */     {
/*  704: 994 */       endWaitingFor(guard);
/*  705:     */     }
/*  706:     */   }
/*  707:     */   
/*  708:     */   @GuardedBy("lock")
/*  709:     */   private void awaitUninterruptibly(Guard guard, boolean signalBeforeWaiting)
/*  710:     */   {
/*  711:1000 */     if (signalBeforeWaiting) {
/*  712:1001 */       signalNextWaiter();
/*  713:     */     }
/*  714:1003 */     beginWaitingFor(guard);
/*  715:     */     try
/*  716:     */     {
/*  717:     */       do
/*  718:     */       {
/*  719:1006 */         guard.condition.awaitUninterruptibly();
/*  720:1007 */       } while (!guard.isSatisfied());
/*  721:     */     }
/*  722:     */     finally
/*  723:     */     {
/*  724:1009 */       endWaitingFor(guard);
/*  725:     */     }
/*  726:     */   }
/*  727:     */   
/*  728:     */   @GuardedBy("lock")
/*  729:     */   private boolean awaitNanos(Guard guard, long nanos, boolean signalBeforeWaiting)
/*  730:     */     throws InterruptedException
/*  731:     */   {
/*  732:1016 */     if (signalBeforeWaiting) {
/*  733:1017 */       signalNextWaiter();
/*  734:     */     }
/*  735:1019 */     beginWaitingFor(guard);
/*  736:     */     try
/*  737:     */     {
/*  738:     */       boolean bool;
/*  739:     */       do
/*  740:     */       {
/*  741:1022 */         if (nanos < 0L) {
/*  742:1023 */           return false;
/*  743:     */         }
/*  744:1025 */         nanos = guard.condition.awaitNanos(nanos);
/*  745:1026 */       } while (!guard.isSatisfied());
/*  746:1027 */       return true;
/*  747:     */     }
/*  748:     */     finally
/*  749:     */     {
/*  750:1029 */       endWaitingFor(guard);
/*  751:     */     }
/*  752:     */   }
/*  753:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Monitor
 * JD-Core Version:    0.7.0.1
 */
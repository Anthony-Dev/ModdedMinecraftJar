/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ final class AsyncSettableFuture<V>
/*  7:   */   extends ForwardingListenableFuture<V>
/*  8:   */ {
/*  9:   */   public static <V> AsyncSettableFuture<V> create()
/* 10:   */   {
/* 11:41 */     return new AsyncSettableFuture();
/* 12:   */   }
/* 13:   */   
/* 14:44 */   private final NestedFuture<V> nested = new NestedFuture(null);
/* 15:45 */   private final ListenableFuture<V> dereferenced = Futures.dereference(this.nested);
/* 16:   */   
/* 17:   */   protected ListenableFuture<V> delegate()
/* 18:   */   {
/* 19:50 */     return this.dereferenced;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean setFuture(ListenableFuture<? extends V> future)
/* 23:   */   {
/* 24:58 */     return this.nested.setFuture((ListenableFuture)Preconditions.checkNotNull(future));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean setValue(@Nullable V value)
/* 28:   */   {
/* 29:67 */     return setFuture(Futures.immediateFuture(value));
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean setException(Throwable exception)
/* 33:   */   {
/* 34:76 */     return setFuture(Futures.immediateFailedFuture(exception));
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean isSet()
/* 38:   */   {
/* 39:88 */     return this.nested.isDone();
/* 40:   */   }
/* 41:   */   
/* 42:   */   private static final class NestedFuture<V>
/* 43:   */     extends AbstractFuture<ListenableFuture<? extends V>>
/* 44:   */   {
/* 45:   */     boolean setFuture(ListenableFuture<? extends V> value)
/* 46:   */     {
/* 47:93 */       boolean result = set(value);
/* 48:94 */       if (isCancelled()) {
/* 49:95 */         value.cancel(wasInterrupted());
/* 50:   */       }
/* 51:97 */       return result;
/* 52:   */     }
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AsyncSettableFuture
 * JD-Core Version:    0.7.0.1
 */
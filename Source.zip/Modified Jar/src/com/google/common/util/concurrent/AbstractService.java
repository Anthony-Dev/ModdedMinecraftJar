/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.concurrent.Executor;
/*   9:    */ import java.util.concurrent.TimeUnit;
/*  10:    */ import java.util.concurrent.TimeoutException;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ import javax.annotation.concurrent.GuardedBy;
/*  13:    */ import javax.annotation.concurrent.Immutable;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ public abstract class AbstractService
/*  17:    */   implements Service
/*  18:    */ {
/*  19: 57 */   private static final ListenerCallQueue.Callback<Service.Listener> STARTING_CALLBACK = new ListenerCallQueue.Callback("starting()")
/*  20:    */   {
/*  21:    */     void call(Service.Listener listener)
/*  22:    */     {
/*  23: 60 */       listener.starting();
/*  24:    */     }
/*  25:    */   };
/*  26: 63 */   private static final ListenerCallQueue.Callback<Service.Listener> RUNNING_CALLBACK = new ListenerCallQueue.Callback("running()")
/*  27:    */   {
/*  28:    */     void call(Service.Listener listener)
/*  29:    */     {
/*  30: 66 */       listener.running();
/*  31:    */     }
/*  32:    */   };
/*  33: 69 */   private static final ListenerCallQueue.Callback<Service.Listener> STOPPING_FROM_STARTING_CALLBACK = stoppingCallback(Service.State.STARTING);
/*  34: 71 */   private static final ListenerCallQueue.Callback<Service.Listener> STOPPING_FROM_RUNNING_CALLBACK = stoppingCallback(Service.State.RUNNING);
/*  35: 74 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_NEW_CALLBACK = terminatedCallback(Service.State.NEW);
/*  36: 76 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_RUNNING_CALLBACK = terminatedCallback(Service.State.RUNNING);
/*  37: 78 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_STOPPING_CALLBACK = terminatedCallback(Service.State.STOPPING);
/*  38:    */   
/*  39:    */   private static ListenerCallQueue.Callback<Service.Listener> terminatedCallback(final Service.State from)
/*  40:    */   {
/*  41: 82 */     new ListenerCallQueue.Callback("terminated({from = " + from + "})")
/*  42:    */     {
/*  43:    */       void call(Service.Listener listener)
/*  44:    */       {
/*  45: 84 */         listener.terminated(from);
/*  46:    */       }
/*  47:    */     };
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static ListenerCallQueue.Callback<Service.Listener> stoppingCallback(final Service.State from)
/*  51:    */   {
/*  52: 90 */     new ListenerCallQueue.Callback("stopping({from = " + from + "})")
/*  53:    */     {
/*  54:    */       void call(Service.Listener listener)
/*  55:    */       {
/*  56: 92 */         listener.stopping(from);
/*  57:    */       }
/*  58:    */     };
/*  59:    */   }
/*  60:    */   
/*  61: 97 */   private final Monitor monitor = new Monitor();
/*  62: 99 */   private final Monitor.Guard isStartable = new Monitor.Guard(this.monitor)
/*  63:    */   {
/*  64:    */     public boolean isSatisfied()
/*  65:    */     {
/*  66:101 */       return AbstractService.this.state() == Service.State.NEW;
/*  67:    */     }
/*  68:    */   };
/*  69:105 */   private final Monitor.Guard isStoppable = new Monitor.Guard(this.monitor)
/*  70:    */   {
/*  71:    */     public boolean isSatisfied()
/*  72:    */     {
/*  73:107 */       return AbstractService.this.state().compareTo(Service.State.RUNNING) <= 0;
/*  74:    */     }
/*  75:    */   };
/*  76:111 */   private final Monitor.Guard hasReachedRunning = new Monitor.Guard(this.monitor)
/*  77:    */   {
/*  78:    */     public boolean isSatisfied()
/*  79:    */     {
/*  80:113 */       return AbstractService.this.state().compareTo(Service.State.RUNNING) >= 0;
/*  81:    */     }
/*  82:    */   };
/*  83:117 */   private final Monitor.Guard isStopped = new Monitor.Guard(this.monitor)
/*  84:    */   {
/*  85:    */     public boolean isSatisfied()
/*  86:    */     {
/*  87:119 */       return AbstractService.this.state().isTerminal();
/*  88:    */     }
/*  89:    */   };
/*  90:    */   @GuardedBy("monitor")
/*  91:126 */   private final List<ListenerCallQueue<Service.Listener>> listeners = Collections.synchronizedList(new ArrayList());
/*  92:    */   @GuardedBy("monitor")
/*  93:139 */   private volatile StateSnapshot snapshot = new StateSnapshot(Service.State.NEW);
/*  94:    */   
/*  95:    */   protected abstract void doStart();
/*  96:    */   
/*  97:    */   protected abstract void doStop();
/*  98:    */   
/*  99:    */   public final Service startAsync()
/* 100:    */   {
/* 101:170 */     if (this.monitor.enterIf(this.isStartable)) {
/* 102:    */       try
/* 103:    */       {
/* 104:172 */         this.snapshot = new StateSnapshot(Service.State.STARTING);
/* 105:173 */         starting();
/* 106:174 */         doStart();
/* 107:    */       }
/* 108:    */       catch (Throwable startupFailure)
/* 109:    */       {
/* 110:177 */         notifyFailed(startupFailure);
/* 111:    */       }
/* 112:    */       finally
/* 113:    */       {
/* 114:179 */         this.monitor.leave();
/* 115:180 */         executeListeners();
/* 116:    */       }
/* 117:    */     } else {
/* 118:183 */       throw new IllegalStateException("Service " + this + " has already been started");
/* 119:    */     }
/* 120:185 */     return this;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public final Service stopAsync()
/* 124:    */   {
/* 125:189 */     if (this.monitor.enterIf(this.isStoppable)) {
/* 126:    */       try
/* 127:    */       {
/* 128:191 */         Service.State previous = state();
/* 129:192 */         switch (10.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()])
/* 130:    */         {
/* 131:    */         case 1: 
/* 132:194 */           this.snapshot = new StateSnapshot(Service.State.TERMINATED);
/* 133:195 */           terminated(Service.State.NEW);
/* 134:196 */           break;
/* 135:    */         case 2: 
/* 136:198 */           this.snapshot = new StateSnapshot(Service.State.STARTING, true, null);
/* 137:199 */           stopping(Service.State.STARTING);
/* 138:200 */           break;
/* 139:    */         case 3: 
/* 140:202 */           this.snapshot = new StateSnapshot(Service.State.STOPPING);
/* 141:203 */           stopping(Service.State.RUNNING);
/* 142:204 */           doStop();
/* 143:205 */           break;
/* 144:    */         case 4: 
/* 145:    */         case 5: 
/* 146:    */         case 6: 
/* 147:210 */           throw new AssertionError("isStoppable is incorrectly implemented, saw: " + previous);
/* 148:    */         default: 
/* 149:212 */           throw new AssertionError("Unexpected state: " + previous);
/* 150:    */         }
/* 151:    */       }
/* 152:    */       catch (Throwable shutdownFailure)
/* 153:    */       {
/* 154:217 */         notifyFailed(shutdownFailure);
/* 155:    */       }
/* 156:    */       finally
/* 157:    */       {
/* 158:219 */         this.monitor.leave();
/* 159:220 */         executeListeners();
/* 160:    */       }
/* 161:    */     }
/* 162:223 */     return this;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public final void awaitRunning()
/* 166:    */   {
/* 167:227 */     this.monitor.enterWhenUninterruptibly(this.hasReachedRunning);
/* 168:    */     try
/* 169:    */     {
/* 170:229 */       checkCurrentState(Service.State.RUNNING);
/* 171:    */     }
/* 172:    */     finally
/* 173:    */     {
/* 174:231 */       this.monitor.leave();
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 179:    */     throws TimeoutException
/* 180:    */   {
/* 181:236 */     if (this.monitor.enterWhenUninterruptibly(this.hasReachedRunning, timeout, unit)) {
/* 182:    */       try
/* 183:    */       {
/* 184:238 */         checkCurrentState(Service.State.RUNNING);
/* 185:    */       }
/* 186:    */       finally
/* 187:    */       {
/* 188:240 */         this.monitor.leave();
/* 189:    */       }
/* 190:    */     } else {
/* 191:247 */       throw new TimeoutException("Timed out waiting for " + this + " to reach the RUNNING state. " + "Current state: " + state());
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public final void awaitTerminated()
/* 196:    */   {
/* 197:253 */     this.monitor.enterWhenUninterruptibly(this.isStopped);
/* 198:    */     try
/* 199:    */     {
/* 200:255 */       checkCurrentState(Service.State.TERMINATED);
/* 201:    */     }
/* 202:    */     finally
/* 203:    */     {
/* 204:257 */       this.monitor.leave();
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 209:    */     throws TimeoutException
/* 210:    */   {
/* 211:262 */     if (this.monitor.enterWhenUninterruptibly(this.isStopped, timeout, unit)) {
/* 212:    */       try
/* 213:    */       {
/* 214:264 */         checkCurrentState(Service.State.TERMINATED);
/* 215:    */       }
/* 216:    */       finally
/* 217:    */       {
/* 218:266 */         this.monitor.leave();
/* 219:    */       }
/* 220:    */     } else {
/* 221:273 */       throw new TimeoutException("Timed out waiting for " + this + " to reach a terminal state. " + "Current state: " + state());
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   @GuardedBy("monitor")
/* 226:    */   private void checkCurrentState(Service.State expected)
/* 227:    */   {
/* 228:281 */     Service.State actual = state();
/* 229:282 */     if (actual != expected)
/* 230:    */     {
/* 231:283 */       if (actual == Service.State.FAILED) {
/* 232:285 */         throw new IllegalStateException("Expected the service to be " + expected + ", but the service has FAILED", failureCause());
/* 233:    */       }
/* 234:288 */       throw new IllegalStateException("Expected the service to be " + expected + ", but was " + actual);
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   protected final void notifyStarted()
/* 239:    */   {
/* 240:300 */     this.monitor.enter();
/* 241:    */     try
/* 242:    */     {
/* 243:304 */       if (this.snapshot.state != Service.State.STARTING)
/* 244:    */       {
/* 245:305 */         IllegalStateException failure = new IllegalStateException("Cannot notifyStarted() when the service is " + this.snapshot.state);
/* 246:    */         
/* 247:307 */         notifyFailed(failure);
/* 248:308 */         throw failure;
/* 249:    */       }
/* 250:311 */       if (this.snapshot.shutdownWhenStartupFinishes)
/* 251:    */       {
/* 252:312 */         this.snapshot = new StateSnapshot(Service.State.STOPPING);
/* 253:    */         
/* 254:    */ 
/* 255:315 */         doStop();
/* 256:    */       }
/* 257:    */       else
/* 258:    */       {
/* 259:317 */         this.snapshot = new StateSnapshot(Service.State.RUNNING);
/* 260:318 */         running();
/* 261:    */       }
/* 262:    */     }
/* 263:    */     finally
/* 264:    */     {
/* 265:321 */       this.monitor.leave();
/* 266:322 */       executeListeners();
/* 267:    */     }
/* 268:    */   }
/* 269:    */   
/* 270:    */   protected final void notifyStopped()
/* 271:    */   {
/* 272:334 */     this.monitor.enter();
/* 273:    */     try
/* 274:    */     {
/* 275:338 */       Service.State previous = this.snapshot.state;
/* 276:339 */       if ((previous != Service.State.STOPPING) && (previous != Service.State.RUNNING))
/* 277:    */       {
/* 278:340 */         IllegalStateException failure = new IllegalStateException("Cannot notifyStopped() when the service is " + previous);
/* 279:    */         
/* 280:342 */         notifyFailed(failure);
/* 281:343 */         throw failure;
/* 282:    */       }
/* 283:345 */       this.snapshot = new StateSnapshot(Service.State.TERMINATED);
/* 284:346 */       terminated(previous);
/* 285:    */     }
/* 286:    */     finally
/* 287:    */     {
/* 288:348 */       this.monitor.leave();
/* 289:349 */       executeListeners();
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   protected final void notifyFailed(Throwable cause)
/* 294:    */   {
/* 295:359 */     Preconditions.checkNotNull(cause);
/* 296:    */     
/* 297:361 */     this.monitor.enter();
/* 298:    */     try
/* 299:    */     {
/* 300:363 */       Service.State previous = state();
/* 301:364 */       switch (10.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()])
/* 302:    */       {
/* 303:    */       case 1: 
/* 304:    */       case 5: 
/* 305:367 */         throw new IllegalStateException("Failed while in state:" + previous, cause);
/* 306:    */       case 2: 
/* 307:    */       case 3: 
/* 308:    */       case 4: 
/* 309:371 */         this.snapshot = new StateSnapshot(Service.State.FAILED, false, cause);
/* 310:372 */         failed(previous, cause);
/* 311:373 */         break;
/* 312:    */       case 6: 
/* 313:    */         break;
/* 314:    */       default: 
/* 315:378 */         throw new AssertionError("Unexpected state: " + previous);
/* 316:    */       }
/* 317:    */     }
/* 318:    */     finally
/* 319:    */     {
/* 320:381 */       this.monitor.leave();
/* 321:382 */       executeListeners();
/* 322:    */     }
/* 323:    */   }
/* 324:    */   
/* 325:    */   public final boolean isRunning()
/* 326:    */   {
/* 327:388 */     return state() == Service.State.RUNNING;
/* 328:    */   }
/* 329:    */   
/* 330:    */   public final Service.State state()
/* 331:    */   {
/* 332:393 */     return this.snapshot.externalState();
/* 333:    */   }
/* 334:    */   
/* 335:    */   public final Throwable failureCause()
/* 336:    */   {
/* 337:401 */     return this.snapshot.failureCause();
/* 338:    */   }
/* 339:    */   
/* 340:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 341:    */   {
/* 342:409 */     Preconditions.checkNotNull(listener, "listener");
/* 343:410 */     Preconditions.checkNotNull(executor, "executor");
/* 344:411 */     this.monitor.enter();
/* 345:    */     try
/* 346:    */     {
/* 347:413 */       if (!state().isTerminal()) {
/* 348:414 */         this.listeners.add(new ListenerCallQueue(listener, executor));
/* 349:    */       }
/* 350:    */     }
/* 351:    */     finally
/* 352:    */     {
/* 353:417 */       this.monitor.leave();
/* 354:    */     }
/* 355:    */   }
/* 356:    */   
/* 357:    */   public String toString()
/* 358:    */   {
/* 359:422 */     return getClass().getSimpleName() + " [" + state() + "]";
/* 360:    */   }
/* 361:    */   
/* 362:    */   private void executeListeners()
/* 363:    */   {
/* 364:430 */     if (!this.monitor.isOccupiedByCurrentThread()) {
/* 365:432 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 366:433 */         ((ListenerCallQueue)this.listeners.get(i)).execute();
/* 367:    */       }
/* 368:    */     }
/* 369:    */   }
/* 370:    */   
/* 371:    */   @GuardedBy("monitor")
/* 372:    */   private void starting()
/* 373:    */   {
/* 374:440 */     STARTING_CALLBACK.enqueueOn(this.listeners);
/* 375:    */   }
/* 376:    */   
/* 377:    */   @GuardedBy("monitor")
/* 378:    */   private void running()
/* 379:    */   {
/* 380:445 */     RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 381:    */   }
/* 382:    */   
/* 383:    */   @GuardedBy("monitor")
/* 384:    */   private void stopping(Service.State from)
/* 385:    */   {
/* 386:450 */     if (from == Service.State.STARTING) {
/* 387:451 */       STOPPING_FROM_STARTING_CALLBACK.enqueueOn(this.listeners);
/* 388:452 */     } else if (from == Service.State.RUNNING) {
/* 389:453 */       STOPPING_FROM_RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 390:    */     } else {
/* 391:455 */       throw new AssertionError();
/* 392:    */     }
/* 393:    */   }
/* 394:    */   
/* 395:    */   @GuardedBy("monitor")
/* 396:    */   private void terminated(Service.State from)
/* 397:    */   {
/* 398:461 */     switch (10.$SwitchMap$com$google$common$util$concurrent$Service$State[from.ordinal()])
/* 399:    */     {
/* 400:    */     case 1: 
/* 401:463 */       TERMINATED_FROM_NEW_CALLBACK.enqueueOn(this.listeners);
/* 402:464 */       break;
/* 403:    */     case 3: 
/* 404:466 */       TERMINATED_FROM_RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 405:467 */       break;
/* 406:    */     case 4: 
/* 407:469 */       TERMINATED_FROM_STOPPING_CALLBACK.enqueueOn(this.listeners);
/* 408:470 */       break;
/* 409:    */     case 2: 
/* 410:    */     case 5: 
/* 411:    */     case 6: 
/* 412:    */     default: 
/* 413:475 */       throw new AssertionError();
/* 414:    */     }
/* 415:    */   }
/* 416:    */   
/* 417:    */   @GuardedBy("monitor")
/* 418:    */   private void failed(final Service.State from, final Throwable cause)
/* 419:    */   {
/* 420:482 */     new ListenerCallQueue.Callback("failed({from = " + from + ", cause = " + cause + "})")
/* 421:    */     {
/* 422:    */       void call(Service.Listener listener)
/* 423:    */       {
/* 424:484 */         listener.failed(from, cause);
/* 425:    */       }
/* 426:484 */     }.enqueueOn(this.listeners);
/* 427:    */   }
/* 428:    */   
/* 429:    */   @Immutable
/* 430:    */   private static final class StateSnapshot
/* 431:    */   {
/* 432:    */     final Service.State state;
/* 433:    */     final boolean shutdownWhenStartupFinishes;
/* 434:    */     @Nullable
/* 435:    */     final Throwable failure;
/* 436:    */     
/* 437:    */     StateSnapshot(Service.State internalState)
/* 438:    */     {
/* 439:516 */       this(internalState, false, null);
/* 440:    */     }
/* 441:    */     
/* 442:    */     StateSnapshot(Service.State internalState, boolean shutdownWhenStartupFinishes, @Nullable Throwable failure)
/* 443:    */     {
/* 444:521 */       Preconditions.checkArgument((!shutdownWhenStartupFinishes) || (internalState == Service.State.STARTING), "shudownWhenStartupFinishes can only be set if state is STARTING. Got %s instead.", new Object[] { internalState });
/* 445:    */       
/* 446:    */ 
/* 447:524 */       Preconditions.checkArgument(((failure != null ? 1 : 0) ^ (internalState == Service.State.FAILED ? 1 : 0)) == 0, "A failure cause should be set if and only if the state is failed.  Got %s and %s instead.", new Object[] { internalState, failure });
/* 448:    */       
/* 449:    */ 
/* 450:527 */       this.state = internalState;
/* 451:528 */       this.shutdownWhenStartupFinishes = shutdownWhenStartupFinishes;
/* 452:529 */       this.failure = failure;
/* 453:    */     }
/* 454:    */     
/* 455:    */     Service.State externalState()
/* 456:    */     {
/* 457:534 */       if ((this.shutdownWhenStartupFinishes) && (this.state == Service.State.STARTING)) {
/* 458:535 */         return Service.State.STOPPING;
/* 459:    */       }
/* 460:537 */       return this.state;
/* 461:    */     }
/* 462:    */     
/* 463:    */     Throwable failureCause()
/* 464:    */     {
/* 465:543 */       Preconditions.checkState(this.state == Service.State.FAILED, "failureCause() is only valid if the service has failed, service is %s", new Object[] { this.state });
/* 466:    */       
/* 467:545 */       return this.failure;
/* 468:    */     }
/* 469:    */   }
/* 470:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractService
 * JD-Core Version:    0.7.0.1
 */
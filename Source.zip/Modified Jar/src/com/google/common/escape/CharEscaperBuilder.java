/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible
/*  12:    */ public final class CharEscaperBuilder
/*  13:    */ {
/*  14:    */   private final Map<Character, String> map;
/*  15:    */   
/*  16:    */   private static class CharArrayDecorator
/*  17:    */     extends CharEscaper
/*  18:    */   {
/*  19:    */     private final char[][] replacements;
/*  20:    */     private final int replaceLength;
/*  21:    */     
/*  22:    */     CharArrayDecorator(char[][] replacements)
/*  23:    */     {
/*  24: 48 */       this.replacements = replacements;
/*  25: 49 */       this.replaceLength = replacements.length;
/*  26:    */     }
/*  27:    */     
/*  28:    */     public String escape(String s)
/*  29:    */     {
/*  30: 57 */       int slen = s.length();
/*  31: 58 */       for (int index = 0; index < slen; index++)
/*  32:    */       {
/*  33: 59 */         char c = s.charAt(index);
/*  34: 60 */         if ((c < this.replacements.length) && (this.replacements[c] != null)) {
/*  35: 61 */           return escapeSlow(s, index);
/*  36:    */         }
/*  37:    */       }
/*  38: 64 */       return s;
/*  39:    */     }
/*  40:    */     
/*  41:    */     protected char[] escape(char c)
/*  42:    */     {
/*  43: 68 */       return c < this.replaceLength ? this.replacements[c] : null;
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47: 76 */   private int max = -1;
/*  48:    */   
/*  49:    */   public CharEscaperBuilder()
/*  50:    */   {
/*  51: 82 */     this.map = new HashMap();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public CharEscaperBuilder addEscape(char c, String r)
/*  55:    */   {
/*  56: 89 */     this.map.put(Character.valueOf(c), Preconditions.checkNotNull(r));
/*  57: 90 */     if (c > this.max) {
/*  58: 91 */       this.max = c;
/*  59:    */     }
/*  60: 93 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public CharEscaperBuilder addEscapes(char[] cs, String r)
/*  64:    */   {
/*  65:100 */     Preconditions.checkNotNull(r);
/*  66:101 */     for (char c : cs) {
/*  67:102 */       addEscape(c, r);
/*  68:    */     }
/*  69:104 */     return this;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public char[][] toArray()
/*  73:    */   {
/*  74:115 */     char[][] result = new char[this.max + 1][];
/*  75:116 */     for (Map.Entry<Character, String> entry : this.map.entrySet()) {
/*  76:117 */       result[((Character)entry.getKey()).charValue()] = ((String)entry.getValue()).toCharArray();
/*  77:    */     }
/*  78:119 */     return result;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Escaper toEscaper()
/*  82:    */   {
/*  83:129 */     return new CharArrayDecorator(toArray());
/*  84:    */   }
/*  85:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.escape.CharEscaperBuilder
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Map;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public abstract class ArrayBasedUnicodeEscaper
/*  12:    */   extends UnicodeEscaper
/*  13:    */ {
/*  14:    */   private final char[][] replacements;
/*  15:    */   private final int replacementsLength;
/*  16:    */   private final int safeMin;
/*  17:    */   private final int safeMax;
/*  18:    */   private final char safeMinChar;
/*  19:    */   private final char safeMaxChar;
/*  20:    */   
/*  21:    */   protected ArrayBasedUnicodeEscaper(Map<Character, String> replacementMap, int safeMin, int safeMax, @Nullable String unsafeReplacement)
/*  22:    */   {
/*  23: 83 */     this(ArrayBasedEscaperMap.create(replacementMap), safeMin, safeMax, unsafeReplacement);
/*  24:    */   }
/*  25:    */   
/*  26:    */   protected ArrayBasedUnicodeEscaper(ArrayBasedEscaperMap escaperMap, int safeMin, int safeMax, @Nullable String unsafeReplacement)
/*  27:    */   {
/*  28:107 */     Preconditions.checkNotNull(escaperMap);
/*  29:108 */     this.replacements = escaperMap.getReplacementArray();
/*  30:109 */     this.replacementsLength = this.replacements.length;
/*  31:110 */     if (safeMax < safeMin)
/*  32:    */     {
/*  33:113 */       safeMax = -1;
/*  34:114 */       safeMin = 2147483647;
/*  35:    */     }
/*  36:116 */     this.safeMin = safeMin;
/*  37:117 */     this.safeMax = safeMax;
/*  38:132 */     if (safeMin >= 55296)
/*  39:    */     {
/*  40:135 */       this.safeMinChar = 65535;
/*  41:136 */       this.safeMaxChar = '\000';
/*  42:    */     }
/*  43:    */     else
/*  44:    */     {
/*  45:140 */       this.safeMinChar = ((char)safeMin);
/*  46:141 */       this.safeMaxChar = ((char)Math.min(safeMax, 55295));
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public final String escape(String s)
/*  51:    */   {
/*  52:153 */     Preconditions.checkNotNull(s);
/*  53:154 */     for (int i = 0; i < s.length(); i++)
/*  54:    */     {
/*  55:155 */       char c = s.charAt(i);
/*  56:156 */       if (((c < this.replacementsLength) && (this.replacements[c] != null)) || (c > this.safeMaxChar) || (c < this.safeMinChar)) {
/*  57:158 */         return escapeSlow(s, i);
/*  58:    */       }
/*  59:    */     }
/*  60:161 */     return s;
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected final int nextEscapeIndex(CharSequence csq, int index, int end)
/*  64:    */   {
/*  65:167 */     while (index < end)
/*  66:    */     {
/*  67:168 */       char c = csq.charAt(index);
/*  68:169 */       if (((c < this.replacementsLength) && (this.replacements[c] != null)) || (c > this.safeMaxChar) || (c < this.safeMinChar)) {
/*  69:    */         break;
/*  70:    */       }
/*  71:173 */       index++;
/*  72:    */     }
/*  73:175 */     return index;
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected final char[] escape(int cp)
/*  77:    */   {
/*  78:185 */     if (cp < this.replacementsLength)
/*  79:    */     {
/*  80:186 */       char[] chars = this.replacements[cp];
/*  81:187 */       if (chars != null) {
/*  82:188 */         return chars;
/*  83:    */       }
/*  84:    */     }
/*  85:191 */     if ((cp >= this.safeMin) && (cp <= this.safeMax)) {
/*  86:192 */       return null;
/*  87:    */     }
/*  88:194 */     return escapeUnsafe(cp);
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected abstract char[] escapeUnsafe(int paramInt);
/*  92:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.escape.ArrayBasedUnicodeEscaper
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Objects.ToStringHelper;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Splitter;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.ImmutableMap;
/*  11:    */ import com.google.common.collect.ImmutableMap.Builder;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.concurrent.TimeUnit;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @Beta
/*  17:    */ public final class CacheBuilderSpec
/*  18:    */ {
/*  19: 89 */   private static final Splitter KEYS_SPLITTER = Splitter.on(',').trimResults();
/*  20: 92 */   private static final Splitter KEY_VALUE_SPLITTER = Splitter.on('=').trimResults();
/*  21: 95 */   private static final ImmutableMap<String, ValueParser> VALUE_PARSERS = ImmutableMap.builder().put("initialCapacity", new InitialCapacityParser()).put("maximumSize", new MaximumSizeParser()).put("maximumWeight", new MaximumWeightParser()).put("concurrencyLevel", new ConcurrencyLevelParser()).put("weakKeys", new KeyStrengthParser(LocalCache.Strength.WEAK)).put("softValues", new ValueStrengthParser(LocalCache.Strength.SOFT)).put("weakValues", new ValueStrengthParser(LocalCache.Strength.WEAK)).put("recordStats", new RecordStatsParser()).put("expireAfterAccess", new AccessDurationParser()).put("expireAfterWrite", new WriteDurationParser()).put("refreshAfterWrite", new RefreshDurationParser()).put("refreshInterval", new RefreshDurationParser()).build();
/*  22:    */   @VisibleForTesting
/*  23:    */   Integer initialCapacity;
/*  24:    */   @VisibleForTesting
/*  25:    */   Long maximumSize;
/*  26:    */   @VisibleForTesting
/*  27:    */   Long maximumWeight;
/*  28:    */   @VisibleForTesting
/*  29:    */   Integer concurrencyLevel;
/*  30:    */   @VisibleForTesting
/*  31:    */   LocalCache.Strength keyStrength;
/*  32:    */   @VisibleForTesting
/*  33:    */   LocalCache.Strength valueStrength;
/*  34:    */   @VisibleForTesting
/*  35:    */   Boolean recordStats;
/*  36:    */   @VisibleForTesting
/*  37:    */   long writeExpirationDuration;
/*  38:    */   @VisibleForTesting
/*  39:    */   TimeUnit writeExpirationTimeUnit;
/*  40:    */   @VisibleForTesting
/*  41:    */   long accessExpirationDuration;
/*  42:    */   @VisibleForTesting
/*  43:    */   TimeUnit accessExpirationTimeUnit;
/*  44:    */   @VisibleForTesting
/*  45:    */   long refreshDuration;
/*  46:    */   @VisibleForTesting
/*  47:    */   TimeUnit refreshTimeUnit;
/*  48:    */   private final String specification;
/*  49:    */   
/*  50:    */   private CacheBuilderSpec(String specification)
/*  51:    */   {
/*  52:128 */     this.specification = specification;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static CacheBuilderSpec parse(String cacheBuilderSpecification)
/*  56:    */   {
/*  57:137 */     CacheBuilderSpec spec = new CacheBuilderSpec(cacheBuilderSpecification);
/*  58:138 */     if (!cacheBuilderSpecification.isEmpty()) {
/*  59:139 */       for (String keyValuePair : KEYS_SPLITTER.split(cacheBuilderSpecification))
/*  60:    */       {
/*  61:140 */         List<String> keyAndValue = ImmutableList.copyOf(KEY_VALUE_SPLITTER.split(keyValuePair));
/*  62:141 */         Preconditions.checkArgument(!keyAndValue.isEmpty(), "blank key-value pair");
/*  63:142 */         Preconditions.checkArgument(keyAndValue.size() <= 2, "key-value pair %s with more than one equals sign", new Object[] { keyValuePair });
/*  64:    */         
/*  65:    */ 
/*  66:    */ 
/*  67:146 */         String key = (String)keyAndValue.get(0);
/*  68:147 */         ValueParser valueParser = (ValueParser)VALUE_PARSERS.get(key);
/*  69:148 */         Preconditions.checkArgument(valueParser != null, "unknown key %s", new Object[] { key });
/*  70:    */         
/*  71:150 */         String value = keyAndValue.size() == 1 ? null : (String)keyAndValue.get(1);
/*  72:151 */         valueParser.parse(spec, key, value);
/*  73:    */       }
/*  74:    */     }
/*  75:155 */     return spec;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static CacheBuilderSpec disableCaching()
/*  79:    */   {
/*  80:163 */     return parse("maximumSize=0");
/*  81:    */   }
/*  82:    */   
/*  83:    */   CacheBuilder<Object, Object> toCacheBuilder()
/*  84:    */   {
/*  85:170 */     CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();
/*  86:171 */     if (this.initialCapacity != null) {
/*  87:172 */       builder.initialCapacity(this.initialCapacity.intValue());
/*  88:    */     }
/*  89:174 */     if (this.maximumSize != null) {
/*  90:175 */       builder.maximumSize(this.maximumSize.longValue());
/*  91:    */     }
/*  92:177 */     if (this.maximumWeight != null) {
/*  93:178 */       builder.maximumWeight(this.maximumWeight.longValue());
/*  94:    */     }
/*  95:180 */     if (this.concurrencyLevel != null) {
/*  96:181 */       builder.concurrencyLevel(this.concurrencyLevel.intValue());
/*  97:    */     }
/*  98:183 */     if (this.keyStrength != null) {
/*  99:184 */       switch (1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.keyStrength.ordinal()])
/* 100:    */       {
/* 101:    */       case 1: 
/* 102:186 */         builder.weakKeys();
/* 103:187 */         break;
/* 104:    */       default: 
/* 105:189 */         throw new AssertionError();
/* 106:    */       }
/* 107:    */     }
/* 108:192 */     if (this.valueStrength != null) {
/* 109:193 */       switch (1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.valueStrength.ordinal()])
/* 110:    */       {
/* 111:    */       case 2: 
/* 112:195 */         builder.softValues();
/* 113:196 */         break;
/* 114:    */       case 1: 
/* 115:198 */         builder.weakValues();
/* 116:199 */         break;
/* 117:    */       default: 
/* 118:201 */         throw new AssertionError();
/* 119:    */       }
/* 120:    */     }
/* 121:204 */     if ((this.recordStats != null) && (this.recordStats.booleanValue())) {
/* 122:205 */       builder.recordStats();
/* 123:    */     }
/* 124:207 */     if (this.writeExpirationTimeUnit != null) {
/* 125:208 */       builder.expireAfterWrite(this.writeExpirationDuration, this.writeExpirationTimeUnit);
/* 126:    */     }
/* 127:210 */     if (this.accessExpirationTimeUnit != null) {
/* 128:211 */       builder.expireAfterAccess(this.accessExpirationDuration, this.accessExpirationTimeUnit);
/* 129:    */     }
/* 130:213 */     if (this.refreshTimeUnit != null) {
/* 131:214 */       builder.refreshAfterWrite(this.refreshDuration, this.refreshTimeUnit);
/* 132:    */     }
/* 133:217 */     return builder;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public String toParsableString()
/* 137:    */   {
/* 138:227 */     return this.specification;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public String toString()
/* 142:    */   {
/* 143:236 */     return Objects.toStringHelper(this).addValue(toParsableString()).toString();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public int hashCode()
/* 147:    */   {
/* 148:241 */     return Objects.hashCode(new Object[] { this.initialCapacity, this.maximumSize, this.maximumWeight, this.concurrencyLevel, this.keyStrength, this.valueStrength, this.recordStats, durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit), durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit), durationInNanos(this.refreshDuration, this.refreshTimeUnit) });
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean equals(@Nullable Object obj)
/* 152:    */   {
/* 153:256 */     if (this == obj) {
/* 154:257 */       return true;
/* 155:    */     }
/* 156:259 */     if (!(obj instanceof CacheBuilderSpec)) {
/* 157:260 */       return false;
/* 158:    */     }
/* 159:262 */     CacheBuilderSpec that = (CacheBuilderSpec)obj;
/* 160:263 */     return (Objects.equal(this.initialCapacity, that.initialCapacity)) && (Objects.equal(this.maximumSize, that.maximumSize)) && (Objects.equal(this.maximumWeight, that.maximumWeight)) && (Objects.equal(this.concurrencyLevel, that.concurrencyLevel)) && (Objects.equal(this.keyStrength, that.keyStrength)) && (Objects.equal(this.valueStrength, that.valueStrength)) && (Objects.equal(this.recordStats, that.recordStats)) && (Objects.equal(durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit), durationInNanos(that.writeExpirationDuration, that.writeExpirationTimeUnit))) && (Objects.equal(durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit), durationInNanos(that.accessExpirationDuration, that.accessExpirationTimeUnit))) && (Objects.equal(durationInNanos(this.refreshDuration, this.refreshTimeUnit), durationInNanos(that.refreshDuration, that.refreshTimeUnit)));
/* 161:    */   }
/* 162:    */   
/* 163:    */   @Nullable
/* 164:    */   private static Long durationInNanos(long duration, @Nullable TimeUnit unit)
/* 165:    */   {
/* 166:283 */     return unit == null ? null : Long.valueOf(unit.toNanos(duration));
/* 167:    */   }
/* 168:    */   
/* 169:    */   static abstract class IntegerParser
/* 170:    */     implements CacheBuilderSpec.ValueParser
/* 171:    */   {
/* 172:    */     protected abstract void parseInteger(CacheBuilderSpec paramCacheBuilderSpec, int paramInt);
/* 173:    */     
/* 174:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 175:    */     {
/* 176:292 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 177:    */       try
/* 178:    */       {
/* 179:294 */         parseInteger(spec, Integer.parseInt(value));
/* 180:    */       }
/* 181:    */       catch (NumberFormatException e)
/* 182:    */       {
/* 183:296 */         throw new IllegalArgumentException(String.format("key %s value set to %s, must be integer", new Object[] { key, value }), e);
/* 184:    */       }
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   static abstract class LongParser
/* 189:    */     implements CacheBuilderSpec.ValueParser
/* 190:    */   {
/* 191:    */     protected abstract void parseLong(CacheBuilderSpec paramCacheBuilderSpec, long paramLong);
/* 192:    */     
/* 193:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 194:    */     {
/* 195:308 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 196:    */       try
/* 197:    */       {
/* 198:310 */         parseLong(spec, Long.parseLong(value));
/* 199:    */       }
/* 200:    */       catch (NumberFormatException e)
/* 201:    */       {
/* 202:312 */         throw new IllegalArgumentException(String.format("key %s value set to %s, must be integer", new Object[] { key, value }), e);
/* 203:    */       }
/* 204:    */     }
/* 205:    */   }
/* 206:    */   
/* 207:    */   static class InitialCapacityParser
/* 208:    */     extends CacheBuilderSpec.IntegerParser
/* 209:    */   {
/* 210:    */     protected void parseInteger(CacheBuilderSpec spec, int value)
/* 211:    */     {
/* 212:322 */       Preconditions.checkArgument(spec.initialCapacity == null, "initial capacity was already set to ", new Object[] { spec.initialCapacity });
/* 213:    */       
/* 214:324 */       spec.initialCapacity = Integer.valueOf(value);
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   static class MaximumSizeParser
/* 219:    */     extends CacheBuilderSpec.LongParser
/* 220:    */   {
/* 221:    */     protected void parseLong(CacheBuilderSpec spec, long value)
/* 222:    */     {
/* 223:332 */       Preconditions.checkArgument(spec.maximumSize == null, "maximum size was already set to ", new Object[] { spec.maximumSize });
/* 224:    */       
/* 225:334 */       Preconditions.checkArgument(spec.maximumWeight == null, "maximum weight was already set to ", new Object[] { spec.maximumWeight });
/* 226:    */       
/* 227:336 */       spec.maximumSize = Long.valueOf(value);
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   static class MaximumWeightParser
/* 232:    */     extends CacheBuilderSpec.LongParser
/* 233:    */   {
/* 234:    */     protected void parseLong(CacheBuilderSpec spec, long value)
/* 235:    */     {
/* 236:344 */       Preconditions.checkArgument(spec.maximumWeight == null, "maximum weight was already set to ", new Object[] { spec.maximumWeight });
/* 237:    */       
/* 238:346 */       Preconditions.checkArgument(spec.maximumSize == null, "maximum size was already set to ", new Object[] { spec.maximumSize });
/* 239:    */       
/* 240:348 */       spec.maximumWeight = Long.valueOf(value);
/* 241:    */     }
/* 242:    */   }
/* 243:    */   
/* 244:    */   static class ConcurrencyLevelParser
/* 245:    */     extends CacheBuilderSpec.IntegerParser
/* 246:    */   {
/* 247:    */     protected void parseInteger(CacheBuilderSpec spec, int value)
/* 248:    */     {
/* 249:356 */       Preconditions.checkArgument(spec.concurrencyLevel == null, "concurrency level was already set to ", new Object[] { spec.concurrencyLevel });
/* 250:    */       
/* 251:358 */       spec.concurrencyLevel = Integer.valueOf(value);
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   static class KeyStrengthParser
/* 256:    */     implements CacheBuilderSpec.ValueParser
/* 257:    */   {
/* 258:    */     private final LocalCache.Strength strength;
/* 259:    */     
/* 260:    */     public KeyStrengthParser(LocalCache.Strength strength)
/* 261:    */     {
/* 262:367 */       this.strength = strength;
/* 263:    */     }
/* 264:    */     
/* 265:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 266:    */     {
/* 267:372 */       Preconditions.checkArgument(value == null, "key %s does not take values", new Object[] { key });
/* 268:373 */       Preconditions.checkArgument(spec.keyStrength == null, "%s was already set to %s", new Object[] { key, spec.keyStrength });
/* 269:374 */       spec.keyStrength = this.strength;
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   static class ValueStrengthParser
/* 274:    */     implements CacheBuilderSpec.ValueParser
/* 275:    */   {
/* 276:    */     private final LocalCache.Strength strength;
/* 277:    */     
/* 278:    */     public ValueStrengthParser(LocalCache.Strength strength)
/* 279:    */     {
/* 280:383 */       this.strength = strength;
/* 281:    */     }
/* 282:    */     
/* 283:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 284:    */     {
/* 285:388 */       Preconditions.checkArgument(value == null, "key %s does not take values", new Object[] { key });
/* 286:389 */       Preconditions.checkArgument(spec.valueStrength == null, "%s was already set to %s", new Object[] { key, spec.valueStrength });
/* 287:    */       
/* 288:    */ 
/* 289:392 */       spec.valueStrength = this.strength;
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   static class RecordStatsParser
/* 294:    */     implements CacheBuilderSpec.ValueParser
/* 295:    */   {
/* 296:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 297:    */     {
/* 298:401 */       Preconditions.checkArgument(value == null, "recordStats does not take values");
/* 299:402 */       Preconditions.checkArgument(spec.recordStats == null, "recordStats already set");
/* 300:403 */       spec.recordStats = Boolean.valueOf(true);
/* 301:    */     }
/* 302:    */   }
/* 303:    */   
/* 304:    */   static abstract class DurationParser
/* 305:    */     implements CacheBuilderSpec.ValueParser
/* 306:    */   {
/* 307:    */     protected abstract void parseDuration(CacheBuilderSpec paramCacheBuilderSpec, long paramLong, TimeUnit paramTimeUnit);
/* 308:    */     
/* 309:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 310:    */     {
/* 311:416 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 312:    */       try
/* 313:    */       {
/* 314:418 */         char lastChar = value.charAt(value.length() - 1);
/* 315:    */         TimeUnit timeUnit;
/* 316:420 */         switch (lastChar)
/* 317:    */         {
/* 318:    */         case 'd': 
/* 319:422 */           timeUnit = TimeUnit.DAYS;
/* 320:423 */           break;
/* 321:    */         case 'h': 
/* 322:425 */           timeUnit = TimeUnit.HOURS;
/* 323:426 */           break;
/* 324:    */         case 'm': 
/* 325:428 */           timeUnit = TimeUnit.MINUTES;
/* 326:429 */           break;
/* 327:    */         case 's': 
/* 328:431 */           timeUnit = TimeUnit.SECONDS;
/* 329:432 */           break;
/* 330:    */         default: 
/* 331:434 */           throw new IllegalArgumentException(String.format("key %s invalid format.  was %s, must end with one of [dDhHmMsS]", new Object[] { key, value }));
/* 332:    */         }
/* 333:439 */         long duration = Long.parseLong(value.substring(0, value.length() - 1));
/* 334:440 */         parseDuration(spec, duration, timeUnit);
/* 335:    */       }
/* 336:    */       catch (NumberFormatException e)
/* 337:    */       {
/* 338:442 */         throw new IllegalArgumentException(String.format("key %s value set to %s, must be integer", new Object[] { key, value }));
/* 339:    */       }
/* 340:    */     }
/* 341:    */   }
/* 342:    */   
/* 343:    */   static class AccessDurationParser
/* 344:    */     extends CacheBuilderSpec.DurationParser
/* 345:    */   {
/* 346:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 347:    */     {
/* 348:451 */       Preconditions.checkArgument(spec.accessExpirationTimeUnit == null, "expireAfterAccess already set");
/* 349:452 */       spec.accessExpirationDuration = duration;
/* 350:453 */       spec.accessExpirationTimeUnit = unit;
/* 351:    */     }
/* 352:    */   }
/* 353:    */   
/* 354:    */   static class WriteDurationParser
/* 355:    */     extends CacheBuilderSpec.DurationParser
/* 356:    */   {
/* 357:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 358:    */     {
/* 359:460 */       Preconditions.checkArgument(spec.writeExpirationTimeUnit == null, "expireAfterWrite already set");
/* 360:461 */       spec.writeExpirationDuration = duration;
/* 361:462 */       spec.writeExpirationTimeUnit = unit;
/* 362:    */     }
/* 363:    */   }
/* 364:    */   
/* 365:    */   static class RefreshDurationParser
/* 366:    */     extends CacheBuilderSpec.DurationParser
/* 367:    */   {
/* 368:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 369:    */     {
/* 370:469 */       Preconditions.checkArgument(spec.refreshTimeUnit == null, "refreshAfterWrite already set");
/* 371:470 */       spec.refreshDuration = duration;
/* 372:471 */       spec.refreshTimeUnit = unit;
/* 373:    */     }
/* 374:    */   }
/* 375:    */   
/* 376:    */   private static abstract interface ValueParser
/* 377:    */   {
/* 378:    */     public abstract void parse(CacheBuilderSpec paramCacheBuilderSpec, String paramString1, @Nullable String paramString2);
/* 379:    */   }
/* 380:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.CacheBuilderSpec
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.collect.ImmutableMap;
/*  5:   */ import com.google.common.collect.Maps;
/*  6:   */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*  7:   */ import java.util.Map;
/*  8:   */ import java.util.concurrent.ExecutionException;
/*  9:   */ 
/* 10:   */ @Beta
/* 11:   */ public abstract class AbstractLoadingCache<K, V>
/* 12:   */   extends AbstractCache<K, V>
/* 13:   */   implements LoadingCache<K, V>
/* 14:   */ {
/* 15:   */   public V getUnchecked(K key)
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:53 */       return get(key);
/* 20:   */     }
/* 21:   */     catch (ExecutionException e)
/* 22:   */     {
/* 23:55 */       throw new UncheckedExecutionException(e.getCause());
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 28:   */     throws ExecutionException
/* 29:   */   {
/* 30:61 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 31:62 */     for (K key : keys) {
/* 32:63 */       if (!result.containsKey(key)) {
/* 33:64 */         result.put(key, get(key));
/* 34:   */       }
/* 35:   */     }
/* 36:67 */     return ImmutableMap.copyOf(result);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public final V apply(K key)
/* 40:   */   {
/* 41:72 */     return getUnchecked(key);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void refresh(K key)
/* 45:   */   {
/* 46:77 */     throw new UnsupportedOperationException();
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.AbstractLoadingCache
 * JD-Core Version:    0.7.0.1
 */
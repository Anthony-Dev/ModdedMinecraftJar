/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.security.AccessController;
/*   5:    */ import java.security.PrivilegedActionException;
/*   6:    */ import java.security.PrivilegedExceptionAction;
/*   7:    */ import java.util.Random;
/*   8:    */ import sun.misc.Unsafe;
/*   9:    */ 
/*  10:    */ abstract class Striped64
/*  11:    */   extends Number
/*  12:    */ {
/*  13:    */   static final class Cell
/*  14:    */   {
/*  15:    */     volatile long p0;
/*  16:    */     volatile long p1;
/*  17:    */     volatile long p2;
/*  18:    */     volatile long p3;
/*  19:    */     volatile long p4;
/*  20:    */     volatile long p5;
/*  21:    */     volatile long p6;
/*  22:    */     volatile long value;
/*  23:    */     volatile long q0;
/*  24:    */     volatile long q1;
/*  25:    */     volatile long q2;
/*  26:    */     volatile long q3;
/*  27:    */     volatile long q4;
/*  28:    */     volatile long q5;
/*  29:    */     volatile long q6;
/*  30:    */     private static final Unsafe UNSAFE;
/*  31:    */     private static final long valueOffset;
/*  32:    */     
/*  33:    */     Cell(long x)
/*  34:    */     {
/*  35: 97 */       this.value = x;
/*  36:    */     }
/*  37:    */     
/*  38:    */     final boolean cas(long cmp, long val)
/*  39:    */     {
/*  40:100 */       return UNSAFE.compareAndSwapLong(this, valueOffset, cmp, val);
/*  41:    */     }
/*  42:    */     
/*  43:    */     static
/*  44:    */     {
/*  45:    */       try
/*  46:    */       {
/*  47:108 */         UNSAFE = Striped64.access$000();
/*  48:109 */         Class<?> ak = Cell.class;
/*  49:110 */         valueOffset = UNSAFE.objectFieldOffset(ak.getDeclaredField("value"));
/*  50:    */       }
/*  51:    */       catch (Exception e)
/*  52:    */       {
/*  53:113 */         throw new Error(e);
/*  54:    */       }
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   static final class HashCode
/*  59:    */   {
/*  60:124 */     static final Random rng = new Random();
/*  61:    */     int code;
/*  62:    */     
/*  63:    */     HashCode()
/*  64:    */     {
/*  65:127 */       int h = rng.nextInt();
/*  66:128 */       this.code = (h == 0 ? 1 : h);
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   static final class ThreadHashCode
/*  71:    */     extends ThreadLocal<Striped64.HashCode>
/*  72:    */   {
/*  73:    */     public Striped64.HashCode initialValue()
/*  74:    */     {
/*  75:136 */       return new Striped64.HashCode();
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:145 */   static final ThreadHashCode threadHashCode = new ThreadHashCode();
/*  80:148 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*  81:    */   volatile transient Cell[] cells;
/*  82:    */   volatile transient long base;
/*  83:    */   volatile transient int busy;
/*  84:    */   private static final Unsafe UNSAFE;
/*  85:    */   private static final long baseOffset;
/*  86:    */   private static final long busyOffset;
/*  87:    */   
/*  88:    */   final boolean casBase(long cmp, long val)
/*  89:    */   {
/*  90:176 */     return UNSAFE.compareAndSwapLong(this, baseOffset, cmp, val);
/*  91:    */   }
/*  92:    */   
/*  93:    */   final boolean casBusy()
/*  94:    */   {
/*  95:183 */     return UNSAFE.compareAndSwapInt(this, busyOffset, 0, 1);
/*  96:    */   }
/*  97:    */   
/*  98:    */   final void retryUpdate(long x, HashCode hc, boolean wasUncontended)
/*  99:    */   {
/* 100:209 */     int h = hc.code;
/* 101:210 */     boolean collide = false;
/* 102:    */     for (;;)
/* 103:    */     {
/* 104:    */       Cell[] as;
/* 105:    */       int n;
/* 106:213 */       if (((as = this.cells) != null) && ((n = as.length) > 0))
/* 107:    */       {
/* 108:    */         Cell a;
/* 109:214 */         if ((a = as[(n - 1 & h)]) == null)
/* 110:    */         {
/* 111:215 */           if (this.busy == 0)
/* 112:    */           {
/* 113:216 */             Cell r = new Cell(x);
/* 114:217 */             if ((this.busy == 0) && (casBusy()))
/* 115:    */             {
/* 116:218 */               boolean created = false;
/* 117:    */               try
/* 118:    */               {
/* 119:    */                 Cell[] rs;
/* 120:    */                 int m;
/* 121:    */                 int j;
/* 122:221 */                 if (((rs = this.cells) != null) && ((m = rs.length) > 0) && (rs[(j = m - 1 & h)] == null))
/* 123:    */                 {
/* 124:224 */                   rs[j] = r;
/* 125:225 */                   created = true;
/* 126:    */                 }
/* 127:    */               }
/* 128:    */               finally
/* 129:    */               {
/* 130:228 */                 this.busy = 0;
/* 131:    */               }
/* 132:230 */               if (!created) {
/* 133:    */                 continue;
/* 134:    */               }
/* 135:231 */               break;
/* 136:    */             }
/* 137:    */           }
/* 138:235 */           collide = false;
/* 139:    */         }
/* 140:237 */         else if (!wasUncontended)
/* 141:    */         {
/* 142:238 */           wasUncontended = true;
/* 143:    */         }
/* 144:    */         else
/* 145:    */         {
/* 146:    */           long v;
/* 147:239 */           if (a.cas(v = a.value, fn(v, x))) {
/* 148:    */             break;
/* 149:    */           }
/* 150:241 */           if ((n >= NCPU) || (this.cells != as))
/* 151:    */           {
/* 152:242 */             collide = false;
/* 153:    */           }
/* 154:243 */           else if (!collide)
/* 155:    */           {
/* 156:244 */             collide = true;
/* 157:    */           }
/* 158:245 */           else if ((this.busy == 0) && (casBusy()))
/* 159:    */           {
/* 160:    */             try
/* 161:    */             {
/* 162:247 */               if (this.cells == as)
/* 163:    */               {
/* 164:248 */                 Cell[] rs = new Cell[n << 1];
/* 165:249 */                 for (int i = 0; i < n; i++) {
/* 166:250 */                   rs[i] = as[i];
/* 167:    */                 }
/* 168:251 */                 this.cells = rs;
/* 169:    */               }
/* 170:    */             }
/* 171:    */             finally
/* 172:    */             {
/* 173:254 */               this.busy = 0;
/* 174:    */             }
/* 175:256 */             collide = false;
/* 176:257 */             continue;
/* 177:    */           }
/* 178:    */         }
/* 179:259 */         h ^= h << 13;
/* 180:260 */         h ^= h >>> 17;
/* 181:261 */         h ^= h << 5;
/* 182:    */       }
/* 183:263 */       else if ((this.busy == 0) && (this.cells == as) && (casBusy()))
/* 184:    */       {
/* 185:264 */         boolean init = false;
/* 186:    */         try
/* 187:    */         {
/* 188:266 */           if (this.cells == as)
/* 189:    */           {
/* 190:267 */             Cell[] rs = new Cell[2];
/* 191:268 */             rs[(h & 0x1)] = new Cell(x);
/* 192:269 */             this.cells = rs;
/* 193:270 */             init = true;
/* 194:    */           }
/* 195:    */         }
/* 196:    */         finally
/* 197:    */         {
/* 198:273 */           this.busy = 0;
/* 199:    */         }
/* 200:275 */         if (init) {
/* 201:    */           break;
/* 202:    */         }
/* 203:    */       }
/* 204:    */       else
/* 205:    */       {
/* 206:    */         long v;
/* 207:278 */         if (casBase(v = this.base, fn(v, x))) {
/* 208:    */           break;
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:281 */     hc.code = h;
/* 213:    */   }
/* 214:    */   
/* 215:    */   final void internalReset(long initialValue)
/* 216:    */   {
/* 217:288 */     Cell[] as = this.cells;
/* 218:289 */     this.base = initialValue;
/* 219:290 */     if (as != null)
/* 220:    */     {
/* 221:291 */       int n = as.length;
/* 222:292 */       for (int i = 0; i < n; i++)
/* 223:    */       {
/* 224:293 */         Cell a = as[i];
/* 225:294 */         if (a != null) {
/* 226:295 */           a.value = initialValue;
/* 227:    */         }
/* 228:    */       }
/* 229:    */     }
/* 230:    */   }
/* 231:    */   
/* 232:    */   static
/* 233:    */   {
/* 234:    */     try
/* 235:    */     {
/* 236:306 */       UNSAFE = getUnsafe();
/* 237:307 */       Class<?> sk = Striped64.class;
/* 238:308 */       baseOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("base"));
/* 239:    */       
/* 240:310 */       busyOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("busy"));
/* 241:    */     }
/* 242:    */     catch (Exception e)
/* 243:    */     {
/* 244:313 */       throw new Error(e);
/* 245:    */     }
/* 246:    */   }
/* 247:    */   
/* 248:    */   private static Unsafe getUnsafe()
/* 249:    */   {
/* 250:    */     try
/* 251:    */     {
/* 252:326 */       return Unsafe.getUnsafe();
/* 253:    */     }
/* 254:    */     catch (SecurityException tryReflectionInstead)
/* 255:    */     {
/* 256:    */       try
/* 257:    */       {
/* 258:329 */         (Unsafe)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 259:    */         {
/* 260:    */           public Unsafe run()
/* 261:    */             throws Exception
/* 262:    */           {
/* 263:332 */             Class<Unsafe> k = Unsafe.class;
/* 264:333 */             for (Field f : k.getDeclaredFields())
/* 265:    */             {
/* 266:334 */               f.setAccessible(true);
/* 267:335 */               Object x = f.get(null);
/* 268:336 */               if (k.isInstance(x)) {
/* 269:337 */                 return (Unsafe)k.cast(x);
/* 270:    */               }
/* 271:    */             }
/* 272:339 */             throw new NoSuchFieldError("the Unsafe");
/* 273:    */           }
/* 274:    */         });
/* 275:    */       }
/* 276:    */       catch (PrivilegedActionException e)
/* 277:    */       {
/* 278:342 */         throw new RuntimeException("Could not initialize intrinsics", e.getCause());
/* 279:    */       }
/* 280:    */     }
/* 281:    */   }
/* 282:    */   
/* 283:    */   abstract long fn(long paramLong1, long paramLong2);
/* 284:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.Striped64
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.ObjectInputStream;
/*   6:    */ import java.io.ObjectOutputStream;
/*   7:    */ import java.io.Serializable;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ final class LongAdder
/*  11:    */   extends Striped64
/*  12:    */   implements Serializable, LongAddable
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 7249069246863182397L;
/*  15:    */   
/*  16:    */   final long fn(long v, long x)
/*  17:    */   {
/*  18: 56 */     return v + x;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void add(long x)
/*  22:    */   {
/*  23:    */     Striped64.Cell[] as;
/*  24:    */     long b;
/*  25: 71 */     if (((as = this.cells) != null) || (!casBase(b = this.base, b + x)))
/*  26:    */     {
/*  27: 72 */       boolean uncontended = true;
/*  28:    */       Striped64.HashCode hc;
/*  29: 73 */       int h = (hc = (Striped64.HashCode)threadHashCode.get()).code;
/*  30:    */       int n;
/*  31:    */       Striped64.Cell a;
/*  32:    */       long v;
/*  33: 74 */       if ((as == null) || ((n = as.length) < 1) || ((a = as[(n - 1 & h)]) == null) || (!(uncontended = a.cas(v = a.value, v + x)))) {
/*  34: 77 */         retryUpdate(x, hc, uncontended);
/*  35:    */       }
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void increment()
/*  40:    */   {
/*  41: 85 */     add(1L);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void decrement()
/*  45:    */   {
/*  46: 92 */     add(-1L);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public long sum()
/*  50:    */   {
/*  51:105 */     long sum = this.base;
/*  52:106 */     Striped64.Cell[] as = this.cells;
/*  53:107 */     if (as != null)
/*  54:    */     {
/*  55:108 */       int n = as.length;
/*  56:109 */       for (int i = 0; i < n; i++)
/*  57:    */       {
/*  58:110 */         Striped64.Cell a = as[i];
/*  59:111 */         if (a != null) {
/*  60:112 */           sum += a.value;
/*  61:    */         }
/*  62:    */       }
/*  63:    */     }
/*  64:115 */     return sum;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void reset()
/*  68:    */   {
/*  69:126 */     internalReset(0L);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public long sumThenReset()
/*  73:    */   {
/*  74:140 */     long sum = this.base;
/*  75:141 */     Striped64.Cell[] as = this.cells;
/*  76:142 */     this.base = 0L;
/*  77:143 */     if (as != null)
/*  78:    */     {
/*  79:144 */       int n = as.length;
/*  80:145 */       for (int i = 0; i < n; i++)
/*  81:    */       {
/*  82:146 */         Striped64.Cell a = as[i];
/*  83:147 */         if (a != null)
/*  84:    */         {
/*  85:148 */           sum += a.value;
/*  86:149 */           a.value = 0L;
/*  87:    */         }
/*  88:    */       }
/*  89:    */     }
/*  90:153 */     return sum;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String toString()
/*  94:    */   {
/*  95:161 */     return Long.toString(sum());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public long longValue()
/*  99:    */   {
/* 100:170 */     return sum();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public int intValue()
/* 104:    */   {
/* 105:178 */     return (int)sum();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public float floatValue()
/* 109:    */   {
/* 110:186 */     return (float)sum();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public double doubleValue()
/* 114:    */   {
/* 115:194 */     return sum();
/* 116:    */   }
/* 117:    */   
/* 118:    */   private void writeObject(ObjectOutputStream s)
/* 119:    */     throws IOException
/* 120:    */   {
/* 121:199 */     s.defaultWriteObject();
/* 122:200 */     s.writeLong(sum());
/* 123:    */   }
/* 124:    */   
/* 125:    */   private void readObject(ObjectInputStream s)
/* 126:    */     throws IOException, ClassNotFoundException
/* 127:    */   {
/* 128:205 */     s.defaultReadObject();
/* 129:206 */     this.busy = 0;
/* 130:207 */     this.cells = null;
/* 131:208 */     this.base = s.readLong();
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.LongAdder
 * JD-Core Version:    0.7.0.1
 */
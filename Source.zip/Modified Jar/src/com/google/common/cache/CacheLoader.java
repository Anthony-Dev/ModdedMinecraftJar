/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Function;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Supplier;
/*   9:    */ import com.google.common.util.concurrent.Futures;
/*  10:    */ import com.google.common.util.concurrent.ListenableFuture;
/*  11:    */ import com.google.common.util.concurrent.ListenableFutureTask;
/*  12:    */ import java.io.Serializable;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.concurrent.Callable;
/*  15:    */ import java.util.concurrent.Executor;
/*  16:    */ 
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ public abstract class CacheLoader<K, V>
/*  19:    */ {
/*  20:    */   public abstract V load(K paramK)
/*  21:    */     throws Exception;
/*  22:    */   
/*  23:    */   @GwtIncompatible("Futures")
/*  24:    */   public ListenableFuture<V> reload(K key, V oldValue)
/*  25:    */     throws Exception
/*  26:    */   {
/*  27: 95 */     Preconditions.checkNotNull(key);
/*  28: 96 */     Preconditions.checkNotNull(oldValue);
/*  29: 97 */     return Futures.immediateFuture(load(key));
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Map<K, V> loadAll(Iterable<? extends K> keys)
/*  33:    */     throws Exception
/*  34:    */   {
/*  35:125 */     throw new UnsupportedLoadingOperationException();
/*  36:    */   }
/*  37:    */   
/*  38:    */   @Beta
/*  39:    */   public static <K, V> CacheLoader<K, V> from(Function<K, V> function)
/*  40:    */   {
/*  41:138 */     return new FunctionToCacheLoader(function);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static final class FunctionToCacheLoader<K, V>
/*  45:    */     extends CacheLoader<K, V>
/*  46:    */     implements Serializable
/*  47:    */   {
/*  48:    */     private final Function<K, V> computingFunction;
/*  49:    */     private static final long serialVersionUID = 0L;
/*  50:    */     
/*  51:    */     public FunctionToCacheLoader(Function<K, V> computingFunction)
/*  52:    */     {
/*  53:146 */       this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/*  54:    */     }
/*  55:    */     
/*  56:    */     public V load(K key)
/*  57:    */     {
/*  58:151 */       return this.computingFunction.apply(Preconditions.checkNotNull(key));
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   @Beta
/*  63:    */   public static <V> CacheLoader<Object, V> from(Supplier<V> supplier)
/*  64:    */   {
/*  65:168 */     return new SupplierToCacheLoader(supplier);
/*  66:    */   }
/*  67:    */   
/*  68:    */   @Beta
/*  69:    */   @GwtIncompatible("Executor + Futures")
/*  70:    */   public static <K, V> CacheLoader<K, V> asyncReloading(CacheLoader<K, V> loader, final Executor executor)
/*  71:    */   {
/*  72:184 */     Preconditions.checkNotNull(loader);
/*  73:185 */     Preconditions.checkNotNull(executor);
/*  74:186 */     new CacheLoader()
/*  75:    */     {
/*  76:    */       public V load(K key)
/*  77:    */         throws Exception
/*  78:    */       {
/*  79:189 */         return this.val$loader.load(key);
/*  80:    */       }
/*  81:    */       
/*  82:    */       public ListenableFuture<V> reload(final K key, final V oldValue)
/*  83:    */         throws Exception
/*  84:    */       {
/*  85:194 */         ListenableFutureTask<V> task = ListenableFutureTask.create(new Callable()
/*  86:    */         {
/*  87:    */           public V call()
/*  88:    */             throws Exception
/*  89:    */           {
/*  90:197 */             return CacheLoader.1.this.val$loader.reload(key, oldValue).get();
/*  91:    */           }
/*  92:199 */         });
/*  93:200 */         executor.execute(task);
/*  94:201 */         return task;
/*  95:    */       }
/*  96:    */       
/*  97:    */       public Map<K, V> loadAll(Iterable<? extends K> keys)
/*  98:    */         throws Exception
/*  99:    */       {
/* 100:206 */         return this.val$loader.loadAll(keys);
/* 101:    */       }
/* 102:    */     };
/* 103:    */   }
/* 104:    */   
/* 105:    */   private static final class SupplierToCacheLoader<V>
/* 106:    */     extends CacheLoader<Object, V>
/* 107:    */     implements Serializable
/* 108:    */   {
/* 109:    */     private final Supplier<V> computingSupplier;
/* 110:    */     private static final long serialVersionUID = 0L;
/* 111:    */     
/* 112:    */     public SupplierToCacheLoader(Supplier<V> computingSupplier)
/* 113:    */     {
/* 114:216 */       this.computingSupplier = ((Supplier)Preconditions.checkNotNull(computingSupplier));
/* 115:    */     }
/* 116:    */     
/* 117:    */     public V load(Object key)
/* 118:    */     {
/* 119:221 */       Preconditions.checkNotNull(key);
/* 120:222 */       return this.computingSupplier.get();
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static final class InvalidCacheLoadException
/* 125:    */     extends RuntimeException
/* 126:    */   {
/* 127:    */     public InvalidCacheLoadException(String message)
/* 128:    */     {
/* 129:237 */       super();
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   static final class UnsupportedLoadingOperationException
/* 134:    */     extends UnsupportedOperationException
/* 135:    */   {}
/* 136:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.CacheLoader
 * JD-Core Version:    0.7.0.1
 */
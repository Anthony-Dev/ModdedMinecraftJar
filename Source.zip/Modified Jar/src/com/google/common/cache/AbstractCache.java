/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.collect.ImmutableMap;
/*   6:    */ import com.google.common.collect.Maps;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.concurrent.Callable;
/*  10:    */ import java.util.concurrent.ConcurrentMap;
/*  11:    */ import java.util.concurrent.ExecutionException;
/*  12:    */ 
/*  13:    */ @Beta
/*  14:    */ @GwtCompatible
/*  15:    */ public abstract class AbstractCache<K, V>
/*  16:    */   implements Cache<K, V>
/*  17:    */ {
/*  18:    */   public V get(K key, Callable<? extends V> valueLoader)
/*  19:    */     throws ExecutionException
/*  20:    */   {
/*  21: 55 */     throw new UnsupportedOperationException();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/*  25:    */   {
/*  26: 69 */     Map<K, V> result = Maps.newLinkedHashMap();
/*  27: 70 */     for (Object key : keys) {
/*  28: 71 */       if (!result.containsKey(key))
/*  29:    */       {
/*  30: 73 */         K castKey = key;
/*  31: 74 */         result.put(castKey, getIfPresent(key));
/*  32:    */       }
/*  33:    */     }
/*  34: 77 */     return ImmutableMap.copyOf(result);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void put(K key, V value)
/*  38:    */   {
/*  39: 85 */     throw new UnsupportedOperationException();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void putAll(Map<? extends K, ? extends V> m)
/*  43:    */   {
/*  44: 93 */     for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
/*  45: 94 */       put(entry.getKey(), entry.getValue());
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void cleanUp() {}
/*  50:    */   
/*  51:    */   public long size()
/*  52:    */   {
/*  53:103 */     throw new UnsupportedOperationException();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void invalidate(Object key)
/*  57:    */   {
/*  58:108 */     throw new UnsupportedOperationException();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void invalidateAll(Iterable<?> keys)
/*  62:    */   {
/*  63:116 */     for (Object key : keys) {
/*  64:117 */       invalidate(key);
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void invalidateAll()
/*  69:    */   {
/*  70:123 */     throw new UnsupportedOperationException();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public CacheStats stats()
/*  74:    */   {
/*  75:128 */     throw new UnsupportedOperationException();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public ConcurrentMap<K, V> asMap()
/*  79:    */   {
/*  80:133 */     throw new UnsupportedOperationException();
/*  81:    */   }
/*  82:    */   
/*  83:    */   @Beta
/*  84:    */   public static final class SimpleStatsCounter
/*  85:    */     implements AbstractCache.StatsCounter
/*  86:    */   {
/*  87:206 */     private final LongAddable hitCount = LongAddables.create();
/*  88:207 */     private final LongAddable missCount = LongAddables.create();
/*  89:208 */     private final LongAddable loadSuccessCount = LongAddables.create();
/*  90:209 */     private final LongAddable loadExceptionCount = LongAddables.create();
/*  91:210 */     private final LongAddable totalLoadTime = LongAddables.create();
/*  92:211 */     private final LongAddable evictionCount = LongAddables.create();
/*  93:    */     
/*  94:    */     public void recordHits(int count)
/*  95:    */     {
/*  96:223 */       this.hitCount.add(count);
/*  97:    */     }
/*  98:    */     
/*  99:    */     public void recordMisses(int count)
/* 100:    */     {
/* 101:231 */       this.missCount.add(count);
/* 102:    */     }
/* 103:    */     
/* 104:    */     public void recordLoadSuccess(long loadTime)
/* 105:    */     {
/* 106:236 */       this.loadSuccessCount.increment();
/* 107:237 */       this.totalLoadTime.add(loadTime);
/* 108:    */     }
/* 109:    */     
/* 110:    */     public void recordLoadException(long loadTime)
/* 111:    */     {
/* 112:242 */       this.loadExceptionCount.increment();
/* 113:243 */       this.totalLoadTime.add(loadTime);
/* 114:    */     }
/* 115:    */     
/* 116:    */     public void recordEviction()
/* 117:    */     {
/* 118:248 */       this.evictionCount.increment();
/* 119:    */     }
/* 120:    */     
/* 121:    */     public CacheStats snapshot()
/* 122:    */     {
/* 123:253 */       return new CacheStats(this.hitCount.sum(), this.missCount.sum(), this.loadSuccessCount.sum(), this.loadExceptionCount.sum(), this.totalLoadTime.sum(), this.evictionCount.sum());
/* 124:    */     }
/* 125:    */     
/* 126:    */     public void incrementBy(AbstractCache.StatsCounter other)
/* 127:    */     {
/* 128:266 */       CacheStats otherStats = other.snapshot();
/* 129:267 */       this.hitCount.add(otherStats.hitCount());
/* 130:268 */       this.missCount.add(otherStats.missCount());
/* 131:269 */       this.loadSuccessCount.add(otherStats.loadSuccessCount());
/* 132:270 */       this.loadExceptionCount.add(otherStats.loadExceptionCount());
/* 133:271 */       this.totalLoadTime.add(otherStats.totalLoadTime());
/* 134:272 */       this.evictionCount.add(otherStats.evictionCount());
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   @Beta
/* 139:    */   public static abstract interface StatsCounter
/* 140:    */   {
/* 141:    */     public abstract void recordHits(int paramInt);
/* 142:    */     
/* 143:    */     public abstract void recordMisses(int paramInt);
/* 144:    */     
/* 145:    */     public abstract void recordLoadSuccess(long paramLong);
/* 146:    */     
/* 147:    */     public abstract void recordLoadException(long paramLong);
/* 148:    */     
/* 149:    */     public abstract void recordEviction();
/* 150:    */     
/* 151:    */     public abstract CacheStats snapshot();
/* 152:    */   }
/* 153:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.AbstractCache
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.net.InetAddress;
/*   6:    */ import java.text.ParseException;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public final class HostSpecifier
/*  11:    */ {
/*  12:    */   private final String canonicalForm;
/*  13:    */   
/*  14:    */   private HostSpecifier(String canonicalForm)
/*  15:    */   {
/*  16: 57 */     this.canonicalForm = canonicalForm;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public static HostSpecifier fromValid(String specifier)
/*  20:    */   {
/*  21: 78 */     HostAndPort parsedHost = HostAndPort.fromString(specifier);
/*  22: 79 */     Preconditions.checkArgument(!parsedHost.hasPort());
/*  23: 80 */     String host = parsedHost.getHostText();
/*  24:    */     
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29: 86 */     InetAddress addr = null;
/*  30:    */     try
/*  31:    */     {
/*  32: 88 */       addr = InetAddresses.forString(host);
/*  33:    */     }
/*  34:    */     catch (IllegalArgumentException e) {}
/*  35: 93 */     if (addr != null) {
/*  36: 94 */       return new HostSpecifier(InetAddresses.toUriString(addr));
/*  37:    */     }
/*  38:100 */     InternetDomainName domain = InternetDomainName.from(host);
/*  39:102 */     if (domain.hasPublicSuffix()) {
/*  40:103 */       return new HostSpecifier(domain.toString());
/*  41:    */     }
/*  42:106 */     throw new IllegalArgumentException("Domain name does not have a recognized public suffix: " + host);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static HostSpecifier from(String specifier)
/*  46:    */     throws ParseException
/*  47:    */   {
/*  48:    */     try
/*  49:    */     {
/*  50:121 */       return fromValid(specifier);
/*  51:    */     }
/*  52:    */     catch (IllegalArgumentException e)
/*  53:    */     {
/*  54:127 */       ParseException parseException = new ParseException("Invalid host specifier: " + specifier, 0);
/*  55:    */       
/*  56:129 */       parseException.initCause(e);
/*  57:130 */       throw parseException;
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static boolean isValid(String specifier)
/*  62:    */   {
/*  63:    */     try
/*  64:    */     {
/*  65:141 */       fromValid(specifier);
/*  66:142 */       return true;
/*  67:    */     }
/*  68:    */     catch (IllegalArgumentException e) {}
/*  69:144 */     return false;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean equals(@Nullable Object other)
/*  73:    */   {
/*  74:150 */     if (this == other) {
/*  75:151 */       return true;
/*  76:    */     }
/*  77:154 */     if ((other instanceof HostSpecifier))
/*  78:    */     {
/*  79:155 */       HostSpecifier that = (HostSpecifier)other;
/*  80:156 */       return this.canonicalForm.equals(that.canonicalForm);
/*  81:    */     }
/*  82:159 */     return false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public int hashCode()
/*  86:    */   {
/*  87:164 */     return this.canonicalForm.hashCode();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String toString()
/*  91:    */   {
/*  92:176 */     return this.canonicalForm;
/*  93:    */   }
/*  94:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.net.HostSpecifier
 * JD-Core Version:    0.7.0.1
 */
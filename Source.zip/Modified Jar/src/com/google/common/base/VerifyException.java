/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @Beta
/*  8:   */ @GwtCompatible
/*  9:   */ public class VerifyException
/* 10:   */   extends RuntimeException
/* 11:   */ {
/* 12:   */   public VerifyException() {}
/* 13:   */   
/* 14:   */   public VerifyException(@Nullable String message)
/* 15:   */   {
/* 16:37 */     super(message);
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.VerifyException
 * JD-Core Version:    0.7.0.1
 */
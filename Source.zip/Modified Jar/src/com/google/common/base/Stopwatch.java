/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ public final class Stopwatch
/*  11:    */ {
/*  12:    */   private final Ticker ticker;
/*  13:    */   private boolean isRunning;
/*  14:    */   private long elapsedNanos;
/*  15:    */   private long startTick;
/*  16:    */   
/*  17:    */   public static Stopwatch createUnstarted()
/*  18:    */   {
/*  19: 89 */     return new Stopwatch();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static Stopwatch createUnstarted(Ticker ticker)
/*  23:    */   {
/*  24: 99 */     return new Stopwatch(ticker);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static Stopwatch createStarted()
/*  28:    */   {
/*  29:109 */     return new Stopwatch().start();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static Stopwatch createStarted(Ticker ticker)
/*  33:    */   {
/*  34:119 */     return new Stopwatch(ticker).start();
/*  35:    */   }
/*  36:    */   
/*  37:    */   @Deprecated
/*  38:    */   Stopwatch()
/*  39:    */   {
/*  40:130 */     this(Ticker.systemTicker());
/*  41:    */   }
/*  42:    */   
/*  43:    */   @Deprecated
/*  44:    */   Stopwatch(Ticker ticker)
/*  45:    */   {
/*  46:141 */     this.ticker = ((Ticker)Preconditions.checkNotNull(ticker, "ticker"));
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isRunning()
/*  50:    */   {
/*  51:150 */     return this.isRunning;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Stopwatch start()
/*  55:    */   {
/*  56:160 */     Preconditions.checkState(!this.isRunning, "This stopwatch is already running.");
/*  57:161 */     this.isRunning = true;
/*  58:162 */     this.startTick = this.ticker.read();
/*  59:163 */     return this;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Stopwatch stop()
/*  63:    */   {
/*  64:174 */     long tick = this.ticker.read();
/*  65:175 */     Preconditions.checkState(this.isRunning, "This stopwatch is already stopped.");
/*  66:176 */     this.isRunning = false;
/*  67:177 */     this.elapsedNanos += tick - this.startTick;
/*  68:178 */     return this;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Stopwatch reset()
/*  72:    */   {
/*  73:188 */     this.elapsedNanos = 0L;
/*  74:189 */     this.isRunning = false;
/*  75:190 */     return this;
/*  76:    */   }
/*  77:    */   
/*  78:    */   private long elapsedNanos()
/*  79:    */   {
/*  80:194 */     return this.isRunning ? this.ticker.read() - this.startTick + this.elapsedNanos : this.elapsedNanos;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public long elapsed(TimeUnit desiredUnit)
/*  84:    */   {
/*  85:208 */     return desiredUnit.convert(elapsedNanos(), TimeUnit.NANOSECONDS);
/*  86:    */   }
/*  87:    */   
/*  88:    */   @GwtIncompatible("String.format()")
/*  89:    */   public String toString()
/*  90:    */   {
/*  91:216 */     long nanos = elapsedNanos();
/*  92:    */     
/*  93:218 */     TimeUnit unit = chooseUnit(nanos);
/*  94:219 */     double value = nanos / TimeUnit.NANOSECONDS.convert(1L, unit);
/*  95:    */     
/*  96:    */ 
/*  97:222 */     return String.format("%.4g %s", new Object[] { Double.valueOf(value), abbreviate(unit) });
/*  98:    */   }
/*  99:    */   
/* 100:    */   private static TimeUnit chooseUnit(long nanos)
/* 101:    */   {
/* 102:226 */     if (TimeUnit.DAYS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 103:227 */       return TimeUnit.DAYS;
/* 104:    */     }
/* 105:229 */     if (TimeUnit.HOURS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 106:230 */       return TimeUnit.HOURS;
/* 107:    */     }
/* 108:232 */     if (TimeUnit.MINUTES.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 109:233 */       return TimeUnit.MINUTES;
/* 110:    */     }
/* 111:235 */     if (TimeUnit.SECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 112:236 */       return TimeUnit.SECONDS;
/* 113:    */     }
/* 114:238 */     if (TimeUnit.MILLISECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 115:239 */       return TimeUnit.MILLISECONDS;
/* 116:    */     }
/* 117:241 */     if (TimeUnit.MICROSECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 118:242 */       return TimeUnit.MICROSECONDS;
/* 119:    */     }
/* 120:244 */     return TimeUnit.NANOSECONDS;
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static String abbreviate(TimeUnit unit)
/* 124:    */   {
/* 125:248 */     switch (1.$SwitchMap$java$util$concurrent$TimeUnit[unit.ordinal()])
/* 126:    */     {
/* 127:    */     case 1: 
/* 128:250 */       return "ns";
/* 129:    */     case 2: 
/* 130:252 */       return "μs";
/* 131:    */     case 3: 
/* 132:254 */       return "ms";
/* 133:    */     case 4: 
/* 134:256 */       return "s";
/* 135:    */     case 5: 
/* 136:258 */       return "min";
/* 137:    */     case 6: 
/* 138:260 */       return "h";
/* 139:    */     case 7: 
/* 140:262 */       return "d";
/* 141:    */     }
/* 142:264 */     throw new AssertionError();
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Stopwatch
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ public abstract class Optional<T>
/*  12:    */   implements Serializable
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 0L;
/*  15:    */   
/*  16:    */   public static <T> Optional<T> absent()
/*  17:    */   {
/*  18: 78 */     return Absent.withType();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static <T> Optional<T> of(T reference)
/*  22:    */   {
/*  23: 85 */     return new Present(Preconditions.checkNotNull(reference));
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static <T> Optional<T> fromNullable(@Nullable T nullableReference)
/*  27:    */   {
/*  28: 93 */     return nullableReference == null ? absent() : new Present(nullableReference);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public abstract boolean isPresent();
/*  32:    */   
/*  33:    */   public abstract T get();
/*  34:    */   
/*  35:    */   public abstract T or(T paramT);
/*  36:    */   
/*  37:    */   public abstract Optional<T> or(Optional<? extends T> paramOptional);
/*  38:    */   
/*  39:    */   @Beta
/*  40:    */   public abstract T or(Supplier<? extends T> paramSupplier);
/*  41:    */   
/*  42:    */   @Nullable
/*  43:    */   public abstract T orNull();
/*  44:    */   
/*  45:    */   public abstract Set<T> asSet();
/*  46:    */   
/*  47:    */   public abstract <V> Optional<V> transform(Function<? super T, V> paramFunction);
/*  48:    */   
/*  49:    */   public abstract boolean equals(@Nullable Object paramObject);
/*  50:    */   
/*  51:    */   public abstract int hashCode();
/*  52:    */   
/*  53:    */   public abstract String toString();
/*  54:    */   
/*  55:    */   @Beta
/*  56:    */   public static <T> Iterable<T> presentInstances(Iterable<? extends Optional<? extends T>> optionals)
/*  57:    */   {
/*  58:218 */     Preconditions.checkNotNull(optionals);
/*  59:219 */     new Iterable()
/*  60:    */     {
/*  61:    */       public Iterator<T> iterator()
/*  62:    */       {
/*  63:222 */         new AbstractIterator()
/*  64:    */         {
/*  65:223 */           private final Iterator<? extends Optional<? extends T>> iterator = (Iterator)Preconditions.checkNotNull(Optional.1.this.val$optionals.iterator());
/*  66:    */           
/*  67:    */           protected T computeNext()
/*  68:    */           {
/*  69:228 */             while (this.iterator.hasNext())
/*  70:    */             {
/*  71:229 */               Optional<? extends T> optional = (Optional)this.iterator.next();
/*  72:230 */               if (optional.isPresent()) {
/*  73:231 */                 return optional.get();
/*  74:    */               }
/*  75:    */             }
/*  76:234 */             return endOfData();
/*  77:    */           }
/*  78:    */         };
/*  79:    */       }
/*  80:    */     };
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Optional
 * JD-Core Version:    0.7.0.1
 */
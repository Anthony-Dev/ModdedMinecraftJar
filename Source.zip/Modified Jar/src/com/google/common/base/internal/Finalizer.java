/*   1:    */ package com.google.common.base.internal;
/*   2:    */ 
/*   3:    */ import java.lang.ref.PhantomReference;
/*   4:    */ import java.lang.ref.Reference;
/*   5:    */ import java.lang.ref.ReferenceQueue;
/*   6:    */ import java.lang.ref.WeakReference;
/*   7:    */ import java.lang.reflect.Field;
/*   8:    */ import java.lang.reflect.Method;
/*   9:    */ import java.util.logging.Level;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ 
/*  12:    */ public class Finalizer
/*  13:    */   implements Runnable
/*  14:    */ {
/*  15: 51 */   private static final Logger logger = Logger.getLogger(Finalizer.class.getName());
/*  16:    */   private static final String FINALIZABLE_REFERENCE = "com.google.common.base.FinalizableReference";
/*  17:    */   private final WeakReference<Class<?>> finalizableReferenceClassReference;
/*  18:    */   private final PhantomReference<Object> frqReference;
/*  19:    */   private final ReferenceQueue<Object> queue;
/*  20:    */   
/*  21:    */   public static void startFinalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*  22:    */   {
/*  23: 80 */     if (!finalizableReferenceClass.getName().equals("com.google.common.base.FinalizableReference")) {
/*  24: 81 */       throw new IllegalArgumentException("Expected com.google.common.base.FinalizableReference.");
/*  25:    */     }
/*  26: 85 */     Finalizer finalizer = new Finalizer(finalizableReferenceClass, queue, frqReference);
/*  27: 86 */     Thread thread = new Thread(finalizer);
/*  28: 87 */     thread.setName(Finalizer.class.getName());
/*  29: 88 */     thread.setDaemon(true);
/*  30:    */     try
/*  31:    */     {
/*  32: 91 */       if (inheritableThreadLocals != null) {
/*  33: 92 */         inheritableThreadLocals.set(thread, null);
/*  34:    */       }
/*  35:    */     }
/*  36:    */     catch (Throwable t)
/*  37:    */     {
/*  38: 95 */       logger.log(Level.INFO, "Failed to clear thread local values inherited by reference finalizer thread.", t);
/*  39:    */     }
/*  40: 99 */     thread.start();
/*  41:    */   }
/*  42:    */   
/*  43:106 */   private static final Field inheritableThreadLocals = getInheritableThreadLocalsField();
/*  44:    */   
/*  45:    */   private Finalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*  46:    */   {
/*  47:114 */     this.queue = queue;
/*  48:    */     
/*  49:116 */     this.finalizableReferenceClassReference = new WeakReference(finalizableReferenceClass);
/*  50:    */     
/*  51:    */ 
/*  52:    */ 
/*  53:120 */     this.frqReference = frqReference;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void run()
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60:131 */       while (cleanUp(this.queue.remove())) {}
/*  61:    */     }
/*  62:    */     catch (InterruptedException e) {}
/*  63:    */   }
/*  64:    */   
/*  65:    */   private boolean cleanUp(Reference<?> reference)
/*  66:    */   {
/*  67:144 */     Method finalizeReferentMethod = getFinalizeReferentMethod();
/*  68:145 */     if (finalizeReferentMethod == null) {
/*  69:146 */       return false;
/*  70:    */     }
/*  71:    */     do
/*  72:    */     {
/*  73:153 */       reference.clear();
/*  74:155 */       if (reference == this.frqReference) {
/*  75:160 */         return false;
/*  76:    */       }
/*  77:    */       try
/*  78:    */       {
/*  79:164 */         finalizeReferentMethod.invoke(reference, new Object[0]);
/*  80:    */       }
/*  81:    */       catch (Throwable t)
/*  82:    */       {
/*  83:166 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*  84:    */       }
/*  85:173 */     } while ((reference = this.queue.poll()) != null);
/*  86:174 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   private Method getFinalizeReferentMethod()
/*  90:    */   {
/*  91:181 */     Class<?> finalizableReferenceClass = (Class)this.finalizableReferenceClassReference.get();
/*  92:183 */     if (finalizableReferenceClass == null) {
/*  93:192 */       return null;
/*  94:    */     }
/*  95:    */     try
/*  96:    */     {
/*  97:195 */       return finalizableReferenceClass.getMethod("finalizeReferent", new Class[0]);
/*  98:    */     }
/*  99:    */     catch (NoSuchMethodException e)
/* 100:    */     {
/* 101:197 */       throw new AssertionError(e);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static Field getInheritableThreadLocalsField()
/* 106:    */   {
/* 107:    */     try
/* 108:    */     {
/* 109:203 */       Field inheritableThreadLocals = Thread.class.getDeclaredField("inheritableThreadLocals");
/* 110:    */       
/* 111:205 */       inheritableThreadLocals.setAccessible(true);
/* 112:206 */       return inheritableThreadLocals;
/* 113:    */     }
/* 114:    */     catch (Throwable t)
/* 115:    */     {
/* 116:208 */       logger.log(Level.INFO, "Couldn't access Thread.inheritableThreadLocals. Reference finalizer threads will inherit thread local values.");
/* 117:    */     }
/* 118:211 */     return null;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.internal.Finalizer
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public enum CaseFormat
/*  10:    */ {
/*  11: 40 */   LOWER_HYPHEN(CharMatcher.is('-'), "-"),  LOWER_UNDERSCORE(CharMatcher.is('_'), "_"),  LOWER_CAMEL(CharMatcher.inRange('A', 'Z'), ""),  UPPER_CAMEL(CharMatcher.inRange('A', 'Z'), ""),  UPPER_UNDERSCORE(CharMatcher.is('_'), "_");
/*  12:    */   
/*  13:    */   private final CharMatcher wordBoundary;
/*  14:    */   private final String wordSeparator;
/*  15:    */   
/*  16:    */   private CaseFormat(CharMatcher wordBoundary, String wordSeparator)
/*  17:    */   {
/*  18:113 */     this.wordBoundary = wordBoundary;
/*  19:114 */     this.wordSeparator = wordSeparator;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public final String to(CaseFormat format, String str)
/*  23:    */   {
/*  24:123 */     Preconditions.checkNotNull(format);
/*  25:124 */     Preconditions.checkNotNull(str);
/*  26:125 */     return format == this ? str : convert(format, str);
/*  27:    */   }
/*  28:    */   
/*  29:    */   String convert(CaseFormat format, String s)
/*  30:    */   {
/*  31:133 */     StringBuilder out = null;
/*  32:134 */     int i = 0;
/*  33:135 */     int j = -1;
/*  34:136 */     while ((j = this.wordBoundary.indexIn(s, ++j)) != -1)
/*  35:    */     {
/*  36:137 */       if (i == 0)
/*  37:    */       {
/*  38:139 */         out = new StringBuilder(s.length() + 4 * this.wordSeparator.length());
/*  39:140 */         out.append(format.normalizeFirstWord(s.substring(i, j)));
/*  40:    */       }
/*  41:    */       else
/*  42:    */       {
/*  43:142 */         out.append(format.normalizeWord(s.substring(i, j)));
/*  44:    */       }
/*  45:144 */       out.append(format.wordSeparator);
/*  46:145 */       i = j + this.wordSeparator.length();
/*  47:    */     }
/*  48:147 */     return format.normalizeWord(s.substring(i));
/*  49:    */   }
/*  50:    */   
/*  51:    */   @Beta
/*  52:    */   public Converter<String, String> converterTo(CaseFormat targetFormat)
/*  53:    */   {
/*  54:159 */     return new StringConverter(this, targetFormat);
/*  55:    */   }
/*  56:    */   
/*  57:    */   abstract String normalizeWord(String paramString);
/*  58:    */   
/*  59:    */   private static final class StringConverter
/*  60:    */     extends Converter<String, String>
/*  61:    */     implements Serializable
/*  62:    */   {
/*  63:    */     private final CaseFormat sourceFormat;
/*  64:    */     private final CaseFormat targetFormat;
/*  65:    */     private static final long serialVersionUID = 0L;
/*  66:    */     
/*  67:    */     StringConverter(CaseFormat sourceFormat, CaseFormat targetFormat)
/*  68:    */     {
/*  69:169 */       this.sourceFormat = ((CaseFormat)Preconditions.checkNotNull(sourceFormat));
/*  70:170 */       this.targetFormat = ((CaseFormat)Preconditions.checkNotNull(targetFormat));
/*  71:    */     }
/*  72:    */     
/*  73:    */     protected String doForward(String s)
/*  74:    */     {
/*  75:175 */       return s == null ? null : this.sourceFormat.to(this.targetFormat, s);
/*  76:    */     }
/*  77:    */     
/*  78:    */     protected String doBackward(String s)
/*  79:    */     {
/*  80:180 */       return s == null ? null : this.targetFormat.to(this.sourceFormat, s);
/*  81:    */     }
/*  82:    */     
/*  83:    */     public boolean equals(@Nullable Object object)
/*  84:    */     {
/*  85:184 */       if ((object instanceof StringConverter))
/*  86:    */       {
/*  87:185 */         StringConverter that = (StringConverter)object;
/*  88:186 */         return (this.sourceFormat.equals(that.sourceFormat)) && (this.targetFormat.equals(that.targetFormat));
/*  89:    */       }
/*  90:189 */       return false;
/*  91:    */     }
/*  92:    */     
/*  93:    */     public int hashCode()
/*  94:    */     {
/*  95:193 */       return this.sourceFormat.hashCode() ^ this.targetFormat.hashCode();
/*  96:    */     }
/*  97:    */     
/*  98:    */     public String toString()
/*  99:    */     {
/* 100:197 */       return this.sourceFormat + ".converterTo(" + this.targetFormat + ")";
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   private String normalizeFirstWord(String word)
/* 105:    */   {
/* 106:206 */     return this == LOWER_CAMEL ? Ascii.toLowerCase(word) : normalizeWord(word);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static String firstCharOnlyToUpper(String word)
/* 110:    */   {
/* 111:210 */     return word.length() + Ascii.toUpperCase(word.charAt(0)) + Ascii.toLowerCase(word.substring(1));
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.CaseFormat
 * JD-Core Version:    0.7.0.1
 */
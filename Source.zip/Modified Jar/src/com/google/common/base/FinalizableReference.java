package com.google.common.base;

public abstract interface FinalizableReference
{
  public abstract void finalizeReferent();
}


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.FinalizableReference
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.io;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Joiner;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Predicate;
/*    7:     */ import com.google.common.base.Splitter;
/*    8:     */ import com.google.common.collect.ImmutableSet;
/*    9:     */ import com.google.common.collect.Lists;
/*   10:     */ import com.google.common.collect.TreeTraverser;
/*   11:     */ import com.google.common.hash.HashCode;
/*   12:     */ import com.google.common.hash.HashFunction;
/*   13:     */ import java.io.BufferedReader;
/*   14:     */ import java.io.BufferedWriter;
/*   15:     */ import java.io.Closeable;
/*   16:     */ import java.io.File;
/*   17:     */ import java.io.FileInputStream;
/*   18:     */ import java.io.FileNotFoundException;
/*   19:     */ import java.io.FileOutputStream;
/*   20:     */ import java.io.IOException;
/*   21:     */ import java.io.InputStream;
/*   22:     */ import java.io.InputStreamReader;
/*   23:     */ import java.io.OutputStream;
/*   24:     */ import java.io.OutputStreamWriter;
/*   25:     */ import java.io.RandomAccessFile;
/*   26:     */ import java.nio.MappedByteBuffer;
/*   27:     */ import java.nio.channels.FileChannel;
/*   28:     */ import java.nio.channels.FileChannel.MapMode;
/*   29:     */ import java.nio.charset.Charset;
/*   30:     */ import java.util.ArrayList;
/*   31:     */ import java.util.Arrays;
/*   32:     */ import java.util.Collections;
/*   33:     */ import java.util.List;
/*   34:     */ 
/*   35:     */ @Beta
/*   36:     */ public final class Files
/*   37:     */ {
/*   38:     */   private static final int TEMP_DIR_ATTEMPTS = 10000;
/*   39:     */   
/*   40:     */   public static BufferedReader newReader(File file, Charset charset)
/*   41:     */     throws FileNotFoundException
/*   42:     */   {
/*   43:  84 */     Preconditions.checkNotNull(file);
/*   44:  85 */     Preconditions.checkNotNull(charset);
/*   45:  86 */     return new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
/*   46:     */   }
/*   47:     */   
/*   48:     */   public static BufferedWriter newWriter(File file, Charset charset)
/*   49:     */     throws FileNotFoundException
/*   50:     */   {
/*   51: 101 */     Preconditions.checkNotNull(file);
/*   52: 102 */     Preconditions.checkNotNull(charset);
/*   53: 103 */     return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), charset));
/*   54:     */   }
/*   55:     */   
/*   56:     */   public static ByteSource asByteSource(File file)
/*   57:     */   {
/*   58: 113 */     return new FileByteSource(file, null);
/*   59:     */   }
/*   60:     */   
/*   61:     */   private static final class FileByteSource
/*   62:     */     extends ByteSource
/*   63:     */   {
/*   64:     */     private final File file;
/*   65:     */     
/*   66:     */     private FileByteSource(File file)
/*   67:     */     {
/*   68: 121 */       this.file = ((File)Preconditions.checkNotNull(file));
/*   69:     */     }
/*   70:     */     
/*   71:     */     public FileInputStream openStream()
/*   72:     */       throws IOException
/*   73:     */     {
/*   74: 126 */       return new FileInputStream(this.file);
/*   75:     */     }
/*   76:     */     
/*   77:     */     public long size()
/*   78:     */       throws IOException
/*   79:     */     {
/*   80: 131 */       if (!this.file.isFile()) {
/*   81: 132 */         throw new FileNotFoundException(this.file.toString());
/*   82:     */       }
/*   83: 134 */       return this.file.length();
/*   84:     */     }
/*   85:     */     
/*   86:     */     public byte[] read()
/*   87:     */       throws IOException
/*   88:     */     {
/*   89: 139 */       Closer closer = Closer.create();
/*   90:     */       try
/*   91:     */       {
/*   92: 141 */         FileInputStream in = (FileInputStream)closer.register(openStream());
/*   93: 142 */         return Files.readFile(in, in.getChannel().size());
/*   94:     */       }
/*   95:     */       catch (Throwable e)
/*   96:     */       {
/*   97: 144 */         throw closer.rethrow(e);
/*   98:     */       }
/*   99:     */       finally
/*  100:     */       {
/*  101: 146 */         closer.close();
/*  102:     */       }
/*  103:     */     }
/*  104:     */     
/*  105:     */     public String toString()
/*  106:     */     {
/*  107: 152 */       return "Files.asByteSource(" + this.file + ")";
/*  108:     */     }
/*  109:     */   }
/*  110:     */   
/*  111:     */   static byte[] readFile(InputStream in, long expectedSize)
/*  112:     */     throws IOException
/*  113:     */   {
/*  114: 164 */     if (expectedSize > 2147483647L) {
/*  115: 165 */       throw new OutOfMemoryError("file is too large to fit in a byte array: " + expectedSize + " bytes");
/*  116:     */     }
/*  117: 171 */     return expectedSize == 0L ? ByteStreams.toByteArray(in) : ByteStreams.toByteArray(in, (int)expectedSize);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static ByteSink asByteSink(File file, FileWriteMode... modes)
/*  121:     */   {
/*  122: 186 */     return new FileByteSink(file, modes, null);
/*  123:     */   }
/*  124:     */   
/*  125:     */   private static final class FileByteSink
/*  126:     */     extends ByteSink
/*  127:     */   {
/*  128:     */     private final File file;
/*  129:     */     private final ImmutableSet<FileWriteMode> modes;
/*  130:     */     
/*  131:     */     private FileByteSink(File file, FileWriteMode... modes)
/*  132:     */     {
/*  133: 195 */       this.file = ((File)Preconditions.checkNotNull(file));
/*  134: 196 */       this.modes = ImmutableSet.copyOf(modes);
/*  135:     */     }
/*  136:     */     
/*  137:     */     public FileOutputStream openStream()
/*  138:     */       throws IOException
/*  139:     */     {
/*  140: 201 */       return new FileOutputStream(this.file, this.modes.contains(FileWriteMode.APPEND));
/*  141:     */     }
/*  142:     */     
/*  143:     */     public String toString()
/*  144:     */     {
/*  145: 206 */       return "Files.asByteSink(" + this.file + ", " + this.modes + ")";
/*  146:     */     }
/*  147:     */   }
/*  148:     */   
/*  149:     */   public static CharSource asCharSource(File file, Charset charset)
/*  150:     */   {
/*  151: 217 */     return asByteSource(file).asCharSource(charset);
/*  152:     */   }
/*  153:     */   
/*  154:     */   public static CharSink asCharSink(File file, Charset charset, FileWriteMode... modes)
/*  155:     */   {
/*  156: 232 */     return asByteSink(file, modes).asCharSink(charset);
/*  157:     */   }
/*  158:     */   
/*  159:     */   @Deprecated
/*  160:     */   public static InputSupplier<FileInputStream> newInputStreamSupplier(File file)
/*  161:     */   {
/*  162: 247 */     return ByteStreams.asInputSupplier(asByteSource(file));
/*  163:     */   }
/*  164:     */   
/*  165:     */   @Deprecated
/*  166:     */   public static OutputSupplier<FileOutputStream> newOutputStreamSupplier(File file)
/*  167:     */   {
/*  168: 262 */     return newOutputStreamSupplier(file, false);
/*  169:     */   }
/*  170:     */   
/*  171:     */   @Deprecated
/*  172:     */   public static OutputSupplier<FileOutputStream> newOutputStreamSupplier(File file, boolean append)
/*  173:     */   {
/*  174: 280 */     return ByteStreams.asOutputSupplier(asByteSink(file, modes(append)));
/*  175:     */   }
/*  176:     */   
/*  177:     */   private static FileWriteMode[] modes(boolean append)
/*  178:     */   {
/*  179: 284 */     return append ? new FileWriteMode[] { FileWriteMode.APPEND } : new FileWriteMode[0];
/*  180:     */   }
/*  181:     */   
/*  182:     */   @Deprecated
/*  183:     */   public static InputSupplier<InputStreamReader> newReaderSupplier(File file, Charset charset)
/*  184:     */   {
/*  185: 303 */     return CharStreams.asInputSupplier(asCharSource(file, charset));
/*  186:     */   }
/*  187:     */   
/*  188:     */   @Deprecated
/*  189:     */   public static OutputSupplier<OutputStreamWriter> newWriterSupplier(File file, Charset charset)
/*  190:     */   {
/*  191: 320 */     return newWriterSupplier(file, charset, false);
/*  192:     */   }
/*  193:     */   
/*  194:     */   @Deprecated
/*  195:     */   public static OutputSupplier<OutputStreamWriter> newWriterSupplier(File file, Charset charset, boolean append)
/*  196:     */   {
/*  197: 340 */     return CharStreams.asOutputSupplier(asCharSink(file, charset, modes(append)));
/*  198:     */   }
/*  199:     */   
/*  200:     */   public static byte[] toByteArray(File file)
/*  201:     */     throws IOException
/*  202:     */   {
/*  203: 353 */     return asByteSource(file).read();
/*  204:     */   }
/*  205:     */   
/*  206:     */   public static String toString(File file, Charset charset)
/*  207:     */     throws IOException
/*  208:     */   {
/*  209: 367 */     return asCharSource(file, charset).read();
/*  210:     */   }
/*  211:     */   
/*  212:     */   @Deprecated
/*  213:     */   public static void copy(InputSupplier<? extends InputStream> from, File to)
/*  214:     */     throws IOException
/*  215:     */   {
/*  216: 384 */     ByteStreams.asByteSource(from).copyTo(asByteSink(to, new FileWriteMode[0]));
/*  217:     */   }
/*  218:     */   
/*  219:     */   public static void write(byte[] from, File to)
/*  220:     */     throws IOException
/*  221:     */   {
/*  222: 395 */     asByteSink(to, new FileWriteMode[0]).write(from);
/*  223:     */   }
/*  224:     */   
/*  225:     */   @Deprecated
/*  226:     */   public static void copy(File from, OutputSupplier<? extends OutputStream> to)
/*  227:     */     throws IOException
/*  228:     */   {
/*  229: 412 */     asByteSource(from).copyTo(ByteStreams.asByteSink(to));
/*  230:     */   }
/*  231:     */   
/*  232:     */   public static void copy(File from, OutputStream to)
/*  233:     */     throws IOException
/*  234:     */   {
/*  235: 423 */     asByteSource(from).copyTo(to);
/*  236:     */   }
/*  237:     */   
/*  238:     */   public static void copy(File from, File to)
/*  239:     */     throws IOException
/*  240:     */   {
/*  241: 440 */     Preconditions.checkArgument(!from.equals(to), "Source %s and destination %s must be different", new Object[] { from, to });
/*  242:     */     
/*  243: 442 */     asByteSource(from).copyTo(asByteSink(to, new FileWriteMode[0]));
/*  244:     */   }
/*  245:     */   
/*  246:     */   @Deprecated
/*  247:     */   public static <R extends Readable,  extends Closeable> void copy(InputSupplier<R> from, File to, Charset charset)
/*  248:     */     throws IOException
/*  249:     */   {
/*  250: 462 */     CharStreams.asCharSource(from).copyTo(asCharSink(to, charset, new FileWriteMode[0]));
/*  251:     */   }
/*  252:     */   
/*  253:     */   public static void write(CharSequence from, File to, Charset charset)
/*  254:     */     throws IOException
/*  255:     */   {
/*  256: 477 */     asCharSink(to, charset, new FileWriteMode[0]).write(from);
/*  257:     */   }
/*  258:     */   
/*  259:     */   public static void append(CharSequence from, File to, Charset charset)
/*  260:     */     throws IOException
/*  261:     */   {
/*  262: 492 */     write(from, to, charset, true);
/*  263:     */   }
/*  264:     */   
/*  265:     */   private static void write(CharSequence from, File to, Charset charset, boolean append)
/*  266:     */     throws IOException
/*  267:     */   {
/*  268: 508 */     asCharSink(to, charset, modes(append)).write(from);
/*  269:     */   }
/*  270:     */   
/*  271:     */   @Deprecated
/*  272:     */   public static <W extends Appendable,  extends Closeable> void copy(File from, Charset charset, OutputSupplier<W> to)
/*  273:     */     throws IOException
/*  274:     */   {
/*  275: 528 */     asCharSource(from, charset).copyTo(CharStreams.asCharSink(to));
/*  276:     */   }
/*  277:     */   
/*  278:     */   public static void copy(File from, Charset charset, Appendable to)
/*  279:     */     throws IOException
/*  280:     */   {
/*  281: 543 */     asCharSource(from, charset).copyTo(to);
/*  282:     */   }
/*  283:     */   
/*  284:     */   public static boolean equal(File file1, File file2)
/*  285:     */     throws IOException
/*  286:     */   {
/*  287: 552 */     Preconditions.checkNotNull(file1);
/*  288: 553 */     Preconditions.checkNotNull(file2);
/*  289: 554 */     if ((file1 == file2) || (file1.equals(file2))) {
/*  290: 555 */       return true;
/*  291:     */     }
/*  292: 563 */     long len1 = file1.length();
/*  293: 564 */     long len2 = file2.length();
/*  294: 565 */     if ((len1 != 0L) && (len2 != 0L) && (len1 != len2)) {
/*  295: 566 */       return false;
/*  296:     */     }
/*  297: 568 */     return asByteSource(file1).contentEquals(asByteSource(file2));
/*  298:     */   }
/*  299:     */   
/*  300:     */   public static File createTempDir()
/*  301:     */   {
/*  302: 591 */     File baseDir = new File(System.getProperty("java.io.tmpdir"));
/*  303: 592 */     String baseName = System.currentTimeMillis() + "-";
/*  304: 594 */     for (int counter = 0; counter < 10000; counter++)
/*  305:     */     {
/*  306: 595 */       File tempDir = new File(baseDir, baseName + counter);
/*  307: 596 */       if (tempDir.mkdir()) {
/*  308: 597 */         return tempDir;
/*  309:     */       }
/*  310:     */     }
/*  311: 600 */     throw new IllegalStateException("Failed to create directory within 10000 attempts (tried " + baseName + "0 to " + baseName + 9999 + ')');
/*  312:     */   }
/*  313:     */   
/*  314:     */   public static void touch(File file)
/*  315:     */     throws IOException
/*  316:     */   {
/*  317: 613 */     Preconditions.checkNotNull(file);
/*  318: 614 */     if ((!file.createNewFile()) && (!file.setLastModified(System.currentTimeMillis()))) {
/*  319: 616 */       throw new IOException("Unable to update modification time of " + file);
/*  320:     */     }
/*  321:     */   }
/*  322:     */   
/*  323:     */   public static void createParentDirs(File file)
/*  324:     */     throws IOException
/*  325:     */   {
/*  326: 631 */     Preconditions.checkNotNull(file);
/*  327: 632 */     File parent = file.getCanonicalFile().getParentFile();
/*  328: 633 */     if (parent == null) {
/*  329: 641 */       return;
/*  330:     */     }
/*  331: 643 */     parent.mkdirs();
/*  332: 644 */     if (!parent.isDirectory()) {
/*  333: 645 */       throw new IOException("Unable to create parent directories of " + file);
/*  334:     */     }
/*  335:     */   }
/*  336:     */   
/*  337:     */   public static void move(File from, File to)
/*  338:     */     throws IOException
/*  339:     */   {
/*  340: 661 */     Preconditions.checkNotNull(from);
/*  341: 662 */     Preconditions.checkNotNull(to);
/*  342: 663 */     Preconditions.checkArgument(!from.equals(to), "Source %s and destination %s must be different", new Object[] { from, to });
/*  343: 666 */     if (!from.renameTo(to))
/*  344:     */     {
/*  345: 667 */       copy(from, to);
/*  346: 668 */       if (!from.delete())
/*  347:     */       {
/*  348: 669 */         if (!to.delete()) {
/*  349: 670 */           throw new IOException("Unable to delete " + to);
/*  350:     */         }
/*  351: 672 */         throw new IOException("Unable to delete " + from);
/*  352:     */       }
/*  353:     */     }
/*  354:     */   }
/*  355:     */   
/*  356:     */   public static String readFirstLine(File file, Charset charset)
/*  357:     */     throws IOException
/*  358:     */   {
/*  359: 690 */     return asCharSource(file, charset).readFirstLine();
/*  360:     */   }
/*  361:     */   
/*  362:     */   public static List<String> readLines(File file, Charset charset)
/*  363:     */     throws IOException
/*  364:     */   {
/*  365: 712 */     (List)readLines(file, charset, new LineProcessor()
/*  366:     */     {
/*  367: 713 */       final List<String> result = Lists.newArrayList();
/*  368:     */       
/*  369:     */       public boolean processLine(String line)
/*  370:     */       {
/*  371: 717 */         this.result.add(line);
/*  372: 718 */         return true;
/*  373:     */       }
/*  374:     */       
/*  375:     */       public List<String> getResult()
/*  376:     */       {
/*  377: 723 */         return this.result;
/*  378:     */       }
/*  379:     */     });
/*  380:     */   }
/*  381:     */   
/*  382:     */   public static <T> T readLines(File file, Charset charset, LineProcessor<T> callback)
/*  383:     */     throws IOException
/*  384:     */   {
/*  385: 741 */     return CharStreams.readLines(newReaderSupplier(file, charset), callback);
/*  386:     */   }
/*  387:     */   
/*  388:     */   public static <T> T readBytes(File file, ByteProcessor<T> processor)
/*  389:     */     throws IOException
/*  390:     */   {
/*  391: 757 */     return ByteStreams.readBytes(newInputStreamSupplier(file), processor);
/*  392:     */   }
/*  393:     */   
/*  394:     */   public static HashCode hash(File file, HashFunction hashFunction)
/*  395:     */     throws IOException
/*  396:     */   {
/*  397: 771 */     return asByteSource(file).hash(hashFunction);
/*  398:     */   }
/*  399:     */   
/*  400:     */   public static MappedByteBuffer map(File file)
/*  401:     */     throws IOException
/*  402:     */   {
/*  403: 791 */     Preconditions.checkNotNull(file);
/*  404: 792 */     return map(file, FileChannel.MapMode.READ_ONLY);
/*  405:     */   }
/*  406:     */   
/*  407:     */   public static MappedByteBuffer map(File file, FileChannel.MapMode mode)
/*  408:     */     throws IOException
/*  409:     */   {
/*  410: 815 */     Preconditions.checkNotNull(file);
/*  411: 816 */     Preconditions.checkNotNull(mode);
/*  412: 817 */     if (!file.exists()) {
/*  413: 818 */       throw new FileNotFoundException(file.toString());
/*  414:     */     }
/*  415: 820 */     return map(file, mode, file.length());
/*  416:     */   }
/*  417:     */   
/*  418:     */   public static MappedByteBuffer map(File file, FileChannel.MapMode mode, long size)
/*  419:     */     throws FileNotFoundException, IOException
/*  420:     */   {
/*  421: 846 */     Preconditions.checkNotNull(file);
/*  422: 847 */     Preconditions.checkNotNull(mode);
/*  423:     */     
/*  424: 849 */     Closer closer = Closer.create();
/*  425:     */     try
/*  426:     */     {
/*  427: 851 */       RandomAccessFile raf = (RandomAccessFile)closer.register(new RandomAccessFile(file, mode == FileChannel.MapMode.READ_ONLY ? "r" : "rw"));
/*  428:     */       
/*  429: 853 */       return map(raf, mode, size);
/*  430:     */     }
/*  431:     */     catch (Throwable e)
/*  432:     */     {
/*  433: 855 */       throw closer.rethrow(e);
/*  434:     */     }
/*  435:     */     finally
/*  436:     */     {
/*  437: 857 */       closer.close();
/*  438:     */     }
/*  439:     */   }
/*  440:     */   
/*  441:     */   private static MappedByteBuffer map(RandomAccessFile raf, FileChannel.MapMode mode, long size)
/*  442:     */     throws IOException
/*  443:     */   {
/*  444: 863 */     Closer closer = Closer.create();
/*  445:     */     try
/*  446:     */     {
/*  447: 865 */       FileChannel channel = (FileChannel)closer.register(raf.getChannel());
/*  448: 866 */       return channel.map(mode, 0L, size);
/*  449:     */     }
/*  450:     */     catch (Throwable e)
/*  451:     */     {
/*  452: 868 */       throw closer.rethrow(e);
/*  453:     */     }
/*  454:     */     finally
/*  455:     */     {
/*  456: 870 */       closer.close();
/*  457:     */     }
/*  458:     */   }
/*  459:     */   
/*  460:     */   public static String simplifyPath(String pathname)
/*  461:     */   {
/*  462: 896 */     Preconditions.checkNotNull(pathname);
/*  463: 897 */     if (pathname.length() == 0) {
/*  464: 898 */       return ".";
/*  465:     */     }
/*  466: 902 */     Iterable<String> components = Splitter.on('/').omitEmptyStrings().split(pathname);
/*  467:     */     
/*  468: 904 */     List<String> path = new ArrayList();
/*  469: 907 */     for (String component : components) {
/*  470: 908 */       if (!component.equals(".")) {
/*  471: 910 */         if (component.equals(".."))
/*  472:     */         {
/*  473: 911 */           if ((path.size() > 0) && (!((String)path.get(path.size() - 1)).equals(".."))) {
/*  474: 912 */             path.remove(path.size() - 1);
/*  475:     */           } else {
/*  476: 914 */             path.add("..");
/*  477:     */           }
/*  478:     */         }
/*  479:     */         else {
/*  480: 917 */           path.add(component);
/*  481:     */         }
/*  482:     */       }
/*  483:     */     }
/*  484: 922 */     String result = Joiner.on('/').join(path);
/*  485: 923 */     if (pathname.charAt(0) == '/') {
/*  486: 924 */       result = "/" + result;
/*  487:     */     }
/*  488: 927 */     while (result.startsWith("/../")) {
/*  489: 928 */       result = result.substring(3);
/*  490:     */     }
/*  491: 930 */     if (result.equals("/..")) {
/*  492: 931 */       result = "/";
/*  493: 932 */     } else if ("".equals(result)) {
/*  494: 933 */       result = ".";
/*  495:     */     }
/*  496: 936 */     return result;
/*  497:     */   }
/*  498:     */   
/*  499:     */   public static String getFileExtension(String fullName)
/*  500:     */   {
/*  501: 947 */     Preconditions.checkNotNull(fullName);
/*  502: 948 */     String fileName = new File(fullName).getName();
/*  503: 949 */     int dotIndex = fileName.lastIndexOf('.');
/*  504: 950 */     return dotIndex == -1 ? "" : fileName.substring(dotIndex + 1);
/*  505:     */   }
/*  506:     */   
/*  507:     */   public static String getNameWithoutExtension(String file)
/*  508:     */   {
/*  509: 964 */     Preconditions.checkNotNull(file);
/*  510: 965 */     String fileName = new File(file).getName();
/*  511: 966 */     int dotIndex = fileName.lastIndexOf('.');
/*  512: 967 */     return dotIndex == -1 ? fileName : fileName.substring(0, dotIndex);
/*  513:     */   }
/*  514:     */   
/*  515:     */   public static TreeTraverser<File> fileTreeTraverser()
/*  516:     */   {
/*  517: 981 */     return FILE_TREE_TRAVERSER;
/*  518:     */   }
/*  519:     */   
/*  520: 984 */   private static final TreeTraverser<File> FILE_TREE_TRAVERSER = new TreeTraverser()
/*  521:     */   {
/*  522:     */     public Iterable<File> children(File file)
/*  523:     */     {
/*  524: 988 */       if (file.isDirectory())
/*  525:     */       {
/*  526: 989 */         File[] files = file.listFiles();
/*  527: 990 */         if (files != null) {
/*  528: 991 */           return Collections.unmodifiableList(Arrays.asList(files));
/*  529:     */         }
/*  530:     */       }
/*  531: 995 */       return Collections.emptyList();
/*  532:     */     }
/*  533:     */     
/*  534:     */     public String toString()
/*  535:     */     {
/*  536:1000 */       return "Files.fileTreeTraverser()";
/*  537:     */     }
/*  538:     */   };
/*  539:     */   
/*  540:     */   public static Predicate<File> isDirectory()
/*  541:     */   {
/*  542:1010 */     return FilePredicate.IS_DIRECTORY;
/*  543:     */   }
/*  544:     */   
/*  545:     */   public static Predicate<File> isFile()
/*  546:     */   {
/*  547:1019 */     return FilePredicate.IS_FILE;
/*  548:     */   }
/*  549:     */   
/*  550:     */   private static abstract enum FilePredicate
/*  551:     */     implements Predicate<File>
/*  552:     */   {
/*  553:1023 */     IS_DIRECTORY,  IS_FILE;
/*  554:     */     
/*  555:     */     private FilePredicate() {}
/*  556:     */   }
/*  557:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.Files
 * JD-Core Version:    0.7.0.1
 */
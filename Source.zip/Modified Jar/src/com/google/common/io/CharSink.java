/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.BufferedWriter;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.Writer;
/*   7:    */ 
/*   8:    */ public abstract class CharSink
/*   9:    */   implements OutputSupplier<Writer>
/*  10:    */ {
/*  11:    */   public abstract Writer openStream()
/*  12:    */     throws IOException;
/*  13:    */   
/*  14:    */   @Deprecated
/*  15:    */   public final Writer getOutput()
/*  16:    */     throws IOException
/*  17:    */   {
/*  18: 78 */     return openStream();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public Writer openBufferedStream()
/*  22:    */     throws IOException
/*  23:    */   {
/*  24: 94 */     Writer writer = openStream();
/*  25: 95 */     return (writer instanceof BufferedWriter) ? (BufferedWriter)writer : new BufferedWriter(writer);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void write(CharSequence charSequence)
/*  29:    */     throws IOException
/*  30:    */   {
/*  31:106 */     Preconditions.checkNotNull(charSequence);
/*  32:    */     
/*  33:108 */     Closer closer = Closer.create();
/*  34:    */     try
/*  35:    */     {
/*  36:110 */       Writer out = (Writer)closer.register(openStream());
/*  37:111 */       out.append(charSequence);
/*  38:112 */       out.flush();
/*  39:    */     }
/*  40:    */     catch (Throwable e)
/*  41:    */     {
/*  42:114 */       throw closer.rethrow(e);
/*  43:    */     }
/*  44:    */     finally
/*  45:    */     {
/*  46:116 */       closer.close();
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void writeLines(Iterable<? extends CharSequence> lines)
/*  51:    */     throws IOException
/*  52:    */   {
/*  53:128 */     writeLines(lines, System.getProperty("line.separator"));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void writeLines(Iterable<? extends CharSequence> lines, String lineSeparator)
/*  57:    */     throws IOException
/*  58:    */   {
/*  59:139 */     Preconditions.checkNotNull(lines);
/*  60:140 */     Preconditions.checkNotNull(lineSeparator);
/*  61:    */     
/*  62:142 */     Closer closer = Closer.create();
/*  63:    */     try
/*  64:    */     {
/*  65:144 */       Writer out = (Writer)closer.register(openBufferedStream());
/*  66:145 */       for (CharSequence line : lines) {
/*  67:146 */         out.append(line).append(lineSeparator);
/*  68:    */       }
/*  69:148 */       out.flush();
/*  70:    */     }
/*  71:    */     catch (Throwable e)
/*  72:    */     {
/*  73:150 */       throw closer.rethrow(e);
/*  74:    */     }
/*  75:    */     finally
/*  76:    */     {
/*  77:152 */       closer.close();
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public long writeFrom(Readable readable)
/*  82:    */     throws IOException
/*  83:    */   {
/*  84:164 */     Preconditions.checkNotNull(readable);
/*  85:    */     
/*  86:166 */     Closer closer = Closer.create();
/*  87:    */     try
/*  88:    */     {
/*  89:168 */       Writer out = (Writer)closer.register(openStream());
/*  90:169 */       long written = CharStreams.copy(readable, out);
/*  91:170 */       out.flush();
/*  92:171 */       return written;
/*  93:    */     }
/*  94:    */     catch (Throwable e)
/*  95:    */     {
/*  96:173 */       throw closer.rethrow(e);
/*  97:    */     }
/*  98:    */     finally
/*  99:    */     {
/* 100:175 */       closer.close();
/* 101:    */     }
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.CharSink
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Lists;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.InputStream;
/*   9:    */ import java.io.InputStreamReader;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ import java.net.URL;
/*  12:    */ import java.nio.charset.Charset;
/*  13:    */ import java.util.List;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ public final class Resources
/*  17:    */ {
/*  18:    */   @Deprecated
/*  19:    */   public static InputSupplier<InputStream> newInputStreamSupplier(URL url)
/*  20:    */   {
/*  21: 62 */     return ByteStreams.asInputSupplier(asByteSource(url));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static ByteSource asByteSource(URL url)
/*  25:    */   {
/*  26: 71 */     return new UrlByteSource(url, null);
/*  27:    */   }
/*  28:    */   
/*  29:    */   private static final class UrlByteSource
/*  30:    */     extends ByteSource
/*  31:    */   {
/*  32:    */     private final URL url;
/*  33:    */     
/*  34:    */     private UrlByteSource(URL url)
/*  35:    */     {
/*  36: 82 */       this.url = ((URL)Preconditions.checkNotNull(url));
/*  37:    */     }
/*  38:    */     
/*  39:    */     public InputStream openStream()
/*  40:    */       throws IOException
/*  41:    */     {
/*  42: 87 */       return this.url.openStream();
/*  43:    */     }
/*  44:    */     
/*  45:    */     public String toString()
/*  46:    */     {
/*  47: 92 */       return "Resources.asByteSource(" + this.url + ")";
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   @Deprecated
/*  52:    */   public static InputSupplier<InputStreamReader> newReaderSupplier(URL url, Charset charset)
/*  53:    */   {
/*  54:110 */     return CharStreams.asInputSupplier(asCharSource(url, charset));
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static CharSource asCharSource(URL url, Charset charset)
/*  58:    */   {
/*  59:120 */     return asByteSource(url).asCharSource(charset);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static byte[] toByteArray(URL url)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65:131 */     return asByteSource(url).read();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static String toString(URL url, Charset charset)
/*  69:    */     throws IOException
/*  70:    */   {
/*  71:145 */     return asCharSource(url, charset).read();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static <T> T readLines(URL url, Charset charset, LineProcessor<T> callback)
/*  75:    */     throws IOException
/*  76:    */   {
/*  77:161 */     return CharStreams.readLines(newReaderSupplier(url, charset), callback);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static List<String> readLines(URL url, Charset charset)
/*  81:    */     throws IOException
/*  82:    */   {
/*  83:183 */     (List)readLines(url, charset, new LineProcessor()
/*  84:    */     {
/*  85:184 */       final List<String> result = Lists.newArrayList();
/*  86:    */       
/*  87:    */       public boolean processLine(String line)
/*  88:    */       {
/*  89:188 */         this.result.add(line);
/*  90:189 */         return true;
/*  91:    */       }
/*  92:    */       
/*  93:    */       public List<String> getResult()
/*  94:    */       {
/*  95:194 */         return this.result;
/*  96:    */       }
/*  97:    */     });
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void copy(URL from, OutputStream to)
/* 101:    */     throws IOException
/* 102:    */   {
/* 103:207 */     asByteSource(from).copyTo(to);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static URL getResource(String resourceName)
/* 107:    */   {
/* 108:225 */     ClassLoader loader = (ClassLoader)Objects.firstNonNull(Thread.currentThread().getContextClassLoader(), Resources.class.getClassLoader());
/* 109:    */     
/* 110:    */ 
/* 111:228 */     URL url = loader.getResource(resourceName);
/* 112:229 */     Preconditions.checkArgument(url != null, "resource %s not found.", new Object[] { resourceName });
/* 113:230 */     return url;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static URL getResource(Class<?> contextClass, String resourceName)
/* 117:    */   {
/* 118:240 */     URL url = contextClass.getResource(resourceName);
/* 119:241 */     Preconditions.checkArgument(url != null, "resource %s relative to %s not found.", new Object[] { resourceName, contextClass.getName() });
/* 120:    */     
/* 121:243 */     return url;
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.Resources
 * JD-Core Version:    0.7.0.1
 */
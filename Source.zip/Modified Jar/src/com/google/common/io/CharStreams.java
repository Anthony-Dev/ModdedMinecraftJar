/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Iterables;
/*   7:    */ import java.io.Closeable;
/*   8:    */ import java.io.EOFException;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.InputStream;
/*  11:    */ import java.io.InputStreamReader;
/*  12:    */ import java.io.OutputStream;
/*  13:    */ import java.io.OutputStreamWriter;
/*  14:    */ import java.io.Reader;
/*  15:    */ import java.io.StringReader;
/*  16:    */ import java.io.Writer;
/*  17:    */ import java.nio.CharBuffer;
/*  18:    */ import java.nio.charset.Charset;
/*  19:    */ import java.util.ArrayList;
/*  20:    */ import java.util.Arrays;
/*  21:    */ import java.util.List;
/*  22:    */ 
/*  23:    */ @Beta
/*  24:    */ public final class CharStreams
/*  25:    */ {
/*  26:    */   private static final int BUF_SIZE = 2048;
/*  27:    */   
/*  28:    */   @Deprecated
/*  29:    */   public static InputSupplier<StringReader> newReaderSupplier(String value)
/*  30:    */   {
/*  31: 76 */     return asInputSupplier(CharSource.wrap(value));
/*  32:    */   }
/*  33:    */   
/*  34:    */   @Deprecated
/*  35:    */   public static InputSupplier<InputStreamReader> newReaderSupplier(InputSupplier<? extends InputStream> in, Charset charset)
/*  36:    */   {
/*  37: 93 */     return asInputSupplier(ByteStreams.asByteSource(in).asCharSource(charset));
/*  38:    */   }
/*  39:    */   
/*  40:    */   @Deprecated
/*  41:    */   public static OutputSupplier<OutputStreamWriter> newWriterSupplier(OutputSupplier<? extends OutputStream> out, Charset charset)
/*  42:    */   {
/*  43:111 */     return asOutputSupplier(ByteStreams.asByteSink(out).asCharSink(charset));
/*  44:    */   }
/*  45:    */   
/*  46:    */   @Deprecated
/*  47:    */   public static <W extends Appendable,  extends Closeable> void write(CharSequence from, OutputSupplier<W> to)
/*  48:    */     throws IOException
/*  49:    */   {
/*  50:128 */     asCharSink(to).write(from);
/*  51:    */   }
/*  52:    */   
/*  53:    */   @Deprecated
/*  54:    */   public static <R extends Readable,  extends Closeable, W extends Appendable,  extends Closeable> long copy(InputSupplier<R> from, OutputSupplier<W> to)
/*  55:    */     throws IOException
/*  56:    */   {
/*  57:147 */     return asCharSource(from).copyTo(asCharSink(to));
/*  58:    */   }
/*  59:    */   
/*  60:    */   @Deprecated
/*  61:    */   public static <R extends Readable,  extends Closeable> long copy(InputSupplier<R> from, Appendable to)
/*  62:    */     throws IOException
/*  63:    */   {
/*  64:165 */     return asCharSource(from).copyTo(to);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static long copy(Readable from, Appendable to)
/*  68:    */     throws IOException
/*  69:    */   {
/*  70:178 */     Preconditions.checkNotNull(from);
/*  71:179 */     Preconditions.checkNotNull(to);
/*  72:180 */     CharBuffer buf = CharBuffer.allocate(2048);
/*  73:181 */     long total = 0L;
/*  74:182 */     while (from.read(buf) != -1)
/*  75:    */     {
/*  76:183 */       buf.flip();
/*  77:184 */       to.append(buf);
/*  78:185 */       total += buf.remaining();
/*  79:186 */       buf.clear();
/*  80:    */     }
/*  81:188 */     return total;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static String toString(Readable r)
/*  85:    */     throws IOException
/*  86:    */   {
/*  87:200 */     return toStringBuilder(r).toString();
/*  88:    */   }
/*  89:    */   
/*  90:    */   @Deprecated
/*  91:    */   public static <R extends Readable,  extends Closeable> String toString(InputSupplier<R> supplier)
/*  92:    */     throws IOException
/*  93:    */   {
/*  94:216 */     return asCharSource(supplier).read();
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static StringBuilder toStringBuilder(Readable r)
/*  98:    */     throws IOException
/*  99:    */   {
/* 100:228 */     StringBuilder sb = new StringBuilder();
/* 101:229 */     copy(r, sb);
/* 102:230 */     return sb;
/* 103:    */   }
/* 104:    */   
/* 105:    */   @Deprecated
/* 106:    */   public static <R extends Readable,  extends Closeable> String readFirstLine(InputSupplier<R> supplier)
/* 107:    */     throws IOException
/* 108:    */   {
/* 109:247 */     return asCharSource(supplier).readFirstLine();
/* 110:    */   }
/* 111:    */   
/* 112:    */   @Deprecated
/* 113:    */   public static <R extends Readable,  extends Closeable> List<String> readLines(InputSupplier<R> supplier)
/* 114:    */     throws IOException
/* 115:    */   {
/* 116:265 */     Closer closer = Closer.create();
/* 117:    */     try
/* 118:    */     {
/* 119:267 */       R r = (Readable)closer.register((Closeable)supplier.getInput());
/* 120:268 */       return readLines(r);
/* 121:    */     }
/* 122:    */     catch (Throwable e)
/* 123:    */     {
/* 124:270 */       throw closer.rethrow(e);
/* 125:    */     }
/* 126:    */     finally
/* 127:    */     {
/* 128:272 */       closer.close();
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static List<String> readLines(Readable r)
/* 133:    */     throws IOException
/* 134:    */   {
/* 135:290 */     List<String> result = new ArrayList();
/* 136:291 */     LineReader lineReader = new LineReader(r);
/* 137:    */     String line;
/* 138:293 */     while ((line = lineReader.readLine()) != null) {
/* 139:294 */       result.add(line);
/* 140:    */     }
/* 141:296 */     return result;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public static <T> T readLines(Readable readable, LineProcessor<T> processor)
/* 145:    */     throws IOException
/* 146:    */   {
/* 147:311 */     Preconditions.checkNotNull(readable);
/* 148:312 */     Preconditions.checkNotNull(processor);
/* 149:    */     
/* 150:314 */     LineReader lineReader = new LineReader(readable);
/* 151:    */     String line;
/* 152:316 */     while ((line = lineReader.readLine()) != null) {
/* 153:317 */       if (!processor.processLine(line)) {
/* 154:    */         break;
/* 155:    */       }
/* 156:    */     }
/* 157:321 */     return processor.getResult();
/* 158:    */   }
/* 159:    */   
/* 160:    */   @Deprecated
/* 161:    */   public static <R extends Readable,  extends Closeable, T> T readLines(InputSupplier<R> supplier, LineProcessor<T> callback)
/* 162:    */     throws IOException
/* 163:    */   {
/* 164:339 */     Preconditions.checkNotNull(supplier);
/* 165:340 */     Preconditions.checkNotNull(callback);
/* 166:    */     
/* 167:342 */     Closer closer = Closer.create();
/* 168:    */     try
/* 169:    */     {
/* 170:344 */       R r = (Readable)closer.register((Closeable)supplier.getInput());
/* 171:345 */       return readLines(r, callback);
/* 172:    */     }
/* 173:    */     catch (Throwable e)
/* 174:    */     {
/* 175:347 */       throw closer.rethrow(e);
/* 176:    */     }
/* 177:    */     finally
/* 178:    */     {
/* 179:349 */       closer.close();
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   @Deprecated
/* 184:    */   public static InputSupplier<Reader> join(Iterable<? extends InputSupplier<? extends Reader>> suppliers)
/* 185:    */   {
/* 186:373 */     Preconditions.checkNotNull(suppliers);
/* 187:374 */     Iterable<CharSource> sources = Iterables.transform(suppliers, new Function()
/* 188:    */     {
/* 189:    */       public CharSource apply(InputSupplier<? extends Reader> input)
/* 190:    */       {
/* 191:378 */         return CharStreams.asCharSource(input);
/* 192:    */       }
/* 193:380 */     });
/* 194:381 */     return asInputSupplier(CharSource.concat(sources));
/* 195:    */   }
/* 196:    */   
/* 197:    */   @Deprecated
/* 198:    */   public static InputSupplier<Reader> join(InputSupplier<? extends Reader>... suppliers)
/* 199:    */   {
/* 200:394 */     return join(Arrays.asList(suppliers));
/* 201:    */   }
/* 202:    */   
/* 203:    */   public static void skipFully(Reader reader, long n)
/* 204:    */     throws IOException
/* 205:    */   {
/* 206:409 */     Preconditions.checkNotNull(reader);
/* 207:410 */     while (n > 0L)
/* 208:    */     {
/* 209:411 */       long amt = reader.skip(n);
/* 210:412 */       if (amt == 0L)
/* 211:    */       {
/* 212:414 */         if (reader.read() == -1) {
/* 213:415 */           throw new EOFException();
/* 214:    */         }
/* 215:417 */         n -= 1L;
/* 216:    */       }
/* 217:    */       else
/* 218:    */       {
/* 219:419 */         n -= amt;
/* 220:    */       }
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static Writer nullWriter()
/* 225:    */   {
/* 226:430 */     return NullWriter.INSTANCE;
/* 227:    */   }
/* 228:    */   
/* 229:    */   private static final class NullWriter
/* 230:    */     extends Writer
/* 231:    */   {
/* 232:435 */     private static final NullWriter INSTANCE = new NullWriter();
/* 233:    */     
/* 234:    */     public void write(int c) {}
/* 235:    */     
/* 236:    */     public void write(char[] cbuf)
/* 237:    */     {
/* 238:443 */       Preconditions.checkNotNull(cbuf);
/* 239:    */     }
/* 240:    */     
/* 241:    */     public void write(char[] cbuf, int off, int len)
/* 242:    */     {
/* 243:448 */       Preconditions.checkPositionIndexes(off, off + len, cbuf.length);
/* 244:    */     }
/* 245:    */     
/* 246:    */     public void write(String str)
/* 247:    */     {
/* 248:453 */       Preconditions.checkNotNull(str);
/* 249:    */     }
/* 250:    */     
/* 251:    */     public void write(String str, int off, int len)
/* 252:    */     {
/* 253:458 */       Preconditions.checkPositionIndexes(off, off + len, str.length());
/* 254:    */     }
/* 255:    */     
/* 256:    */     public Writer append(CharSequence csq)
/* 257:    */     {
/* 258:463 */       Preconditions.checkNotNull(csq);
/* 259:464 */       return this;
/* 260:    */     }
/* 261:    */     
/* 262:    */     public Writer append(CharSequence csq, int start, int end)
/* 263:    */     {
/* 264:469 */       Preconditions.checkPositionIndexes(start, end, csq.length());
/* 265:470 */       return this;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public Writer append(char c)
/* 269:    */     {
/* 270:475 */       return this;
/* 271:    */     }
/* 272:    */     
/* 273:    */     public void flush() {}
/* 274:    */     
/* 275:    */     public void close() {}
/* 276:    */     
/* 277:    */     public String toString()
/* 278:    */     {
/* 279:488 */       return "CharStreams.nullWriter()";
/* 280:    */     }
/* 281:    */   }
/* 282:    */   
/* 283:    */   public static Writer asWriter(Appendable target)
/* 284:    */   {
/* 285:503 */     if ((target instanceof Writer)) {
/* 286:504 */       return (Writer)target;
/* 287:    */     }
/* 288:506 */     return new AppendableWriter(target);
/* 289:    */   }
/* 290:    */   
/* 291:    */   static Reader asReader(Readable readable)
/* 292:    */   {
/* 293:512 */     Preconditions.checkNotNull(readable);
/* 294:513 */     if ((readable instanceof Reader)) {
/* 295:514 */       return (Reader)readable;
/* 296:    */     }
/* 297:516 */     new Reader()
/* 298:    */     {
/* 299:    */       public int read(char[] cbuf, int off, int len)
/* 300:    */         throws IOException
/* 301:    */       {
/* 302:519 */         return read(CharBuffer.wrap(cbuf, off, len));
/* 303:    */       }
/* 304:    */       
/* 305:    */       public int read(CharBuffer target)
/* 306:    */         throws IOException
/* 307:    */       {
/* 308:524 */         return this.val$readable.read(target);
/* 309:    */       }
/* 310:    */       
/* 311:    */       public void close()
/* 312:    */         throws IOException
/* 313:    */       {
/* 314:529 */         if ((this.val$readable instanceof Closeable)) {
/* 315:530 */           ((Closeable)this.val$readable).close();
/* 316:    */         }
/* 317:    */       }
/* 318:    */     };
/* 319:    */   }
/* 320:    */   
/* 321:    */   @Deprecated
/* 322:    */   public static CharSource asCharSource(InputSupplier<? extends Readable> supplier)
/* 323:    */   {
/* 324:552 */     Preconditions.checkNotNull(supplier);
/* 325:553 */     new CharSource()
/* 326:    */     {
/* 327:    */       public Reader openStream()
/* 328:    */         throws IOException
/* 329:    */       {
/* 330:556 */         return CharStreams.asReader((Readable)this.val$supplier.getInput());
/* 331:    */       }
/* 332:    */       
/* 333:    */       public String toString()
/* 334:    */       {
/* 335:561 */         return "CharStreams.asCharSource(" + this.val$supplier + ")";
/* 336:    */       }
/* 337:    */     };
/* 338:    */   }
/* 339:    */   
/* 340:    */   @Deprecated
/* 341:    */   public static CharSink asCharSink(OutputSupplier<? extends Appendable> supplier)
/* 342:    */   {
/* 343:582 */     Preconditions.checkNotNull(supplier);
/* 344:583 */     new CharSink()
/* 345:    */     {
/* 346:    */       public Writer openStream()
/* 347:    */         throws IOException
/* 348:    */       {
/* 349:586 */         return CharStreams.asWriter((Appendable)this.val$supplier.getOutput());
/* 350:    */       }
/* 351:    */       
/* 352:    */       public String toString()
/* 353:    */       {
/* 354:591 */         return "CharStreams.asCharSink(" + this.val$supplier + ")";
/* 355:    */       }
/* 356:    */     };
/* 357:    */   }
/* 358:    */   
/* 359:    */   static <R extends Reader> InputSupplier<R> asInputSupplier(CharSource source)
/* 360:    */   {
/* 361:599 */     return (InputSupplier)Preconditions.checkNotNull(source);
/* 362:    */   }
/* 363:    */   
/* 364:    */   static <W extends Writer> OutputSupplier<W> asOutputSupplier(CharSink sink)
/* 365:    */   {
/* 366:605 */     return (OutputSupplier)Preconditions.checkNotNull(sink);
/* 367:    */   }
/* 368:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.CharStreams
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.io.Reader;
/*  10:    */ import java.io.Writer;
/*  11:    */ 
/*  12:    */ @GwtCompatible(emulated=true)
/*  13:    */ final class GwtWorkarounds
/*  14:    */ {
/*  15:    */   @GwtIncompatible("Reader")
/*  16:    */   static CharInput asCharInput(Reader reader)
/*  17:    */   {
/*  18: 53 */     Preconditions.checkNotNull(reader);
/*  19: 54 */     new CharInput()
/*  20:    */     {
/*  21:    */       public int read()
/*  22:    */         throws IOException
/*  23:    */       {
/*  24: 57 */         return this.val$reader.read();
/*  25:    */       }
/*  26:    */       
/*  27:    */       public void close()
/*  28:    */         throws IOException
/*  29:    */       {
/*  30: 62 */         this.val$reader.close();
/*  31:    */       }
/*  32:    */     };
/*  33:    */   }
/*  34:    */   
/*  35:    */   static CharInput asCharInput(CharSequence chars)
/*  36:    */   {
/*  37: 71 */     Preconditions.checkNotNull(chars);
/*  38: 72 */     new CharInput()
/*  39:    */     {
/*  40: 73 */       int index = 0;
/*  41:    */       
/*  42:    */       public int read()
/*  43:    */       {
/*  44: 77 */         if (this.index < this.val$chars.length()) {
/*  45: 78 */           return this.val$chars.charAt(this.index++);
/*  46:    */         }
/*  47: 80 */         return -1;
/*  48:    */       }
/*  49:    */       
/*  50:    */       public void close()
/*  51:    */       {
/*  52: 86 */         this.index = this.val$chars.length();
/*  53:    */       }
/*  54:    */     };
/*  55:    */   }
/*  56:    */   
/*  57:    */   @GwtIncompatible("InputStream")
/*  58:    */   static InputStream asInputStream(ByteInput input)
/*  59:    */   {
/*  60:104 */     Preconditions.checkNotNull(input);
/*  61:105 */     new InputStream()
/*  62:    */     {
/*  63:    */       public int read()
/*  64:    */         throws IOException
/*  65:    */       {
/*  66:108 */         return this.val$input.read();
/*  67:    */       }
/*  68:    */       
/*  69:    */       public int read(byte[] b, int off, int len)
/*  70:    */         throws IOException
/*  71:    */       {
/*  72:113 */         Preconditions.checkNotNull(b);
/*  73:114 */         Preconditions.checkPositionIndexes(off, off + len, b.length);
/*  74:115 */         if (len == 0) {
/*  75:116 */           return 0;
/*  76:    */         }
/*  77:118 */         int firstByte = read();
/*  78:119 */         if (firstByte == -1) {
/*  79:120 */           return -1;
/*  80:    */         }
/*  81:122 */         b[off] = ((byte)firstByte);
/*  82:123 */         for (int dst = 1; dst < len; dst++)
/*  83:    */         {
/*  84:124 */           int readByte = read();
/*  85:125 */           if (readByte == -1) {
/*  86:126 */             return dst;
/*  87:    */           }
/*  88:128 */           b[(off + dst)] = ((byte)readByte);
/*  89:    */         }
/*  90:130 */         return len;
/*  91:    */       }
/*  92:    */       
/*  93:    */       public void close()
/*  94:    */         throws IOException
/*  95:    */       {
/*  96:135 */         this.val$input.close();
/*  97:    */       }
/*  98:    */     };
/*  99:    */   }
/* 100:    */   
/* 101:    */   @GwtIncompatible("OutputStream")
/* 102:    */   static OutputStream asOutputStream(ByteOutput output)
/* 103:    */   {
/* 104:154 */     Preconditions.checkNotNull(output);
/* 105:155 */     new OutputStream()
/* 106:    */     {
/* 107:    */       public void write(int b)
/* 108:    */         throws IOException
/* 109:    */       {
/* 110:158 */         this.val$output.write((byte)b);
/* 111:    */       }
/* 112:    */       
/* 113:    */       public void flush()
/* 114:    */         throws IOException
/* 115:    */       {
/* 116:163 */         this.val$output.flush();
/* 117:    */       }
/* 118:    */       
/* 119:    */       public void close()
/* 120:    */         throws IOException
/* 121:    */       {
/* 122:168 */         this.val$output.close();
/* 123:    */       }
/* 124:    */     };
/* 125:    */   }
/* 126:    */   
/* 127:    */   @GwtIncompatible("Writer")
/* 128:    */   static CharOutput asCharOutput(Writer writer)
/* 129:    */   {
/* 130:187 */     Preconditions.checkNotNull(writer);
/* 131:188 */     new CharOutput()
/* 132:    */     {
/* 133:    */       public void write(char c)
/* 134:    */         throws IOException
/* 135:    */       {
/* 136:191 */         this.val$writer.append(c);
/* 137:    */       }
/* 138:    */       
/* 139:    */       public void flush()
/* 140:    */         throws IOException
/* 141:    */       {
/* 142:196 */         this.val$writer.flush();
/* 143:    */       }
/* 144:    */       
/* 145:    */       public void close()
/* 146:    */         throws IOException
/* 147:    */       {
/* 148:201 */         this.val$writer.close();
/* 149:    */       }
/* 150:    */     };
/* 151:    */   }
/* 152:    */   
/* 153:    */   static CharOutput stringBuilderOutput(int initialSize)
/* 154:    */   {
/* 155:211 */     StringBuilder builder = new StringBuilder(initialSize);
/* 156:212 */     new CharOutput()
/* 157:    */     {
/* 158:    */       public void write(char c)
/* 159:    */       {
/* 160:216 */         this.val$builder.append(c);
/* 161:    */       }
/* 162:    */       
/* 163:    */       public void flush() {}
/* 164:    */       
/* 165:    */       public void close() {}
/* 166:    */       
/* 167:    */       public String toString()
/* 168:    */       {
/* 169:227 */         return this.val$builder.toString();
/* 170:    */       }
/* 171:    */     };
/* 172:    */   }
/* 173:    */   
/* 174:    */   static abstract interface ByteInput
/* 175:    */   {
/* 176:    */     public abstract int read()
/* 177:    */       throws IOException;
/* 178:    */     
/* 179:    */     public abstract void close()
/* 180:    */       throws IOException;
/* 181:    */   }
/* 182:    */   
/* 183:    */   static abstract interface ByteOutput
/* 184:    */   {
/* 185:    */     public abstract void write(byte paramByte)
/* 186:    */       throws IOException;
/* 187:    */     
/* 188:    */     public abstract void flush()
/* 189:    */       throws IOException;
/* 190:    */     
/* 191:    */     public abstract void close()
/* 192:    */       throws IOException;
/* 193:    */   }
/* 194:    */   
/* 195:    */   static abstract interface CharInput
/* 196:    */   {
/* 197:    */     public abstract int read()
/* 198:    */       throws IOException;
/* 199:    */     
/* 200:    */     public abstract void close()
/* 201:    */       throws IOException;
/* 202:    */   }
/* 203:    */   
/* 204:    */   static abstract interface CharOutput
/* 205:    */   {
/* 206:    */     public abstract void write(char paramChar)
/* 207:    */       throws IOException;
/* 208:    */     
/* 209:    */     public abstract void flush()
/* 210:    */       throws IOException;
/* 211:    */     
/* 212:    */     public abstract void close()
/* 213:    */       throws IOException;
/* 214:    */   }
/* 215:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.GwtWorkarounds
 * JD-Core Version:    0.7.0.1
 */
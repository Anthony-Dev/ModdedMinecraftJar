/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import java.io.FilterInputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.InputStream;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public final class CountingInputStream
/* 11:   */   extends FilterInputStream
/* 12:   */ {
/* 13:   */   private long count;
/* 14:37 */   private long mark = -1L;
/* 15:   */   
/* 16:   */   public CountingInputStream(@Nullable InputStream in)
/* 17:   */   {
/* 18:45 */     super(in);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public long getCount()
/* 22:   */   {
/* 23:50 */     return this.count;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int read()
/* 27:   */     throws IOException
/* 28:   */   {
/* 29:54 */     int result = this.in.read();
/* 30:55 */     if (result != -1) {
/* 31:56 */       this.count += 1L;
/* 32:   */     }
/* 33:58 */     return result;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public int read(byte[] b, int off, int len)
/* 37:   */     throws IOException
/* 38:   */   {
/* 39:62 */     int result = this.in.read(b, off, len);
/* 40:63 */     if (result != -1) {
/* 41:64 */       this.count += result;
/* 42:   */     }
/* 43:66 */     return result;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public long skip(long n)
/* 47:   */     throws IOException
/* 48:   */   {
/* 49:70 */     long result = this.in.skip(n);
/* 50:71 */     this.count += result;
/* 51:72 */     return result;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public synchronized void mark(int readlimit)
/* 55:   */   {
/* 56:76 */     this.in.mark(readlimit);
/* 57:77 */     this.mark = this.count;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public synchronized void reset()
/* 61:   */     throws IOException
/* 62:   */   {
/* 63:82 */     if (!this.in.markSupported()) {
/* 64:83 */       throw new IOException("Mark not supported");
/* 65:   */     }
/* 66:85 */     if (this.mark == -1L) {
/* 67:86 */       throw new IOException("Mark not set");
/* 68:   */     }
/* 69:89 */     this.in.reset();
/* 70:90 */     this.count = this.mark;
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.CountingInputStream
 * JD-Core Version:    0.7.0.1
 */
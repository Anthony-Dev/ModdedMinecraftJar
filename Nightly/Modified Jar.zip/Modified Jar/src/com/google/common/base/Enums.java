/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.lang.ref.WeakReference;
/*   8:    */ import java.lang.reflect.Field;
/*   9:    */ import java.util.EnumSet;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.WeakHashMap;
/*  13:    */ import javax.annotation.Nullable;
/*  14:    */ 
/*  15:    */ @GwtCompatible(emulated=true)
/*  16:    */ @Beta
/*  17:    */ public final class Enums
/*  18:    */ {
/*  19:    */   @GwtIncompatible("reflection")
/*  20:    */   public static Field getField(Enum<?> enumValue)
/*  21:    */   {
/*  22: 57 */     Class<?> clazz = enumValue.getDeclaringClass();
/*  23:    */     try
/*  24:    */     {
/*  25: 59 */       return clazz.getDeclaredField(enumValue.name());
/*  26:    */     }
/*  27:    */     catch (NoSuchFieldException impossible)
/*  28:    */     {
/*  29: 61 */       throw new AssertionError(impossible);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   @Deprecated
/*  34:    */   public static <T extends Enum<T>> Function<String, T> valueOfFunction(Class<T> enumClass)
/*  35:    */   {
/*  36: 80 */     return new ValueOfFunction(enumClass, null);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private static final class ValueOfFunction<T extends Enum<T>>
/*  40:    */     implements Function<String, T>, Serializable
/*  41:    */   {
/*  42:    */     private final Class<T> enumClass;
/*  43:    */     private static final long serialVersionUID = 0L;
/*  44:    */     
/*  45:    */     private ValueOfFunction(Class<T> enumClass)
/*  46:    */     {
/*  47: 93 */       this.enumClass = ((Class)Preconditions.checkNotNull(enumClass));
/*  48:    */     }
/*  49:    */     
/*  50:    */     public T apply(String value)
/*  51:    */     {
/*  52:    */       try
/*  53:    */       {
/*  54: 99 */         return Enum.valueOf(this.enumClass, value);
/*  55:    */       }
/*  56:    */       catch (IllegalArgumentException e) {}
/*  57:101 */       return null;
/*  58:    */     }
/*  59:    */     
/*  60:    */     public boolean equals(@Nullable Object obj)
/*  61:    */     {
/*  62:106 */       return ((obj instanceof ValueOfFunction)) && (this.enumClass.equals(((ValueOfFunction)obj).enumClass));
/*  63:    */     }
/*  64:    */     
/*  65:    */     public int hashCode()
/*  66:    */     {
/*  67:110 */       return this.enumClass.hashCode();
/*  68:    */     }
/*  69:    */     
/*  70:    */     public String toString()
/*  71:    */     {
/*  72:114 */       return "Enums.valueOf(" + this.enumClass + ")";
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <T extends Enum<T>> Optional<T> getIfPresent(Class<T> enumClass, String value)
/*  77:    */   {
/*  78:130 */     Preconditions.checkNotNull(enumClass);
/*  79:131 */     Preconditions.checkNotNull(value);
/*  80:132 */     return Platform.getEnumIfPresent(enumClass, value);
/*  81:    */   }
/*  82:    */   
/*  83:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  84:137 */   private static final Map<Class<? extends Enum<?>>, Map<String, WeakReference<? extends Enum<?>>>> enumConstantCache = new WeakHashMap();
/*  85:    */   
/*  86:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  87:    */   private static <T extends Enum<T>> Map<String, WeakReference<? extends Enum<?>>> populateCache(Class<T> enumClass)
/*  88:    */   {
/*  89:143 */     Map<String, WeakReference<? extends Enum<?>>> result = new HashMap();
/*  90:145 */     for (T enumInstance : EnumSet.allOf(enumClass)) {
/*  91:146 */       result.put(enumInstance.name(), new WeakReference(enumInstance));
/*  92:    */     }
/*  93:148 */     enumConstantCache.put(enumClass, result);
/*  94:149 */     return result;
/*  95:    */   }
/*  96:    */   
/*  97:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  98:    */   static <T extends Enum<T>> Map<String, WeakReference<? extends Enum<?>>> getEnumConstants(Class<T> enumClass)
/*  99:    */   {
/* 100:155 */     synchronized (enumConstantCache)
/* 101:    */     {
/* 102:156 */       Map<String, WeakReference<? extends Enum<?>>> constants = (Map)enumConstantCache.get(enumClass);
/* 103:158 */       if (constants == null) {
/* 104:159 */         constants = populateCache(enumClass);
/* 105:    */       }
/* 106:161 */       return constants;
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static <T extends Enum<T>> Converter<String, T> stringConverter(Class<T> enumClass)
/* 111:    */   {
/* 112:174 */     return new StringConverter(enumClass);
/* 113:    */   }
/* 114:    */   
/* 115:    */   private static final class StringConverter<T extends Enum<T>>
/* 116:    */     extends Converter<String, T>
/* 117:    */     implements Serializable
/* 118:    */   {
/* 119:    */     private final Class<T> enumClass;
/* 120:    */     private static final long serialVersionUID = 0L;
/* 121:    */     
/* 122:    */     StringConverter(Class<T> enumClass)
/* 123:    */     {
/* 124:183 */       this.enumClass = ((Class)Preconditions.checkNotNull(enumClass));
/* 125:    */     }
/* 126:    */     
/* 127:    */     protected T doForward(String value)
/* 128:    */     {
/* 129:188 */       return Enum.valueOf(this.enumClass, value);
/* 130:    */     }
/* 131:    */     
/* 132:    */     protected String doBackward(T enumValue)
/* 133:    */     {
/* 134:193 */       return enumValue.name();
/* 135:    */     }
/* 136:    */     
/* 137:    */     public boolean equals(@Nullable Object object)
/* 138:    */     {
/* 139:198 */       if ((object instanceof StringConverter))
/* 140:    */       {
/* 141:199 */         StringConverter<?> that = (StringConverter)object;
/* 142:200 */         return this.enumClass.equals(that.enumClass);
/* 143:    */       }
/* 144:202 */       return false;
/* 145:    */     }
/* 146:    */     
/* 147:    */     public int hashCode()
/* 148:    */     {
/* 149:207 */       return this.enumClass.hashCode();
/* 150:    */     }
/* 151:    */     
/* 152:    */     public String toString()
/* 153:    */     {
/* 154:212 */       return "Enums.stringConverter(" + this.enumClass.getName() + ".class)";
/* 155:    */     }
/* 156:    */   }
/* 157:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Enums
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ public final class Suppliers
/*  12:    */ {
/*  13:    */   public static <F, T> Supplier<T> compose(Function<? super F, T> function, Supplier<F> supplier)
/*  14:    */   {
/*  15: 51 */     Preconditions.checkNotNull(function);
/*  16: 52 */     Preconditions.checkNotNull(supplier);
/*  17: 53 */     return new SupplierComposition(function, supplier);
/*  18:    */   }
/*  19:    */   
/*  20:    */   private static class SupplierComposition<F, T>
/*  21:    */     implements Supplier<T>, Serializable
/*  22:    */   {
/*  23:    */     final Function<? super F, T> function;
/*  24:    */     final Supplier<F> supplier;
/*  25:    */     private static final long serialVersionUID = 0L;
/*  26:    */     
/*  27:    */     SupplierComposition(Function<? super F, T> function, Supplier<F> supplier)
/*  28:    */     {
/*  29: 62 */       this.function = function;
/*  30: 63 */       this.supplier = supplier;
/*  31:    */     }
/*  32:    */     
/*  33:    */     public T get()
/*  34:    */     {
/*  35: 67 */       return this.function.apply(this.supplier.get());
/*  36:    */     }
/*  37:    */     
/*  38:    */     public boolean equals(@Nullable Object obj)
/*  39:    */     {
/*  40: 71 */       if ((obj instanceof SupplierComposition))
/*  41:    */       {
/*  42: 72 */         SupplierComposition<?, ?> that = (SupplierComposition)obj;
/*  43: 73 */         return (this.function.equals(that.function)) && (this.supplier.equals(that.supplier));
/*  44:    */       }
/*  45: 75 */       return false;
/*  46:    */     }
/*  47:    */     
/*  48:    */     public int hashCode()
/*  49:    */     {
/*  50: 79 */       return Objects.hashCode(new Object[] { this.function, this.supplier });
/*  51:    */     }
/*  52:    */     
/*  53:    */     public String toString()
/*  54:    */     {
/*  55: 83 */       return "Suppliers.compose(" + this.function + ", " + this.supplier + ")";
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <T> Supplier<T> memoize(Supplier<T> delegate)
/*  60:    */   {
/*  61:103 */     return (delegate instanceof MemoizingSupplier) ? delegate : new MemoizingSupplier((Supplier)Preconditions.checkNotNull(delegate));
/*  62:    */   }
/*  63:    */   
/*  64:    */   @VisibleForTesting
/*  65:    */   static class MemoizingSupplier<T>
/*  66:    */     implements Supplier<T>, Serializable
/*  67:    */   {
/*  68:    */     final Supplier<T> delegate;
/*  69:    */     volatile transient boolean initialized;
/*  70:    */     transient T value;
/*  71:    */     private static final long serialVersionUID = 0L;
/*  72:    */     
/*  73:    */     MemoizingSupplier(Supplier<T> delegate)
/*  74:    */     {
/*  75:117 */       this.delegate = delegate;
/*  76:    */     }
/*  77:    */     
/*  78:    */     public T get()
/*  79:    */     {
/*  80:122 */       if (!this.initialized) {
/*  81:123 */         synchronized (this)
/*  82:    */         {
/*  83:124 */           if (!this.initialized)
/*  84:    */           {
/*  85:125 */             T t = this.delegate.get();
/*  86:126 */             this.value = t;
/*  87:127 */             this.initialized = true;
/*  88:128 */             return t;
/*  89:    */           }
/*  90:    */         }
/*  91:    */       }
/*  92:132 */       return this.value;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public String toString()
/*  96:    */     {
/*  97:136 */       return "Suppliers.memoize(" + this.delegate + ")";
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static <T> Supplier<T> memoizeWithExpiration(Supplier<T> delegate, long duration, TimeUnit unit)
/* 102:    */   {
/* 103:162 */     return new ExpiringMemoizingSupplier(delegate, duration, unit);
/* 104:    */   }
/* 105:    */   
/* 106:    */   @VisibleForTesting
/* 107:    */   static class ExpiringMemoizingSupplier<T>
/* 108:    */     implements Supplier<T>, Serializable
/* 109:    */   {
/* 110:    */     final Supplier<T> delegate;
/* 111:    */     final long durationNanos;
/* 112:    */     volatile transient T value;
/* 113:    */     volatile transient long expirationNanos;
/* 114:    */     private static final long serialVersionUID = 0L;
/* 115:    */     
/* 116:    */     ExpiringMemoizingSupplier(Supplier<T> delegate, long duration, TimeUnit unit)
/* 117:    */     {
/* 118:175 */       this.delegate = ((Supplier)Preconditions.checkNotNull(delegate));
/* 119:176 */       this.durationNanos = unit.toNanos(duration);
/* 120:177 */       Preconditions.checkArgument(duration > 0L);
/* 121:    */     }
/* 122:    */     
/* 123:    */     public T get()
/* 124:    */     {
/* 125:187 */       long nanos = this.expirationNanos;
/* 126:188 */       long now = Platform.systemNanoTime();
/* 127:189 */       if ((nanos == 0L) || (now - nanos >= 0L)) {
/* 128:190 */         synchronized (this)
/* 129:    */         {
/* 130:191 */           if (nanos == this.expirationNanos)
/* 131:    */           {
/* 132:192 */             T t = this.delegate.get();
/* 133:193 */             this.value = t;
/* 134:194 */             nanos = now + this.durationNanos;
/* 135:    */             
/* 136:    */ 
/* 137:197 */             this.expirationNanos = (nanos == 0L ? 1L : nanos);
/* 138:198 */             return t;
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:202 */       return this.value;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public String toString()
/* 146:    */     {
/* 147:208 */       return "Suppliers.memoizeWithExpiration(" + this.delegate + ", " + this.durationNanos + ", NANOS)";
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static <T> Supplier<T> ofInstance(@Nullable T instance)
/* 152:    */   {
/* 153:219 */     return new SupplierOfInstance(instance);
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static class SupplierOfInstance<T>
/* 157:    */     implements Supplier<T>, Serializable
/* 158:    */   {
/* 159:    */     final T instance;
/* 160:    */     private static final long serialVersionUID = 0L;
/* 161:    */     
/* 162:    */     SupplierOfInstance(@Nullable T instance)
/* 163:    */     {
/* 164:227 */       this.instance = instance;
/* 165:    */     }
/* 166:    */     
/* 167:    */     public T get()
/* 168:    */     {
/* 169:231 */       return this.instance;
/* 170:    */     }
/* 171:    */     
/* 172:    */     public boolean equals(@Nullable Object obj)
/* 173:    */     {
/* 174:235 */       if ((obj instanceof SupplierOfInstance))
/* 175:    */       {
/* 176:236 */         SupplierOfInstance<?> that = (SupplierOfInstance)obj;
/* 177:237 */         return Objects.equal(this.instance, that.instance);
/* 178:    */       }
/* 179:239 */       return false;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int hashCode()
/* 183:    */     {
/* 184:243 */       return Objects.hashCode(new Object[] { this.instance });
/* 185:    */     }
/* 186:    */     
/* 187:    */     public String toString()
/* 188:    */     {
/* 189:247 */       return "Suppliers.ofInstance(" + this.instance + ")";
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static <T> Supplier<T> synchronizedSupplier(Supplier<T> delegate)
/* 194:    */   {
/* 195:258 */     return new ThreadSafeSupplier((Supplier)Preconditions.checkNotNull(delegate));
/* 196:    */   }
/* 197:    */   
/* 198:    */   private static class ThreadSafeSupplier<T>
/* 199:    */     implements Supplier<T>, Serializable
/* 200:    */   {
/* 201:    */     final Supplier<T> delegate;
/* 202:    */     private static final long serialVersionUID = 0L;
/* 203:    */     
/* 204:    */     ThreadSafeSupplier(Supplier<T> delegate)
/* 205:    */     {
/* 206:266 */       this.delegate = delegate;
/* 207:    */     }
/* 208:    */     
/* 209:    */     public T get()
/* 210:    */     {
/* 211:270 */       synchronized (this.delegate)
/* 212:    */       {
/* 213:271 */         return this.delegate.get();
/* 214:    */       }
/* 215:    */     }
/* 216:    */     
/* 217:    */     public String toString()
/* 218:    */     {
/* 219:276 */       return "Suppliers.synchronizedSupplier(" + this.delegate + ")";
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   @Beta
/* 224:    */   public static <T> Function<Supplier<T>, T> supplierFunction()
/* 225:    */   {
/* 226:291 */     SupplierFunction<T> sf = SupplierFunctionImpl.INSTANCE;
/* 227:292 */     return sf;
/* 228:    */   }
/* 229:    */   
/* 230:    */   private static enum SupplierFunctionImpl
/* 231:    */     implements Suppliers.SupplierFunction<Object>
/* 232:    */   {
/* 233:298 */     INSTANCE;
/* 234:    */     
/* 235:    */     private SupplierFunctionImpl() {}
/* 236:    */     
/* 237:    */     public Object apply(Supplier<Object> input)
/* 238:    */     {
/* 239:302 */       return input.get();
/* 240:    */     }
/* 241:    */     
/* 242:    */     public String toString()
/* 243:    */     {
/* 244:306 */       return "Suppliers.supplierFunction()";
/* 245:    */     }
/* 246:    */   }
/* 247:    */   
/* 248:    */   private static abstract interface SupplierFunction<T>
/* 249:    */     extends Function<Supplier<T>, T>
/* 250:    */   {}
/* 251:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Suppliers
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.LinkedHashMap;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.regex.Matcher;
/*  13:    */ import java.util.regex.Pattern;
/*  14:    */ import javax.annotation.CheckReturnValue;
/*  15:    */ 
/*  16:    */ @GwtCompatible(emulated=true)
/*  17:    */ public final class Splitter
/*  18:    */ {
/*  19:    */   private final CharMatcher trimmer;
/*  20:    */   private final boolean omitEmptyStrings;
/*  21:    */   private final Strategy strategy;
/*  22:    */   private final int limit;
/*  23:    */   
/*  24:    */   private Splitter(Strategy strategy)
/*  25:    */   {
/*  26:110 */     this(strategy, false, CharMatcher.NONE, 2147483647);
/*  27:    */   }
/*  28:    */   
/*  29:    */   private Splitter(Strategy strategy, boolean omitEmptyStrings, CharMatcher trimmer, int limit)
/*  30:    */   {
/*  31:115 */     this.strategy = strategy;
/*  32:116 */     this.omitEmptyStrings = omitEmptyStrings;
/*  33:117 */     this.trimmer = trimmer;
/*  34:118 */     this.limit = limit;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static Splitter on(char separator)
/*  38:    */   {
/*  39:130 */     return on(CharMatcher.is(separator));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static Splitter on(CharMatcher separatorMatcher)
/*  43:    */   {
/*  44:144 */     Preconditions.checkNotNull(separatorMatcher);
/*  45:    */     
/*  46:146 */     new Splitter(new Strategy()
/*  47:    */     {
/*  48:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/*  49:    */       {
/*  50:149 */         new Splitter.SplittingIterator(splitter, toSplit)
/*  51:    */         {
/*  52:    */           int separatorStart(int start)
/*  53:    */           {
/*  54:151 */             return Splitter.1.this.val$separatorMatcher.indexIn(this.toSplit, start);
/*  55:    */           }
/*  56:    */           
/*  57:    */           int separatorEnd(int separatorPosition)
/*  58:    */           {
/*  59:155 */             return separatorPosition + 1;
/*  60:    */           }
/*  61:    */         };
/*  62:    */       }
/*  63:    */     });
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static Splitter on(String separator)
/*  67:    */   {
/*  68:171 */     Preconditions.checkArgument(separator.length() != 0, "The separator may not be the empty string.");
/*  69:    */     
/*  70:    */ 
/*  71:174 */     new Splitter(new Strategy()
/*  72:    */     {
/*  73:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/*  74:    */       {
/*  75:177 */         new Splitter.SplittingIterator(splitter, toSplit)
/*  76:    */         {
/*  77:    */           public int separatorStart(int start)
/*  78:    */           {
/*  79:179 */             int separatorLength = Splitter.2.this.val$separator.length();
/*  80:    */             
/*  81:    */ 
/*  82:182 */             int p = start;int last = this.toSplit.length() - separatorLength;
/*  83:    */             label80:
/*  84:183 */             for (; p <= last; p++)
/*  85:    */             {
/*  86:184 */               for (int i = 0; i < separatorLength; i++) {
/*  87:185 */                 if (this.toSplit.charAt(i + p) != Splitter.2.this.val$separator.charAt(i)) {
/*  88:    */                   break label80;
/*  89:    */                 }
/*  90:    */               }
/*  91:189 */               return p;
/*  92:    */             }
/*  93:191 */             return -1;
/*  94:    */           }
/*  95:    */           
/*  96:    */           public int separatorEnd(int separatorPosition)
/*  97:    */           {
/*  98:195 */             return separatorPosition + Splitter.2.this.val$separator.length();
/*  99:    */           }
/* 100:    */         };
/* 101:    */       }
/* 102:    */     });
/* 103:    */   }
/* 104:    */   
/* 105:    */   @GwtIncompatible("java.util.regex")
/* 106:    */   public static Splitter on(Pattern separatorPattern)
/* 107:    */   {
/* 108:216 */     Preconditions.checkNotNull(separatorPattern);
/* 109:217 */     Preconditions.checkArgument(!separatorPattern.matcher("").matches(), "The pattern may not match the empty string: %s", new Object[] { separatorPattern });
/* 110:    */     
/* 111:    */ 
/* 112:220 */     new Splitter(new Strategy()
/* 113:    */     {
/* 114:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/* 115:    */       {
/* 116:223 */         final Matcher matcher = this.val$separatorPattern.matcher(toSplit);
/* 117:224 */         new Splitter.SplittingIterator(splitter, toSplit)
/* 118:    */         {
/* 119:    */           public int separatorStart(int start)
/* 120:    */           {
/* 121:226 */             return matcher.find(start) ? matcher.start() : -1;
/* 122:    */           }
/* 123:    */           
/* 124:    */           public int separatorEnd(int separatorPosition)
/* 125:    */           {
/* 126:230 */             return matcher.end();
/* 127:    */           }
/* 128:    */         };
/* 129:    */       }
/* 130:    */     });
/* 131:    */   }
/* 132:    */   
/* 133:    */   @GwtIncompatible("java.util.regex")
/* 134:    */   public static Splitter onPattern(String separatorPattern)
/* 135:    */   {
/* 136:254 */     return on(Pattern.compile(separatorPattern));
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static Splitter fixedLength(int length)
/* 140:    */   {
/* 141:277 */     Preconditions.checkArgument(length > 0, "The length may not be less than 1");
/* 142:    */     
/* 143:279 */     new Splitter(new Strategy()
/* 144:    */     {
/* 145:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/* 146:    */       {
/* 147:282 */         new Splitter.SplittingIterator(splitter, toSplit)
/* 148:    */         {
/* 149:    */           public int separatorStart(int start)
/* 150:    */           {
/* 151:284 */             int nextChunkStart = start + Splitter.4.this.val$length;
/* 152:285 */             return nextChunkStart < this.toSplit.length() ? nextChunkStart : -1;
/* 153:    */           }
/* 154:    */           
/* 155:    */           public int separatorEnd(int separatorPosition)
/* 156:    */           {
/* 157:289 */             return separatorPosition;
/* 158:    */           }
/* 159:    */         };
/* 160:    */       }
/* 161:    */     });
/* 162:    */   }
/* 163:    */   
/* 164:    */   @CheckReturnValue
/* 165:    */   public Splitter omitEmptyStrings()
/* 166:    */   {
/* 167:316 */     return new Splitter(this.strategy, true, this.trimmer, this.limit);
/* 168:    */   }
/* 169:    */   
/* 170:    */   @CheckReturnValue
/* 171:    */   public Splitter limit(int limit)
/* 172:    */   {
/* 173:340 */     Preconditions.checkArgument(limit > 0, "must be greater than zero: %s", new Object[] { Integer.valueOf(limit) });
/* 174:341 */     return new Splitter(this.strategy, this.omitEmptyStrings, this.trimmer, limit);
/* 175:    */   }
/* 176:    */   
/* 177:    */   @CheckReturnValue
/* 178:    */   public Splitter trimResults()
/* 179:    */   {
/* 180:356 */     return trimResults(CharMatcher.WHITESPACE);
/* 181:    */   }
/* 182:    */   
/* 183:    */   @CheckReturnValue
/* 184:    */   public Splitter trimResults(CharMatcher trimmer)
/* 185:    */   {
/* 186:373 */     Preconditions.checkNotNull(trimmer);
/* 187:374 */     return new Splitter(this.strategy, this.omitEmptyStrings, trimmer, this.limit);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Iterable<String> split(final CharSequence sequence)
/* 191:    */   {
/* 192:386 */     Preconditions.checkNotNull(sequence);
/* 193:    */     
/* 194:388 */     new Iterable()
/* 195:    */     {
/* 196:    */       public Iterator<String> iterator()
/* 197:    */       {
/* 198:390 */         return Splitter.this.splittingIterator(sequence);
/* 199:    */       }
/* 200:    */       
/* 201:    */       public String toString()
/* 202:    */       {
/* 203:393 */         return ']';
/* 204:    */       }
/* 205:    */     };
/* 206:    */   }
/* 207:    */   
/* 208:    */   private Iterator<String> splittingIterator(CharSequence sequence)
/* 209:    */   {
/* 210:402 */     return this.strategy.iterator(this, sequence);
/* 211:    */   }
/* 212:    */   
/* 213:    */   @Beta
/* 214:    */   public List<String> splitToList(CharSequence sequence)
/* 215:    */   {
/* 216:416 */     Preconditions.checkNotNull(sequence);
/* 217:    */     
/* 218:418 */     Iterator<String> iterator = splittingIterator(sequence);
/* 219:419 */     List<String> result = new ArrayList();
/* 220:421 */     while (iterator.hasNext()) {
/* 221:422 */       result.add(iterator.next());
/* 222:    */     }
/* 223:425 */     return Collections.unmodifiableList(result);
/* 224:    */   }
/* 225:    */   
/* 226:    */   @CheckReturnValue
/* 227:    */   @Beta
/* 228:    */   public MapSplitter withKeyValueSeparator(String separator)
/* 229:    */   {
/* 230:437 */     return withKeyValueSeparator(on(separator));
/* 231:    */   }
/* 232:    */   
/* 233:    */   @CheckReturnValue
/* 234:    */   @Beta
/* 235:    */   public MapSplitter withKeyValueSeparator(char separator)
/* 236:    */   {
/* 237:449 */     return withKeyValueSeparator(on(separator));
/* 238:    */   }
/* 239:    */   
/* 240:    */   @CheckReturnValue
/* 241:    */   @Beta
/* 242:    */   public MapSplitter withKeyValueSeparator(Splitter keyValueSplitter)
/* 243:    */   {
/* 244:462 */     return new MapSplitter(this, keyValueSplitter, null);
/* 245:    */   }
/* 246:    */   
/* 247:    */   @Beta
/* 248:    */   public static final class MapSplitter
/* 249:    */   {
/* 250:    */     private static final String INVALID_ENTRY_MESSAGE = "Chunk [%s] is not a valid entry";
/* 251:    */     private final Splitter outerSplitter;
/* 252:    */     private final Splitter entrySplitter;
/* 253:    */     
/* 254:    */     private MapSplitter(Splitter outerSplitter, Splitter entrySplitter)
/* 255:    */     {
/* 256:480 */       this.outerSplitter = outerSplitter;
/* 257:481 */       this.entrySplitter = ((Splitter)Preconditions.checkNotNull(entrySplitter));
/* 258:    */     }
/* 259:    */     
/* 260:    */     public Map<String, String> split(CharSequence sequence)
/* 261:    */     {
/* 262:500 */       Map<String, String> map = new LinkedHashMap();
/* 263:501 */       for (String entry : this.outerSplitter.split(sequence))
/* 264:    */       {
/* 265:502 */         Iterator<String> entryFields = this.entrySplitter.splittingIterator(entry);
/* 266:    */         
/* 267:504 */         Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 268:505 */         String key = (String)entryFields.next();
/* 269:506 */         Preconditions.checkArgument(!map.containsKey(key), "Duplicate key [%s] found.", new Object[] { key });
/* 270:    */         
/* 271:508 */         Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 272:509 */         String value = (String)entryFields.next();
/* 273:510 */         map.put(key, value);
/* 274:    */         
/* 275:512 */         Preconditions.checkArgument(!entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 276:    */       }
/* 277:514 */       return Collections.unmodifiableMap(map);
/* 278:    */     }
/* 279:    */   }
/* 280:    */   
/* 281:    */   private static abstract class SplittingIterator
/* 282:    */     extends AbstractIterator<String>
/* 283:    */   {
/* 284:    */     final CharSequence toSplit;
/* 285:    */     final CharMatcher trimmer;
/* 286:    */     final boolean omitEmptyStrings;
/* 287:540 */     int offset = 0;
/* 288:    */     int limit;
/* 289:    */     
/* 290:    */     abstract int separatorStart(int paramInt);
/* 291:    */     
/* 292:    */     abstract int separatorEnd(int paramInt);
/* 293:    */     
/* 294:    */     protected SplittingIterator(Splitter splitter, CharSequence toSplit)
/* 295:    */     {
/* 296:544 */       this.trimmer = splitter.trimmer;
/* 297:545 */       this.omitEmptyStrings = splitter.omitEmptyStrings;
/* 298:546 */       this.limit = splitter.limit;
/* 299:547 */       this.toSplit = toSplit;
/* 300:    */     }
/* 301:    */     
/* 302:    */     protected String computeNext()
/* 303:    */     {
/* 304:557 */       int nextStart = this.offset;
/* 305:558 */       while (this.offset != -1)
/* 306:    */       {
/* 307:559 */         int start = nextStart;
/* 308:    */         
/* 309:    */ 
/* 310:562 */         int separatorPosition = separatorStart(this.offset);
/* 311:    */         int end;
/* 312:563 */         if (separatorPosition == -1)
/* 313:    */         {
/* 314:564 */           int end = this.toSplit.length();
/* 315:565 */           this.offset = -1;
/* 316:    */         }
/* 317:    */         else
/* 318:    */         {
/* 319:567 */           end = separatorPosition;
/* 320:568 */           this.offset = separatorEnd(separatorPosition);
/* 321:    */         }
/* 322:570 */         if (this.offset == nextStart)
/* 323:    */         {
/* 324:578 */           this.offset += 1;
/* 325:579 */           if (this.offset >= this.toSplit.length()) {
/* 326:580 */             this.offset = -1;
/* 327:    */           }
/* 328:    */         }
/* 329:    */         else
/* 330:    */         {
/* 331:585 */           while ((start < end) && (this.trimmer.matches(this.toSplit.charAt(start)))) {
/* 332:586 */             start++;
/* 333:    */           }
/* 334:588 */           while ((end > start) && (this.trimmer.matches(this.toSplit.charAt(end - 1)))) {
/* 335:589 */             end--;
/* 336:    */           }
/* 337:592 */           if ((this.omitEmptyStrings) && (start == end))
/* 338:    */           {
/* 339:594 */             nextStart = this.offset;
/* 340:    */           }
/* 341:    */           else
/* 342:    */           {
/* 343:598 */             if (this.limit == 1)
/* 344:    */             {
/* 345:602 */               end = this.toSplit.length();
/* 346:603 */               this.offset = -1;
/* 347:605 */               while ((end > start) && (this.trimmer.matches(this.toSplit.charAt(end - 1)))) {
/* 348:606 */                 end--;
/* 349:    */               }
/* 350:    */             }
/* 351:609 */             this.limit -= 1;
/* 352:    */             
/* 353:    */ 
/* 354:612 */             return this.toSplit.subSequence(start, end).toString();
/* 355:    */           }
/* 356:    */         }
/* 357:    */       }
/* 358:614 */       return (String)endOfData();
/* 359:    */     }
/* 360:    */   }
/* 361:    */   
/* 362:    */   private static abstract interface Strategy
/* 363:    */   {
/* 364:    */     public abstract Iterator<String> iterator(Splitter paramSplitter, CharSequence paramCharSequence);
/* 365:    */   }
/* 366:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Splitter
 * JD-Core Version:    0.7.0.1
 */
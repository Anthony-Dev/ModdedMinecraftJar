/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Iterator;
/*  5:   */ import java.util.NoSuchElementException;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ abstract class AbstractIterator<T>
/*  9:   */   implements Iterator<T>
/* 10:   */ {
/* 11:32 */   private State state = State.NOT_READY;
/* 12:   */   private T next;
/* 13:   */   protected abstract T computeNext();
/* 14:   */   
/* 15:   */   private static enum State
/* 16:   */   {
/* 17:37 */     READY,  NOT_READY,  DONE,  FAILED;
/* 18:   */     
/* 19:   */     private State() {}
/* 20:   */   }
/* 21:   */   
/* 22:   */   protected final T endOfData()
/* 23:   */   {
/* 24:45 */     this.state = State.DONE;
/* 25:46 */     return null;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public final boolean hasNext()
/* 29:   */   {
/* 30:51 */     Preconditions.checkState(this.state != State.FAILED);
/* 31:52 */     switch (1.$SwitchMap$com$google$common$base$AbstractIterator$State[this.state.ordinal()])
/* 32:   */     {
/* 33:   */     case 1: 
/* 34:54 */       return false;
/* 35:   */     case 2: 
/* 36:56 */       return true;
/* 37:   */     }
/* 38:59 */     return tryToComputeNext();
/* 39:   */   }
/* 40:   */   
/* 41:   */   private boolean tryToComputeNext()
/* 42:   */   {
/* 43:63 */     this.state = State.FAILED;
/* 44:64 */     this.next = computeNext();
/* 45:65 */     if (this.state != State.DONE)
/* 46:   */     {
/* 47:66 */       this.state = State.READY;
/* 48:67 */       return true;
/* 49:   */     }
/* 50:69 */     return false;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public final T next()
/* 54:   */   {
/* 55:74 */     if (!hasNext()) {
/* 56:75 */       throw new NoSuchElementException();
/* 57:   */     }
/* 58:77 */     this.state = State.NOT_READY;
/* 59:78 */     T result = this.next;
/* 60:79 */     this.next = null;
/* 61:80 */     return result;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public final void remove()
/* 65:   */   {
/* 66:84 */     throw new UnsupportedOperationException();
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.AbstractIterator
 * JD-Core Version:    0.7.0.1
 */
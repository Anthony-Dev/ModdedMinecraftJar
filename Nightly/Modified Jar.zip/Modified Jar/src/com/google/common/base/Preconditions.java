/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ @GwtCompatible
/*   7:    */ public final class Preconditions
/*   8:    */ {
/*   9:    */   public static void checkArgument(boolean expression)
/*  10:    */   {
/*  11:110 */     if (!expression) {
/*  12:111 */       throw new IllegalArgumentException();
/*  13:    */     }
/*  14:    */   }
/*  15:    */   
/*  16:    */   public static void checkArgument(boolean expression, @Nullable Object errorMessage)
/*  17:    */   {
/*  18:124 */     if (!expression) {
/*  19:125 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*  20:    */     }
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static void checkArgument(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  24:    */   {
/*  25:147 */     if (!expression) {
/*  26:148 */       throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void checkState(boolean expression)
/*  31:    */   {
/*  32:160 */     if (!expression) {
/*  33:161 */       throw new IllegalStateException();
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void checkState(boolean expression, @Nullable Object errorMessage)
/*  38:    */   {
/*  39:175 */     if (!expression) {
/*  40:176 */       throw new IllegalStateException(String.valueOf(errorMessage));
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void checkState(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  45:    */   {
/*  46:199 */     if (!expression) {
/*  47:200 */       throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <T> T checkNotNull(T reference)
/*  52:    */   {
/*  53:212 */     if (reference == null) {
/*  54:213 */       throw new NullPointerException();
/*  55:    */     }
/*  56:215 */     return reference;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <T> T checkNotNull(T reference, @Nullable Object errorMessage)
/*  60:    */   {
/*  61:228 */     if (reference == null) {
/*  62:229 */       throw new NullPointerException(String.valueOf(errorMessage));
/*  63:    */     }
/*  64:231 */     return reference;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <T> T checkNotNull(T reference, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  68:    */   {
/*  69:251 */     if (reference == null) {
/*  70:253 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*  71:    */     }
/*  72:255 */     return reference;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int checkElementIndex(int index, int size)
/*  76:    */   {
/*  77:295 */     return checkElementIndex(index, size, "index");
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static int checkElementIndex(int index, int size, @Nullable String desc)
/*  81:    */   {
/*  82:312 */     if ((index < 0) || (index >= size)) {
/*  83:313 */       throw new IndexOutOfBoundsException(badElementIndex(index, size, desc));
/*  84:    */     }
/*  85:315 */     return index;
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static String badElementIndex(int index, int size, String desc)
/*  89:    */   {
/*  90:319 */     if (index < 0) {
/*  91:320 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/*  92:    */     }
/*  93:321 */     if (size < 0) {
/*  94:322 */       throw new IllegalArgumentException("negative size: " + size);
/*  95:    */     }
/*  96:324 */     return format("%s (%s) must be less than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int checkPositionIndex(int index, int size)
/* 100:    */   {
/* 101:339 */     return checkPositionIndex(index, size, "index");
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static int checkPositionIndex(int index, int size, @Nullable String desc)
/* 105:    */   {
/* 106:355 */     if ((index < 0) || (index > size)) {
/* 107:356 */       throw new IndexOutOfBoundsException(badPositionIndex(index, size, desc));
/* 108:    */     }
/* 109:358 */     return index;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static String badPositionIndex(int index, int size, String desc)
/* 113:    */   {
/* 114:362 */     if (index < 0) {
/* 115:363 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/* 116:    */     }
/* 117:364 */     if (size < 0) {
/* 118:365 */       throw new IllegalArgumentException("negative size: " + size);
/* 119:    */     }
/* 120:367 */     return format("%s (%s) must not be greater than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static void checkPositionIndexes(int start, int end, int size)
/* 124:    */   {
/* 125:385 */     if ((start < 0) || (end < start) || (end > size)) {
/* 126:386 */       throw new IndexOutOfBoundsException(badPositionIndexes(start, end, size));
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static String badPositionIndexes(int start, int end, int size)
/* 131:    */   {
/* 132:391 */     if ((start < 0) || (start > size)) {
/* 133:392 */       return badPositionIndex(start, size, "start index");
/* 134:    */     }
/* 135:394 */     if ((end < 0) || (end > size)) {
/* 136:395 */       return badPositionIndex(end, size, "end index");
/* 137:    */     }
/* 138:398 */     return format("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(end), Integer.valueOf(start) });
/* 139:    */   }
/* 140:    */   
/* 141:    */   static String format(String template, @Nullable Object... args)
/* 142:    */   {
/* 143:413 */     template = String.valueOf(template);
/* 144:    */     
/* 145:    */ 
/* 146:416 */     StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
/* 147:417 */     int templateStart = 0;
/* 148:418 */     int i = 0;
/* 149:419 */     while (i < args.length)
/* 150:    */     {
/* 151:420 */       int placeholderStart = template.indexOf("%s", templateStart);
/* 152:421 */       if (placeholderStart == -1) {
/* 153:    */         break;
/* 154:    */       }
/* 155:424 */       builder.append(template.substring(templateStart, placeholderStart));
/* 156:425 */       builder.append(args[(i++)]);
/* 157:426 */       templateStart = placeholderStart + 2;
/* 158:    */     }
/* 159:428 */     builder.append(template.substring(templateStart));
/* 160:431 */     if (i < args.length)
/* 161:    */     {
/* 162:432 */       builder.append(" [");
/* 163:433 */       builder.append(args[(i++)]);
/* 164:434 */       while (i < args.length)
/* 165:    */       {
/* 166:435 */         builder.append(", ");
/* 167:436 */         builder.append(args[(i++)]);
/* 168:    */       }
/* 169:438 */       builder.append(']');
/* 170:    */     }
/* 171:441 */     return builder.toString();
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Preconditions
 * JD-Core Version:    0.7.0.1
 */
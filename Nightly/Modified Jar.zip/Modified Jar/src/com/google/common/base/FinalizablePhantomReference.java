/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import java.lang.ref.PhantomReference;
/*  4:   */ 
/*  5:   */ public abstract class FinalizablePhantomReference<T>
/*  6:   */   extends PhantomReference<T>
/*  7:   */   implements FinalizableReference
/*  8:   */ {
/*  9:   */   protected FinalizablePhantomReference(T referent, FinalizableReferenceQueue queue)
/* 10:   */   {
/* 11:41 */     super(referent, queue.queue);
/* 12:42 */     queue.cleanUp();
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.FinalizablePhantomReference
 * JD-Core Version:    0.7.0.1
 */
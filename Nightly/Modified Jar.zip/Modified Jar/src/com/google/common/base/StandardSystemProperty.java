/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ 
/*   6:    */ @Beta
/*   7:    */ @GwtIncompatible("java.lang.System#getProperty")
/*   8:    */ public enum StandardSystemProperty
/*   9:    */ {
/*  10: 33 */   JAVA_VERSION("java.version"),  JAVA_VENDOR("java.vendor"),  JAVA_VENDOR_URL("java.vendor.url"),  JAVA_HOME("java.home"),  JAVA_VM_SPECIFICATION_VERSION("java.vm.specification.version"),  JAVA_VM_SPECIFICATION_VENDOR("java.vm.specification.vendor"),  JAVA_VM_SPECIFICATION_NAME("java.vm.specification.name"),  JAVA_VM_VERSION("java.vm.version"),  JAVA_VM_VENDOR("java.vm.vendor"),  JAVA_VM_NAME("java.vm.name"),  JAVA_SPECIFICATION_VERSION("java.specification.version"),  JAVA_SPECIFICATION_VENDOR("java.specification.vendor"),  JAVA_SPECIFICATION_NAME("java.specification.name"),  JAVA_CLASS_VERSION("java.class.version"),  JAVA_CLASS_PATH("java.class.path"),  JAVA_LIBRARY_PATH("java.library.path"),  JAVA_IO_TMPDIR("java.io.tmpdir"),  JAVA_COMPILER("java.compiler"),  JAVA_EXT_DIRS("java.ext.dirs"),  OS_NAME("os.name"),  OS_ARCH("os.arch"),  OS_VERSION("os.version"),  FILE_SEPARATOR("file.separator"),  PATH_SEPARATOR("path.separator"),  LINE_SEPARATOR("line.separator"),  USER_NAME("user.name"),  USER_HOME("user.home"),  USER_DIR("user.dir");
/*  11:    */   
/*  12:    */   private final String key;
/*  13:    */   
/*  14:    */   private StandardSystemProperty(String key)
/*  15:    */   {
/*  16:119 */     this.key = key;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public String key()
/*  20:    */   {
/*  21:126 */     return this.key;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public String value()
/*  25:    */   {
/*  26:134 */     return System.getProperty(this.key);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public String toString()
/*  30:    */   {
/*  31:141 */     return key() + "=" + value();
/*  32:    */   }
/*  33:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.StandardSystemProperty
 * JD-Core Version:    0.7.0.1
 */
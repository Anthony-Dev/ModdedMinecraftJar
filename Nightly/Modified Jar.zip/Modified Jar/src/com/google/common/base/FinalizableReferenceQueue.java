/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import java.io.Closeable;
/*   5:    */ import java.io.FileNotFoundException;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.lang.ref.PhantomReference;
/*   8:    */ import java.lang.ref.Reference;
/*   9:    */ import java.lang.ref.ReferenceQueue;
/*  10:    */ import java.lang.reflect.Method;
/*  11:    */ import java.net.URL;
/*  12:    */ import java.net.URLClassLoader;
/*  13:    */ import java.util.logging.Level;
/*  14:    */ import java.util.logging.Logger;
/*  15:    */ 
/*  16:    */ public class FinalizableReferenceQueue
/*  17:    */   implements Closeable
/*  18:    */ {
/*  19:129 */   private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
/*  20:    */   private static final String FINALIZER_CLASS_NAME = "com.google.common.base.internal.Finalizer";
/*  21:    */   private static final Method startFinalizer;
/*  22:    */   final ReferenceQueue<Object> queue;
/*  23:    */   final PhantomReference<Object> frqRef;
/*  24:    */   final boolean threadStarted;
/*  25:    */   
/*  26:    */   static
/*  27:    */   {
/*  28:136 */     Class<?> finalizer = loadFinalizer(new FinalizerLoader[] { new SystemLoader(), new DecoupledLoader(), new DirectLoader() });
/*  29:    */     
/*  30:138 */     startFinalizer = getStartFinalizer(finalizer);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public FinalizableReferenceQueue()
/*  34:    */   {
/*  35:158 */     this.queue = new ReferenceQueue();
/*  36:159 */     this.frqRef = new PhantomReference(this, this.queue);
/*  37:160 */     boolean threadStarted = false;
/*  38:    */     try
/*  39:    */     {
/*  40:162 */       startFinalizer.invoke(null, new Object[] { FinalizableReference.class, this.queue, this.frqRef });
/*  41:163 */       threadStarted = true;
/*  42:    */     }
/*  43:    */     catch (IllegalAccessException impossible)
/*  44:    */     {
/*  45:165 */       throw new AssertionError(impossible);
/*  46:    */     }
/*  47:    */     catch (Throwable t)
/*  48:    */     {
/*  49:167 */       logger.log(Level.INFO, "Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created.", t);
/*  50:    */     }
/*  51:171 */     this.threadStarted = threadStarted;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void close()
/*  55:    */   {
/*  56:176 */     this.frqRef.enqueue();
/*  57:177 */     cleanUp();
/*  58:    */   }
/*  59:    */   
/*  60:    */   void cleanUp()
/*  61:    */   {
/*  62:186 */     if (this.threadStarted) {
/*  63:    */       return;
/*  64:    */     }
/*  65:    */     Reference<?> reference;
/*  66:191 */     while ((reference = this.queue.poll()) != null)
/*  67:    */     {
/*  68:196 */       reference.clear();
/*  69:    */       try
/*  70:    */       {
/*  71:198 */         ((FinalizableReference)reference).finalizeReferent();
/*  72:    */       }
/*  73:    */       catch (Throwable t)
/*  74:    */       {
/*  75:200 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*  76:    */       }
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static Class<?> loadFinalizer(FinalizerLoader... loaders)
/*  81:    */   {
/*  82:211 */     for (FinalizerLoader loader : loaders)
/*  83:    */     {
/*  84:212 */       Class<?> finalizer = loader.loadFinalizer();
/*  85:213 */       if (finalizer != null) {
/*  86:214 */         return finalizer;
/*  87:    */       }
/*  88:    */     }
/*  89:218 */     throw new AssertionError();
/*  90:    */   }
/*  91:    */   
/*  92:    */   static class SystemLoader
/*  93:    */     implements FinalizableReferenceQueue.FinalizerLoader
/*  94:    */   {
/*  95:    */     @VisibleForTesting
/*  96:    */     static boolean disabled;
/*  97:    */     
/*  98:    */     public Class<?> loadFinalizer()
/*  99:    */     {
/* 100:246 */       if (disabled) {
/* 101:247 */         return null;
/* 102:    */       }
/* 103:    */       ClassLoader systemLoader;
/* 104:    */       try
/* 105:    */       {
/* 106:251 */         systemLoader = ClassLoader.getSystemClassLoader();
/* 107:    */       }
/* 108:    */       catch (SecurityException e)
/* 109:    */       {
/* 110:253 */         FinalizableReferenceQueue.logger.info("Not allowed to access system class loader.");
/* 111:254 */         return null;
/* 112:    */       }
/* 113:256 */       if (systemLoader != null) {
/* 114:    */         try
/* 115:    */         {
/* 116:258 */           return systemLoader.loadClass("com.google.common.base.internal.Finalizer");
/* 117:    */         }
/* 118:    */         catch (ClassNotFoundException e)
/* 119:    */         {
/* 120:261 */           return null;
/* 121:    */         }
/* 122:    */       }
/* 123:264 */       return null;
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   static class DecoupledLoader
/* 128:    */     implements FinalizableReferenceQueue.FinalizerLoader
/* 129:    */   {
/* 130:    */     private static final String LOADING_ERROR = "Could not load Finalizer in its own class loader.Loading Finalizer in the current class loader instead. As a result, you will not be ableto garbage collect this class loader. To support reclaiming this class loader, eitherresolve the underlying issue, or move Google Collections to your system class path.";
/* 131:    */     
/* 132:    */     public Class<?> loadFinalizer()
/* 133:    */     {
/* 134:    */       try
/* 135:    */       {
/* 136:292 */         ClassLoader finalizerLoader = newLoader(getBaseUrl());
/* 137:293 */         return finalizerLoader.loadClass("com.google.common.base.internal.Finalizer");
/* 138:    */       }
/* 139:    */       catch (Exception e)
/* 140:    */       {
/* 141:295 */         FinalizableReferenceQueue.logger.log(Level.WARNING, "Could not load Finalizer in its own class loader.Loading Finalizer in the current class loader instead. As a result, you will not be ableto garbage collect this class loader. To support reclaiming this class loader, eitherresolve the underlying issue, or move Google Collections to your system class path.", e);
/* 142:    */       }
/* 143:296 */       return null;
/* 144:    */     }
/* 145:    */     
/* 146:    */     URL getBaseUrl()
/* 147:    */       throws IOException
/* 148:    */     {
/* 149:305 */       String finalizerPath = "com.google.common.base.internal.Finalizer".replace('.', '/') + ".class";
/* 150:306 */       URL finalizerUrl = getClass().getClassLoader().getResource(finalizerPath);
/* 151:307 */       if (finalizerUrl == null) {
/* 152:308 */         throw new FileNotFoundException(finalizerPath);
/* 153:    */       }
/* 154:312 */       String urlString = finalizerUrl.toString();
/* 155:313 */       if (!urlString.endsWith(finalizerPath)) {
/* 156:314 */         throw new IOException("Unsupported path style: " + urlString);
/* 157:    */       }
/* 158:316 */       urlString = urlString.substring(0, urlString.length() - finalizerPath.length());
/* 159:317 */       return new URL(finalizerUrl, urlString);
/* 160:    */     }
/* 161:    */     
/* 162:    */     URLClassLoader newLoader(URL base)
/* 163:    */     {
/* 164:325 */       return new URLClassLoader(new URL[] { base }, null);
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   static class DirectLoader
/* 169:    */     implements FinalizableReferenceQueue.FinalizerLoader
/* 170:    */   {
/* 171:    */     public Class<?> loadFinalizer()
/* 172:    */     {
/* 173:    */       try
/* 174:    */       {
/* 175:337 */         return Class.forName("com.google.common.base.internal.Finalizer");
/* 176:    */       }
/* 177:    */       catch (ClassNotFoundException e)
/* 178:    */       {
/* 179:339 */         throw new AssertionError(e);
/* 180:    */       }
/* 181:    */     }
/* 182:    */   }
/* 183:    */   
/* 184:    */   static Method getStartFinalizer(Class<?> finalizer)
/* 185:    */   {
/* 186:    */     try
/* 187:    */     {
/* 188:349 */       return finalizer.getMethod("startFinalizer", new Class[] { Class.class, ReferenceQueue.class, PhantomReference.class });
/* 189:    */     }
/* 190:    */     catch (NoSuchMethodException e)
/* 191:    */     {
/* 192:355 */       throw new AssertionError(e);
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   static abstract interface FinalizerLoader
/* 197:    */   {
/* 198:    */     public abstract Class<?> loadFinalizer();
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.FinalizableReferenceQueue
 * JD-Core Version:    0.7.0.1
 */
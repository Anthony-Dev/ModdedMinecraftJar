/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public final class Objects
/*  10:    */ {
/*  11:    */   @CheckReturnValue
/*  12:    */   public static boolean equal(@Nullable Object a, @Nullable Object b)
/*  13:    */   {
/*  14: 57 */     return (a == b) || ((a != null) && (a.equals(b)));
/*  15:    */   }
/*  16:    */   
/*  17:    */   public static int hashCode(@Nullable Object... objects)
/*  18:    */   {
/*  19: 78 */     return Arrays.hashCode(objects);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static ToStringHelper toStringHelper(Object self)
/*  23:    */   {
/*  24:121 */     return new ToStringHelper(simpleName(self.getClass()), null);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static ToStringHelper toStringHelper(Class<?> clazz)
/*  28:    */   {
/*  29:135 */     return new ToStringHelper(simpleName(clazz), null);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static ToStringHelper toStringHelper(String className)
/*  33:    */   {
/*  34:147 */     return new ToStringHelper(className, null);
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static String simpleName(Class<?> clazz)
/*  38:    */   {
/*  39:155 */     String name = clazz.getName();
/*  40:    */     
/*  41:    */ 
/*  42:    */ 
/*  43:159 */     name = name.replaceAll("\\$[0-9]+", "\\$");
/*  44:    */     
/*  45:    */ 
/*  46:162 */     int start = name.lastIndexOf('$');
/*  47:166 */     if (start == -1) {
/*  48:167 */       start = name.lastIndexOf('.');
/*  49:    */     }
/*  50:169 */     return name.substring(start + 1);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <T> T firstNonNull(@Nullable T first, @Nullable T second)
/*  54:    */   {
/*  55:190 */     return first != null ? first : Preconditions.checkNotNull(second);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static final class ToStringHelper
/*  59:    */   {
/*  60:    */     private final String className;
/*  61:201 */     private ValueHolder holderHead = new ValueHolder(null);
/*  62:202 */     private ValueHolder holderTail = this.holderHead;
/*  63:203 */     private boolean omitNullValues = false;
/*  64:    */     
/*  65:    */     private ToStringHelper(String className)
/*  66:    */     {
/*  67:209 */       this.className = ((String)Preconditions.checkNotNull(className));
/*  68:    */     }
/*  69:    */     
/*  70:    */     public ToStringHelper omitNullValues()
/*  71:    */     {
/*  72:220 */       this.omitNullValues = true;
/*  73:221 */       return this;
/*  74:    */     }
/*  75:    */     
/*  76:    */     public ToStringHelper add(String name, @Nullable Object value)
/*  77:    */     {
/*  78:231 */       return addHolder(name, value);
/*  79:    */     }
/*  80:    */     
/*  81:    */     public ToStringHelper add(String name, boolean value)
/*  82:    */     {
/*  83:241 */       return addHolder(name, String.valueOf(value));
/*  84:    */     }
/*  85:    */     
/*  86:    */     public ToStringHelper add(String name, char value)
/*  87:    */     {
/*  88:251 */       return addHolder(name, String.valueOf(value));
/*  89:    */     }
/*  90:    */     
/*  91:    */     public ToStringHelper add(String name, double value)
/*  92:    */     {
/*  93:261 */       return addHolder(name, String.valueOf(value));
/*  94:    */     }
/*  95:    */     
/*  96:    */     public ToStringHelper add(String name, float value)
/*  97:    */     {
/*  98:271 */       return addHolder(name, String.valueOf(value));
/*  99:    */     }
/* 100:    */     
/* 101:    */     public ToStringHelper add(String name, int value)
/* 102:    */     {
/* 103:281 */       return addHolder(name, String.valueOf(value));
/* 104:    */     }
/* 105:    */     
/* 106:    */     public ToStringHelper add(String name, long value)
/* 107:    */     {
/* 108:291 */       return addHolder(name, String.valueOf(value));
/* 109:    */     }
/* 110:    */     
/* 111:    */     public ToStringHelper addValue(@Nullable Object value)
/* 112:    */     {
/* 113:301 */       return addHolder(value);
/* 114:    */     }
/* 115:    */     
/* 116:    */     public ToStringHelper addValue(boolean value)
/* 117:    */     {
/* 118:313 */       return addHolder(String.valueOf(value));
/* 119:    */     }
/* 120:    */     
/* 121:    */     public ToStringHelper addValue(char value)
/* 122:    */     {
/* 123:325 */       return addHolder(String.valueOf(value));
/* 124:    */     }
/* 125:    */     
/* 126:    */     public ToStringHelper addValue(double value)
/* 127:    */     {
/* 128:337 */       return addHolder(String.valueOf(value));
/* 129:    */     }
/* 130:    */     
/* 131:    */     public ToStringHelper addValue(float value)
/* 132:    */     {
/* 133:349 */       return addHolder(String.valueOf(value));
/* 134:    */     }
/* 135:    */     
/* 136:    */     public ToStringHelper addValue(int value)
/* 137:    */     {
/* 138:361 */       return addHolder(String.valueOf(value));
/* 139:    */     }
/* 140:    */     
/* 141:    */     public ToStringHelper addValue(long value)
/* 142:    */     {
/* 143:373 */       return addHolder(String.valueOf(value));
/* 144:    */     }
/* 145:    */     
/* 146:    */     public String toString()
/* 147:    */     {
/* 148:388 */       boolean omitNullValuesSnapshot = this.omitNullValues;
/* 149:389 */       String nextSeparator = "";
/* 150:390 */       StringBuilder builder = new StringBuilder(32).append(this.className).append('{');
/* 151:392 */       for (ValueHolder valueHolder = this.holderHead.next; valueHolder != null; valueHolder = valueHolder.next) {
/* 152:394 */         if ((!omitNullValuesSnapshot) || (valueHolder.value != null))
/* 153:    */         {
/* 154:395 */           builder.append(nextSeparator);
/* 155:396 */           nextSeparator = ", ";
/* 156:398 */           if (valueHolder.name != null) {
/* 157:399 */             builder.append(valueHolder.name).append('=');
/* 158:    */           }
/* 159:401 */           builder.append(valueHolder.value);
/* 160:    */         }
/* 161:    */       }
/* 162:404 */       return '}';
/* 163:    */     }
/* 164:    */     
/* 165:    */     private ValueHolder addHolder()
/* 166:    */     {
/* 167:408 */       ValueHolder valueHolder = new ValueHolder(null);
/* 168:409 */       this.holderTail = (this.holderTail.next = valueHolder);
/* 169:410 */       return valueHolder;
/* 170:    */     }
/* 171:    */     
/* 172:    */     private ToStringHelper addHolder(@Nullable Object value)
/* 173:    */     {
/* 174:414 */       ValueHolder valueHolder = addHolder();
/* 175:415 */       valueHolder.value = value;
/* 176:416 */       return this;
/* 177:    */     }
/* 178:    */     
/* 179:    */     private ToStringHelper addHolder(String name, @Nullable Object value)
/* 180:    */     {
/* 181:420 */       ValueHolder valueHolder = addHolder();
/* 182:421 */       valueHolder.value = value;
/* 183:422 */       valueHolder.name = ((String)Preconditions.checkNotNull(name));
/* 184:423 */       return this;
/* 185:    */     }
/* 186:    */     
/* 187:    */     private static final class ValueHolder
/* 188:    */     {
/* 189:    */       String name;
/* 190:    */       Object value;
/* 191:    */       ValueHolder next;
/* 192:    */     }
/* 193:    */   }
/* 194:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Objects
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Collections;
/*  5:   */ import java.util.Set;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ final class Present<T>
/* 10:   */   extends Optional<T>
/* 11:   */ {
/* 12:   */   private final T reference;
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   Present(T reference)
/* 16:   */   {
/* 17:36 */     this.reference = reference;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean isPresent()
/* 21:   */   {
/* 22:40 */     return true;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public T get()
/* 26:   */   {
/* 27:44 */     return this.reference;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public T or(T defaultValue)
/* 31:   */   {
/* 32:48 */     Preconditions.checkNotNull(defaultValue, "use Optional.orNull() instead of Optional.or(null)");
/* 33:49 */     return this.reference;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Optional<T> or(Optional<? extends T> secondChoice)
/* 37:   */   {
/* 38:53 */     Preconditions.checkNotNull(secondChoice);
/* 39:54 */     return this;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public T or(Supplier<? extends T> supplier)
/* 43:   */   {
/* 44:58 */     Preconditions.checkNotNull(supplier);
/* 45:59 */     return this.reference;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public T orNull()
/* 49:   */   {
/* 50:63 */     return this.reference;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Set<T> asSet()
/* 54:   */   {
/* 55:67 */     return Collections.singleton(this.reference);
/* 56:   */   }
/* 57:   */   
/* 58:   */   public <V> Optional<V> transform(Function<? super T, V> function)
/* 59:   */   {
/* 60:71 */     return new Present(Preconditions.checkNotNull(function.apply(this.reference), "the Function passed to Optional.transform() must not return null."));
/* 61:   */   }
/* 62:   */   
/* 63:   */   public boolean equals(@Nullable Object object)
/* 64:   */   {
/* 65:76 */     if ((object instanceof Present))
/* 66:   */     {
/* 67:77 */       Present<?> other = (Present)object;
/* 68:78 */       return this.reference.equals(other.reference);
/* 69:   */     }
/* 70:80 */     return false;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public int hashCode()
/* 74:   */   {
/* 75:84 */     return 1502476572 + this.reference.hashCode();
/* 76:   */   }
/* 77:   */   
/* 78:   */   public String toString()
/* 79:   */   {
/* 80:88 */     return "Optional.of(" + this.reference + ")";
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Present
 * JD-Core Version:    0.7.0.1
 */
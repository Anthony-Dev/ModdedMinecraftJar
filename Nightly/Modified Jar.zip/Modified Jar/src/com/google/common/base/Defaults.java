/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ public final class Defaults
/*  8:   */ {
/*  9:   */   private static final Map<Class<?>, Object> DEFAULTS;
/* 10:   */   
/* 11:   */   static
/* 12:   */   {
/* 13:38 */     Map<Class<?>, Object> map = new HashMap();
/* 14:39 */     put(map, Boolean.TYPE, Boolean.valueOf(false));
/* 15:40 */     put(map, Character.TYPE, Character.valueOf('\000'));
/* 16:41 */     put(map, Byte.TYPE, Byte.valueOf((byte)0));
/* 17:42 */     put(map, Short.TYPE, Short.valueOf((short)0));
/* 18:43 */     put(map, Integer.TYPE, Integer.valueOf(0));
/* 19:44 */     put(map, Long.TYPE, Long.valueOf(0L));
/* 20:45 */     put(map, Float.TYPE, Float.valueOf(0.0F));
/* 21:46 */     put(map, Double.TYPE, Double.valueOf(0.0D));
/* 22:47 */     DEFAULTS = Collections.unmodifiableMap(map);
/* 23:   */   }
/* 24:   */   
/* 25:   */   private static <T> void put(Map<Class<?>, Object> map, Class<T> type, T value)
/* 26:   */   {
/* 27:51 */     map.put(type, value);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static <T> T defaultValue(Class<T> type)
/* 31:   */   {
/* 32:62 */     T t = DEFAULTS.get(Preconditions.checkNotNull(type));
/* 33:63 */     return t;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Defaults
 * JD-Core Version:    0.7.0.1
 */
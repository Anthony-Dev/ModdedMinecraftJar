/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.math.LongMath;
/*   5:    */ import com.google.common.primitives.Ints;
/*   6:    */ import com.google.common.primitives.Longs;
/*   7:    */ import java.math.RoundingMode;
/*   8:    */ import java.util.Arrays;
/*   9:    */ 
/*  10:    */  enum BloomFilterStrategies
/*  11:    */   implements BloomFilter.Strategy
/*  12:    */ {
/*  13: 44 */   MURMUR128_MITZ_32,  MURMUR128_MITZ_64;
/*  14:    */   
/*  15:    */   private BloomFilterStrategies() {}
/*  16:    */   
/*  17:    */   static final class BitArray
/*  18:    */   {
/*  19:    */     final long[] data;
/*  20:    */     long bitCount;
/*  21:    */     
/*  22:    */     BitArray(long bits)
/*  23:    */     {
/*  24:145 */       this(new long[Ints.checkedCast(LongMath.divide(bits, 64L, RoundingMode.CEILING))]);
/*  25:    */     }
/*  26:    */     
/*  27:    */     BitArray(long[] data)
/*  28:    */     {
/*  29:150 */       Preconditions.checkArgument(data.length > 0, "data length is zero!");
/*  30:151 */       this.data = data;
/*  31:152 */       long bitCount = 0L;
/*  32:153 */       for (long value : data) {
/*  33:154 */         bitCount += Long.bitCount(value);
/*  34:    */       }
/*  35:156 */       this.bitCount = bitCount;
/*  36:    */     }
/*  37:    */     
/*  38:    */     boolean set(long index)
/*  39:    */     {
/*  40:161 */       if (!get(index))
/*  41:    */       {
/*  42:162 */         this.data[((int)(index >>> 6))] |= 1L << (int)index;
/*  43:163 */         this.bitCount += 1L;
/*  44:164 */         return true;
/*  45:    */       }
/*  46:166 */       return false;
/*  47:    */     }
/*  48:    */     
/*  49:    */     boolean get(long index)
/*  50:    */     {
/*  51:170 */       return (this.data[((int)(index >>> 6))] & 1L << (int)index) != 0L;
/*  52:    */     }
/*  53:    */     
/*  54:    */     long bitSize()
/*  55:    */     {
/*  56:175 */       return this.data.length * 64L;
/*  57:    */     }
/*  58:    */     
/*  59:    */     long bitCount()
/*  60:    */     {
/*  61:180 */       return this.bitCount;
/*  62:    */     }
/*  63:    */     
/*  64:    */     BitArray copy()
/*  65:    */     {
/*  66:184 */       return new BitArray((long[])this.data.clone());
/*  67:    */     }
/*  68:    */     
/*  69:    */     void putAll(BitArray array)
/*  70:    */     {
/*  71:189 */       Preconditions.checkArgument(this.data.length == array.data.length, "BitArrays must be of equal length (%s != %s)", new Object[] { Integer.valueOf(this.data.length), Integer.valueOf(array.data.length) });
/*  72:    */       
/*  73:191 */       this.bitCount = 0L;
/*  74:192 */       for (int i = 0; i < this.data.length; i++)
/*  75:    */       {
/*  76:193 */         this.data[i] |= array.data[i];
/*  77:194 */         this.bitCount += Long.bitCount(this.data[i]);
/*  78:    */       }
/*  79:    */     }
/*  80:    */     
/*  81:    */     public boolean equals(Object o)
/*  82:    */     {
/*  83:199 */       if ((o instanceof BitArray))
/*  84:    */       {
/*  85:200 */         BitArray bitArray = (BitArray)o;
/*  86:201 */         return Arrays.equals(this.data, bitArray.data);
/*  87:    */       }
/*  88:203 */       return false;
/*  89:    */     }
/*  90:    */     
/*  91:    */     public int hashCode()
/*  92:    */     {
/*  93:207 */       return Arrays.hashCode(this.data);
/*  94:    */     }
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.BloomFilterStrategies
 * JD-Core Version:    0.7.0.1
 */
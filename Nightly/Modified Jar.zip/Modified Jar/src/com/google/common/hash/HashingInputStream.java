/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.FilterInputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public final class HashingInputStream
/*  11:    */   extends FilterInputStream
/*  12:    */ {
/*  13:    */   private final Hasher hasher;
/*  14:    */   
/*  15:    */   public HashingInputStream(HashFunction hashFunction, InputStream in)
/*  16:    */   {
/*  17: 42 */     super((InputStream)Preconditions.checkNotNull(in));
/*  18: 43 */     this.hasher = ((Hasher)Preconditions.checkNotNull(hashFunction.newHasher()));
/*  19:    */   }
/*  20:    */   
/*  21:    */   public int read()
/*  22:    */     throws IOException
/*  23:    */   {
/*  24: 52 */     int b = this.in.read();
/*  25: 53 */     if (b != -1) {
/*  26: 54 */       this.hasher.putByte((byte)b);
/*  27:    */     }
/*  28: 56 */     return b;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public int read(byte[] bytes, int off, int len)
/*  32:    */     throws IOException
/*  33:    */   {
/*  34: 65 */     int numOfBytesRead = this.in.read(bytes, off, len);
/*  35: 66 */     if (numOfBytesRead != -1) {
/*  36: 67 */       this.hasher.putBytes(bytes, off, numOfBytesRead);
/*  37:    */     }
/*  38: 69 */     return numOfBytesRead;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean markSupported()
/*  42:    */   {
/*  43: 78 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void mark(int readlimit) {}
/*  47:    */   
/*  48:    */   public void reset()
/*  49:    */     throws IOException
/*  50:    */   {
/*  51: 93 */     throw new IOException("reset not supported");
/*  52:    */   }
/*  53:    */   
/*  54:    */   public HashCode hash()
/*  55:    */   {
/*  56:101 */     return this.hasher.hash();
/*  57:    */   }
/*  58:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.HashingInputStream
 * JD-Core Version:    0.7.0.1
 */
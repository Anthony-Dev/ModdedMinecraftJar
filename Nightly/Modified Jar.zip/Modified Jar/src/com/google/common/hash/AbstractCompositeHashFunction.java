/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.nio.charset.Charset;
/*  5:   */ 
/*  6:   */ abstract class AbstractCompositeHashFunction
/*  7:   */   extends AbstractStreamingHashFunction
/*  8:   */ {
/*  9:   */   final HashFunction[] functions;
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   AbstractCompositeHashFunction(HashFunction... functions)
/* 13:   */   {
/* 14:34 */     for (HashFunction function : functions) {
/* 15:35 */       Preconditions.checkNotNull(function);
/* 16:   */     }
/* 17:37 */     this.functions = functions;
/* 18:   */   }
/* 19:   */   
/* 20:   */   abstract HashCode makeHash(Hasher[] paramArrayOfHasher);
/* 21:   */   
/* 22:   */   public Hasher newHasher()
/* 23:   */   {
/* 24:50 */     final Hasher[] hashers = new Hasher[this.functions.length];
/* 25:51 */     for (int i = 0; i < hashers.length; i++) {
/* 26:52 */       hashers[i] = this.functions[i].newHasher();
/* 27:   */     }
/* 28:54 */     new Hasher()
/* 29:   */     {
/* 30:   */       public Hasher putByte(byte b)
/* 31:   */       {
/* 32:56 */         for (Hasher hasher : hashers) {
/* 33:57 */           hasher.putByte(b);
/* 34:   */         }
/* 35:59 */         return this;
/* 36:   */       }
/* 37:   */       
/* 38:   */       public Hasher putBytes(byte[] bytes)
/* 39:   */       {
/* 40:63 */         for (Hasher hasher : hashers) {
/* 41:64 */           hasher.putBytes(bytes);
/* 42:   */         }
/* 43:66 */         return this;
/* 44:   */       }
/* 45:   */       
/* 46:   */       public Hasher putBytes(byte[] bytes, int off, int len)
/* 47:   */       {
/* 48:70 */         for (Hasher hasher : hashers) {
/* 49:71 */           hasher.putBytes(bytes, off, len);
/* 50:   */         }
/* 51:73 */         return this;
/* 52:   */       }
/* 53:   */       
/* 54:   */       public Hasher putShort(short s)
/* 55:   */       {
/* 56:77 */         for (Hasher hasher : hashers) {
/* 57:78 */           hasher.putShort(s);
/* 58:   */         }
/* 59:80 */         return this;
/* 60:   */       }
/* 61:   */       
/* 62:   */       public Hasher putInt(int i)
/* 63:   */       {
/* 64:84 */         for (Hasher hasher : hashers) {
/* 65:85 */           hasher.putInt(i);
/* 66:   */         }
/* 67:87 */         return this;
/* 68:   */       }
/* 69:   */       
/* 70:   */       public Hasher putLong(long l)
/* 71:   */       {
/* 72:91 */         for (Hasher hasher : hashers) {
/* 73:92 */           hasher.putLong(l);
/* 74:   */         }
/* 75:94 */         return this;
/* 76:   */       }
/* 77:   */       
/* 78:   */       public Hasher putFloat(float f)
/* 79:   */       {
/* 80:98 */         for (Hasher hasher : hashers) {
/* 81:99 */           hasher.putFloat(f);
/* 82:   */         }
/* 83::1 */         return this;
/* 84:   */       }
/* 85:   */       
/* 86:   */       public Hasher putDouble(double d)
/* 87:   */       {
/* 88::5 */         for (Hasher hasher : hashers) {
/* 89::6 */           hasher.putDouble(d);
/* 90:   */         }
/* 91::8 */         return this;
/* 92:   */       }
/* 93:   */       
/* 94:   */       public Hasher putBoolean(boolean b)
/* 95:   */       {
/* 96:;2 */         for (Hasher hasher : hashers) {
/* 97:;3 */           hasher.putBoolean(b);
/* 98:   */         }
/* 99:;5 */         return this;
/* :0:   */       }
/* :1:   */       
/* :2:   */       public Hasher putChar(char c)
/* :3:   */       {
/* :4:;9 */         for (Hasher hasher : hashers) {
/* :5:<0 */           hasher.putChar(c);
/* :6:   */         }
/* :7:<2 */         return this;
/* :8:   */       }
/* :9:   */       
/* ;0:   */       public Hasher putUnencodedChars(CharSequence chars)
/* ;1:   */       {
/* ;2:<6 */         for (Hasher hasher : hashers) {
/* ;3:<7 */           hasher.putUnencodedChars(chars);
/* ;4:   */         }
/* ;5:<9 */         return this;
/* ;6:   */       }
/* ;7:   */       
/* ;8:   */       public Hasher putString(CharSequence chars, Charset charset)
/* ;9:   */       {
/* <0:=3 */         for (Hasher hasher : hashers) {
/* <1:=4 */           hasher.putString(chars, charset);
/* <2:   */         }
/* <3:=6 */         return this;
/* <4:   */       }
/* <5:   */       
/* <6:   */       public <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/* <7:   */       {
/* <8:>0 */         for (Hasher hasher : hashers) {
/* <9:>1 */           hasher.putObject(instance, funnel);
/* =0:   */         }
/* =1:>3 */         return this;
/* =2:   */       }
/* =3:   */       
/* =4:   */       public HashCode hash()
/* =5:   */       {
/* =6:>7 */         return AbstractCompositeHashFunction.this.makeHash(hashers);
/* =7:   */       }
/* =8:   */     };
/* =9:   */   }
/* >0:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.AbstractCompositeHashFunction
 * JD-Core Version:    0.7.0.1
 */
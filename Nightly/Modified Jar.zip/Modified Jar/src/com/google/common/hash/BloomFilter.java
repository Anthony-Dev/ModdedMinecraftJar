/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ public final class BloomFilter<T>
/*  13:    */   implements Predicate<T>, Serializable
/*  14:    */ {
/*  15:    */   private final BloomFilterStrategies.BitArray bits;
/*  16:    */   private final int numHashFunctions;
/*  17:    */   private final Funnel<T> funnel;
/*  18:    */   private final Strategy strategy;
/*  19:    */   
/*  20:    */   private BloomFilter(BloomFilterStrategies.BitArray bits, int numHashFunctions, Funnel<T> funnel, Strategy strategy)
/*  21:    */   {
/*  22:105 */     Preconditions.checkArgument(numHashFunctions > 0, "numHashFunctions (%s) must be > 0", new Object[] { Integer.valueOf(numHashFunctions) });
/*  23:    */     
/*  24:107 */     Preconditions.checkArgument(numHashFunctions <= 255, "numHashFunctions (%s) must be <= 255", new Object[] { Integer.valueOf(numHashFunctions) });
/*  25:    */     
/*  26:109 */     this.bits = ((BloomFilterStrategies.BitArray)Preconditions.checkNotNull(bits));
/*  27:110 */     this.numHashFunctions = numHashFunctions;
/*  28:111 */     this.funnel = ((Funnel)Preconditions.checkNotNull(funnel));
/*  29:112 */     this.strategy = ((Strategy)Preconditions.checkNotNull(strategy));
/*  30:    */   }
/*  31:    */   
/*  32:    */   public BloomFilter<T> copy()
/*  33:    */   {
/*  34:122 */     return new BloomFilter(this.bits.copy(), this.numHashFunctions, this.funnel, this.strategy);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean mightContain(T object)
/*  38:    */   {
/*  39:130 */     return this.strategy.mightContain(object, this.funnel, this.numHashFunctions, this.bits);
/*  40:    */   }
/*  41:    */   
/*  42:    */   @Deprecated
/*  43:    */   public boolean apply(T input)
/*  44:    */   {
/*  45:140 */     return mightContain(input);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean put(T object)
/*  49:    */   {
/*  50:156 */     return this.strategy.put(object, this.funnel, this.numHashFunctions, this.bits);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public double expectedFpp()
/*  54:    */   {
/*  55:172 */     return Math.pow(this.bits.bitCount() / bitSize(), this.numHashFunctions);
/*  56:    */   }
/*  57:    */   
/*  58:    */   @VisibleForTesting
/*  59:    */   long bitSize()
/*  60:    */   {
/*  61:179 */     return this.bits.bitSize();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isCompatible(BloomFilter<T> that)
/*  65:    */   {
/*  66:198 */     Preconditions.checkNotNull(that);
/*  67:199 */     return (this != that) && (this.numHashFunctions == that.numHashFunctions) && (bitSize() == that.bitSize()) && (this.strategy.equals(that.strategy)) && (this.funnel.equals(that.funnel));
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void putAll(BloomFilter<T> that)
/*  71:    */   {
/*  72:217 */     Preconditions.checkNotNull(that);
/*  73:218 */     Preconditions.checkArgument(this != that, "Cannot combine a BloomFilter with itself.");
/*  74:219 */     Preconditions.checkArgument(this.numHashFunctions == that.numHashFunctions, "BloomFilters must have the same number of hash functions (%s != %s)", new Object[] { Integer.valueOf(this.numHashFunctions), Integer.valueOf(that.numHashFunctions) });
/*  75:    */     
/*  76:    */ 
/*  77:222 */     Preconditions.checkArgument(bitSize() == that.bitSize(), "BloomFilters must have the same size underlying bit arrays (%s != %s)", new Object[] { Long.valueOf(bitSize()), Long.valueOf(that.bitSize()) });
/*  78:    */     
/*  79:    */ 
/*  80:225 */     Preconditions.checkArgument(this.strategy.equals(that.strategy), "BloomFilters must have equal strategies (%s != %s)", new Object[] { this.strategy, that.strategy });
/*  81:    */     
/*  82:    */ 
/*  83:228 */     Preconditions.checkArgument(this.funnel.equals(that.funnel), "BloomFilters must have equal funnels (%s != %s)", new Object[] { this.funnel, that.funnel });
/*  84:    */     
/*  85:    */ 
/*  86:231 */     this.bits.putAll(that.bits);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean equals(@Nullable Object object)
/*  90:    */   {
/*  91:236 */     if (object == this) {
/*  92:237 */       return true;
/*  93:    */     }
/*  94:239 */     if ((object instanceof BloomFilter))
/*  95:    */     {
/*  96:240 */       BloomFilter<?> that = (BloomFilter)object;
/*  97:241 */       return (this.numHashFunctions == that.numHashFunctions) && (this.funnel.equals(that.funnel)) && (this.bits.equals(that.bits)) && (this.strategy.equals(that.strategy));
/*  98:    */     }
/*  99:246 */     return false;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public int hashCode()
/* 103:    */   {
/* 104:251 */     return Objects.hashCode(new Object[] { Integer.valueOf(this.numHashFunctions), this.funnel, this.strategy, this.bits });
/* 105:    */   }
/* 106:    */   
/* 107:254 */   private static final Strategy DEFAULT_STRATEGY = ;
/* 108:    */   @VisibleForTesting
/* 109:    */   static final String USE_MITZ32_PROPERTY = "com.google.common.hash.BloomFilter.useMitz32";
/* 110:    */   
/* 111:    */   @VisibleForTesting
/* 112:    */   static Strategy getDefaultStrategyFromSystemProperty()
/* 113:    */   {
/* 114:262 */     return Boolean.parseBoolean(System.getProperty("com.google.common.hash.BloomFilter.useMitz32")) ? BloomFilterStrategies.MURMUR128_MITZ_32 : BloomFilterStrategies.MURMUR128_MITZ_64;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static <T> BloomFilter<T> create(Funnel<T> funnel, int expectedInsertions, double fpp)
/* 118:    */   {
/* 119:290 */     return create(funnel, expectedInsertions, fpp, DEFAULT_STRATEGY);
/* 120:    */   }
/* 121:    */   
/* 122:    */   @VisibleForTesting
/* 123:    */   static <T> BloomFilter<T> create(Funnel<T> funnel, int expectedInsertions, double fpp, Strategy strategy)
/* 124:    */   {
/* 125:296 */     Preconditions.checkNotNull(funnel);
/* 126:297 */     Preconditions.checkArgument(expectedInsertions >= 0, "Expected insertions (%s) must be >= 0", new Object[] { Integer.valueOf(expectedInsertions) });
/* 127:    */     
/* 128:299 */     Preconditions.checkArgument(fpp > 0.0D, "False positive probability (%s) must be > 0.0", new Object[] { Double.valueOf(fpp) });
/* 129:300 */     Preconditions.checkArgument(fpp < 1.0D, "False positive probability (%s) must be < 1.0", new Object[] { Double.valueOf(fpp) });
/* 130:301 */     Preconditions.checkNotNull(strategy);
/* 131:303 */     if (expectedInsertions == 0) {
/* 132:304 */       expectedInsertions = 1;
/* 133:    */     }
/* 134:312 */     long numBits = optimalNumOfBits(expectedInsertions, fpp);
/* 135:313 */     int numHashFunctions = optimalNumOfHashFunctions(expectedInsertions, numBits);
/* 136:    */     try
/* 137:    */     {
/* 138:315 */       return new BloomFilter(new BloomFilterStrategies.BitArray(numBits), numHashFunctions, funnel, strategy);
/* 139:    */     }
/* 140:    */     catch (IllegalArgumentException e)
/* 141:    */     {
/* 142:317 */       throw new IllegalArgumentException("Could not create BloomFilter of " + numBits + " bits", e);
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static <T> BloomFilter<T> create(Funnel<T> funnel, int expectedInsertions)
/* 147:    */   {
/* 148:338 */     return create(funnel, expectedInsertions, 0.03D);
/* 149:    */   }
/* 150:    */   
/* 151:    */   @VisibleForTesting
/* 152:    */   static int optimalNumOfHashFunctions(long n, long m)
/* 153:    */   {
/* 154:366 */     return Math.max(1, (int)Math.round(m / n * Math.log(2.0D)));
/* 155:    */   }
/* 156:    */   
/* 157:    */   @VisibleForTesting
/* 158:    */   static long optimalNumOfBits(long n, double p)
/* 159:    */   {
/* 160:380 */     if (p == 0.0D) {
/* 161:381 */       p = 4.9E-324D;
/* 162:    */     }
/* 163:383 */     return (-n * Math.log(p) / (Math.log(2.0D) * Math.log(2.0D)));
/* 164:    */   }
/* 165:    */   
/* 166:    */   private Object writeReplace()
/* 167:    */   {
/* 168:387 */     return new SerialForm(this);
/* 169:    */   }
/* 170:    */   
/* 171:    */   private static class SerialForm<T>
/* 172:    */     implements Serializable
/* 173:    */   {
/* 174:    */     final long[] data;
/* 175:    */     final int numHashFunctions;
/* 176:    */     final Funnel<T> funnel;
/* 177:    */     final BloomFilter.Strategy strategy;
/* 178:    */     private static final long serialVersionUID = 1L;
/* 179:    */     
/* 180:    */     SerialForm(BloomFilter<T> bf)
/* 181:    */     {
/* 182:397 */       this.data = bf.bits.data;
/* 183:398 */       this.numHashFunctions = bf.numHashFunctions;
/* 184:399 */       this.funnel = bf.funnel;
/* 185:400 */       this.strategy = bf.strategy;
/* 186:    */     }
/* 187:    */     
/* 188:    */     Object readResolve()
/* 189:    */     {
/* 190:403 */       return new BloomFilter(new BloomFilterStrategies.BitArray(this.data), this.numHashFunctions, this.funnel, this.strategy, null);
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   static abstract interface Strategy
/* 195:    */     extends Serializable
/* 196:    */   {
/* 197:    */     public abstract <T> boolean put(T paramT, Funnel<? super T> paramFunnel, int paramInt, BloomFilterStrategies.BitArray paramBitArray);
/* 198:    */     
/* 199:    */     public abstract <T> boolean mightContain(T paramT, Funnel<? super T> paramFunnel, int paramInt, BloomFilterStrategies.BitArray paramBitArray);
/* 200:    */     
/* 201:    */     public abstract int ordinal();
/* 202:    */   }
/* 203:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.BloomFilter
 * JD-Core Version:    0.7.0.1
 */
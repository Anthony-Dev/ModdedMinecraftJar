/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.ByteOrder;
/*   6:    */ 
/*   7:    */ abstract class AbstractByteHasher
/*   8:    */   extends AbstractHasher
/*   9:    */ {
/*  10: 38 */   private final ByteBuffer scratch = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/*  11:    */   
/*  12:    */   protected abstract void update(byte paramByte);
/*  13:    */   
/*  14:    */   protected void update(byte[] b)
/*  15:    */   {
/*  16: 49 */     update(b, 0, b.length);
/*  17:    */   }
/*  18:    */   
/*  19:    */   protected void update(byte[] b, int off, int len)
/*  20:    */   {
/*  21: 56 */     for (int i = off; i < off + len; i++) {
/*  22: 57 */       update(b[i]);
/*  23:    */     }
/*  24:    */   }
/*  25:    */   
/*  26:    */   public Hasher putByte(byte b)
/*  27:    */   {
/*  28: 63 */     update(b);
/*  29: 64 */     return this;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Hasher putBytes(byte[] bytes)
/*  33:    */   {
/*  34: 69 */     Preconditions.checkNotNull(bytes);
/*  35: 70 */     update(bytes);
/*  36: 71 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Hasher putBytes(byte[] bytes, int off, int len)
/*  40:    */   {
/*  41: 76 */     Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  42: 77 */     update(bytes, off, len);
/*  43: 78 */     return this;
/*  44:    */   }
/*  45:    */   
/*  46:    */   private Hasher update(int bytes)
/*  47:    */   {
/*  48:    */     try
/*  49:    */     {
/*  50: 86 */       update(this.scratch.array(), 0, bytes);
/*  51:    */     }
/*  52:    */     finally
/*  53:    */     {
/*  54: 88 */       this.scratch.clear();
/*  55:    */     }
/*  56: 90 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Hasher putShort(short s)
/*  60:    */   {
/*  61: 95 */     this.scratch.putShort(s);
/*  62: 96 */     return update(2);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Hasher putInt(int i)
/*  66:    */   {
/*  67:101 */     this.scratch.putInt(i);
/*  68:102 */     return update(4);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Hasher putLong(long l)
/*  72:    */   {
/*  73:107 */     this.scratch.putLong(l);
/*  74:108 */     return update(8);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Hasher putChar(char c)
/*  78:    */   {
/*  79:113 */     this.scratch.putChar(c);
/*  80:114 */     return update(2);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/*  84:    */   {
/*  85:119 */     funnel.funnel(instance, this);
/*  86:120 */     return this;
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.AbstractByteHasher
 * JD-Core Version:    0.7.0.1
 */
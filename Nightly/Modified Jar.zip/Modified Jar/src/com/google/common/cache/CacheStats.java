/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Objects.ToStringHelper;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible
/*  12:    */ public final class CacheStats
/*  13:    */ {
/*  14:    */   private final long hitCount;
/*  15:    */   private final long missCount;
/*  16:    */   private final long loadSuccessCount;
/*  17:    */   private final long loadExceptionCount;
/*  18:    */   private final long totalLoadTime;
/*  19:    */   private final long evictionCount;
/*  20:    */   
/*  21:    */   public CacheStats(long hitCount, long missCount, long loadSuccessCount, long loadExceptionCount, long totalLoadTime, long evictionCount)
/*  22:    */   {
/*  23: 79 */     Preconditions.checkArgument(hitCount >= 0L);
/*  24: 80 */     Preconditions.checkArgument(missCount >= 0L);
/*  25: 81 */     Preconditions.checkArgument(loadSuccessCount >= 0L);
/*  26: 82 */     Preconditions.checkArgument(loadExceptionCount >= 0L);
/*  27: 83 */     Preconditions.checkArgument(totalLoadTime >= 0L);
/*  28: 84 */     Preconditions.checkArgument(evictionCount >= 0L);
/*  29:    */     
/*  30: 86 */     this.hitCount = hitCount;
/*  31: 87 */     this.missCount = missCount;
/*  32: 88 */     this.loadSuccessCount = loadSuccessCount;
/*  33: 89 */     this.loadExceptionCount = loadExceptionCount;
/*  34: 90 */     this.totalLoadTime = totalLoadTime;
/*  35: 91 */     this.evictionCount = evictionCount;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public long requestCount()
/*  39:    */   {
/*  40: 99 */     return this.hitCount + this.missCount;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public long hitCount()
/*  44:    */   {
/*  45:106 */     return this.hitCount;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public double hitRate()
/*  49:    */   {
/*  50:115 */     long requestCount = requestCount();
/*  51:116 */     return requestCount == 0L ? 1.0D : this.hitCount / requestCount;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public long missCount()
/*  55:    */   {
/*  56:126 */     return this.missCount;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public double missRate()
/*  60:    */   {
/*  61:139 */     long requestCount = requestCount();
/*  62:140 */     return requestCount == 0L ? 0.0D : this.missCount / requestCount;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public long loadCount()
/*  66:    */   {
/*  67:149 */     return this.loadSuccessCount + this.loadExceptionCount;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public long loadSuccessCount()
/*  71:    */   {
/*  72:160 */     return this.loadSuccessCount;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public long loadExceptionCount()
/*  76:    */   {
/*  77:171 */     return this.loadExceptionCount;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public double loadExceptionRate()
/*  81:    */   {
/*  82:180 */     long totalLoadCount = this.loadSuccessCount + this.loadExceptionCount;
/*  83:181 */     return totalLoadCount == 0L ? 0.0D : this.loadExceptionCount / totalLoadCount;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public long totalLoadTime()
/*  87:    */   {
/*  88:192 */     return this.totalLoadTime;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public double averageLoadPenalty()
/*  92:    */   {
/*  93:200 */     long totalLoadCount = this.loadSuccessCount + this.loadExceptionCount;
/*  94:201 */     return totalLoadCount == 0L ? 0.0D : this.totalLoadTime / totalLoadCount;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public long evictionCount()
/*  98:    */   {
/*  99:211 */     return this.evictionCount;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public CacheStats minus(CacheStats other)
/* 103:    */   {
/* 104:220 */     return new CacheStats(Math.max(0L, this.hitCount - other.hitCount), Math.max(0L, this.missCount - other.missCount), Math.max(0L, this.loadSuccessCount - other.loadSuccessCount), Math.max(0L, this.loadExceptionCount - other.loadExceptionCount), Math.max(0L, this.totalLoadTime - other.totalLoadTime), Math.max(0L, this.evictionCount - other.evictionCount));
/* 105:    */   }
/* 106:    */   
/* 107:    */   public CacheStats plus(CacheStats other)
/* 108:    */   {
/* 109:236 */     return new CacheStats(this.hitCount + other.hitCount, this.missCount + other.missCount, this.loadSuccessCount + other.loadSuccessCount, this.loadExceptionCount + other.loadExceptionCount, this.totalLoadTime + other.totalLoadTime, this.evictionCount + other.evictionCount);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public int hashCode()
/* 113:    */   {
/* 114:247 */     return Objects.hashCode(new Object[] { Long.valueOf(this.hitCount), Long.valueOf(this.missCount), Long.valueOf(this.loadSuccessCount), Long.valueOf(this.loadExceptionCount), Long.valueOf(this.totalLoadTime), Long.valueOf(this.evictionCount) });
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean equals(@Nullable Object object)
/* 118:    */   {
/* 119:253 */     if ((object instanceof CacheStats))
/* 120:    */     {
/* 121:254 */       CacheStats other = (CacheStats)object;
/* 122:255 */       return (this.hitCount == other.hitCount) && (this.missCount == other.missCount) && (this.loadSuccessCount == other.loadSuccessCount) && (this.loadExceptionCount == other.loadExceptionCount) && (this.totalLoadTime == other.totalLoadTime) && (this.evictionCount == other.evictionCount);
/* 123:    */     }
/* 124:262 */     return false;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public String toString()
/* 128:    */   {
/* 129:267 */     return Objects.toStringHelper(this).add("hitCount", this.hitCount).add("missCount", this.missCount).add("loadSuccessCount", this.loadSuccessCount).add("loadExceptionCount", this.loadExceptionCount).add("totalLoadTime", this.totalLoadTime).add("evictionCount", this.evictionCount).toString();
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.CacheStats
 * JD-Core Version:    0.7.0.1
 */
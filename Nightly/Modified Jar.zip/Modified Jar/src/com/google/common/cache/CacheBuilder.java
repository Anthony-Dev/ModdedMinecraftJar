/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Ascii;
/*   7:    */ import com.google.common.base.Equivalence;
/*   8:    */ import com.google.common.base.Objects;
/*   9:    */ import com.google.common.base.Objects.ToStringHelper;
/*  10:    */ import com.google.common.base.Preconditions;
/*  11:    */ import com.google.common.base.Supplier;
/*  12:    */ import com.google.common.base.Suppliers;
/*  13:    */ import com.google.common.base.Ticker;
/*  14:    */ import java.util.concurrent.TimeUnit;
/*  15:    */ import java.util.logging.Level;
/*  16:    */ import java.util.logging.Logger;
/*  17:    */ import javax.annotation.CheckReturnValue;
/*  18:    */ 
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class CacheBuilder<K, V>
/*  21:    */ {
/*  22:    */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*  23:    */   private static final int DEFAULT_CONCURRENCY_LEVEL = 4;
/*  24:    */   private static final int DEFAULT_EXPIRATION_NANOS = 0;
/*  25:    */   private static final int DEFAULT_REFRESH_NANOS = 0;
/*  26:159 */   static final Supplier<? extends AbstractCache.StatsCounter> NULL_STATS_COUNTER = Suppliers.ofInstance(new AbstractCache.StatsCounter()
/*  27:    */   {
/*  28:    */     public void recordHits(int count) {}
/*  29:    */     
/*  30:    */     public void recordMisses(int count) {}
/*  31:    */     
/*  32:    */     public void recordLoadSuccess(long loadTime) {}
/*  33:    */     
/*  34:    */     public void recordLoadException(long loadTime) {}
/*  35:    */     
/*  36:    */     public void recordEviction() {}
/*  37:    */     
/*  38:    */     public CacheStats snapshot()
/*  39:    */     {
/*  40:178 */       return CacheBuilder.EMPTY_STATS;
/*  41:    */     }
/*  42:159 */   });
/*  43:181 */   static final CacheStats EMPTY_STATS = new CacheStats(0L, 0L, 0L, 0L, 0L, 0L);
/*  44:183 */   static final Supplier<AbstractCache.StatsCounter> CACHE_STATS_COUNTER = new Supplier()
/*  45:    */   {
/*  46:    */     public AbstractCache.StatsCounter get()
/*  47:    */     {
/*  48:187 */       return new AbstractCache.SimpleStatsCounter();
/*  49:    */     }
/*  50:    */   };
/*  51:    */   
/*  52:    */   static enum NullListener
/*  53:    */     implements RemovalListener<Object, Object>
/*  54:    */   {
/*  55:192 */     INSTANCE;
/*  56:    */     
/*  57:    */     private NullListener() {}
/*  58:    */     
/*  59:    */     public void onRemoval(RemovalNotification<Object, Object> notification) {}
/*  60:    */   }
/*  61:    */   
/*  62:    */   static enum OneWeigher
/*  63:    */     implements Weigher<Object, Object>
/*  64:    */   {
/*  65:199 */     INSTANCE;
/*  66:    */     
/*  67:    */     private OneWeigher() {}
/*  68:    */     
/*  69:    */     public int weigh(Object key, Object value)
/*  70:    */     {
/*  71:203 */       return 1;
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:207 */   static final Ticker NULL_TICKER = new Ticker()
/*  76:    */   {
/*  77:    */     public long read()
/*  78:    */     {
/*  79:210 */       return 0L;
/*  80:    */     }
/*  81:    */   };
/*  82:214 */   private static final Logger logger = Logger.getLogger(CacheBuilder.class.getName());
/*  83:    */   static final int UNSET_INT = -1;
/*  84:218 */   boolean strictParsing = true;
/*  85:220 */   int initialCapacity = -1;
/*  86:221 */   int concurrencyLevel = -1;
/*  87:222 */   long maximumSize = -1L;
/*  88:223 */   long maximumWeight = -1L;
/*  89:    */   Weigher<? super K, ? super V> weigher;
/*  90:    */   LocalCache.Strength keyStrength;
/*  91:    */   LocalCache.Strength valueStrength;
/*  92:229 */   long expireAfterWriteNanos = -1L;
/*  93:230 */   long expireAfterAccessNanos = -1L;
/*  94:231 */   long refreshNanos = -1L;
/*  95:    */   Equivalence<Object> keyEquivalence;
/*  96:    */   Equivalence<Object> valueEquivalence;
/*  97:    */   RemovalListener<? super K, ? super V> removalListener;
/*  98:    */   Ticker ticker;
/*  99:239 */   Supplier<? extends AbstractCache.StatsCounter> statsCounterSupplier = NULL_STATS_COUNTER;
/* 100:    */   
/* 101:    */   public static CacheBuilder<Object, Object> newBuilder()
/* 102:    */   {
/* 103:249 */     return new CacheBuilder();
/* 104:    */   }
/* 105:    */   
/* 106:    */   @Beta
/* 107:    */   @GwtIncompatible("To be supported")
/* 108:    */   public static CacheBuilder<Object, Object> from(CacheBuilderSpec spec)
/* 109:    */   {
/* 110:260 */     return spec.toCacheBuilder().lenientParsing();
/* 111:    */   }
/* 112:    */   
/* 113:    */   @Beta
/* 114:    */   @GwtIncompatible("To be supported")
/* 115:    */   public static CacheBuilder<Object, Object> from(String spec)
/* 116:    */   {
/* 117:274 */     return from(CacheBuilderSpec.parse(spec));
/* 118:    */   }
/* 119:    */   
/* 120:    */   @GwtIncompatible("To be supported")
/* 121:    */   CacheBuilder<K, V> lenientParsing()
/* 122:    */   {
/* 123:282 */     this.strictParsing = false;
/* 124:283 */     return this;
/* 125:    */   }
/* 126:    */   
/* 127:    */   @GwtIncompatible("To be supported")
/* 128:    */   CacheBuilder<K, V> keyEquivalence(Equivalence<Object> equivalence)
/* 129:    */   {
/* 130:294 */     Preconditions.checkState(this.keyEquivalence == null, "key equivalence was already set to %s", new Object[] { this.keyEquivalence });
/* 131:295 */     this.keyEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 132:296 */     return this;
/* 133:    */   }
/* 134:    */   
/* 135:    */   Equivalence<Object> getKeyEquivalence()
/* 136:    */   {
/* 137:300 */     return (Equivalence)Objects.firstNonNull(this.keyEquivalence, getKeyStrength().defaultEquivalence());
/* 138:    */   }
/* 139:    */   
/* 140:    */   @GwtIncompatible("To be supported")
/* 141:    */   CacheBuilder<K, V> valueEquivalence(Equivalence<Object> equivalence)
/* 142:    */   {
/* 143:312 */     Preconditions.checkState(this.valueEquivalence == null, "value equivalence was already set to %s", new Object[] { this.valueEquivalence });
/* 144:    */     
/* 145:314 */     this.valueEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 146:315 */     return this;
/* 147:    */   }
/* 148:    */   
/* 149:    */   Equivalence<Object> getValueEquivalence()
/* 150:    */   {
/* 151:319 */     return (Equivalence)Objects.firstNonNull(this.valueEquivalence, getValueStrength().defaultEquivalence());
/* 152:    */   }
/* 153:    */   
/* 154:    */   public CacheBuilder<K, V> initialCapacity(int initialCapacity)
/* 155:    */   {
/* 156:333 */     Preconditions.checkState(this.initialCapacity == -1, "initial capacity was already set to %s", new Object[] { Integer.valueOf(this.initialCapacity) });
/* 157:    */     
/* 158:335 */     Preconditions.checkArgument(initialCapacity >= 0);
/* 159:336 */     this.initialCapacity = initialCapacity;
/* 160:337 */     return this;
/* 161:    */   }
/* 162:    */   
/* 163:    */   int getInitialCapacity()
/* 164:    */   {
/* 165:341 */     return this.initialCapacity == -1 ? 16 : this.initialCapacity;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public CacheBuilder<K, V> concurrencyLevel(int concurrencyLevel)
/* 169:    */   {
/* 170:375 */     Preconditions.checkState(this.concurrencyLevel == -1, "concurrency level was already set to %s", new Object[] { Integer.valueOf(this.concurrencyLevel) });
/* 171:    */     
/* 172:377 */     Preconditions.checkArgument(concurrencyLevel > 0);
/* 173:378 */     this.concurrencyLevel = concurrencyLevel;
/* 174:379 */     return this;
/* 175:    */   }
/* 176:    */   
/* 177:    */   int getConcurrencyLevel()
/* 178:    */   {
/* 179:383 */     return this.concurrencyLevel == -1 ? 4 : this.concurrencyLevel;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public CacheBuilder<K, V> maximumSize(long size)
/* 183:    */   {
/* 184:402 */     Preconditions.checkState(this.maximumSize == -1L, "maximum size was already set to %s", new Object[] { Long.valueOf(this.maximumSize) });
/* 185:    */     
/* 186:404 */     Preconditions.checkState(this.maximumWeight == -1L, "maximum weight was already set to %s", new Object[] { Long.valueOf(this.maximumWeight) });
/* 187:    */     
/* 188:406 */     Preconditions.checkState(this.weigher == null, "maximum size can not be combined with weigher");
/* 189:407 */     Preconditions.checkArgument(size >= 0L, "maximum size must not be negative");
/* 190:408 */     this.maximumSize = size;
/* 191:409 */     return this;
/* 192:    */   }
/* 193:    */   
/* 194:    */   @GwtIncompatible("To be supported")
/* 195:    */   public CacheBuilder<K, V> maximumWeight(long weight)
/* 196:    */   {
/* 197:438 */     Preconditions.checkState(this.maximumWeight == -1L, "maximum weight was already set to %s", new Object[] { Long.valueOf(this.maximumWeight) });
/* 198:    */     
/* 199:440 */     Preconditions.checkState(this.maximumSize == -1L, "maximum size was already set to %s", new Object[] { Long.valueOf(this.maximumSize) });
/* 200:    */     
/* 201:442 */     this.maximumWeight = weight;
/* 202:443 */     Preconditions.checkArgument(weight >= 0L, "maximum weight must not be negative");
/* 203:444 */     return this;
/* 204:    */   }
/* 205:    */   
/* 206:    */   @GwtIncompatible("To be supported")
/* 207:    */   public <K1 extends K, V1 extends V> CacheBuilder<K1, V1> weigher(Weigher<? super K1, ? super V1> weigher)
/* 208:    */   {
/* 209:478 */     Preconditions.checkState(this.weigher == null);
/* 210:479 */     if (this.strictParsing) {
/* 211:480 */       Preconditions.checkState(this.maximumSize == -1L, "weigher can not be combined with maximum size", new Object[] { Long.valueOf(this.maximumSize) });
/* 212:    */     }
/* 213:486 */     CacheBuilder<K1, V1> me = this;
/* 214:487 */     me.weigher = ((Weigher)Preconditions.checkNotNull(weigher));
/* 215:488 */     return me;
/* 216:    */   }
/* 217:    */   
/* 218:    */   long getMaximumWeight()
/* 219:    */   {
/* 220:492 */     if ((this.expireAfterWriteNanos == 0L) || (this.expireAfterAccessNanos == 0L)) {
/* 221:493 */       return 0L;
/* 222:    */     }
/* 223:495 */     return this.weigher == null ? this.maximumSize : this.maximumWeight;
/* 224:    */   }
/* 225:    */   
/* 226:    */   <K1 extends K, V1 extends V> Weigher<K1, V1> getWeigher()
/* 227:    */   {
/* 228:501 */     return (Weigher)Objects.firstNonNull(this.weigher, OneWeigher.INSTANCE);
/* 229:    */   }
/* 230:    */   
/* 231:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 232:    */   public CacheBuilder<K, V> weakKeys()
/* 233:    */   {
/* 234:519 */     return setKeyStrength(LocalCache.Strength.WEAK);
/* 235:    */   }
/* 236:    */   
/* 237:    */   CacheBuilder<K, V> setKeyStrength(LocalCache.Strength strength)
/* 238:    */   {
/* 239:523 */     Preconditions.checkState(this.keyStrength == null, "Key strength was already set to %s", new Object[] { this.keyStrength });
/* 240:524 */     this.keyStrength = ((LocalCache.Strength)Preconditions.checkNotNull(strength));
/* 241:525 */     return this;
/* 242:    */   }
/* 243:    */   
/* 244:    */   LocalCache.Strength getKeyStrength()
/* 245:    */   {
/* 246:529 */     return (LocalCache.Strength)Objects.firstNonNull(this.keyStrength, LocalCache.Strength.STRONG);
/* 247:    */   }
/* 248:    */   
/* 249:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 250:    */   public CacheBuilder<K, V> weakValues()
/* 251:    */   {
/* 252:550 */     return setValueStrength(LocalCache.Strength.WEAK);
/* 253:    */   }
/* 254:    */   
/* 255:    */   @GwtIncompatible("java.lang.ref.SoftReference")
/* 256:    */   public CacheBuilder<K, V> softValues()
/* 257:    */   {
/* 258:574 */     return setValueStrength(LocalCache.Strength.SOFT);
/* 259:    */   }
/* 260:    */   
/* 261:    */   CacheBuilder<K, V> setValueStrength(LocalCache.Strength strength)
/* 262:    */   {
/* 263:578 */     Preconditions.checkState(this.valueStrength == null, "Value strength was already set to %s", new Object[] { this.valueStrength });
/* 264:579 */     this.valueStrength = ((LocalCache.Strength)Preconditions.checkNotNull(strength));
/* 265:580 */     return this;
/* 266:    */   }
/* 267:    */   
/* 268:    */   LocalCache.Strength getValueStrength()
/* 269:    */   {
/* 270:584 */     return (LocalCache.Strength)Objects.firstNonNull(this.valueStrength, LocalCache.Strength.STRONG);
/* 271:    */   }
/* 272:    */   
/* 273:    */   public CacheBuilder<K, V> expireAfterWrite(long duration, TimeUnit unit)
/* 274:    */   {
/* 275:607 */     Preconditions.checkState(this.expireAfterWriteNanos == -1L, "expireAfterWrite was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterWriteNanos) });
/* 276:    */     
/* 277:609 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 278:610 */     this.expireAfterWriteNanos = unit.toNanos(duration);
/* 279:611 */     return this;
/* 280:    */   }
/* 281:    */   
/* 282:    */   long getExpireAfterWriteNanos()
/* 283:    */   {
/* 284:615 */     return this.expireAfterWriteNanos == -1L ? 0L : this.expireAfterWriteNanos;
/* 285:    */   }
/* 286:    */   
/* 287:    */   public CacheBuilder<K, V> expireAfterAccess(long duration, TimeUnit unit)
/* 288:    */   {
/* 289:641 */     Preconditions.checkState(this.expireAfterAccessNanos == -1L, "expireAfterAccess was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterAccessNanos) });
/* 290:    */     
/* 291:643 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 292:644 */     this.expireAfterAccessNanos = unit.toNanos(duration);
/* 293:645 */     return this;
/* 294:    */   }
/* 295:    */   
/* 296:    */   long getExpireAfterAccessNanos()
/* 297:    */   {
/* 298:649 */     return this.expireAfterAccessNanos == -1L ? 0L : this.expireAfterAccessNanos;
/* 299:    */   }
/* 300:    */   
/* 301:    */   @Beta
/* 302:    */   @GwtIncompatible("To be supported (synchronously).")
/* 303:    */   public CacheBuilder<K, V> refreshAfterWrite(long duration, TimeUnit unit)
/* 304:    */   {
/* 305:681 */     Preconditions.checkNotNull(unit);
/* 306:682 */     Preconditions.checkState(this.refreshNanos == -1L, "refresh was already set to %s ns", new Object[] { Long.valueOf(this.refreshNanos) });
/* 307:683 */     Preconditions.checkArgument(duration > 0L, "duration must be positive: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 308:684 */     this.refreshNanos = unit.toNanos(duration);
/* 309:685 */     return this;
/* 310:    */   }
/* 311:    */   
/* 312:    */   long getRefreshNanos()
/* 313:    */   {
/* 314:689 */     return this.refreshNanos == -1L ? 0L : this.refreshNanos;
/* 315:    */   }
/* 316:    */   
/* 317:    */   public CacheBuilder<K, V> ticker(Ticker ticker)
/* 318:    */   {
/* 319:702 */     Preconditions.checkState(this.ticker == null);
/* 320:703 */     this.ticker = ((Ticker)Preconditions.checkNotNull(ticker));
/* 321:704 */     return this;
/* 322:    */   }
/* 323:    */   
/* 324:    */   Ticker getTicker(boolean recordsTime)
/* 325:    */   {
/* 326:708 */     if (this.ticker != null) {
/* 327:709 */       return this.ticker;
/* 328:    */     }
/* 329:711 */     return recordsTime ? Ticker.systemTicker() : NULL_TICKER;
/* 330:    */   }
/* 331:    */   
/* 332:    */   @CheckReturnValue
/* 333:    */   public <K1 extends K, V1 extends V> CacheBuilder<K1, V1> removalListener(RemovalListener<? super K1, ? super V1> listener)
/* 334:    */   {
/* 335:738 */     Preconditions.checkState(this.removalListener == null);
/* 336:    */     
/* 337:    */ 
/* 338:    */ 
/* 339:742 */     CacheBuilder<K1, V1> me = this;
/* 340:743 */     me.removalListener = ((RemovalListener)Preconditions.checkNotNull(listener));
/* 341:744 */     return me;
/* 342:    */   }
/* 343:    */   
/* 344:    */   <K1 extends K, V1 extends V> RemovalListener<K1, V1> getRemovalListener()
/* 345:    */   {
/* 346:750 */     return (RemovalListener)Objects.firstNonNull(this.removalListener, NullListener.INSTANCE);
/* 347:    */   }
/* 348:    */   
/* 349:    */   public CacheBuilder<K, V> recordStats()
/* 350:    */   {
/* 351:762 */     this.statsCounterSupplier = CACHE_STATS_COUNTER;
/* 352:763 */     return this;
/* 353:    */   }
/* 354:    */   
/* 355:    */   boolean isRecordingStats()
/* 356:    */   {
/* 357:767 */     return this.statsCounterSupplier == CACHE_STATS_COUNTER;
/* 358:    */   }
/* 359:    */   
/* 360:    */   Supplier<? extends AbstractCache.StatsCounter> getStatsCounterSupplier()
/* 361:    */   {
/* 362:771 */     return this.statsCounterSupplier;
/* 363:    */   }
/* 364:    */   
/* 365:    */   public <K1 extends K, V1 extends V> LoadingCache<K1, V1> build(CacheLoader<? super K1, V1> loader)
/* 366:    */   {
/* 367:788 */     checkWeightWithWeigher();
/* 368:789 */     return new LocalCache.LocalLoadingCache(this, loader);
/* 369:    */   }
/* 370:    */   
/* 371:    */   public <K1 extends K, V1 extends V> Cache<K1, V1> build()
/* 372:    */   {
/* 373:805 */     checkWeightWithWeigher();
/* 374:806 */     checkNonLoadingCache();
/* 375:807 */     return new LocalCache.LocalManualCache(this);
/* 376:    */   }
/* 377:    */   
/* 378:    */   private void checkNonLoadingCache()
/* 379:    */   {
/* 380:811 */     Preconditions.checkState(this.refreshNanos == -1L, "refreshAfterWrite requires a LoadingCache");
/* 381:    */   }
/* 382:    */   
/* 383:    */   private void checkWeightWithWeigher()
/* 384:    */   {
/* 385:815 */     if (this.weigher == null) {
/* 386:816 */       Preconditions.checkState(this.maximumWeight == -1L, "maximumWeight requires weigher");
/* 387:818 */     } else if (this.strictParsing) {
/* 388:819 */       Preconditions.checkState(this.maximumWeight != -1L, "weigher requires maximumWeight");
/* 389:821 */     } else if (this.maximumWeight == -1L) {
/* 390:822 */       logger.log(Level.WARNING, "ignoring weigher specified without maximumWeight");
/* 391:    */     }
/* 392:    */   }
/* 393:    */   
/* 394:    */   public String toString()
/* 395:    */   {
/* 396:834 */     Objects.ToStringHelper s = Objects.toStringHelper(this);
/* 397:835 */     if (this.initialCapacity != -1) {
/* 398:836 */       s.add("initialCapacity", this.initialCapacity);
/* 399:    */     }
/* 400:838 */     if (this.concurrencyLevel != -1) {
/* 401:839 */       s.add("concurrencyLevel", this.concurrencyLevel);
/* 402:    */     }
/* 403:841 */     if (this.maximumSize != -1L) {
/* 404:842 */       s.add("maximumSize", this.maximumSize);
/* 405:    */     }
/* 406:844 */     if (this.maximumWeight != -1L) {
/* 407:845 */       s.add("maximumWeight", this.maximumWeight);
/* 408:    */     }
/* 409:847 */     if (this.expireAfterWriteNanos != -1L) {
/* 410:848 */       s.add("expireAfterWrite", this.expireAfterWriteNanos + "ns");
/* 411:    */     }
/* 412:850 */     if (this.expireAfterAccessNanos != -1L) {
/* 413:851 */       s.add("expireAfterAccess", this.expireAfterAccessNanos + "ns");
/* 414:    */     }
/* 415:853 */     if (this.keyStrength != null) {
/* 416:854 */       s.add("keyStrength", Ascii.toLowerCase(this.keyStrength.toString()));
/* 417:    */     }
/* 418:856 */     if (this.valueStrength != null) {
/* 419:857 */       s.add("valueStrength", Ascii.toLowerCase(this.valueStrength.toString()));
/* 420:    */     }
/* 421:859 */     if (this.keyEquivalence != null) {
/* 422:860 */       s.addValue("keyEquivalence");
/* 423:    */     }
/* 424:862 */     if (this.valueEquivalence != null) {
/* 425:863 */       s.addValue("valueEquivalence");
/* 426:    */     }
/* 427:865 */     if (this.removalListener != null) {
/* 428:866 */       s.addValue("removalListener");
/* 429:    */     }
/* 430:868 */     return s.toString();
/* 431:    */   }
/* 432:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.CacheBuilder
 * JD-Core Version:    0.7.0.1
 */
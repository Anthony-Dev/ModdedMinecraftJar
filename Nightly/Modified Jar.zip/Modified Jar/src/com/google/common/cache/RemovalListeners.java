/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.concurrent.Executor;
/*  6:   */ 
/*  7:   */ @Beta
/*  8:   */ public final class RemovalListeners
/*  9:   */ {
/* 10:   */   public static <K, V> RemovalListener<K, V> asynchronous(final RemovalListener<K, V> listener, Executor executor)
/* 11:   */   {
/* 12:46 */     Preconditions.checkNotNull(listener);
/* 13:47 */     Preconditions.checkNotNull(executor);
/* 14:48 */     new RemovalListener()
/* 15:   */     {
/* 16:   */       public void onRemoval(final RemovalNotification<K, V> notification)
/* 17:   */       {
/* 18:51 */         this.val$executor.execute(new Runnable()
/* 19:   */         {
/* 20:   */           public void run()
/* 21:   */           {
/* 22:54 */             RemovalListeners.1.this.val$listener.onRemoval(notification);
/* 23:   */           }
/* 24:   */         });
/* 25:   */       }
/* 26:   */     };
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.RemovalListeners
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import com.google.common.base.Objects;
/*  6:   */ import com.google.common.base.Preconditions;
/*  7:   */ import java.util.Map.Entry;
/*  8:   */ import javax.annotation.Nullable;
/*  9:   */ 
/* 10:   */ @Beta
/* 11:   */ @GwtCompatible
/* 12:   */ public final class RemovalNotification<K, V>
/* 13:   */   implements Map.Entry<K, V>
/* 14:   */ {
/* 15:   */   @Nullable
/* 16:   */   private final K key;
/* 17:   */   @Nullable
/* 18:   */   private final V value;
/* 19:   */   private final RemovalCause cause;
/* 20:   */   private static final long serialVersionUID = 0L;
/* 21:   */   
/* 22:   */   RemovalNotification(@Nullable K key, @Nullable V value, RemovalCause cause)
/* 23:   */   {
/* 24:48 */     this.key = key;
/* 25:49 */     this.value = value;
/* 26:50 */     this.cause = ((RemovalCause)Preconditions.checkNotNull(cause));
/* 27:   */   }
/* 28:   */   
/* 29:   */   public RemovalCause getCause()
/* 30:   */   {
/* 31:57 */     return this.cause;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public boolean wasEvicted()
/* 35:   */   {
/* 36:65 */     return this.cause.wasEvicted();
/* 37:   */   }
/* 38:   */   
/* 39:   */   @Nullable
/* 40:   */   public K getKey()
/* 41:   */   {
/* 42:69 */     return this.key;
/* 43:   */   }
/* 44:   */   
/* 45:   */   @Nullable
/* 46:   */   public V getValue()
/* 47:   */   {
/* 48:73 */     return this.value;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public final V setValue(V value)
/* 52:   */   {
/* 53:77 */     throw new UnsupportedOperationException();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public boolean equals(@Nullable Object object)
/* 57:   */   {
/* 58:81 */     if ((object instanceof Map.Entry))
/* 59:   */     {
/* 60:82 */       Map.Entry<?, ?> that = (Map.Entry)object;
/* 61:83 */       return (Objects.equal(getKey(), that.getKey())) && (Objects.equal(getValue(), that.getValue()));
/* 62:   */     }
/* 63:86 */     return false;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public int hashCode()
/* 67:   */   {
/* 68:90 */     K k = getKey();
/* 69:91 */     V v = getValue();
/* 70:92 */     return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
/* 71:   */   }
/* 72:   */   
/* 73:   */   public String toString()
/* 74:   */   {
/* 75:99 */     return getKey() + "=" + getValue();
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.RemovalNotification
 * JD-Core Version:    0.7.0.1
 */
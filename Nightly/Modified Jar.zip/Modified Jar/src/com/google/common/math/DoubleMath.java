/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.primitives.Booleans;
/*   8:    */ import java.math.BigInteger;
/*   9:    */ import java.math.RoundingMode;
/*  10:    */ import java.util.Iterator;
/*  11:    */ 
/*  12:    */ @GwtCompatible(emulated=true)
/*  13:    */ public final class DoubleMath
/*  14:    */ {
/*  15:    */   private static final double MIN_INT_AS_DOUBLE = -2147483648.0D;
/*  16:    */   private static final double MAX_INT_AS_DOUBLE = 2147483647.0D;
/*  17:    */   private static final double MIN_LONG_AS_DOUBLE = -9.223372036854776E+018D;
/*  18:    */   private static final double MAX_LONG_AS_DOUBLE_PLUS_ONE = 9.223372036854776E+018D;
/*  19:    */   
/*  20:    */   @GwtIncompatible("#isMathematicalInteger, com.google.common.math.DoubleUtils")
/*  21:    */   static double roundIntermediate(double x, RoundingMode mode)
/*  22:    */   {
/*  23: 58 */     if (!DoubleUtils.isFinite(x)) {
/*  24: 59 */       throw new ArithmeticException("input is infinite or NaN");
/*  25:    */     }
/*  26: 61 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  27:    */     {
/*  28:    */     case 1: 
/*  29: 63 */       MathPreconditions.checkRoundingUnnecessary(isMathematicalInteger(x));
/*  30: 64 */       return x;
/*  31:    */     case 2: 
/*  32: 67 */       if ((x >= 0.0D) || (isMathematicalInteger(x))) {
/*  33: 68 */         return x;
/*  34:    */       }
/*  35: 70 */       return x - 1.0D;
/*  36:    */     case 3: 
/*  37: 74 */       if ((x <= 0.0D) || (isMathematicalInteger(x))) {
/*  38: 75 */         return x;
/*  39:    */       }
/*  40: 77 */       return x + 1.0D;
/*  41:    */     case 4: 
/*  42: 81 */       return x;
/*  43:    */     case 5: 
/*  44: 84 */       if (isMathematicalInteger(x)) {
/*  45: 85 */         return x;
/*  46:    */       }
/*  47: 87 */       return x + Math.copySign(1.0D, x);
/*  48:    */     case 6: 
/*  49: 91 */       return Math.rint(x);
/*  50:    */     case 7: 
/*  51: 94 */       double z = Math.rint(x);
/*  52: 95 */       if (Math.abs(x - z) == 0.5D) {
/*  53: 96 */         return x + Math.copySign(0.5D, x);
/*  54:    */       }
/*  55: 98 */       return z;
/*  56:    */     case 8: 
/*  57:103 */       double z = Math.rint(x);
/*  58:104 */       if (Math.abs(x - z) == 0.5D) {
/*  59:105 */         return x;
/*  60:    */       }
/*  61:107 */       return z;
/*  62:    */     }
/*  63:112 */     throw new AssertionError();
/*  64:    */   }
/*  65:    */   
/*  66:    */   @GwtIncompatible("#roundIntermediate")
/*  67:    */   public static int roundToInt(double x, RoundingMode mode)
/*  68:    */   {
/*  69:132 */     double z = roundIntermediate(x, mode);
/*  70:133 */     MathPreconditions.checkInRange((z > -2147483649.0D ? 1 : 0) & (z < 2147483648.0D ? 1 : 0));
/*  71:134 */     return (int)z;
/*  72:    */   }
/*  73:    */   
/*  74:    */   @GwtIncompatible("#roundIntermediate")
/*  75:    */   public static long roundToLong(double x, RoundingMode mode)
/*  76:    */   {
/*  77:156 */     double z = roundIntermediate(x, mode);
/*  78:157 */     MathPreconditions.checkInRange((-9.223372036854776E+018D - z < 1.0D ? 1 : 0) & (z < 9.223372036854776E+018D ? 1 : 0));
/*  79:158 */     return z;
/*  80:    */   }
/*  81:    */   
/*  82:    */   @GwtIncompatible("#roundIntermediate, java.lang.Math.getExponent, com.google.common.math.DoubleUtils")
/*  83:    */   public static BigInteger roundToBigInteger(double x, RoundingMode mode)
/*  84:    */   {
/*  85:182 */     x = roundIntermediate(x, mode);
/*  86:183 */     if (((-9.223372036854776E+018D - x < 1.0D ? 1 : 0) & (x < 9.223372036854776E+018D ? 1 : 0)) != 0) {
/*  87:184 */       return BigInteger.valueOf(x);
/*  88:    */     }
/*  89:186 */     int exponent = Math.getExponent(x);
/*  90:187 */     long significand = DoubleUtils.getSignificand(x);
/*  91:188 */     BigInteger result = BigInteger.valueOf(significand).shiftLeft(exponent - 52);
/*  92:189 */     return x < 0.0D ? result.negate() : result;
/*  93:    */   }
/*  94:    */   
/*  95:    */   @GwtIncompatible("com.google.common.math.DoubleUtils")
/*  96:    */   public static boolean isPowerOfTwo(double x)
/*  97:    */   {
/*  98:198 */     return (x > 0.0D) && (DoubleUtils.isFinite(x)) && (LongMath.isPowerOfTwo(DoubleUtils.getSignificand(x)));
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static double log2(double x)
/* 102:    */   {
/* 103:217 */     return Math.log(x) / LN_2;
/* 104:    */   }
/* 105:    */   
/* 106:220 */   private static final double LN_2 = Math.log(2.0D);
/* 107:    */   @VisibleForTesting
/* 108:    */   static final int MAX_FACTORIAL = 170;
/* 109:    */   
/* 110:    */   @GwtIncompatible("java.lang.Math.getExponent, com.google.common.math.DoubleUtils")
/* 111:    */   public static int log2(double x, RoundingMode mode)
/* 112:    */   {
/* 113:234 */     Preconditions.checkArgument((x > 0.0D) && (DoubleUtils.isFinite(x)), "x must be positive and finite");
/* 114:235 */     int exponent = Math.getExponent(x);
/* 115:236 */     if (!DoubleUtils.isNormal(x)) {
/* 116:237 */       return log2(x * 4503599627370496.0D, mode) - 52;
/* 117:    */     }
/* 118:    */     boolean increment;
/* 119:242 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 120:    */     {
/* 121:    */     case 1: 
/* 122:244 */       MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
/* 123:    */     case 2: 
/* 124:247 */       increment = false;
/* 125:248 */       break;
/* 126:    */     case 3: 
/* 127:250 */       increment = !isPowerOfTwo(x);
/* 128:251 */       break;
/* 129:    */     case 4: 
/* 130:253 */       increment = (exponent < 0 ? 1 : 0) & (!isPowerOfTwo(x) ? 1 : 0);
/* 131:254 */       break;
/* 132:    */     case 5: 
/* 133:256 */       increment = (exponent >= 0 ? 1 : 0) & (!isPowerOfTwo(x) ? 1 : 0);
/* 134:257 */       break;
/* 135:    */     case 6: 
/* 136:    */     case 7: 
/* 137:    */     case 8: 
/* 138:261 */       double xScaled = DoubleUtils.scaleNormalize(x);
/* 139:    */       
/* 140:    */ 
/* 141:264 */       increment = xScaled * xScaled > 2.0D;
/* 142:265 */       break;
/* 143:    */     default: 
/* 144:267 */       throw new AssertionError();
/* 145:    */     }
/* 146:269 */     return increment ? exponent + 1 : exponent;
/* 147:    */   }
/* 148:    */   
/* 149:    */   @GwtIncompatible("java.lang.Math.getExponent, com.google.common.math.DoubleUtils")
/* 150:    */   public static boolean isMathematicalInteger(double x)
/* 151:    */   {
/* 152:280 */     return (DoubleUtils.isFinite(x)) && ((x == 0.0D) || (52 - Long.numberOfTrailingZeros(DoubleUtils.getSignificand(x)) <= Math.getExponent(x)));
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static double factorial(int n)
/* 156:    */   {
/* 157:295 */     MathPreconditions.checkNonNegative("n", n);
/* 158:296 */     if (n > 170) {
/* 159:297 */       return (1.0D / 0.0D);
/* 160:    */     }
/* 161:301 */     double accum = 1.0D;
/* 162:302 */     for (int i = 1 + (n & 0xFFFFFFF0); i <= n; i++) {
/* 163:303 */       accum *= i;
/* 164:    */     }
/* 165:305 */     return accum * everySixteenthFactorial[(n >> 4)];
/* 166:    */   }
/* 167:    */   
/* 168:    */   @VisibleForTesting
/* 169:313 */   static final double[] everySixteenthFactorial = { 1.0D, 20922789888000.0D, 2.631308369336935E+035D, 1.241391559253607E+061D, 1.268869321858842E+089D, 7.156945704626381E+118D, 9.916779348709497E+149D, 1.974506857221074E+182D, 3.856204823625804E+215D, 5.550293832739304E+249D, 4.714723635992062E+284D };
/* 170:    */   
/* 171:    */   public static boolean fuzzyEquals(double a, double b, double tolerance)
/* 172:    */   {
/* 173:352 */     MathPreconditions.checkNonNegative("tolerance", tolerance);
/* 174:353 */     return (Math.copySign(a - b, 1.0D) <= tolerance) || (a == b) || ((Double.isNaN(a)) && (Double.isNaN(b)));
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static int fuzzyCompare(double a, double b, double tolerance)
/* 178:    */   {
/* 179:375 */     if (fuzzyEquals(a, b, tolerance)) {
/* 180:376 */       return 0;
/* 181:    */     }
/* 182:377 */     if (a < b) {
/* 183:378 */       return -1;
/* 184:    */     }
/* 185:379 */     if (a > b) {
/* 186:380 */       return 1;
/* 187:    */     }
/* 188:382 */     return Booleans.compare(Double.isNaN(a), Double.isNaN(b));
/* 189:    */   }
/* 190:    */   
/* 191:    */   @GwtIncompatible("com.google.common.math.DoubleUtils")
/* 192:    */   private static final class MeanAccumulator
/* 193:    */   {
/* 194:389 */     private long count = 0L;
/* 195:390 */     private double mean = 0.0D;
/* 196:    */     
/* 197:    */     void add(double value)
/* 198:    */     {
/* 199:393 */       Preconditions.checkArgument(DoubleUtils.isFinite(value));
/* 200:394 */       this.count += 1L;
/* 201:    */       
/* 202:396 */       this.mean += (value - this.mean) / this.count;
/* 203:    */     }
/* 204:    */     
/* 205:    */     double mean()
/* 206:    */     {
/* 207:400 */       Preconditions.checkArgument(this.count > 0L, "Cannot take mean of 0 values");
/* 208:401 */       return this.mean;
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   @GwtIncompatible("MeanAccumulator")
/* 213:    */   public static double mean(double... values)
/* 214:    */   {
/* 215:411 */     MeanAccumulator accumulator = new MeanAccumulator(null);
/* 216:412 */     for (double value : values) {
/* 217:413 */       accumulator.add(value);
/* 218:    */     }
/* 219:415 */     return accumulator.mean();
/* 220:    */   }
/* 221:    */   
/* 222:    */   @GwtIncompatible("MeanAccumulator")
/* 223:    */   public static double mean(int... values)
/* 224:    */   {
/* 225:424 */     MeanAccumulator accumulator = new MeanAccumulator(null);
/* 226:425 */     for (int value : values) {
/* 227:426 */       accumulator.add(value);
/* 228:    */     }
/* 229:428 */     return accumulator.mean();
/* 230:    */   }
/* 231:    */   
/* 232:    */   @GwtIncompatible("MeanAccumulator")
/* 233:    */   public static double mean(long... values)
/* 234:    */   {
/* 235:438 */     MeanAccumulator accumulator = new MeanAccumulator(null);
/* 236:439 */     for (long value : values) {
/* 237:440 */       accumulator.add(value);
/* 238:    */     }
/* 239:442 */     return accumulator.mean();
/* 240:    */   }
/* 241:    */   
/* 242:    */   @GwtIncompatible("MeanAccumulator")
/* 243:    */   public static double mean(Iterable<? extends Number> values)
/* 244:    */   {
/* 245:452 */     MeanAccumulator accumulator = new MeanAccumulator(null);
/* 246:453 */     for (Number value : values) {
/* 247:454 */       accumulator.add(value.doubleValue());
/* 248:    */     }
/* 249:456 */     return accumulator.mean();
/* 250:    */   }
/* 251:    */   
/* 252:    */   @GwtIncompatible("MeanAccumulator")
/* 253:    */   public static double mean(Iterator<? extends Number> values)
/* 254:    */   {
/* 255:466 */     MeanAccumulator accumulator = new MeanAccumulator(null);
/* 256:467 */     while (values.hasNext()) {
/* 257:468 */       accumulator.add(((Number)values.next()).doubleValue());
/* 258:    */     }
/* 259:470 */     return accumulator.mean();
/* 260:    */   }
/* 261:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.math.DoubleMath
 * JD-Core Version:    0.7.0.1
 */
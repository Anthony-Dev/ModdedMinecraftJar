/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.math.RoundingMode;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ public final class LongMath
/*  11:    */ {
/*  12:    */   @VisibleForTesting
/*  13:    */   static final long MAX_POWER_OF_SQRT2_UNSIGNED = -5402926248376769404L;
/*  14:    */   
/*  15:    */   public static boolean isPowerOfTwo(long x)
/*  16:    */   {
/*  17: 62 */     return (x > 0L ? 1 : 0) & ((x & x - 1L) == 0L ? 1 : 0);
/*  18:    */   }
/*  19:    */   
/*  20:    */   @VisibleForTesting
/*  21:    */   static int lessThanBranchFree(long x, long y)
/*  22:    */   {
/*  23: 73 */     return (int)((x - y ^ 0xFFFFFFFF ^ 0xFFFFFFFF) >>> 63);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static int log2(long x, RoundingMode mode)
/*  27:    */   {
/*  28: 86 */     MathPreconditions.checkPositive("x", x);
/*  29: 87 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  30:    */     {
/*  31:    */     case 1: 
/*  32: 89 */       MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
/*  33:    */     case 2: 
/*  34:    */     case 3: 
/*  35: 93 */       return 63 - Long.numberOfLeadingZeros(x);
/*  36:    */     case 4: 
/*  37:    */     case 5: 
/*  38: 97 */       return 64 - Long.numberOfLeadingZeros(x - 1L);
/*  39:    */     case 6: 
/*  40:    */     case 7: 
/*  41:    */     case 8: 
/*  42:103 */       int leadingZeros = Long.numberOfLeadingZeros(x);
/*  43:104 */       long cmp = -5402926248376769404L >>> leadingZeros;
/*  44:    */       
/*  45:106 */       int logFloor = 63 - leadingZeros;
/*  46:107 */       return logFloor + lessThanBranchFree(cmp, x);
/*  47:    */     }
/*  48:110 */     throw new AssertionError("impossible");
/*  49:    */   }
/*  50:    */   
/*  51:    */   @GwtIncompatible("TODO")
/*  52:    */   public static int log10(long x, RoundingMode mode)
/*  53:    */   {
/*  54:128 */     MathPreconditions.checkPositive("x", x);
/*  55:129 */     int logFloor = log10Floor(x);
/*  56:130 */     long floorPow = powersOf10[logFloor];
/*  57:131 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  58:    */     {
/*  59:    */     case 1: 
/*  60:133 */       MathPreconditions.checkRoundingUnnecessary(x == floorPow);
/*  61:    */     case 2: 
/*  62:    */     case 3: 
/*  63:137 */       return logFloor;
/*  64:    */     case 4: 
/*  65:    */     case 5: 
/*  66:140 */       return logFloor + lessThanBranchFree(floorPow, x);
/*  67:    */     case 6: 
/*  68:    */     case 7: 
/*  69:    */     case 8: 
/*  70:145 */       return logFloor + lessThanBranchFree(halfPowersOf10[logFloor], x);
/*  71:    */     }
/*  72:147 */     throw new AssertionError();
/*  73:    */   }
/*  74:    */   
/*  75:    */   @GwtIncompatible("TODO")
/*  76:    */   static int log10Floor(long x)
/*  77:    */   {
/*  78:160 */     int y = maxLog10ForLeadingZeros[Long.numberOfLeadingZeros(x)];
/*  79:    */     
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:165 */     return y - lessThanBranchFree(x, powersOf10[y]);
/*  84:    */   }
/*  85:    */   
/*  86:    */   @VisibleForTesting
/*  87:169 */   static final byte[] maxLog10ForLeadingZeros = { 19, 18, 18, 18, 18, 17, 17, 17, 16, 16, 16, 15, 15, 15, 15, 14, 14, 14, 13, 13, 13, 12, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9, 9, 9, 8, 8, 8, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 4, 4, 4, 3, 3, 3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 0 };
/*  88:    */   @GwtIncompatible("TODO")
/*  89:    */   @VisibleForTesting
/*  90:176 */   static final long[] powersOf10 = { 1L, 10L, 100L, 1000L, 10000L, 100000L, 1000000L, 10000000L, 100000000L, 1000000000L, 10000000000L, 100000000000L, 1000000000000L, 10000000000000L, 100000000000000L, 1000000000000000L, 10000000000000000L, 100000000000000000L, 1000000000000000000L };
/*  91:    */   @GwtIncompatible("TODO")
/*  92:    */   @VisibleForTesting
/*  93:201 */   static final long[] halfPowersOf10 = { 3L, 31L, 316L, 3162L, 31622L, 316227L, 3162277L, 31622776L, 316227766L, 3162277660L, 31622776601L, 316227766016L, 3162277660168L, 31622776601683L, 316227766016837L, 3162277660168379L, 31622776601683793L, 316227766016837933L, 3162277660168379331L };
/*  94:    */   @VisibleForTesting
/*  95:    */   static final long FLOOR_SQRT_MAX_LONG = 3037000499L;
/*  96:    */   
/*  97:    */   @GwtIncompatible("TODO")
/*  98:    */   public static long pow(long b, int k)
/*  99:    */   {
/* 100:232 */     MathPreconditions.checkNonNegative("exponent", k);
/* 101:233 */     if ((-2L <= b) && (b <= 2L))
/* 102:    */     {
/* 103:234 */       switch ((int)b)
/* 104:    */       {
/* 105:    */       case 0: 
/* 106:236 */         return k == 0 ? 1L : 0L;
/* 107:    */       case 1: 
/* 108:238 */         return 1L;
/* 109:    */       case -1: 
/* 110:240 */         return (k & 0x1) == 0 ? 1L : -1L;
/* 111:    */       case 2: 
/* 112:242 */         return k < 64 ? 1L << k : 0L;
/* 113:    */       case -2: 
/* 114:244 */         if (k < 64) {
/* 115:245 */           return (k & 0x1) == 0 ? 1L << k : -(1L << k);
/* 116:    */         }
/* 117:247 */         return 0L;
/* 118:    */       }
/* 119:250 */       throw new AssertionError();
/* 120:    */     }
/* 121:253 */     for (long accum = 1L;; k >>= 1)
/* 122:    */     {
/* 123:254 */       switch (k)
/* 124:    */       {
/* 125:    */       case 0: 
/* 126:256 */         return accum;
/* 127:    */       case 1: 
/* 128:258 */         return accum * b;
/* 129:    */       }
/* 130:260 */       accum *= ((k & 0x1) == 0 ? 1L : b);
/* 131:261 */       b *= b;
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   @GwtIncompatible("TODO")
/* 136:    */   public static long sqrt(long x, RoundingMode mode)
/* 137:    */   {
/* 138:276 */     MathPreconditions.checkNonNegative("x", x);
/* 139:277 */     if (fitsInInt(x)) {
/* 140:278 */       return IntMath.sqrt((int)x, mode);
/* 141:    */     }
/* 142:295 */     long guess = Math.sqrt(x);
/* 143:    */     
/* 144:297 */     long guessSquared = guess * guess;
/* 145:300 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 146:    */     {
/* 147:    */     case 1: 
/* 148:302 */       MathPreconditions.checkRoundingUnnecessary(guessSquared == x);
/* 149:303 */       return guess;
/* 150:    */     case 2: 
/* 151:    */     case 3: 
/* 152:306 */       if (x < guessSquared) {
/* 153:307 */         return guess - 1L;
/* 154:    */       }
/* 155:309 */       return guess;
/* 156:    */     case 4: 
/* 157:    */     case 5: 
/* 158:312 */       if (x > guessSquared) {
/* 159:313 */         return guess + 1L;
/* 160:    */       }
/* 161:315 */       return guess;
/* 162:    */     case 6: 
/* 163:    */     case 7: 
/* 164:    */     case 8: 
/* 165:319 */       long sqrtFloor = guess - (x < guessSquared ? 1 : 0);
/* 166:320 */       long halfSquare = sqrtFloor * sqrtFloor + sqrtFloor;
/* 167:    */       
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:332 */       return sqrtFloor + lessThanBranchFree(halfSquare, x);
/* 179:    */     }
/* 180:334 */     throw new AssertionError();
/* 181:    */   }
/* 182:    */   
/* 183:    */   @GwtIncompatible("TODO")
/* 184:    */   public static long divide(long p, long q, RoundingMode mode)
/* 185:    */   {
/* 186:348 */     Preconditions.checkNotNull(mode);
/* 187:349 */     long div = p / q;
/* 188:350 */     long rem = p - q * div;
/* 189:352 */     if (rem == 0L) {
/* 190:353 */       return div;
/* 191:    */     }
/* 192:363 */     int signum = 0x1 | (int)((p ^ q) >> 63);
/* 193:    */     boolean increment;
/* 194:    */     boolean increment;
/* 195:365 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 196:    */     {
/* 197:    */     case 1: 
/* 198:367 */       MathPreconditions.checkRoundingUnnecessary(rem == 0L);
/* 199:    */     case 2: 
/* 200:370 */       increment = false;
/* 201:371 */       break;
/* 202:    */     case 4: 
/* 203:373 */       increment = true;
/* 204:374 */       break;
/* 205:    */     case 5: 
/* 206:376 */       increment = signum > 0;
/* 207:377 */       break;
/* 208:    */     case 3: 
/* 209:379 */       increment = signum < 0;
/* 210:380 */       break;
/* 211:    */     case 6: 
/* 212:    */     case 7: 
/* 213:    */     case 8: 
/* 214:384 */       long absRem = Math.abs(rem);
/* 215:385 */       long cmpRemToHalfDivisor = absRem - (Math.abs(q) - absRem);
/* 216:388 */       if (cmpRemToHalfDivisor == 0L) {
/* 217:389 */         increment = (mode == RoundingMode.HALF_UP ? 1 : 0) | (mode == RoundingMode.HALF_EVEN ? 1 : 0) & ((div & 1L) != 0L ? 1 : 0);
/* 218:    */       } else {
/* 219:391 */         increment = cmpRemToHalfDivisor > 0L;
/* 220:    */       }
/* 221:393 */       break;
/* 222:    */     default: 
/* 223:395 */       throw new AssertionError();
/* 224:    */     }
/* 225:397 */     return increment ? div + signum : div;
/* 226:    */   }
/* 227:    */   
/* 228:    */   @GwtIncompatible("TODO")
/* 229:    */   public static int mod(long x, int m)
/* 230:    */   {
/* 231:421 */     return (int)mod(x, m);
/* 232:    */   }
/* 233:    */   
/* 234:    */   @GwtIncompatible("TODO")
/* 235:    */   public static long mod(long x, long m)
/* 236:    */   {
/* 237:444 */     if (m <= 0L) {
/* 238:445 */       throw new ArithmeticException("Modulus must be positive");
/* 239:    */     }
/* 240:447 */     long result = x % m;
/* 241:448 */     return result >= 0L ? result : result + m;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static long gcd(long a, long b)
/* 245:    */   {
/* 246:463 */     MathPreconditions.checkNonNegative("a", a);
/* 247:464 */     MathPreconditions.checkNonNegative("b", b);
/* 248:465 */     if (a == 0L) {
/* 249:468 */       return b;
/* 250:    */     }
/* 251:469 */     if (b == 0L) {
/* 252:470 */       return a;
/* 253:    */     }
/* 254:476 */     int aTwos = Long.numberOfTrailingZeros(a);
/* 255:477 */     a >>= aTwos;
/* 256:478 */     int bTwos = Long.numberOfTrailingZeros(b);
/* 257:479 */     b >>= bTwos;
/* 258:480 */     while (a != b)
/* 259:    */     {
/* 260:488 */       long delta = a - b;
/* 261:    */       
/* 262:490 */       long minDeltaOrZero = delta & delta >> 63;
/* 263:    */       
/* 264:    */ 
/* 265:493 */       a = delta - minDeltaOrZero - minDeltaOrZero;
/* 266:    */       
/* 267:    */ 
/* 268:496 */       b += minDeltaOrZero;
/* 269:497 */       a >>= Long.numberOfTrailingZeros(a);
/* 270:    */     }
/* 271:499 */     return a << Math.min(aTwos, bTwos);
/* 272:    */   }
/* 273:    */   
/* 274:    */   @GwtIncompatible("TODO")
/* 275:    */   public static long checkedAdd(long a, long b)
/* 276:    */   {
/* 277:509 */     long result = a + b;
/* 278:510 */     MathPreconditions.checkNoOverflow(((a ^ b) < 0L ? 1 : 0) | ((a ^ result) >= 0L ? 1 : 0));
/* 279:511 */     return result;
/* 280:    */   }
/* 281:    */   
/* 282:    */   @GwtIncompatible("TODO")
/* 283:    */   public static long checkedSubtract(long a, long b)
/* 284:    */   {
/* 285:521 */     long result = a - b;
/* 286:522 */     MathPreconditions.checkNoOverflow(((a ^ b) >= 0L ? 1 : 0) | ((a ^ result) >= 0L ? 1 : 0));
/* 287:523 */     return result;
/* 288:    */   }
/* 289:    */   
/* 290:    */   @GwtIncompatible("TODO")
/* 291:    */   public static long checkedMultiply(long a, long b)
/* 292:    */   {
/* 293:534 */     int leadingZeros = Long.numberOfLeadingZeros(a) + Long.numberOfLeadingZeros(a ^ 0xFFFFFFFF) + Long.numberOfLeadingZeros(b) + Long.numberOfLeadingZeros(b ^ 0xFFFFFFFF);
/* 294:546 */     if (leadingZeros > 65) {
/* 295:547 */       return a * b;
/* 296:    */     }
/* 297:549 */     MathPreconditions.checkNoOverflow(leadingZeros >= 64);
/* 298:550 */     MathPreconditions.checkNoOverflow((a >= 0L ? 1 : 0) | (b != -9223372036854775808L ? 1 : 0));
/* 299:551 */     long result = a * b;
/* 300:552 */     MathPreconditions.checkNoOverflow((a == 0L) || (result / a == b));
/* 301:553 */     return result;
/* 302:    */   }
/* 303:    */   
/* 304:    */   @GwtIncompatible("TODO")
/* 305:    */   public static long checkedPow(long b, int k)
/* 306:    */   {
/* 307:564 */     MathPreconditions.checkNonNegative("exponent", k);
/* 308:565 */     if (((b >= -2L ? 1 : 0) & (b <= 2L ? 1 : 0)) != 0)
/* 309:    */     {
/* 310:566 */       switch ((int)b)
/* 311:    */       {
/* 312:    */       case 0: 
/* 313:568 */         return k == 0 ? 1L : 0L;
/* 314:    */       case 1: 
/* 315:570 */         return 1L;
/* 316:    */       case -1: 
/* 317:572 */         return (k & 0x1) == 0 ? 1L : -1L;
/* 318:    */       case 2: 
/* 319:574 */         MathPreconditions.checkNoOverflow(k < 63);
/* 320:575 */         return 1L << k;
/* 321:    */       case -2: 
/* 322:577 */         MathPreconditions.checkNoOverflow(k < 64);
/* 323:578 */         return (k & 0x1) == 0 ? 1L << k : -1L << k;
/* 324:    */       }
/* 325:580 */       throw new AssertionError();
/* 326:    */     }
/* 327:583 */     long accum = 1L;
/* 328:    */     for (;;)
/* 329:    */     {
/* 330:585 */       switch (k)
/* 331:    */       {
/* 332:    */       case 0: 
/* 333:587 */         return accum;
/* 334:    */       case 1: 
/* 335:589 */         return checkedMultiply(accum, b);
/* 336:    */       }
/* 337:591 */       if ((k & 0x1) != 0) {
/* 338:592 */         accum = checkedMultiply(accum, b);
/* 339:    */       }
/* 340:594 */       k >>= 1;
/* 341:595 */       if (k > 0)
/* 342:    */       {
/* 343:596 */         MathPreconditions.checkNoOverflow(b <= 3037000499L);
/* 344:597 */         b *= b;
/* 345:    */       }
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:    */   @GwtIncompatible("TODO")
/* 350:    */   public static long factorial(int n)
/* 351:    */   {
/* 352:614 */     MathPreconditions.checkNonNegative("n", n);
/* 353:615 */     return n < factorials.length ? factorials[n] : 9223372036854775807L;
/* 354:    */   }
/* 355:    */   
/* 356:618 */   static final long[] factorials = { 1L, 1L, 2L, 6L, 24L, 120L, 720L, 5040L, 40320L, 362880L, 3628800L, 39916800L, 479001600L, 6227020800L, 87178291200L, 1307674368000L, 20922789888000L, 355687428096000L, 6402373705728000L, 121645100408832000L, 2432902008176640000L };
/* 357:    */   
/* 358:    */   public static long binomial(int n, int k)
/* 359:    */   {
/* 360:649 */     MathPreconditions.checkNonNegative("n", n);
/* 361:650 */     MathPreconditions.checkNonNegative("k", k);
/* 362:651 */     Preconditions.checkArgument(k <= n, "k (%s) > n (%s)", new Object[] { Integer.valueOf(k), Integer.valueOf(n) });
/* 363:652 */     if (k > n >> 1) {
/* 364:653 */       k = n - k;
/* 365:    */     }
/* 366:655 */     switch (k)
/* 367:    */     {
/* 368:    */     case 0: 
/* 369:657 */       return 1L;
/* 370:    */     case 1: 
/* 371:659 */       return n;
/* 372:    */     }
/* 373:661 */     if (n < factorials.length) {
/* 374:662 */       return factorials[n] / (factorials[k] * factorials[(n - k)]);
/* 375:    */     }
/* 376:663 */     if ((k >= biggestBinomials.length) || (n > biggestBinomials[k])) {
/* 377:664 */       return 9223372036854775807L;
/* 378:    */     }
/* 379:665 */     if ((k < biggestSimpleBinomials.length) && (n <= biggestSimpleBinomials[k]))
/* 380:    */     {
/* 381:667 */       long result = n--;
/* 382:668 */       for (int i = 2; i <= k; i++)
/* 383:    */       {
/* 384:669 */         result *= n;
/* 385:670 */         result /= i;n--;
/* 386:    */       }
/* 387:672 */       return result;
/* 388:    */     }
/* 389:674 */     int nBits = log2(n, RoundingMode.CEILING);
/* 390:    */     
/* 391:676 */     long result = 1L;
/* 392:677 */     long numerator = n--;
/* 393:678 */     long denominator = 1L;
/* 394:    */     
/* 395:680 */     int numeratorBits = nBits;
/* 396:688 */     for (int i = 2; i <= k; n--)
/* 397:    */     {
/* 398:689 */       if (numeratorBits + nBits < 63)
/* 399:    */       {
/* 400:691 */         numerator *= n;
/* 401:692 */         denominator *= i;
/* 402:693 */         numeratorBits += nBits;
/* 403:    */       }
/* 404:    */       else
/* 405:    */       {
/* 406:697 */         result = multiplyFraction(result, numerator, denominator);
/* 407:698 */         numerator = n;
/* 408:699 */         denominator = i;
/* 409:700 */         numeratorBits = nBits;
/* 410:    */       }
/* 411:688 */       i++;
/* 412:    */     }
/* 413:703 */     return multiplyFraction(result, numerator, denominator);
/* 414:    */   }
/* 415:    */   
/* 416:    */   static long multiplyFraction(long x, long numerator, long denominator)
/* 417:    */   {
/* 418:712 */     if (x == 1L) {
/* 419:713 */       return numerator / denominator;
/* 420:    */     }
/* 421:715 */     long commonDivisor = gcd(x, denominator);
/* 422:716 */     x /= commonDivisor;
/* 423:717 */     denominator /= commonDivisor;
/* 424:    */     
/* 425:    */ 
/* 426:720 */     return x * (numerator / denominator);
/* 427:    */   }
/* 428:    */   
/* 429:727 */   static final int[] biggestBinomials = { 2147483647, 2147483647, 2147483647, 3810779, 121977, 16175, 4337, 1733, 887, 534, 361, 265, 206, 169, 143, 125, 111, 101, 94, 88, 83, 79, 76, 74, 72, 70, 69, 68, 67, 67, 66, 66, 66, 66 };
/* 430:    */   @VisibleForTesting
/* 431:736 */   static final int[] biggestSimpleBinomials = { 2147483647, 2147483647, 2147483647, 2642246, 86251, 11724, 3218, 1313, 684, 419, 287, 214, 169, 139, 119, 105, 95, 87, 81, 76, 73, 70, 68, 66, 64, 63, 62, 62, 61, 61, 61 };
/* 432:    */   
/* 433:    */   static boolean fitsInInt(long x)
/* 434:    */   {
/* 435:744 */     return (int)x == x;
/* 436:    */   }
/* 437:    */   
/* 438:    */   public static long mean(long x, long y)
/* 439:    */   {
/* 440:757 */     return (x & y) + ((x ^ y) >> 1);
/* 441:    */   }
/* 442:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.math.LongMath
 * JD-Core Version:    0.7.0.1
 */
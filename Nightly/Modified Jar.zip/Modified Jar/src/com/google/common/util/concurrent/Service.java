/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.util.concurrent.Executor;
/*   5:    */ import java.util.concurrent.TimeUnit;
/*   6:    */ import java.util.concurrent.TimeoutException;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ public abstract interface Service
/*  10:    */ {
/*  11:    */   public abstract Service startAsync();
/*  12:    */   
/*  13:    */   public abstract boolean isRunning();
/*  14:    */   
/*  15:    */   public abstract State state();
/*  16:    */   
/*  17:    */   public abstract Service stopAsync();
/*  18:    */   
/*  19:    */   public abstract void awaitRunning();
/*  20:    */   
/*  21:    */   public abstract void awaitRunning(long paramLong, TimeUnit paramTimeUnit)
/*  22:    */     throws TimeoutException;
/*  23:    */   
/*  24:    */   public abstract void awaitTerminated();
/*  25:    */   
/*  26:    */   public abstract void awaitTerminated(long paramLong, TimeUnit paramTimeUnit)
/*  27:    */     throws TimeoutException;
/*  28:    */   
/*  29:    */   public abstract Throwable failureCause();
/*  30:    */   
/*  31:    */   public abstract void addListener(Listener paramListener, Executor paramExecutor);
/*  32:    */   
/*  33:    */   @Beta
/*  34:    */   public static abstract class Listener
/*  35:    */   {
/*  36:    */     public void starting() {}
/*  37:    */     
/*  38:    */     public void running() {}
/*  39:    */     
/*  40:    */     public void stopping(Service.State from) {}
/*  41:    */     
/*  42:    */     public void terminated(Service.State from) {}
/*  43:    */     
/*  44:    */     public void failed(Service.State from, Throwable failure) {}
/*  45:    */   }
/*  46:    */   
/*  47:    */   @Beta
/*  48:    */   public static abstract enum State
/*  49:    */   {
/*  50:189 */     NEW,  STARTING,  RUNNING,  STOPPING,  TERMINATED,  FAILED;
/*  51:    */     
/*  52:    */     private State() {}
/*  53:    */     
/*  54:    */     abstract boolean isTerminal();
/*  55:    */   }
/*  56:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Service
 * JD-Core Version:    0.7.0.1
 */
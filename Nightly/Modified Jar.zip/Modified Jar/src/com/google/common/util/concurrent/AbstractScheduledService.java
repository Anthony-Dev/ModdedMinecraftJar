/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Supplier;
/*   6:    */ import com.google.common.base.Throwables;
/*   7:    */ import java.util.concurrent.Callable;
/*   8:    */ import java.util.concurrent.Executor;
/*   9:    */ import java.util.concurrent.Executors;
/*  10:    */ import java.util.concurrent.Future;
/*  11:    */ import java.util.concurrent.ScheduledExecutorService;
/*  12:    */ import java.util.concurrent.ThreadFactory;
/*  13:    */ import java.util.concurrent.TimeUnit;
/*  14:    */ import java.util.concurrent.TimeoutException;
/*  15:    */ import java.util.concurrent.locks.ReentrantLock;
/*  16:    */ import java.util.logging.Level;
/*  17:    */ import java.util.logging.Logger;
/*  18:    */ import javax.annotation.concurrent.GuardedBy;
/*  19:    */ 
/*  20:    */ @Beta
/*  21:    */ public abstract class AbstractScheduledService
/*  22:    */   implements Service
/*  23:    */ {
/*  24: 95 */   private static final Logger logger = Logger.getLogger(AbstractScheduledService.class.getName());
/*  25:    */   protected abstract void runOneIteration()
/*  26:    */     throws Exception;
/*  27:    */   
/*  28:    */   protected void startUp()
/*  29:    */     throws Exception
/*  30:    */   {}
/*  31:    */   
/*  32:    */   protected void shutDown()
/*  33:    */     throws Exception
/*  34:    */   {}
/*  35:    */   
/*  36:    */   protected abstract Scheduler scheduler();
/*  37:    */   
/*  38:    */   public static abstract class Scheduler
/*  39:    */   {
/*  40:    */     public static Scheduler newFixedDelaySchedule(long initialDelay, long delay, final TimeUnit unit)
/*  41:    */     {
/*  42:121 */       new Scheduler(initialDelay)
/*  43:    */       {
/*  44:    */         public Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable task)
/*  45:    */         {
/*  46:125 */           return executor.scheduleWithFixedDelay(task, this.val$initialDelay, unit, this.val$unit);
/*  47:    */         }
/*  48:    */       };
/*  49:    */     }
/*  50:    */     
/*  51:    */     public static Scheduler newFixedRateSchedule(long initialDelay, long period, final TimeUnit unit)
/*  52:    */     {
/*  53:140 */       new Scheduler(initialDelay)
/*  54:    */       {
/*  55:    */         public Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable task)
/*  56:    */         {
/*  57:144 */           return executor.scheduleAtFixedRate(task, this.val$initialDelay, unit, this.val$unit);
/*  58:    */         }
/*  59:    */       };
/*  60:    */     }
/*  61:    */     
/*  62:    */     abstract Future<?> schedule(AbstractService paramAbstractService, ScheduledExecutorService paramScheduledExecutorService, Runnable paramRunnable);
/*  63:    */   }
/*  64:    */   
/*  65:157 */   private final AbstractService delegate = new AbstractService()
/*  66:    */   {
/*  67:    */     private volatile Future<?> runningTask;
/*  68:    */     private volatile ScheduledExecutorService executorService;
/*  69:166 */     private final ReentrantLock lock = new ReentrantLock();
/*  70:168 */     private final Runnable task = new Runnable()
/*  71:    */     {
/*  72:    */       public void run()
/*  73:    */       {
/*  74:170 */         AbstractScheduledService.1.this.lock.lock();
/*  75:    */         try
/*  76:    */         {
/*  77:172 */           AbstractScheduledService.this.runOneIteration();
/*  78:    */         }
/*  79:    */         catch (Throwable t)
/*  80:    */         {
/*  81:    */           try
/*  82:    */           {
/*  83:175 */             AbstractScheduledService.this.shutDown();
/*  84:    */           }
/*  85:    */           catch (Exception ignored)
/*  86:    */           {
/*  87:177 */             AbstractScheduledService.logger.log(Level.WARNING, "Error while attempting to shut down the service after failure.", ignored);
/*  88:    */           }
/*  89:180 */           AbstractScheduledService.1.this.notifyFailed(t);
/*  90:181 */           throw Throwables.propagate(t);
/*  91:    */         }
/*  92:    */         finally
/*  93:    */         {
/*  94:183 */           AbstractScheduledService.1.this.lock.unlock();
/*  95:    */         }
/*  96:    */       }
/*  97:    */     };
/*  98:    */     
/*  99:    */     protected final void doStart()
/* 100:    */     {
/* 101:189 */       this.executorService = MoreExecutors.renamingDecorator(AbstractScheduledService.this.executor(), new Supplier()
/* 102:    */       {
/* 103:    */         public String get()
/* 104:    */         {
/* 105:191 */           return AbstractScheduledService.this.serviceName() + " " + AbstractScheduledService.1.this.state();
/* 106:    */         }
/* 107:193 */       });
/* 108:194 */       this.executorService.execute(new Runnable()
/* 109:    */       {
/* 110:    */         public void run()
/* 111:    */         {
/* 112:196 */           AbstractScheduledService.1.this.lock.lock();
/* 113:    */           try
/* 114:    */           {
/* 115:198 */             AbstractScheduledService.this.startUp();
/* 116:199 */             AbstractScheduledService.1.this.runningTask = AbstractScheduledService.this.scheduler().schedule(AbstractScheduledService.this.delegate, AbstractScheduledService.1.this.executorService, AbstractScheduledService.1.this.task);
/* 117:200 */             AbstractScheduledService.1.this.notifyStarted();
/* 118:    */           }
/* 119:    */           catch (Throwable t)
/* 120:    */           {
/* 121:202 */             AbstractScheduledService.1.this.notifyFailed(t);
/* 122:203 */             throw Throwables.propagate(t);
/* 123:    */           }
/* 124:    */           finally
/* 125:    */           {
/* 126:205 */             AbstractScheduledService.1.this.lock.unlock();
/* 127:    */           }
/* 128:    */         }
/* 129:    */       });
/* 130:    */     }
/* 131:    */     
/* 132:    */     protected final void doStop()
/* 133:    */     {
/* 134:212 */       this.runningTask.cancel(false);
/* 135:213 */       this.executorService.execute(new Runnable()
/* 136:    */       {
/* 137:    */         public void run()
/* 138:    */         {
/* 139:    */           try
/* 140:    */           {
/* 141:216 */             AbstractScheduledService.1.this.lock.lock();
/* 142:    */             try
/* 143:    */             {
/* 144:218 */               if (AbstractScheduledService.1.this.state() != Service.State.STOPPING) {
/* 145:    */                 return;
/* 146:    */               }
/* 147:225 */               AbstractScheduledService.this.shutDown();
/* 148:    */             }
/* 149:    */             finally
/* 150:    */             {
/* 151:227 */               AbstractScheduledService.1.this.lock.unlock();
/* 152:    */             }
/* 153:229 */             AbstractScheduledService.1.this.notifyStopped();
/* 154:    */           }
/* 155:    */           catch (Throwable t)
/* 156:    */           {
/* 157:231 */             AbstractScheduledService.1.this.notifyFailed(t);
/* 158:232 */             throw Throwables.propagate(t);
/* 159:    */           }
/* 160:    */         }
/* 161:    */       });
/* 162:    */     }
/* 163:    */   };
/* 164:    */   
/* 165:    */   protected ScheduledExecutorService executor()
/* 166:    */   {
/* 167:285 */     final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(new ThreadFactory()
/* 168:    */     {
/* 169:    */       public Thread newThread(Runnable runnable)
/* 170:    */       {
/* 171:288 */         return MoreExecutors.newThread(AbstractScheduledService.this.serviceName(), runnable);
/* 172:    */       }
/* 173:295 */     });
/* 174:296 */     addListener(new Service.Listener()
/* 175:    */     {
/* 176:    */       public void terminated(Service.State from)
/* 177:    */       {
/* 178:298 */         executor.shutdown();
/* 179:    */       }
/* 180:    */       
/* 181:    */       public void failed(Service.State from, Throwable failure)
/* 182:    */       {
/* 183:301 */         executor.shutdown();
/* 184:    */       }
/* 185:301 */     }, MoreExecutors.sameThreadExecutor());
/* 186:    */     
/* 187:303 */     return executor;
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected String serviceName()
/* 191:    */   {
/* 192:313 */     return getClass().getSimpleName();
/* 193:    */   }
/* 194:    */   
/* 195:    */   public String toString()
/* 196:    */   {
/* 197:317 */     return serviceName() + " [" + state() + "]";
/* 198:    */   }
/* 199:    */   
/* 200:    */   public final boolean isRunning()
/* 201:    */   {
/* 202:321 */     return this.delegate.isRunning();
/* 203:    */   }
/* 204:    */   
/* 205:    */   public final Service.State state()
/* 206:    */   {
/* 207:325 */     return this.delegate.state();
/* 208:    */   }
/* 209:    */   
/* 210:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 211:    */   {
/* 212:332 */     this.delegate.addListener(listener, executor);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public final Throwable failureCause()
/* 216:    */   {
/* 217:339 */     return this.delegate.failureCause();
/* 218:    */   }
/* 219:    */   
/* 220:    */   public final Service startAsync()
/* 221:    */   {
/* 222:346 */     this.delegate.startAsync();
/* 223:347 */     return this;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public final Service stopAsync()
/* 227:    */   {
/* 228:354 */     this.delegate.stopAsync();
/* 229:355 */     return this;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public final void awaitRunning()
/* 233:    */   {
/* 234:362 */     this.delegate.awaitRunning();
/* 235:    */   }
/* 236:    */   
/* 237:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 238:    */     throws TimeoutException
/* 239:    */   {
/* 240:369 */     this.delegate.awaitRunning(timeout, unit);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public final void awaitTerminated()
/* 244:    */   {
/* 245:376 */     this.delegate.awaitTerminated();
/* 246:    */   }
/* 247:    */   
/* 248:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 249:    */     throws TimeoutException
/* 250:    */   {
/* 251:383 */     this.delegate.awaitTerminated(timeout, unit);
/* 252:    */   }
/* 253:    */   
/* 254:    */   @Beta
/* 255:    */   public static abstract class CustomScheduler
/* 256:    */     extends AbstractScheduledService.Scheduler
/* 257:    */   {
/* 258:    */     public CustomScheduler()
/* 259:    */     {
/* 260:395 */       super();
/* 261:    */     }
/* 262:    */     
/* 263:    */     private class ReschedulableCallable
/* 264:    */       extends ForwardingFuture<Void>
/* 265:    */       implements Callable<Void>
/* 266:    */     {
/* 267:    */       private final Runnable wrappedRunnable;
/* 268:    */       private final ScheduledExecutorService executor;
/* 269:    */       private final AbstractService service;
/* 270:419 */       private final ReentrantLock lock = new ReentrantLock();
/* 271:    */       @GuardedBy("lock")
/* 272:    */       private Future<Void> currentFuture;
/* 273:    */       
/* 274:    */       ReschedulableCallable(AbstractService service, ScheduledExecutorService executor, Runnable runnable)
/* 275:    */       {
/* 276:427 */         this.wrappedRunnable = runnable;
/* 277:428 */         this.executor = executor;
/* 278:429 */         this.service = service;
/* 279:    */       }
/* 280:    */       
/* 281:    */       public Void call()
/* 282:    */         throws Exception
/* 283:    */       {
/* 284:434 */         this.wrappedRunnable.run();
/* 285:435 */         reschedule();
/* 286:436 */         return null;
/* 287:    */       }
/* 288:    */       
/* 289:    */       public void reschedule()
/* 290:    */       {
/* 291:447 */         this.lock.lock();
/* 292:    */         try
/* 293:    */         {
/* 294:449 */           if ((this.currentFuture == null) || (!this.currentFuture.isCancelled()))
/* 295:    */           {
/* 296:450 */             AbstractScheduledService.CustomScheduler.Schedule schedule = AbstractScheduledService.CustomScheduler.this.getNextSchedule();
/* 297:451 */             this.currentFuture = this.executor.schedule(this, AbstractScheduledService.CustomScheduler.Schedule.access$700(schedule), AbstractScheduledService.CustomScheduler.Schedule.access$800(schedule));
/* 298:    */           }
/* 299:    */         }
/* 300:    */         catch (Throwable e)
/* 301:    */         {
/* 302:459 */           this.service.notifyFailed(e);
/* 303:    */         }
/* 304:    */         finally
/* 305:    */         {
/* 306:461 */           this.lock.unlock();
/* 307:    */         }
/* 308:    */       }
/* 309:    */       
/* 310:    */       public boolean cancel(boolean mayInterruptIfRunning)
/* 311:    */       {
/* 312:470 */         this.lock.lock();
/* 313:    */         try
/* 314:    */         {
/* 315:472 */           return this.currentFuture.cancel(mayInterruptIfRunning);
/* 316:    */         }
/* 317:    */         finally
/* 318:    */         {
/* 319:474 */           this.lock.unlock();
/* 320:    */         }
/* 321:    */       }
/* 322:    */       
/* 323:    */       protected Future<Void> delegate()
/* 324:    */       {
/* 325:480 */         throw new UnsupportedOperationException("Only cancel is supported by this future");
/* 326:    */       }
/* 327:    */     }
/* 328:    */     
/* 329:    */     final Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable runnable)
/* 330:    */     {
/* 331:487 */       ReschedulableCallable task = new ReschedulableCallable(service, executor, runnable);
/* 332:488 */       task.reschedule();
/* 333:489 */       return task;
/* 334:    */     }
/* 335:    */     
/* 336:    */     protected abstract Schedule getNextSchedule()
/* 337:    */       throws Exception;
/* 338:    */     
/* 339:    */     @Beta
/* 340:    */     protected static final class Schedule
/* 341:    */     {
/* 342:    */       private final long delay;
/* 343:    */       private final TimeUnit unit;
/* 344:    */       
/* 345:    */       public Schedule(long delay, TimeUnit unit)
/* 346:    */       {
/* 347:509 */         this.delay = delay;
/* 348:510 */         this.unit = ((TimeUnit)Preconditions.checkNotNull(unit));
/* 349:    */       }
/* 350:    */     }
/* 351:    */   }
/* 352:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractScheduledService
 * JD-Core Version:    0.7.0.1
 */
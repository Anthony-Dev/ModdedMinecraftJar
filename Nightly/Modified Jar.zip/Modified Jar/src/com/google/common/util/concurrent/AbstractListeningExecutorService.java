/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import java.util.concurrent.AbstractExecutorService;
/*  5:   */ import java.util.concurrent.Callable;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public abstract class AbstractListeningExecutorService
/* 10:   */   extends AbstractExecutorService
/* 11:   */   implements ListeningExecutorService
/* 12:   */ {
/* 13:   */   protected final <T> ListenableFutureTask<T> newTaskFor(Runnable runnable, T value)
/* 14:   */   {
/* 15:42 */     return ListenableFutureTask.create(runnable, value);
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected final <T> ListenableFutureTask<T> newTaskFor(Callable<T> callable)
/* 19:   */   {
/* 20:46 */     return ListenableFutureTask.create(callable);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public ListenableFuture<?> submit(Runnable task)
/* 24:   */   {
/* 25:50 */     return (ListenableFuture)super.submit(task);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public <T> ListenableFuture<T> submit(Runnable task, @Nullable T result)
/* 29:   */   {
/* 30:54 */     return (ListenableFuture)super.submit(task, result);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public <T> ListenableFuture<T> submit(Callable<T> task)
/* 34:   */   {
/* 35:58 */     return (ListenableFuture)super.submit(task);
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractListeningExecutorService
 * JD-Core Version:    0.7.0.1
 */
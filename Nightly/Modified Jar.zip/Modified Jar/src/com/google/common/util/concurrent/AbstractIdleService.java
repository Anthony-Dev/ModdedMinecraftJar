/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import com.google.common.base.Throwables;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import java.util.concurrent.TimeoutException;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public abstract class AbstractIdleService
/*  12:    */   implements Service
/*  13:    */ {
/*  14: 41 */   private final Supplier<String> threadNameSupplier = new Supplier()
/*  15:    */   {
/*  16:    */     public String get()
/*  17:    */     {
/*  18: 43 */       return AbstractIdleService.this.serviceName() + " " + AbstractIdleService.this.state();
/*  19:    */     }
/*  20:    */   };
/*  21: 48 */   private final Service delegate = new AbstractService()
/*  22:    */   {
/*  23:    */     protected final void doStart()
/*  24:    */     {
/*  25: 50 */       MoreExecutors.renamingDecorator(AbstractIdleService.this.executor(), AbstractIdleService.this.threadNameSupplier).execute(new Runnable()
/*  26:    */       {
/*  27:    */         public void run()
/*  28:    */         {
/*  29:    */           try
/*  30:    */           {
/*  31: 54 */             AbstractIdleService.this.startUp();
/*  32: 55 */             AbstractIdleService.2.this.notifyStarted();
/*  33:    */           }
/*  34:    */           catch (Throwable t)
/*  35:    */           {
/*  36: 57 */             AbstractIdleService.2.this.notifyFailed(t);
/*  37: 58 */             throw Throwables.propagate(t);
/*  38:    */           }
/*  39:    */         }
/*  40:    */       });
/*  41:    */     }
/*  42:    */     
/*  43:    */     protected final void doStop()
/*  44:    */     {
/*  45: 65 */       MoreExecutors.renamingDecorator(AbstractIdleService.this.executor(), AbstractIdleService.this.threadNameSupplier).execute(new Runnable()
/*  46:    */       {
/*  47:    */         public void run()
/*  48:    */         {
/*  49:    */           try
/*  50:    */           {
/*  51: 69 */             AbstractIdleService.this.shutDown();
/*  52: 70 */             AbstractIdleService.2.this.notifyStopped();
/*  53:    */           }
/*  54:    */           catch (Throwable t)
/*  55:    */           {
/*  56: 72 */             AbstractIdleService.2.this.notifyFailed(t);
/*  57: 73 */             throw Throwables.propagate(t);
/*  58:    */           }
/*  59:    */         }
/*  60:    */       });
/*  61:    */     }
/*  62:    */   };
/*  63:    */   
/*  64:    */   protected abstract void startUp()
/*  65:    */     throws Exception;
/*  66:    */   
/*  67:    */   protected abstract void shutDown()
/*  68:    */     throws Exception;
/*  69:    */   
/*  70:    */   protected Executor executor()
/*  71:    */   {
/*  72: 98 */     new Executor()
/*  73:    */     {
/*  74:    */       public void execute(Runnable command)
/*  75:    */       {
/*  76:100 */         MoreExecutors.newThread((String)AbstractIdleService.this.threadNameSupplier.get(), command).start();
/*  77:    */       }
/*  78:    */     };
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String toString()
/*  82:    */   {
/*  83:106 */     return serviceName() + " [" + state() + "]";
/*  84:    */   }
/*  85:    */   
/*  86:    */   public final boolean isRunning()
/*  87:    */   {
/*  88:110 */     return this.delegate.isRunning();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public final Service.State state()
/*  92:    */   {
/*  93:114 */     return this.delegate.state();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public final void addListener(Service.Listener listener, Executor executor)
/*  97:    */   {
/*  98:121 */     this.delegate.addListener(listener, executor);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public final Throwable failureCause()
/* 102:    */   {
/* 103:128 */     return this.delegate.failureCause();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public final Service startAsync()
/* 107:    */   {
/* 108:135 */     this.delegate.startAsync();
/* 109:136 */     return this;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public final Service stopAsync()
/* 113:    */   {
/* 114:143 */     this.delegate.stopAsync();
/* 115:144 */     return this;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public final void awaitRunning()
/* 119:    */   {
/* 120:151 */     this.delegate.awaitRunning();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 124:    */     throws TimeoutException
/* 125:    */   {
/* 126:158 */     this.delegate.awaitRunning(timeout, unit);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public final void awaitTerminated()
/* 130:    */   {
/* 131:165 */     this.delegate.awaitTerminated();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 135:    */     throws TimeoutException
/* 136:    */   {
/* 137:172 */     this.delegate.awaitTerminated(timeout, unit);
/* 138:    */   }
/* 139:    */   
/* 140:    */   protected String serviceName()
/* 141:    */   {
/* 142:182 */     return getClass().getSimpleName();
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractIdleService
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Ticker;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import javax.annotation.concurrent.ThreadSafe;
/*   9:    */ 
/*  10:    */ @ThreadSafe
/*  11:    */ @Beta
/*  12:    */ public abstract class RateLimiter
/*  13:    */ {
/*  14:    */   private final SleepingTicker ticker;
/*  15:    */   private final long offsetNanos;
/*  16:    */   double storedPermits;
/*  17:    */   double maxPermits;
/*  18:    */   volatile double stableIntervalMicros;
/*  19:    */   
/*  20:    */   public static RateLimiter create(double permitsPerSecond)
/*  21:    */   {
/*  22:242 */     return create(SleepingTicker.SYSTEM_TICKER, permitsPerSecond);
/*  23:    */   }
/*  24:    */   
/*  25:    */   @VisibleForTesting
/*  26:    */   static RateLimiter create(SleepingTicker ticker, double permitsPerSecond)
/*  27:    */   {
/*  28:247 */     RateLimiter rateLimiter = new Bursty(ticker, 1.0D);
/*  29:248 */     rateLimiter.setRate(permitsPerSecond);
/*  30:249 */     return rateLimiter;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static RateLimiter create(double permitsPerSecond, long warmupPeriod, TimeUnit unit)
/*  34:    */   {
/*  35:275 */     return create(SleepingTicker.SYSTEM_TICKER, permitsPerSecond, warmupPeriod, unit);
/*  36:    */   }
/*  37:    */   
/*  38:    */   @VisibleForTesting
/*  39:    */   static RateLimiter create(SleepingTicker ticker, double permitsPerSecond, long warmupPeriod, TimeUnit unit)
/*  40:    */   {
/*  41:281 */     RateLimiter rateLimiter = new WarmingUp(ticker, warmupPeriod, unit);
/*  42:282 */     rateLimiter.setRate(permitsPerSecond);
/*  43:283 */     return rateLimiter;
/*  44:    */   }
/*  45:    */   
/*  46:    */   @VisibleForTesting
/*  47:    */   static RateLimiter createWithCapacity(SleepingTicker ticker, double permitsPerSecond, long maxBurstBuildup, TimeUnit unit)
/*  48:    */   {
/*  49:289 */     double maxBurstSeconds = unit.toNanos(maxBurstBuildup) / 1000000000.0D;
/*  50:290 */     Bursty rateLimiter = new Bursty(ticker, maxBurstSeconds);
/*  51:291 */     rateLimiter.setRate(permitsPerSecond);
/*  52:292 */     return rateLimiter;
/*  53:    */   }
/*  54:    */   
/*  55:323 */   private final Object mutex = new Object();
/*  56:329 */   private long nextFreeTicketMicros = 0L;
/*  57:    */   
/*  58:    */   private RateLimiter(SleepingTicker ticker)
/*  59:    */   {
/*  60:332 */     this.ticker = ticker;
/*  61:333 */     this.offsetNanos = ticker.read();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public final void setRate(double permitsPerSecond)
/*  65:    */   {
/*  66:355 */     Preconditions.checkArgument((permitsPerSecond > 0.0D) && (!Double.isNaN(permitsPerSecond)), "rate must be positive");
/*  67:357 */     synchronized (this.mutex)
/*  68:    */     {
/*  69:358 */       resync(readSafeMicros());
/*  70:359 */       double stableIntervalMicros = TimeUnit.SECONDS.toMicros(1L) / permitsPerSecond;
/*  71:360 */       this.stableIntervalMicros = stableIntervalMicros;
/*  72:361 */       doSetRate(permitsPerSecond, stableIntervalMicros);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   abstract void doSetRate(double paramDouble1, double paramDouble2);
/*  77:    */   
/*  78:    */   public final double getRate()
/*  79:    */   {
/*  80:375 */     return TimeUnit.SECONDS.toMicros(1L) / this.stableIntervalMicros;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public double acquire()
/*  84:    */   {
/*  85:388 */     return acquire(1);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public double acquire(int permits)
/*  89:    */   {
/*  90:400 */     long microsToWait = reserve(permits);
/*  91:401 */     this.ticker.sleepMicrosUninterruptibly(microsToWait);
/*  92:402 */     return 1.0D * microsToWait / TimeUnit.SECONDS.toMicros(1L);
/*  93:    */   }
/*  94:    */   
/*  95:    */   long reserve()
/*  96:    */   {
/*  97:414 */     return reserve(1);
/*  98:    */   }
/*  99:    */   
/* 100:    */   long reserve(int permits)
/* 101:    */   {
/* 102:424 */     checkPermits(permits);
/* 103:425 */     synchronized (this.mutex)
/* 104:    */     {
/* 105:426 */       return reserveNextTicket(permits, readSafeMicros());
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean tryAcquire(long timeout, TimeUnit unit)
/* 110:    */   {
/* 111:443 */     return tryAcquire(1, timeout, unit);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean tryAcquire(int permits)
/* 115:    */   {
/* 116:457 */     return tryAcquire(permits, 0L, TimeUnit.MICROSECONDS);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean tryAcquire()
/* 120:    */   {
/* 121:471 */     return tryAcquire(1, 0L, TimeUnit.MICROSECONDS);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean tryAcquire(int permits, long timeout, TimeUnit unit)
/* 125:    */   {
/* 126:486 */     long timeoutMicros = unit.toMicros(timeout);
/* 127:487 */     checkPermits(permits);
/* 128:    */     long microsToWait;
/* 129:489 */     synchronized (this.mutex)
/* 130:    */     {
/* 131:490 */       long nowMicros = readSafeMicros();
/* 132:491 */       if (this.nextFreeTicketMicros > nowMicros + timeoutMicros) {
/* 133:492 */         return false;
/* 134:    */       }
/* 135:494 */       microsToWait = reserveNextTicket(permits, nowMicros);
/* 136:    */     }
/* 137:497 */     this.ticker.sleepMicrosUninterruptibly(microsToWait);
/* 138:498 */     return true;
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static void checkPermits(int permits)
/* 142:    */   {
/* 143:502 */     Preconditions.checkArgument(permits > 0, "Requested permits must be positive");
/* 144:    */   }
/* 145:    */   
/* 146:    */   private long reserveNextTicket(double requiredPermits, long nowMicros)
/* 147:    */   {
/* 148:511 */     resync(nowMicros);
/* 149:512 */     long microsToNextFreeTicket = Math.max(0L, this.nextFreeTicketMicros - nowMicros);
/* 150:513 */     double storedPermitsToSpend = Math.min(requiredPermits, this.storedPermits);
/* 151:514 */     double freshPermits = requiredPermits - storedPermitsToSpend;
/* 152:    */     
/* 153:516 */     long waitMicros = storedPermitsToWaitTime(this.storedPermits, storedPermitsToSpend) + (freshPermits * this.stableIntervalMicros);
/* 154:    */     
/* 155:    */ 
/* 156:519 */     this.nextFreeTicketMicros += waitMicros;
/* 157:520 */     this.storedPermits -= storedPermitsToSpend;
/* 158:521 */     return microsToNextFreeTicket;
/* 159:    */   }
/* 160:    */   
/* 161:    */   abstract long storedPermitsToWaitTime(double paramDouble1, double paramDouble2);
/* 162:    */   
/* 163:    */   private void resync(long nowMicros)
/* 164:    */   {
/* 165:536 */     if (nowMicros > this.nextFreeTicketMicros)
/* 166:    */     {
/* 167:537 */       this.storedPermits = Math.min(this.maxPermits, this.storedPermits + (nowMicros - this.nextFreeTicketMicros) / this.stableIntervalMicros);
/* 168:    */       
/* 169:539 */       this.nextFreeTicketMicros = nowMicros;
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   private long readSafeMicros()
/* 174:    */   {
/* 175:544 */     return TimeUnit.NANOSECONDS.toMicros(this.ticker.read() - this.offsetNanos);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public String toString()
/* 179:    */   {
/* 180:549 */     return String.format("RateLimiter[stableRate=%3.1fqps]", new Object[] { Double.valueOf(1000000.0D / this.stableIntervalMicros) });
/* 181:    */   }
/* 182:    */   
/* 183:    */   private static class WarmingUp
/* 184:    */     extends RateLimiter
/* 185:    */   {
/* 186:    */     final long warmupPeriodMicros;
/* 187:    */     private double slope;
/* 188:    */     private double halfPermits;
/* 189:    */     
/* 190:    */     WarmingUp(RateLimiter.SleepingTicker ticker, long warmupPeriod, TimeUnit timeUnit)
/* 191:    */     {
/* 192:638 */       super(null);
/* 193:639 */       this.warmupPeriodMicros = timeUnit.toMicros(warmupPeriod);
/* 194:    */     }
/* 195:    */     
/* 196:    */     void doSetRate(double permitsPerSecond, double stableIntervalMicros)
/* 197:    */     {
/* 198:644 */       double oldMaxPermits = this.maxPermits;
/* 199:645 */       this.maxPermits = (this.warmupPeriodMicros / stableIntervalMicros);
/* 200:646 */       this.halfPermits = (this.maxPermits / 2.0D);
/* 201:    */       
/* 202:648 */       double coldIntervalMicros = stableIntervalMicros * 3.0D;
/* 203:649 */       this.slope = ((coldIntervalMicros - stableIntervalMicros) / this.halfPermits);
/* 204:650 */       if (oldMaxPermits == (1.0D / 0.0D)) {
/* 205:652 */         this.storedPermits = 0.0D;
/* 206:    */       } else {
/* 207:654 */         this.storedPermits = (oldMaxPermits == 0.0D ? this.maxPermits : this.storedPermits * this.maxPermits / oldMaxPermits);
/* 208:    */       }
/* 209:    */     }
/* 210:    */     
/* 211:    */     long storedPermitsToWaitTime(double storedPermits, double permitsToTake)
/* 212:    */     {
/* 213:662 */       double availablePermitsAboveHalf = storedPermits - this.halfPermits;
/* 214:663 */       long micros = 0L;
/* 215:665 */       if (availablePermitsAboveHalf > 0.0D)
/* 216:    */       {
/* 217:666 */         double permitsAboveHalfToTake = Math.min(availablePermitsAboveHalf, permitsToTake);
/* 218:667 */         micros = (permitsAboveHalfToTake * (permitsToTime(availablePermitsAboveHalf) + permitsToTime(availablePermitsAboveHalf - permitsAboveHalfToTake)) / 2.0D);
/* 219:    */         
/* 220:669 */         permitsToTake -= permitsAboveHalfToTake;
/* 221:    */       }
/* 222:672 */       micros = (micros + this.stableIntervalMicros * permitsToTake);
/* 223:673 */       return micros;
/* 224:    */     }
/* 225:    */     
/* 226:    */     private double permitsToTime(double permits)
/* 227:    */     {
/* 228:677 */       return this.stableIntervalMicros + permits * this.slope;
/* 229:    */     }
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static class Bursty
/* 233:    */     extends RateLimiter
/* 234:    */   {
/* 235:    */     final double maxBurstSeconds;
/* 236:    */     
/* 237:    */     Bursty(RateLimiter.SleepingTicker ticker, double maxBurstSeconds)
/* 238:    */     {
/* 239:692 */       super(null);
/* 240:693 */       this.maxBurstSeconds = maxBurstSeconds;
/* 241:    */     }
/* 242:    */     
/* 243:    */     void doSetRate(double permitsPerSecond, double stableIntervalMicros)
/* 244:    */     {
/* 245:698 */       double oldMaxPermits = this.maxPermits;
/* 246:699 */       this.maxPermits = (this.maxBurstSeconds * permitsPerSecond);
/* 247:700 */       this.storedPermits = (oldMaxPermits == 0.0D ? 0.0D : this.storedPermits * this.maxPermits / oldMaxPermits);
/* 248:    */     }
/* 249:    */     
/* 250:    */     long storedPermitsToWaitTime(double storedPermits, double permitsToTake)
/* 251:    */     {
/* 252:707 */       return 0L;
/* 253:    */     }
/* 254:    */   }
/* 255:    */   
/* 256:    */   @VisibleForTesting
/* 257:    */   static abstract class SleepingTicker
/* 258:    */     extends Ticker
/* 259:    */   {
/* 260:715 */     static final SleepingTicker SYSTEM_TICKER = new SleepingTicker()
/* 261:    */     {
/* 262:    */       public long read()
/* 263:    */       {
/* 264:718 */         return systemTicker().read();
/* 265:    */       }
/* 266:    */       
/* 267:    */       public void sleepMicrosUninterruptibly(long micros)
/* 268:    */       {
/* 269:723 */         if (micros > 0L) {
/* 270:724 */           Uninterruptibles.sleepUninterruptibly(micros, TimeUnit.MICROSECONDS);
/* 271:    */         }
/* 272:    */       }
/* 273:    */     };
/* 274:    */     
/* 275:    */     abstract void sleepMicrosUninterruptibly(long paramLong);
/* 276:    */   }
/* 277:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.RateLimiter
 * JD-Core Version:    0.7.0.1
 */
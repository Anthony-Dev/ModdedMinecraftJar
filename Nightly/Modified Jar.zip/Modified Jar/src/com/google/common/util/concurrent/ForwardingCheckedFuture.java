/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.concurrent.TimeUnit;
/*  6:   */ import java.util.concurrent.TimeoutException;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public abstract class ForwardingCheckedFuture<V, X extends Exception>
/* 10:   */   extends ForwardingListenableFuture<V>
/* 11:   */   implements CheckedFuture<V, X>
/* 12:   */ {
/* 13:   */   public V checkedGet()
/* 14:   */     throws Exception
/* 15:   */   {
/* 16:46 */     return delegate().checkedGet();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public V checkedGet(long timeout, TimeUnit unit)
/* 20:   */     throws TimeoutException, Exception
/* 21:   */   {
/* 22:51 */     return delegate().checkedGet(timeout, unit);
/* 23:   */   }
/* 24:   */   
/* 25:   */   protected abstract CheckedFuture<V, X> delegate();
/* 26:   */   
/* 27:   */   @Beta
/* 28:   */   public static abstract class SimpleForwardingCheckedFuture<V, X extends Exception>
/* 29:   */     extends ForwardingCheckedFuture<V, X>
/* 30:   */   {
/* 31:   */     private final CheckedFuture<V, X> delegate;
/* 32:   */     
/* 33:   */     protected SimpleForwardingCheckedFuture(CheckedFuture<V, X> delegate)
/* 34:   */     {
/* 35:70 */       this.delegate = ((CheckedFuture)Preconditions.checkNotNull(delegate));
/* 36:   */     }
/* 37:   */     
/* 38:   */     protected final CheckedFuture<V, X> delegate()
/* 39:   */     {
/* 40:75 */       return this.delegate;
/* 41:   */     }
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingCheckedFuture
 * JD-Core Version:    0.7.0.1
 */
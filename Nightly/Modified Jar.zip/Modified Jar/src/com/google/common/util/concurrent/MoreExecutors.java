/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Supplier;
/*   7:    */ import com.google.common.base.Throwables;
/*   8:    */ import com.google.common.collect.Lists;
/*   9:    */ import com.google.common.collect.Queues;
/*  10:    */ import java.lang.reflect.InvocationTargetException;
/*  11:    */ import java.lang.reflect.Method;
/*  12:    */ import java.util.Collection;
/*  13:    */ import java.util.Collections;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.concurrent.BlockingQueue;
/*  17:    */ import java.util.concurrent.Callable;
/*  18:    */ import java.util.concurrent.Delayed;
/*  19:    */ import java.util.concurrent.ExecutionException;
/*  20:    */ import java.util.concurrent.Executor;
/*  21:    */ import java.util.concurrent.ExecutorService;
/*  22:    */ import java.util.concurrent.Executors;
/*  23:    */ import java.util.concurrent.Future;
/*  24:    */ import java.util.concurrent.RejectedExecutionException;
/*  25:    */ import java.util.concurrent.ScheduledExecutorService;
/*  26:    */ import java.util.concurrent.ScheduledFuture;
/*  27:    */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*  28:    */ import java.util.concurrent.ThreadFactory;
/*  29:    */ import java.util.concurrent.ThreadPoolExecutor;
/*  30:    */ import java.util.concurrent.TimeUnit;
/*  31:    */ import java.util.concurrent.TimeoutException;
/*  32:    */ import java.util.concurrent.locks.Condition;
/*  33:    */ import java.util.concurrent.locks.Lock;
/*  34:    */ import java.util.concurrent.locks.ReentrantLock;
/*  35:    */ 
/*  36:    */ public final class MoreExecutors
/*  37:    */ {
/*  38:    */   @Beta
/*  39:    */   public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  40:    */   {
/*  41: 86 */     return new Application().getExitingExecutorService(executor, terminationTimeout, timeUnit);
/*  42:    */   }
/*  43:    */   
/*  44:    */   @Beta
/*  45:    */   public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  46:    */   {
/*  47:109 */     return new Application().getExitingScheduledExecutorService(executor, terminationTimeout, timeUnit);
/*  48:    */   }
/*  49:    */   
/*  50:    */   @Beta
/*  51:    */   public static void addDelayedShutdownHook(ExecutorService service, long terminationTimeout, TimeUnit timeUnit)
/*  52:    */   {
/*  53:127 */     new Application().addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  54:    */   }
/*  55:    */   
/*  56:    */   @Beta
/*  57:    */   public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor)
/*  58:    */   {
/*  59:148 */     return new Application().getExitingExecutorService(executor);
/*  60:    */   }
/*  61:    */   
/*  62:    */   @Beta
/*  63:    */   public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor)
/*  64:    */   {
/*  65:169 */     return new Application().getExitingScheduledExecutorService(executor);
/*  66:    */   }
/*  67:    */   
/*  68:    */   @VisibleForTesting
/*  69:    */   static class Application
/*  70:    */   {
/*  71:    */     final ExecutorService getExitingExecutorService(ThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  72:    */     {
/*  73:177 */       MoreExecutors.useDaemonThreadFactory(executor);
/*  74:178 */       ExecutorService service = Executors.unconfigurableExecutorService(executor);
/*  75:179 */       addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  76:180 */       return service;
/*  77:    */     }
/*  78:    */     
/*  79:    */     final ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  80:    */     {
/*  81:185 */       MoreExecutors.useDaemonThreadFactory(executor);
/*  82:186 */       ScheduledExecutorService service = Executors.unconfigurableScheduledExecutorService(executor);
/*  83:187 */       addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  84:188 */       return service;
/*  85:    */     }
/*  86:    */     
/*  87:    */     final void addDelayedShutdownHook(final ExecutorService service, final long terminationTimeout, TimeUnit timeUnit)
/*  88:    */     {
/*  89:193 */       Preconditions.checkNotNull(service);
/*  90:194 */       Preconditions.checkNotNull(timeUnit);
/*  91:195 */       addShutdownHook(MoreExecutors.newThread("DelayedShutdownHook-for-" + service, new Runnable()
/*  92:    */       {
/*  93:    */         public void run()
/*  94:    */         {
/*  95:    */           try
/*  96:    */           {
/*  97:204 */             service.shutdown();
/*  98:205 */             service.awaitTermination(terminationTimeout, this.val$timeUnit);
/*  99:    */           }
/* 100:    */           catch (InterruptedException ignored) {}
/* 101:    */         }
/* 102:    */       }));
/* 103:    */     }
/* 104:    */     
/* 105:    */     final ExecutorService getExitingExecutorService(ThreadPoolExecutor executor)
/* 106:    */     {
/* 107:214 */       return getExitingExecutorService(executor, 120L, TimeUnit.SECONDS);
/* 108:    */     }
/* 109:    */     
/* 110:    */     final ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor)
/* 111:    */     {
/* 112:219 */       return getExitingScheduledExecutorService(executor, 120L, TimeUnit.SECONDS);
/* 113:    */     }
/* 114:    */     
/* 115:    */     @VisibleForTesting
/* 116:    */     void addShutdownHook(Thread hook)
/* 117:    */     {
/* 118:223 */       Runtime.getRuntime().addShutdownHook(hook);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   private static void useDaemonThreadFactory(ThreadPoolExecutor executor)
/* 123:    */   {
/* 124:228 */     executor.setThreadFactory(new ThreadFactoryBuilder().setDaemon(true).setThreadFactory(executor.getThreadFactory()).build());
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static ListeningExecutorService sameThreadExecutor()
/* 128:    */   {
/* 129:268 */     return new SameThreadExecutorService(null);
/* 130:    */   }
/* 131:    */   
/* 132:    */   private static class SameThreadExecutorService
/* 133:    */     extends AbstractListeningExecutorService
/* 134:    */   {
/* 135:278 */     private final Lock lock = new ReentrantLock();
/* 136:281 */     private final Condition termination = this.lock.newCondition();
/* 137:290 */     private int runningTasks = 0;
/* 138:291 */     private boolean shutdown = false;
/* 139:    */     
/* 140:    */     public void execute(Runnable command)
/* 141:    */     {
/* 142:295 */       startTask();
/* 143:    */       try
/* 144:    */       {
/* 145:297 */         command.run();
/* 146:    */       }
/* 147:    */       finally
/* 148:    */       {
/* 149:299 */         endTask();
/* 150:    */       }
/* 151:    */     }
/* 152:    */     
/* 153:    */     public boolean isShutdown()
/* 154:    */     {
/* 155:305 */       this.lock.lock();
/* 156:    */       try
/* 157:    */       {
/* 158:307 */         return this.shutdown;
/* 159:    */       }
/* 160:    */       finally
/* 161:    */       {
/* 162:309 */         this.lock.unlock();
/* 163:    */       }
/* 164:    */     }
/* 165:    */     
/* 166:    */     public void shutdown()
/* 167:    */     {
/* 168:315 */       this.lock.lock();
/* 169:    */       try
/* 170:    */       {
/* 171:317 */         this.shutdown = true;
/* 172:    */       }
/* 173:    */       finally
/* 174:    */       {
/* 175:319 */         this.lock.unlock();
/* 176:    */       }
/* 177:    */     }
/* 178:    */     
/* 179:    */     public List<Runnable> shutdownNow()
/* 180:    */     {
/* 181:326 */       shutdown();
/* 182:327 */       return Collections.emptyList();
/* 183:    */     }
/* 184:    */     
/* 185:    */     public boolean isTerminated()
/* 186:    */     {
/* 187:332 */       this.lock.lock();
/* 188:    */       try
/* 189:    */       {
/* 190:334 */         return (this.shutdown) && (this.runningTasks == 0);
/* 191:    */       }
/* 192:    */       finally
/* 193:    */       {
/* 194:336 */         this.lock.unlock();
/* 195:    */       }
/* 196:    */     }
/* 197:    */     
/* 198:    */     /* Error */
/* 199:    */     public boolean awaitTermination(long timeout, TimeUnit unit)
/* 200:    */       throws InterruptedException
/* 201:    */     {
/* 202:    */       // Byte code:
/* 203:    */       //   0: aload_3
/* 204:    */       //   1: lload_1
/* 205:    */       //   2: invokevirtual 105	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 206:    */       //   5: lstore 4
/* 207:    */       //   7: aload_0
/* 208:    */       //   8: getfield 95	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:lock	Ljava/util/concurrent/locks/Lock;
/* 209:    */       //   11: invokeinterface 110 1 0
/* 210:    */       //   16: aload_0
/* 211:    */       //   17: invokevirtual 102	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:isTerminated	()Z
/* 212:    */       //   20: ifeq +18 -> 38
/* 213:    */       //   23: iconst_1
/* 214:    */       //   24: istore 6
/* 215:    */       //   26: aload_0
/* 216:    */       //   27: getfield 95	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:lock	Ljava/util/concurrent/locks/Lock;
/* 217:    */       //   30: invokeinterface 111 1 0
/* 218:    */       //   35: iload 6
/* 219:    */       //   37: ireturn
/* 220:    */       //   38: lload 4
/* 221:    */       //   40: lconst_0
/* 222:    */       //   41: lcmp
/* 223:    */       //   42: ifgt +18 -> 60
/* 224:    */       //   45: iconst_0
/* 225:    */       //   46: istore 6
/* 226:    */       //   48: aload_0
/* 227:    */       //   49: getfield 95	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:lock	Ljava/util/concurrent/locks/Lock;
/* 228:    */       //   52: invokeinterface 111 1 0
/* 229:    */       //   57: iload 6
/* 230:    */       //   59: ireturn
/* 231:    */       //   60: aload_0
/* 232:    */       //   61: getfield 94	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:termination	Ljava/util/concurrent/locks/Condition;
/* 233:    */       //   64: lload 4
/* 234:    */       //   66: invokeinterface 109 3 0
/* 235:    */       //   71: lstore 4
/* 236:    */       //   73: goto -57 -> 16
/* 237:    */       //   76: astore 7
/* 238:    */       //   78: aload_0
/* 239:    */       //   79: getfield 95	com/google/common/util/concurrent/MoreExecutors$SameThreadExecutorService:lock	Ljava/util/concurrent/locks/Lock;
/* 240:    */       //   82: invokeinterface 111 1 0
/* 241:    */       //   87: aload 7
/* 242:    */       //   89: athrow
/* 243:    */       // Line number table:
/* 244:    */       //   Java source line #343	-> byte code offset #0
/* 245:    */       //   Java source line #344	-> byte code offset #7
/* 246:    */       //   Java source line #347	-> byte code offset #16
/* 247:    */       //   Java source line #348	-> byte code offset #23
/* 248:    */       //   Java source line #356	-> byte code offset #26
/* 249:    */       //   Java source line #349	-> byte code offset #38
/* 250:    */       //   Java source line #350	-> byte code offset #45
/* 251:    */       //   Java source line #356	-> byte code offset #48
/* 252:    */       //   Java source line #352	-> byte code offset #60
/* 253:    */       //   Java source line #356	-> byte code offset #76
/* 254:    */       // Local variable table:
/* 255:    */       //   start	length	slot	name	signature
/* 256:    */       //   0	90	0	this	SameThreadExecutorService
/* 257:    */       //   0	90	1	timeout	long
/* 258:    */       //   0	90	3	unit	TimeUnit
/* 259:    */       //   5	67	4	nanos	long
/* 260:    */       //   24	34	6	bool	boolean
/* 261:    */       //   76	12	7	localObject	Object
/* 262:    */       // Exception table:
/* 263:    */       //   from	to	target	type
/* 264:    */       //   16	26	76	finally
/* 265:    */       //   38	48	76	finally
/* 266:    */       //   60	78	76	finally
/* 267:    */     }
/* 268:    */     
/* 269:    */     private void startTask()
/* 270:    */     {
/* 271:368 */       this.lock.lock();
/* 272:    */       try
/* 273:    */       {
/* 274:370 */         if (isShutdown()) {
/* 275:371 */           throw new RejectedExecutionException("Executor already shutdown");
/* 276:    */         }
/* 277:373 */         this.runningTasks += 1;
/* 278:    */       }
/* 279:    */       finally
/* 280:    */       {
/* 281:375 */         this.lock.unlock();
/* 282:    */       }
/* 283:    */     }
/* 284:    */     
/* 285:    */     private void endTask()
/* 286:    */     {
/* 287:383 */       this.lock.lock();
/* 288:    */       try
/* 289:    */       {
/* 290:385 */         this.runningTasks -= 1;
/* 291:386 */         if (isTerminated()) {
/* 292:387 */           this.termination.signalAll();
/* 293:    */         }
/* 294:    */       }
/* 295:    */       finally
/* 296:    */       {
/* 297:390 */         this.lock.unlock();
/* 298:    */       }
/* 299:    */     }
/* 300:    */   }
/* 301:    */   
/* 302:    */   public static ListeningExecutorService listeningDecorator(ExecutorService delegate)
/* 303:    */   {
/* 304:415 */     return (delegate instanceof ScheduledExecutorService) ? new ScheduledListeningDecorator((ScheduledExecutorService)delegate) : (delegate instanceof ListeningExecutorService) ? (ListeningExecutorService)delegate : new ListeningDecorator(delegate);
/* 305:    */   }
/* 306:    */   
/* 307:    */   public static ListeningScheduledExecutorService listeningDecorator(ScheduledExecutorService delegate)
/* 308:    */   {
/* 309:443 */     return (delegate instanceof ListeningScheduledExecutorService) ? (ListeningScheduledExecutorService)delegate : new ScheduledListeningDecorator(delegate);
/* 310:    */   }
/* 311:    */   
/* 312:    */   private static class ListeningDecorator
/* 313:    */     extends AbstractListeningExecutorService
/* 314:    */   {
/* 315:    */     private final ExecutorService delegate;
/* 316:    */     
/* 317:    */     ListeningDecorator(ExecutorService delegate)
/* 318:    */     {
/* 319:453 */       this.delegate = ((ExecutorService)Preconditions.checkNotNull(delegate));
/* 320:    */     }
/* 321:    */     
/* 322:    */     public boolean awaitTermination(long timeout, TimeUnit unit)
/* 323:    */       throws InterruptedException
/* 324:    */     {
/* 325:459 */       return this.delegate.awaitTermination(timeout, unit);
/* 326:    */     }
/* 327:    */     
/* 328:    */     public boolean isShutdown()
/* 329:    */     {
/* 330:464 */       return this.delegate.isShutdown();
/* 331:    */     }
/* 332:    */     
/* 333:    */     public boolean isTerminated()
/* 334:    */     {
/* 335:469 */       return this.delegate.isTerminated();
/* 336:    */     }
/* 337:    */     
/* 338:    */     public void shutdown()
/* 339:    */     {
/* 340:474 */       this.delegate.shutdown();
/* 341:    */     }
/* 342:    */     
/* 343:    */     public List<Runnable> shutdownNow()
/* 344:    */     {
/* 345:479 */       return this.delegate.shutdownNow();
/* 346:    */     }
/* 347:    */     
/* 348:    */     public void execute(Runnable command)
/* 349:    */     {
/* 350:484 */       this.delegate.execute(command);
/* 351:    */     }
/* 352:    */   }
/* 353:    */   
/* 354:    */   private static class ScheduledListeningDecorator
/* 355:    */     extends MoreExecutors.ListeningDecorator
/* 356:    */     implements ListeningScheduledExecutorService
/* 357:    */   {
/* 358:    */     final ScheduledExecutorService delegate;
/* 359:    */     
/* 360:    */     ScheduledListeningDecorator(ScheduledExecutorService delegate)
/* 361:    */     {
/* 362:494 */       super();
/* 363:495 */       this.delegate = ((ScheduledExecutorService)Preconditions.checkNotNull(delegate));
/* 364:    */     }
/* 365:    */     
/* 366:    */     public ListenableScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit)
/* 367:    */     {
/* 368:501 */       ListenableFutureTask<Void> task = ListenableFutureTask.create(command, null);
/* 369:    */       
/* 370:503 */       ScheduledFuture<?> scheduled = this.delegate.schedule(task, delay, unit);
/* 371:504 */       return new ListenableScheduledTask(task, scheduled);
/* 372:    */     }
/* 373:    */     
/* 374:    */     public <V> ListenableScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit)
/* 375:    */     {
/* 376:510 */       ListenableFutureTask<V> task = ListenableFutureTask.create(callable);
/* 377:511 */       ScheduledFuture<?> scheduled = this.delegate.schedule(task, delay, unit);
/* 378:512 */       return new ListenableScheduledTask(task, scheduled);
/* 379:    */     }
/* 380:    */     
/* 381:    */     public ListenableScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit)
/* 382:    */     {
/* 383:518 */       NeverSuccessfulListenableFutureTask task = new NeverSuccessfulListenableFutureTask(command);
/* 384:    */       
/* 385:520 */       ScheduledFuture<?> scheduled = this.delegate.scheduleAtFixedRate(task, initialDelay, period, unit);
/* 386:    */       
/* 387:522 */       return new ListenableScheduledTask(task, scheduled);
/* 388:    */     }
/* 389:    */     
/* 390:    */     public ListenableScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit)
/* 391:    */     {
/* 392:528 */       NeverSuccessfulListenableFutureTask task = new NeverSuccessfulListenableFutureTask(command);
/* 393:    */       
/* 394:530 */       ScheduledFuture<?> scheduled = this.delegate.scheduleWithFixedDelay(task, initialDelay, delay, unit);
/* 395:    */       
/* 396:532 */       return new ListenableScheduledTask(task, scheduled);
/* 397:    */     }
/* 398:    */     
/* 399:    */     private static final class ListenableScheduledTask<V>
/* 400:    */       extends ForwardingListenableFuture.SimpleForwardingListenableFuture<V>
/* 401:    */       implements ListenableScheduledFuture<V>
/* 402:    */     {
/* 403:    */       private final ScheduledFuture<?> scheduledDelegate;
/* 404:    */       
/* 405:    */       public ListenableScheduledTask(ListenableFuture<V> listenableDelegate, ScheduledFuture<?> scheduledDelegate)
/* 406:    */       {
/* 407:544 */         super();
/* 408:545 */         this.scheduledDelegate = scheduledDelegate;
/* 409:    */       }
/* 410:    */       
/* 411:    */       public boolean cancel(boolean mayInterruptIfRunning)
/* 412:    */       {
/* 413:550 */         boolean cancelled = super.cancel(mayInterruptIfRunning);
/* 414:551 */         if (cancelled) {
/* 415:553 */           this.scheduledDelegate.cancel(mayInterruptIfRunning);
/* 416:    */         }
/* 417:557 */         return cancelled;
/* 418:    */       }
/* 419:    */       
/* 420:    */       public long getDelay(TimeUnit unit)
/* 421:    */       {
/* 422:562 */         return this.scheduledDelegate.getDelay(unit);
/* 423:    */       }
/* 424:    */       
/* 425:    */       public int compareTo(Delayed other)
/* 426:    */       {
/* 427:567 */         return this.scheduledDelegate.compareTo(other);
/* 428:    */       }
/* 429:    */     }
/* 430:    */     
/* 431:    */     private static final class NeverSuccessfulListenableFutureTask
/* 432:    */       extends AbstractFuture<Void>
/* 433:    */       implements Runnable
/* 434:    */     {
/* 435:    */       private final Runnable delegate;
/* 436:    */       
/* 437:    */       public NeverSuccessfulListenableFutureTask(Runnable delegate)
/* 438:    */       {
/* 439:577 */         this.delegate = ((Runnable)Preconditions.checkNotNull(delegate));
/* 440:    */       }
/* 441:    */       
/* 442:    */       public void run()
/* 443:    */       {
/* 444:    */         try
/* 445:    */         {
/* 446:582 */           this.delegate.run();
/* 447:    */         }
/* 448:    */         catch (Throwable t)
/* 449:    */         {
/* 450:584 */           setException(t);
/* 451:585 */           throw Throwables.propagate(t);
/* 452:    */         }
/* 453:    */       }
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   static <T> T invokeAnyImpl(ListeningExecutorService executorService, Collection<? extends Callable<T>> tasks, boolean timed, long nanos)
/* 458:    */     throws InterruptedException, ExecutionException, TimeoutException
/* 459:    */   {
/* 460:609 */     Preconditions.checkNotNull(executorService);
/* 461:610 */     int ntasks = tasks.size();
/* 462:611 */     Preconditions.checkArgument(ntasks > 0);
/* 463:612 */     List<Future<T>> futures = Lists.newArrayListWithCapacity(ntasks);
/* 464:613 */     BlockingQueue<Future<T>> futureQueue = Queues.newLinkedBlockingQueue();
/* 465:    */     try
/* 466:    */     {
/* 467:624 */       ExecutionException ee = null;
/* 468:625 */       long lastTime = timed ? System.nanoTime() : 0L;
/* 469:626 */       Iterator<? extends Callable<T>> it = tasks.iterator();
/* 470:    */       
/* 471:628 */       futures.add(submitAndAddQueueListener(executorService, (Callable)it.next(), futureQueue));
/* 472:629 */       ntasks--;
/* 473:630 */       int active = 1;
/* 474:    */       for (;;)
/* 475:    */       {
/* 476:633 */         Future<T> f = (Future)futureQueue.poll();
/* 477:    */         long now;
/* 478:634 */         if (f == null) {
/* 479:635 */           if (ntasks > 0)
/* 480:    */           {
/* 481:636 */             ntasks--;
/* 482:637 */             futures.add(submitAndAddQueueListener(executorService, (Callable)it.next(), futureQueue));
/* 483:638 */             active++;
/* 484:    */           }
/* 485:    */           else
/* 486:    */           {
/* 487:639 */             if (active == 0) {
/* 488:    */               break;
/* 489:    */             }
/* 490:641 */             if (timed)
/* 491:    */             {
/* 492:642 */               f = (Future)futureQueue.poll(nanos, TimeUnit.NANOSECONDS);
/* 493:643 */               if (f == null) {
/* 494:644 */                 throw new TimeoutException();
/* 495:    */               }
/* 496:646 */               now = System.nanoTime();
/* 497:647 */               nanos -= now - lastTime;
/* 498:648 */               lastTime = now;
/* 499:    */             }
/* 500:    */             else
/* 501:    */             {
/* 502:650 */               f = (Future)futureQueue.take();
/* 503:    */             }
/* 504:    */           }
/* 505:    */         }
/* 506:653 */         if (f != null)
/* 507:    */         {
/* 508:654 */           active--;
/* 509:    */           try
/* 510:    */           {
/* 511:    */             Iterator i$;
/* 512:    */             Future<T> f;
/* 513:656 */             return f.get();
/* 514:    */           }
/* 515:    */           catch (ExecutionException eex)
/* 516:    */           {
/* 517:658 */             ee = eex;
/* 518:    */           }
/* 519:    */           catch (RuntimeException rex)
/* 520:    */           {
/* 521:660 */             ee = new ExecutionException(rex);
/* 522:    */           }
/* 523:    */         }
/* 524:    */       }
/* 525:665 */       if (ee == null) {
/* 526:666 */         ee = new ExecutionException(null);
/* 527:    */       }
/* 528:668 */       throw ee;
/* 529:    */     }
/* 530:    */     finally
/* 531:    */     {
/* 532:670 */       for (Future<T> f : futures) {
/* 533:671 */         f.cancel(true);
/* 534:    */       }
/* 535:    */     }
/* 536:    */   }
/* 537:    */   
/* 538:    */   private static <T> ListenableFuture<T> submitAndAddQueueListener(ListeningExecutorService executorService, Callable<T> task, BlockingQueue<Future<T>> queue)
/* 539:    */   {
/* 540:682 */     final ListenableFuture<T> future = executorService.submit(task);
/* 541:683 */     future.addListener(new Runnable()
/* 542:    */     {
/* 543:    */       public void run()
/* 544:    */       {
/* 545:685 */         this.val$queue.add(future);
/* 546:    */       }
/* 547:685 */     }, sameThreadExecutor());
/* 548:    */     
/* 549:    */ 
/* 550:688 */     return future;
/* 551:    */   }
/* 552:    */   
/* 553:    */   @Beta
/* 554:    */   public static ThreadFactory platformThreadFactory()
/* 555:    */   {
/* 556:701 */     if (!isAppEngine()) {
/* 557:702 */       return Executors.defaultThreadFactory();
/* 558:    */     }
/* 559:    */     try
/* 560:    */     {
/* 561:705 */       return (ThreadFactory)Class.forName("com.google.appengine.api.ThreadManager").getMethod("currentRequestThreadFactory", new Class[0]).invoke(null, new Object[0]);
/* 562:    */     }
/* 563:    */     catch (IllegalAccessException e)
/* 564:    */     {
/* 565:709 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 566:    */     }
/* 567:    */     catch (ClassNotFoundException e)
/* 568:    */     {
/* 569:711 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 570:    */     }
/* 571:    */     catch (NoSuchMethodException e)
/* 572:    */     {
/* 573:713 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 574:    */     }
/* 575:    */     catch (InvocationTargetException e)
/* 576:    */     {
/* 577:715 */       throw Throwables.propagate(e.getCause());
/* 578:    */     }
/* 579:    */   }
/* 580:    */   
/* 581:    */   private static boolean isAppEngine()
/* 582:    */   {
/* 583:720 */     if (System.getProperty("com.google.appengine.runtime.environment") == null) {
/* 584:721 */       return false;
/* 585:    */     }
/* 586:    */     try
/* 587:    */     {
/* 588:725 */       return Class.forName("com.google.apphosting.api.ApiProxy").getMethod("getCurrentEnvironment", new Class[0]).invoke(null, new Object[0]) != null;
/* 589:    */     }
/* 590:    */     catch (ClassNotFoundException e)
/* 591:    */     {
/* 592:730 */       return false;
/* 593:    */     }
/* 594:    */     catch (InvocationTargetException e)
/* 595:    */     {
/* 596:733 */       return false;
/* 597:    */     }
/* 598:    */     catch (IllegalAccessException e)
/* 599:    */     {
/* 600:736 */       return false;
/* 601:    */     }
/* 602:    */     catch (NoSuchMethodException e) {}
/* 603:739 */     return false;
/* 604:    */   }
/* 605:    */   
/* 606:    */   static Thread newThread(String name, Runnable runnable)
/* 607:    */   {
/* 608:748 */     Preconditions.checkNotNull(name);
/* 609:749 */     Preconditions.checkNotNull(runnable);
/* 610:750 */     Thread result = platformThreadFactory().newThread(runnable);
/* 611:    */     try
/* 612:    */     {
/* 613:752 */       result.setName(name);
/* 614:    */     }
/* 615:    */     catch (SecurityException e) {}
/* 616:756 */     return result;
/* 617:    */   }
/* 618:    */   
/* 619:    */   static Executor renamingDecorator(Executor executor, final Supplier<String> nameSupplier)
/* 620:    */   {
/* 621:775 */     Preconditions.checkNotNull(executor);
/* 622:776 */     Preconditions.checkNotNull(nameSupplier);
/* 623:777 */     if (isAppEngine()) {
/* 624:779 */       return executor;
/* 625:    */     }
/* 626:781 */     new Executor()
/* 627:    */     {
/* 628:    */       public void execute(Runnable command)
/* 629:    */       {
/* 630:783 */         this.val$executor.execute(Callables.threadRenaming(command, nameSupplier));
/* 631:    */       }
/* 632:    */     };
/* 633:    */   }
/* 634:    */   
/* 635:    */   static ExecutorService renamingDecorator(ExecutorService service, final Supplier<String> nameSupplier)
/* 636:    */   {
/* 637:802 */     Preconditions.checkNotNull(service);
/* 638:803 */     Preconditions.checkNotNull(nameSupplier);
/* 639:804 */     if (isAppEngine()) {
/* 640:806 */       return service;
/* 641:    */     }
/* 642:808 */     new WrappingExecutorService(service)
/* 643:    */     {
/* 644:    */       protected <T> Callable<T> wrapTask(Callable<T> callable)
/* 645:    */       {
/* 646:810 */         return Callables.threadRenaming(callable, nameSupplier);
/* 647:    */       }
/* 648:    */       
/* 649:    */       protected Runnable wrapTask(Runnable command)
/* 650:    */       {
/* 651:813 */         return Callables.threadRenaming(command, nameSupplier);
/* 652:    */       }
/* 653:    */     };
/* 654:    */   }
/* 655:    */   
/* 656:    */   static ScheduledExecutorService renamingDecorator(ScheduledExecutorService service, final Supplier<String> nameSupplier)
/* 657:    */   {
/* 658:832 */     Preconditions.checkNotNull(service);
/* 659:833 */     Preconditions.checkNotNull(nameSupplier);
/* 660:834 */     if (isAppEngine()) {
/* 661:836 */       return service;
/* 662:    */     }
/* 663:838 */     new WrappingScheduledExecutorService(service)
/* 664:    */     {
/* 665:    */       protected <T> Callable<T> wrapTask(Callable<T> callable)
/* 666:    */       {
/* 667:840 */         return Callables.threadRenaming(callable, nameSupplier);
/* 668:    */       }
/* 669:    */       
/* 670:    */       protected Runnable wrapTask(Runnable command)
/* 671:    */       {
/* 672:843 */         return Callables.threadRenaming(command, nameSupplier);
/* 673:    */       }
/* 674:    */     };
/* 675:    */   }
/* 676:    */   
/* 677:    */   @Beta
/* 678:    */   public static boolean shutdownAndAwaitTermination(ExecutorService service, long timeout, TimeUnit unit)
/* 679:    */   {
/* 680:875 */     Preconditions.checkNotNull(unit);
/* 681:    */     
/* 682:877 */     service.shutdown();
/* 683:    */     try
/* 684:    */     {
/* 685:879 */       long halfTimeoutNanos = TimeUnit.NANOSECONDS.convert(timeout, unit) / 2L;
/* 686:881 */       if (!service.awaitTermination(halfTimeoutNanos, TimeUnit.NANOSECONDS))
/* 687:    */       {
/* 688:883 */         service.shutdownNow();
/* 689:    */         
/* 690:885 */         service.awaitTermination(halfTimeoutNanos, TimeUnit.NANOSECONDS);
/* 691:    */       }
/* 692:    */     }
/* 693:    */     catch (InterruptedException ie)
/* 694:    */     {
/* 695:889 */       Thread.currentThread().interrupt();
/* 696:    */       
/* 697:891 */       service.shutdownNow();
/* 698:    */     }
/* 699:893 */     return service.isTerminated();
/* 700:    */   }
/* 701:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.MoreExecutors
 * JD-Core Version:    0.7.0.1
 */
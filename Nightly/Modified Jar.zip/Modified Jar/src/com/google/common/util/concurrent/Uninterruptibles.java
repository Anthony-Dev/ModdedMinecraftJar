/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.util.concurrent.BlockingQueue;
/*   5:    */ import java.util.concurrent.CountDownLatch;
/*   6:    */ import java.util.concurrent.ExecutionException;
/*   7:    */ import java.util.concurrent.Future;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public final class Uninterruptibles
/*  11:    */ {
/*  12:    */   public static void awaitUninterruptibly(CountDownLatch latch)
/*  13:    */   {
/*  14: 51 */     boolean interrupted = false;
/*  15:    */     try
/*  16:    */     {
/*  17: 55 */       latch.await();
/*  18:    */     }
/*  19:    */     catch (InterruptedException e)
/*  20:    */     {
/*  21:    */       for (;;)
/*  22:    */       {
/*  23: 58 */         interrupted = true;
/*  24:    */       }
/*  25:    */     }
/*  26:    */     finally
/*  27:    */     {
/*  28: 62 */       if (interrupted) {
/*  29: 63 */         Thread.currentThread().interrupt();
/*  30:    */       }
/*  31:    */     }
/*  32:    */   }
/*  33:    */   
/*  34:    */   /* Error */
/*  35:    */   public static boolean awaitUninterruptibly(CountDownLatch latch, long timeout, java.util.concurrent.TimeUnit unit)
/*  36:    */   {
/*  37:    */     // Byte code:
/*  38:    */     //   0: iconst_0
/*  39:    */     //   1: istore 4
/*  40:    */     //   3: aload_3
/*  41:    */     //   4: lload_1
/*  42:    */     //   5: invokevirtual 123	java/util/concurrent/TimeUnit:toNanos	(J)J
/*  43:    */     //   8: lstore 5
/*  44:    */     //   10: invokestatic 117	java/lang/System:nanoTime	()J
/*  45:    */     //   13: lload 5
/*  46:    */     //   15: ladd
/*  47:    */     //   16: lstore 7
/*  48:    */     //   18: aload_0
/*  49:    */     //   19: lload 5
/*  50:    */     //   21: getstatic 114	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/*  51:    */     //   24: invokevirtual 122	java/util/concurrent/CountDownLatch:await	(JLjava/util/concurrent/TimeUnit;)Z
/*  52:    */     //   27: istore 9
/*  53:    */     //   29: iload 4
/*  54:    */     //   31: ifeq +9 -> 40
/*  55:    */     //   34: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  56:    */     //   37: invokevirtual 118	java/lang/Thread:interrupt	()V
/*  57:    */     //   40: iload 9
/*  58:    */     //   42: ireturn
/*  59:    */     //   43: astore 9
/*  60:    */     //   45: iconst_1
/*  61:    */     //   46: istore 4
/*  62:    */     //   48: lload 7
/*  63:    */     //   50: invokestatic 117	java/lang/System:nanoTime	()J
/*  64:    */     //   53: lsub
/*  65:    */     //   54: lstore 5
/*  66:    */     //   56: goto -38 -> 18
/*  67:    */     //   59: astore 10
/*  68:    */     //   61: iload 4
/*  69:    */     //   63: ifeq +9 -> 72
/*  70:    */     //   66: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  71:    */     //   69: invokevirtual 118	java/lang/Thread:interrupt	()V
/*  72:    */     //   72: aload 10
/*  73:    */     //   74: athrow
/*  74:    */     // Line number table:
/*  75:    */     //   Java source line #75	-> byte code offset #0
/*  76:    */     //   Java source line #77	-> byte code offset #3
/*  77:    */     //   Java source line #78	-> byte code offset #10
/*  78:    */     //   Java source line #83	-> byte code offset #18
/*  79:    */     //   Java source line #90	-> byte code offset #29
/*  80:    */     //   Java source line #91	-> byte code offset #34
/*  81:    */     //   Java source line #84	-> byte code offset #43
/*  82:    */     //   Java source line #85	-> byte code offset #45
/*  83:    */     //   Java source line #86	-> byte code offset #48
/*  84:    */     //   Java source line #87	-> byte code offset #56
/*  85:    */     //   Java source line #90	-> byte code offset #59
/*  86:    */     //   Java source line #91	-> byte code offset #66
/*  87:    */     // Local variable table:
/*  88:    */     //   start	length	slot	name	signature
/*  89:    */     //   0	75	0	latch	CountDownLatch
/*  90:    */     //   0	75	1	timeout	long
/*  91:    */     //   0	75	3	unit	java.util.concurrent.TimeUnit
/*  92:    */     //   1	61	4	interrupted	boolean
/*  93:    */     //   8	47	5	remainingNanos	long
/*  94:    */     //   16	33	7	end	long
/*  95:    */     //   27	14	9	bool1	boolean
/*  96:    */     //   43	3	9	e	InterruptedException
/*  97:    */     //   59	14	10	localObject	Object
/*  98:    */     // Exception table:
/*  99:    */     //   from	to	target	type
/* 100:    */     //   18	29	43	java/lang/InterruptedException
/* 101:    */     //   3	29	59	finally
/* 102:    */     //   43	61	59	finally
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static void joinUninterruptibly(Thread toJoin)
/* 106:    */   {
/* 107:100 */     boolean interrupted = false;
/* 108:    */     try
/* 109:    */     {
/* 110:104 */       toJoin.join();
/* 111:    */     }
/* 112:    */     catch (InterruptedException e)
/* 113:    */     {
/* 114:    */       for (;;)
/* 115:    */       {
/* 116:107 */         interrupted = true;
/* 117:    */       }
/* 118:    */     }
/* 119:    */     finally
/* 120:    */     {
/* 121:111 */       if (interrupted) {
/* 122:112 */         Thread.currentThread().interrupt();
/* 123:    */       }
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static <V> V getUninterruptibly(Future<V> future)
/* 128:    */     throws ExecutionException
/* 129:    */   {
/* 130:131 */     boolean interrupted = false;
/* 131:    */     try
/* 132:    */     {
/* 133:135 */       return future.get();
/* 134:    */     }
/* 135:    */     catch (InterruptedException e)
/* 136:    */     {
/* 137:    */       for (;;)
/* 138:    */       {
/* 139:137 */         interrupted = true;
/* 140:    */       }
/* 141:    */     }
/* 142:    */     finally
/* 143:    */     {
/* 144:141 */       if (interrupted) {
/* 145:142 */         Thread.currentThread().interrupt();
/* 146:    */       }
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   /* Error */
/* 151:    */   public static <V> V getUninterruptibly(Future<V> future, long timeout, java.util.concurrent.TimeUnit unit)
/* 152:    */     throws ExecutionException, java.util.concurrent.TimeoutException
/* 153:    */   {
/* 154:    */     // Byte code:
/* 155:    */     //   0: iconst_0
/* 156:    */     //   1: istore 4
/* 157:    */     //   3: aload_3
/* 158:    */     //   4: lload_1
/* 159:    */     //   5: invokevirtual 123	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 160:    */     //   8: lstore 5
/* 161:    */     //   10: invokestatic 117	java/lang/System:nanoTime	()J
/* 162:    */     //   13: lload 5
/* 163:    */     //   15: ladd
/* 164:    */     //   16: lstore 7
/* 165:    */     //   18: aload_0
/* 166:    */     //   19: lload 5
/* 167:    */     //   21: getstatic 114	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 168:    */     //   24: invokeinterface 129 4 0
/* 169:    */     //   29: astore 9
/* 170:    */     //   31: iload 4
/* 171:    */     //   33: ifeq +9 -> 42
/* 172:    */     //   36: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 173:    */     //   39: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 174:    */     //   42: aload 9
/* 175:    */     //   44: areturn
/* 176:    */     //   45: astore 9
/* 177:    */     //   47: iconst_1
/* 178:    */     //   48: istore 4
/* 179:    */     //   50: lload 7
/* 180:    */     //   52: invokestatic 117	java/lang/System:nanoTime	()J
/* 181:    */     //   55: lsub
/* 182:    */     //   56: lstore 5
/* 183:    */     //   58: goto -40 -> 18
/* 184:    */     //   61: astore 10
/* 185:    */     //   63: iload 4
/* 186:    */     //   65: ifeq +9 -> 74
/* 187:    */     //   68: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 188:    */     //   71: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 189:    */     //   74: aload 10
/* 190:    */     //   76: athrow
/* 191:    */     // Line number table:
/* 192:    */     //   Java source line #163	-> byte code offset #0
/* 193:    */     //   Java source line #165	-> byte code offset #3
/* 194:    */     //   Java source line #166	-> byte code offset #10
/* 195:    */     //   Java source line #171	-> byte code offset #18
/* 196:    */     //   Java source line #178	-> byte code offset #31
/* 197:    */     //   Java source line #179	-> byte code offset #36
/* 198:    */     //   Java source line #172	-> byte code offset #45
/* 199:    */     //   Java source line #173	-> byte code offset #47
/* 200:    */     //   Java source line #174	-> byte code offset #50
/* 201:    */     //   Java source line #175	-> byte code offset #58
/* 202:    */     //   Java source line #178	-> byte code offset #61
/* 203:    */     //   Java source line #179	-> byte code offset #68
/* 204:    */     // Local variable table:
/* 205:    */     //   start	length	slot	name	signature
/* 206:    */     //   0	77	0	future	Future<V>
/* 207:    */     //   0	77	1	timeout	long
/* 208:    */     //   0	77	3	unit	java.util.concurrent.TimeUnit
/* 209:    */     //   1	63	4	interrupted	boolean
/* 210:    */     //   8	49	5	remainingNanos	long
/* 211:    */     //   16	35	7	end	long
/* 212:    */     //   29	14	9	localObject1	Object
/* 213:    */     //   45	3	9	e	InterruptedException
/* 214:    */     //   61	14	10	localObject2	Object
/* 215:    */     // Exception table:
/* 216:    */     //   from	to	target	type
/* 217:    */     //   18	31	45	java/lang/InterruptedException
/* 218:    */     //   3	31	61	finally
/* 219:    */     //   45	63	61	finally
/* 220:    */   }
/* 221:    */   
/* 222:    */   /* Error */
/* 223:    */   public static void joinUninterruptibly(Thread toJoin, long timeout, java.util.concurrent.TimeUnit unit)
/* 224:    */   {
/* 225:    */     // Byte code:
/* 226:    */     //   0: aload_0
/* 227:    */     //   1: invokestatic 115	com/google/common/base/Preconditions:checkNotNull	(Ljava/lang/Object;)Ljava/lang/Object;
/* 228:    */     //   4: pop
/* 229:    */     //   5: iconst_0
/* 230:    */     //   6: istore 4
/* 231:    */     //   8: aload_3
/* 232:    */     //   9: lload_1
/* 233:    */     //   10: invokevirtual 123	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 234:    */     //   13: lstore 5
/* 235:    */     //   15: invokestatic 117	java/lang/System:nanoTime	()J
/* 236:    */     //   18: lload 5
/* 237:    */     //   20: ladd
/* 238:    */     //   21: lstore 7
/* 239:    */     //   23: getstatic 114	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 240:    */     //   26: aload_0
/* 241:    */     //   27: lload 5
/* 242:    */     //   29: invokevirtual 125	java/util/concurrent/TimeUnit:timedJoin	(Ljava/lang/Thread;J)V
/* 243:    */     //   32: iload 4
/* 244:    */     //   34: ifeq +9 -> 43
/* 245:    */     //   37: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 246:    */     //   40: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 247:    */     //   43: return
/* 248:    */     //   44: astore 9
/* 249:    */     //   46: iconst_1
/* 250:    */     //   47: istore 4
/* 251:    */     //   49: lload 7
/* 252:    */     //   51: invokestatic 117	java/lang/System:nanoTime	()J
/* 253:    */     //   54: lsub
/* 254:    */     //   55: lstore 5
/* 255:    */     //   57: goto -34 -> 23
/* 256:    */     //   60: astore 10
/* 257:    */     //   62: iload 4
/* 258:    */     //   64: ifeq +9 -> 73
/* 259:    */     //   67: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 260:    */     //   70: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 261:    */     //   73: aload 10
/* 262:    */     //   75: athrow
/* 263:    */     // Line number table:
/* 264:    */     //   Java source line #191	-> byte code offset #0
/* 265:    */     //   Java source line #192	-> byte code offset #5
/* 266:    */     //   Java source line #194	-> byte code offset #8
/* 267:    */     //   Java source line #195	-> byte code offset #15
/* 268:    */     //   Java source line #199	-> byte code offset #23
/* 269:    */     //   Java source line #207	-> byte code offset #32
/* 270:    */     //   Java source line #208	-> byte code offset #37
/* 271:    */     //   Java source line #201	-> byte code offset #44
/* 272:    */     //   Java source line #202	-> byte code offset #46
/* 273:    */     //   Java source line #203	-> byte code offset #49
/* 274:    */     //   Java source line #204	-> byte code offset #57
/* 275:    */     //   Java source line #207	-> byte code offset #60
/* 276:    */     //   Java source line #208	-> byte code offset #67
/* 277:    */     // Local variable table:
/* 278:    */     //   start	length	slot	name	signature
/* 279:    */     //   0	76	0	toJoin	Thread
/* 280:    */     //   0	76	1	timeout	long
/* 281:    */     //   0	76	3	unit	java.util.concurrent.TimeUnit
/* 282:    */     //   6	57	4	interrupted	boolean
/* 283:    */     //   13	43	5	remainingNanos	long
/* 284:    */     //   21	29	7	end	long
/* 285:    */     //   44	3	9	e	InterruptedException
/* 286:    */     //   60	14	10	localObject	Object
/* 287:    */     // Exception table:
/* 288:    */     //   from	to	target	type
/* 289:    */     //   23	32	44	java/lang/InterruptedException
/* 290:    */     //   8	32	60	finally
/* 291:    */     //   44	62	60	finally
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static <E> E takeUninterruptibly(BlockingQueue<E> queue)
/* 295:    */   {
/* 296:217 */     boolean interrupted = false;
/* 297:    */     try
/* 298:    */     {
/* 299:221 */       return queue.take();
/* 300:    */     }
/* 301:    */     catch (InterruptedException e)
/* 302:    */     {
/* 303:    */       for (;;)
/* 304:    */       {
/* 305:223 */         interrupted = true;
/* 306:    */       }
/* 307:    */     }
/* 308:    */     finally
/* 309:    */     {
/* 310:227 */       if (interrupted) {
/* 311:228 */         Thread.currentThread().interrupt();
/* 312:    */       }
/* 313:    */     }
/* 314:    */   }
/* 315:    */   
/* 316:    */   public static <E> void putUninterruptibly(BlockingQueue<E> queue, E element)
/* 317:    */   {
/* 318:243 */     boolean interrupted = false;
/* 319:    */     try
/* 320:    */     {
/* 321:247 */       queue.put(element);
/* 322:    */     }
/* 323:    */     catch (InterruptedException e)
/* 324:    */     {
/* 325:    */       for (;;)
/* 326:    */       {
/* 327:250 */         interrupted = true;
/* 328:    */       }
/* 329:    */     }
/* 330:    */     finally
/* 331:    */     {
/* 332:254 */       if (interrupted) {
/* 333:255 */         Thread.currentThread().interrupt();
/* 334:    */       }
/* 335:    */     }
/* 336:    */   }
/* 337:    */   
/* 338:    */   /* Error */
/* 339:    */   public static void sleepUninterruptibly(long sleepFor, java.util.concurrent.TimeUnit unit)
/* 340:    */   {
/* 341:    */     // Byte code:
/* 342:    */     //   0: iconst_0
/* 343:    */     //   1: istore_3
/* 344:    */     //   2: aload_2
/* 345:    */     //   3: lload_0
/* 346:    */     //   4: invokevirtual 123	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 347:    */     //   7: lstore 4
/* 348:    */     //   9: invokestatic 117	java/lang/System:nanoTime	()J
/* 349:    */     //   12: lload 4
/* 350:    */     //   14: ladd
/* 351:    */     //   15: lstore 6
/* 352:    */     //   17: getstatic 114	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 353:    */     //   20: lload 4
/* 354:    */     //   22: invokevirtual 124	java/util/concurrent/TimeUnit:sleep	(J)V
/* 355:    */     //   25: iload_3
/* 356:    */     //   26: ifeq +9 -> 35
/* 357:    */     //   29: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 358:    */     //   32: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 359:    */     //   35: return
/* 360:    */     //   36: astore 8
/* 361:    */     //   38: iconst_1
/* 362:    */     //   39: istore_3
/* 363:    */     //   40: lload 6
/* 364:    */     //   42: invokestatic 117	java/lang/System:nanoTime	()J
/* 365:    */     //   45: lsub
/* 366:    */     //   46: lstore 4
/* 367:    */     //   48: goto -31 -> 17
/* 368:    */     //   51: astore 9
/* 369:    */     //   53: iload_3
/* 370:    */     //   54: ifeq +9 -> 63
/* 371:    */     //   57: invokestatic 120	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 372:    */     //   60: invokevirtual 118	java/lang/Thread:interrupt	()V
/* 373:    */     //   63: aload 9
/* 374:    */     //   65: athrow
/* 375:    */     // Line number table:
/* 376:    */     //   Java source line #266	-> byte code offset #0
/* 377:    */     //   Java source line #268	-> byte code offset #2
/* 378:    */     //   Java source line #269	-> byte code offset #9
/* 379:    */     //   Java source line #273	-> byte code offset #17
/* 380:    */     //   Java source line #281	-> byte code offset #25
/* 381:    */     //   Java source line #282	-> byte code offset #29
/* 382:    */     //   Java source line #275	-> byte code offset #36
/* 383:    */     //   Java source line #276	-> byte code offset #38
/* 384:    */     //   Java source line #277	-> byte code offset #40
/* 385:    */     //   Java source line #278	-> byte code offset #48
/* 386:    */     //   Java source line #281	-> byte code offset #51
/* 387:    */     //   Java source line #282	-> byte code offset #57
/* 388:    */     // Local variable table:
/* 389:    */     //   start	length	slot	name	signature
/* 390:    */     //   0	66	0	sleepFor	long
/* 391:    */     //   0	66	2	unit	java.util.concurrent.TimeUnit
/* 392:    */     //   1	53	3	interrupted	boolean
/* 393:    */     //   7	40	4	remainingNanos	long
/* 394:    */     //   15	26	6	end	long
/* 395:    */     //   36	3	8	e	InterruptedException
/* 396:    */     //   51	13	9	localObject	Object
/* 397:    */     // Exception table:
/* 398:    */     //   from	to	target	type
/* 399:    */     //   17	25	36	java/lang/InterruptedException
/* 400:    */     //   2	25	51	finally
/* 401:    */     //   36	53	51	finally
/* 402:    */   }
/* 403:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Uninterruptibles
 * JD-Core Version:    0.7.0.1
 */
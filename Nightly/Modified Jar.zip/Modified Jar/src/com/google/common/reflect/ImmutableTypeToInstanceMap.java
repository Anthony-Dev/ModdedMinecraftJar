/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.collect.ForwardingMap;
/*   5:    */ import com.google.common.collect.ImmutableMap;
/*   6:    */ import com.google.common.collect.ImmutableMap.Builder;
/*   7:    */ import java.util.Map;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public final class ImmutableTypeToInstanceMap<B>
/*  11:    */   extends ForwardingMap<TypeToken<? extends B>, B>
/*  12:    */   implements TypeToInstanceMap<B>
/*  13:    */ {
/*  14:    */   private final ImmutableMap<TypeToken<? extends B>, B> delegate;
/*  15:    */   
/*  16:    */   public static <B> ImmutableTypeToInstanceMap<B> of()
/*  17:    */   {
/*  18: 38 */     return new ImmutableTypeToInstanceMap(ImmutableMap.of());
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static <B> Builder<B> builder()
/*  22:    */   {
/*  23: 43 */     return new Builder(null);
/*  24:    */   }
/*  25:    */   
/*  26:    */   @Beta
/*  27:    */   public static final class Builder<B>
/*  28:    */   {
/*  29: 64 */     private final ImmutableMap.Builder<TypeToken<? extends B>, B> mapBuilder = ImmutableMap.builder();
/*  30:    */     
/*  31:    */     public <T extends B> Builder<B> put(Class<T> key, T value)
/*  32:    */     {
/*  33: 74 */       this.mapBuilder.put(TypeToken.of(key), value);
/*  34: 75 */       return this;
/*  35:    */     }
/*  36:    */     
/*  37:    */     public <T extends B> Builder<B> put(TypeToken<T> key, T value)
/*  38:    */     {
/*  39: 83 */       this.mapBuilder.put(key.rejectTypeVariables(), value);
/*  40: 84 */       return this;
/*  41:    */     }
/*  42:    */     
/*  43:    */     public ImmutableTypeToInstanceMap<B> build()
/*  44:    */     {
/*  45: 94 */       return new ImmutableTypeToInstanceMap(this.mapBuilder.build(), null);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   private ImmutableTypeToInstanceMap(ImmutableMap<TypeToken<? extends B>, B> delegate)
/*  50:    */   {
/*  51:101 */     this.delegate = delegate;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public <T extends B> T getInstance(TypeToken<T> type)
/*  55:    */   {
/*  56:105 */     return trustedGet(type.rejectTypeVariables());
/*  57:    */   }
/*  58:    */   
/*  59:    */   public <T extends B> T putInstance(TypeToken<T> type, T value)
/*  60:    */   {
/*  61:114 */     throw new UnsupportedOperationException();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public <T extends B> T getInstance(Class<T> type)
/*  65:    */   {
/*  66:118 */     return trustedGet(TypeToken.of(type));
/*  67:    */   }
/*  68:    */   
/*  69:    */   public <T extends B> T putInstance(Class<T> type, T value)
/*  70:    */   {
/*  71:127 */     throw new UnsupportedOperationException();
/*  72:    */   }
/*  73:    */   
/*  74:    */   protected Map<TypeToken<? extends B>, B> delegate()
/*  75:    */   {
/*  76:131 */     return this.delegate;
/*  77:    */   }
/*  78:    */   
/*  79:    */   private <T extends B> T trustedGet(TypeToken<T> type)
/*  80:    */   {
/*  81:136 */     return this.delegate.get(type);
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.ImmutableTypeToInstanceMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.CharMatcher;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import com.google.common.base.Splitter;
/*   9:    */ import com.google.common.collect.FluentIterable;
/*  10:    */ import com.google.common.collect.ImmutableMap;
/*  11:    */ import com.google.common.collect.ImmutableSet;
/*  12:    */ import com.google.common.collect.ImmutableSet.Builder;
/*  13:    */ import com.google.common.collect.ImmutableSortedSet;
/*  14:    */ import com.google.common.collect.ImmutableSortedSet.Builder;
/*  15:    */ import com.google.common.collect.Maps;
/*  16:    */ import com.google.common.collect.Ordering;
/*  17:    */ import com.google.common.collect.Sets;
/*  18:    */ import java.io.File;
/*  19:    */ import java.io.IOException;
/*  20:    */ import java.net.URI;
/*  21:    */ import java.net.URISyntaxException;
/*  22:    */ import java.net.URL;
/*  23:    */ import java.net.URLClassLoader;
/*  24:    */ import java.util.Enumeration;
/*  25:    */ import java.util.LinkedHashMap;
/*  26:    */ import java.util.Map.Entry;
/*  27:    */ import java.util.Set;
/*  28:    */ import java.util.jar.Attributes;
/*  29:    */ import java.util.jar.Attributes.Name;
/*  30:    */ import java.util.jar.JarEntry;
/*  31:    */ import java.util.jar.JarFile;
/*  32:    */ import java.util.jar.Manifest;
/*  33:    */ import java.util.logging.Logger;
/*  34:    */ import javax.annotation.Nullable;
/*  35:    */ 
/*  36:    */ @Beta
/*  37:    */ public final class ClassPath
/*  38:    */ {
/*  39: 60 */   private static final Logger logger = Logger.getLogger(ClassPath.class.getName());
/*  40: 62 */   private static final Predicate<ClassInfo> IS_TOP_LEVEL = new Predicate()
/*  41:    */   {
/*  42:    */     public boolean apply(ClassPath.ClassInfo info)
/*  43:    */     {
/*  44: 64 */       return ClassPath.ClassInfo.access$000(info).indexOf('$') == -1;
/*  45:    */     }
/*  46:    */   };
/*  47: 69 */   private static final Splitter CLASS_PATH_ATTRIBUTE_SEPARATOR = Splitter.on(" ").omitEmptyStrings();
/*  48:    */   private static final String CLASS_FILE_NAME_EXTENSION = ".class";
/*  49:    */   private final ImmutableSet<ResourceInfo> resources;
/*  50:    */   
/*  51:    */   private ClassPath(ImmutableSet<ResourceInfo> resources)
/*  52:    */   {
/*  53: 77 */     this.resources = resources;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static ClassPath from(ClassLoader classloader)
/*  57:    */     throws IOException
/*  58:    */   {
/*  59: 90 */     Scanner scanner = new Scanner();
/*  60: 91 */     for (Map.Entry<URI, ClassLoader> entry : getClassPathEntries(classloader).entrySet()) {
/*  61: 92 */       scanner.scan((URI)entry.getKey(), (ClassLoader)entry.getValue());
/*  62:    */     }
/*  63: 94 */     return new ClassPath(scanner.getResources());
/*  64:    */   }
/*  65:    */   
/*  66:    */   public ImmutableSet<ResourceInfo> getResources()
/*  67:    */   {
/*  68:102 */     return this.resources;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public ImmutableSet<ClassInfo> getAllClasses()
/*  72:    */   {
/*  73:111 */     return FluentIterable.from(this.resources).filter(ClassInfo.class).toSet();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public ImmutableSet<ClassInfo> getTopLevelClasses()
/*  77:    */   {
/*  78:116 */     return FluentIterable.from(this.resources).filter(ClassInfo.class).filter(IS_TOP_LEVEL).toSet();
/*  79:    */   }
/*  80:    */   
/*  81:    */   public ImmutableSet<ClassInfo> getTopLevelClasses(String packageName)
/*  82:    */   {
/*  83:121 */     Preconditions.checkNotNull(packageName);
/*  84:122 */     ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
/*  85:123 */     for (ClassInfo classInfo : getTopLevelClasses()) {
/*  86:124 */       if (classInfo.getPackageName().equals(packageName)) {
/*  87:125 */         builder.add(classInfo);
/*  88:    */       }
/*  89:    */     }
/*  90:128 */     return builder.build();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public ImmutableSet<ClassInfo> getTopLevelClassesRecursive(String packageName)
/*  94:    */   {
/*  95:136 */     Preconditions.checkNotNull(packageName);
/*  96:137 */     String packagePrefix = packageName + '.';
/*  97:138 */     ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
/*  98:139 */     for (ClassInfo classInfo : getTopLevelClasses()) {
/*  99:140 */       if (classInfo.getName().startsWith(packagePrefix)) {
/* 100:141 */         builder.add(classInfo);
/* 101:    */       }
/* 102:    */     }
/* 103:144 */     return builder.build();
/* 104:    */   }
/* 105:    */   
/* 106:    */   @Beta
/* 107:    */   public static class ResourceInfo
/* 108:    */   {
/* 109:    */     private final String resourceName;
/* 110:    */     final ClassLoader loader;
/* 111:    */     
/* 112:    */     static ResourceInfo of(String resourceName, ClassLoader loader)
/* 113:    */     {
/* 114:159 */       if (resourceName.endsWith(".class")) {
/* 115:160 */         return new ClassPath.ClassInfo(resourceName, loader);
/* 116:    */       }
/* 117:162 */       return new ResourceInfo(resourceName, loader);
/* 118:    */     }
/* 119:    */     
/* 120:    */     ResourceInfo(String resourceName, ClassLoader loader)
/* 121:    */     {
/* 122:167 */       this.resourceName = ((String)Preconditions.checkNotNull(resourceName));
/* 123:168 */       this.loader = ((ClassLoader)Preconditions.checkNotNull(loader));
/* 124:    */     }
/* 125:    */     
/* 126:    */     public final URL url()
/* 127:    */     {
/* 128:173 */       return (URL)Preconditions.checkNotNull(this.loader.getResource(this.resourceName), "Failed to load resource: %s", new Object[] { this.resourceName });
/* 129:    */     }
/* 130:    */     
/* 131:    */     public final String getResourceName()
/* 132:    */     {
/* 133:179 */       return this.resourceName;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public int hashCode()
/* 137:    */     {
/* 138:183 */       return this.resourceName.hashCode();
/* 139:    */     }
/* 140:    */     
/* 141:    */     public boolean equals(Object obj)
/* 142:    */     {
/* 143:187 */       if ((obj instanceof ResourceInfo))
/* 144:    */       {
/* 145:188 */         ResourceInfo that = (ResourceInfo)obj;
/* 146:189 */         return (this.resourceName.equals(that.resourceName)) && (this.loader == that.loader);
/* 147:    */       }
/* 148:192 */       return false;
/* 149:    */     }
/* 150:    */     
/* 151:    */     public String toString()
/* 152:    */     {
/* 153:197 */       return this.resourceName;
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   @Beta
/* 158:    */   public static final class ClassInfo
/* 159:    */     extends ClassPath.ResourceInfo
/* 160:    */   {
/* 161:    */     private final String className;
/* 162:    */     
/* 163:    */     ClassInfo(String resourceName, ClassLoader loader)
/* 164:    */     {
/* 165:211 */       super(loader);
/* 166:212 */       this.className = ClassPath.getClassName(resourceName);
/* 167:    */     }
/* 168:    */     
/* 169:    */     public String getPackageName()
/* 170:    */     {
/* 171:222 */       return Reflection.getPackageName(this.className);
/* 172:    */     }
/* 173:    */     
/* 174:    */     public String getSimpleName()
/* 175:    */     {
/* 176:232 */       int lastDollarSign = this.className.lastIndexOf('$');
/* 177:233 */       if (lastDollarSign != -1)
/* 178:    */       {
/* 179:234 */         String innerClassName = this.className.substring(lastDollarSign + 1);
/* 180:    */         
/* 181:    */ 
/* 182:237 */         return CharMatcher.DIGIT.trimLeadingFrom(innerClassName);
/* 183:    */       }
/* 184:239 */       String packageName = getPackageName();
/* 185:240 */       if (packageName.isEmpty()) {
/* 186:241 */         return this.className;
/* 187:    */       }
/* 188:245 */       return this.className.substring(packageName.length() + 1);
/* 189:    */     }
/* 190:    */     
/* 191:    */     public String getName()
/* 192:    */     {
/* 193:255 */       return this.className;
/* 194:    */     }
/* 195:    */     
/* 196:    */     public Class<?> load()
/* 197:    */     {
/* 198:    */       try
/* 199:    */       {
/* 200:266 */         return this.loader.loadClass(this.className);
/* 201:    */       }
/* 202:    */       catch (ClassNotFoundException e)
/* 203:    */       {
/* 204:269 */         throw new IllegalStateException(e);
/* 205:    */       }
/* 206:    */     }
/* 207:    */     
/* 208:    */     public String toString()
/* 209:    */     {
/* 210:274 */       return this.className;
/* 211:    */     }
/* 212:    */   }
/* 213:    */   
/* 214:    */   @VisibleForTesting
/* 215:    */   static ImmutableMap<URI, ClassLoader> getClassPathEntries(ClassLoader classloader)
/* 216:    */   {
/* 217:280 */     LinkedHashMap<URI, ClassLoader> entries = Maps.newLinkedHashMap();
/* 218:    */     
/* 219:282 */     ClassLoader parent = classloader.getParent();
/* 220:283 */     if (parent != null) {
/* 221:284 */       entries.putAll(getClassPathEntries(parent));
/* 222:    */     }
/* 223:286 */     if ((classloader instanceof URLClassLoader))
/* 224:    */     {
/* 225:287 */       URLClassLoader urlClassLoader = (URLClassLoader)classloader;
/* 226:288 */       for (URL entry : urlClassLoader.getURLs())
/* 227:    */       {
/* 228:    */         URI uri;
/* 229:    */         try
/* 230:    */         {
/* 231:291 */           uri = entry.toURI();
/* 232:    */         }
/* 233:    */         catch (URISyntaxException e)
/* 234:    */         {
/* 235:293 */           throw new IllegalArgumentException(e);
/* 236:    */         }
/* 237:295 */         if (!entries.containsKey(uri)) {
/* 238:296 */           entries.put(uri, classloader);
/* 239:    */         }
/* 240:    */       }
/* 241:    */     }
/* 242:300 */     return ImmutableMap.copyOf(entries);
/* 243:    */   }
/* 244:    */   
/* 245:    */   @VisibleForTesting
/* 246:    */   static final class Scanner
/* 247:    */   {
/* 248:305 */     private final ImmutableSortedSet.Builder<ClassPath.ResourceInfo> resources = new ImmutableSortedSet.Builder(Ordering.usingToString());
/* 249:307 */     private final Set<URI> scannedUris = Sets.newHashSet();
/* 250:    */     
/* 251:    */     ImmutableSortedSet<ClassPath.ResourceInfo> getResources()
/* 252:    */     {
/* 253:310 */       return this.resources.build();
/* 254:    */     }
/* 255:    */     
/* 256:    */     void scan(URI uri, ClassLoader classloader)
/* 257:    */       throws IOException
/* 258:    */     {
/* 259:314 */       if ((uri.getScheme().equals("file")) && (this.scannedUris.add(uri))) {
/* 260:315 */         scanFrom(new File(uri), classloader);
/* 261:    */       }
/* 262:    */     }
/* 263:    */     
/* 264:    */     @VisibleForTesting
/* 265:    */     void scanFrom(File file, ClassLoader classloader)
/* 266:    */       throws IOException
/* 267:    */     {
/* 268:321 */       if (!file.exists()) {
/* 269:322 */         return;
/* 270:    */       }
/* 271:324 */       if (file.isDirectory()) {
/* 272:325 */         scanDirectory(file, classloader);
/* 273:    */       } else {
/* 274:327 */         scanJar(file, classloader);
/* 275:    */       }
/* 276:    */     }
/* 277:    */     
/* 278:    */     private void scanDirectory(File directory, ClassLoader classloader)
/* 279:    */       throws IOException
/* 280:    */     {
/* 281:332 */       scanDirectory(directory, classloader, "", ImmutableSet.of());
/* 282:    */     }
/* 283:    */     
/* 284:    */     private void scanDirectory(File directory, ClassLoader classloader, String packagePrefix, ImmutableSet<File> ancestors)
/* 285:    */       throws IOException
/* 286:    */     {
/* 287:338 */       File canonical = directory.getCanonicalFile();
/* 288:339 */       if (ancestors.contains(canonical)) {
/* 289:341 */         return;
/* 290:    */       }
/* 291:343 */       File[] files = directory.listFiles();
/* 292:344 */       if (files == null)
/* 293:    */       {
/* 294:345 */         ClassPath.logger.warning("Cannot read directory " + directory);
/* 295:    */         
/* 296:347 */         return;
/* 297:    */       }
/* 298:349 */       ImmutableSet<File> newAncestors = ImmutableSet.builder().addAll(ancestors).add(canonical).build();
/* 299:353 */       for (File f : files)
/* 300:    */       {
/* 301:354 */         String name = f.getName();
/* 302:355 */         if (f.isDirectory())
/* 303:    */         {
/* 304:356 */           scanDirectory(f, classloader, packagePrefix + name + "/", newAncestors);
/* 305:    */         }
/* 306:    */         else
/* 307:    */         {
/* 308:358 */           String resourceName = packagePrefix + name;
/* 309:359 */           if (!resourceName.equals("META-INF/MANIFEST.MF")) {
/* 310:360 */             this.resources.add(ClassPath.ResourceInfo.of(resourceName, classloader));
/* 311:    */           }
/* 312:    */         }
/* 313:    */       }
/* 314:    */     }
/* 315:    */     
/* 316:    */     private void scanJar(File file, ClassLoader classloader)
/* 317:    */       throws IOException
/* 318:    */     {
/* 319:    */       JarFile jarFile;
/* 320:    */       try
/* 321:    */       {
/* 322:369 */         jarFile = new JarFile(file);
/* 323:    */       }
/* 324:    */       catch (IOException e)
/* 325:    */       {
/* 326:372 */         return;
/* 327:    */       }
/* 328:    */       try
/* 329:    */       {
/* 330:375 */         for (URI uri : getClassPathFromManifest(file, jarFile.getManifest())) {
/* 331:376 */           scan(uri, classloader);
/* 332:    */         }
/* 333:378 */         Enumeration<JarEntry> entries = jarFile.entries();
/* 334:379 */         while (entries.hasMoreElements())
/* 335:    */         {
/* 336:380 */           JarEntry entry = (JarEntry)entries.nextElement();
/* 337:381 */           if ((!entry.isDirectory()) && (!entry.getName().equals("META-INF/MANIFEST.MF"))) {
/* 338:384 */             this.resources.add(ClassPath.ResourceInfo.of(entry.getName(), classloader));
/* 339:    */           }
/* 340:    */         }
/* 341:    */         return;
/* 342:    */       }
/* 343:    */       finally
/* 344:    */       {
/* 345:    */         try
/* 346:    */         {
/* 347:388 */           jarFile.close();
/* 348:    */         }
/* 349:    */         catch (IOException ignored) {}
/* 350:    */       }
/* 351:    */     }
/* 352:    */     
/* 353:    */     @VisibleForTesting
/* 354:    */     static ImmutableSet<URI> getClassPathFromManifest(File jarFile, @Nullable Manifest manifest)
/* 355:    */     {
/* 356:401 */       if (manifest == null) {
/* 357:402 */         return ImmutableSet.of();
/* 358:    */       }
/* 359:404 */       ImmutableSet.Builder<URI> builder = ImmutableSet.builder();
/* 360:405 */       String classpathAttribute = manifest.getMainAttributes().getValue(Attributes.Name.CLASS_PATH.toString());
/* 361:407 */       if (classpathAttribute != null) {
/* 362:408 */         for (String path : ClassPath.CLASS_PATH_ATTRIBUTE_SEPARATOR.split(classpathAttribute))
/* 363:    */         {
/* 364:    */           URI uri;
/* 365:    */           try
/* 366:    */           {
/* 367:411 */             uri = getClassPathEntry(jarFile, path);
/* 368:    */           }
/* 369:    */           catch (URISyntaxException e)
/* 370:    */           {
/* 371:414 */             ClassPath.logger.warning("Invalid Class-Path entry: " + path);
/* 372:    */           }
/* 373:415 */           continue;
/* 374:    */           
/* 375:417 */           builder.add(uri);
/* 376:    */         }
/* 377:    */       }
/* 378:420 */       return builder.build();
/* 379:    */     }
/* 380:    */     
/* 381:    */     @VisibleForTesting
/* 382:    */     static URI getClassPathEntry(File jarFile, String path)
/* 383:    */       throws URISyntaxException
/* 384:    */     {
/* 385:431 */       URI uri = new URI(path);
/* 386:432 */       if (uri.isAbsolute()) {
/* 387:433 */         return uri;
/* 388:    */       }
/* 389:435 */       return new File(jarFile.getParentFile(), path.replace('/', File.separatorChar)).toURI();
/* 390:    */     }
/* 391:    */   }
/* 392:    */   
/* 393:    */   @VisibleForTesting
/* 394:    */   static String getClassName(String filename)
/* 395:    */   {
/* 396:441 */     int classNameEnd = filename.length() - ".class".length();
/* 397:442 */     return filename.substring(0, classNameEnd).replace('/', '.');
/* 398:    */   }
/* 399:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.ClassPath
 * JD-Core Version:    0.7.0.1
 */
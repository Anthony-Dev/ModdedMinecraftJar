/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Joiner;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicates;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.ImmutableList.Builder;
/*  11:    */ import com.google.common.collect.Iterables;
/*  12:    */ import java.io.Serializable;
/*  13:    */ import java.lang.reflect.Array;
/*  14:    */ import java.lang.reflect.GenericArrayType;
/*  15:    */ import java.lang.reflect.GenericDeclaration;
/*  16:    */ import java.lang.reflect.ParameterizedType;
/*  17:    */ import java.lang.reflect.Type;
/*  18:    */ import java.lang.reflect.TypeVariable;
/*  19:    */ import java.lang.reflect.WildcardType;
/*  20:    */ import java.util.Arrays;
/*  21:    */ import java.util.Collection;
/*  22:    */ import java.util.concurrent.atomic.AtomicReference;
/*  23:    */ import javax.annotation.Nullable;
/*  24:    */ 
/*  25:    */ final class Types
/*  26:    */ {
/*  27: 53 */   private static final Function<Type, String> TYPE_TO_STRING = new Function()
/*  28:    */   {
/*  29:    */     public String apply(Type from)
/*  30:    */     {
/*  31: 56 */       return Types.toString(from);
/*  32:    */     }
/*  33:    */   };
/*  34: 60 */   private static final Joiner COMMA_JOINER = Joiner.on(", ").useForNull("null");
/*  35:    */   
/*  36:    */   static Type newArrayType(Type componentType)
/*  37:    */   {
/*  38: 64 */     if ((componentType instanceof WildcardType))
/*  39:    */     {
/*  40: 65 */       WildcardType wildcard = (WildcardType)componentType;
/*  41: 66 */       Type[] lowerBounds = wildcard.getLowerBounds();
/*  42: 67 */       Preconditions.checkArgument(lowerBounds.length <= 1, "Wildcard cannot have more than one lower bounds.");
/*  43: 68 */       if (lowerBounds.length == 1) {
/*  44: 69 */         return supertypeOf(newArrayType(lowerBounds[0]));
/*  45:    */       }
/*  46: 71 */       Type[] upperBounds = wildcard.getUpperBounds();
/*  47: 72 */       Preconditions.checkArgument(upperBounds.length == 1, "Wildcard should have only one upper bound.");
/*  48: 73 */       return subtypeOf(newArrayType(upperBounds[0]));
/*  49:    */     }
/*  50: 76 */     return JavaVersion.CURRENT.newArrayType(componentType);
/*  51:    */   }
/*  52:    */   
/*  53:    */   static ParameterizedType newParameterizedTypeWithOwner(@Nullable Type ownerType, Class<?> rawType, Type... arguments)
/*  54:    */   {
/*  55: 85 */     if (ownerType == null) {
/*  56: 86 */       return newParameterizedType(rawType, arguments);
/*  57:    */     }
/*  58: 89 */     Preconditions.checkNotNull(arguments);
/*  59: 90 */     Preconditions.checkArgument(rawType.getEnclosingClass() != null, "Owner type for unenclosed %s", new Object[] { rawType });
/*  60: 91 */     return new ParameterizedTypeImpl(ownerType, rawType, arguments);
/*  61:    */   }
/*  62:    */   
/*  63:    */   static ParameterizedType newParameterizedType(Class<?> rawType, Type... arguments)
/*  64:    */   {
/*  65: 99 */     return new ParameterizedTypeImpl(ClassOwnership.JVM_BEHAVIOR.getOwnerType(rawType), rawType, arguments);
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static abstract enum ClassOwnership
/*  69:    */   {
/*  70:106 */     OWNED_BY_ENCLOSING_CLASS,  LOCAL_CLASS_HAS_NO_OWNER;
/*  71:    */     
/*  72:127 */     static final ClassOwnership JVM_BEHAVIOR = detectJvmBehavior();
/*  73:    */     
/*  74:    */     private ClassOwnership() {}
/*  75:    */     
/*  76:    */     @Nullable
/*  77:    */     abstract Class<?> getOwnerType(Class<?> paramClass);
/*  78:    */     
/*  79:    */     private static ClassOwnership detectJvmBehavior()
/*  80:    */     {
/*  81:131 */       Class<?> subclass = new 1LocalClass() {}.getClass();
/*  82:132 */       ParameterizedType parameterizedType = (ParameterizedType)subclass.getGenericSuperclass();
/*  83:134 */       for (ClassOwnership behavior : values()) {
/*  84:135 */         if (behavior.getOwnerType(1LocalClass.class) == parameterizedType.getOwnerType()) {
/*  85:136 */           return behavior;
/*  86:    */         }
/*  87:    */       }
/*  88:139 */       throw new AssertionError();
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   static <D extends GenericDeclaration> TypeVariable<D> newArtificialTypeVariable(D declaration, String name, Type... bounds)
/*  93:    */   {
/*  94:149 */     return new TypeVariableImpl(declaration, name, bounds.length == 0 ? new Type[] { Object.class } : bounds);
/*  95:    */   }
/*  96:    */   
/*  97:    */   @VisibleForTesting
/*  98:    */   static WildcardType subtypeOf(Type upperBound)
/*  99:    */   {
/* 100:159 */     return new WildcardTypeImpl(new Type[0], new Type[] { upperBound });
/* 101:    */   }
/* 102:    */   
/* 103:    */   @VisibleForTesting
/* 104:    */   static WildcardType supertypeOf(Type lowerBound)
/* 105:    */   {
/* 106:164 */     return new WildcardTypeImpl(new Type[] { lowerBound }, new Type[] { Object.class });
/* 107:    */   }
/* 108:    */   
/* 109:    */   static String toString(Type type)
/* 110:    */   {
/* 111:177 */     return (type instanceof Class) ? ((Class)type).getName() : type.toString();
/* 112:    */   }
/* 113:    */   
/* 114:    */   @Nullable
/* 115:    */   static Type getComponentType(Type type)
/* 116:    */   {
/* 117:183 */     Preconditions.checkNotNull(type);
/* 118:184 */     AtomicReference<Type> result = new AtomicReference();
/* 119:185 */     new TypeVisitor()
/* 120:    */     {
/* 121:    */       void visitTypeVariable(TypeVariable<?> t)
/* 122:    */       {
/* 123:187 */         this.val$result.set(Types.subtypeOfComponentType(t.getBounds()));
/* 124:    */       }
/* 125:    */       
/* 126:    */       void visitWildcardType(WildcardType t)
/* 127:    */       {
/* 128:190 */         this.val$result.set(Types.subtypeOfComponentType(t.getUpperBounds()));
/* 129:    */       }
/* 130:    */       
/* 131:    */       void visitGenericArrayType(GenericArrayType t)
/* 132:    */       {
/* 133:193 */         this.val$result.set(t.getGenericComponentType());
/* 134:    */       }
/* 135:    */       
/* 136:    */       void visitClass(Class<?> t)
/* 137:    */       {
/* 138:196 */         this.val$result.set(t.getComponentType());
/* 139:    */       }
/* 140:196 */     }.visit(new Type[] { type });
/* 141:    */     
/* 142:    */ 
/* 143:199 */     return (Type)result.get();
/* 144:    */   }
/* 145:    */   
/* 146:    */   @Nullable
/* 147:    */   private static Type subtypeOfComponentType(Type[] bounds)
/* 148:    */   {
/* 149:207 */     for (Type bound : bounds)
/* 150:    */     {
/* 151:208 */       Type componentType = getComponentType(bound);
/* 152:209 */       if (componentType != null)
/* 153:    */       {
/* 154:212 */         if ((componentType instanceof Class))
/* 155:    */         {
/* 156:213 */           Class<?> componentClass = (Class)componentType;
/* 157:214 */           if (componentClass.isPrimitive()) {
/* 158:215 */             return componentClass;
/* 159:    */           }
/* 160:    */         }
/* 161:218 */         return subtypeOf(componentType);
/* 162:    */       }
/* 163:    */     }
/* 164:221 */     return null;
/* 165:    */   }
/* 166:    */   
/* 167:    */   private static final class GenericArrayTypeImpl
/* 168:    */     implements GenericArrayType, Serializable
/* 169:    */   {
/* 170:    */     private final Type componentType;
/* 171:    */     private static final long serialVersionUID = 0L;
/* 172:    */     
/* 173:    */     GenericArrayTypeImpl(Type componentType)
/* 174:    */     {
/* 175:230 */       this.componentType = Types.JavaVersion.CURRENT.usedInGenericType(componentType);
/* 176:    */     }
/* 177:    */     
/* 178:    */     public Type getGenericComponentType()
/* 179:    */     {
/* 180:234 */       return this.componentType;
/* 181:    */     }
/* 182:    */     
/* 183:    */     public String toString()
/* 184:    */     {
/* 185:238 */       return Types.toString(this.componentType) + "[]";
/* 186:    */     }
/* 187:    */     
/* 188:    */     public int hashCode()
/* 189:    */     {
/* 190:242 */       return this.componentType.hashCode();
/* 191:    */     }
/* 192:    */     
/* 193:    */     public boolean equals(Object obj)
/* 194:    */     {
/* 195:246 */       if ((obj instanceof GenericArrayType))
/* 196:    */       {
/* 197:247 */         GenericArrayType that = (GenericArrayType)obj;
/* 198:248 */         return Objects.equal(getGenericComponentType(), that.getGenericComponentType());
/* 199:    */       }
/* 200:251 */       return false;
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   private static final class ParameterizedTypeImpl
/* 205:    */     implements ParameterizedType, Serializable
/* 206:    */   {
/* 207:    */     private final Type ownerType;
/* 208:    */     private final ImmutableList<Type> argumentsList;
/* 209:    */     private final Class<?> rawType;
/* 210:    */     private static final long serialVersionUID = 0L;
/* 211:    */     
/* 212:    */     ParameterizedTypeImpl(@Nullable Type ownerType, Class<?> rawType, Type[] typeArguments)
/* 213:    */     {
/* 214:266 */       Preconditions.checkNotNull(rawType);
/* 215:267 */       Preconditions.checkArgument(typeArguments.length == rawType.getTypeParameters().length);
/* 216:268 */       Types.disallowPrimitiveType(typeArguments, "type parameter");
/* 217:269 */       this.ownerType = ownerType;
/* 218:270 */       this.rawType = rawType;
/* 219:271 */       this.argumentsList = Types.JavaVersion.CURRENT.usedInGenericType(typeArguments);
/* 220:    */     }
/* 221:    */     
/* 222:    */     public Type[] getActualTypeArguments()
/* 223:    */     {
/* 224:275 */       return Types.toArray(this.argumentsList);
/* 225:    */     }
/* 226:    */     
/* 227:    */     public Type getRawType()
/* 228:    */     {
/* 229:279 */       return this.rawType;
/* 230:    */     }
/* 231:    */     
/* 232:    */     public Type getOwnerType()
/* 233:    */     {
/* 234:283 */       return this.ownerType;
/* 235:    */     }
/* 236:    */     
/* 237:    */     public String toString()
/* 238:    */     {
/* 239:287 */       StringBuilder builder = new StringBuilder();
/* 240:288 */       if (this.ownerType != null) {
/* 241:289 */         builder.append(Types.toString(this.ownerType)).append('.');
/* 242:    */       }
/* 243:291 */       builder.append(this.rawType.getName()).append('<').append(Types.COMMA_JOINER.join(Iterables.transform(this.argumentsList, Types.TYPE_TO_STRING))).append('>');
/* 244:    */       
/* 245:    */ 
/* 246:    */ 
/* 247:295 */       return builder.toString();
/* 248:    */     }
/* 249:    */     
/* 250:    */     public int hashCode()
/* 251:    */     {
/* 252:299 */       return (this.ownerType == null ? 0 : this.ownerType.hashCode()) ^ this.argumentsList.hashCode() ^ this.rawType.hashCode();
/* 253:    */     }
/* 254:    */     
/* 255:    */     public boolean equals(Object other)
/* 256:    */     {
/* 257:304 */       if (!(other instanceof ParameterizedType)) {
/* 258:305 */         return false;
/* 259:    */       }
/* 260:307 */       ParameterizedType that = (ParameterizedType)other;
/* 261:308 */       return (getRawType().equals(that.getRawType())) && (Objects.equal(getOwnerType(), that.getOwnerType())) && (Arrays.equals(getActualTypeArguments(), that.getActualTypeArguments()));
/* 262:    */     }
/* 263:    */   }
/* 264:    */   
/* 265:    */   private static final class TypeVariableImpl<D extends GenericDeclaration>
/* 266:    */     implements TypeVariable<D>
/* 267:    */   {
/* 268:    */     private final D genericDeclaration;
/* 269:    */     private final String name;
/* 270:    */     private final ImmutableList<Type> bounds;
/* 271:    */     
/* 272:    */     TypeVariableImpl(D genericDeclaration, String name, Type[] bounds)
/* 273:    */     {
/* 274:325 */       Types.disallowPrimitiveType(bounds, "bound for type variable");
/* 275:326 */       this.genericDeclaration = ((GenericDeclaration)Preconditions.checkNotNull(genericDeclaration));
/* 276:327 */       this.name = ((String)Preconditions.checkNotNull(name));
/* 277:328 */       this.bounds = ImmutableList.copyOf(bounds);
/* 278:    */     }
/* 279:    */     
/* 280:    */     public Type[] getBounds()
/* 281:    */     {
/* 282:332 */       return Types.toArray(this.bounds);
/* 283:    */     }
/* 284:    */     
/* 285:    */     public D getGenericDeclaration()
/* 286:    */     {
/* 287:336 */       return this.genericDeclaration;
/* 288:    */     }
/* 289:    */     
/* 290:    */     public String getName()
/* 291:    */     {
/* 292:340 */       return this.name;
/* 293:    */     }
/* 294:    */     
/* 295:    */     public String toString()
/* 296:    */     {
/* 297:344 */       return this.name;
/* 298:    */     }
/* 299:    */     
/* 300:    */     public int hashCode()
/* 301:    */     {
/* 302:348 */       return this.genericDeclaration.hashCode() ^ this.name.hashCode();
/* 303:    */     }
/* 304:    */     
/* 305:    */     public boolean equals(Object obj)
/* 306:    */     {
/* 307:352 */       if (Types.NativeTypeVariableEquals.NATIVE_TYPE_VARIABLE_ONLY)
/* 308:    */       {
/* 309:354 */         if ((obj instanceof TypeVariableImpl))
/* 310:    */         {
/* 311:355 */           TypeVariableImpl<?> that = (TypeVariableImpl)obj;
/* 312:356 */           return (this.name.equals(that.getName())) && (this.genericDeclaration.equals(that.getGenericDeclaration())) && (this.bounds.equals(that.bounds));
/* 313:    */         }
/* 314:360 */         return false;
/* 315:    */       }
/* 316:363 */       if ((obj instanceof TypeVariable))
/* 317:    */       {
/* 318:364 */         TypeVariable<?> that = (TypeVariable)obj;
/* 319:365 */         return (this.name.equals(that.getName())) && (this.genericDeclaration.equals(that.getGenericDeclaration()));
/* 320:    */       }
/* 321:368 */       return false;
/* 322:    */     }
/* 323:    */   }
/* 324:    */   
/* 325:    */   static final class WildcardTypeImpl
/* 326:    */     implements WildcardType, Serializable
/* 327:    */   {
/* 328:    */     private final ImmutableList<Type> lowerBounds;
/* 329:    */     private final ImmutableList<Type> upperBounds;
/* 330:    */     private static final long serialVersionUID = 0L;
/* 331:    */     
/* 332:    */     WildcardTypeImpl(Type[] lowerBounds, Type[] upperBounds)
/* 333:    */     {
/* 334:379 */       Types.disallowPrimitiveType(lowerBounds, "lower bound for wildcard");
/* 335:380 */       Types.disallowPrimitiveType(upperBounds, "upper bound for wildcard");
/* 336:381 */       this.lowerBounds = Types.JavaVersion.CURRENT.usedInGenericType(lowerBounds);
/* 337:382 */       this.upperBounds = Types.JavaVersion.CURRENT.usedInGenericType(upperBounds);
/* 338:    */     }
/* 339:    */     
/* 340:    */     public Type[] getLowerBounds()
/* 341:    */     {
/* 342:386 */       return Types.toArray(this.lowerBounds);
/* 343:    */     }
/* 344:    */     
/* 345:    */     public Type[] getUpperBounds()
/* 346:    */     {
/* 347:390 */       return Types.toArray(this.upperBounds);
/* 348:    */     }
/* 349:    */     
/* 350:    */     public boolean equals(Object obj)
/* 351:    */     {
/* 352:394 */       if ((obj instanceof WildcardType))
/* 353:    */       {
/* 354:395 */         WildcardType that = (WildcardType)obj;
/* 355:396 */         return (this.lowerBounds.equals(Arrays.asList(that.getLowerBounds()))) && (this.upperBounds.equals(Arrays.asList(that.getUpperBounds())));
/* 356:    */       }
/* 357:399 */       return false;
/* 358:    */     }
/* 359:    */     
/* 360:    */     public int hashCode()
/* 361:    */     {
/* 362:403 */       return this.lowerBounds.hashCode() ^ this.upperBounds.hashCode();
/* 363:    */     }
/* 364:    */     
/* 365:    */     public String toString()
/* 366:    */     {
/* 367:407 */       StringBuilder builder = new StringBuilder("?");
/* 368:408 */       for (Type lowerBound : this.lowerBounds) {
/* 369:409 */         builder.append(" super ").append(Types.toString(lowerBound));
/* 370:    */       }
/* 371:411 */       for (Type upperBound : Types.filterUpperBounds(this.upperBounds)) {
/* 372:412 */         builder.append(" extends ").append(Types.toString(upperBound));
/* 373:    */       }
/* 374:414 */       return builder.toString();
/* 375:    */     }
/* 376:    */   }
/* 377:    */   
/* 378:    */   private static Type[] toArray(Collection<Type> types)
/* 379:    */   {
/* 380:421 */     return (Type[])types.toArray(new Type[types.size()]);
/* 381:    */   }
/* 382:    */   
/* 383:    */   private static Iterable<Type> filterUpperBounds(Iterable<Type> bounds)
/* 384:    */   {
/* 385:425 */     return Iterables.filter(bounds, Predicates.not(Predicates.equalTo(Object.class)));
/* 386:    */   }
/* 387:    */   
/* 388:    */   private static void disallowPrimitiveType(Type[] types, String usedAs)
/* 389:    */   {
/* 390:430 */     for (Type type : types) {
/* 391:431 */       if ((type instanceof Class))
/* 392:    */       {
/* 393:432 */         Class<?> cls = (Class)type;
/* 394:433 */         Preconditions.checkArgument(!cls.isPrimitive(), "Primitive type '%s' used as %s", new Object[] { cls, usedAs });
/* 395:    */       }
/* 396:    */     }
/* 397:    */   }
/* 398:    */   
/* 399:    */   static Class<?> getArrayClass(Class<?> componentType)
/* 400:    */   {
/* 401:444 */     return Array.newInstance(componentType, 0).getClass();
/* 402:    */   }
/* 403:    */   
/* 404:    */   static abstract enum JavaVersion
/* 405:    */   {
/* 406:450 */     JAVA6,  JAVA7;
/* 407:    */     
/* 408:479 */     static final JavaVersion CURRENT = (new TypeCapture() {}.capture() instanceof Class) ? JAVA7 : JAVA6;
/* 409:    */     
/* 410:    */     private JavaVersion() {}
/* 411:    */     
/* 412:    */     abstract Type newArrayType(Type paramType);
/* 413:    */     
/* 414:    */     abstract Type usedInGenericType(Type paramType);
/* 415:    */     
/* 416:    */     final ImmutableList<Type> usedInGenericType(Type[] types)
/* 417:    */     {
/* 418:486 */       ImmutableList.Builder<Type> builder = ImmutableList.builder();
/* 419:487 */       for (Type type : types) {
/* 420:488 */         builder.add(usedInGenericType(type));
/* 421:    */       }
/* 422:490 */       return builder.build();
/* 423:    */     }
/* 424:    */   }
/* 425:    */   
/* 426:    */   static final class NativeTypeVariableEquals<X>
/* 427:    */   {
/* 428:505 */     static final boolean NATIVE_TYPE_VARIABLE_ONLY = !NativeTypeVariableEquals.class.getTypeParameters()[0].equals(Types.newArtificialTypeVariable(NativeTypeVariableEquals.class, "X", new Type[0]));
/* 429:    */   }
/* 430:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.Types
 * JD-Core Version:    0.7.0.1
 */
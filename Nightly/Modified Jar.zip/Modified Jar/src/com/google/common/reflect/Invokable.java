/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.collect.ImmutableList;
/*   6:    */ import com.google.common.collect.ImmutableList.Builder;
/*   7:    */ import java.lang.annotation.Annotation;
/*   8:    */ import java.lang.reflect.AccessibleObject;
/*   9:    */ import java.lang.reflect.Constructor;
/*  10:    */ import java.lang.reflect.GenericDeclaration;
/*  11:    */ import java.lang.reflect.InvocationTargetException;
/*  12:    */ import java.lang.reflect.Member;
/*  13:    */ import java.lang.reflect.Method;
/*  14:    */ import java.lang.reflect.Modifier;
/*  15:    */ import java.lang.reflect.Type;
/*  16:    */ import java.lang.reflect.TypeVariable;
/*  17:    */ import java.util.Arrays;
/*  18:    */ import javax.annotation.Nullable;
/*  19:    */ 
/*  20:    */ @Beta
/*  21:    */ public abstract class Invokable<T, R>
/*  22:    */   extends Element
/*  23:    */   implements GenericDeclaration
/*  24:    */ {
/*  25:    */   <M extends AccessibleObject,  extends Member> Invokable(M member)
/*  26:    */   {
/*  27: 63 */     super(member);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static Invokable<?, Object> from(Method method)
/*  31:    */   {
/*  32: 68 */     return new MethodInvokable(method);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <T> Invokable<T, T> from(Constructor<T> constructor)
/*  36:    */   {
/*  37: 73 */     return new ConstructorInvokable(constructor);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public abstract boolean isOverridable();
/*  41:    */   
/*  42:    */   public abstract boolean isVarArgs();
/*  43:    */   
/*  44:    */   public final R invoke(@Nullable T receiver, Object... args)
/*  45:    */     throws InvocationTargetException, IllegalAccessException
/*  46:    */   {
/*  47:102 */     return invokeInternal(receiver, (Object[])Preconditions.checkNotNull(args));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public final TypeToken<? extends R> getReturnType()
/*  51:    */   {
/*  52:109 */     return TypeToken.of(getGenericReturnType());
/*  53:    */   }
/*  54:    */   
/*  55:    */   public final ImmutableList<Parameter> getParameters()
/*  56:    */   {
/*  57:118 */     Type[] parameterTypes = getGenericParameterTypes();
/*  58:119 */     Annotation[][] annotations = getParameterAnnotations();
/*  59:120 */     ImmutableList.Builder<Parameter> builder = ImmutableList.builder();
/*  60:121 */     for (int i = 0; i < parameterTypes.length; i++) {
/*  61:122 */       builder.add(new Parameter(this, i, TypeToken.of(parameterTypes[i]), annotations[i]));
/*  62:    */     }
/*  63:125 */     return builder.build();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public final ImmutableList<TypeToken<? extends Throwable>> getExceptionTypes()
/*  67:    */   {
/*  68:130 */     ImmutableList.Builder<TypeToken<? extends Throwable>> builder = ImmutableList.builder();
/*  69:131 */     for (Type type : getGenericExceptionTypes())
/*  70:    */     {
/*  71:134 */       TypeToken<? extends Throwable> exceptionType = TypeToken.of(type);
/*  72:    */       
/*  73:136 */       builder.add(exceptionType);
/*  74:    */     }
/*  75:138 */     return builder.build();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public final <R1 extends R> Invokable<T, R1> returning(Class<R1> returnType)
/*  79:    */   {
/*  80:148 */     return returning(TypeToken.of(returnType));
/*  81:    */   }
/*  82:    */   
/*  83:    */   public final <R1 extends R> Invokable<T, R1> returning(TypeToken<R1> returnType)
/*  84:    */   {
/*  85:153 */     if (!returnType.isAssignableFrom(getReturnType())) {
/*  86:154 */       throw new IllegalArgumentException("Invokable is known to return " + getReturnType() + ", not " + returnType);
/*  87:    */     }
/*  88:158 */     Invokable<T, R1> specialized = this;
/*  89:159 */     return specialized;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public final Class<? super T> getDeclaringClass()
/*  93:    */   {
/*  94:164 */     return super.getDeclaringClass();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public TypeToken<T> getOwnerType()
/*  98:    */   {
/*  99:171 */     return TypeToken.of(getDeclaringClass());
/* 100:    */   }
/* 101:    */   
/* 102:    */   abstract Object invokeInternal(@Nullable Object paramObject, Object[] paramArrayOfObject)
/* 103:    */     throws InvocationTargetException, IllegalAccessException;
/* 104:    */   
/* 105:    */   abstract Type[] getGenericParameterTypes();
/* 106:    */   
/* 107:    */   abstract Type[] getGenericExceptionTypes();
/* 108:    */   
/* 109:    */   abstract Annotation[][] getParameterAnnotations();
/* 110:    */   
/* 111:    */   abstract Type getGenericReturnType();
/* 112:    */   
/* 113:    */   static class MethodInvokable<T>
/* 114:    */     extends Invokable<T, Object>
/* 115:    */   {
/* 116:    */     final Method method;
/* 117:    */     
/* 118:    */     MethodInvokable(Method method)
/* 119:    */     {
/* 120:191 */       super();
/* 121:192 */       this.method = method;
/* 122:    */     }
/* 123:    */     
/* 124:    */     final Object invokeInternal(@Nullable Object receiver, Object[] args)
/* 125:    */       throws InvocationTargetException, IllegalAccessException
/* 126:    */     {
/* 127:197 */       return this.method.invoke(receiver, args);
/* 128:    */     }
/* 129:    */     
/* 130:    */     Type getGenericReturnType()
/* 131:    */     {
/* 132:201 */       return this.method.getGenericReturnType();
/* 133:    */     }
/* 134:    */     
/* 135:    */     Type[] getGenericParameterTypes()
/* 136:    */     {
/* 137:205 */       return this.method.getGenericParameterTypes();
/* 138:    */     }
/* 139:    */     
/* 140:    */     Type[] getGenericExceptionTypes()
/* 141:    */     {
/* 142:209 */       return this.method.getGenericExceptionTypes();
/* 143:    */     }
/* 144:    */     
/* 145:    */     final Annotation[][] getParameterAnnotations()
/* 146:    */     {
/* 147:213 */       return this.method.getParameterAnnotations();
/* 148:    */     }
/* 149:    */     
/* 150:    */     public final TypeVariable<?>[] getTypeParameters()
/* 151:    */     {
/* 152:217 */       return this.method.getTypeParameters();
/* 153:    */     }
/* 154:    */     
/* 155:    */     public final boolean isOverridable()
/* 156:    */     {
/* 157:221 */       return (!isFinal()) && (!isPrivate()) && (!isStatic()) && (!Modifier.isFinal(getDeclaringClass().getModifiers()));
/* 158:    */     }
/* 159:    */     
/* 160:    */     public final boolean isVarArgs()
/* 161:    */     {
/* 162:226 */       return this.method.isVarArgs();
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   static class ConstructorInvokable<T>
/* 167:    */     extends Invokable<T, T>
/* 168:    */   {
/* 169:    */     final Constructor<?> constructor;
/* 170:    */     
/* 171:    */     ConstructorInvokable(Constructor<?> constructor)
/* 172:    */     {
/* 173:235 */       super();
/* 174:236 */       this.constructor = constructor;
/* 175:    */     }
/* 176:    */     
/* 177:    */     final Object invokeInternal(@Nullable Object receiver, Object[] args)
/* 178:    */       throws InvocationTargetException, IllegalAccessException
/* 179:    */     {
/* 180:    */       try
/* 181:    */       {
/* 182:242 */         return this.constructor.newInstance(args);
/* 183:    */       }
/* 184:    */       catch (InstantiationException e)
/* 185:    */       {
/* 186:244 */         throw new RuntimeException(this.constructor + " failed.", e);
/* 187:    */       }
/* 188:    */     }
/* 189:    */     
/* 190:    */     Type getGenericReturnType()
/* 191:    */     {
/* 192:250 */       Class<?> declaringClass = getDeclaringClass();
/* 193:251 */       TypeVariable<?>[] typeParams = declaringClass.getTypeParameters();
/* 194:252 */       if (typeParams.length > 0) {
/* 195:253 */         return Types.newParameterizedType(declaringClass, typeParams);
/* 196:    */       }
/* 197:255 */       return declaringClass;
/* 198:    */     }
/* 199:    */     
/* 200:    */     Type[] getGenericParameterTypes()
/* 201:    */     {
/* 202:260 */       Type[] types = this.constructor.getGenericParameterTypes();
/* 203:261 */       if ((types.length > 0) && (mayNeedHiddenThis()))
/* 204:    */       {
/* 205:262 */         Class<?>[] rawParamTypes = this.constructor.getParameterTypes();
/* 206:263 */         if ((types.length == rawParamTypes.length) && (rawParamTypes[0] == getDeclaringClass().getEnclosingClass())) {
/* 207:266 */           return (Type[])Arrays.copyOfRange(types, 1, types.length);
/* 208:    */         }
/* 209:    */       }
/* 210:269 */       return types;
/* 211:    */     }
/* 212:    */     
/* 213:    */     Type[] getGenericExceptionTypes()
/* 214:    */     {
/* 215:273 */       return this.constructor.getGenericExceptionTypes();
/* 216:    */     }
/* 217:    */     
/* 218:    */     final Annotation[][] getParameterAnnotations()
/* 219:    */     {
/* 220:277 */       return this.constructor.getParameterAnnotations();
/* 221:    */     }
/* 222:    */     
/* 223:    */     public final TypeVariable<?>[] getTypeParameters()
/* 224:    */     {
/* 225:290 */       TypeVariable<?>[] declaredByClass = getDeclaringClass().getTypeParameters();
/* 226:291 */       TypeVariable<?>[] declaredByConstructor = this.constructor.getTypeParameters();
/* 227:292 */       TypeVariable<?>[] result = new TypeVariable[declaredByClass.length + declaredByConstructor.length];
/* 228:    */       
/* 229:294 */       System.arraycopy(declaredByClass, 0, result, 0, declaredByClass.length);
/* 230:295 */       System.arraycopy(declaredByConstructor, 0, result, declaredByClass.length, declaredByConstructor.length);
/* 231:    */       
/* 232:    */ 
/* 233:    */ 
/* 234:299 */       return result;
/* 235:    */     }
/* 236:    */     
/* 237:    */     public final boolean isOverridable()
/* 238:    */     {
/* 239:303 */       return false;
/* 240:    */     }
/* 241:    */     
/* 242:    */     public final boolean isVarArgs()
/* 243:    */     {
/* 244:307 */       return this.constructor.isVarArgs();
/* 245:    */     }
/* 246:    */     
/* 247:    */     private boolean mayNeedHiddenThis()
/* 248:    */     {
/* 249:311 */       Class<?> declaringClass = this.constructor.getDeclaringClass();
/* 250:312 */       if (declaringClass.getEnclosingConstructor() != null) {
/* 251:314 */         return true;
/* 252:    */       }
/* 253:316 */       Method enclosingMethod = declaringClass.getEnclosingMethod();
/* 254:317 */       if (enclosingMethod != null) {
/* 255:319 */         return !Modifier.isStatic(enclosingMethod.getModifiers());
/* 256:    */       }
/* 257:327 */       return (declaringClass.getEnclosingClass() != null) && (!Modifier.isStatic(declaringClass.getModifiers()));
/* 258:    */     }
/* 259:    */   }
/* 260:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.Invokable
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.ArrayDeque;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Queue;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ @GwtIncompatible("java.util.ArrayDeque")
/*  14:    */ public final class EvictingQueue<E>
/*  15:    */   extends ForwardingQueue<E>
/*  16:    */   implements Serializable
/*  17:    */ {
/*  18:    */   private final Queue<E> delegate;
/*  19:    */   @VisibleForTesting
/*  20:    */   final int maxSize;
/*  21:    */   private static final long serialVersionUID = 0L;
/*  22:    */   
/*  23:    */   private EvictingQueue(int maxSize)
/*  24:    */   {
/*  25: 54 */     Preconditions.checkArgument(maxSize >= 0, "maxSize (%s) must >= 0", new Object[] { Integer.valueOf(maxSize) });
/*  26: 55 */     this.delegate = new ArrayDeque(maxSize);
/*  27: 56 */     this.maxSize = maxSize;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <E> EvictingQueue<E> create(int maxSize)
/*  31:    */   {
/*  32: 66 */     return new EvictingQueue(maxSize);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public int remainingCapacity()
/*  36:    */   {
/*  37: 76 */     return this.maxSize - size();
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected Queue<E> delegate()
/*  41:    */   {
/*  42: 80 */     return this.delegate;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean offer(E e)
/*  46:    */   {
/*  47: 90 */     return add(e);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean add(E e)
/*  51:    */   {
/*  52:100 */     Preconditions.checkNotNull(e);
/*  53:101 */     if (this.maxSize == 0) {
/*  54:102 */       return true;
/*  55:    */     }
/*  56:104 */     if (size() == this.maxSize) {
/*  57:105 */       this.delegate.remove();
/*  58:    */     }
/*  59:107 */     this.delegate.add(e);
/*  60:108 */     return true;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean addAll(Collection<? extends E> collection)
/*  64:    */   {
/*  65:112 */     return standardAddAll(collection);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean contains(Object object)
/*  69:    */   {
/*  70:117 */     return delegate().contains(Preconditions.checkNotNull(object));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean remove(Object object)
/*  74:    */   {
/*  75:122 */     return delegate().remove(Preconditions.checkNotNull(object));
/*  76:    */   }
/*  77:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EvictingQueue
 * JD-Core Version:    0.7.0.1
 */
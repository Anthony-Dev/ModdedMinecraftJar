/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Comparator;
/*   5:    */ import java.util.NavigableSet;
/*   6:    */ 
/*   7:    */ @GwtCompatible(emulated=true)
/*   8:    */ final class UnmodifiableSortedMultiset<E>
/*   9:    */   extends Multisets.UnmodifiableMultiset<E>
/*  10:    */   implements SortedMultiset<E>
/*  11:    */ {
/*  12:    */   private transient UnmodifiableSortedMultiset<E> descendingMultiset;
/*  13:    */   private static final long serialVersionUID = 0L;
/*  14:    */   
/*  15:    */   UnmodifiableSortedMultiset(SortedMultiset<E> delegate)
/*  16:    */   {
/*  17: 36 */     super(delegate);
/*  18:    */   }
/*  19:    */   
/*  20:    */   protected SortedMultiset<E> delegate()
/*  21:    */   {
/*  22: 41 */     return (SortedMultiset)super.delegate();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Comparator<? super E> comparator()
/*  26:    */   {
/*  27: 46 */     return delegate().comparator();
/*  28:    */   }
/*  29:    */   
/*  30:    */   NavigableSet<E> createElementSet()
/*  31:    */   {
/*  32: 51 */     return Sets.unmodifiableNavigableSet(delegate().elementSet());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public NavigableSet<E> elementSet()
/*  36:    */   {
/*  37: 56 */     return (NavigableSet)super.elementSet();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public SortedMultiset<E> descendingMultiset()
/*  41:    */   {
/*  42: 63 */     UnmodifiableSortedMultiset<E> result = this.descendingMultiset;
/*  43: 64 */     if (result == null)
/*  44:    */     {
/*  45: 65 */       result = new UnmodifiableSortedMultiset(delegate().descendingMultiset());
/*  46:    */       
/*  47: 67 */       result.descendingMultiset = this;
/*  48: 68 */       return this.descendingMultiset = result;
/*  49:    */     }
/*  50: 70 */     return result;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Multiset.Entry<E> firstEntry()
/*  54:    */   {
/*  55: 75 */     return delegate().firstEntry();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Multiset.Entry<E> lastEntry()
/*  59:    */   {
/*  60: 80 */     return delegate().lastEntry();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Multiset.Entry<E> pollFirstEntry()
/*  64:    */   {
/*  65: 85 */     throw new UnsupportedOperationException();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Multiset.Entry<E> pollLastEntry()
/*  69:    */   {
/*  70: 90 */     throw new UnsupportedOperationException();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public SortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/*  74:    */   {
/*  75: 95 */     return Multisets.unmodifiableSortedMultiset(delegate().headMultiset(upperBound, boundType));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public SortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/*  79:    */   {
/*  80:103 */     return Multisets.unmodifiableSortedMultiset(delegate().subMultiset(lowerBound, lowerBoundType, upperBound, upperBoundType));
/*  81:    */   }
/*  82:    */   
/*  83:    */   public SortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/*  84:    */   {
/*  85:109 */     return Multisets.unmodifiableSortedMultiset(delegate().tailMultiset(lowerBound, boundType));
/*  86:    */   }
/*  87:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.UnmodifiableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */
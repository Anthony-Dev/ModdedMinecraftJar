/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ public class HashBasedTable<R, C, V>
/*  12:    */   extends StandardTable<R, C, V>
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 0L;
/*  15:    */   
/*  16:    */   private static class Factory<C, V>
/*  17:    */     implements Supplier<Map<C, V>>, Serializable
/*  18:    */   {
/*  19:    */     final int expectedSize;
/*  20:    */     private static final long serialVersionUID = 0L;
/*  21:    */     
/*  22:    */     Factory(int expectedSize)
/*  23:    */     {
/*  24: 61 */       this.expectedSize = expectedSize;
/*  25:    */     }
/*  26:    */     
/*  27:    */     public Map<C, V> get()
/*  28:    */     {
/*  29: 65 */       return Maps.newHashMapWithExpectedSize(this.expectedSize);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <R, C, V> HashBasedTable<R, C, V> create()
/*  34:    */   {
/*  35: 74 */     return new HashBasedTable(new HashMap(), new Factory(0));
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <R, C, V> HashBasedTable<R, C, V> create(int expectedRows, int expectedCellsPerRow)
/*  39:    */   {
/*  40: 89 */     CollectPreconditions.checkNonnegative(expectedCellsPerRow, "expectedCellsPerRow");
/*  41: 90 */     Map<R, Map<C, V>> backingMap = Maps.newHashMapWithExpectedSize(expectedRows);
/*  42:    */     
/*  43: 92 */     return new HashBasedTable(backingMap, new Factory(expectedCellsPerRow));
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <R, C, V> HashBasedTable<R, C, V> create(Table<? extends R, ? extends C, ? extends V> table)
/*  47:    */   {
/*  48:106 */     HashBasedTable<R, C, V> result = create();
/*  49:107 */     result.putAll(table);
/*  50:108 */     return result;
/*  51:    */   }
/*  52:    */   
/*  53:    */   HashBasedTable(Map<R, Map<C, V>> backingMap, Factory<C, V> factory)
/*  54:    */   {
/*  55:112 */     super(backingMap, factory);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*  59:    */   {
/*  60:119 */     return super.contains(rowKey, columnKey);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean containsColumn(@Nullable Object columnKey)
/*  64:    */   {
/*  65:123 */     return super.containsColumn(columnKey);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean containsRow(@Nullable Object rowKey)
/*  69:    */   {
/*  70:127 */     return super.containsRow(rowKey);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean containsValue(@Nullable Object value)
/*  74:    */   {
/*  75:131 */     return super.containsValue(value);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/*  79:    */   {
/*  80:135 */     return super.get(rowKey, columnKey);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean equals(@Nullable Object obj)
/*  84:    */   {
/*  85:139 */     return super.equals(obj);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/*  89:    */   {
/*  90:144 */     return super.remove(rowKey, columnKey);
/*  91:    */   }
/*  92:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.HashBasedTable
 * JD-Core Version:    0.7.0.1
 */
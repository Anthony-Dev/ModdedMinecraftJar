/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableMultiset<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements Multiset<E>
/*  18:    */ {
/*  19: 55 */   private static final ImmutableMultiset<Object> EMPTY = new RegularImmutableMultiset(ImmutableMap.of(), 0);
/*  20:    */   private transient ImmutableSet<Multiset.Entry<E>> entrySet;
/*  21:    */   
/*  22:    */   public static <E> ImmutableMultiset<E> of()
/*  23:    */   {
/*  24: 63 */     return EMPTY;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <E> ImmutableMultiset<E> of(E element)
/*  28:    */   {
/*  29: 74 */     return copyOfInternal(new Object[] { element });
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2)
/*  33:    */   {
/*  34: 85 */     return copyOfInternal(new Object[] { e1, e2 });
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3)
/*  38:    */   {
/*  39: 96 */     return copyOfInternal(new Object[] { e1, e2, e3 });
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4)
/*  43:    */   {
/*  44:107 */     return copyOfInternal(new Object[] { e1, e2, e3, e4 });
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5)
/*  48:    */   {
/*  49:118 */     return copyOfInternal(new Object[] { e1, e2, e3, e4, e5 });
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others)
/*  53:    */   {
/*  54:130 */     return new Builder().add(e1).add(e2).add(e3).add(e4).add(e5).add(e6).add(others).build();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static <E> ImmutableMultiset<E> copyOf(E[] elements)
/*  58:    */   {
/*  59:152 */     return copyOf(Arrays.asList(elements));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static <E> ImmutableMultiset<E> copyOf(Iterable<? extends E> elements)
/*  63:    */   {
/*  64:174 */     if ((elements instanceof ImmutableMultiset))
/*  65:    */     {
/*  66:176 */       ImmutableMultiset<E> result = (ImmutableMultiset)elements;
/*  67:177 */       if (!result.isPartialView()) {
/*  68:178 */         return result;
/*  69:    */       }
/*  70:    */     }
/*  71:182 */     Multiset<? extends E> multiset = (elements instanceof Multiset) ? Multisets.cast(elements) : LinkedHashMultiset.create(elements);
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75:186 */     return copyOfInternal(multiset);
/*  76:    */   }
/*  77:    */   
/*  78:    */   private static <E> ImmutableMultiset<E> copyOfInternal(E... elements)
/*  79:    */   {
/*  80:190 */     return copyOf(Arrays.asList(elements));
/*  81:    */   }
/*  82:    */   
/*  83:    */   private static <E> ImmutableMultiset<E> copyOfInternal(Multiset<? extends E> multiset)
/*  84:    */   {
/*  85:195 */     return copyFromEntries(multiset.entrySet());
/*  86:    */   }
/*  87:    */   
/*  88:    */   static <E> ImmutableMultiset<E> copyFromEntries(Collection<? extends Multiset.Entry<? extends E>> entries)
/*  89:    */   {
/*  90:200 */     long size = 0L;
/*  91:201 */     ImmutableMap.Builder<E, Integer> builder = ImmutableMap.builder();
/*  92:202 */     for (Multiset.Entry<? extends E> entry : entries)
/*  93:    */     {
/*  94:203 */       int count = entry.getCount();
/*  95:204 */       if (count > 0)
/*  96:    */       {
/*  97:207 */         builder.put(entry.getElement(), Integer.valueOf(count));
/*  98:208 */         size += count;
/*  99:    */       }
/* 100:    */     }
/* 101:212 */     if (size == 0L) {
/* 102:213 */       return of();
/* 103:    */     }
/* 104:215 */     return new RegularImmutableMultiset(builder.build(), Ints.saturatedCast(size));
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static <E> ImmutableMultiset<E> copyOf(Iterator<? extends E> elements)
/* 108:    */   {
/* 109:231 */     Multiset<E> multiset = LinkedHashMultiset.create();
/* 110:232 */     Iterators.addAll(multiset, elements);
/* 111:233 */     return copyOfInternal(multiset);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public UnmodifiableIterator<E> iterator()
/* 115:    */   {
/* 116:239 */     final Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/* 117:240 */     new UnmodifiableIterator()
/* 118:    */     {
/* 119:    */       int remaining;
/* 120:    */       E element;
/* 121:    */       
/* 122:    */       public boolean hasNext()
/* 123:    */       {
/* 124:246 */         return (this.remaining > 0) || (entryIterator.hasNext());
/* 125:    */       }
/* 126:    */       
/* 127:    */       public E next()
/* 128:    */       {
/* 129:251 */         if (this.remaining <= 0)
/* 130:    */         {
/* 131:252 */           Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/* 132:253 */           this.element = entry.getElement();
/* 133:254 */           this.remaining = entry.getCount();
/* 134:    */         }
/* 135:256 */         this.remaining -= 1;
/* 136:257 */         return this.element;
/* 137:    */       }
/* 138:    */     };
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean contains(@Nullable Object object)
/* 142:    */   {
/* 143:264 */     return count(object) > 0;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean containsAll(Collection<?> targets)
/* 147:    */   {
/* 148:269 */     return elementSet().containsAll(targets);
/* 149:    */   }
/* 150:    */   
/* 151:    */   @Deprecated
/* 152:    */   public final int add(E element, int occurrences)
/* 153:    */   {
/* 154:281 */     throw new UnsupportedOperationException();
/* 155:    */   }
/* 156:    */   
/* 157:    */   @Deprecated
/* 158:    */   public final int remove(Object element, int occurrences)
/* 159:    */   {
/* 160:293 */     throw new UnsupportedOperationException();
/* 161:    */   }
/* 162:    */   
/* 163:    */   @Deprecated
/* 164:    */   public final int setCount(E element, int count)
/* 165:    */   {
/* 166:305 */     throw new UnsupportedOperationException();
/* 167:    */   }
/* 168:    */   
/* 169:    */   @Deprecated
/* 170:    */   public final boolean setCount(E element, int oldCount, int newCount)
/* 171:    */   {
/* 172:317 */     throw new UnsupportedOperationException();
/* 173:    */   }
/* 174:    */   
/* 175:    */   @GwtIncompatible("not present in emulated superclass")
/* 176:    */   int copyIntoArray(Object[] dst, int offset)
/* 177:    */   {
/* 178:323 */     for (Multiset.Entry<E> entry : entrySet())
/* 179:    */     {
/* 180:324 */       Arrays.fill(dst, offset, offset + entry.getCount(), entry.getElement());
/* 181:325 */       offset += entry.getCount();
/* 182:    */     }
/* 183:327 */     return offset;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public boolean equals(@Nullable Object object)
/* 187:    */   {
/* 188:331 */     return Multisets.equalsImpl(this, object);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public int hashCode()
/* 192:    */   {
/* 193:335 */     return Sets.hashCodeImpl(entrySet());
/* 194:    */   }
/* 195:    */   
/* 196:    */   public String toString()
/* 197:    */   {
/* 198:339 */     return entrySet().toString();
/* 199:    */   }
/* 200:    */   
/* 201:    */   public ImmutableSet<Multiset.Entry<E>> entrySet()
/* 202:    */   {
/* 203:346 */     ImmutableSet<Multiset.Entry<E>> es = this.entrySet;
/* 204:347 */     return es == null ? (this.entrySet = createEntrySet()) : es;
/* 205:    */   }
/* 206:    */   
/* 207:    */   private final ImmutableSet<Multiset.Entry<E>> createEntrySet()
/* 208:    */   {
/* 209:351 */     return isEmpty() ? ImmutableSet.of() : new EntrySet(null);
/* 210:    */   }
/* 211:    */   
/* 212:    */   abstract Multiset.Entry<E> getEntry(int paramInt);
/* 213:    */   
/* 214:    */   private final class EntrySet
/* 215:    */     extends ImmutableSet<Multiset.Entry<E>>
/* 216:    */   {
/* 217:    */     private static final long serialVersionUID = 0L;
/* 218:    */     
/* 219:    */     private EntrySet() {}
/* 220:    */     
/* 221:    */     boolean isPartialView()
/* 222:    */     {
/* 223:359 */       return ImmutableMultiset.this.isPartialView();
/* 224:    */     }
/* 225:    */     
/* 226:    */     public UnmodifiableIterator<Multiset.Entry<E>> iterator()
/* 227:    */     {
/* 228:364 */       return asList().iterator();
/* 229:    */     }
/* 230:    */     
/* 231:    */     ImmutableList<Multiset.Entry<E>> createAsList()
/* 232:    */     {
/* 233:369 */       new ImmutableAsList()
/* 234:    */       {
/* 235:    */         public Multiset.Entry<E> get(int index)
/* 236:    */         {
/* 237:372 */           return ImmutableMultiset.this.getEntry(index);
/* 238:    */         }
/* 239:    */         
/* 240:    */         ImmutableCollection<Multiset.Entry<E>> delegateCollection()
/* 241:    */         {
/* 242:377 */           return ImmutableMultiset.EntrySet.this;
/* 243:    */         }
/* 244:    */       };
/* 245:    */     }
/* 246:    */     
/* 247:    */     public int size()
/* 248:    */     {
/* 249:384 */       return ImmutableMultiset.this.elementSet().size();
/* 250:    */     }
/* 251:    */     
/* 252:    */     public boolean contains(Object o)
/* 253:    */     {
/* 254:389 */       if ((o instanceof Multiset.Entry))
/* 255:    */       {
/* 256:390 */         Multiset.Entry<?> entry = (Multiset.Entry)o;
/* 257:391 */         if (entry.getCount() <= 0) {
/* 258:392 */           return false;
/* 259:    */         }
/* 260:394 */         int count = ImmutableMultiset.this.count(entry.getElement());
/* 261:395 */         return count == entry.getCount();
/* 262:    */       }
/* 263:397 */       return false;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public int hashCode()
/* 267:    */     {
/* 268:402 */       return ImmutableMultiset.this.hashCode();
/* 269:    */     }
/* 270:    */     
/* 271:    */     Object writeReplace()
/* 272:    */     {
/* 273:409 */       return new ImmutableMultiset.EntrySetSerializedForm(ImmutableMultiset.this);
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   static class EntrySetSerializedForm<E>
/* 278:    */     implements Serializable
/* 279:    */   {
/* 280:    */     final ImmutableMultiset<E> multiset;
/* 281:    */     
/* 282:    */     EntrySetSerializedForm(ImmutableMultiset<E> multiset)
/* 283:    */     {
/* 284:419 */       this.multiset = multiset;
/* 285:    */     }
/* 286:    */     
/* 287:    */     Object readResolve()
/* 288:    */     {
/* 289:423 */       return this.multiset.entrySet();
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   private static class SerializedForm
/* 294:    */     implements Serializable
/* 295:    */   {
/* 296:    */     final Object[] elements;
/* 297:    */     final int[] counts;
/* 298:    */     private static final long serialVersionUID = 0L;
/* 299:    */     
/* 300:    */     SerializedForm(Multiset<?> multiset)
/* 301:    */     {
/* 302:432 */       int distinct = multiset.entrySet().size();
/* 303:433 */       this.elements = new Object[distinct];
/* 304:434 */       this.counts = new int[distinct];
/* 305:435 */       int i = 0;
/* 306:436 */       for (Multiset.Entry<?> entry : multiset.entrySet())
/* 307:    */       {
/* 308:437 */         this.elements[i] = entry.getElement();
/* 309:438 */         this.counts[i] = entry.getCount();
/* 310:439 */         i++;
/* 311:    */       }
/* 312:    */     }
/* 313:    */     
/* 314:    */     Object readResolve()
/* 315:    */     {
/* 316:444 */       LinkedHashMultiset<Object> multiset = LinkedHashMultiset.create(this.elements.length);
/* 317:446 */       for (int i = 0; i < this.elements.length; i++) {
/* 318:447 */         multiset.add(this.elements[i], this.counts[i]);
/* 319:    */       }
/* 320:449 */       return ImmutableMultiset.copyOf(multiset);
/* 321:    */     }
/* 322:    */   }
/* 323:    */   
/* 324:    */   Object writeReplace()
/* 325:    */   {
/* 326:458 */     return new SerializedForm(this);
/* 327:    */   }
/* 328:    */   
/* 329:    */   public static <E> Builder<E> builder()
/* 330:    */   {
/* 331:466 */     return new Builder();
/* 332:    */   }
/* 333:    */   
/* 334:    */   public static class Builder<E>
/* 335:    */     extends ImmutableCollection.Builder<E>
/* 336:    */   {
/* 337:    */     final Multiset<E> contents;
/* 338:    */     
/* 339:    */     public Builder()
/* 340:    */     {
/* 341:495 */       this(LinkedHashMultiset.create());
/* 342:    */     }
/* 343:    */     
/* 344:    */     Builder(Multiset<E> contents)
/* 345:    */     {
/* 346:499 */       this.contents = contents;
/* 347:    */     }
/* 348:    */     
/* 349:    */     public Builder<E> add(E element)
/* 350:    */     {
/* 351:510 */       this.contents.add(Preconditions.checkNotNull(element));
/* 352:511 */       return this;
/* 353:    */     }
/* 354:    */     
/* 355:    */     public Builder<E> addCopies(E element, int occurrences)
/* 356:    */     {
/* 357:528 */       this.contents.add(Preconditions.checkNotNull(element), occurrences);
/* 358:529 */       return this;
/* 359:    */     }
/* 360:    */     
/* 361:    */     public Builder<E> setCount(E element, int count)
/* 362:    */     {
/* 363:543 */       this.contents.setCount(Preconditions.checkNotNull(element), count);
/* 364:544 */       return this;
/* 365:    */     }
/* 366:    */     
/* 367:    */     public Builder<E> add(E... elements)
/* 368:    */     {
/* 369:556 */       super.add(elements);
/* 370:557 */       return this;
/* 371:    */     }
/* 372:    */     
/* 373:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 374:    */     {
/* 375:570 */       if ((elements instanceof Multiset))
/* 376:    */       {
/* 377:571 */         Multiset<? extends E> multiset = Multisets.cast(elements);
/* 378:572 */         for (Multiset.Entry<? extends E> entry : multiset.entrySet()) {
/* 379:573 */           addCopies(entry.getElement(), entry.getCount());
/* 380:    */         }
/* 381:    */       }
/* 382:    */       else
/* 383:    */       {
/* 384:576 */         super.addAll(elements);
/* 385:    */       }
/* 386:578 */       return this;
/* 387:    */     }
/* 388:    */     
/* 389:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 390:    */     {
/* 391:590 */       super.addAll(elements);
/* 392:591 */       return this;
/* 393:    */     }
/* 394:    */     
/* 395:    */     public ImmutableMultiset<E> build()
/* 396:    */     {
/* 397:599 */       return ImmutableMultiset.copyOf(this.contents);
/* 398:    */     }
/* 399:    */   }
/* 400:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMultiset
 * JD-Core Version:    0.7.0.1
 */
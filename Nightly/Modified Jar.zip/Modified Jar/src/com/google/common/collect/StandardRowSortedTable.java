/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Supplier;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.SortedMap;
/*   9:    */ import java.util.SortedSet;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ class StandardRowSortedTable<R, C, V>
/*  13:    */   extends StandardTable<R, C, V>
/*  14:    */   implements RowSortedTable<R, C, V>
/*  15:    */ {
/*  16:    */   private static final long serialVersionUID = 0L;
/*  17:    */   
/*  18:    */   StandardRowSortedTable(SortedMap<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*  19:    */   {
/*  20: 59 */     super(backingMap, factory);
/*  21:    */   }
/*  22:    */   
/*  23:    */   private SortedMap<R, Map<C, V>> sortedBackingMap()
/*  24:    */   {
/*  25: 63 */     return (SortedMap)this.backingMap;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SortedSet<R> rowKeySet()
/*  29:    */   {
/*  30: 73 */     return (SortedSet)rowMap().keySet();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public SortedMap<R, Map<C, V>> rowMap()
/*  34:    */   {
/*  35: 83 */     return (SortedMap)super.rowMap();
/*  36:    */   }
/*  37:    */   
/*  38:    */   SortedMap<R, Map<C, V>> createRowMap()
/*  39:    */   {
/*  40: 88 */     return new RowSortedMap(null);
/*  41:    */   }
/*  42:    */   
/*  43:    */   private class RowSortedMap
/*  44:    */     extends StandardTable<R, C, V>.RowMap
/*  45:    */     implements SortedMap<R, Map<C, V>>
/*  46:    */   {
/*  47:    */     private RowSortedMap()
/*  48:    */     {
/*  49: 91 */       super();
/*  50:    */     }
/*  51:    */     
/*  52:    */     public SortedSet<R> keySet()
/*  53:    */     {
/*  54: 94 */       return (SortedSet)super.keySet();
/*  55:    */     }
/*  56:    */     
/*  57:    */     SortedSet<R> createKeySet()
/*  58:    */     {
/*  59: 99 */       return new Maps.SortedKeySet(this);
/*  60:    */     }
/*  61:    */     
/*  62:    */     public Comparator<? super R> comparator()
/*  63:    */     {
/*  64:104 */       return StandardRowSortedTable.this.sortedBackingMap().comparator();
/*  65:    */     }
/*  66:    */     
/*  67:    */     public R firstKey()
/*  68:    */     {
/*  69:109 */       return StandardRowSortedTable.this.sortedBackingMap().firstKey();
/*  70:    */     }
/*  71:    */     
/*  72:    */     public R lastKey()
/*  73:    */     {
/*  74:114 */       return StandardRowSortedTable.this.sortedBackingMap().lastKey();
/*  75:    */     }
/*  76:    */     
/*  77:    */     public SortedMap<R, Map<C, V>> headMap(R toKey)
/*  78:    */     {
/*  79:119 */       Preconditions.checkNotNull(toKey);
/*  80:120 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().headMap(toKey), StandardRowSortedTable.this.factory).rowMap();
/*  81:    */     }
/*  82:    */     
/*  83:    */     public SortedMap<R, Map<C, V>> subMap(R fromKey, R toKey)
/*  84:    */     {
/*  85:126 */       Preconditions.checkNotNull(fromKey);
/*  86:127 */       Preconditions.checkNotNull(toKey);
/*  87:128 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().subMap(fromKey, toKey), StandardRowSortedTable.this.factory).rowMap();
/*  88:    */     }
/*  89:    */     
/*  90:    */     public SortedMap<R, Map<C, V>> tailMap(R fromKey)
/*  91:    */     {
/*  92:134 */       Preconditions.checkNotNull(fromKey);
/*  93:135 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().tailMap(fromKey), StandardRowSortedTable.this.factory).rowMap();
/*  94:    */     }
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.StandardRowSortedTable
 * JD-Core Version:    0.7.0.1
 */
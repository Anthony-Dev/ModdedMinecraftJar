/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ final class GeneralRange<T>
/*  12:    */   implements Serializable
/*  13:    */ {
/*  14:    */   private final Comparator<? super T> comparator;
/*  15:    */   private final boolean hasLowerBound;
/*  16:    */   @Nullable
/*  17:    */   private final T lowerEndpoint;
/*  18:    */   private final BoundType lowerBoundType;
/*  19:    */   private final boolean hasUpperBound;
/*  20:    */   @Nullable
/*  21:    */   private final T upperEndpoint;
/*  22:    */   private final BoundType upperBoundType;
/*  23:    */   private transient GeneralRange<T> reverse;
/*  24:    */   
/*  25:    */   static <T extends Comparable> GeneralRange<T> from(Range<T> range)
/*  26:    */   {
/*  27: 46 */     T lowerEndpoint = range.hasLowerBound() ? range.lowerEndpoint() : null;
/*  28: 47 */     BoundType lowerBoundType = range.hasLowerBound() ? range.lowerBoundType() : BoundType.OPEN;
/*  29:    */     
/*  30:    */ 
/*  31: 50 */     T upperEndpoint = range.hasUpperBound() ? range.upperEndpoint() : null;
/*  32: 51 */     BoundType upperBoundType = range.hasUpperBound() ? range.upperBoundType() : BoundType.OPEN;
/*  33: 52 */     return new GeneralRange(Ordering.natural(), range.hasLowerBound(), lowerEndpoint, lowerBoundType, range.hasUpperBound(), upperEndpoint, upperBoundType);
/*  34:    */   }
/*  35:    */   
/*  36:    */   static <T> GeneralRange<T> all(Comparator<? super T> comparator)
/*  37:    */   {
/*  38: 60 */     return new GeneralRange(comparator, false, null, BoundType.OPEN, false, null, BoundType.OPEN);
/*  39:    */   }
/*  40:    */   
/*  41:    */   static <T> GeneralRange<T> downTo(Comparator<? super T> comparator, @Nullable T endpoint, BoundType boundType)
/*  42:    */   {
/*  43: 69 */     return new GeneralRange(comparator, true, endpoint, boundType, false, null, BoundType.OPEN);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static <T> GeneralRange<T> upTo(Comparator<? super T> comparator, @Nullable T endpoint, BoundType boundType)
/*  47:    */   {
/*  48: 78 */     return new GeneralRange(comparator, false, null, BoundType.OPEN, true, endpoint, boundType);
/*  49:    */   }
/*  50:    */   
/*  51:    */   static <T> GeneralRange<T> range(Comparator<? super T> comparator, @Nullable T lower, BoundType lowerType, @Nullable T upper, BoundType upperType)
/*  52:    */   {
/*  53: 87 */     return new GeneralRange(comparator, true, lower, lowerType, true, upper, upperType);
/*  54:    */   }
/*  55:    */   
/*  56:    */   private GeneralRange(Comparator<? super T> comparator, boolean hasLowerBound, @Nullable T lowerEndpoint, BoundType lowerBoundType, boolean hasUpperBound, @Nullable T upperEndpoint, BoundType upperBoundType)
/*  57:    */   {
/*  58:103 */     this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*  59:104 */     this.hasLowerBound = hasLowerBound;
/*  60:105 */     this.hasUpperBound = hasUpperBound;
/*  61:106 */     this.lowerEndpoint = lowerEndpoint;
/*  62:107 */     this.lowerBoundType = ((BoundType)Preconditions.checkNotNull(lowerBoundType));
/*  63:108 */     this.upperEndpoint = upperEndpoint;
/*  64:109 */     this.upperBoundType = ((BoundType)Preconditions.checkNotNull(upperBoundType));
/*  65:111 */     if (hasLowerBound) {
/*  66:112 */       comparator.compare(lowerEndpoint, lowerEndpoint);
/*  67:    */     }
/*  68:114 */     if (hasUpperBound) {
/*  69:115 */       comparator.compare(upperEndpoint, upperEndpoint);
/*  70:    */     }
/*  71:117 */     if ((hasLowerBound) && (hasUpperBound))
/*  72:    */     {
/*  73:118 */       int cmp = comparator.compare(lowerEndpoint, upperEndpoint);
/*  74:    */       
/*  75:120 */       Preconditions.checkArgument(cmp <= 0, "lowerEndpoint (%s) > upperEndpoint (%s)", new Object[] { lowerEndpoint, upperEndpoint });
/*  76:122 */       if (cmp == 0) {
/*  77:123 */         Preconditions.checkArgument((lowerBoundType != BoundType.OPEN ? 1 : 0) | (upperBoundType != BoundType.OPEN ? 1 : 0));
/*  78:    */       }
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   Comparator<? super T> comparator()
/*  83:    */   {
/*  84:129 */     return this.comparator;
/*  85:    */   }
/*  86:    */   
/*  87:    */   boolean hasLowerBound()
/*  88:    */   {
/*  89:133 */     return this.hasLowerBound;
/*  90:    */   }
/*  91:    */   
/*  92:    */   boolean hasUpperBound()
/*  93:    */   {
/*  94:137 */     return this.hasUpperBound;
/*  95:    */   }
/*  96:    */   
/*  97:    */   boolean isEmpty()
/*  98:    */   {
/*  99:141 */     return ((hasUpperBound()) && (tooLow(getUpperEndpoint()))) || ((hasLowerBound()) && (tooHigh(getLowerEndpoint())));
/* 100:    */   }
/* 101:    */   
/* 102:    */   boolean tooLow(@Nullable T t)
/* 103:    */   {
/* 104:146 */     if (!hasLowerBound()) {
/* 105:147 */       return false;
/* 106:    */     }
/* 107:149 */     T lbound = getLowerEndpoint();
/* 108:150 */     int cmp = this.comparator.compare(t, lbound);
/* 109:151 */     return (cmp < 0 ? 1 : 0) | (cmp == 0 ? 1 : 0) & (getLowerBoundType() == BoundType.OPEN ? 1 : 0);
/* 110:    */   }
/* 111:    */   
/* 112:    */   boolean tooHigh(@Nullable T t)
/* 113:    */   {
/* 114:155 */     if (!hasUpperBound()) {
/* 115:156 */       return false;
/* 116:    */     }
/* 117:158 */     T ubound = getUpperEndpoint();
/* 118:159 */     int cmp = this.comparator.compare(t, ubound);
/* 119:160 */     return (cmp > 0 ? 1 : 0) | (cmp == 0 ? 1 : 0) & (getUpperBoundType() == BoundType.OPEN ? 1 : 0);
/* 120:    */   }
/* 121:    */   
/* 122:    */   boolean contains(@Nullable T t)
/* 123:    */   {
/* 124:164 */     return (!tooLow(t)) && (!tooHigh(t));
/* 125:    */   }
/* 126:    */   
/* 127:    */   GeneralRange<T> intersect(GeneralRange<T> other)
/* 128:    */   {
/* 129:171 */     Preconditions.checkNotNull(other);
/* 130:172 */     Preconditions.checkArgument(this.comparator.equals(other.comparator));
/* 131:    */     
/* 132:174 */     boolean hasLowBound = this.hasLowerBound;
/* 133:    */     
/* 134:176 */     T lowEnd = getLowerEndpoint();
/* 135:177 */     BoundType lowType = getLowerBoundType();
/* 136:178 */     if (!hasLowerBound())
/* 137:    */     {
/* 138:179 */       hasLowBound = other.hasLowerBound;
/* 139:180 */       lowEnd = other.getLowerEndpoint();
/* 140:181 */       lowType = other.getLowerBoundType();
/* 141:    */     }
/* 142:182 */     else if (other.hasLowerBound())
/* 143:    */     {
/* 144:183 */       int cmp = this.comparator.compare(getLowerEndpoint(), other.getLowerEndpoint());
/* 145:184 */       if ((cmp < 0) || ((cmp == 0) && (other.getLowerBoundType() == BoundType.OPEN)))
/* 146:    */       {
/* 147:185 */         lowEnd = other.getLowerEndpoint();
/* 148:186 */         lowType = other.getLowerBoundType();
/* 149:    */       }
/* 150:    */     }
/* 151:190 */     boolean hasUpBound = this.hasUpperBound;
/* 152:    */     
/* 153:192 */     T upEnd = getUpperEndpoint();
/* 154:193 */     BoundType upType = getUpperBoundType();
/* 155:194 */     if (!hasUpperBound())
/* 156:    */     {
/* 157:195 */       hasUpBound = other.hasUpperBound;
/* 158:196 */       upEnd = other.getUpperEndpoint();
/* 159:197 */       upType = other.getUpperBoundType();
/* 160:    */     }
/* 161:198 */     else if (other.hasUpperBound())
/* 162:    */     {
/* 163:199 */       int cmp = this.comparator.compare(getUpperEndpoint(), other.getUpperEndpoint());
/* 164:200 */       if ((cmp > 0) || ((cmp == 0) && (other.getUpperBoundType() == BoundType.OPEN)))
/* 165:    */       {
/* 166:201 */         upEnd = other.getUpperEndpoint();
/* 167:202 */         upType = other.getUpperBoundType();
/* 168:    */       }
/* 169:    */     }
/* 170:206 */     if ((hasLowBound) && (hasUpBound))
/* 171:    */     {
/* 172:207 */       int cmp = this.comparator.compare(lowEnd, upEnd);
/* 173:208 */       if ((cmp > 0) || ((cmp == 0) && (lowType == BoundType.OPEN) && (upType == BoundType.OPEN)))
/* 174:    */       {
/* 175:210 */         lowEnd = upEnd;
/* 176:211 */         lowType = BoundType.OPEN;
/* 177:212 */         upType = BoundType.CLOSED;
/* 178:    */       }
/* 179:    */     }
/* 180:216 */     return new GeneralRange(this.comparator, hasLowBound, lowEnd, lowType, hasUpBound, upEnd, upType);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean equals(@Nullable Object obj)
/* 184:    */   {
/* 185:221 */     if ((obj instanceof GeneralRange))
/* 186:    */     {
/* 187:222 */       GeneralRange<?> r = (GeneralRange)obj;
/* 188:223 */       return (this.comparator.equals(r.comparator)) && (this.hasLowerBound == r.hasLowerBound) && (this.hasUpperBound == r.hasUpperBound) && (getLowerBoundType().equals(r.getLowerBoundType())) && (getUpperBoundType().equals(r.getUpperBoundType())) && (Objects.equal(getLowerEndpoint(), r.getLowerEndpoint())) && (Objects.equal(getUpperEndpoint(), r.getUpperEndpoint()));
/* 189:    */     }
/* 190:229 */     return false;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public int hashCode()
/* 194:    */   {
/* 195:234 */     return Objects.hashCode(new Object[] { this.comparator, getLowerEndpoint(), getLowerBoundType(), getUpperEndpoint(), getUpperBoundType() });
/* 196:    */   }
/* 197:    */   
/* 198:    */   GeneralRange<T> reverse()
/* 199:    */   {
/* 200:244 */     GeneralRange<T> result = this.reverse;
/* 201:245 */     if (result == null)
/* 202:    */     {
/* 203:246 */       result = new GeneralRange(Ordering.from(this.comparator).reverse(), this.hasUpperBound, getUpperEndpoint(), getUpperBoundType(), this.hasLowerBound, getLowerEndpoint(), getLowerBoundType());
/* 204:    */       
/* 205:    */ 
/* 206:249 */       result.reverse = this;
/* 207:250 */       return this.reverse = result;
/* 208:    */     }
/* 209:252 */     return result;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public String toString()
/* 213:    */   {
/* 214:257 */     return this.comparator + ":" + (this.lowerBoundType == BoundType.CLOSED ? '[' : '(') + (this.hasLowerBound ? this.lowerEndpoint : "-∞") + ',' + (this.hasUpperBound ? this.upperEndpoint : "∞") + (this.upperBoundType == BoundType.CLOSED ? ']' : ')');
/* 215:    */   }
/* 216:    */   
/* 217:    */   T getLowerEndpoint()
/* 218:    */   {
/* 219:269 */     return this.lowerEndpoint;
/* 220:    */   }
/* 221:    */   
/* 222:    */   BoundType getLowerBoundType()
/* 223:    */   {
/* 224:273 */     return this.lowerBoundType;
/* 225:    */   }
/* 226:    */   
/* 227:    */   T getUpperEndpoint()
/* 228:    */   {
/* 229:277 */     return this.upperEndpoint;
/* 230:    */   }
/* 231:    */   
/* 232:    */   BoundType getUpperBoundType()
/* 233:    */   {
/* 234:281 */     return this.upperBoundType;
/* 235:    */   }
/* 236:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.GeneralRange
 * JD-Core Version:    0.7.0.1
 */
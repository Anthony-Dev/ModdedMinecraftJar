/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.NoSuchElementException;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ public abstract class AbstractSequentialIterator<T>
/*  9:   */   extends UnmodifiableIterator<T>
/* 10:   */ {
/* 11:   */   private T nextOrNull;
/* 12:   */   
/* 13:   */   protected AbstractSequentialIterator(@Nullable T firstOrNull)
/* 14:   */   {
/* 15:53 */     this.nextOrNull = firstOrNull;
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected abstract T computeNext(T paramT);
/* 19:   */   
/* 20:   */   public final boolean hasNext()
/* 21:   */   {
/* 22:66 */     return this.nextOrNull != null;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public final T next()
/* 26:   */   {
/* 27:71 */     if (!hasNext()) {
/* 28:72 */       throw new NoSuchElementException();
/* 29:   */     }
/* 30:   */     try
/* 31:   */     {
/* 32:75 */       return this.nextOrNull;
/* 33:   */     }
/* 34:   */     finally
/* 35:   */     {
/* 36:77 */       this.nextOrNull = computeNext(this.nextOrNull);
/* 37:   */     }
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractSequentialIterator
 * JD-Core Version:    0.7.0.1
 */
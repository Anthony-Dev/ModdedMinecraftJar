/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ class RegularImmutableBiMap<K, V>
/*  10:    */   extends ImmutableBiMap<K, V>
/*  11:    */ {
/*  12:    */   static final double MAX_LOAD_FACTOR = 1.2D;
/*  13:    */   private final transient ImmutableMapEntry<K, V>[] keyTable;
/*  14:    */   private final transient ImmutableMapEntry<K, V>[] valueTable;
/*  15:    */   private final transient ImmutableMapEntry<K, V>[] entries;
/*  16:    */   private final transient int mask;
/*  17:    */   private final transient int hashCode;
/*  18:    */   private transient ImmutableBiMap<V, K> inverse;
/*  19:    */   
/*  20:    */   RegularImmutableBiMap(ImmutableMapEntry.TerminalEntry<?, ?>... entriesToAdd)
/*  21:    */   {
/*  22: 46 */     this(entriesToAdd.length, entriesToAdd);
/*  23:    */   }
/*  24:    */   
/*  25:    */   RegularImmutableBiMap(int n, ImmutableMapEntry.TerminalEntry<?, ?>[] entriesToAdd)
/*  26:    */   {
/*  27: 56 */     int tableSize = Hashing.closedTableSize(n, 1.2D);
/*  28: 57 */     this.mask = (tableSize - 1);
/*  29: 58 */     ImmutableMapEntry<K, V>[] keyTable = createEntryArray(tableSize);
/*  30: 59 */     ImmutableMapEntry<K, V>[] valueTable = createEntryArray(tableSize);
/*  31: 60 */     ImmutableMapEntry<K, V>[] entries = createEntryArray(n);
/*  32: 61 */     int hashCode = 0;
/*  33: 63 */     for (int i = 0; i < n; i++)
/*  34:    */     {
/*  35: 65 */       ImmutableMapEntry.TerminalEntry<K, V> entry = entriesToAdd[i];
/*  36: 66 */       K key = entry.getKey();
/*  37: 67 */       V value = entry.getValue();
/*  38:    */       
/*  39: 69 */       int keyHash = key.hashCode();
/*  40: 70 */       int valueHash = value.hashCode();
/*  41: 71 */       int keyBucket = Hashing.smear(keyHash) & this.mask;
/*  42: 72 */       int valueBucket = Hashing.smear(valueHash) & this.mask;
/*  43:    */       
/*  44: 74 */       ImmutableMapEntry<K, V> nextInKeyBucket = keyTable[keyBucket];
/*  45: 75 */       for (ImmutableMapEntry<K, V> keyEntry = nextInKeyBucket; keyEntry != null; keyEntry = keyEntry.getNextInKeyBucket()) {
/*  46: 77 */         checkNoConflict(!key.equals(keyEntry.getKey()), "key", entry, keyEntry);
/*  47:    */       }
/*  48: 79 */       ImmutableMapEntry<K, V> nextInValueBucket = valueTable[valueBucket];
/*  49: 80 */       for (ImmutableMapEntry<K, V> valueEntry = nextInValueBucket; valueEntry != null; valueEntry = valueEntry.getNextInValueBucket()) {
/*  50: 82 */         checkNoConflict(!value.equals(valueEntry.getValue()), "value", entry, valueEntry);
/*  51:    */       }
/*  52: 84 */       ImmutableMapEntry<K, V> newEntry = (nextInKeyBucket == null) && (nextInValueBucket == null) ? entry : new NonTerminalBiMapEntry(entry, nextInKeyBucket, nextInValueBucket);
/*  53:    */       
/*  54:    */ 
/*  55:    */ 
/*  56: 88 */       keyTable[keyBucket] = newEntry;
/*  57: 89 */       valueTable[valueBucket] = newEntry;
/*  58: 90 */       entries[i] = newEntry;
/*  59: 91 */       hashCode += (keyHash ^ valueHash);
/*  60:    */     }
/*  61: 94 */     this.keyTable = keyTable;
/*  62: 95 */     this.valueTable = valueTable;
/*  63: 96 */     this.entries = entries;
/*  64: 97 */     this.hashCode = hashCode;
/*  65:    */   }
/*  66:    */   
/*  67:    */   RegularImmutableBiMap(Map.Entry<?, ?>[] entriesToAdd)
/*  68:    */   {
/*  69:104 */     int n = entriesToAdd.length;
/*  70:105 */     int tableSize = Hashing.closedTableSize(n, 1.2D);
/*  71:106 */     this.mask = (tableSize - 1);
/*  72:107 */     ImmutableMapEntry<K, V>[] keyTable = createEntryArray(tableSize);
/*  73:108 */     ImmutableMapEntry<K, V>[] valueTable = createEntryArray(tableSize);
/*  74:109 */     ImmutableMapEntry<K, V>[] entries = createEntryArray(n);
/*  75:110 */     int hashCode = 0;
/*  76:112 */     for (int i = 0; i < n; i++)
/*  77:    */     {
/*  78:114 */       Map.Entry<K, V> entry = entriesToAdd[i];
/*  79:115 */       K key = entry.getKey();
/*  80:116 */       V value = entry.getValue();
/*  81:117 */       CollectPreconditions.checkEntryNotNull(key, value);
/*  82:118 */       int keyHash = key.hashCode();
/*  83:119 */       int valueHash = value.hashCode();
/*  84:120 */       int keyBucket = Hashing.smear(keyHash) & this.mask;
/*  85:121 */       int valueBucket = Hashing.smear(valueHash) & this.mask;
/*  86:    */       
/*  87:123 */       ImmutableMapEntry<K, V> nextInKeyBucket = keyTable[keyBucket];
/*  88:124 */       for (ImmutableMapEntry<K, V> keyEntry = nextInKeyBucket; keyEntry != null; keyEntry = keyEntry.getNextInKeyBucket()) {
/*  89:126 */         checkNoConflict(!key.equals(keyEntry.getKey()), "key", entry, keyEntry);
/*  90:    */       }
/*  91:128 */       ImmutableMapEntry<K, V> nextInValueBucket = valueTable[valueBucket];
/*  92:129 */       for (ImmutableMapEntry<K, V> valueEntry = nextInValueBucket; valueEntry != null; valueEntry = valueEntry.getNextInValueBucket()) {
/*  93:131 */         checkNoConflict(!value.equals(valueEntry.getValue()), "value", entry, valueEntry);
/*  94:    */       }
/*  95:133 */       ImmutableMapEntry<K, V> newEntry = (nextInKeyBucket == null) && (nextInValueBucket == null) ? new ImmutableMapEntry.TerminalEntry(key, value) : new NonTerminalBiMapEntry(key, value, nextInKeyBucket, nextInValueBucket);
/*  96:    */       
/*  97:    */ 
/*  98:    */ 
/*  99:137 */       keyTable[keyBucket] = newEntry;
/* 100:138 */       valueTable[valueBucket] = newEntry;
/* 101:139 */       entries[i] = newEntry;
/* 102:140 */       hashCode += (keyHash ^ valueHash);
/* 103:    */     }
/* 104:143 */     this.keyTable = keyTable;
/* 105:144 */     this.valueTable = valueTable;
/* 106:145 */     this.entries = entries;
/* 107:146 */     this.hashCode = hashCode;
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static final class NonTerminalBiMapEntry<K, V>
/* 111:    */     extends ImmutableMapEntry<K, V>
/* 112:    */   {
/* 113:    */     @Nullable
/* 114:    */     private final ImmutableMapEntry<K, V> nextInKeyBucket;
/* 115:    */     @Nullable
/* 116:    */     private final ImmutableMapEntry<K, V> nextInValueBucket;
/* 117:    */     
/* 118:    */     NonTerminalBiMapEntry(K key, V value, @Nullable ImmutableMapEntry<K, V> nextInKeyBucket, @Nullable ImmutableMapEntry<K, V> nextInValueBucket)
/* 119:    */     {
/* 120:155 */       super(value);
/* 121:156 */       this.nextInKeyBucket = nextInKeyBucket;
/* 122:157 */       this.nextInValueBucket = nextInValueBucket;
/* 123:    */     }
/* 124:    */     
/* 125:    */     NonTerminalBiMapEntry(ImmutableMapEntry<K, V> contents, @Nullable ImmutableMapEntry<K, V> nextInKeyBucket, @Nullable ImmutableMapEntry<K, V> nextInValueBucket)
/* 126:    */     {
/* 127:163 */       super();
/* 128:164 */       this.nextInKeyBucket = nextInKeyBucket;
/* 129:165 */       this.nextInValueBucket = nextInValueBucket;
/* 130:    */     }
/* 131:    */     
/* 132:    */     @Nullable
/* 133:    */     ImmutableMapEntry<K, V> getNextInKeyBucket()
/* 134:    */     {
/* 135:171 */       return this.nextInKeyBucket;
/* 136:    */     }
/* 137:    */     
/* 138:    */     @Nullable
/* 139:    */     ImmutableMapEntry<K, V> getNextInValueBucket()
/* 140:    */     {
/* 141:177 */       return this.nextInValueBucket;
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static <K, V> ImmutableMapEntry<K, V>[] createEntryArray(int length)
/* 146:    */   {
/* 147:183 */     return new ImmutableMapEntry[length];
/* 148:    */   }
/* 149:    */   
/* 150:    */   @Nullable
/* 151:    */   public V get(@Nullable Object key)
/* 152:    */   {
/* 153:189 */     if (key == null) {
/* 154:190 */       return null;
/* 155:    */     }
/* 156:192 */     int bucket = Hashing.smear(key.hashCode()) & this.mask;
/* 157:193 */     for (ImmutableMapEntry<K, V> entry = this.keyTable[bucket]; entry != null; entry = entry.getNextInKeyBucket()) {
/* 158:195 */       if (key.equals(entry.getKey())) {
/* 159:196 */         return entry.getValue();
/* 160:    */       }
/* 161:    */     }
/* 162:199 */     return null;
/* 163:    */   }
/* 164:    */   
/* 165:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 166:    */   {
/* 167:204 */     new ImmutableMapEntrySet()
/* 168:    */     {
/* 169:    */       ImmutableMap<K, V> map()
/* 170:    */       {
/* 171:207 */         return RegularImmutableBiMap.this;
/* 172:    */       }
/* 173:    */       
/* 174:    */       public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 175:    */       {
/* 176:212 */         return asList().iterator();
/* 177:    */       }
/* 178:    */       
/* 179:    */       ImmutableList<Map.Entry<K, V>> createAsList()
/* 180:    */       {
/* 181:217 */         return new RegularImmutableAsList(this, RegularImmutableBiMap.this.entries);
/* 182:    */       }
/* 183:    */       
/* 184:    */       boolean isHashCodeFast()
/* 185:    */       {
/* 186:222 */         return true;
/* 187:    */       }
/* 188:    */       
/* 189:    */       public int hashCode()
/* 190:    */       {
/* 191:227 */         return RegularImmutableBiMap.this.hashCode;
/* 192:    */       }
/* 193:    */     };
/* 194:    */   }
/* 195:    */   
/* 196:    */   boolean isPartialView()
/* 197:    */   {
/* 198:234 */     return false;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public int size()
/* 202:    */   {
/* 203:239 */     return this.entries.length;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public ImmutableBiMap<V, K> inverse()
/* 207:    */   {
/* 208:246 */     ImmutableBiMap<V, K> result = this.inverse;
/* 209:247 */     return result == null ? (this.inverse = new Inverse(null)) : result;
/* 210:    */   }
/* 211:    */   
/* 212:    */   private final class Inverse
/* 213:    */     extends ImmutableBiMap<V, K>
/* 214:    */   {
/* 215:    */     private Inverse() {}
/* 216:    */     
/* 217:    */     public int size()
/* 218:    */     {
/* 219:254 */       return inverse().size();
/* 220:    */     }
/* 221:    */     
/* 222:    */     public ImmutableBiMap<K, V> inverse()
/* 223:    */     {
/* 224:259 */       return RegularImmutableBiMap.this;
/* 225:    */     }
/* 226:    */     
/* 227:    */     public K get(@Nullable Object value)
/* 228:    */     {
/* 229:264 */       if (value == null) {
/* 230:265 */         return null;
/* 231:    */       }
/* 232:267 */       int bucket = Hashing.smear(value.hashCode()) & RegularImmutableBiMap.this.mask;
/* 233:268 */       for (ImmutableMapEntry<K, V> entry = RegularImmutableBiMap.this.valueTable[bucket]; entry != null; entry = entry.getNextInValueBucket()) {
/* 234:270 */         if (value.equals(entry.getValue())) {
/* 235:271 */           return entry.getKey();
/* 236:    */         }
/* 237:    */       }
/* 238:274 */       return null;
/* 239:    */     }
/* 240:    */     
/* 241:    */     ImmutableSet<Map.Entry<V, K>> createEntrySet()
/* 242:    */     {
/* 243:279 */       return new InverseEntrySet();
/* 244:    */     }
/* 245:    */     
/* 246:    */     final class InverseEntrySet
/* 247:    */       extends ImmutableMapEntrySet<V, K>
/* 248:    */     {
/* 249:    */       InverseEntrySet() {}
/* 250:    */       
/* 251:    */       ImmutableMap<V, K> map()
/* 252:    */       {
/* 253:285 */         return RegularImmutableBiMap.Inverse.this;
/* 254:    */       }
/* 255:    */       
/* 256:    */       boolean isHashCodeFast()
/* 257:    */       {
/* 258:290 */         return true;
/* 259:    */       }
/* 260:    */       
/* 261:    */       public int hashCode()
/* 262:    */       {
/* 263:295 */         return RegularImmutableBiMap.this.hashCode;
/* 264:    */       }
/* 265:    */       
/* 266:    */       public UnmodifiableIterator<Map.Entry<V, K>> iterator()
/* 267:    */       {
/* 268:300 */         return asList().iterator();
/* 269:    */       }
/* 270:    */       
/* 271:    */       ImmutableList<Map.Entry<V, K>> createAsList()
/* 272:    */       {
/* 273:305 */         new ImmutableAsList()
/* 274:    */         {
/* 275:    */           public Map.Entry<V, K> get(int index)
/* 276:    */           {
/* 277:308 */             Map.Entry<K, V> entry = RegularImmutableBiMap.this.entries[index];
/* 278:309 */             return Maps.immutableEntry(entry.getValue(), entry.getKey());
/* 279:    */           }
/* 280:    */           
/* 281:    */           ImmutableCollection<Map.Entry<V, K>> delegateCollection()
/* 282:    */           {
/* 283:314 */             return RegularImmutableBiMap.Inverse.InverseEntrySet.this;
/* 284:    */           }
/* 285:    */         };
/* 286:    */       }
/* 287:    */     }
/* 288:    */     
/* 289:    */     boolean isPartialView()
/* 290:    */     {
/* 291:322 */       return false;
/* 292:    */     }
/* 293:    */     
/* 294:    */     Object writeReplace()
/* 295:    */     {
/* 296:327 */       return new RegularImmutableBiMap.InverseSerializedForm(RegularImmutableBiMap.this);
/* 297:    */     }
/* 298:    */   }
/* 299:    */   
/* 300:    */   private static class InverseSerializedForm<K, V>
/* 301:    */     implements Serializable
/* 302:    */   {
/* 303:    */     private final ImmutableBiMap<K, V> forward;
/* 304:    */     private static final long serialVersionUID = 1L;
/* 305:    */     
/* 306:    */     InverseSerializedForm(ImmutableBiMap<K, V> forward)
/* 307:    */     {
/* 308:335 */       this.forward = forward;
/* 309:    */     }
/* 310:    */     
/* 311:    */     Object readResolve()
/* 312:    */     {
/* 313:339 */       return this.forward.inverse();
/* 314:    */     }
/* 315:    */   }
/* 316:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */
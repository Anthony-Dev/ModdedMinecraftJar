/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.util.Comparator;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(emulated=true)
/*  9:   */ final class ImmutableSortedAsList<E>
/* 10:   */   extends RegularImmutableAsList<E>
/* 11:   */   implements SortedIterable<E>
/* 12:   */ {
/* 13:   */   ImmutableSortedAsList(ImmutableSortedSet<E> backingSet, ImmutableList<E> backingList)
/* 14:   */   {
/* 15:36 */     super(backingSet, backingList);
/* 16:   */   }
/* 17:   */   
/* 18:   */   ImmutableSortedSet<E> delegateCollection()
/* 19:   */   {
/* 20:41 */     return (ImmutableSortedSet)super.delegateCollection();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Comparator<? super E> comparator()
/* 24:   */   {
/* 25:45 */     return delegateCollection().comparator();
/* 26:   */   }
/* 27:   */   
/* 28:   */   @GwtIncompatible("ImmutableSortedSet.indexOf")
/* 29:   */   public int indexOf(@Nullable Object target)
/* 30:   */   {
/* 31:53 */     int index = delegateCollection().indexOf(target);
/* 32:   */     
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:60 */     return (index >= 0) && (get(index).equals(target)) ? index : -1;
/* 39:   */   }
/* 40:   */   
/* 41:   */   @GwtIncompatible("ImmutableSortedSet.indexOf")
/* 42:   */   public int lastIndexOf(@Nullable Object target)
/* 43:   */   {
/* 44:65 */     return indexOf(target);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean contains(Object target)
/* 48:   */   {
/* 49:71 */     return indexOf(target) >= 0;
/* 50:   */   }
/* 51:   */   
/* 52:   */   @GwtIncompatible("super.subListUnchecked does not exist; inherited subList is valid if slow")
/* 53:   */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/* 54:   */   {
/* 55:82 */     return new RegularImmutableSortedSet(super.subListUnchecked(fromIndex, toIndex), comparator()).asList();
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedAsList
 * JD-Core Version:    0.7.0.1
 */
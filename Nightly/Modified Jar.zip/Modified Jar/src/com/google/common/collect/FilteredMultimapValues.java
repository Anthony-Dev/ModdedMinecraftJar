/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Objects;
/*  5:   */ import com.google.common.base.Preconditions;
/*  6:   */ import com.google.common.base.Predicate;
/*  7:   */ import com.google.common.base.Predicates;
/*  8:   */ import java.util.AbstractCollection;
/*  9:   */ import java.util.Collection;
/* 10:   */ import java.util.Iterator;
/* 11:   */ import java.util.Map.Entry;
/* 12:   */ import javax.annotation.Nullable;
/* 13:   */ 
/* 14:   */ @GwtCompatible
/* 15:   */ final class FilteredMultimapValues<K, V>
/* 16:   */   extends AbstractCollection<V>
/* 17:   */ {
/* 18:   */   private final FilteredMultimap<K, V> multimap;
/* 19:   */   
/* 20:   */   FilteredMultimapValues(FilteredMultimap<K, V> multimap)
/* 21:   */   {
/* 22:42 */     this.multimap = ((FilteredMultimap)Preconditions.checkNotNull(multimap));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Iterator<V> iterator()
/* 26:   */   {
/* 27:47 */     return Maps.valueIterator(this.multimap.entries().iterator());
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean contains(@Nullable Object o)
/* 31:   */   {
/* 32:52 */     return this.multimap.containsValue(o);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public int size()
/* 36:   */   {
/* 37:57 */     return this.multimap.size();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public boolean remove(@Nullable Object o)
/* 41:   */   {
/* 42:62 */     Predicate<? super Map.Entry<K, V>> entryPredicate = this.multimap.entryPredicate();
/* 43:63 */     Iterator<Map.Entry<K, V>> unfilteredItr = this.multimap.unfiltered().entries().iterator();
/* 44:64 */     while (unfilteredItr.hasNext())
/* 45:   */     {
/* 46:65 */       Map.Entry<K, V> entry = (Map.Entry)unfilteredItr.next();
/* 47:66 */       if ((entryPredicate.apply(entry)) && (Objects.equal(entry.getValue(), o)))
/* 48:   */       {
/* 49:67 */         unfilteredItr.remove();
/* 50:68 */         return true;
/* 51:   */       }
/* 52:   */     }
/* 53:71 */     return false;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public boolean removeAll(Collection<?> c)
/* 57:   */   {
/* 58:76 */     return Iterables.removeIf(this.multimap.unfiltered().entries(), Predicates.and(this.multimap.entryPredicate(), Maps.valuePredicateOnEntries(Predicates.in(c))));
/* 59:   */   }
/* 60:   */   
/* 61:   */   public boolean retainAll(Collection<?> c)
/* 62:   */   {
/* 63:84 */     return Iterables.removeIf(this.multimap.unfiltered().entries(), Predicates.and(this.multimap.entryPredicate(), Maps.valuePredicateOnEntries(Predicates.not(Predicates.in(c)))));
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void clear()
/* 67:   */   {
/* 68:92 */     this.multimap.clear();
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.FilteredMultimapValues
 * JD-Core Version:    0.7.0.1
 */
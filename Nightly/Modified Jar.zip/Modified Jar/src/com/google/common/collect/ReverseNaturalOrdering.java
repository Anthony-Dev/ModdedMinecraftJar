/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Iterator;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class ReverseNaturalOrdering
/* 10:   */   extends Ordering<Comparable>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:31 */   static final ReverseNaturalOrdering INSTANCE = new ReverseNaturalOrdering();
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   public int compare(Comparable left, Comparable right)
/* 17:   */   {
/* 18:34 */     Preconditions.checkNotNull(left);
/* 19:35 */     if (left == right) {
/* 20:36 */       return 0;
/* 21:   */     }
/* 22:39 */     return right.compareTo(left);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public <S extends Comparable> Ordering<S> reverse()
/* 26:   */   {
/* 27:43 */     return Ordering.natural();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public <E extends Comparable> E min(E a, E b)
/* 31:   */   {
/* 32:49 */     return (Comparable)NaturalOrdering.INSTANCE.max(a, b);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public <E extends Comparable> E min(E a, E b, E c, E... rest)
/* 36:   */   {
/* 37:53 */     return (Comparable)NaturalOrdering.INSTANCE.max(a, b, c, rest);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public <E extends Comparable> E min(Iterator<E> iterator)
/* 41:   */   {
/* 42:57 */     return (Comparable)NaturalOrdering.INSTANCE.max(iterator);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public <E extends Comparable> E min(Iterable<E> iterable)
/* 46:   */   {
/* 47:61 */     return (Comparable)NaturalOrdering.INSTANCE.max(iterable);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public <E extends Comparable> E max(E a, E b)
/* 51:   */   {
/* 52:65 */     return (Comparable)NaturalOrdering.INSTANCE.min(a, b);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public <E extends Comparable> E max(E a, E b, E c, E... rest)
/* 56:   */   {
/* 57:69 */     return (Comparable)NaturalOrdering.INSTANCE.min(a, b, c, rest);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public <E extends Comparable> E max(Iterator<E> iterator)
/* 61:   */   {
/* 62:73 */     return (Comparable)NaturalOrdering.INSTANCE.min(iterator);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public <E extends Comparable> E max(Iterable<E> iterable)
/* 66:   */   {
/* 67:77 */     return (Comparable)NaturalOrdering.INSTANCE.min(iterable);
/* 68:   */   }
/* 69:   */   
/* 70:   */   private Object readResolve()
/* 71:   */   {
/* 72:82 */     return INSTANCE;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String toString()
/* 76:   */   {
/* 77:86 */     return "Ordering.natural().reverse()";
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ReverseNaturalOrdering
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtIncompatible;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ class DescendingImmutableSortedSet<E>
/*   7:    */   extends ImmutableSortedSet<E>
/*   8:    */ {
/*   9:    */   private final ImmutableSortedSet<E> forward;
/*  10:    */   
/*  11:    */   DescendingImmutableSortedSet(ImmutableSortedSet<E> forward)
/*  12:    */   {
/*  13: 32 */     super(Ordering.from(forward.comparator()).reverse());
/*  14: 33 */     this.forward = forward;
/*  15:    */   }
/*  16:    */   
/*  17:    */   public int size()
/*  18:    */   {
/*  19: 38 */     return this.forward.size();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public UnmodifiableIterator<E> iterator()
/*  23:    */   {
/*  24: 43 */     return this.forward.descendingIterator();
/*  25:    */   }
/*  26:    */   
/*  27:    */   ImmutableSortedSet<E> headSetImpl(E toElement, boolean inclusive)
/*  28:    */   {
/*  29: 48 */     return this.forward.tailSet(toElement, inclusive).descendingSet();
/*  30:    */   }
/*  31:    */   
/*  32:    */   ImmutableSortedSet<E> subSetImpl(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  33:    */   {
/*  34: 54 */     return this.forward.subSet(toElement, toInclusive, fromElement, fromInclusive).descendingSet();
/*  35:    */   }
/*  36:    */   
/*  37:    */   ImmutableSortedSet<E> tailSetImpl(E fromElement, boolean inclusive)
/*  38:    */   {
/*  39: 59 */     return this.forward.headSet(fromElement, inclusive).descendingSet();
/*  40:    */   }
/*  41:    */   
/*  42:    */   @GwtIncompatible("NavigableSet")
/*  43:    */   public ImmutableSortedSet<E> descendingSet()
/*  44:    */   {
/*  45: 65 */     return this.forward;
/*  46:    */   }
/*  47:    */   
/*  48:    */   @GwtIncompatible("NavigableSet")
/*  49:    */   public UnmodifiableIterator<E> descendingIterator()
/*  50:    */   {
/*  51: 71 */     return this.forward.iterator();
/*  52:    */   }
/*  53:    */   
/*  54:    */   @GwtIncompatible("NavigableSet")
/*  55:    */   ImmutableSortedSet<E> createDescendingSet()
/*  56:    */   {
/*  57: 77 */     throw new AssertionError("should never be called");
/*  58:    */   }
/*  59:    */   
/*  60:    */   public E lower(E element)
/*  61:    */   {
/*  62: 82 */     return this.forward.higher(element);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public E floor(E element)
/*  66:    */   {
/*  67: 87 */     return this.forward.ceiling(element);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public E ceiling(E element)
/*  71:    */   {
/*  72: 92 */     return this.forward.floor(element);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public E higher(E element)
/*  76:    */   {
/*  77: 97 */     return this.forward.lower(element);
/*  78:    */   }
/*  79:    */   
/*  80:    */   int indexOf(@Nullable Object target)
/*  81:    */   {
/*  82:102 */     int index = this.forward.indexOf(target);
/*  83:103 */     if (index == -1) {
/*  84:104 */       return index;
/*  85:    */     }
/*  86:106 */     return size() - 1 - index;
/*  87:    */   }
/*  88:    */   
/*  89:    */   boolean isPartialView()
/*  90:    */   {
/*  91:112 */     return this.forward.isPartialView();
/*  92:    */   }
/*  93:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.DescendingImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */
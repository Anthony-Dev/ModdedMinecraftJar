/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.primitives.Ints;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ final class RegularImmutableSortedMultiset<E>
/*   8:    */   extends ImmutableSortedMultiset<E>
/*   9:    */ {
/*  10:    */   private final transient RegularImmutableSortedSet<E> elementSet;
/*  11:    */   private final transient int[] counts;
/*  12:    */   private final transient long[] cumulativeCounts;
/*  13:    */   private final transient int offset;
/*  14:    */   private final transient int length;
/*  15:    */   
/*  16:    */   RegularImmutableSortedMultiset(RegularImmutableSortedSet<E> elementSet, int[] counts, long[] cumulativeCounts, int offset, int length)
/*  17:    */   {
/*  18: 44 */     this.elementSet = elementSet;
/*  19: 45 */     this.counts = counts;
/*  20: 46 */     this.cumulativeCounts = cumulativeCounts;
/*  21: 47 */     this.offset = offset;
/*  22: 48 */     this.length = length;
/*  23:    */   }
/*  24:    */   
/*  25:    */   Multiset.Entry<E> getEntry(int index)
/*  26:    */   {
/*  27: 53 */     return Multisets.immutableEntry(this.elementSet.asList().get(index), this.counts[(this.offset + index)]);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Multiset.Entry<E> firstEntry()
/*  31:    */   {
/*  32: 60 */     return getEntry(0);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Multiset.Entry<E> lastEntry()
/*  36:    */   {
/*  37: 65 */     return getEntry(this.length - 1);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int count(@Nullable Object element)
/*  41:    */   {
/*  42: 70 */     int index = this.elementSet.indexOf(element);
/*  43: 71 */     return index == -1 ? 0 : this.counts[(index + this.offset)];
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int size()
/*  47:    */   {
/*  48: 76 */     long size = this.cumulativeCounts[(this.offset + this.length)] - this.cumulativeCounts[this.offset];
/*  49: 77 */     return Ints.saturatedCast(size);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ImmutableSortedSet<E> elementSet()
/*  53:    */   {
/*  54: 82 */     return this.elementSet;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public ImmutableSortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/*  58:    */   {
/*  59: 87 */     return getSubMultiset(0, this.elementSet.headIndex(upperBound, Preconditions.checkNotNull(boundType) == BoundType.CLOSED));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public ImmutableSortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/*  63:    */   {
/*  64: 92 */     return getSubMultiset(this.elementSet.tailIndex(lowerBound, Preconditions.checkNotNull(boundType) == BoundType.CLOSED), this.length);
/*  65:    */   }
/*  66:    */   
/*  67:    */   ImmutableSortedMultiset<E> getSubMultiset(int from, int to)
/*  68:    */   {
/*  69: 97 */     Preconditions.checkPositionIndexes(from, to, this.length);
/*  70: 98 */     if (from == to) {
/*  71: 99 */       return emptyMultiset(comparator());
/*  72:    */     }
/*  73:100 */     if ((from == 0) && (to == this.length)) {
/*  74:101 */       return this;
/*  75:    */     }
/*  76:103 */     RegularImmutableSortedSet<E> subElementSet = (RegularImmutableSortedSet)this.elementSet.getSubSet(from, to);
/*  77:    */     
/*  78:105 */     return new RegularImmutableSortedMultiset(subElementSet, this.counts, this.cumulativeCounts, this.offset + from, to - from);
/*  79:    */   }
/*  80:    */   
/*  81:    */   boolean isPartialView()
/*  82:    */   {
/*  83:112 */     return (this.offset > 0) || (this.length < this.counts.length);
/*  84:    */   }
/*  85:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */
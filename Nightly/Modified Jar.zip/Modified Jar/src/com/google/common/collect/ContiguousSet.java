/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import java.util.NoSuchElementException;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ContiguousSet<C extends Comparable>
/*  13:    */   extends ImmutableSortedSet<C>
/*  14:    */ {
/*  15:    */   final DiscreteDomain<C> domain;
/*  16:    */   
/*  17:    */   public static <C extends Comparable> ContiguousSet<C> create(Range<C> range, DiscreteDomain<C> domain)
/*  18:    */   {
/*  19: 54 */     Preconditions.checkNotNull(range);
/*  20: 55 */     Preconditions.checkNotNull(domain);
/*  21: 56 */     Range<C> effectiveRange = range;
/*  22:    */     try
/*  23:    */     {
/*  24: 58 */       if (!range.hasLowerBound()) {
/*  25: 59 */         effectiveRange = effectiveRange.intersection(Range.atLeast(domain.minValue()));
/*  26:    */       }
/*  27: 61 */       if (!range.hasUpperBound()) {
/*  28: 62 */         effectiveRange = effectiveRange.intersection(Range.atMost(domain.maxValue()));
/*  29:    */       }
/*  30:    */     }
/*  31:    */     catch (NoSuchElementException e)
/*  32:    */     {
/*  33: 65 */       throw new IllegalArgumentException(e);
/*  34:    */     }
/*  35: 69 */     boolean empty = (effectiveRange.isEmpty()) || (Range.compareOrThrow(range.lowerBound.leastValueAbove(domain), range.upperBound.greatestValueBelow(domain)) > 0);
/*  36:    */     
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40: 74 */     return empty ? new EmptyContiguousSet(domain) : new RegularContiguousSet(effectiveRange, domain);
/*  41:    */   }
/*  42:    */   
/*  43:    */   ContiguousSet(DiscreteDomain<C> domain)
/*  44:    */   {
/*  45: 82 */     super(Ordering.natural());
/*  46: 83 */     this.domain = domain;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public ContiguousSet<C> headSet(C toElement)
/*  50:    */   {
/*  51: 87 */     return headSetImpl((Comparable)Preconditions.checkNotNull(toElement), false);
/*  52:    */   }
/*  53:    */   
/*  54:    */   @GwtIncompatible("NavigableSet")
/*  55:    */   public ContiguousSet<C> headSet(C toElement, boolean inclusive)
/*  56:    */   {
/*  57: 95 */     return headSetImpl((Comparable)Preconditions.checkNotNull(toElement), inclusive);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public ContiguousSet<C> subSet(C fromElement, C toElement)
/*  61:    */   {
/*  62: 99 */     Preconditions.checkNotNull(fromElement);
/*  63:100 */     Preconditions.checkNotNull(toElement);
/*  64:101 */     Preconditions.checkArgument(comparator().compare(fromElement, toElement) <= 0);
/*  65:102 */     return subSetImpl(fromElement, true, toElement, false);
/*  66:    */   }
/*  67:    */   
/*  68:    */   @GwtIncompatible("NavigableSet")
/*  69:    */   public ContiguousSet<C> subSet(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/*  70:    */   {
/*  71:111 */     Preconditions.checkNotNull(fromElement);
/*  72:112 */     Preconditions.checkNotNull(toElement);
/*  73:113 */     Preconditions.checkArgument(comparator().compare(fromElement, toElement) <= 0);
/*  74:114 */     return subSetImpl(fromElement, fromInclusive, toElement, toInclusive);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public ContiguousSet<C> tailSet(C fromElement)
/*  78:    */   {
/*  79:118 */     return tailSetImpl((Comparable)Preconditions.checkNotNull(fromElement), true);
/*  80:    */   }
/*  81:    */   
/*  82:    */   @GwtIncompatible("NavigableSet")
/*  83:    */   public ContiguousSet<C> tailSet(C fromElement, boolean inclusive)
/*  84:    */   {
/*  85:126 */     return tailSetImpl((Comparable)Preconditions.checkNotNull(fromElement), inclusive);
/*  86:    */   }
/*  87:    */   
/*  88:    */   abstract ContiguousSet<C> headSetImpl(C paramC, boolean paramBoolean);
/*  89:    */   
/*  90:    */   abstract ContiguousSet<C> subSetImpl(C paramC1, boolean paramBoolean1, C paramC2, boolean paramBoolean2);
/*  91:    */   
/*  92:    */   abstract ContiguousSet<C> tailSetImpl(C paramC, boolean paramBoolean);
/*  93:    */   
/*  94:    */   public abstract ContiguousSet<C> intersection(ContiguousSet<C> paramContiguousSet);
/*  95:    */   
/*  96:    */   public abstract Range<C> range();
/*  97:    */   
/*  98:    */   public abstract Range<C> range(BoundType paramBoundType1, BoundType paramBoundType2);
/*  99:    */   
/* 100:    */   public String toString()
/* 101:    */   {
/* 102:170 */     return range().toString();
/* 103:    */   }
/* 104:    */   
/* 105:    */   @Deprecated
/* 106:    */   public static <E> ImmutableSortedSet.Builder<E> builder()
/* 107:    */   {
/* 108:182 */     throw new UnsupportedOperationException();
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ContiguousSet
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Converter;
/*    7:     */ import com.google.common.base.Equivalence;
/*    8:     */ import com.google.common.base.Function;
/*    9:     */ import com.google.common.base.Joiner;
/*   10:     */ import com.google.common.base.Joiner.MapJoiner;
/*   11:     */ import com.google.common.base.Objects;
/*   12:     */ import com.google.common.base.Preconditions;
/*   13:     */ import com.google.common.base.Predicate;
/*   14:     */ import com.google.common.base.Predicates;
/*   15:     */ import java.io.Serializable;
/*   16:     */ import java.util.AbstractCollection;
/*   17:     */ import java.util.AbstractMap;
/*   18:     */ import java.util.ArrayList;
/*   19:     */ import java.util.Collection;
/*   20:     */ import java.util.Collections;
/*   21:     */ import java.util.Comparator;
/*   22:     */ import java.util.EnumMap;
/*   23:     */ import java.util.Enumeration;
/*   24:     */ import java.util.HashMap;
/*   25:     */ import java.util.IdentityHashMap;
/*   26:     */ import java.util.Iterator;
/*   27:     */ import java.util.LinkedHashMap;
/*   28:     */ import java.util.Map;
/*   29:     */ import java.util.Map.Entry;
/*   30:     */ import java.util.NavigableMap;
/*   31:     */ import java.util.NavigableSet;
/*   32:     */ import java.util.Properties;
/*   33:     */ import java.util.Set;
/*   34:     */ import java.util.SortedMap;
/*   35:     */ import java.util.SortedSet;
/*   36:     */ import java.util.TreeMap;
/*   37:     */ import java.util.concurrent.ConcurrentMap;
/*   38:     */ import javax.annotation.Nullable;
/*   39:     */ 
/*   40:     */ @GwtCompatible(emulated=true)
/*   41:     */ public final class Maps
/*   42:     */ {
/*   43:     */   private static abstract enum EntryFunction
/*   44:     */     implements Function<Map.Entry<?, ?>, Object>
/*   45:     */   {
/*   46:  86 */     KEY,  VALUE;
/*   47:     */     
/*   48:     */     private EntryFunction() {}
/*   49:     */   }
/*   50:     */   
/*   51:     */   static <K> Function<Map.Entry<K, ?>, K> keyFunction()
/*   52:     */   {
/*   53: 104 */     return EntryFunction.KEY;
/*   54:     */   }
/*   55:     */   
/*   56:     */   static <V> Function<Map.Entry<?, V>, V> valueFunction()
/*   57:     */   {
/*   58: 109 */     return EntryFunction.VALUE;
/*   59:     */   }
/*   60:     */   
/*   61:     */   static <K, V> Iterator<K> keyIterator(Iterator<Map.Entry<K, V>> entryIterator)
/*   62:     */   {
/*   63: 113 */     return Iterators.transform(entryIterator, keyFunction());
/*   64:     */   }
/*   65:     */   
/*   66:     */   static <K, V> Iterator<V> valueIterator(Iterator<Map.Entry<K, V>> entryIterator)
/*   67:     */   {
/*   68: 117 */     return Iterators.transform(entryIterator, valueFunction());
/*   69:     */   }
/*   70:     */   
/*   71:     */   static <K, V> UnmodifiableIterator<V> valueIterator(UnmodifiableIterator<Map.Entry<K, V>> entryIterator)
/*   72:     */   {
/*   73: 122 */     new UnmodifiableIterator()
/*   74:     */     {
/*   75:     */       public boolean hasNext()
/*   76:     */       {
/*   77: 125 */         return this.val$entryIterator.hasNext();
/*   78:     */       }
/*   79:     */       
/*   80:     */       public V next()
/*   81:     */       {
/*   82: 130 */         return ((Map.Entry)this.val$entryIterator.next()).getValue();
/*   83:     */       }
/*   84:     */     };
/*   85:     */   }
/*   86:     */   
/*   87:     */   @GwtCompatible(serializable=true)
/*   88:     */   @Beta
/*   89:     */   public static <K extends Enum<K>, V> ImmutableMap<K, V> immutableEnumMap(Map<K, ? extends V> map)
/*   90:     */   {
/*   91: 150 */     if ((map instanceof ImmutableEnumMap))
/*   92:     */     {
/*   93: 152 */       ImmutableEnumMap<K, V> result = (ImmutableEnumMap)map;
/*   94: 153 */       return result;
/*   95:     */     }
/*   96: 154 */     if (map.isEmpty()) {
/*   97: 155 */       return ImmutableMap.of();
/*   98:     */     }
/*   99: 157 */     for (Map.Entry<K, ? extends V> entry : map.entrySet())
/*  100:     */     {
/*  101: 158 */       Preconditions.checkNotNull(entry.getKey());
/*  102: 159 */       Preconditions.checkNotNull(entry.getValue());
/*  103:     */     }
/*  104: 161 */     return ImmutableEnumMap.asImmutable(new EnumMap(map));
/*  105:     */   }
/*  106:     */   
/*  107:     */   public static <K, V> HashMap<K, V> newHashMap()
/*  108:     */   {
/*  109: 177 */     return new HashMap();
/*  110:     */   }
/*  111:     */   
/*  112:     */   public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int expectedSize)
/*  113:     */   {
/*  114: 195 */     return new HashMap(capacity(expectedSize));
/*  115:     */   }
/*  116:     */   
/*  117:     */   static int capacity(int expectedSize)
/*  118:     */   {
/*  119: 204 */     if (expectedSize < 3)
/*  120:     */     {
/*  121: 205 */       CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
/*  122: 206 */       return expectedSize + 1;
/*  123:     */     }
/*  124: 208 */     if (expectedSize < 1073741824) {
/*  125: 209 */       return expectedSize + expectedSize / 3;
/*  126:     */     }
/*  127: 211 */     return 2147483647;
/*  128:     */   }
/*  129:     */   
/*  130:     */   public static <K, V> HashMap<K, V> newHashMap(Map<? extends K, ? extends V> map)
/*  131:     */   {
/*  132: 230 */     return new HashMap(map);
/*  133:     */   }
/*  134:     */   
/*  135:     */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap()
/*  136:     */   {
/*  137: 243 */     return new LinkedHashMap();
/*  138:     */   }
/*  139:     */   
/*  140:     */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap(Map<? extends K, ? extends V> map)
/*  141:     */   {
/*  142: 259 */     return new LinkedHashMap(map);
/*  143:     */   }
/*  144:     */   
/*  145:     */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap()
/*  146:     */   {
/*  147: 278 */     return new MapMaker().makeMap();
/*  148:     */   }
/*  149:     */   
/*  150:     */   public static <K extends Comparable, V> TreeMap<K, V> newTreeMap()
/*  151:     */   {
/*  152: 291 */     return new TreeMap();
/*  153:     */   }
/*  154:     */   
/*  155:     */   public static <K, V> TreeMap<K, V> newTreeMap(SortedMap<K, ? extends V> map)
/*  156:     */   {
/*  157: 307 */     return new TreeMap(map);
/*  158:     */   }
/*  159:     */   
/*  160:     */   public static <C, K extends C, V> TreeMap<K, V> newTreeMap(@Nullable Comparator<C> comparator)
/*  161:     */   {
/*  162: 327 */     return new TreeMap(comparator);
/*  163:     */   }
/*  164:     */   
/*  165:     */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Class<K> type)
/*  166:     */   {
/*  167: 337 */     return new EnumMap((Class)Preconditions.checkNotNull(type));
/*  168:     */   }
/*  169:     */   
/*  170:     */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Map<K, ? extends V> map)
/*  171:     */   {
/*  172: 351 */     return new EnumMap(map);
/*  173:     */   }
/*  174:     */   
/*  175:     */   public static <K, V> IdentityHashMap<K, V> newIdentityHashMap()
/*  176:     */   {
/*  177: 360 */     return new IdentityHashMap();
/*  178:     */   }
/*  179:     */   
/*  180:     */   public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right)
/*  181:     */   {
/*  182: 382 */     if ((left instanceof SortedMap))
/*  183:     */     {
/*  184: 383 */       SortedMap<K, ? extends V> sortedLeft = (SortedMap)left;
/*  185: 384 */       SortedMapDifference<K, V> result = difference(sortedLeft, right);
/*  186: 385 */       return result;
/*  187:     */     }
/*  188: 387 */     return difference(left, right, Equivalence.equals());
/*  189:     */   }
/*  190:     */   
/*  191:     */   @Beta
/*  192:     */   public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right, Equivalence<? super V> valueEquivalence)
/*  193:     */   {
/*  194: 413 */     Preconditions.checkNotNull(valueEquivalence);
/*  195:     */     
/*  196: 415 */     Map<K, V> onlyOnLeft = newHashMap();
/*  197: 416 */     Map<K, V> onlyOnRight = new HashMap(right);
/*  198: 417 */     Map<K, V> onBoth = newHashMap();
/*  199: 418 */     Map<K, MapDifference.ValueDifference<V>> differences = newHashMap();
/*  200: 419 */     doDifference(left, right, valueEquivalence, onlyOnLeft, onlyOnRight, onBoth, differences);
/*  201: 420 */     return new MapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
/*  202:     */   }
/*  203:     */   
/*  204:     */   private static <K, V> void doDifference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right, Equivalence<? super V> valueEquivalence, Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth, Map<K, MapDifference.ValueDifference<V>> differences)
/*  205:     */   {
/*  206: 428 */     for (Map.Entry<? extends K, ? extends V> entry : left.entrySet())
/*  207:     */     {
/*  208: 429 */       K leftKey = entry.getKey();
/*  209: 430 */       V leftValue = entry.getValue();
/*  210: 431 */       if (right.containsKey(leftKey))
/*  211:     */       {
/*  212: 432 */         V rightValue = onlyOnRight.remove(leftKey);
/*  213: 433 */         if (valueEquivalence.equivalent(leftValue, rightValue)) {
/*  214: 434 */           onBoth.put(leftKey, leftValue);
/*  215:     */         } else {
/*  216: 436 */           differences.put(leftKey, ValueDifferenceImpl.create(leftValue, rightValue));
/*  217:     */         }
/*  218:     */       }
/*  219:     */       else
/*  220:     */       {
/*  221: 440 */         onlyOnLeft.put(leftKey, leftValue);
/*  222:     */       }
/*  223:     */     }
/*  224:     */   }
/*  225:     */   
/*  226:     */   private static <K, V> Map<K, V> unmodifiableMap(Map<K, V> map)
/*  227:     */   {
/*  228: 446 */     if ((map instanceof SortedMap)) {
/*  229: 447 */       return Collections.unmodifiableSortedMap((SortedMap)map);
/*  230:     */     }
/*  231: 449 */     return Collections.unmodifiableMap(map);
/*  232:     */   }
/*  233:     */   
/*  234:     */   static class MapDifferenceImpl<K, V>
/*  235:     */     implements MapDifference<K, V>
/*  236:     */   {
/*  237:     */     final Map<K, V> onlyOnLeft;
/*  238:     */     final Map<K, V> onlyOnRight;
/*  239:     */     final Map<K, V> onBoth;
/*  240:     */     final Map<K, MapDifference.ValueDifference<V>> differences;
/*  241:     */     
/*  242:     */     MapDifferenceImpl(Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth, Map<K, MapDifference.ValueDifference<V>> differences)
/*  243:     */     {
/*  244: 462 */       this.onlyOnLeft = Maps.unmodifiableMap(onlyOnLeft);
/*  245: 463 */       this.onlyOnRight = Maps.unmodifiableMap(onlyOnRight);
/*  246: 464 */       this.onBoth = Maps.unmodifiableMap(onBoth);
/*  247: 465 */       this.differences = Maps.unmodifiableMap(differences);
/*  248:     */     }
/*  249:     */     
/*  250:     */     public boolean areEqual()
/*  251:     */     {
/*  252: 470 */       return (this.onlyOnLeft.isEmpty()) && (this.onlyOnRight.isEmpty()) && (this.differences.isEmpty());
/*  253:     */     }
/*  254:     */     
/*  255:     */     public Map<K, V> entriesOnlyOnLeft()
/*  256:     */     {
/*  257: 475 */       return this.onlyOnLeft;
/*  258:     */     }
/*  259:     */     
/*  260:     */     public Map<K, V> entriesOnlyOnRight()
/*  261:     */     {
/*  262: 480 */       return this.onlyOnRight;
/*  263:     */     }
/*  264:     */     
/*  265:     */     public Map<K, V> entriesInCommon()
/*  266:     */     {
/*  267: 485 */       return this.onBoth;
/*  268:     */     }
/*  269:     */     
/*  270:     */     public Map<K, MapDifference.ValueDifference<V>> entriesDiffering()
/*  271:     */     {
/*  272: 490 */       return this.differences;
/*  273:     */     }
/*  274:     */     
/*  275:     */     public boolean equals(Object object)
/*  276:     */     {
/*  277: 494 */       if (object == this) {
/*  278: 495 */         return true;
/*  279:     */       }
/*  280: 497 */       if ((object instanceof MapDifference))
/*  281:     */       {
/*  282: 498 */         MapDifference<?, ?> other = (MapDifference)object;
/*  283: 499 */         return (entriesOnlyOnLeft().equals(other.entriesOnlyOnLeft())) && (entriesOnlyOnRight().equals(other.entriesOnlyOnRight())) && (entriesInCommon().equals(other.entriesInCommon())) && (entriesDiffering().equals(other.entriesDiffering()));
/*  284:     */       }
/*  285: 504 */       return false;
/*  286:     */     }
/*  287:     */     
/*  288:     */     public int hashCode()
/*  289:     */     {
/*  290: 508 */       return Objects.hashCode(new Object[] { entriesOnlyOnLeft(), entriesOnlyOnRight(), entriesInCommon(), entriesDiffering() });
/*  291:     */     }
/*  292:     */     
/*  293:     */     public String toString()
/*  294:     */     {
/*  295: 513 */       if (areEqual()) {
/*  296: 514 */         return "equal";
/*  297:     */       }
/*  298: 517 */       StringBuilder result = new StringBuilder("not equal");
/*  299: 518 */       if (!this.onlyOnLeft.isEmpty()) {
/*  300: 519 */         result.append(": only on left=").append(this.onlyOnLeft);
/*  301:     */       }
/*  302: 521 */       if (!this.onlyOnRight.isEmpty()) {
/*  303: 522 */         result.append(": only on right=").append(this.onlyOnRight);
/*  304:     */       }
/*  305: 524 */       if (!this.differences.isEmpty()) {
/*  306: 525 */         result.append(": value differences=").append(this.differences);
/*  307:     */       }
/*  308: 527 */       return result.toString();
/*  309:     */     }
/*  310:     */   }
/*  311:     */   
/*  312:     */   static class ValueDifferenceImpl<V>
/*  313:     */     implements MapDifference.ValueDifference<V>
/*  314:     */   {
/*  315:     */     private final V left;
/*  316:     */     private final V right;
/*  317:     */     
/*  318:     */     static <V> MapDifference.ValueDifference<V> create(@Nullable V left, @Nullable V right)
/*  319:     */     {
/*  320: 537 */       return new ValueDifferenceImpl(left, right);
/*  321:     */     }
/*  322:     */     
/*  323:     */     private ValueDifferenceImpl(@Nullable V left, @Nullable V right)
/*  324:     */     {
/*  325: 541 */       this.left = left;
/*  326: 542 */       this.right = right;
/*  327:     */     }
/*  328:     */     
/*  329:     */     public V leftValue()
/*  330:     */     {
/*  331: 547 */       return this.left;
/*  332:     */     }
/*  333:     */     
/*  334:     */     public V rightValue()
/*  335:     */     {
/*  336: 552 */       return this.right;
/*  337:     */     }
/*  338:     */     
/*  339:     */     public boolean equals(@Nullable Object object)
/*  340:     */     {
/*  341: 556 */       if ((object instanceof MapDifference.ValueDifference))
/*  342:     */       {
/*  343: 557 */         MapDifference.ValueDifference<?> that = (MapDifference.ValueDifference)object;
/*  344:     */         
/*  345: 559 */         return (Objects.equal(this.left, that.leftValue())) && (Objects.equal(this.right, that.rightValue()));
/*  346:     */       }
/*  347: 562 */       return false;
/*  348:     */     }
/*  349:     */     
/*  350:     */     public int hashCode()
/*  351:     */     {
/*  352: 566 */       return Objects.hashCode(new Object[] { this.left, this.right });
/*  353:     */     }
/*  354:     */     
/*  355:     */     public String toString()
/*  356:     */     {
/*  357: 570 */       return "(" + this.left + ", " + this.right + ")";
/*  358:     */     }
/*  359:     */   }
/*  360:     */   
/*  361:     */   public static <K, V> SortedMapDifference<K, V> difference(SortedMap<K, ? extends V> left, Map<? extends K, ? extends V> right)
/*  362:     */   {
/*  363: 595 */     Preconditions.checkNotNull(left);
/*  364: 596 */     Preconditions.checkNotNull(right);
/*  365: 597 */     Comparator<? super K> comparator = orNaturalOrder(left.comparator());
/*  366: 598 */     SortedMap<K, V> onlyOnLeft = newTreeMap(comparator);
/*  367: 599 */     SortedMap<K, V> onlyOnRight = newTreeMap(comparator);
/*  368: 600 */     onlyOnRight.putAll(right);
/*  369: 601 */     SortedMap<K, V> onBoth = newTreeMap(comparator);
/*  370: 602 */     SortedMap<K, MapDifference.ValueDifference<V>> differences = newTreeMap(comparator);
/*  371:     */     
/*  372: 604 */     doDifference(left, right, Equivalence.equals(), onlyOnLeft, onlyOnRight, onBoth, differences);
/*  373: 605 */     return new SortedMapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
/*  374:     */   }
/*  375:     */   
/*  376:     */   static class SortedMapDifferenceImpl<K, V>
/*  377:     */     extends Maps.MapDifferenceImpl<K, V>
/*  378:     */     implements SortedMapDifference<K, V>
/*  379:     */   {
/*  380:     */     SortedMapDifferenceImpl(SortedMap<K, V> onlyOnLeft, SortedMap<K, V> onlyOnRight, SortedMap<K, V> onBoth, SortedMap<K, MapDifference.ValueDifference<V>> differences)
/*  381:     */     {
/*  382: 613 */       super(onlyOnRight, onBoth, differences);
/*  383:     */     }
/*  384:     */     
/*  385:     */     public SortedMap<K, MapDifference.ValueDifference<V>> entriesDiffering()
/*  386:     */     {
/*  387: 617 */       return (SortedMap)super.entriesDiffering();
/*  388:     */     }
/*  389:     */     
/*  390:     */     public SortedMap<K, V> entriesInCommon()
/*  391:     */     {
/*  392: 621 */       return (SortedMap)super.entriesInCommon();
/*  393:     */     }
/*  394:     */     
/*  395:     */     public SortedMap<K, V> entriesOnlyOnLeft()
/*  396:     */     {
/*  397: 625 */       return (SortedMap)super.entriesOnlyOnLeft();
/*  398:     */     }
/*  399:     */     
/*  400:     */     public SortedMap<K, V> entriesOnlyOnRight()
/*  401:     */     {
/*  402: 629 */       return (SortedMap)super.entriesOnlyOnRight();
/*  403:     */     }
/*  404:     */   }
/*  405:     */   
/*  406:     */   static <E> Comparator<? super E> orNaturalOrder(@Nullable Comparator<? super E> comparator)
/*  407:     */   {
/*  408: 641 */     if (comparator != null) {
/*  409: 642 */       return comparator;
/*  410:     */     }
/*  411: 644 */     return Ordering.natural();
/*  412:     */   }
/*  413:     */   
/*  414:     */   @Beta
/*  415:     */   public static <K, V> Map<K, V> asMap(Set<K> set, Function<? super K, V> function)
/*  416:     */   {
/*  417: 677 */     if ((set instanceof SortedSet)) {
/*  418: 678 */       return asMap((SortedSet)set, function);
/*  419:     */     }
/*  420: 680 */     return new AsMapView(set, function);
/*  421:     */   }
/*  422:     */   
/*  423:     */   @Beta
/*  424:     */   public static <K, V> SortedMap<K, V> asMap(SortedSet<K> set, Function<? super K, V> function)
/*  425:     */   {
/*  426: 713 */     return Platform.mapsAsMapSortedSet(set, function);
/*  427:     */   }
/*  428:     */   
/*  429:     */   static <K, V> SortedMap<K, V> asMapSortedIgnoreNavigable(SortedSet<K> set, Function<? super K, V> function)
/*  430:     */   {
/*  431: 718 */     return new SortedAsMapView(set, function);
/*  432:     */   }
/*  433:     */   
/*  434:     */   @Beta
/*  435:     */   @GwtIncompatible("NavigableMap")
/*  436:     */   public static <K, V> NavigableMap<K, V> asMap(NavigableSet<K> set, Function<? super K, V> function)
/*  437:     */   {
/*  438: 751 */     return new NavigableAsMapView(set, function);
/*  439:     */   }
/*  440:     */   
/*  441:     */   private static class AsMapView<K, V>
/*  442:     */     extends Maps.ImprovedAbstractMap<K, V>
/*  443:     */   {
/*  444:     */     private final Set<K> set;
/*  445:     */     final Function<? super K, V> function;
/*  446:     */     
/*  447:     */     Set<K> backingSet()
/*  448:     */     {
/*  449: 760 */       return this.set;
/*  450:     */     }
/*  451:     */     
/*  452:     */     AsMapView(Set<K> set, Function<? super K, V> function)
/*  453:     */     {
/*  454: 764 */       this.set = ((Set)Preconditions.checkNotNull(set));
/*  455: 765 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  456:     */     }
/*  457:     */     
/*  458:     */     public Set<K> createKeySet()
/*  459:     */     {
/*  460: 770 */       return Maps.removeOnlySet(backingSet());
/*  461:     */     }
/*  462:     */     
/*  463:     */     Collection<V> createValues()
/*  464:     */     {
/*  465: 775 */       return Collections2.transform(this.set, this.function);
/*  466:     */     }
/*  467:     */     
/*  468:     */     public int size()
/*  469:     */     {
/*  470: 780 */       return backingSet().size();
/*  471:     */     }
/*  472:     */     
/*  473:     */     public boolean containsKey(@Nullable Object key)
/*  474:     */     {
/*  475: 785 */       return backingSet().contains(key);
/*  476:     */     }
/*  477:     */     
/*  478:     */     public V get(@Nullable Object key)
/*  479:     */     {
/*  480: 790 */       if (Collections2.safeContains(backingSet(), key))
/*  481:     */       {
/*  482: 792 */         K k = key;
/*  483: 793 */         return this.function.apply(k);
/*  484:     */       }
/*  485: 795 */       return null;
/*  486:     */     }
/*  487:     */     
/*  488:     */     public V remove(@Nullable Object key)
/*  489:     */     {
/*  490: 801 */       if (backingSet().remove(key))
/*  491:     */       {
/*  492: 803 */         K k = key;
/*  493: 804 */         return this.function.apply(k);
/*  494:     */       }
/*  495: 806 */       return null;
/*  496:     */     }
/*  497:     */     
/*  498:     */     public void clear()
/*  499:     */     {
/*  500: 812 */       backingSet().clear();
/*  501:     */     }
/*  502:     */     
/*  503:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/*  504:     */     {
/*  505: 817 */       new Maps.EntrySet()
/*  506:     */       {
/*  507:     */         Map<K, V> map()
/*  508:     */         {
/*  509: 820 */           return Maps.AsMapView.this;
/*  510:     */         }
/*  511:     */         
/*  512:     */         public Iterator<Map.Entry<K, V>> iterator()
/*  513:     */         {
/*  514: 825 */           return Maps.asMapEntryIterator(Maps.AsMapView.this.backingSet(), Maps.AsMapView.this.function);
/*  515:     */         }
/*  516:     */       };
/*  517:     */     }
/*  518:     */   }
/*  519:     */   
/*  520:     */   static <K, V> Iterator<Map.Entry<K, V>> asMapEntryIterator(Set<K> set, final Function<? super K, V> function)
/*  521:     */   {
/*  522: 833 */     new TransformedIterator(set.iterator())
/*  523:     */     {
/*  524:     */       Map.Entry<K, V> transform(K key)
/*  525:     */       {
/*  526: 836 */         return Maps.immutableEntry(key, function.apply(key));
/*  527:     */       }
/*  528:     */     };
/*  529:     */   }
/*  530:     */   
/*  531:     */   private static class SortedAsMapView<K, V>
/*  532:     */     extends Maps.AsMapView<K, V>
/*  533:     */     implements SortedMap<K, V>
/*  534:     */   {
/*  535:     */     SortedAsMapView(SortedSet<K> set, Function<? super K, V> function)
/*  536:     */     {
/*  537: 845 */       super(function);
/*  538:     */     }
/*  539:     */     
/*  540:     */     SortedSet<K> backingSet()
/*  541:     */     {
/*  542: 850 */       return (SortedSet)super.backingSet();
/*  543:     */     }
/*  544:     */     
/*  545:     */     public Comparator<? super K> comparator()
/*  546:     */     {
/*  547: 855 */       return backingSet().comparator();
/*  548:     */     }
/*  549:     */     
/*  550:     */     public Set<K> keySet()
/*  551:     */     {
/*  552: 860 */       return Maps.removeOnlySortedSet(backingSet());
/*  553:     */     }
/*  554:     */     
/*  555:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/*  556:     */     {
/*  557: 865 */       return Maps.asMap(backingSet().subSet(fromKey, toKey), this.function);
/*  558:     */     }
/*  559:     */     
/*  560:     */     public SortedMap<K, V> headMap(K toKey)
/*  561:     */     {
/*  562: 870 */       return Maps.asMap(backingSet().headSet(toKey), this.function);
/*  563:     */     }
/*  564:     */     
/*  565:     */     public SortedMap<K, V> tailMap(K fromKey)
/*  566:     */     {
/*  567: 875 */       return Maps.asMap(backingSet().tailSet(fromKey), this.function);
/*  568:     */     }
/*  569:     */     
/*  570:     */     public K firstKey()
/*  571:     */     {
/*  572: 880 */       return backingSet().first();
/*  573:     */     }
/*  574:     */     
/*  575:     */     public K lastKey()
/*  576:     */     {
/*  577: 885 */       return backingSet().last();
/*  578:     */     }
/*  579:     */   }
/*  580:     */   
/*  581:     */   @GwtIncompatible("NavigableMap")
/*  582:     */   private static final class NavigableAsMapView<K, V>
/*  583:     */     extends AbstractNavigableMap<K, V>
/*  584:     */   {
/*  585:     */     private final NavigableSet<K> set;
/*  586:     */     private final Function<? super K, V> function;
/*  587:     */     
/*  588:     */     NavigableAsMapView(NavigableSet<K> ks, Function<? super K, V> vFunction)
/*  589:     */     {
/*  590: 901 */       this.set = ((NavigableSet)Preconditions.checkNotNull(ks));
/*  591: 902 */       this.function = ((Function)Preconditions.checkNotNull(vFunction));
/*  592:     */     }
/*  593:     */     
/*  594:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/*  595:     */     {
/*  596: 908 */       return Maps.asMap(this.set.subSet(fromKey, fromInclusive, toKey, toInclusive), this.function);
/*  597:     */     }
/*  598:     */     
/*  599:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/*  600:     */     {
/*  601: 913 */       return Maps.asMap(this.set.headSet(toKey, inclusive), this.function);
/*  602:     */     }
/*  603:     */     
/*  604:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/*  605:     */     {
/*  606: 918 */       return Maps.asMap(this.set.tailSet(fromKey, inclusive), this.function);
/*  607:     */     }
/*  608:     */     
/*  609:     */     public Comparator<? super K> comparator()
/*  610:     */     {
/*  611: 923 */       return this.set.comparator();
/*  612:     */     }
/*  613:     */     
/*  614:     */     @Nullable
/*  615:     */     public V get(@Nullable Object key)
/*  616:     */     {
/*  617: 929 */       if (Collections2.safeContains(this.set, key))
/*  618:     */       {
/*  619: 931 */         K k = key;
/*  620: 932 */         return this.function.apply(k);
/*  621:     */       }
/*  622: 934 */       return null;
/*  623:     */     }
/*  624:     */     
/*  625:     */     public void clear()
/*  626:     */     {
/*  627: 940 */       this.set.clear();
/*  628:     */     }
/*  629:     */     
/*  630:     */     Iterator<Map.Entry<K, V>> entryIterator()
/*  631:     */     {
/*  632: 945 */       return Maps.asMapEntryIterator(this.set, this.function);
/*  633:     */     }
/*  634:     */     
/*  635:     */     Iterator<Map.Entry<K, V>> descendingEntryIterator()
/*  636:     */     {
/*  637: 950 */       return descendingMap().entrySet().iterator();
/*  638:     */     }
/*  639:     */     
/*  640:     */     public NavigableSet<K> navigableKeySet()
/*  641:     */     {
/*  642: 955 */       return Maps.removeOnlyNavigableSet(this.set);
/*  643:     */     }
/*  644:     */     
/*  645:     */     public int size()
/*  646:     */     {
/*  647: 960 */       return this.set.size();
/*  648:     */     }
/*  649:     */     
/*  650:     */     public NavigableMap<K, V> descendingMap()
/*  651:     */     {
/*  652: 965 */       return Maps.asMap(this.set.descendingSet(), this.function);
/*  653:     */     }
/*  654:     */   }
/*  655:     */   
/*  656:     */   private static <E> Set<E> removeOnlySet(Set<E> set)
/*  657:     */   {
/*  658: 970 */     new ForwardingSet()
/*  659:     */     {
/*  660:     */       protected Set<E> delegate()
/*  661:     */       {
/*  662: 973 */         return this.val$set;
/*  663:     */       }
/*  664:     */       
/*  665:     */       public boolean add(E element)
/*  666:     */       {
/*  667: 978 */         throw new UnsupportedOperationException();
/*  668:     */       }
/*  669:     */       
/*  670:     */       public boolean addAll(Collection<? extends E> es)
/*  671:     */       {
/*  672: 983 */         throw new UnsupportedOperationException();
/*  673:     */       }
/*  674:     */     };
/*  675:     */   }
/*  676:     */   
/*  677:     */   private static <E> SortedSet<E> removeOnlySortedSet(SortedSet<E> set)
/*  678:     */   {
/*  679: 989 */     new ForwardingSortedSet()
/*  680:     */     {
/*  681:     */       protected SortedSet<E> delegate()
/*  682:     */       {
/*  683: 992 */         return this.val$set;
/*  684:     */       }
/*  685:     */       
/*  686:     */       public boolean add(E element)
/*  687:     */       {
/*  688: 997 */         throw new UnsupportedOperationException();
/*  689:     */       }
/*  690:     */       
/*  691:     */       public boolean addAll(Collection<? extends E> es)
/*  692:     */       {
/*  693:1002 */         throw new UnsupportedOperationException();
/*  694:     */       }
/*  695:     */       
/*  696:     */       public SortedSet<E> headSet(E toElement)
/*  697:     */       {
/*  698:1007 */         return Maps.removeOnlySortedSet(super.headSet(toElement));
/*  699:     */       }
/*  700:     */       
/*  701:     */       public SortedSet<E> subSet(E fromElement, E toElement)
/*  702:     */       {
/*  703:1012 */         return Maps.removeOnlySortedSet(super.subSet(fromElement, toElement));
/*  704:     */       }
/*  705:     */       
/*  706:     */       public SortedSet<E> tailSet(E fromElement)
/*  707:     */       {
/*  708:1017 */         return Maps.removeOnlySortedSet(super.tailSet(fromElement));
/*  709:     */       }
/*  710:     */     };
/*  711:     */   }
/*  712:     */   
/*  713:     */   @GwtIncompatible("NavigableSet")
/*  714:     */   private static <E> NavigableSet<E> removeOnlyNavigableSet(NavigableSet<E> set)
/*  715:     */   {
/*  716:1024 */     new ForwardingNavigableSet()
/*  717:     */     {
/*  718:     */       protected NavigableSet<E> delegate()
/*  719:     */       {
/*  720:1027 */         return this.val$set;
/*  721:     */       }
/*  722:     */       
/*  723:     */       public boolean add(E element)
/*  724:     */       {
/*  725:1032 */         throw new UnsupportedOperationException();
/*  726:     */       }
/*  727:     */       
/*  728:     */       public boolean addAll(Collection<? extends E> es)
/*  729:     */       {
/*  730:1037 */         throw new UnsupportedOperationException();
/*  731:     */       }
/*  732:     */       
/*  733:     */       public SortedSet<E> headSet(E toElement)
/*  734:     */       {
/*  735:1042 */         return Maps.removeOnlySortedSet(super.headSet(toElement));
/*  736:     */       }
/*  737:     */       
/*  738:     */       public SortedSet<E> subSet(E fromElement, E toElement)
/*  739:     */       {
/*  740:1047 */         return Maps.removeOnlySortedSet(super.subSet(fromElement, toElement));
/*  741:     */       }
/*  742:     */       
/*  743:     */       public SortedSet<E> tailSet(E fromElement)
/*  744:     */       {
/*  745:1053 */         return Maps.removeOnlySortedSet(super.tailSet(fromElement));
/*  746:     */       }
/*  747:     */       
/*  748:     */       public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  749:     */       {
/*  750:1058 */         return Maps.removeOnlyNavigableSet(super.headSet(toElement, inclusive));
/*  751:     */       }
/*  752:     */       
/*  753:     */       public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  754:     */       {
/*  755:1063 */         return Maps.removeOnlyNavigableSet(super.tailSet(fromElement, inclusive));
/*  756:     */       }
/*  757:     */       
/*  758:     */       public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  759:     */       {
/*  760:1069 */         return Maps.removeOnlyNavigableSet(super.subSet(fromElement, fromInclusive, toElement, toInclusive));
/*  761:     */       }
/*  762:     */       
/*  763:     */       public NavigableSet<E> descendingSet()
/*  764:     */       {
/*  765:1075 */         return Maps.removeOnlyNavigableSet(super.descendingSet());
/*  766:     */       }
/*  767:     */     };
/*  768:     */   }
/*  769:     */   
/*  770:     */   @Beta
/*  771:     */   public static <K, V> ImmutableMap<K, V> toMap(Iterable<K> keys, Function<? super K, V> valueFunction)
/*  772:     */   {
/*  773:1097 */     return toMap(keys.iterator(), valueFunction);
/*  774:     */   }
/*  775:     */   
/*  776:     */   @Beta
/*  777:     */   public static <K, V> ImmutableMap<K, V> toMap(Iterator<K> keys, Function<? super K, V> valueFunction)
/*  778:     */   {
/*  779:1114 */     Preconditions.checkNotNull(valueFunction);
/*  780:     */     
/*  781:1116 */     Map<K, V> builder = newLinkedHashMap();
/*  782:1117 */     while (keys.hasNext())
/*  783:     */     {
/*  784:1118 */       K key = keys.next();
/*  785:1119 */       builder.put(key, valueFunction.apply(key));
/*  786:     */     }
/*  787:1121 */     return ImmutableMap.copyOf(builder);
/*  788:     */   }
/*  789:     */   
/*  790:     */   public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterable<V> values, Function<? super V, K> keyFunction)
/*  791:     */   {
/*  792:1140 */     return uniqueIndex(values.iterator(), keyFunction);
/*  793:     */   }
/*  794:     */   
/*  795:     */   public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterator<V> values, Function<? super V, K> keyFunction)
/*  796:     */   {
/*  797:1160 */     Preconditions.checkNotNull(keyFunction);
/*  798:1161 */     ImmutableMap.Builder<K, V> builder = ImmutableMap.builder();
/*  799:1162 */     while (values.hasNext())
/*  800:     */     {
/*  801:1163 */       V value = values.next();
/*  802:1164 */       builder.put(keyFunction.apply(value), value);
/*  803:     */     }
/*  804:1166 */     return builder.build();
/*  805:     */   }
/*  806:     */   
/*  807:     */   @GwtIncompatible("java.util.Properties")
/*  808:     */   public static ImmutableMap<String, String> fromProperties(Properties properties)
/*  809:     */   {
/*  810:1185 */     ImmutableMap.Builder<String, String> builder = ImmutableMap.builder();
/*  811:1187 */     for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements();)
/*  812:     */     {
/*  813:1188 */       String key = (String)e.nextElement();
/*  814:1189 */       builder.put(key, properties.getProperty(key));
/*  815:     */     }
/*  816:1192 */     return builder.build();
/*  817:     */   }
/*  818:     */   
/*  819:     */   @GwtCompatible(serializable=true)
/*  820:     */   public static <K, V> Map.Entry<K, V> immutableEntry(@Nullable K key, @Nullable V value)
/*  821:     */   {
/*  822:1207 */     return new ImmutableEntry(key, value);
/*  823:     */   }
/*  824:     */   
/*  825:     */   static <K, V> Set<Map.Entry<K, V>> unmodifiableEntrySet(Set<Map.Entry<K, V>> entrySet)
/*  826:     */   {
/*  827:1220 */     return new UnmodifiableEntrySet(Collections.unmodifiableSet(entrySet));
/*  828:     */   }
/*  829:     */   
/*  830:     */   static <K, V> Map.Entry<K, V> unmodifiableEntry(Map.Entry<? extends K, ? extends V> entry)
/*  831:     */   {
/*  832:1234 */     Preconditions.checkNotNull(entry);
/*  833:1235 */     new AbstractMapEntry()
/*  834:     */     {
/*  835:     */       public K getKey()
/*  836:     */       {
/*  837:1237 */         return this.val$entry.getKey();
/*  838:     */       }
/*  839:     */       
/*  840:     */       public V getValue()
/*  841:     */       {
/*  842:1241 */         return this.val$entry.getValue();
/*  843:     */       }
/*  844:     */     };
/*  845:     */   }
/*  846:     */   
/*  847:     */   static class UnmodifiableEntries<K, V>
/*  848:     */     extends ForwardingCollection<Map.Entry<K, V>>
/*  849:     */   {
/*  850:     */     private final Collection<Map.Entry<K, V>> entries;
/*  851:     */     
/*  852:     */     UnmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*  853:     */     {
/*  854:1252 */       this.entries = entries;
/*  855:     */     }
/*  856:     */     
/*  857:     */     protected Collection<Map.Entry<K, V>> delegate()
/*  858:     */     {
/*  859:1256 */       return this.entries;
/*  860:     */     }
/*  861:     */     
/*  862:     */     public Iterator<Map.Entry<K, V>> iterator()
/*  863:     */     {
/*  864:1260 */       final Iterator<Map.Entry<K, V>> delegate = super.iterator();
/*  865:1261 */       new UnmodifiableIterator()
/*  866:     */       {
/*  867:     */         public boolean hasNext()
/*  868:     */         {
/*  869:1264 */           return delegate.hasNext();
/*  870:     */         }
/*  871:     */         
/*  872:     */         public Map.Entry<K, V> next()
/*  873:     */         {
/*  874:1268 */           return Maps.unmodifiableEntry((Map.Entry)delegate.next());
/*  875:     */         }
/*  876:     */       };
/*  877:     */     }
/*  878:     */     
/*  879:     */     public Object[] toArray()
/*  880:     */     {
/*  881:1276 */       return standardToArray();
/*  882:     */     }
/*  883:     */     
/*  884:     */     public <T> T[] toArray(T[] array)
/*  885:     */     {
/*  886:1280 */       return standardToArray(array);
/*  887:     */     }
/*  888:     */   }
/*  889:     */   
/*  890:     */   static class UnmodifiableEntrySet<K, V>
/*  891:     */     extends Maps.UnmodifiableEntries<K, V>
/*  892:     */     implements Set<Map.Entry<K, V>>
/*  893:     */   {
/*  894:     */     UnmodifiableEntrySet(Set<Map.Entry<K, V>> entries)
/*  895:     */     {
/*  896:1288 */       super();
/*  897:     */     }
/*  898:     */     
/*  899:     */     public boolean equals(@Nullable Object object)
/*  900:     */     {
/*  901:1294 */       return Sets.equalsImpl(this, object);
/*  902:     */     }
/*  903:     */     
/*  904:     */     public int hashCode()
/*  905:     */     {
/*  906:1298 */       return Sets.hashCodeImpl(this);
/*  907:     */     }
/*  908:     */   }
/*  909:     */   
/*  910:     */   @Beta
/*  911:     */   public static <A, B> Converter<A, B> asConverter(BiMap<A, B> bimap)
/*  912:     */   {
/*  913:1315 */     return new BiMapConverter(bimap);
/*  914:     */   }
/*  915:     */   
/*  916:     */   private static final class BiMapConverter<A, B>
/*  917:     */     extends Converter<A, B>
/*  918:     */     implements Serializable
/*  919:     */   {
/*  920:     */     private final BiMap<A, B> bimap;
/*  921:     */     private static final long serialVersionUID = 0L;
/*  922:     */     
/*  923:     */     BiMapConverter(BiMap<A, B> bimap)
/*  924:     */     {
/*  925:1322 */       this.bimap = ((BiMap)Preconditions.checkNotNull(bimap));
/*  926:     */     }
/*  927:     */     
/*  928:     */     protected B doForward(A a)
/*  929:     */     {
/*  930:1327 */       return convert(this.bimap, a);
/*  931:     */     }
/*  932:     */     
/*  933:     */     protected A doBackward(B b)
/*  934:     */     {
/*  935:1332 */       return convert(this.bimap.inverse(), b);
/*  936:     */     }
/*  937:     */     
/*  938:     */     private static <X, Y> Y convert(BiMap<X, Y> bimap, X input)
/*  939:     */     {
/*  940:1336 */       Y output = bimap.get(input);
/*  941:1337 */       Preconditions.checkArgument(output != null, "No non-null mapping present for input: %s", new Object[] { input });
/*  942:1338 */       return output;
/*  943:     */     }
/*  944:     */     
/*  945:     */     public boolean equals(@Nullable Object object)
/*  946:     */     {
/*  947:1343 */       if ((object instanceof BiMapConverter))
/*  948:     */       {
/*  949:1344 */         BiMapConverter<?, ?> that = (BiMapConverter)object;
/*  950:1345 */         return this.bimap.equals(that.bimap);
/*  951:     */       }
/*  952:1347 */       return false;
/*  953:     */     }
/*  954:     */     
/*  955:     */     public int hashCode()
/*  956:     */     {
/*  957:1352 */       return this.bimap.hashCode();
/*  958:     */     }
/*  959:     */     
/*  960:     */     public String toString()
/*  961:     */     {
/*  962:1358 */       return "Maps.asConverter(" + this.bimap + ")";
/*  963:     */     }
/*  964:     */   }
/*  965:     */   
/*  966:     */   public static <K, V> BiMap<K, V> synchronizedBiMap(BiMap<K, V> bimap)
/*  967:     */   {
/*  968:1393 */     return Synchronized.biMap(bimap, null);
/*  969:     */   }
/*  970:     */   
/*  971:     */   public static <K, V> BiMap<K, V> unmodifiableBiMap(BiMap<? extends K, ? extends V> bimap)
/*  972:     */   {
/*  973:1411 */     return new UnmodifiableBiMap(bimap, null);
/*  974:     */   }
/*  975:     */   
/*  976:     */   private static class UnmodifiableBiMap<K, V>
/*  977:     */     extends ForwardingMap<K, V>
/*  978:     */     implements BiMap<K, V>, Serializable
/*  979:     */   {
/*  980:     */     final Map<K, V> unmodifiableMap;
/*  981:     */     final BiMap<? extends K, ? extends V> delegate;
/*  982:     */     BiMap<V, K> inverse;
/*  983:     */     transient Set<V> values;
/*  984:     */     private static final long serialVersionUID = 0L;
/*  985:     */     
/*  986:     */     UnmodifiableBiMap(BiMap<? extends K, ? extends V> delegate, @Nullable BiMap<V, K> inverse)
/*  987:     */     {
/*  988:1424 */       this.unmodifiableMap = Collections.unmodifiableMap(delegate);
/*  989:1425 */       this.delegate = delegate;
/*  990:1426 */       this.inverse = inverse;
/*  991:     */     }
/*  992:     */     
/*  993:     */     protected Map<K, V> delegate()
/*  994:     */     {
/*  995:1430 */       return this.unmodifiableMap;
/*  996:     */     }
/*  997:     */     
/*  998:     */     public V forcePut(K key, V value)
/*  999:     */     {
/* 1000:1435 */       throw new UnsupportedOperationException();
/* 1001:     */     }
/* 1002:     */     
/* 1003:     */     public BiMap<V, K> inverse()
/* 1004:     */     {
/* 1005:1440 */       BiMap<V, K> result = this.inverse;
/* 1006:1441 */       return result == null ? (this.inverse = new UnmodifiableBiMap(this.delegate.inverse(), this)) : result;
/* 1007:     */     }
/* 1008:     */     
/* 1009:     */     public Set<V> values()
/* 1010:     */     {
/* 1011:1447 */       Set<V> result = this.values;
/* 1012:1448 */       return result == null ? (this.values = Collections.unmodifiableSet(this.delegate.values())) : result;
/* 1013:     */     }
/* 1014:     */   }
/* 1015:     */   
/* 1016:     */   public static <K, V1, V2> Map<K, V2> transformValues(Map<K, V1> fromMap, Function<? super V1, V2> function)
/* 1017:     */   {
/* 1018:1494 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   public static <K, V1, V2> SortedMap<K, V2> transformValues(SortedMap<K, V1> fromMap, Function<? super V1, V2> function)
/* 1022:     */   {
/* 1023:1538 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   @GwtIncompatible("NavigableMap")
/* 1027:     */   public static <K, V1, V2> NavigableMap<K, V2> transformValues(NavigableMap<K, V1> fromMap, Function<? super V1, V2> function)
/* 1028:     */   {
/* 1029:1585 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1030:     */   }
/* 1031:     */   
/* 1032:     */   public static <K, V1, V2> Map<K, V2> transformEntries(Map<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1033:     */   {
/* 1034:1642 */     if ((fromMap instanceof SortedMap)) {
/* 1035:1643 */       return transformEntries((SortedMap)fromMap, transformer);
/* 1036:     */     }
/* 1037:1645 */     return new TransformedEntriesMap(fromMap, transformer);
/* 1038:     */   }
/* 1039:     */   
/* 1040:     */   public static <K, V1, V2> SortedMap<K, V2> transformEntries(SortedMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1041:     */   {
/* 1042:1703 */     return Platform.mapsTransformEntriesSortedMap(fromMap, transformer);
/* 1043:     */   }
/* 1044:     */   
/* 1045:     */   @GwtIncompatible("NavigableMap")
/* 1046:     */   public static <K, V1, V2> NavigableMap<K, V2> transformEntries(NavigableMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1047:     */   {
/* 1048:1763 */     return new TransformedEntriesNavigableMap(fromMap, transformer);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   static <K, V1, V2> SortedMap<K, V2> transformEntriesIgnoreNavigable(SortedMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1052:     */   {
/* 1053:1769 */     return new TransformedEntriesSortedMap(fromMap, transformer);
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   static <K, V1, V2> EntryTransformer<K, V1, V2> asEntryTransformer(Function<? super V1, V2> function)
/* 1057:     */   {
/* 1058:1808 */     Preconditions.checkNotNull(function);
/* 1059:1809 */     new EntryTransformer()
/* 1060:     */     {
/* 1061:     */       public V2 transformEntry(K key, V1 value)
/* 1062:     */       {
/* 1063:1812 */         return this.val$function.apply(value);
/* 1064:     */       }
/* 1065:     */     };
/* 1066:     */   }
/* 1067:     */   
/* 1068:     */   static <K, V1, V2> Function<V1, V2> asValueToValueFunction(EntryTransformer<? super K, V1, V2> transformer, final K key)
/* 1069:     */   {
/* 1070:1819 */     Preconditions.checkNotNull(transformer);
/* 1071:1820 */     new Function()
/* 1072:     */     {
/* 1073:     */       public V2 apply(@Nullable V1 v1)
/* 1074:     */       {
/* 1075:1823 */         return this.val$transformer.transformEntry(key, v1);
/* 1076:     */       }
/* 1077:     */     };
/* 1078:     */   }
/* 1079:     */   
/* 1080:     */   static <K, V1, V2> Function<Map.Entry<K, V1>, V2> asEntryToValueFunction(EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1081:     */   {
/* 1082:1833 */     Preconditions.checkNotNull(transformer);
/* 1083:1834 */     new Function()
/* 1084:     */     {
/* 1085:     */       public V2 apply(Map.Entry<K, V1> entry)
/* 1086:     */       {
/* 1087:1837 */         return this.val$transformer.transformEntry(entry.getKey(), entry.getValue());
/* 1088:     */       }
/* 1089:     */     };
/* 1090:     */   }
/* 1091:     */   
/* 1092:     */   static <V2, K, V1> Map.Entry<K, V2> transformEntry(final EntryTransformer<? super K, ? super V1, V2> transformer, Map.Entry<K, V1> entry)
/* 1093:     */   {
/* 1094:1847 */     Preconditions.checkNotNull(transformer);
/* 1095:1848 */     Preconditions.checkNotNull(entry);
/* 1096:1849 */     new AbstractMapEntry()
/* 1097:     */     {
/* 1098:     */       public K getKey()
/* 1099:     */       {
/* 1100:1852 */         return this.val$entry.getKey();
/* 1101:     */       }
/* 1102:     */       
/* 1103:     */       public V2 getValue()
/* 1104:     */       {
/* 1105:1857 */         return transformer.transformEntry(this.val$entry.getKey(), this.val$entry.getValue());
/* 1106:     */       }
/* 1107:     */     };
/* 1108:     */   }
/* 1109:     */   
/* 1110:     */   static <K, V1, V2> Function<Map.Entry<K, V1>, Map.Entry<K, V2>> asEntryToEntryFunction(EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1111:     */   {
/* 1112:1867 */     Preconditions.checkNotNull(transformer);
/* 1113:1868 */     new Function()
/* 1114:     */     {
/* 1115:     */       public Map.Entry<K, V2> apply(Map.Entry<K, V1> entry)
/* 1116:     */       {
/* 1117:1871 */         return Maps.transformEntry(this.val$transformer, entry);
/* 1118:     */       }
/* 1119:     */     };
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static class TransformedEntriesMap<K, V1, V2>
/* 1123:     */     extends Maps.ImprovedAbstractMap<K, V2>
/* 1124:     */   {
/* 1125:     */     final Map<K, V1> fromMap;
/* 1126:     */     final Maps.EntryTransformer<? super K, ? super V1, V2> transformer;
/* 1127:     */     
/* 1128:     */     TransformedEntriesMap(Map<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1129:     */     {
/* 1130:1884 */       this.fromMap = ((Map)Preconditions.checkNotNull(fromMap));
/* 1131:1885 */       this.transformer = ((Maps.EntryTransformer)Preconditions.checkNotNull(transformer));
/* 1132:     */     }
/* 1133:     */     
/* 1134:     */     public int size()
/* 1135:     */     {
/* 1136:1889 */       return this.fromMap.size();
/* 1137:     */     }
/* 1138:     */     
/* 1139:     */     public boolean containsKey(Object key)
/* 1140:     */     {
/* 1141:1893 */       return this.fromMap.containsKey(key);
/* 1142:     */     }
/* 1143:     */     
/* 1144:     */     public V2 get(Object key)
/* 1145:     */     {
/* 1146:1899 */       V1 value = this.fromMap.get(key);
/* 1147:1900 */       return (value != null) || (this.fromMap.containsKey(key)) ? this.transformer.transformEntry(key, value) : null;
/* 1148:     */     }
/* 1149:     */     
/* 1150:     */     public V2 remove(Object key)
/* 1151:     */     {
/* 1152:1908 */       return this.fromMap.containsKey(key) ? this.transformer.transformEntry(key, this.fromMap.remove(key)) : null;
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public void clear()
/* 1156:     */     {
/* 1157:1914 */       this.fromMap.clear();
/* 1158:     */     }
/* 1159:     */     
/* 1160:     */     public Set<K> keySet()
/* 1161:     */     {
/* 1162:1918 */       return this.fromMap.keySet();
/* 1163:     */     }
/* 1164:     */     
/* 1165:     */     protected Set<Map.Entry<K, V2>> createEntrySet()
/* 1166:     */     {
/* 1167:1923 */       new Maps.EntrySet()
/* 1168:     */       {
/* 1169:     */         Map<K, V2> map()
/* 1170:     */         {
/* 1171:1925 */           return Maps.TransformedEntriesMap.this;
/* 1172:     */         }
/* 1173:     */         
/* 1174:     */         public Iterator<Map.Entry<K, V2>> iterator()
/* 1175:     */         {
/* 1176:1929 */           return Iterators.transform(Maps.TransformedEntriesMap.this.fromMap.entrySet().iterator(), Maps.asEntryToEntryFunction(Maps.TransformedEntriesMap.this.transformer));
/* 1177:     */         }
/* 1178:     */       };
/* 1179:     */     }
/* 1180:     */   }
/* 1181:     */   
/* 1182:     */   static class TransformedEntriesSortedMap<K, V1, V2>
/* 1183:     */     extends Maps.TransformedEntriesMap<K, V1, V2>
/* 1184:     */     implements SortedMap<K, V2>
/* 1185:     */   {
/* 1186:     */     protected SortedMap<K, V1> fromMap()
/* 1187:     */     {
/* 1188:1940 */       return (SortedMap)this.fromMap;
/* 1189:     */     }
/* 1190:     */     
/* 1191:     */     TransformedEntriesSortedMap(SortedMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1192:     */     {
/* 1193:1945 */       super(transformer);
/* 1194:     */     }
/* 1195:     */     
/* 1196:     */     public Comparator<? super K> comparator()
/* 1197:     */     {
/* 1198:1949 */       return fromMap().comparator();
/* 1199:     */     }
/* 1200:     */     
/* 1201:     */     public K firstKey()
/* 1202:     */     {
/* 1203:1953 */       return fromMap().firstKey();
/* 1204:     */     }
/* 1205:     */     
/* 1206:     */     public SortedMap<K, V2> headMap(K toKey)
/* 1207:     */     {
/* 1208:1957 */       return Maps.transformEntries(fromMap().headMap(toKey), this.transformer);
/* 1209:     */     }
/* 1210:     */     
/* 1211:     */     public K lastKey()
/* 1212:     */     {
/* 1213:1961 */       return fromMap().lastKey();
/* 1214:     */     }
/* 1215:     */     
/* 1216:     */     public SortedMap<K, V2> subMap(K fromKey, K toKey)
/* 1217:     */     {
/* 1218:1965 */       return Maps.transformEntries(fromMap().subMap(fromKey, toKey), this.transformer);
/* 1219:     */     }
/* 1220:     */     
/* 1221:     */     public SortedMap<K, V2> tailMap(K fromKey)
/* 1222:     */     {
/* 1223:1970 */       return Maps.transformEntries(fromMap().tailMap(fromKey), this.transformer);
/* 1224:     */     }
/* 1225:     */   }
/* 1226:     */   
/* 1227:     */   @GwtIncompatible("NavigableMap")
/* 1228:     */   private static class TransformedEntriesNavigableMap<K, V1, V2>
/* 1229:     */     extends Maps.TransformedEntriesSortedMap<K, V1, V2>
/* 1230:     */     implements NavigableMap<K, V2>
/* 1231:     */   {
/* 1232:     */     TransformedEntriesNavigableMap(NavigableMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1233:     */     {
/* 1234:1981 */       super(transformer);
/* 1235:     */     }
/* 1236:     */     
/* 1237:     */     public Map.Entry<K, V2> ceilingEntry(K key)
/* 1238:     */     {
/* 1239:1985 */       return transformEntry(fromMap().ceilingEntry(key));
/* 1240:     */     }
/* 1241:     */     
/* 1242:     */     public K ceilingKey(K key)
/* 1243:     */     {
/* 1244:1989 */       return fromMap().ceilingKey(key);
/* 1245:     */     }
/* 1246:     */     
/* 1247:     */     public NavigableSet<K> descendingKeySet()
/* 1248:     */     {
/* 1249:1993 */       return fromMap().descendingKeySet();
/* 1250:     */     }
/* 1251:     */     
/* 1252:     */     public NavigableMap<K, V2> descendingMap()
/* 1253:     */     {
/* 1254:1997 */       return Maps.transformEntries(fromMap().descendingMap(), this.transformer);
/* 1255:     */     }
/* 1256:     */     
/* 1257:     */     public Map.Entry<K, V2> firstEntry()
/* 1258:     */     {
/* 1259:2001 */       return transformEntry(fromMap().firstEntry());
/* 1260:     */     }
/* 1261:     */     
/* 1262:     */     public Map.Entry<K, V2> floorEntry(K key)
/* 1263:     */     {
/* 1264:2004 */       return transformEntry(fromMap().floorEntry(key));
/* 1265:     */     }
/* 1266:     */     
/* 1267:     */     public K floorKey(K key)
/* 1268:     */     {
/* 1269:2008 */       return fromMap().floorKey(key);
/* 1270:     */     }
/* 1271:     */     
/* 1272:     */     public NavigableMap<K, V2> headMap(K toKey)
/* 1273:     */     {
/* 1274:2012 */       return headMap(toKey, false);
/* 1275:     */     }
/* 1276:     */     
/* 1277:     */     public NavigableMap<K, V2> headMap(K toKey, boolean inclusive)
/* 1278:     */     {
/* 1279:2016 */       return Maps.transformEntries(fromMap().headMap(toKey, inclusive), this.transformer);
/* 1280:     */     }
/* 1281:     */     
/* 1282:     */     public Map.Entry<K, V2> higherEntry(K key)
/* 1283:     */     {
/* 1284:2021 */       return transformEntry(fromMap().higherEntry(key));
/* 1285:     */     }
/* 1286:     */     
/* 1287:     */     public K higherKey(K key)
/* 1288:     */     {
/* 1289:2025 */       return fromMap().higherKey(key);
/* 1290:     */     }
/* 1291:     */     
/* 1292:     */     public Map.Entry<K, V2> lastEntry()
/* 1293:     */     {
/* 1294:2029 */       return transformEntry(fromMap().lastEntry());
/* 1295:     */     }
/* 1296:     */     
/* 1297:     */     public Map.Entry<K, V2> lowerEntry(K key)
/* 1298:     */     {
/* 1299:2033 */       return transformEntry(fromMap().lowerEntry(key));
/* 1300:     */     }
/* 1301:     */     
/* 1302:     */     public K lowerKey(K key)
/* 1303:     */     {
/* 1304:2037 */       return fromMap().lowerKey(key);
/* 1305:     */     }
/* 1306:     */     
/* 1307:     */     public NavigableSet<K> navigableKeySet()
/* 1308:     */     {
/* 1309:2041 */       return fromMap().navigableKeySet();
/* 1310:     */     }
/* 1311:     */     
/* 1312:     */     public Map.Entry<K, V2> pollFirstEntry()
/* 1313:     */     {
/* 1314:2045 */       return transformEntry(fromMap().pollFirstEntry());
/* 1315:     */     }
/* 1316:     */     
/* 1317:     */     public Map.Entry<K, V2> pollLastEntry()
/* 1318:     */     {
/* 1319:2049 */       return transformEntry(fromMap().pollLastEntry());
/* 1320:     */     }
/* 1321:     */     
/* 1322:     */     public NavigableMap<K, V2> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1323:     */     {
/* 1324:2054 */       return Maps.transformEntries(fromMap().subMap(fromKey, fromInclusive, toKey, toInclusive), this.transformer);
/* 1325:     */     }
/* 1326:     */     
/* 1327:     */     public NavigableMap<K, V2> subMap(K fromKey, K toKey)
/* 1328:     */     {
/* 1329:2060 */       return subMap(fromKey, true, toKey, false);
/* 1330:     */     }
/* 1331:     */     
/* 1332:     */     public NavigableMap<K, V2> tailMap(K fromKey)
/* 1333:     */     {
/* 1334:2064 */       return tailMap(fromKey, true);
/* 1335:     */     }
/* 1336:     */     
/* 1337:     */     public NavigableMap<K, V2> tailMap(K fromKey, boolean inclusive)
/* 1338:     */     {
/* 1339:2068 */       return Maps.transformEntries(fromMap().tailMap(fromKey, inclusive), this.transformer);
/* 1340:     */     }
/* 1341:     */     
/* 1342:     */     @Nullable
/* 1343:     */     private Map.Entry<K, V2> transformEntry(@Nullable Map.Entry<K, V1> entry)
/* 1344:     */     {
/* 1345:2074 */       return entry == null ? null : Maps.transformEntry(this.transformer, entry);
/* 1346:     */     }
/* 1347:     */     
/* 1348:     */     protected NavigableMap<K, V1> fromMap()
/* 1349:     */     {
/* 1350:2078 */       return (NavigableMap)super.fromMap();
/* 1351:     */     }
/* 1352:     */   }
/* 1353:     */   
/* 1354:     */   static <K> Predicate<Map.Entry<K, ?>> keyPredicateOnEntries(Predicate<? super K> keyPredicate)
/* 1355:     */   {
/* 1356:2083 */     return Predicates.compose(keyPredicate, keyFunction());
/* 1357:     */   }
/* 1358:     */   
/* 1359:     */   static <V> Predicate<Map.Entry<?, V>> valuePredicateOnEntries(Predicate<? super V> valuePredicate)
/* 1360:     */   {
/* 1361:2087 */     return Predicates.compose(valuePredicate, valueFunction());
/* 1362:     */   }
/* 1363:     */   
/* 1364:     */   public static <K, V> Map<K, V> filterKeys(Map<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1365:     */   {
/* 1366:2120 */     if ((unfiltered instanceof SortedMap)) {
/* 1367:2121 */       return filterKeys((SortedMap)unfiltered, keyPredicate);
/* 1368:     */     }
/* 1369:2122 */     if ((unfiltered instanceof BiMap)) {
/* 1370:2123 */       return filterKeys((BiMap)unfiltered, keyPredicate);
/* 1371:     */     }
/* 1372:2125 */     Preconditions.checkNotNull(keyPredicate);
/* 1373:2126 */     Predicate<Map.Entry<K, ?>> entryPredicate = keyPredicateOnEntries(keyPredicate);
/* 1374:2127 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredKeyMap((Map)Preconditions.checkNotNull(unfiltered), keyPredicate, entryPredicate);
/* 1375:     */   }
/* 1376:     */   
/* 1377:     */   public static <K, V> SortedMap<K, V> filterKeys(SortedMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1378:     */   {
/* 1379:2167 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1380:     */   }
/* 1381:     */   
/* 1382:     */   @GwtIncompatible("NavigableMap")
/* 1383:     */   public static <K, V> NavigableMap<K, V> filterKeys(NavigableMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1384:     */   {
/* 1385:2205 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1386:     */   }
/* 1387:     */   
/* 1388:     */   public static <K, V> BiMap<K, V> filterKeys(BiMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1389:     */   {
/* 1390:2235 */     Preconditions.checkNotNull(keyPredicate);
/* 1391:2236 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1392:     */   }
/* 1393:     */   
/* 1394:     */   public static <K, V> Map<K, V> filterValues(Map<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1395:     */   {
/* 1396:2270 */     if ((unfiltered instanceof SortedMap)) {
/* 1397:2271 */       return filterValues((SortedMap)unfiltered, valuePredicate);
/* 1398:     */     }
/* 1399:2272 */     if ((unfiltered instanceof BiMap)) {
/* 1400:2273 */       return filterValues((BiMap)unfiltered, valuePredicate);
/* 1401:     */     }
/* 1402:2275 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1403:     */   }
/* 1404:     */   
/* 1405:     */   public static <K, V> SortedMap<K, V> filterValues(SortedMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1406:     */   {
/* 1407:2311 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1408:     */   }
/* 1409:     */   
/* 1410:     */   @GwtIncompatible("NavigableMap")
/* 1411:     */   public static <K, V> NavigableMap<K, V> filterValues(NavigableMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1412:     */   {
/* 1413:2348 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1414:     */   }
/* 1415:     */   
/* 1416:     */   public static <K, V> BiMap<K, V> filterValues(BiMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1417:     */   {
/* 1418:2381 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1419:     */   }
/* 1420:     */   
/* 1421:     */   public static <K, V> Map<K, V> filterEntries(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1422:     */   {
/* 1423:2415 */     if ((unfiltered instanceof SortedMap)) {
/* 1424:2416 */       return filterEntries((SortedMap)unfiltered, entryPredicate);
/* 1425:     */     }
/* 1426:2417 */     if ((unfiltered instanceof BiMap)) {
/* 1427:2418 */       return filterEntries((BiMap)unfiltered, entryPredicate);
/* 1428:     */     }
/* 1429:2420 */     Preconditions.checkNotNull(entryPredicate);
/* 1430:2421 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredEntryMap((Map)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1431:     */   }
/* 1432:     */   
/* 1433:     */   public static <K, V> SortedMap<K, V> filterEntries(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1434:     */   {
/* 1435:2460 */     return Platform.mapsFilterSortedMap(unfiltered, entryPredicate);
/* 1436:     */   }
/* 1437:     */   
/* 1438:     */   static <K, V> SortedMap<K, V> filterSortedIgnoreNavigable(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1439:     */   {
/* 1440:2466 */     Preconditions.checkNotNull(entryPredicate);
/* 1441:2467 */     return (unfiltered instanceof FilteredEntrySortedMap) ? filterFiltered((FilteredEntrySortedMap)unfiltered, entryPredicate) : new FilteredEntrySortedMap((SortedMap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1442:     */   }
/* 1443:     */   
/* 1444:     */   @GwtIncompatible("NavigableMap")
/* 1445:     */   public static <K, V> NavigableMap<K, V> filterEntries(NavigableMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1446:     */   {
/* 1447:2507 */     Preconditions.checkNotNull(entryPredicate);
/* 1448:2508 */     return (unfiltered instanceof FilteredEntryNavigableMap) ? filterFiltered((FilteredEntryNavigableMap)unfiltered, entryPredicate) : new FilteredEntryNavigableMap((NavigableMap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1449:     */   }
/* 1450:     */   
/* 1451:     */   public static <K, V> BiMap<K, V> filterEntries(BiMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1452:     */   {
/* 1453:2542 */     Preconditions.checkNotNull(unfiltered);
/* 1454:2543 */     Preconditions.checkNotNull(entryPredicate);
/* 1455:2544 */     return (unfiltered instanceof FilteredEntryBiMap) ? filterFiltered((FilteredEntryBiMap)unfiltered, entryPredicate) : new FilteredEntryBiMap(unfiltered, entryPredicate);
/* 1456:     */   }
/* 1457:     */   
/* 1458:     */   private static <K, V> Map<K, V> filterFiltered(AbstractFilteredMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1459:     */   {
/* 1460:2555 */     return new FilteredEntryMap(map.unfiltered, Predicates.and(map.predicate, entryPredicate));
/* 1461:     */   }
/* 1462:     */   
/* 1463:     */   private static abstract class AbstractFilteredMap<K, V>
/* 1464:     */     extends Maps.ImprovedAbstractMap<K, V>
/* 1465:     */   {
/* 1466:     */     final Map<K, V> unfiltered;
/* 1467:     */     final Predicate<? super Map.Entry<K, V>> predicate;
/* 1468:     */     
/* 1469:     */     AbstractFilteredMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/* 1470:     */     {
/* 1471:2566 */       this.unfiltered = unfiltered;
/* 1472:2567 */       this.predicate = predicate;
/* 1473:     */     }
/* 1474:     */     
/* 1475:     */     boolean apply(@Nullable Object key, @Nullable V value)
/* 1476:     */     {
/* 1477:2574 */       K k = key;
/* 1478:2575 */       return this.predicate.apply(Maps.immutableEntry(k, value));
/* 1479:     */     }
/* 1480:     */     
/* 1481:     */     public V put(K key, V value)
/* 1482:     */     {
/* 1483:2579 */       Preconditions.checkArgument(apply(key, value));
/* 1484:2580 */       return this.unfiltered.put(key, value);
/* 1485:     */     }
/* 1486:     */     
/* 1487:     */     public void putAll(Map<? extends K, ? extends V> map)
/* 1488:     */     {
/* 1489:2584 */       for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 1490:2585 */         Preconditions.checkArgument(apply(entry.getKey(), entry.getValue()));
/* 1491:     */       }
/* 1492:2587 */       this.unfiltered.putAll(map);
/* 1493:     */     }
/* 1494:     */     
/* 1495:     */     public boolean containsKey(Object key)
/* 1496:     */     {
/* 1497:2591 */       return (this.unfiltered.containsKey(key)) && (apply(key, this.unfiltered.get(key)));
/* 1498:     */     }
/* 1499:     */     
/* 1500:     */     public V get(Object key)
/* 1501:     */     {
/* 1502:2595 */       V value = this.unfiltered.get(key);
/* 1503:2596 */       return (value != null) && (apply(key, value)) ? value : null;
/* 1504:     */     }
/* 1505:     */     
/* 1506:     */     public boolean isEmpty()
/* 1507:     */     {
/* 1508:2600 */       return entrySet().isEmpty();
/* 1509:     */     }
/* 1510:     */     
/* 1511:     */     public V remove(Object key)
/* 1512:     */     {
/* 1513:2604 */       return containsKey(key) ? this.unfiltered.remove(key) : null;
/* 1514:     */     }
/* 1515:     */     
/* 1516:     */     Collection<V> createValues()
/* 1517:     */     {
/* 1518:2609 */       return new Maps.FilteredMapValues(this, this.unfiltered, this.predicate);
/* 1519:     */     }
/* 1520:     */   }
/* 1521:     */   
/* 1522:     */   private static final class FilteredMapValues<K, V>
/* 1523:     */     extends Maps.Values<K, V>
/* 1524:     */   {
/* 1525:     */     Map<K, V> unfiltered;
/* 1526:     */     Predicate<? super Map.Entry<K, V>> predicate;
/* 1527:     */     
/* 1528:     */     FilteredMapValues(Map<K, V> filteredMap, Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/* 1529:     */     {
/* 1530:2619 */       super();
/* 1531:2620 */       this.unfiltered = unfiltered;
/* 1532:2621 */       this.predicate = predicate;
/* 1533:     */     }
/* 1534:     */     
/* 1535:     */     public boolean remove(Object o)
/* 1536:     */     {
/* 1537:2625 */       return Iterables.removeFirstMatching(this.unfiltered.entrySet(), Predicates.and(this.predicate, Maps.valuePredicateOnEntries(Predicates.equalTo(o)))) != null;
/* 1538:     */     }
/* 1539:     */     
/* 1540:     */     private boolean removeIf(Predicate<? super V> valuePredicate)
/* 1541:     */     {
/* 1542:2631 */       return Iterables.removeIf(this.unfiltered.entrySet(), Predicates.and(this.predicate, Maps.valuePredicateOnEntries(valuePredicate)));
/* 1543:     */     }
/* 1544:     */     
/* 1545:     */     public boolean removeAll(Collection<?> collection)
/* 1546:     */     {
/* 1547:2636 */       return removeIf(Predicates.in(collection));
/* 1548:     */     }
/* 1549:     */     
/* 1550:     */     public boolean retainAll(Collection<?> collection)
/* 1551:     */     {
/* 1552:2640 */       return removeIf(Predicates.not(Predicates.in(collection)));
/* 1553:     */     }
/* 1554:     */     
/* 1555:     */     public Object[] toArray()
/* 1556:     */     {
/* 1557:2645 */       return Lists.newArrayList(iterator()).toArray();
/* 1558:     */     }
/* 1559:     */     
/* 1560:     */     public <T> T[] toArray(T[] array)
/* 1561:     */     {
/* 1562:2649 */       return Lists.newArrayList(iterator()).toArray(array);
/* 1563:     */     }
/* 1564:     */   }
/* 1565:     */   
/* 1566:     */   private static class FilteredKeyMap<K, V>
/* 1567:     */     extends Maps.AbstractFilteredMap<K, V>
/* 1568:     */   {
/* 1569:     */     Predicate<? super K> keyPredicate;
/* 1570:     */     
/* 1571:     */     FilteredKeyMap(Map<K, V> unfiltered, Predicate<? super K> keyPredicate, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1572:     */     {
/* 1573:2658 */       super(entryPredicate);
/* 1574:2659 */       this.keyPredicate = keyPredicate;
/* 1575:     */     }
/* 1576:     */     
/* 1577:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/* 1578:     */     {
/* 1579:2664 */       return Sets.filter(this.unfiltered.entrySet(), this.predicate);
/* 1580:     */     }
/* 1581:     */     
/* 1582:     */     Set<K> createKeySet()
/* 1583:     */     {
/* 1584:2669 */       return Sets.filter(this.unfiltered.keySet(), this.keyPredicate);
/* 1585:     */     }
/* 1586:     */     
/* 1587:     */     public boolean containsKey(Object key)
/* 1588:     */     {
/* 1589:2677 */       return (this.unfiltered.containsKey(key)) && (this.keyPredicate.apply(key));
/* 1590:     */     }
/* 1591:     */   }
/* 1592:     */   
/* 1593:     */   static class FilteredEntryMap<K, V>
/* 1594:     */     extends Maps.AbstractFilteredMap<K, V>
/* 1595:     */   {
/* 1596:     */     final Set<Map.Entry<K, V>> filteredEntrySet;
/* 1597:     */     
/* 1598:     */     FilteredEntryMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1599:     */     {
/* 1600:2690 */       super(entryPredicate);
/* 1601:2691 */       this.filteredEntrySet = Sets.filter(unfiltered.entrySet(), this.predicate);
/* 1602:     */     }
/* 1603:     */     
/* 1604:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/* 1605:     */     {
/* 1606:2696 */       return new EntrySet(null);
/* 1607:     */     }
/* 1608:     */     
/* 1609:     */     private class EntrySet
/* 1610:     */       extends ForwardingSet<Map.Entry<K, V>>
/* 1611:     */     {
/* 1612:     */       private EntrySet() {}
/* 1613:     */       
/* 1614:     */       protected Set<Map.Entry<K, V>> delegate()
/* 1615:     */       {
/* 1616:2701 */         return Maps.FilteredEntryMap.this.filteredEntrySet;
/* 1617:     */       }
/* 1618:     */       
/* 1619:     */       public Iterator<Map.Entry<K, V>> iterator()
/* 1620:     */       {
/* 1621:2705 */         new TransformedIterator(Maps.FilteredEntryMap.this.filteredEntrySet.iterator())
/* 1622:     */         {
/* 1623:     */           Map.Entry<K, V> transform(final Map.Entry<K, V> entry)
/* 1624:     */           {
/* 1625:2708 */             new ForwardingMapEntry()
/* 1626:     */             {
/* 1627:     */               protected Map.Entry<K, V> delegate()
/* 1628:     */               {
/* 1629:2711 */                 return entry;
/* 1630:     */               }
/* 1631:     */               
/* 1632:     */               public V setValue(V newValue)
/* 1633:     */               {
/* 1634:2716 */                 Preconditions.checkArgument(Maps.FilteredEntryMap.this.apply(getKey(), newValue));
/* 1635:2717 */                 return super.setValue(newValue);
/* 1636:     */               }
/* 1637:     */             };
/* 1638:     */           }
/* 1639:     */         };
/* 1640:     */       }
/* 1641:     */     }
/* 1642:     */     
/* 1643:     */     Set<K> createKeySet()
/* 1644:     */     {
/* 1645:2727 */       return new KeySet();
/* 1646:     */     }
/* 1647:     */     
/* 1648:     */     class KeySet
/* 1649:     */       extends Maps.KeySet<K, V>
/* 1650:     */     {
/* 1651:     */       KeySet()
/* 1652:     */       {
/* 1653:2732 */         super();
/* 1654:     */       }
/* 1655:     */       
/* 1656:     */       public boolean remove(Object o)
/* 1657:     */       {
/* 1658:2736 */         if (Maps.FilteredEntryMap.this.containsKey(o))
/* 1659:     */         {
/* 1660:2737 */           Maps.FilteredEntryMap.this.unfiltered.remove(o);
/* 1661:2738 */           return true;
/* 1662:     */         }
/* 1663:2740 */         return false;
/* 1664:     */       }
/* 1665:     */       
/* 1666:     */       private boolean removeIf(Predicate<? super K> keyPredicate)
/* 1667:     */       {
/* 1668:2744 */         return Iterables.removeIf(Maps.FilteredEntryMap.this.unfiltered.entrySet(), Predicates.and(Maps.FilteredEntryMap.this.predicate, Maps.keyPredicateOnEntries(keyPredicate)));
/* 1669:     */       }
/* 1670:     */       
/* 1671:     */       public boolean removeAll(Collection<?> c)
/* 1672:     */       {
/* 1673:2750 */         return removeIf(Predicates.in(c));
/* 1674:     */       }
/* 1675:     */       
/* 1676:     */       public boolean retainAll(Collection<?> c)
/* 1677:     */       {
/* 1678:2755 */         return removeIf(Predicates.not(Predicates.in(c)));
/* 1679:     */       }
/* 1680:     */       
/* 1681:     */       public Object[] toArray()
/* 1682:     */       {
/* 1683:2760 */         return Lists.newArrayList(iterator()).toArray();
/* 1684:     */       }
/* 1685:     */       
/* 1686:     */       public <T> T[] toArray(T[] array)
/* 1687:     */       {
/* 1688:2764 */         return Lists.newArrayList(iterator()).toArray(array);
/* 1689:     */       }
/* 1690:     */     }
/* 1691:     */   }
/* 1692:     */   
/* 1693:     */   private static <K, V> SortedMap<K, V> filterFiltered(FilteredEntrySortedMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1694:     */   {
/* 1695:2776 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
/* 1696:     */     
/* 1697:2778 */     return new FilteredEntrySortedMap(map.sortedMap(), predicate);
/* 1698:     */   }
/* 1699:     */   
/* 1700:     */   private static class FilteredEntrySortedMap<K, V>
/* 1701:     */     extends Maps.FilteredEntryMap<K, V>
/* 1702:     */     implements SortedMap<K, V>
/* 1703:     */   {
/* 1704:     */     FilteredEntrySortedMap(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1705:     */     {
/* 1706:2786 */       super(entryPredicate);
/* 1707:     */     }
/* 1708:     */     
/* 1709:     */     SortedMap<K, V> sortedMap()
/* 1710:     */     {
/* 1711:2790 */       return (SortedMap)this.unfiltered;
/* 1712:     */     }
/* 1713:     */     
/* 1714:     */     public SortedSet<K> keySet()
/* 1715:     */     {
/* 1716:2794 */       return (SortedSet)super.keySet();
/* 1717:     */     }
/* 1718:     */     
/* 1719:     */     SortedSet<K> createKeySet()
/* 1720:     */     {
/* 1721:2799 */       return new SortedKeySet();
/* 1722:     */     }
/* 1723:     */     
/* 1724:     */     class SortedKeySet
/* 1725:     */       extends Maps.FilteredEntryMap<K, V>.KeySet
/* 1726:     */       implements SortedSet<K>
/* 1727:     */     {
/* 1728:     */       SortedKeySet()
/* 1729:     */       {
/* 1730:2802 */         super();
/* 1731:     */       }
/* 1732:     */       
/* 1733:     */       public Comparator<? super K> comparator()
/* 1734:     */       {
/* 1735:2805 */         return Maps.FilteredEntrySortedMap.this.sortedMap().comparator();
/* 1736:     */       }
/* 1737:     */       
/* 1738:     */       public SortedSet<K> subSet(K fromElement, K toElement)
/* 1739:     */       {
/* 1740:2810 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.subMap(fromElement, toElement).keySet();
/* 1741:     */       }
/* 1742:     */       
/* 1743:     */       public SortedSet<K> headSet(K toElement)
/* 1744:     */       {
/* 1745:2815 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.headMap(toElement).keySet();
/* 1746:     */       }
/* 1747:     */       
/* 1748:     */       public SortedSet<K> tailSet(K fromElement)
/* 1749:     */       {
/* 1750:2820 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.tailMap(fromElement).keySet();
/* 1751:     */       }
/* 1752:     */       
/* 1753:     */       public K first()
/* 1754:     */       {
/* 1755:2825 */         return Maps.FilteredEntrySortedMap.this.firstKey();
/* 1756:     */       }
/* 1757:     */       
/* 1758:     */       public K last()
/* 1759:     */       {
/* 1760:2830 */         return Maps.FilteredEntrySortedMap.this.lastKey();
/* 1761:     */       }
/* 1762:     */     }
/* 1763:     */     
/* 1764:     */     public Comparator<? super K> comparator()
/* 1765:     */     {
/* 1766:2835 */       return sortedMap().comparator();
/* 1767:     */     }
/* 1768:     */     
/* 1769:     */     public K firstKey()
/* 1770:     */     {
/* 1771:2840 */       return keySet().iterator().next();
/* 1772:     */     }
/* 1773:     */     
/* 1774:     */     public K lastKey()
/* 1775:     */     {
/* 1776:2844 */       SortedMap<K, V> headMap = sortedMap();
/* 1777:     */       for (;;)
/* 1778:     */       {
/* 1779:2847 */         K key = headMap.lastKey();
/* 1780:2848 */         if (apply(key, this.unfiltered.get(key))) {
/* 1781:2849 */           return key;
/* 1782:     */         }
/* 1783:2851 */         headMap = sortedMap().headMap(key);
/* 1784:     */       }
/* 1785:     */     }
/* 1786:     */     
/* 1787:     */     public SortedMap<K, V> headMap(K toKey)
/* 1788:     */     {
/* 1789:2856 */       return new FilteredEntrySortedMap(sortedMap().headMap(toKey), this.predicate);
/* 1790:     */     }
/* 1791:     */     
/* 1792:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1793:     */     {
/* 1794:2860 */       return new FilteredEntrySortedMap(sortedMap().subMap(fromKey, toKey), this.predicate);
/* 1795:     */     }
/* 1796:     */     
/* 1797:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1798:     */     {
/* 1799:2865 */       return new FilteredEntrySortedMap(sortedMap().tailMap(fromKey), this.predicate);
/* 1800:     */     }
/* 1801:     */   }
/* 1802:     */   
/* 1803:     */   @GwtIncompatible("NavigableMap")
/* 1804:     */   private static <K, V> NavigableMap<K, V> filterFiltered(FilteredEntryNavigableMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1805:     */   {
/* 1806:2878 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.entryPredicate, entryPredicate);
/* 1807:     */     
/* 1808:2880 */     return new FilteredEntryNavigableMap(map.unfiltered, predicate);
/* 1809:     */   }
/* 1810:     */   
/* 1811:     */   @GwtIncompatible("NavigableMap")
/* 1812:     */   private static class FilteredEntryNavigableMap<K, V>
/* 1813:     */     extends AbstractNavigableMap<K, V>
/* 1814:     */   {
/* 1815:     */     private final NavigableMap<K, V> unfiltered;
/* 1816:     */     private final Predicate<? super Map.Entry<K, V>> entryPredicate;
/* 1817:     */     private final Map<K, V> filteredDelegate;
/* 1818:     */     
/* 1819:     */     FilteredEntryNavigableMap(NavigableMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1820:     */     {
/* 1821:2897 */       this.unfiltered = ((NavigableMap)Preconditions.checkNotNull(unfiltered));
/* 1822:2898 */       this.entryPredicate = entryPredicate;
/* 1823:2899 */       this.filteredDelegate = new Maps.FilteredEntryMap(unfiltered, entryPredicate);
/* 1824:     */     }
/* 1825:     */     
/* 1826:     */     public Comparator<? super K> comparator()
/* 1827:     */     {
/* 1828:2904 */       return this.unfiltered.comparator();
/* 1829:     */     }
/* 1830:     */     
/* 1831:     */     public NavigableSet<K> navigableKeySet()
/* 1832:     */     {
/* 1833:2909 */       new Maps.NavigableKeySet(this)
/* 1834:     */       {
/* 1835:     */         public boolean removeAll(Collection<?> c)
/* 1836:     */         {
/* 1837:2912 */           return Iterators.removeIf(Maps.FilteredEntryNavigableMap.this.unfiltered.entrySet().iterator(), Predicates.and(Maps.FilteredEntryNavigableMap.this.entryPredicate, Maps.keyPredicateOnEntries(Predicates.in(c))));
/* 1838:     */         }
/* 1839:     */         
/* 1840:     */         public boolean retainAll(Collection<?> c)
/* 1841:     */         {
/* 1842:2918 */           return Iterators.removeIf(Maps.FilteredEntryNavigableMap.this.unfiltered.entrySet().iterator(), Predicates.and(Maps.FilteredEntryNavigableMap.this.entryPredicate, Maps.keyPredicateOnEntries(Predicates.not(Predicates.in(c)))));
/* 1843:     */         }
/* 1844:     */       };
/* 1845:     */     }
/* 1846:     */     
/* 1847:     */     public Collection<V> values()
/* 1848:     */     {
/* 1849:2926 */       return new Maps.FilteredMapValues(this, this.unfiltered, this.entryPredicate);
/* 1850:     */     }
/* 1851:     */     
/* 1852:     */     Iterator<Map.Entry<K, V>> entryIterator()
/* 1853:     */     {
/* 1854:2931 */       return Iterators.filter(this.unfiltered.entrySet().iterator(), this.entryPredicate);
/* 1855:     */     }
/* 1856:     */     
/* 1857:     */     Iterator<Map.Entry<K, V>> descendingEntryIterator()
/* 1858:     */     {
/* 1859:2936 */       return Iterators.filter(this.unfiltered.descendingMap().entrySet().iterator(), this.entryPredicate);
/* 1860:     */     }
/* 1861:     */     
/* 1862:     */     public int size()
/* 1863:     */     {
/* 1864:2941 */       return this.filteredDelegate.size();
/* 1865:     */     }
/* 1866:     */     
/* 1867:     */     @Nullable
/* 1868:     */     public V get(@Nullable Object key)
/* 1869:     */     {
/* 1870:2947 */       return this.filteredDelegate.get(key);
/* 1871:     */     }
/* 1872:     */     
/* 1873:     */     public boolean containsKey(@Nullable Object key)
/* 1874:     */     {
/* 1875:2952 */       return this.filteredDelegate.containsKey(key);
/* 1876:     */     }
/* 1877:     */     
/* 1878:     */     public V put(K key, V value)
/* 1879:     */     {
/* 1880:2957 */       return this.filteredDelegate.put(key, value);
/* 1881:     */     }
/* 1882:     */     
/* 1883:     */     public V remove(@Nullable Object key)
/* 1884:     */     {
/* 1885:2962 */       return this.filteredDelegate.remove(key);
/* 1886:     */     }
/* 1887:     */     
/* 1888:     */     public void putAll(Map<? extends K, ? extends V> m)
/* 1889:     */     {
/* 1890:2967 */       this.filteredDelegate.putAll(m);
/* 1891:     */     }
/* 1892:     */     
/* 1893:     */     public void clear()
/* 1894:     */     {
/* 1895:2972 */       this.filteredDelegate.clear();
/* 1896:     */     }
/* 1897:     */     
/* 1898:     */     public Set<Map.Entry<K, V>> entrySet()
/* 1899:     */     {
/* 1900:2977 */       return this.filteredDelegate.entrySet();
/* 1901:     */     }
/* 1902:     */     
/* 1903:     */     public Map.Entry<K, V> pollFirstEntry()
/* 1904:     */     {
/* 1905:2982 */       return (Map.Entry)Iterables.removeFirstMatching(this.unfiltered.entrySet(), this.entryPredicate);
/* 1906:     */     }
/* 1907:     */     
/* 1908:     */     public Map.Entry<K, V> pollLastEntry()
/* 1909:     */     {
/* 1910:2987 */       return (Map.Entry)Iterables.removeFirstMatching(this.unfiltered.descendingMap().entrySet(), this.entryPredicate);
/* 1911:     */     }
/* 1912:     */     
/* 1913:     */     public NavigableMap<K, V> descendingMap()
/* 1914:     */     {
/* 1915:2992 */       return Maps.filterEntries(this.unfiltered.descendingMap(), this.entryPredicate);
/* 1916:     */     }
/* 1917:     */     
/* 1918:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1919:     */     {
/* 1920:2998 */       return Maps.filterEntries(this.unfiltered.subMap(fromKey, fromInclusive, toKey, toInclusive), this.entryPredicate);
/* 1921:     */     }
/* 1922:     */     
/* 1923:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 1924:     */     {
/* 1925:3004 */       return Maps.filterEntries(this.unfiltered.headMap(toKey, inclusive), this.entryPredicate);
/* 1926:     */     }
/* 1927:     */     
/* 1928:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 1929:     */     {
/* 1930:3009 */       return Maps.filterEntries(this.unfiltered.tailMap(fromKey, inclusive), this.entryPredicate);
/* 1931:     */     }
/* 1932:     */   }
/* 1933:     */   
/* 1934:     */   private static <K, V> BiMap<K, V> filterFiltered(FilteredEntryBiMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1935:     */   {
/* 1936:3019 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
/* 1937:3020 */     return new FilteredEntryBiMap(map.unfiltered(), predicate);
/* 1938:     */   }
/* 1939:     */   
/* 1940:     */   static final class FilteredEntryBiMap<K, V>
/* 1941:     */     extends Maps.FilteredEntryMap<K, V>
/* 1942:     */     implements BiMap<K, V>
/* 1943:     */   {
/* 1944:     */     private final BiMap<V, K> inverse;
/* 1945:     */     
/* 1946:     */     private static <K, V> Predicate<Map.Entry<V, K>> inversePredicate(Predicate<? super Map.Entry<K, V>> forwardPredicate)
/* 1947:     */     {
/* 1948:3029 */       new Predicate()
/* 1949:     */       {
/* 1950:     */         public boolean apply(Map.Entry<V, K> input)
/* 1951:     */         {
/* 1952:3032 */           return this.val$forwardPredicate.apply(Maps.immutableEntry(input.getValue(), input.getKey()));
/* 1953:     */         }
/* 1954:     */       };
/* 1955:     */     }
/* 1956:     */     
/* 1957:     */     FilteredEntryBiMap(BiMap<K, V> delegate, Predicate<? super Map.Entry<K, V>> predicate)
/* 1958:     */     {
/* 1959:3040 */       super(predicate);
/* 1960:3041 */       this.inverse = new FilteredEntryBiMap(delegate.inverse(), inversePredicate(predicate), this);
/* 1961:     */     }
/* 1962:     */     
/* 1963:     */     private FilteredEntryBiMap(BiMap<K, V> delegate, Predicate<? super Map.Entry<K, V>> predicate, BiMap<V, K> inverse)
/* 1964:     */     {
/* 1965:3048 */       super(predicate);
/* 1966:3049 */       this.inverse = inverse;
/* 1967:     */     }
/* 1968:     */     
/* 1969:     */     BiMap<K, V> unfiltered()
/* 1970:     */     {
/* 1971:3053 */       return (BiMap)this.unfiltered;
/* 1972:     */     }
/* 1973:     */     
/* 1974:     */     public V forcePut(@Nullable K key, @Nullable V value)
/* 1975:     */     {
/* 1976:3058 */       Preconditions.checkArgument(apply(key, value));
/* 1977:3059 */       return unfiltered().forcePut(key, value);
/* 1978:     */     }
/* 1979:     */     
/* 1980:     */     public BiMap<V, K> inverse()
/* 1981:     */     {
/* 1982:3064 */       return this.inverse;
/* 1983:     */     }
/* 1984:     */     
/* 1985:     */     public Set<V> values()
/* 1986:     */     {
/* 1987:3069 */       return this.inverse.keySet();
/* 1988:     */     }
/* 1989:     */   }
/* 1990:     */   
/* 1991:     */   @GwtIncompatible("NavigableMap")
/* 1992:     */   public static <K, V> NavigableMap<K, V> unmodifiableNavigableMap(NavigableMap<K, V> map)
/* 1993:     */   {
/* 1994:3087 */     Preconditions.checkNotNull(map);
/* 1995:3088 */     if ((map instanceof UnmodifiableNavigableMap)) {
/* 1996:3089 */       return map;
/* 1997:     */     }
/* 1998:3091 */     return new UnmodifiableNavigableMap(map);
/* 1999:     */   }
/* 2000:     */   
/* 2001:     */   @Nullable
/* 2002:     */   private static <K, V> Map.Entry<K, V> unmodifiableOrNull(@Nullable Map.Entry<K, V> entry)
/* 2003:     */   {
/* 2004:3096 */     return entry == null ? null : unmodifiableEntry(entry);
/* 2005:     */   }
/* 2006:     */   
/* 2007:     */   @GwtIncompatible("NavigableMap")
/* 2008:     */   static class UnmodifiableNavigableMap<K, V>
/* 2009:     */     extends ForwardingSortedMap<K, V>
/* 2010:     */     implements NavigableMap<K, V>, Serializable
/* 2011:     */   {
/* 2012:     */     private final NavigableMap<K, V> delegate;
/* 2013:     */     private transient UnmodifiableNavigableMap<K, V> descendingMap;
/* 2014:     */     
/* 2015:     */     UnmodifiableNavigableMap(NavigableMap<K, V> delegate)
/* 2016:     */     {
/* 2017:3105 */       this.delegate = delegate;
/* 2018:     */     }
/* 2019:     */     
/* 2020:     */     UnmodifiableNavigableMap(NavigableMap<K, V> delegate, UnmodifiableNavigableMap<K, V> descendingMap)
/* 2021:     */     {
/* 2022:3110 */       this.delegate = delegate;
/* 2023:3111 */       this.descendingMap = descendingMap;
/* 2024:     */     }
/* 2025:     */     
/* 2026:     */     protected SortedMap<K, V> delegate()
/* 2027:     */     {
/* 2028:3116 */       return Collections.unmodifiableSortedMap(this.delegate);
/* 2029:     */     }
/* 2030:     */     
/* 2031:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 2032:     */     {
/* 2033:3121 */       return Maps.unmodifiableOrNull(this.delegate.lowerEntry(key));
/* 2034:     */     }
/* 2035:     */     
/* 2036:     */     public K lowerKey(K key)
/* 2037:     */     {
/* 2038:3126 */       return this.delegate.lowerKey(key);
/* 2039:     */     }
/* 2040:     */     
/* 2041:     */     public Map.Entry<K, V> floorEntry(K key)
/* 2042:     */     {
/* 2043:3131 */       return Maps.unmodifiableOrNull(this.delegate.floorEntry(key));
/* 2044:     */     }
/* 2045:     */     
/* 2046:     */     public K floorKey(K key)
/* 2047:     */     {
/* 2048:3136 */       return this.delegate.floorKey(key);
/* 2049:     */     }
/* 2050:     */     
/* 2051:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 2052:     */     {
/* 2053:3141 */       return Maps.unmodifiableOrNull(this.delegate.ceilingEntry(key));
/* 2054:     */     }
/* 2055:     */     
/* 2056:     */     public K ceilingKey(K key)
/* 2057:     */     {
/* 2058:3146 */       return this.delegate.ceilingKey(key);
/* 2059:     */     }
/* 2060:     */     
/* 2061:     */     public Map.Entry<K, V> higherEntry(K key)
/* 2062:     */     {
/* 2063:3151 */       return Maps.unmodifiableOrNull(this.delegate.higherEntry(key));
/* 2064:     */     }
/* 2065:     */     
/* 2066:     */     public K higherKey(K key)
/* 2067:     */     {
/* 2068:3156 */       return this.delegate.higherKey(key);
/* 2069:     */     }
/* 2070:     */     
/* 2071:     */     public Map.Entry<K, V> firstEntry()
/* 2072:     */     {
/* 2073:3161 */       return Maps.unmodifiableOrNull(this.delegate.firstEntry());
/* 2074:     */     }
/* 2075:     */     
/* 2076:     */     public Map.Entry<K, V> lastEntry()
/* 2077:     */     {
/* 2078:3166 */       return Maps.unmodifiableOrNull(this.delegate.lastEntry());
/* 2079:     */     }
/* 2080:     */     
/* 2081:     */     public final Map.Entry<K, V> pollFirstEntry()
/* 2082:     */     {
/* 2083:3171 */       throw new UnsupportedOperationException();
/* 2084:     */     }
/* 2085:     */     
/* 2086:     */     public final Map.Entry<K, V> pollLastEntry()
/* 2087:     */     {
/* 2088:3176 */       throw new UnsupportedOperationException();
/* 2089:     */     }
/* 2090:     */     
/* 2091:     */     public NavigableMap<K, V> descendingMap()
/* 2092:     */     {
/* 2093:3183 */       UnmodifiableNavigableMap<K, V> result = this.descendingMap;
/* 2094:3184 */       return result == null ? (this.descendingMap = new UnmodifiableNavigableMap(this.delegate.descendingMap(), this)) : result;
/* 2095:     */     }
/* 2096:     */     
/* 2097:     */     public Set<K> keySet()
/* 2098:     */     {
/* 2099:3191 */       return navigableKeySet();
/* 2100:     */     }
/* 2101:     */     
/* 2102:     */     public NavigableSet<K> navigableKeySet()
/* 2103:     */     {
/* 2104:3196 */       return Sets.unmodifiableNavigableSet(this.delegate.navigableKeySet());
/* 2105:     */     }
/* 2106:     */     
/* 2107:     */     public NavigableSet<K> descendingKeySet()
/* 2108:     */     {
/* 2109:3201 */       return Sets.unmodifiableNavigableSet(this.delegate.descendingKeySet());
/* 2110:     */     }
/* 2111:     */     
/* 2112:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 2113:     */     {
/* 2114:3206 */       return subMap(fromKey, true, toKey, false);
/* 2115:     */     }
/* 2116:     */     
/* 2117:     */     public SortedMap<K, V> headMap(K toKey)
/* 2118:     */     {
/* 2119:3211 */       return headMap(toKey, false);
/* 2120:     */     }
/* 2121:     */     
/* 2122:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 2123:     */     {
/* 2124:3216 */       return tailMap(fromKey, true);
/* 2125:     */     }
/* 2126:     */     
/* 2127:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 2128:     */     {
/* 2129:3223 */       return Maps.unmodifiableNavigableMap(this.delegate.subMap(fromKey, fromInclusive, toKey, toInclusive));
/* 2130:     */     }
/* 2131:     */     
/* 2132:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 2133:     */     {
/* 2134:3232 */       return Maps.unmodifiableNavigableMap(this.delegate.headMap(toKey, inclusive));
/* 2135:     */     }
/* 2136:     */     
/* 2137:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 2138:     */     {
/* 2139:3237 */       return Maps.unmodifiableNavigableMap(this.delegate.tailMap(fromKey, inclusive));
/* 2140:     */     }
/* 2141:     */   }
/* 2142:     */   
/* 2143:     */   @GwtIncompatible("NavigableMap")
/* 2144:     */   public static <K, V> NavigableMap<K, V> synchronizedNavigableMap(NavigableMap<K, V> navigableMap)
/* 2145:     */   {
/* 2146:3292 */     return Synchronized.navigableMap(navigableMap);
/* 2147:     */   }
/* 2148:     */   
/* 2149:     */   @GwtCompatible
/* 2150:     */   static abstract class ImprovedAbstractMap<K, V>
/* 2151:     */     extends AbstractMap<K, V>
/* 2152:     */   {
/* 2153:     */     private transient Set<Map.Entry<K, V>> entrySet;
/* 2154:     */     private transient Set<K> keySet;
/* 2155:     */     private transient Collection<V> values;
/* 2156:     */     
/* 2157:     */     abstract Set<Map.Entry<K, V>> createEntrySet();
/* 2158:     */     
/* 2159:     */     public Set<Map.Entry<K, V>> entrySet()
/* 2160:     */     {
/* 2161:3314 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 2162:3315 */       return result == null ? (this.entrySet = createEntrySet()) : result;
/* 2163:     */     }
/* 2164:     */     
/* 2165:     */     public Set<K> keySet()
/* 2166:     */     {
/* 2167:3321 */       Set<K> result = this.keySet;
/* 2168:3322 */       return result == null ? (this.keySet = createKeySet()) : result;
/* 2169:     */     }
/* 2170:     */     
/* 2171:     */     Set<K> createKeySet()
/* 2172:     */     {
/* 2173:3326 */       return new Maps.KeySet(this);
/* 2174:     */     }
/* 2175:     */     
/* 2176:     */     public Collection<V> values()
/* 2177:     */     {
/* 2178:3332 */       Collection<V> result = this.values;
/* 2179:3333 */       return result == null ? (this.values = createValues()) : result;
/* 2180:     */     }
/* 2181:     */     
/* 2182:     */     Collection<V> createValues()
/* 2183:     */     {
/* 2184:3337 */       return new Maps.Values(this);
/* 2185:     */     }
/* 2186:     */   }
/* 2187:     */   
/* 2188:     */   static <V> V safeGet(Map<?, V> map, @Nullable Object key)
/* 2189:     */   {
/* 2190:3346 */     Preconditions.checkNotNull(map);
/* 2191:     */     try
/* 2192:     */     {
/* 2193:3348 */       return map.get(key);
/* 2194:     */     }
/* 2195:     */     catch (ClassCastException e)
/* 2196:     */     {
/* 2197:3350 */       return null;
/* 2198:     */     }
/* 2199:     */     catch (NullPointerException e) {}
/* 2200:3352 */     return null;
/* 2201:     */   }
/* 2202:     */   
/* 2203:     */   static boolean safeContainsKey(Map<?, ?> map, Object key)
/* 2204:     */   {
/* 2205:3361 */     Preconditions.checkNotNull(map);
/* 2206:     */     try
/* 2207:     */     {
/* 2208:3363 */       return map.containsKey(key);
/* 2209:     */     }
/* 2210:     */     catch (ClassCastException e)
/* 2211:     */     {
/* 2212:3365 */       return false;
/* 2213:     */     }
/* 2214:     */     catch (NullPointerException e) {}
/* 2215:3367 */     return false;
/* 2216:     */   }
/* 2217:     */   
/* 2218:     */   static <V> V safeRemove(Map<?, V> map, Object key)
/* 2219:     */   {
/* 2220:3376 */     Preconditions.checkNotNull(map);
/* 2221:     */     try
/* 2222:     */     {
/* 2223:3378 */       return map.remove(key);
/* 2224:     */     }
/* 2225:     */     catch (ClassCastException e)
/* 2226:     */     {
/* 2227:3380 */       return null;
/* 2228:     */     }
/* 2229:     */     catch (NullPointerException e) {}
/* 2230:3382 */     return null;
/* 2231:     */   }
/* 2232:     */   
/* 2233:     */   static boolean containsKeyImpl(Map<?, ?> map, @Nullable Object key)
/* 2234:     */   {
/* 2235:3390 */     return Iterators.contains(keyIterator(map.entrySet().iterator()), key);
/* 2236:     */   }
/* 2237:     */   
/* 2238:     */   static boolean containsValueImpl(Map<?, ?> map, @Nullable Object value)
/* 2239:     */   {
/* 2240:3397 */     return Iterators.contains(valueIterator(map.entrySet().iterator()), value);
/* 2241:     */   }
/* 2242:     */   
/* 2243:     */   static <K, V> boolean containsEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/* 2244:     */   {
/* 2245:3414 */     if (!(o instanceof Map.Entry)) {
/* 2246:3415 */       return false;
/* 2247:     */     }
/* 2248:3417 */     return c.contains(unmodifiableEntry((Map.Entry)o));
/* 2249:     */   }
/* 2250:     */   
/* 2251:     */   static <K, V> boolean removeEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/* 2252:     */   {
/* 2253:3434 */     if (!(o instanceof Map.Entry)) {
/* 2254:3435 */       return false;
/* 2255:     */     }
/* 2256:3437 */     return c.remove(unmodifiableEntry((Map.Entry)o));
/* 2257:     */   }
/* 2258:     */   
/* 2259:     */   static boolean equalsImpl(Map<?, ?> map, Object object)
/* 2260:     */   {
/* 2261:3444 */     if (map == object) {
/* 2262:3445 */       return true;
/* 2263:     */     }
/* 2264:3446 */     if ((object instanceof Map))
/* 2265:     */     {
/* 2266:3447 */       Map<?, ?> o = (Map)object;
/* 2267:3448 */       return map.entrySet().equals(o.entrySet());
/* 2268:     */     }
/* 2269:3450 */     return false;
/* 2270:     */   }
/* 2271:     */   
/* 2272:3453 */   static final Joiner.MapJoiner STANDARD_JOINER = Collections2.STANDARD_JOINER.withKeyValueSeparator("=");
/* 2273:     */   
/* 2274:     */   static String toStringImpl(Map<?, ?> map)
/* 2275:     */   {
/* 2276:3460 */     StringBuilder sb = Collections2.newStringBuilderForCollection(map.size()).append('{');
/* 2277:     */     
/* 2278:3462 */     STANDARD_JOINER.appendTo(sb, map);
/* 2279:3463 */     return '}';
/* 2280:     */   }
/* 2281:     */   
/* 2282:     */   static <K, V> void putAllImpl(Map<K, V> self, Map<? extends K, ? extends V> map)
/* 2283:     */   {
/* 2284:3471 */     for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 2285:3472 */       self.put(entry.getKey(), entry.getValue());
/* 2286:     */     }
/* 2287:     */   }
/* 2288:     */   
/* 2289:     */   static class KeySet<K, V>
/* 2290:     */     extends Sets.ImprovedAbstractSet<K>
/* 2291:     */   {
/* 2292:     */     final Map<K, V> map;
/* 2293:     */     
/* 2294:     */     KeySet(Map<K, V> map)
/* 2295:     */     {
/* 2296:3480 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 2297:     */     }
/* 2298:     */     
/* 2299:     */     Map<K, V> map()
/* 2300:     */     {
/* 2301:3484 */       return this.map;
/* 2302:     */     }
/* 2303:     */     
/* 2304:     */     public Iterator<K> iterator()
/* 2305:     */     {
/* 2306:3488 */       return Maps.keyIterator(map().entrySet().iterator());
/* 2307:     */     }
/* 2308:     */     
/* 2309:     */     public int size()
/* 2310:     */     {
/* 2311:3492 */       return map().size();
/* 2312:     */     }
/* 2313:     */     
/* 2314:     */     public boolean isEmpty()
/* 2315:     */     {
/* 2316:3496 */       return map().isEmpty();
/* 2317:     */     }
/* 2318:     */     
/* 2319:     */     public boolean contains(Object o)
/* 2320:     */     {
/* 2321:3500 */       return map().containsKey(o);
/* 2322:     */     }
/* 2323:     */     
/* 2324:     */     public boolean remove(Object o)
/* 2325:     */     {
/* 2326:3504 */       if (contains(o))
/* 2327:     */       {
/* 2328:3505 */         map().remove(o);
/* 2329:3506 */         return true;
/* 2330:     */       }
/* 2331:3508 */       return false;
/* 2332:     */     }
/* 2333:     */     
/* 2334:     */     public void clear()
/* 2335:     */     {
/* 2336:3512 */       map().clear();
/* 2337:     */     }
/* 2338:     */   }
/* 2339:     */   
/* 2340:     */   @Nullable
/* 2341:     */   static <K> K keyOrNull(@Nullable Map.Entry<K, ?> entry)
/* 2342:     */   {
/* 2343:3518 */     return entry == null ? null : entry.getKey();
/* 2344:     */   }
/* 2345:     */   
/* 2346:     */   @Nullable
/* 2347:     */   static <V> V valueOrNull(@Nullable Map.Entry<?, V> entry)
/* 2348:     */   {
/* 2349:3523 */     return entry == null ? null : entry.getValue();
/* 2350:     */   }
/* 2351:     */   
/* 2352:     */   static class SortedKeySet<K, V>
/* 2353:     */     extends Maps.KeySet<K, V>
/* 2354:     */     implements SortedSet<K>
/* 2355:     */   {
/* 2356:     */     SortedKeySet(SortedMap<K, V> map)
/* 2357:     */     {
/* 2358:3528 */       super();
/* 2359:     */     }
/* 2360:     */     
/* 2361:     */     SortedMap<K, V> map()
/* 2362:     */     {
/* 2363:3533 */       return (SortedMap)super.map();
/* 2364:     */     }
/* 2365:     */     
/* 2366:     */     public Comparator<? super K> comparator()
/* 2367:     */     {
/* 2368:3538 */       return map().comparator();
/* 2369:     */     }
/* 2370:     */     
/* 2371:     */     public SortedSet<K> subSet(K fromElement, K toElement)
/* 2372:     */     {
/* 2373:3543 */       return new SortedKeySet(map().subMap(fromElement, toElement));
/* 2374:     */     }
/* 2375:     */     
/* 2376:     */     public SortedSet<K> headSet(K toElement)
/* 2377:     */     {
/* 2378:3548 */       return new SortedKeySet(map().headMap(toElement));
/* 2379:     */     }
/* 2380:     */     
/* 2381:     */     public SortedSet<K> tailSet(K fromElement)
/* 2382:     */     {
/* 2383:3553 */       return new SortedKeySet(map().tailMap(fromElement));
/* 2384:     */     }
/* 2385:     */     
/* 2386:     */     public K first()
/* 2387:     */     {
/* 2388:3558 */       return map().firstKey();
/* 2389:     */     }
/* 2390:     */     
/* 2391:     */     public K last()
/* 2392:     */     {
/* 2393:3563 */       return map().lastKey();
/* 2394:     */     }
/* 2395:     */   }
/* 2396:     */   
/* 2397:     */   @GwtIncompatible("NavigableMap")
/* 2398:     */   static class NavigableKeySet<K, V>
/* 2399:     */     extends Maps.SortedKeySet<K, V>
/* 2400:     */     implements NavigableSet<K>
/* 2401:     */   {
/* 2402:     */     NavigableKeySet(NavigableMap<K, V> map)
/* 2403:     */     {
/* 2404:3570 */       super();
/* 2405:     */     }
/* 2406:     */     
/* 2407:     */     NavigableMap<K, V> map()
/* 2408:     */     {
/* 2409:3575 */       return (NavigableMap)this.map;
/* 2410:     */     }
/* 2411:     */     
/* 2412:     */     public K lower(K e)
/* 2413:     */     {
/* 2414:3580 */       return map().lowerKey(e);
/* 2415:     */     }
/* 2416:     */     
/* 2417:     */     public K floor(K e)
/* 2418:     */     {
/* 2419:3585 */       return map().floorKey(e);
/* 2420:     */     }
/* 2421:     */     
/* 2422:     */     public K ceiling(K e)
/* 2423:     */     {
/* 2424:3590 */       return map().ceilingKey(e);
/* 2425:     */     }
/* 2426:     */     
/* 2427:     */     public K higher(K e)
/* 2428:     */     {
/* 2429:3595 */       return map().higherKey(e);
/* 2430:     */     }
/* 2431:     */     
/* 2432:     */     public K pollFirst()
/* 2433:     */     {
/* 2434:3600 */       return Maps.keyOrNull(map().pollFirstEntry());
/* 2435:     */     }
/* 2436:     */     
/* 2437:     */     public K pollLast()
/* 2438:     */     {
/* 2439:3605 */       return Maps.keyOrNull(map().pollLastEntry());
/* 2440:     */     }
/* 2441:     */     
/* 2442:     */     public NavigableSet<K> descendingSet()
/* 2443:     */     {
/* 2444:3610 */       return map().descendingKeySet();
/* 2445:     */     }
/* 2446:     */     
/* 2447:     */     public Iterator<K> descendingIterator()
/* 2448:     */     {
/* 2449:3615 */       return descendingSet().iterator();
/* 2450:     */     }
/* 2451:     */     
/* 2452:     */     public NavigableSet<K> subSet(K fromElement, boolean fromInclusive, K toElement, boolean toInclusive)
/* 2453:     */     {
/* 2454:3624 */       return map().subMap(fromElement, fromInclusive, toElement, toInclusive).navigableKeySet();
/* 2455:     */     }
/* 2456:     */     
/* 2457:     */     public NavigableSet<K> headSet(K toElement, boolean inclusive)
/* 2458:     */     {
/* 2459:3629 */       return map().headMap(toElement, inclusive).navigableKeySet();
/* 2460:     */     }
/* 2461:     */     
/* 2462:     */     public NavigableSet<K> tailSet(K fromElement, boolean inclusive)
/* 2463:     */     {
/* 2464:3634 */       return map().tailMap(fromElement, inclusive).navigableKeySet();
/* 2465:     */     }
/* 2466:     */     
/* 2467:     */     public SortedSet<K> subSet(K fromElement, K toElement)
/* 2468:     */     {
/* 2469:3639 */       return subSet(fromElement, true, toElement, false);
/* 2470:     */     }
/* 2471:     */     
/* 2472:     */     public SortedSet<K> headSet(K toElement)
/* 2473:     */     {
/* 2474:3644 */       return headSet(toElement, false);
/* 2475:     */     }
/* 2476:     */     
/* 2477:     */     public SortedSet<K> tailSet(K fromElement)
/* 2478:     */     {
/* 2479:3649 */       return tailSet(fromElement, true);
/* 2480:     */     }
/* 2481:     */   }
/* 2482:     */   
/* 2483:     */   static class Values<K, V>
/* 2484:     */     extends AbstractCollection<V>
/* 2485:     */   {
/* 2486:     */     final Map<K, V> map;
/* 2487:     */     
/* 2488:     */     Values(Map<K, V> map)
/* 2489:     */     {
/* 2490:3657 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 2491:     */     }
/* 2492:     */     
/* 2493:     */     final Map<K, V> map()
/* 2494:     */     {
/* 2495:3661 */       return this.map;
/* 2496:     */     }
/* 2497:     */     
/* 2498:     */     public Iterator<V> iterator()
/* 2499:     */     {
/* 2500:3665 */       return Maps.valueIterator(map().entrySet().iterator());
/* 2501:     */     }
/* 2502:     */     
/* 2503:     */     public boolean remove(Object o)
/* 2504:     */     {
/* 2505:     */       try
/* 2506:     */       {
/* 2507:3670 */         return super.remove(o);
/* 2508:     */       }
/* 2509:     */       catch (UnsupportedOperationException e)
/* 2510:     */       {
/* 2511:3672 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2512:3673 */           if (Objects.equal(o, entry.getValue()))
/* 2513:     */           {
/* 2514:3674 */             map().remove(entry.getKey());
/* 2515:3675 */             return true;
/* 2516:     */           }
/* 2517:     */         }
/* 2518:     */       }
/* 2519:3678 */       return false;
/* 2520:     */     }
/* 2521:     */     
/* 2522:     */     public boolean removeAll(Collection<?> c)
/* 2523:     */     {
/* 2524:     */       try
/* 2525:     */       {
/* 2526:3684 */         return super.removeAll((Collection)Preconditions.checkNotNull(c));
/* 2527:     */       }
/* 2528:     */       catch (UnsupportedOperationException e)
/* 2529:     */       {
/* 2530:3686 */         Set<K> toRemove = Sets.newHashSet();
/* 2531:3687 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2532:3688 */           if (c.contains(entry.getValue())) {
/* 2533:3689 */             toRemove.add(entry.getKey());
/* 2534:     */           }
/* 2535:     */         }
/* 2536:3692 */         return map().keySet().removeAll(toRemove);
/* 2537:     */       }
/* 2538:     */     }
/* 2539:     */     
/* 2540:     */     public boolean retainAll(Collection<?> c)
/* 2541:     */     {
/* 2542:     */       try
/* 2543:     */       {
/* 2544:3698 */         return super.retainAll((Collection)Preconditions.checkNotNull(c));
/* 2545:     */       }
/* 2546:     */       catch (UnsupportedOperationException e)
/* 2547:     */       {
/* 2548:3700 */         Set<K> toRetain = Sets.newHashSet();
/* 2549:3701 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2550:3702 */           if (c.contains(entry.getValue())) {
/* 2551:3703 */             toRetain.add(entry.getKey());
/* 2552:     */           }
/* 2553:     */         }
/* 2554:3706 */         return map().keySet().retainAll(toRetain);
/* 2555:     */       }
/* 2556:     */     }
/* 2557:     */     
/* 2558:     */     public int size()
/* 2559:     */     {
/* 2560:3711 */       return map().size();
/* 2561:     */     }
/* 2562:     */     
/* 2563:     */     public boolean isEmpty()
/* 2564:     */     {
/* 2565:3715 */       return map().isEmpty();
/* 2566:     */     }
/* 2567:     */     
/* 2568:     */     public boolean contains(@Nullable Object o)
/* 2569:     */     {
/* 2570:3719 */       return map().containsValue(o);
/* 2571:     */     }
/* 2572:     */     
/* 2573:     */     public void clear()
/* 2574:     */     {
/* 2575:3723 */       map().clear();
/* 2576:     */     }
/* 2577:     */   }
/* 2578:     */   
/* 2579:     */   static abstract class EntrySet<K, V>
/* 2580:     */     extends Sets.ImprovedAbstractSet<Map.Entry<K, V>>
/* 2581:     */   {
/* 2582:     */     abstract Map<K, V> map();
/* 2583:     */     
/* 2584:     */     public int size()
/* 2585:     */     {
/* 2586:3732 */       return map().size();
/* 2587:     */     }
/* 2588:     */     
/* 2589:     */     public void clear()
/* 2590:     */     {
/* 2591:3736 */       map().clear();
/* 2592:     */     }
/* 2593:     */     
/* 2594:     */     public boolean contains(Object o)
/* 2595:     */     {
/* 2596:3740 */       if ((o instanceof Map.Entry))
/* 2597:     */       {
/* 2598:3741 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2599:3742 */         Object key = entry.getKey();
/* 2600:3743 */         V value = Maps.safeGet(map(), key);
/* 2601:3744 */         return (Objects.equal(value, entry.getValue())) && ((value != null) || (map().containsKey(key)));
/* 2602:     */       }
/* 2603:3747 */       return false;
/* 2604:     */     }
/* 2605:     */     
/* 2606:     */     public boolean isEmpty()
/* 2607:     */     {
/* 2608:3751 */       return map().isEmpty();
/* 2609:     */     }
/* 2610:     */     
/* 2611:     */     public boolean remove(Object o)
/* 2612:     */     {
/* 2613:3755 */       if (contains(o))
/* 2614:     */       {
/* 2615:3756 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2616:3757 */         return map().keySet().remove(entry.getKey());
/* 2617:     */       }
/* 2618:3759 */       return false;
/* 2619:     */     }
/* 2620:     */     
/* 2621:     */     public boolean removeAll(Collection<?> c)
/* 2622:     */     {
/* 2623:     */       try
/* 2624:     */       {
/* 2625:3764 */         return super.removeAll((Collection)Preconditions.checkNotNull(c));
/* 2626:     */       }
/* 2627:     */       catch (UnsupportedOperationException e) {}
/* 2628:3767 */       return Sets.removeAllImpl(this, c.iterator());
/* 2629:     */     }
/* 2630:     */     
/* 2631:     */     public boolean retainAll(Collection<?> c)
/* 2632:     */     {
/* 2633:     */       try
/* 2634:     */       {
/* 2635:3773 */         return super.retainAll((Collection)Preconditions.checkNotNull(c));
/* 2636:     */       }
/* 2637:     */       catch (UnsupportedOperationException e)
/* 2638:     */       {
/* 2639:3776 */         Set<Object> keys = Sets.newHashSetWithExpectedSize(c.size());
/* 2640:3777 */         for (Object o : c) {
/* 2641:3778 */           if (contains(o))
/* 2642:     */           {
/* 2643:3779 */             Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2644:3780 */             keys.add(entry.getKey());
/* 2645:     */           }
/* 2646:     */         }
/* 2647:3783 */         return map().keySet().retainAll(keys);
/* 2648:     */       }
/* 2649:     */     }
/* 2650:     */   }
/* 2651:     */   
/* 2652:     */   @GwtIncompatible("NavigableMap")
/* 2653:     */   static abstract class DescendingMap<K, V>
/* 2654:     */     extends ForwardingMap<K, V>
/* 2655:     */     implements NavigableMap<K, V>
/* 2656:     */   {
/* 2657:     */     private transient Comparator<? super K> comparator;
/* 2658:     */     private transient Set<Map.Entry<K, V>> entrySet;
/* 2659:     */     private transient NavigableSet<K> navigableKeySet;
/* 2660:     */     
/* 2661:     */     abstract NavigableMap<K, V> forward();
/* 2662:     */     
/* 2663:     */     protected final Map<K, V> delegate()
/* 2664:     */     {
/* 2665:3796 */       return forward();
/* 2666:     */     }
/* 2667:     */     
/* 2668:     */     public Comparator<? super K> comparator()
/* 2669:     */     {
/* 2670:3804 */       Comparator<? super K> result = this.comparator;
/* 2671:3805 */       if (result == null)
/* 2672:     */       {
/* 2673:3806 */         Comparator<? super K> forwardCmp = forward().comparator();
/* 2674:3807 */         if (forwardCmp == null) {
/* 2675:3808 */           forwardCmp = Ordering.natural();
/* 2676:     */         }
/* 2677:3810 */         result = this.comparator = reverse(forwardCmp);
/* 2678:     */       }
/* 2679:3812 */       return result;
/* 2680:     */     }
/* 2681:     */     
/* 2682:     */     private static <T> Ordering<T> reverse(Comparator<T> forward)
/* 2683:     */     {
/* 2684:3817 */       return Ordering.from(forward).reverse();
/* 2685:     */     }
/* 2686:     */     
/* 2687:     */     public K firstKey()
/* 2688:     */     {
/* 2689:3822 */       return forward().lastKey();
/* 2690:     */     }
/* 2691:     */     
/* 2692:     */     public K lastKey()
/* 2693:     */     {
/* 2694:3827 */       return forward().firstKey();
/* 2695:     */     }
/* 2696:     */     
/* 2697:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 2698:     */     {
/* 2699:3832 */       return forward().higherEntry(key);
/* 2700:     */     }
/* 2701:     */     
/* 2702:     */     public K lowerKey(K key)
/* 2703:     */     {
/* 2704:3837 */       return forward().higherKey(key);
/* 2705:     */     }
/* 2706:     */     
/* 2707:     */     public Map.Entry<K, V> floorEntry(K key)
/* 2708:     */     {
/* 2709:3842 */       return forward().ceilingEntry(key);
/* 2710:     */     }
/* 2711:     */     
/* 2712:     */     public K floorKey(K key)
/* 2713:     */     {
/* 2714:3847 */       return forward().ceilingKey(key);
/* 2715:     */     }
/* 2716:     */     
/* 2717:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 2718:     */     {
/* 2719:3852 */       return forward().floorEntry(key);
/* 2720:     */     }
/* 2721:     */     
/* 2722:     */     public K ceilingKey(K key)
/* 2723:     */     {
/* 2724:3857 */       return forward().floorKey(key);
/* 2725:     */     }
/* 2726:     */     
/* 2727:     */     public Map.Entry<K, V> higherEntry(K key)
/* 2728:     */     {
/* 2729:3862 */       return forward().lowerEntry(key);
/* 2730:     */     }
/* 2731:     */     
/* 2732:     */     public K higherKey(K key)
/* 2733:     */     {
/* 2734:3867 */       return forward().lowerKey(key);
/* 2735:     */     }
/* 2736:     */     
/* 2737:     */     public Map.Entry<K, V> firstEntry()
/* 2738:     */     {
/* 2739:3872 */       return forward().lastEntry();
/* 2740:     */     }
/* 2741:     */     
/* 2742:     */     public Map.Entry<K, V> lastEntry()
/* 2743:     */     {
/* 2744:3877 */       return forward().firstEntry();
/* 2745:     */     }
/* 2746:     */     
/* 2747:     */     public Map.Entry<K, V> pollFirstEntry()
/* 2748:     */     {
/* 2749:3882 */       return forward().pollLastEntry();
/* 2750:     */     }
/* 2751:     */     
/* 2752:     */     public Map.Entry<K, V> pollLastEntry()
/* 2753:     */     {
/* 2754:3887 */       return forward().pollFirstEntry();
/* 2755:     */     }
/* 2756:     */     
/* 2757:     */     public NavigableMap<K, V> descendingMap()
/* 2758:     */     {
/* 2759:3892 */       return forward();
/* 2760:     */     }
/* 2761:     */     
/* 2762:     */     public Set<Map.Entry<K, V>> entrySet()
/* 2763:     */     {
/* 2764:3899 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 2765:3900 */       return result == null ? (this.entrySet = createEntrySet()) : result;
/* 2766:     */     }
/* 2767:     */     
/* 2768:     */     abstract Iterator<Map.Entry<K, V>> entryIterator();
/* 2769:     */     
/* 2770:     */     Set<Map.Entry<K, V>> createEntrySet()
/* 2771:     */     {
/* 2772:3906 */       new Maps.EntrySet()
/* 2773:     */       {
/* 2774:     */         Map<K, V> map()
/* 2775:     */         {
/* 2776:3909 */           return Maps.DescendingMap.this;
/* 2777:     */         }
/* 2778:     */         
/* 2779:     */         public Iterator<Map.Entry<K, V>> iterator()
/* 2780:     */         {
/* 2781:3914 */           return Maps.DescendingMap.this.entryIterator();
/* 2782:     */         }
/* 2783:     */       };
/* 2784:     */     }
/* 2785:     */     
/* 2786:     */     public Set<K> keySet()
/* 2787:     */     {
/* 2788:3921 */       return navigableKeySet();
/* 2789:     */     }
/* 2790:     */     
/* 2791:     */     public NavigableSet<K> navigableKeySet()
/* 2792:     */     {
/* 2793:3928 */       NavigableSet<K> result = this.navigableKeySet;
/* 2794:3929 */       return result == null ? (this.navigableKeySet = new Maps.NavigableKeySet(this)) : result;
/* 2795:     */     }
/* 2796:     */     
/* 2797:     */     public NavigableSet<K> descendingKeySet()
/* 2798:     */     {
/* 2799:3934 */       return forward().navigableKeySet();
/* 2800:     */     }
/* 2801:     */     
/* 2802:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 2803:     */     {
/* 2804:3941 */       return forward().subMap(toKey, toInclusive, fromKey, fromInclusive).descendingMap();
/* 2805:     */     }
/* 2806:     */     
/* 2807:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 2808:     */     {
/* 2809:3946 */       return forward().tailMap(toKey, inclusive).descendingMap();
/* 2810:     */     }
/* 2811:     */     
/* 2812:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 2813:     */     {
/* 2814:3951 */       return forward().headMap(fromKey, inclusive).descendingMap();
/* 2815:     */     }
/* 2816:     */     
/* 2817:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 2818:     */     {
/* 2819:3956 */       return subMap(fromKey, true, toKey, false);
/* 2820:     */     }
/* 2821:     */     
/* 2822:     */     public SortedMap<K, V> headMap(K toKey)
/* 2823:     */     {
/* 2824:3961 */       return headMap(toKey, false);
/* 2825:     */     }
/* 2826:     */     
/* 2827:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 2828:     */     {
/* 2829:3966 */       return tailMap(fromKey, true);
/* 2830:     */     }
/* 2831:     */     
/* 2832:     */     public Collection<V> values()
/* 2833:     */     {
/* 2834:3971 */       return new Maps.Values(this);
/* 2835:     */     }
/* 2836:     */     
/* 2837:     */     public String toString()
/* 2838:     */     {
/* 2839:3976 */       return standardToString();
/* 2840:     */     }
/* 2841:     */   }
/* 2842:     */   
/* 2843:     */   public static abstract interface EntryTransformer<K, V1, V2>
/* 2844:     */   {
/* 2845:     */     public abstract V2 transformEntry(@Nullable K paramK, @Nullable V1 paramV1);
/* 2846:     */   }
/* 2847:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Maps
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.VisibleForTesting;
/*    4:     */ import com.google.common.base.Equivalence;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Ticker;
/*    7:     */ import com.google.common.primitives.Ints;
/*    8:     */ import java.io.IOException;
/*    9:     */ import java.io.ObjectInputStream;
/*   10:     */ import java.io.ObjectOutputStream;
/*   11:     */ import java.io.Serializable;
/*   12:     */ import java.lang.ref.Reference;
/*   13:     */ import java.lang.ref.ReferenceQueue;
/*   14:     */ import java.lang.ref.SoftReference;
/*   15:     */ import java.lang.ref.WeakReference;
/*   16:     */ import java.util.AbstractCollection;
/*   17:     */ import java.util.AbstractMap;
/*   18:     */ import java.util.AbstractQueue;
/*   19:     */ import java.util.AbstractSet;
/*   20:     */ import java.util.Collection;
/*   21:     */ import java.util.Iterator;
/*   22:     */ import java.util.Map;
/*   23:     */ import java.util.Map.Entry;
/*   24:     */ import java.util.NoSuchElementException;
/*   25:     */ import java.util.Queue;
/*   26:     */ import java.util.Set;
/*   27:     */ import java.util.concurrent.CancellationException;
/*   28:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   29:     */ import java.util.concurrent.ConcurrentMap;
/*   30:     */ import java.util.concurrent.ExecutionException;
/*   31:     */ import java.util.concurrent.TimeUnit;
/*   32:     */ import java.util.concurrent.atomic.AtomicInteger;
/*   33:     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*   34:     */ import java.util.concurrent.locks.ReentrantLock;
/*   35:     */ import java.util.logging.Level;
/*   36:     */ import java.util.logging.Logger;
/*   37:     */ import javax.annotation.Nullable;
/*   38:     */ import javax.annotation.concurrent.GuardedBy;
/*   39:     */ 
/*   40:     */ class MapMakerInternalMap<K, V>
/*   41:     */   extends AbstractMap<K, V>
/*   42:     */   implements ConcurrentMap<K, V>, Serializable
/*   43:     */ {
/*   44:     */   static final int MAXIMUM_CAPACITY = 1073741824;
/*   45:     */   static final int MAX_SEGMENTS = 65536;
/*   46:     */   static final int CONTAINS_VALUE_RETRIES = 3;
/*   47:     */   static final int DRAIN_THRESHOLD = 63;
/*   48:     */   static final int DRAIN_MAX = 16;
/*   49:     */   static final long CLEANUP_EXECUTOR_DELAY_SECS = 60L;
/*   50: 135 */   private static final Logger logger = Logger.getLogger(MapMakerInternalMap.class.getName());
/*   51:     */   final transient int segmentMask;
/*   52:     */   final transient int segmentShift;
/*   53:     */   final transient Segment<K, V>[] segments;
/*   54:     */   final int concurrencyLevel;
/*   55:     */   final Equivalence<Object> keyEquivalence;
/*   56:     */   final Equivalence<Object> valueEquivalence;
/*   57:     */   final Strength keyStrength;
/*   58:     */   final Strength valueStrength;
/*   59:     */   final int maximumSize;
/*   60:     */   final long expireAfterAccessNanos;
/*   61:     */   final long expireAfterWriteNanos;
/*   62:     */   final Queue<MapMaker.RemovalNotification<K, V>> removalNotificationQueue;
/*   63:     */   final MapMaker.RemovalListener<K, V> removalListener;
/*   64:     */   final transient EntryFactory entryFactory;
/*   65:     */   final Ticker ticker;
/*   66:     */   
/*   67:     */   MapMakerInternalMap(MapMaker builder)
/*   68:     */   {
/*   69: 196 */     this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
/*   70:     */     
/*   71: 198 */     this.keyStrength = builder.getKeyStrength();
/*   72: 199 */     this.valueStrength = builder.getValueStrength();
/*   73:     */     
/*   74: 201 */     this.keyEquivalence = builder.getKeyEquivalence();
/*   75: 202 */     this.valueEquivalence = this.valueStrength.defaultEquivalence();
/*   76:     */     
/*   77: 204 */     this.maximumSize = builder.maximumSize;
/*   78: 205 */     this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
/*   79: 206 */     this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
/*   80:     */     
/*   81: 208 */     this.entryFactory = EntryFactory.getFactory(this.keyStrength, expires(), evictsBySize());
/*   82: 209 */     this.ticker = builder.getTicker();
/*   83:     */     
/*   84: 211 */     this.removalListener = builder.getRemovalListener();
/*   85: 212 */     this.removalNotificationQueue = (this.removalListener == GenericMapMaker.NullListener.INSTANCE ? discardingQueue() : new ConcurrentLinkedQueue());
/*   86:     */     
/*   87:     */ 
/*   88:     */ 
/*   89: 216 */     int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
/*   90: 217 */     if (evictsBySize()) {
/*   91: 218 */       initialCapacity = Math.min(initialCapacity, this.maximumSize);
/*   92:     */     }
/*   93: 224 */     int segmentShift = 0;
/*   94: 225 */     int segmentCount = 1;
/*   95: 227 */     while ((segmentCount < this.concurrencyLevel) && ((!evictsBySize()) || (segmentCount * 2 <= this.maximumSize)))
/*   96:     */     {
/*   97: 228 */       segmentShift++;
/*   98: 229 */       segmentCount <<= 1;
/*   99:     */     }
/*  100: 231 */     this.segmentShift = (32 - segmentShift);
/*  101: 232 */     this.segmentMask = (segmentCount - 1);
/*  102:     */     
/*  103: 234 */     this.segments = newSegmentArray(segmentCount);
/*  104:     */     
/*  105: 236 */     int segmentCapacity = initialCapacity / segmentCount;
/*  106: 237 */     if (segmentCapacity * segmentCount < initialCapacity) {
/*  107: 238 */       segmentCapacity++;
/*  108:     */     }
/*  109: 241 */     int segmentSize = 1;
/*  110: 242 */     while (segmentSize < segmentCapacity) {
/*  111: 243 */       segmentSize <<= 1;
/*  112:     */     }
/*  113: 246 */     if (evictsBySize())
/*  114:     */     {
/*  115: 248 */       int maximumSegmentSize = this.maximumSize / segmentCount + 1;
/*  116: 249 */       int remainder = this.maximumSize % segmentCount;
/*  117: 250 */       for (int i = 0; i < this.segments.length; i++)
/*  118:     */       {
/*  119: 251 */         if (i == remainder) {
/*  120: 252 */           maximumSegmentSize--;
/*  121:     */         }
/*  122: 254 */         this.segments[i] = createSegment(segmentSize, maximumSegmentSize);
/*  123:     */       }
/*  124:     */     }
/*  125:     */     else
/*  126:     */     {
/*  127: 258 */       for (int i = 0; i < this.segments.length; i++) {
/*  128: 259 */         this.segments[i] = createSegment(segmentSize, -1);
/*  129:     */       }
/*  130:     */     }
/*  131:     */   }
/*  132:     */   
/*  133:     */   boolean evictsBySize()
/*  134:     */   {
/*  135: 266 */     return this.maximumSize != -1;
/*  136:     */   }
/*  137:     */   
/*  138:     */   boolean expires()
/*  139:     */   {
/*  140: 270 */     return (expiresAfterWrite()) || (expiresAfterAccess());
/*  141:     */   }
/*  142:     */   
/*  143:     */   boolean expiresAfterWrite()
/*  144:     */   {
/*  145: 274 */     return this.expireAfterWriteNanos > 0L;
/*  146:     */   }
/*  147:     */   
/*  148:     */   boolean expiresAfterAccess()
/*  149:     */   {
/*  150: 278 */     return this.expireAfterAccessNanos > 0L;
/*  151:     */   }
/*  152:     */   
/*  153:     */   boolean usesKeyReferences()
/*  154:     */   {
/*  155: 282 */     return this.keyStrength != Strength.STRONG;
/*  156:     */   }
/*  157:     */   
/*  158:     */   boolean usesValueReferences()
/*  159:     */   {
/*  160: 286 */     return this.valueStrength != Strength.STRONG;
/*  161:     */   }
/*  162:     */   
/*  163:     */   static abstract enum Strength
/*  164:     */   {
/*  165: 295 */     STRONG,  SOFT,  WEAK;
/*  166:     */     
/*  167:     */     private Strength() {}
/*  168:     */     
/*  169:     */     abstract <K, V> MapMakerInternalMap.ValueReference<K, V> referenceValue(MapMakerInternalMap.Segment<K, V> paramSegment, MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry, V paramV);
/*  170:     */     
/*  171:     */     abstract Equivalence<Object> defaultEquivalence();
/*  172:     */   }
/*  173:     */   
/*  174:     */   static abstract enum EntryFactory
/*  175:     */   {
/*  176: 352 */     STRONG,  STRONG_EXPIRABLE,  STRONG_EVICTABLE,  STRONG_EXPIRABLE_EVICTABLE,  WEAK,  WEAK_EXPIRABLE,  WEAK_EVICTABLE,  WEAK_EXPIRABLE_EVICTABLE;
/*  177:     */     
/*  178:     */     static final int EXPIRABLE_MASK = 1;
/*  179:     */     static final int EVICTABLE_MASK = 2;
/*  180: 470 */     static final EntryFactory[][] factories = { { STRONG, STRONG_EXPIRABLE, STRONG_EVICTABLE, STRONG_EXPIRABLE_EVICTABLE }, new EntryFactory[0], { WEAK, WEAK_EXPIRABLE, WEAK_EVICTABLE, WEAK_EXPIRABLE_EVICTABLE } };
/*  181:     */     
/*  182:     */     private EntryFactory() {}
/*  183:     */     
/*  184:     */     static EntryFactory getFactory(MapMakerInternalMap.Strength keyStrength, boolean expireAfterWrite, boolean evictsBySize)
/*  185:     */     {
/*  186: 478 */       int flags = (expireAfterWrite ? 1 : 0) | (evictsBySize ? 2 : 0);
/*  187: 479 */       return factories[keyStrength.ordinal()][flags];
/*  188:     */     }
/*  189:     */     
/*  190:     */     abstract <K, V> MapMakerInternalMap.ReferenceEntry<K, V> newEntry(MapMakerInternalMap.Segment<K, V> paramSegment, K paramK, int paramInt, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry);
/*  191:     */     
/*  192:     */     @GuardedBy("Segment.this")
/*  193:     */     <K, V> MapMakerInternalMap.ReferenceEntry<K, V> copyEntry(MapMakerInternalMap.Segment<K, V> segment, MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newNext)
/*  194:     */     {
/*  195: 502 */       return newEntry(segment, original.getKey(), original.getHash(), newNext);
/*  196:     */     }
/*  197:     */     
/*  198:     */     @GuardedBy("Segment.this")
/*  199:     */     <K, V> void copyExpirableEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newEntry)
/*  200:     */     {
/*  201: 509 */       newEntry.setExpirationTime(original.getExpirationTime());
/*  202:     */       
/*  203: 511 */       MapMakerInternalMap.connectExpirables(original.getPreviousExpirable(), newEntry);
/*  204: 512 */       MapMakerInternalMap.connectExpirables(newEntry, original.getNextExpirable());
/*  205:     */       
/*  206: 514 */       MapMakerInternalMap.nullifyExpirable(original);
/*  207:     */     }
/*  208:     */     
/*  209:     */     @GuardedBy("Segment.this")
/*  210:     */     <K, V> void copyEvictableEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newEntry)
/*  211:     */     {
/*  212: 521 */       MapMakerInternalMap.connectEvictables(original.getPreviousEvictable(), newEntry);
/*  213: 522 */       MapMakerInternalMap.connectEvictables(newEntry, original.getNextEvictable());
/*  214:     */       
/*  215: 524 */       MapMakerInternalMap.nullifyEvictable(original);
/*  216:     */     }
/*  217:     */   }
/*  218:     */   
/*  219: 578 */   static final ValueReference<Object, Object> UNSET = new ValueReference()
/*  220:     */   {
/*  221:     */     public Object get()
/*  222:     */     {
/*  223: 581 */       return null;
/*  224:     */     }
/*  225:     */     
/*  226:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getEntry()
/*  227:     */     {
/*  228: 586 */       return null;
/*  229:     */     }
/*  230:     */     
/*  231:     */     public MapMakerInternalMap.ValueReference<Object, Object> copyFor(ReferenceQueue<Object> queue, @Nullable Object value, MapMakerInternalMap.ReferenceEntry<Object, Object> entry)
/*  232:     */     {
/*  233: 592 */       return this;
/*  234:     */     }
/*  235:     */     
/*  236:     */     public boolean isComputingReference()
/*  237:     */     {
/*  238: 597 */       return false;
/*  239:     */     }
/*  240:     */     
/*  241:     */     public Object waitForValue()
/*  242:     */     {
/*  243: 602 */       return null;
/*  244:     */     }
/*  245:     */     
/*  246:     */     public void clear(MapMakerInternalMap.ValueReference<Object, Object> newValue) {}
/*  247:     */   };
/*  248:     */   
/*  249:     */   static <K, V> ValueReference<K, V> unset()
/*  250:     */   {
/*  251: 614 */     return UNSET;
/*  252:     */   }
/*  253:     */   
/*  254:     */   private static enum NullEntry
/*  255:     */     implements MapMakerInternalMap.ReferenceEntry<Object, Object>
/*  256:     */   {
/*  257: 720 */     INSTANCE;
/*  258:     */     
/*  259:     */     private NullEntry() {}
/*  260:     */     
/*  261:     */     public MapMakerInternalMap.ValueReference<Object, Object> getValueReference()
/*  262:     */     {
/*  263: 724 */       return null;
/*  264:     */     }
/*  265:     */     
/*  266:     */     public void setValueReference(MapMakerInternalMap.ValueReference<Object, Object> valueReference) {}
/*  267:     */     
/*  268:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNext()
/*  269:     */     {
/*  270: 732 */       return null;
/*  271:     */     }
/*  272:     */     
/*  273:     */     public int getHash()
/*  274:     */     {
/*  275: 737 */       return 0;
/*  276:     */     }
/*  277:     */     
/*  278:     */     public Object getKey()
/*  279:     */     {
/*  280: 742 */       return null;
/*  281:     */     }
/*  282:     */     
/*  283:     */     public long getExpirationTime()
/*  284:     */     {
/*  285: 747 */       return 0L;
/*  286:     */     }
/*  287:     */     
/*  288:     */     public void setExpirationTime(long time) {}
/*  289:     */     
/*  290:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNextExpirable()
/*  291:     */     {
/*  292: 755 */       return this;
/*  293:     */     }
/*  294:     */     
/*  295:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<Object, Object> next) {}
/*  296:     */     
/*  297:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getPreviousExpirable()
/*  298:     */     {
/*  299: 763 */       return this;
/*  300:     */     }
/*  301:     */     
/*  302:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<Object, Object> previous) {}
/*  303:     */     
/*  304:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNextEvictable()
/*  305:     */     {
/*  306: 771 */       return this;
/*  307:     */     }
/*  308:     */     
/*  309:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<Object, Object> next) {}
/*  310:     */     
/*  311:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getPreviousEvictable()
/*  312:     */     {
/*  313: 779 */       return this;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<Object, Object> previous) {}
/*  317:     */   }
/*  318:     */   
/*  319:     */   static abstract class AbstractReferenceEntry<K, V>
/*  320:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  321:     */   {
/*  322:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  323:     */     {
/*  324: 789 */       throw new UnsupportedOperationException();
/*  325:     */     }
/*  326:     */     
/*  327:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  328:     */     {
/*  329: 794 */       throw new UnsupportedOperationException();
/*  330:     */     }
/*  331:     */     
/*  332:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  333:     */     {
/*  334: 799 */       throw new UnsupportedOperationException();
/*  335:     */     }
/*  336:     */     
/*  337:     */     public int getHash()
/*  338:     */     {
/*  339: 804 */       throw new UnsupportedOperationException();
/*  340:     */     }
/*  341:     */     
/*  342:     */     public K getKey()
/*  343:     */     {
/*  344: 809 */       throw new UnsupportedOperationException();
/*  345:     */     }
/*  346:     */     
/*  347:     */     public long getExpirationTime()
/*  348:     */     {
/*  349: 814 */       throw new UnsupportedOperationException();
/*  350:     */     }
/*  351:     */     
/*  352:     */     public void setExpirationTime(long time)
/*  353:     */     {
/*  354: 819 */       throw new UnsupportedOperationException();
/*  355:     */     }
/*  356:     */     
/*  357:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  358:     */     {
/*  359: 824 */       throw new UnsupportedOperationException();
/*  360:     */     }
/*  361:     */     
/*  362:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  363:     */     {
/*  364: 829 */       throw new UnsupportedOperationException();
/*  365:     */     }
/*  366:     */     
/*  367:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  368:     */     {
/*  369: 834 */       throw new UnsupportedOperationException();
/*  370:     */     }
/*  371:     */     
/*  372:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  373:     */     {
/*  374: 839 */       throw new UnsupportedOperationException();
/*  375:     */     }
/*  376:     */     
/*  377:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  378:     */     {
/*  379: 844 */       throw new UnsupportedOperationException();
/*  380:     */     }
/*  381:     */     
/*  382:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  383:     */     {
/*  384: 849 */       throw new UnsupportedOperationException();
/*  385:     */     }
/*  386:     */     
/*  387:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  388:     */     {
/*  389: 854 */       throw new UnsupportedOperationException();
/*  390:     */     }
/*  391:     */     
/*  392:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  393:     */     {
/*  394: 859 */       throw new UnsupportedOperationException();
/*  395:     */     }
/*  396:     */   }
/*  397:     */   
/*  398:     */   static <K, V> ReferenceEntry<K, V> nullEntry()
/*  399:     */   {
/*  400: 865 */     return NullEntry.INSTANCE;
/*  401:     */   }
/*  402:     */   
/*  403: 868 */   static final Queue<? extends Object> DISCARDING_QUEUE = new AbstractQueue()
/*  404:     */   {
/*  405:     */     public boolean offer(Object o)
/*  406:     */     {
/*  407: 871 */       return true;
/*  408:     */     }
/*  409:     */     
/*  410:     */     public Object peek()
/*  411:     */     {
/*  412: 876 */       return null;
/*  413:     */     }
/*  414:     */     
/*  415:     */     public Object poll()
/*  416:     */     {
/*  417: 881 */       return null;
/*  418:     */     }
/*  419:     */     
/*  420:     */     public int size()
/*  421:     */     {
/*  422: 886 */       return 0;
/*  423:     */     }
/*  424:     */     
/*  425:     */     public Iterator<Object> iterator()
/*  426:     */     {
/*  427: 891 */       return Iterators.emptyIterator();
/*  428:     */     }
/*  429:     */   };
/*  430:     */   transient Set<K> keySet;
/*  431:     */   transient Collection<V> values;
/*  432:     */   transient Set<Map.Entry<K, V>> entrySet;
/*  433:     */   private static final long serialVersionUID = 5L;
/*  434:     */   
/*  435:     */   static <E> Queue<E> discardingQueue()
/*  436:     */   {
/*  437: 900 */     return DISCARDING_QUEUE;
/*  438:     */   }
/*  439:     */   
/*  440:     */   static class StrongEntry<K, V>
/*  441:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  442:     */   {
/*  443:     */     final K key;
/*  444:     */     final int hash;
/*  445:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  446:     */     
/*  447:     */     StrongEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  448:     */     {
/*  449: 918 */       this.key = key;
/*  450: 919 */       this.hash = hash;
/*  451: 920 */       this.next = next;
/*  452:     */     }
/*  453:     */     
/*  454:     */     public K getKey()
/*  455:     */     {
/*  456: 925 */       return this.key;
/*  457:     */     }
/*  458:     */     
/*  459:     */     public long getExpirationTime()
/*  460:     */     {
/*  461: 932 */       throw new UnsupportedOperationException();
/*  462:     */     }
/*  463:     */     
/*  464:     */     public void setExpirationTime(long time)
/*  465:     */     {
/*  466: 937 */       throw new UnsupportedOperationException();
/*  467:     */     }
/*  468:     */     
/*  469:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  470:     */     {
/*  471: 942 */       throw new UnsupportedOperationException();
/*  472:     */     }
/*  473:     */     
/*  474:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  475:     */     {
/*  476: 947 */       throw new UnsupportedOperationException();
/*  477:     */     }
/*  478:     */     
/*  479:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  480:     */     {
/*  481: 952 */       throw new UnsupportedOperationException();
/*  482:     */     }
/*  483:     */     
/*  484:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  485:     */     {
/*  486: 957 */       throw new UnsupportedOperationException();
/*  487:     */     }
/*  488:     */     
/*  489:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  490:     */     {
/*  491: 964 */       throw new UnsupportedOperationException();
/*  492:     */     }
/*  493:     */     
/*  494:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  495:     */     {
/*  496: 969 */       throw new UnsupportedOperationException();
/*  497:     */     }
/*  498:     */     
/*  499:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  500:     */     {
/*  501: 974 */       throw new UnsupportedOperationException();
/*  502:     */     }
/*  503:     */     
/*  504:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  505:     */     {
/*  506: 979 */       throw new UnsupportedOperationException();
/*  507:     */     }
/*  508:     */     
/*  509: 986 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/*  510:     */     
/*  511:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  512:     */     {
/*  513: 990 */       return this.valueReference;
/*  514:     */     }
/*  515:     */     
/*  516:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  517:     */     {
/*  518: 995 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/*  519: 996 */       this.valueReference = valueReference;
/*  520: 997 */       previous.clear(valueReference);
/*  521:     */     }
/*  522:     */     
/*  523:     */     public int getHash()
/*  524:     */     {
/*  525:1002 */       return this.hash;
/*  526:     */     }
/*  527:     */     
/*  528:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  529:     */     {
/*  530:1007 */       return this.next;
/*  531:     */     }
/*  532:     */   }
/*  533:     */   
/*  534:     */   static final class StrongExpirableEntry<K, V>
/*  535:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  536:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  537:     */   {
/*  538:     */     StrongExpirableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  539:     */     {
/*  540:1014 */       super(hash, next);
/*  541:     */     }
/*  542:     */     
/*  543:1019 */     volatile long time = 9223372036854775807L;
/*  544:     */     
/*  545:     */     public long getExpirationTime()
/*  546:     */     {
/*  547:1023 */       return this.time;
/*  548:     */     }
/*  549:     */     
/*  550:     */     public void setExpirationTime(long time)
/*  551:     */     {
/*  552:1028 */       this.time = time;
/*  553:     */     }
/*  554:     */     
/*  555:     */     @GuardedBy("Segment.this")
/*  556:1031 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  557:     */     
/*  558:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  559:     */     {
/*  560:1036 */       return this.nextExpirable;
/*  561:     */     }
/*  562:     */     
/*  563:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  564:     */     {
/*  565:1041 */       this.nextExpirable = next;
/*  566:     */     }
/*  567:     */     
/*  568:     */     @GuardedBy("Segment.this")
/*  569:1044 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  570:     */     
/*  571:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  572:     */     {
/*  573:1049 */       return this.previousExpirable;
/*  574:     */     }
/*  575:     */     
/*  576:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  577:     */     {
/*  578:1054 */       this.previousExpirable = previous;
/*  579:     */     }
/*  580:     */   }
/*  581:     */   
/*  582:     */   static final class StrongEvictableEntry<K, V>
/*  583:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  584:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  585:     */   {
/*  586:     */     StrongEvictableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  587:     */     {
/*  588:1061 */       super(hash, next);
/*  589:     */     }
/*  590:     */     
/*  591:     */     @GuardedBy("Segment.this")
/*  592:1066 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  593:     */     
/*  594:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  595:     */     {
/*  596:1071 */       return this.nextEvictable;
/*  597:     */     }
/*  598:     */     
/*  599:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  600:     */     {
/*  601:1076 */       this.nextEvictable = next;
/*  602:     */     }
/*  603:     */     
/*  604:     */     @GuardedBy("Segment.this")
/*  605:1079 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  606:     */     
/*  607:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  608:     */     {
/*  609:1084 */       return this.previousEvictable;
/*  610:     */     }
/*  611:     */     
/*  612:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  613:     */     {
/*  614:1089 */       this.previousEvictable = previous;
/*  615:     */     }
/*  616:     */   }
/*  617:     */   
/*  618:     */   static final class StrongExpirableEvictableEntry<K, V>
/*  619:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  620:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  621:     */   {
/*  622:     */     StrongExpirableEvictableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  623:     */     {
/*  624:1096 */       super(hash, next);
/*  625:     */     }
/*  626:     */     
/*  627:1101 */     volatile long time = 9223372036854775807L;
/*  628:     */     
/*  629:     */     public long getExpirationTime()
/*  630:     */     {
/*  631:1105 */       return this.time;
/*  632:     */     }
/*  633:     */     
/*  634:     */     public void setExpirationTime(long time)
/*  635:     */     {
/*  636:1110 */       this.time = time;
/*  637:     */     }
/*  638:     */     
/*  639:     */     @GuardedBy("Segment.this")
/*  640:1113 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  641:     */     
/*  642:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  643:     */     {
/*  644:1118 */       return this.nextExpirable;
/*  645:     */     }
/*  646:     */     
/*  647:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  648:     */     {
/*  649:1123 */       this.nextExpirable = next;
/*  650:     */     }
/*  651:     */     
/*  652:     */     @GuardedBy("Segment.this")
/*  653:1126 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  654:     */     
/*  655:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  656:     */     {
/*  657:1131 */       return this.previousExpirable;
/*  658:     */     }
/*  659:     */     
/*  660:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  661:     */     {
/*  662:1136 */       this.previousExpirable = previous;
/*  663:     */     }
/*  664:     */     
/*  665:     */     @GuardedBy("Segment.this")
/*  666:1141 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  667:     */     
/*  668:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  669:     */     {
/*  670:1146 */       return this.nextEvictable;
/*  671:     */     }
/*  672:     */     
/*  673:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  674:     */     {
/*  675:1151 */       this.nextEvictable = next;
/*  676:     */     }
/*  677:     */     
/*  678:     */     @GuardedBy("Segment.this")
/*  679:1154 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  680:     */     
/*  681:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  682:     */     {
/*  683:1159 */       return this.previousEvictable;
/*  684:     */     }
/*  685:     */     
/*  686:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  687:     */     {
/*  688:1164 */       this.previousEvictable = previous;
/*  689:     */     }
/*  690:     */   }
/*  691:     */   
/*  692:     */   static class SoftEntry<K, V>
/*  693:     */     extends SoftReference<K>
/*  694:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  695:     */   {
/*  696:     */     final int hash;
/*  697:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  698:     */     
/*  699:     */     SoftEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  700:     */     {
/*  701:1173 */       super(queue);
/*  702:1174 */       this.hash = hash;
/*  703:1175 */       this.next = next;
/*  704:     */     }
/*  705:     */     
/*  706:     */     public K getKey()
/*  707:     */     {
/*  708:1180 */       return get();
/*  709:     */     }
/*  710:     */     
/*  711:     */     public long getExpirationTime()
/*  712:     */     {
/*  713:1186 */       throw new UnsupportedOperationException();
/*  714:     */     }
/*  715:     */     
/*  716:     */     public void setExpirationTime(long time)
/*  717:     */     {
/*  718:1191 */       throw new UnsupportedOperationException();
/*  719:     */     }
/*  720:     */     
/*  721:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  722:     */     {
/*  723:1196 */       throw new UnsupportedOperationException();
/*  724:     */     }
/*  725:     */     
/*  726:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  727:     */     {
/*  728:1201 */       throw new UnsupportedOperationException();
/*  729:     */     }
/*  730:     */     
/*  731:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  732:     */     {
/*  733:1206 */       throw new UnsupportedOperationException();
/*  734:     */     }
/*  735:     */     
/*  736:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  737:     */     {
/*  738:1211 */       throw new UnsupportedOperationException();
/*  739:     */     }
/*  740:     */     
/*  741:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  742:     */     {
/*  743:1218 */       throw new UnsupportedOperationException();
/*  744:     */     }
/*  745:     */     
/*  746:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  747:     */     {
/*  748:1223 */       throw new UnsupportedOperationException();
/*  749:     */     }
/*  750:     */     
/*  751:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  752:     */     {
/*  753:1228 */       throw new UnsupportedOperationException();
/*  754:     */     }
/*  755:     */     
/*  756:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  757:     */     {
/*  758:1233 */       throw new UnsupportedOperationException();
/*  759:     */     }
/*  760:     */     
/*  761:1240 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/*  762:     */     
/*  763:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  764:     */     {
/*  765:1244 */       return this.valueReference;
/*  766:     */     }
/*  767:     */     
/*  768:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  769:     */     {
/*  770:1249 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/*  771:1250 */       this.valueReference = valueReference;
/*  772:1251 */       previous.clear(valueReference);
/*  773:     */     }
/*  774:     */     
/*  775:     */     public int getHash()
/*  776:     */     {
/*  777:1256 */       return this.hash;
/*  778:     */     }
/*  779:     */     
/*  780:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  781:     */     {
/*  782:1261 */       return this.next;
/*  783:     */     }
/*  784:     */   }
/*  785:     */   
/*  786:     */   static final class SoftExpirableEntry<K, V>
/*  787:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  788:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  789:     */   {
/*  790:     */     SoftExpirableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  791:     */     {
/*  792:1269 */       super(key, hash, next);
/*  793:     */     }
/*  794:     */     
/*  795:1274 */     volatile long time = 9223372036854775807L;
/*  796:     */     
/*  797:     */     public long getExpirationTime()
/*  798:     */     {
/*  799:1278 */       return this.time;
/*  800:     */     }
/*  801:     */     
/*  802:     */     public void setExpirationTime(long time)
/*  803:     */     {
/*  804:1283 */       this.time = time;
/*  805:     */     }
/*  806:     */     
/*  807:     */     @GuardedBy("Segment.this")
/*  808:1286 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  809:     */     
/*  810:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  811:     */     {
/*  812:1291 */       return this.nextExpirable;
/*  813:     */     }
/*  814:     */     
/*  815:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  816:     */     {
/*  817:1296 */       this.nextExpirable = next;
/*  818:     */     }
/*  819:     */     
/*  820:     */     @GuardedBy("Segment.this")
/*  821:1299 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  822:     */     
/*  823:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  824:     */     {
/*  825:1304 */       return this.previousExpirable;
/*  826:     */     }
/*  827:     */     
/*  828:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  829:     */     {
/*  830:1309 */       this.previousExpirable = previous;
/*  831:     */     }
/*  832:     */   }
/*  833:     */   
/*  834:     */   static final class SoftEvictableEntry<K, V>
/*  835:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  836:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  837:     */   {
/*  838:     */     SoftEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  839:     */     {
/*  840:1317 */       super(key, hash, next);
/*  841:     */     }
/*  842:     */     
/*  843:     */     @GuardedBy("Segment.this")
/*  844:1322 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  845:     */     
/*  846:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  847:     */     {
/*  848:1327 */       return this.nextEvictable;
/*  849:     */     }
/*  850:     */     
/*  851:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  852:     */     {
/*  853:1332 */       this.nextEvictable = next;
/*  854:     */     }
/*  855:     */     
/*  856:     */     @GuardedBy("Segment.this")
/*  857:1335 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  858:     */     
/*  859:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  860:     */     {
/*  861:1340 */       return this.previousEvictable;
/*  862:     */     }
/*  863:     */     
/*  864:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  865:     */     {
/*  866:1345 */       this.previousEvictable = previous;
/*  867:     */     }
/*  868:     */   }
/*  869:     */   
/*  870:     */   static final class SoftExpirableEvictableEntry<K, V>
/*  871:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  872:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  873:     */   {
/*  874:     */     SoftExpirableEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  875:     */     {
/*  876:1353 */       super(key, hash, next);
/*  877:     */     }
/*  878:     */     
/*  879:1358 */     volatile long time = 9223372036854775807L;
/*  880:     */     
/*  881:     */     public long getExpirationTime()
/*  882:     */     {
/*  883:1362 */       return this.time;
/*  884:     */     }
/*  885:     */     
/*  886:     */     public void setExpirationTime(long time)
/*  887:     */     {
/*  888:1367 */       this.time = time;
/*  889:     */     }
/*  890:     */     
/*  891:     */     @GuardedBy("Segment.this")
/*  892:1370 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  893:     */     
/*  894:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  895:     */     {
/*  896:1375 */       return this.nextExpirable;
/*  897:     */     }
/*  898:     */     
/*  899:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  900:     */     {
/*  901:1380 */       this.nextExpirable = next;
/*  902:     */     }
/*  903:     */     
/*  904:     */     @GuardedBy("Segment.this")
/*  905:1383 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  906:     */     
/*  907:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  908:     */     {
/*  909:1388 */       return this.previousExpirable;
/*  910:     */     }
/*  911:     */     
/*  912:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  913:     */     {
/*  914:1393 */       this.previousExpirable = previous;
/*  915:     */     }
/*  916:     */     
/*  917:     */     @GuardedBy("Segment.this")
/*  918:1398 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  919:     */     
/*  920:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  921:     */     {
/*  922:1403 */       return this.nextEvictable;
/*  923:     */     }
/*  924:     */     
/*  925:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  926:     */     {
/*  927:1408 */       this.nextEvictable = next;
/*  928:     */     }
/*  929:     */     
/*  930:     */     @GuardedBy("Segment.this")
/*  931:1411 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  932:     */     
/*  933:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  934:     */     {
/*  935:1416 */       return this.previousEvictable;
/*  936:     */     }
/*  937:     */     
/*  938:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  939:     */     {
/*  940:1421 */       this.previousEvictable = previous;
/*  941:     */     }
/*  942:     */   }
/*  943:     */   
/*  944:     */   static class WeakEntry<K, V>
/*  945:     */     extends WeakReference<K>
/*  946:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  947:     */   {
/*  948:     */     final int hash;
/*  949:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  950:     */     
/*  951:     */     WeakEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  952:     */     {
/*  953:1430 */       super(queue);
/*  954:1431 */       this.hash = hash;
/*  955:1432 */       this.next = next;
/*  956:     */     }
/*  957:     */     
/*  958:     */     public K getKey()
/*  959:     */     {
/*  960:1437 */       return get();
/*  961:     */     }
/*  962:     */     
/*  963:     */     public long getExpirationTime()
/*  964:     */     {
/*  965:1444 */       throw new UnsupportedOperationException();
/*  966:     */     }
/*  967:     */     
/*  968:     */     public void setExpirationTime(long time)
/*  969:     */     {
/*  970:1449 */       throw new UnsupportedOperationException();
/*  971:     */     }
/*  972:     */     
/*  973:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  974:     */     {
/*  975:1454 */       throw new UnsupportedOperationException();
/*  976:     */     }
/*  977:     */     
/*  978:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  979:     */     {
/*  980:1459 */       throw new UnsupportedOperationException();
/*  981:     */     }
/*  982:     */     
/*  983:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  984:     */     {
/*  985:1464 */       throw new UnsupportedOperationException();
/*  986:     */     }
/*  987:     */     
/*  988:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  989:     */     {
/*  990:1469 */       throw new UnsupportedOperationException();
/*  991:     */     }
/*  992:     */     
/*  993:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  994:     */     {
/*  995:1476 */       throw new UnsupportedOperationException();
/*  996:     */     }
/*  997:     */     
/*  998:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  999:     */     {
/* 1000:1481 */       throw new UnsupportedOperationException();
/* 1001:     */     }
/* 1002:     */     
/* 1003:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1004:     */     {
/* 1005:1486 */       throw new UnsupportedOperationException();
/* 1006:     */     }
/* 1007:     */     
/* 1008:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1009:     */     {
/* 1010:1491 */       throw new UnsupportedOperationException();
/* 1011:     */     }
/* 1012:     */     
/* 1013:1498 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/* 1014:     */     
/* 1015:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/* 1016:     */     {
/* 1017:1502 */       return this.valueReference;
/* 1018:     */     }
/* 1019:     */     
/* 1020:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 1021:     */     {
/* 1022:1507 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/* 1023:1508 */       this.valueReference = valueReference;
/* 1024:1509 */       previous.clear(valueReference);
/* 1025:     */     }
/* 1026:     */     
/* 1027:     */     public int getHash()
/* 1028:     */     {
/* 1029:1514 */       return this.hash;
/* 1030:     */     }
/* 1031:     */     
/* 1032:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/* 1033:     */     {
/* 1034:1519 */       return this.next;
/* 1035:     */     }
/* 1036:     */   }
/* 1037:     */   
/* 1038:     */   static final class WeakExpirableEntry<K, V>
/* 1039:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1040:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1041:     */   {
/* 1042:     */     WeakExpirableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1043:     */     {
/* 1044:1527 */       super(key, hash, next);
/* 1045:     */     }
/* 1046:     */     
/* 1047:1532 */     volatile long time = 9223372036854775807L;
/* 1048:     */     
/* 1049:     */     public long getExpirationTime()
/* 1050:     */     {
/* 1051:1536 */       return this.time;
/* 1052:     */     }
/* 1053:     */     
/* 1054:     */     public void setExpirationTime(long time)
/* 1055:     */     {
/* 1056:1541 */       this.time = time;
/* 1057:     */     }
/* 1058:     */     
/* 1059:     */     @GuardedBy("Segment.this")
/* 1060:1544 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/* 1061:     */     
/* 1062:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 1063:     */     {
/* 1064:1549 */       return this.nextExpirable;
/* 1065:     */     }
/* 1066:     */     
/* 1067:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1068:     */     {
/* 1069:1554 */       this.nextExpirable = next;
/* 1070:     */     }
/* 1071:     */     
/* 1072:     */     @GuardedBy("Segment.this")
/* 1073:1557 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/* 1074:     */     
/* 1075:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 1076:     */     {
/* 1077:1562 */       return this.previousExpirable;
/* 1078:     */     }
/* 1079:     */     
/* 1080:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1081:     */     {
/* 1082:1567 */       this.previousExpirable = previous;
/* 1083:     */     }
/* 1084:     */   }
/* 1085:     */   
/* 1086:     */   static final class WeakEvictableEntry<K, V>
/* 1087:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1088:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1089:     */   {
/* 1090:     */     WeakEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1091:     */     {
/* 1092:1575 */       super(key, hash, next);
/* 1093:     */     }
/* 1094:     */     
/* 1095:     */     @GuardedBy("Segment.this")
/* 1096:1580 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/* 1097:     */     
/* 1098:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 1099:     */     {
/* 1100:1585 */       return this.nextEvictable;
/* 1101:     */     }
/* 1102:     */     
/* 1103:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1104:     */     {
/* 1105:1590 */       this.nextEvictable = next;
/* 1106:     */     }
/* 1107:     */     
/* 1108:     */     @GuardedBy("Segment.this")
/* 1109:1593 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/* 1110:     */     
/* 1111:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1112:     */     {
/* 1113:1598 */       return this.previousEvictable;
/* 1114:     */     }
/* 1115:     */     
/* 1116:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1117:     */     {
/* 1118:1603 */       this.previousEvictable = previous;
/* 1119:     */     }
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static final class WeakExpirableEvictableEntry<K, V>
/* 1123:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1124:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1125:     */   {
/* 1126:     */     WeakExpirableEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1127:     */     {
/* 1128:1611 */       super(key, hash, next);
/* 1129:     */     }
/* 1130:     */     
/* 1131:1616 */     volatile long time = 9223372036854775807L;
/* 1132:     */     
/* 1133:     */     public long getExpirationTime()
/* 1134:     */     {
/* 1135:1620 */       return this.time;
/* 1136:     */     }
/* 1137:     */     
/* 1138:     */     public void setExpirationTime(long time)
/* 1139:     */     {
/* 1140:1625 */       this.time = time;
/* 1141:     */     }
/* 1142:     */     
/* 1143:     */     @GuardedBy("Segment.this")
/* 1144:1628 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/* 1145:     */     
/* 1146:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 1147:     */     {
/* 1148:1633 */       return this.nextExpirable;
/* 1149:     */     }
/* 1150:     */     
/* 1151:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1152:     */     {
/* 1153:1638 */       this.nextExpirable = next;
/* 1154:     */     }
/* 1155:     */     
/* 1156:     */     @GuardedBy("Segment.this")
/* 1157:1641 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/* 1158:     */     
/* 1159:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 1160:     */     {
/* 1161:1646 */       return this.previousExpirable;
/* 1162:     */     }
/* 1163:     */     
/* 1164:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1165:     */     {
/* 1166:1651 */       this.previousExpirable = previous;
/* 1167:     */     }
/* 1168:     */     
/* 1169:     */     @GuardedBy("Segment.this")
/* 1170:1656 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/* 1171:     */     
/* 1172:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 1173:     */     {
/* 1174:1661 */       return this.nextEvictable;
/* 1175:     */     }
/* 1176:     */     
/* 1177:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1178:     */     {
/* 1179:1666 */       this.nextEvictable = next;
/* 1180:     */     }
/* 1181:     */     
/* 1182:     */     @GuardedBy("Segment.this")
/* 1183:1669 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/* 1184:     */     
/* 1185:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1186:     */     {
/* 1187:1674 */       return this.previousEvictable;
/* 1188:     */     }
/* 1189:     */     
/* 1190:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1191:     */     {
/* 1192:1679 */       this.previousEvictable = previous;
/* 1193:     */     }
/* 1194:     */   }
/* 1195:     */   
/* 1196:     */   static final class WeakValueReference<K, V>
/* 1197:     */     extends WeakReference<V>
/* 1198:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1199:     */   {
/* 1200:     */     final MapMakerInternalMap.ReferenceEntry<K, V> entry;
/* 1201:     */     
/* 1202:     */     WeakValueReference(ReferenceQueue<V> queue, V referent, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1203:     */     {
/* 1204:1691 */       super(queue);
/* 1205:1692 */       this.entry = entry;
/* 1206:     */     }
/* 1207:     */     
/* 1208:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1209:     */     {
/* 1210:1697 */       return this.entry;
/* 1211:     */     }
/* 1212:     */     
/* 1213:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 1214:     */     {
/* 1215:1702 */       clear();
/* 1216:     */     }
/* 1217:     */     
/* 1218:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1219:     */     {
/* 1220:1708 */       return new WeakValueReference(queue, value, entry);
/* 1221:     */     }
/* 1222:     */     
/* 1223:     */     public boolean isComputingReference()
/* 1224:     */     {
/* 1225:1713 */       return false;
/* 1226:     */     }
/* 1227:     */     
/* 1228:     */     public V waitForValue()
/* 1229:     */     {
/* 1230:1718 */       return get();
/* 1231:     */     }
/* 1232:     */   }
/* 1233:     */   
/* 1234:     */   static final class SoftValueReference<K, V>
/* 1235:     */     extends SoftReference<V>
/* 1236:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1237:     */   {
/* 1238:     */     final MapMakerInternalMap.ReferenceEntry<K, V> entry;
/* 1239:     */     
/* 1240:     */     SoftValueReference(ReferenceQueue<V> queue, V referent, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1241:     */     {
/* 1242:1730 */       super(queue);
/* 1243:1731 */       this.entry = entry;
/* 1244:     */     }
/* 1245:     */     
/* 1246:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1247:     */     {
/* 1248:1736 */       return this.entry;
/* 1249:     */     }
/* 1250:     */     
/* 1251:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 1252:     */     {
/* 1253:1741 */       clear();
/* 1254:     */     }
/* 1255:     */     
/* 1256:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1257:     */     {
/* 1258:1747 */       return new SoftValueReference(queue, value, entry);
/* 1259:     */     }
/* 1260:     */     
/* 1261:     */     public boolean isComputingReference()
/* 1262:     */     {
/* 1263:1752 */       return false;
/* 1264:     */     }
/* 1265:     */     
/* 1266:     */     public V waitForValue()
/* 1267:     */     {
/* 1268:1757 */       return get();
/* 1269:     */     }
/* 1270:     */   }
/* 1271:     */   
/* 1272:     */   static final class StrongValueReference<K, V>
/* 1273:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1274:     */   {
/* 1275:     */     final V referent;
/* 1276:     */     
/* 1277:     */     StrongValueReference(V referent)
/* 1278:     */     {
/* 1279:1768 */       this.referent = referent;
/* 1280:     */     }
/* 1281:     */     
/* 1282:     */     public V get()
/* 1283:     */     {
/* 1284:1773 */       return this.referent;
/* 1285:     */     }
/* 1286:     */     
/* 1287:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1288:     */     {
/* 1289:1778 */       return null;
/* 1290:     */     }
/* 1291:     */     
/* 1292:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1293:     */     {
/* 1294:1784 */       return this;
/* 1295:     */     }
/* 1296:     */     
/* 1297:     */     public boolean isComputingReference()
/* 1298:     */     {
/* 1299:1789 */       return false;
/* 1300:     */     }
/* 1301:     */     
/* 1302:     */     public V waitForValue()
/* 1303:     */     {
/* 1304:1794 */       return get();
/* 1305:     */     }
/* 1306:     */     
/* 1307:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 1308:     */   }
/* 1309:     */   
/* 1310:     */   static int rehash(int h)
/* 1311:     */   {
/* 1312:1813 */     h += (h << 15 ^ 0xFFFFCD7D);
/* 1313:1814 */     h ^= h >>> 10;
/* 1314:1815 */     h += (h << 3);
/* 1315:1816 */     h ^= h >>> 6;
/* 1316:1817 */     h += (h << 2) + (h << 14);
/* 1317:1818 */     return h ^ h >>> 16;
/* 1318:     */   }
/* 1319:     */   
/* 1320:     */   @GuardedBy("Segment.this")
/* 1321:     */   @VisibleForTesting
/* 1322:     */   ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next)
/* 1323:     */   {
/* 1324:1827 */     return segmentFor(hash).newEntry(key, hash, next);
/* 1325:     */   }
/* 1326:     */   
/* 1327:     */   @GuardedBy("Segment.this")
/* 1328:     */   @VisibleForTesting
/* 1329:     */   ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext)
/* 1330:     */   {
/* 1331:1836 */     int hash = original.getHash();
/* 1332:1837 */     return segmentFor(hash).copyEntry(original, newNext);
/* 1333:     */   }
/* 1334:     */   
/* 1335:     */   @GuardedBy("Segment.this")
/* 1336:     */   @VisibleForTesting
/* 1337:     */   ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value)
/* 1338:     */   {
/* 1339:1846 */     int hash = entry.getHash();
/* 1340:1847 */     return this.valueStrength.referenceValue(segmentFor(hash), entry, value);
/* 1341:     */   }
/* 1342:     */   
/* 1343:     */   int hash(Object key)
/* 1344:     */   {
/* 1345:1851 */     int h = this.keyEquivalence.hash(key);
/* 1346:1852 */     return rehash(h);
/* 1347:     */   }
/* 1348:     */   
/* 1349:     */   void reclaimValue(ValueReference<K, V> valueReference)
/* 1350:     */   {
/* 1351:1856 */     ReferenceEntry<K, V> entry = valueReference.getEntry();
/* 1352:1857 */     int hash = entry.getHash();
/* 1353:1858 */     segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
/* 1354:     */   }
/* 1355:     */   
/* 1356:     */   void reclaimKey(ReferenceEntry<K, V> entry)
/* 1357:     */   {
/* 1358:1862 */     int hash = entry.getHash();
/* 1359:1863 */     segmentFor(hash).reclaimKey(entry, hash);
/* 1360:     */   }
/* 1361:     */   
/* 1362:     */   @VisibleForTesting
/* 1363:     */   boolean isLive(ReferenceEntry<K, V> entry)
/* 1364:     */   {
/* 1365:1872 */     return segmentFor(entry.getHash()).getLiveValue(entry) != null;
/* 1366:     */   }
/* 1367:     */   
/* 1368:     */   Segment<K, V> segmentFor(int hash)
/* 1369:     */   {
/* 1370:1883 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/* 1371:     */   }
/* 1372:     */   
/* 1373:     */   Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize)
/* 1374:     */   {
/* 1375:1887 */     return new Segment(this, initialCapacity, maxSegmentSize);
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   V getLiveValue(ReferenceEntry<K, V> entry)
/* 1379:     */   {
/* 1380:1896 */     if (entry.getKey() == null) {
/* 1381:1897 */       return null;
/* 1382:     */     }
/* 1383:1899 */     V value = entry.getValueReference().get();
/* 1384:1900 */     if (value == null) {
/* 1385:1901 */       return null;
/* 1386:     */     }
/* 1387:1904 */     if ((expires()) && (isExpired(entry))) {
/* 1388:1905 */       return null;
/* 1389:     */     }
/* 1390:1907 */     return value;
/* 1391:     */   }
/* 1392:     */   
/* 1393:     */   boolean isExpired(ReferenceEntry<K, V> entry)
/* 1394:     */   {
/* 1395:1916 */     return isExpired(entry, this.ticker.read());
/* 1396:     */   }
/* 1397:     */   
/* 1398:     */   boolean isExpired(ReferenceEntry<K, V> entry, long now)
/* 1399:     */   {
/* 1400:1924 */     return now - entry.getExpirationTime() > 0L;
/* 1401:     */   }
/* 1402:     */   
/* 1403:     */   @GuardedBy("Segment.this")
/* 1404:     */   static <K, V> void connectExpirables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1405:     */   {
/* 1406:1929 */     previous.setNextExpirable(next);
/* 1407:1930 */     next.setPreviousExpirable(previous);
/* 1408:     */   }
/* 1409:     */   
/* 1410:     */   @GuardedBy("Segment.this")
/* 1411:     */   static <K, V> void nullifyExpirable(ReferenceEntry<K, V> nulled)
/* 1412:     */   {
/* 1413:1935 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1414:1936 */     nulled.setNextExpirable(nullEntry);
/* 1415:1937 */     nulled.setPreviousExpirable(nullEntry);
/* 1416:     */   }
/* 1417:     */   
/* 1418:     */   void processPendingNotifications()
/* 1419:     */   {
/* 1420:     */     MapMaker.RemovalNotification<K, V> notification;
/* 1421:1949 */     while ((notification = (MapMaker.RemovalNotification)this.removalNotificationQueue.poll()) != null) {
/* 1422:     */       try
/* 1423:     */       {
/* 1424:1951 */         this.removalListener.onRemoval(notification);
/* 1425:     */       }
/* 1426:     */       catch (Exception e)
/* 1427:     */       {
/* 1428:1953 */         logger.log(Level.WARNING, "Exception thrown by removal listener", e);
/* 1429:     */       }
/* 1430:     */     }
/* 1431:     */   }
/* 1432:     */   
/* 1433:     */   @GuardedBy("Segment.this")
/* 1434:     */   static <K, V> void connectEvictables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1435:     */   {
/* 1436:1961 */     previous.setNextEvictable(next);
/* 1437:1962 */     next.setPreviousEvictable(previous);
/* 1438:     */   }
/* 1439:     */   
/* 1440:     */   @GuardedBy("Segment.this")
/* 1441:     */   static <K, V> void nullifyEvictable(ReferenceEntry<K, V> nulled)
/* 1442:     */   {
/* 1443:1967 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1444:1968 */     nulled.setNextEvictable(nullEntry);
/* 1445:1969 */     nulled.setPreviousEvictable(nullEntry);
/* 1446:     */   }
/* 1447:     */   
/* 1448:     */   final Segment<K, V>[] newSegmentArray(int ssize)
/* 1449:     */   {
/* 1450:1974 */     return new Segment[ssize];
/* 1451:     */   }
/* 1452:     */   
/* 1453:     */   static class Segment<K, V>
/* 1454:     */     extends ReentrantLock
/* 1455:     */   {
/* 1456:     */     final MapMakerInternalMap<K, V> map;
/* 1457:     */     volatile int count;
/* 1458:     */     int modCount;
/* 1459:     */     int threshold;
/* 1460:     */     volatile AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table;
/* 1461:     */     final int maxSegmentSize;
/* 1462:     */     final ReferenceQueue<K> keyReferenceQueue;
/* 1463:     */     final ReferenceQueue<V> valueReferenceQueue;
/* 1464:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> recencyQueue;
/* 1465:2074 */     final AtomicInteger readCount = new AtomicInteger();
/* 1466:     */     @GuardedBy("Segment.this")
/* 1467:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> evictionQueue;
/* 1468:     */     @GuardedBy("Segment.this")
/* 1469:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> expirationQueue;
/* 1470:     */     
/* 1471:     */     Segment(MapMakerInternalMap<K, V> map, int initialCapacity, int maxSegmentSize)
/* 1472:     */     {
/* 1473:2091 */       this.map = map;
/* 1474:2092 */       this.maxSegmentSize = maxSegmentSize;
/* 1475:2093 */       initTable(newEntryArray(initialCapacity));
/* 1476:     */       
/* 1477:2095 */       this.keyReferenceQueue = (map.usesKeyReferences() ? new ReferenceQueue() : null);
/* 1478:     */       
/* 1479:     */ 
/* 1480:2098 */       this.valueReferenceQueue = (map.usesValueReferences() ? new ReferenceQueue() : null);
/* 1481:     */       
/* 1482:     */ 
/* 1483:2101 */       this.recencyQueue = ((map.evictsBySize()) || (map.expiresAfterAccess()) ? new ConcurrentLinkedQueue() : MapMakerInternalMap.discardingQueue());
/* 1484:     */       
/* 1485:     */ 
/* 1486:     */ 
/* 1487:2105 */       this.evictionQueue = (map.evictsBySize() ? new MapMakerInternalMap.EvictionQueue() : MapMakerInternalMap.discardingQueue());
/* 1488:     */       
/* 1489:     */ 
/* 1490:     */ 
/* 1491:2109 */       this.expirationQueue = (map.expires() ? new MapMakerInternalMap.ExpirationQueue() : MapMakerInternalMap.discardingQueue());
/* 1492:     */     }
/* 1493:     */     
/* 1494:     */     AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newEntryArray(int size)
/* 1495:     */     {
/* 1496:2115 */       return new AtomicReferenceArray(size);
/* 1497:     */     }
/* 1498:     */     
/* 1499:     */     void initTable(AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newTable)
/* 1500:     */     {
/* 1501:2119 */       this.threshold = (newTable.length() * 3 / 4);
/* 1502:2120 */       if (this.threshold == this.maxSegmentSize) {
/* 1503:2122 */         this.threshold += 1;
/* 1504:     */       }
/* 1505:2124 */       this.table = newTable;
/* 1506:     */     }
/* 1507:     */     
/* 1508:     */     @GuardedBy("Segment.this")
/* 1509:     */     MapMakerInternalMap.ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1510:     */     {
/* 1511:2129 */       return this.map.entryFactory.newEntry(this, key, hash, next);
/* 1512:     */     }
/* 1513:     */     
/* 1514:     */     @GuardedBy("Segment.this")
/* 1515:     */     MapMakerInternalMap.ReferenceEntry<K, V> copyEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newNext)
/* 1516:     */     {
/* 1517:2138 */       if (original.getKey() == null) {
/* 1518:2140 */         return null;
/* 1519:     */       }
/* 1520:2143 */       MapMakerInternalMap.ValueReference<K, V> valueReference = original.getValueReference();
/* 1521:2144 */       V value = valueReference.get();
/* 1522:2145 */       if ((value == null) && (!valueReference.isComputingReference())) {
/* 1523:2147 */         return null;
/* 1524:     */       }
/* 1525:2150 */       MapMakerInternalMap.ReferenceEntry<K, V> newEntry = this.map.entryFactory.copyEntry(this, original, newNext);
/* 1526:2151 */       newEntry.setValueReference(valueReference.copyFor(this.valueReferenceQueue, value, newEntry));
/* 1527:2152 */       return newEntry;
/* 1528:     */     }
/* 1529:     */     
/* 1530:     */     @GuardedBy("Segment.this")
/* 1531:     */     void setValue(MapMakerInternalMap.ReferenceEntry<K, V> entry, V value)
/* 1532:     */     {
/* 1533:2160 */       MapMakerInternalMap.ValueReference<K, V> valueReference = this.map.valueStrength.referenceValue(this, entry, value);
/* 1534:2161 */       entry.setValueReference(valueReference);
/* 1535:2162 */       recordWrite(entry);
/* 1536:     */     }
/* 1537:     */     
/* 1538:     */     void tryDrainReferenceQueues()
/* 1539:     */     {
/* 1540:2171 */       if (tryLock()) {
/* 1541:     */         try
/* 1542:     */         {
/* 1543:2173 */           drainReferenceQueues();
/* 1544:     */         }
/* 1545:     */         finally
/* 1546:     */         {
/* 1547:2175 */           unlock();
/* 1548:     */         }
/* 1549:     */       }
/* 1550:     */     }
/* 1551:     */     
/* 1552:     */     @GuardedBy("Segment.this")
/* 1553:     */     void drainReferenceQueues()
/* 1554:     */     {
/* 1555:2186 */       if (this.map.usesKeyReferences()) {
/* 1556:2187 */         drainKeyReferenceQueue();
/* 1557:     */       }
/* 1558:2189 */       if (this.map.usesValueReferences()) {
/* 1559:2190 */         drainValueReferenceQueue();
/* 1560:     */       }
/* 1561:     */     }
/* 1562:     */     
/* 1563:     */     @GuardedBy("Segment.this")
/* 1564:     */     void drainKeyReferenceQueue()
/* 1565:     */     {
/* 1566:2197 */       int i = 0;
/* 1567:     */       Reference<? extends K> ref;
/* 1568:2198 */       for (; (ref = this.keyReferenceQueue.poll()) != null; i == 16)
/* 1569:     */       {
/* 1570:2200 */         MapMakerInternalMap.ReferenceEntry<K, V> entry = (MapMakerInternalMap.ReferenceEntry)ref;
/* 1571:2201 */         this.map.reclaimKey(entry);
/* 1572:2202 */         i++;
/* 1573:     */       }
/* 1574:     */     }
/* 1575:     */     
/* 1576:     */     @GuardedBy("Segment.this")
/* 1577:     */     void drainValueReferenceQueue()
/* 1578:     */     {
/* 1579:2211 */       int i = 0;
/* 1580:     */       Reference<? extends V> ref;
/* 1581:2212 */       for (; (ref = this.valueReferenceQueue.poll()) != null; i == 16)
/* 1582:     */       {
/* 1583:2214 */         MapMakerInternalMap.ValueReference<K, V> valueReference = (MapMakerInternalMap.ValueReference)ref;
/* 1584:2215 */         this.map.reclaimValue(valueReference);
/* 1585:2216 */         i++;
/* 1586:     */       }
/* 1587:     */     }
/* 1588:     */     
/* 1589:     */     void clearReferenceQueues()
/* 1590:     */     {
/* 1591:2226 */       if (this.map.usesKeyReferences()) {
/* 1592:2227 */         clearKeyReferenceQueue();
/* 1593:     */       }
/* 1594:2229 */       if (this.map.usesValueReferences()) {
/* 1595:2230 */         clearValueReferenceQueue();
/* 1596:     */       }
/* 1597:     */     }
/* 1598:     */     
/* 1599:     */     void clearKeyReferenceQueue()
/* 1600:     */     {
/* 1601:2235 */       while (this.keyReferenceQueue.poll() != null) {}
/* 1602:     */     }
/* 1603:     */     
/* 1604:     */     void clearValueReferenceQueue()
/* 1605:     */     {
/* 1606:2239 */       while (this.valueReferenceQueue.poll() != null) {}
/* 1607:     */     }
/* 1608:     */     
/* 1609:     */     void recordRead(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1610:     */     {
/* 1611:2252 */       if (this.map.expiresAfterAccess()) {
/* 1612:2253 */         recordExpirationTime(entry, this.map.expireAfterAccessNanos);
/* 1613:     */       }
/* 1614:2255 */       this.recencyQueue.add(entry);
/* 1615:     */     }
/* 1616:     */     
/* 1617:     */     @GuardedBy("Segment.this")
/* 1618:     */     void recordLockedRead(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1619:     */     {
/* 1620:2267 */       this.evictionQueue.add(entry);
/* 1621:2268 */       if (this.map.expiresAfterAccess())
/* 1622:     */       {
/* 1623:2269 */         recordExpirationTime(entry, this.map.expireAfterAccessNanos);
/* 1624:2270 */         this.expirationQueue.add(entry);
/* 1625:     */       }
/* 1626:     */     }
/* 1627:     */     
/* 1628:     */     @GuardedBy("Segment.this")
/* 1629:     */     void recordWrite(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1630:     */     {
/* 1631:2281 */       drainRecencyQueue();
/* 1632:2282 */       this.evictionQueue.add(entry);
/* 1633:2283 */       if (this.map.expires())
/* 1634:     */       {
/* 1635:2286 */         long expiration = this.map.expiresAfterAccess() ? this.map.expireAfterAccessNanos : this.map.expireAfterWriteNanos;
/* 1636:     */         
/* 1637:     */ 
/* 1638:2289 */         recordExpirationTime(entry, expiration);
/* 1639:2290 */         this.expirationQueue.add(entry);
/* 1640:     */       }
/* 1641:     */     }
/* 1642:     */     
/* 1643:     */     @GuardedBy("Segment.this")
/* 1644:     */     void drainRecencyQueue()
/* 1645:     */     {
/* 1646:     */       MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1647:2303 */       while ((e = (MapMakerInternalMap.ReferenceEntry)this.recencyQueue.poll()) != null)
/* 1648:     */       {
/* 1649:2308 */         if (this.evictionQueue.contains(e)) {
/* 1650:2309 */           this.evictionQueue.add(e);
/* 1651:     */         }
/* 1652:2311 */         if ((this.map.expiresAfterAccess()) && (this.expirationQueue.contains(e))) {
/* 1653:2312 */           this.expirationQueue.add(e);
/* 1654:     */         }
/* 1655:     */       }
/* 1656:     */     }
/* 1657:     */     
/* 1658:     */     void recordExpirationTime(MapMakerInternalMap.ReferenceEntry<K, V> entry, long expirationNanos)
/* 1659:     */     {
/* 1660:2321 */       entry.setExpirationTime(this.map.ticker.read() + expirationNanos);
/* 1661:     */     }
/* 1662:     */     
/* 1663:     */     void tryExpireEntries()
/* 1664:     */     {
/* 1665:2328 */       if (tryLock()) {
/* 1666:     */         try
/* 1667:     */         {
/* 1668:2330 */           expireEntries();
/* 1669:     */         }
/* 1670:     */         finally
/* 1671:     */         {
/* 1672:2332 */           unlock();
/* 1673:     */         }
/* 1674:     */       }
/* 1675:     */     }
/* 1676:     */     
/* 1677:     */     @GuardedBy("Segment.this")
/* 1678:     */     void expireEntries()
/* 1679:     */     {
/* 1680:2340 */       drainRecencyQueue();
/* 1681:2342 */       if (this.expirationQueue.isEmpty()) {
/* 1682:2345 */         return;
/* 1683:     */       }
/* 1684:2347 */       long now = this.map.ticker.read();
/* 1685:     */       MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1686:2349 */       while (((e = (MapMakerInternalMap.ReferenceEntry)this.expirationQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1687:2350 */         if (!removeEntry(e, e.getHash(), MapMaker.RemovalCause.EXPIRED)) {
/* 1688:2351 */           throw new AssertionError();
/* 1689:     */         }
/* 1690:     */       }
/* 1691:     */     }
/* 1692:     */     
/* 1693:     */     void enqueueNotification(MapMakerInternalMap.ReferenceEntry<K, V> entry, MapMaker.RemovalCause cause)
/* 1694:     */     {
/* 1695:2359 */       enqueueNotification(entry.getKey(), entry.getHash(), entry.getValueReference().get(), cause);
/* 1696:     */     }
/* 1697:     */     
/* 1698:     */     void enqueueNotification(@Nullable K key, int hash, @Nullable V value, MapMaker.RemovalCause cause)
/* 1699:     */     {
/* 1700:2363 */       if (this.map.removalNotificationQueue != MapMakerInternalMap.DISCARDING_QUEUE)
/* 1701:     */       {
/* 1702:2364 */         MapMaker.RemovalNotification<K, V> notification = new MapMaker.RemovalNotification(key, value, cause);
/* 1703:2365 */         this.map.removalNotificationQueue.offer(notification);
/* 1704:     */       }
/* 1705:     */     }
/* 1706:     */     
/* 1707:     */     @GuardedBy("Segment.this")
/* 1708:     */     boolean evictEntries()
/* 1709:     */     {
/* 1710:2377 */       if ((this.map.evictsBySize()) && (this.count >= this.maxSegmentSize))
/* 1711:     */       {
/* 1712:2378 */         drainRecencyQueue();
/* 1713:     */         
/* 1714:2380 */         MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)this.evictionQueue.remove();
/* 1715:2381 */         if (!removeEntry(e, e.getHash(), MapMaker.RemovalCause.SIZE)) {
/* 1716:2382 */           throw new AssertionError();
/* 1717:     */         }
/* 1718:2384 */         return true;
/* 1719:     */       }
/* 1720:2386 */       return false;
/* 1721:     */     }
/* 1722:     */     
/* 1723:     */     MapMakerInternalMap.ReferenceEntry<K, V> getFirst(int hash)
/* 1724:     */     {
/* 1725:2394 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1726:2395 */       return (MapMakerInternalMap.ReferenceEntry)table.get(hash & table.length() - 1);
/* 1727:     */     }
/* 1728:     */     
/* 1729:     */     MapMakerInternalMap.ReferenceEntry<K, V> getEntry(Object key, int hash)
/* 1730:     */     {
/* 1731:2401 */       if (this.count != 0) {
/* 1732:2402 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = getFirst(hash); e != null; e = e.getNext()) {
/* 1733:2403 */           if (e.getHash() == hash)
/* 1734:     */           {
/* 1735:2407 */             K entryKey = e.getKey();
/* 1736:2408 */             if (entryKey == null) {
/* 1737:2409 */               tryDrainReferenceQueues();
/* 1738:2413 */             } else if (this.map.keyEquivalence.equivalent(key, entryKey)) {
/* 1739:2414 */               return e;
/* 1740:     */             }
/* 1741:     */           }
/* 1742:     */         }
/* 1743:     */       }
/* 1744:2419 */       return null;
/* 1745:     */     }
/* 1746:     */     
/* 1747:     */     MapMakerInternalMap.ReferenceEntry<K, V> getLiveEntry(Object key, int hash)
/* 1748:     */     {
/* 1749:2423 */       MapMakerInternalMap.ReferenceEntry<K, V> e = getEntry(key, hash);
/* 1750:2424 */       if (e == null) {
/* 1751:2425 */         return null;
/* 1752:     */       }
/* 1753:2426 */       if ((this.map.expires()) && (this.map.isExpired(e)))
/* 1754:     */       {
/* 1755:2427 */         tryExpireEntries();
/* 1756:2428 */         return null;
/* 1757:     */       }
/* 1758:2430 */       return e;
/* 1759:     */     }
/* 1760:     */     
/* 1761:     */     V get(Object key, int hash)
/* 1762:     */     {
/* 1763:     */       try
/* 1764:     */       {
/* 1765:2435 */         MapMakerInternalMap.ReferenceEntry<K, V> e = getLiveEntry(key, hash);
/* 1766:2436 */         if (e == null) {
/* 1767:2437 */           return null;
/* 1768:     */         }
/* 1769:2440 */         Object value = e.getValueReference().get();
/* 1770:2441 */         if (value != null) {
/* 1771:2442 */           recordRead(e);
/* 1772:     */         } else {
/* 1773:2444 */           tryDrainReferenceQueues();
/* 1774:     */         }
/* 1775:2446 */         return value;
/* 1776:     */       }
/* 1777:     */       finally
/* 1778:     */       {
/* 1779:2448 */         postReadCleanup();
/* 1780:     */       }
/* 1781:     */     }
/* 1782:     */     
/* 1783:     */     boolean containsKey(Object key, int hash)
/* 1784:     */     {
/* 1785:     */       try
/* 1786:     */       {
/* 1787:     */         MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1788:2454 */         if (this.count != 0)
/* 1789:     */         {
/* 1790:2455 */           e = getLiveEntry(key, hash);
/* 1791:     */           boolean bool;
/* 1792:2456 */           if (e == null) {
/* 1793:2457 */             return false;
/* 1794:     */           }
/* 1795:2459 */           return e.getValueReference().get() != null;
/* 1796:     */         }
/* 1797:2462 */         return 0;
/* 1798:     */       }
/* 1799:     */       finally
/* 1800:     */       {
/* 1801:2464 */         postReadCleanup();
/* 1802:     */       }
/* 1803:     */     }
/* 1804:     */     
/* 1805:     */     @VisibleForTesting
/* 1806:     */     boolean containsValue(Object value)
/* 1807:     */     {
/* 1808:     */       try
/* 1809:     */       {
/* 1810:     */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table;
/* 1811:2475 */         if (this.count != 0)
/* 1812:     */         {
/* 1813:2476 */           table = this.table;
/* 1814:2477 */           int length = table.length();
/* 1815:2478 */           for (int i = 0; i < length; i++) {
/* 1816:2479 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)table.get(i); e != null; e = e.getNext())
/* 1817:     */             {
/* 1818:2480 */               V entryValue = getLiveValue(e);
/* 1819:2481 */               if (entryValue != null) {
/* 1820:2484 */                 if (this.map.valueEquivalence.equivalent(value, entryValue)) {
/* 1821:2485 */                   return true;
/* 1822:     */                 }
/* 1823:     */               }
/* 1824:     */             }
/* 1825:     */           }
/* 1826:     */         }
/* 1827:2491 */         return 0;
/* 1828:     */       }
/* 1829:     */       finally
/* 1830:     */       {
/* 1831:2493 */         postReadCleanup();
/* 1832:     */       }
/* 1833:     */     }
/* 1834:     */     
/* 1835:     */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/* 1836:     */     {
/* 1837:2498 */       lock();
/* 1838:     */       try
/* 1839:     */       {
/* 1840:2500 */         preWriteCleanup();
/* 1841:     */         
/* 1842:2502 */         int newCount = this.count + 1;
/* 1843:2503 */         if (newCount > this.threshold)
/* 1844:     */         {
/* 1845:2504 */           expand();
/* 1846:2505 */           newCount = this.count + 1;
/* 1847:     */         }
/* 1848:2508 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1849:2509 */         int index = hash & table.length() - 1;
/* 1850:2510 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 1851:     */         K entryKey;
/* 1852:2513 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 1853:     */         {
/* 1854:2514 */           entryKey = e.getKey();
/* 1855:2515 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1856:     */           {
/* 1857:2519 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 1858:2520 */             V entryValue = valueReference.get();
/* 1859:     */             V ?;
/* 1860:2522 */             if (entryValue == null)
/* 1861:     */             {
/* 1862:2523 */               this.modCount += 1;
/* 1863:2524 */               setValue(e, value);
/* 1864:2525 */               if (!valueReference.isComputingReference())
/* 1865:     */               {
/* 1866:2526 */                 enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 1867:2527 */                 newCount = this.count;
/* 1868:     */               }
/* 1869:2528 */               else if (evictEntries())
/* 1870:     */               {
/* 1871:2529 */                 newCount = this.count + 1;
/* 1872:     */               }
/* 1873:2531 */               this.count = newCount;
/* 1874:2532 */               return null;
/* 1875:     */             }
/* 1876:2533 */             if (onlyIfAbsent)
/* 1877:     */             {
/* 1878:2537 */               recordLockedRead(e);
/* 1879:2538 */               return entryValue;
/* 1880:     */             }
/* 1881:2541 */             this.modCount += 1;
/* 1882:2542 */             enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 1883:2543 */             setValue(e, value);
/* 1884:2544 */             return entryValue;
/* 1885:     */           }
/* 1886:     */         }
/* 1887:2550 */         this.modCount += 1;
/* 1888:2551 */         MapMakerInternalMap.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 1889:2552 */         setValue(newEntry, value);
/* 1890:2553 */         table.set(index, newEntry);
/* 1891:2554 */         if (evictEntries()) {
/* 1892:2555 */           newCount = this.count + 1;
/* 1893:     */         }
/* 1894:2557 */         this.count = newCount;
/* 1895:2558 */         return null;
/* 1896:     */       }
/* 1897:     */       finally
/* 1898:     */       {
/* 1899:2560 */         unlock();
/* 1900:2561 */         postWriteCleanup();
/* 1901:     */       }
/* 1902:     */     }
/* 1903:     */     
/* 1904:     */     @GuardedBy("Segment.this")
/* 1905:     */     void expand()
/* 1906:     */     {
/* 1907:2570 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> oldTable = this.table;
/* 1908:2571 */       int oldCapacity = oldTable.length();
/* 1909:2572 */       if (oldCapacity >= 1073741824) {
/* 1910:2573 */         return;
/* 1911:     */       }
/* 1912:2586 */       int newCount = this.count;
/* 1913:2587 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newTable = newEntryArray(oldCapacity << 1);
/* 1914:2588 */       this.threshold = (newTable.length() * 3 / 4);
/* 1915:2589 */       int newMask = newTable.length() - 1;
/* 1916:2590 */       for (int oldIndex = 0; oldIndex < oldCapacity; oldIndex++)
/* 1917:     */       {
/* 1918:2593 */         MapMakerInternalMap.ReferenceEntry<K, V> head = (MapMakerInternalMap.ReferenceEntry)oldTable.get(oldIndex);
/* 1919:2595 */         if (head != null)
/* 1920:     */         {
/* 1921:2596 */           MapMakerInternalMap.ReferenceEntry<K, V> next = head.getNext();
/* 1922:2597 */           int headIndex = head.getHash() & newMask;
/* 1923:2600 */           if (next == null)
/* 1924:     */           {
/* 1925:2601 */             newTable.set(headIndex, head);
/* 1926:     */           }
/* 1927:     */           else
/* 1928:     */           {
/* 1929:2606 */             MapMakerInternalMap.ReferenceEntry<K, V> tail = head;
/* 1930:2607 */             int tailIndex = headIndex;
/* 1931:2608 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = next; e != null; e = e.getNext())
/* 1932:     */             {
/* 1933:2609 */               int newIndex = e.getHash() & newMask;
/* 1934:2610 */               if (newIndex != tailIndex)
/* 1935:     */               {
/* 1936:2612 */                 tailIndex = newIndex;
/* 1937:2613 */                 tail = e;
/* 1938:     */               }
/* 1939:     */             }
/* 1940:2616 */             newTable.set(tailIndex, tail);
/* 1941:2619 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = head; e != tail; e = e.getNext())
/* 1942:     */             {
/* 1943:2620 */               int newIndex = e.getHash() & newMask;
/* 1944:2621 */               MapMakerInternalMap.ReferenceEntry<K, V> newNext = (MapMakerInternalMap.ReferenceEntry)newTable.get(newIndex);
/* 1945:2622 */               MapMakerInternalMap.ReferenceEntry<K, V> newFirst = copyEntry(e, newNext);
/* 1946:2623 */               if (newFirst != null)
/* 1947:     */               {
/* 1948:2624 */                 newTable.set(newIndex, newFirst);
/* 1949:     */               }
/* 1950:     */               else
/* 1951:     */               {
/* 1952:2626 */                 removeCollectedEntry(e);
/* 1953:2627 */                 newCount--;
/* 1954:     */               }
/* 1955:     */             }
/* 1956:     */           }
/* 1957:     */         }
/* 1958:     */       }
/* 1959:2633 */       this.table = newTable;
/* 1960:2634 */       this.count = newCount;
/* 1961:     */     }
/* 1962:     */     
/* 1963:     */     boolean replace(K key, int hash, V oldValue, V newValue)
/* 1964:     */     {
/* 1965:2638 */       lock();
/* 1966:     */       try
/* 1967:     */       {
/* 1968:2640 */         preWriteCleanup();
/* 1969:     */         
/* 1970:2642 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1971:2643 */         int index = hash & table.length() - 1;
/* 1972:2644 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 1973:2646 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 1974:     */         {
/* 1975:2647 */           K entryKey = e.getKey();
/* 1976:2648 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1977:     */           {
/* 1978:2652 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 1979:2653 */             V entryValue = valueReference.get();
/* 1980:     */             int newCount;
/* 1981:2654 */             if (entryValue == null)
/* 1982:     */             {
/* 1983:2655 */               if (isCollected(valueReference))
/* 1984:     */               {
/* 1985:2656 */                 newCount = this.count - 1;
/* 1986:2657 */                 this.modCount += 1;
/* 1987:2658 */                 enqueueNotification(entryKey, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 1988:2659 */                 MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 1989:2660 */                 newCount = this.count - 1;
/* 1990:2661 */                 table.set(index, newFirst);
/* 1991:2662 */                 this.count = newCount;
/* 1992:     */               }
/* 1993:2664 */               return 0;
/* 1994:     */             }
/* 1995:2667 */             if (this.map.valueEquivalence.equivalent(oldValue, entryValue))
/* 1996:     */             {
/* 1997:2668 */               this.modCount += 1;
/* 1998:2669 */               enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 1999:2670 */               setValue(e, newValue);
/* 2000:2671 */               return 1;
/* 2001:     */             }
/* 2002:2675 */             recordLockedRead(e);
/* 2003:2676 */             return 0;
/* 2004:     */           }
/* 2005:     */         }
/* 2006:2681 */         return 0;
/* 2007:     */       }
/* 2008:     */       finally
/* 2009:     */       {
/* 2010:2683 */         unlock();
/* 2011:2684 */         postWriteCleanup();
/* 2012:     */       }
/* 2013:     */     }
/* 2014:     */     
/* 2015:     */     V replace(K key, int hash, V newValue)
/* 2016:     */     {
/* 2017:2689 */       lock();
/* 2018:     */       try
/* 2019:     */       {
/* 2020:2691 */         preWriteCleanup();
/* 2021:     */         
/* 2022:2693 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2023:2694 */         int index = hash & table.length() - 1;
/* 2024:2695 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2025:2697 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2026:     */         {
/* 2027:2698 */           K entryKey = e.getKey();
/* 2028:2699 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2029:     */           {
/* 2030:2703 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2031:2704 */             V entryValue = valueReference.get();
/* 2032:     */             int newCount;
/* 2033:2705 */             if (entryValue == null)
/* 2034:     */             {
/* 2035:2706 */               if (isCollected(valueReference))
/* 2036:     */               {
/* 2037:2707 */                 newCount = this.count - 1;
/* 2038:2708 */                 this.modCount += 1;
/* 2039:2709 */                 enqueueNotification(entryKey, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 2040:2710 */                 MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2041:2711 */                 newCount = this.count - 1;
/* 2042:2712 */                 table.set(index, newFirst);
/* 2043:2713 */                 this.count = newCount;
/* 2044:     */               }
/* 2045:2715 */               return null;
/* 2046:     */             }
/* 2047:2718 */             this.modCount += 1;
/* 2048:2719 */             enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 2049:2720 */             setValue(e, newValue);
/* 2050:2721 */             return entryValue;
/* 2051:     */           }
/* 2052:     */         }
/* 2053:2725 */         return null;
/* 2054:     */       }
/* 2055:     */       finally
/* 2056:     */       {
/* 2057:2727 */         unlock();
/* 2058:2728 */         postWriteCleanup();
/* 2059:     */       }
/* 2060:     */     }
/* 2061:     */     
/* 2062:     */     V remove(Object key, int hash)
/* 2063:     */     {
/* 2064:2733 */       lock();
/* 2065:     */       try
/* 2066:     */       {
/* 2067:2735 */         preWriteCleanup();
/* 2068:     */         
/* 2069:2737 */         int newCount = this.count - 1;
/* 2070:2738 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2071:2739 */         int index = hash & table.length() - 1;
/* 2072:2740 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2073:2742 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2074:     */         {
/* 2075:2743 */           K entryKey = e.getKey();
/* 2076:2744 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2077:     */           {
/* 2078:2746 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2079:2747 */             V entryValue = valueReference.get();
/* 2080:     */             MapMaker.RemovalCause cause;
/* 2081:2750 */             if (entryValue != null)
/* 2082:     */             {
/* 2083:2751 */               cause = MapMaker.RemovalCause.EXPLICIT;
/* 2084:     */             }
/* 2085:     */             else
/* 2086:     */             {
/* 2087:     */               MapMaker.RemovalCause cause;
/* 2088:2752 */               if (isCollected(valueReference)) {
/* 2089:2753 */                 cause = MapMaker.RemovalCause.COLLECTED;
/* 2090:     */               } else {
/* 2091:2755 */                 return null;
/* 2092:     */               }
/* 2093:     */             }
/* 2094:     */             MapMaker.RemovalCause cause;
/* 2095:2758 */             this.modCount += 1;
/* 2096:2759 */             enqueueNotification(entryKey, hash, entryValue, cause);
/* 2097:2760 */             Object newFirst = removeFromChain(first, e);
/* 2098:2761 */             newCount = this.count - 1;
/* 2099:2762 */             table.set(index, newFirst);
/* 2100:2763 */             this.count = newCount;
/* 2101:2764 */             return entryValue;
/* 2102:     */           }
/* 2103:     */         }
/* 2104:2768 */         return null;
/* 2105:     */       }
/* 2106:     */       finally
/* 2107:     */       {
/* 2108:2770 */         unlock();
/* 2109:2771 */         postWriteCleanup();
/* 2110:     */       }
/* 2111:     */     }
/* 2112:     */     
/* 2113:     */     boolean remove(Object key, int hash, Object value)
/* 2114:     */     {
/* 2115:2776 */       lock();
/* 2116:     */       try
/* 2117:     */       {
/* 2118:2778 */         preWriteCleanup();
/* 2119:     */         
/* 2120:2780 */         int newCount = this.count - 1;
/* 2121:2781 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2122:2782 */         int index = hash & table.length() - 1;
/* 2123:2783 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2124:2785 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2125:     */         {
/* 2126:2786 */           K entryKey = e.getKey();
/* 2127:2787 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2128:     */           {
/* 2129:2789 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2130:2790 */             V entryValue = valueReference.get();
/* 2131:     */             MapMaker.RemovalCause cause;
/* 2132:2793 */             if (this.map.valueEquivalence.equivalent(value, entryValue))
/* 2133:     */             {
/* 2134:2794 */               cause = MapMaker.RemovalCause.EXPLICIT;
/* 2135:     */             }
/* 2136:     */             else
/* 2137:     */             {
/* 2138:     */               MapMaker.RemovalCause cause;
/* 2139:2795 */               if (isCollected(valueReference)) {
/* 2140:2796 */                 cause = MapMaker.RemovalCause.COLLECTED;
/* 2141:     */               } else {
/* 2142:2798 */                 return false;
/* 2143:     */               }
/* 2144:     */             }
/* 2145:     */             MapMaker.RemovalCause cause;
/* 2146:2801 */             this.modCount += 1;
/* 2147:2802 */             enqueueNotification(entryKey, hash, entryValue, cause);
/* 2148:2803 */             Object newFirst = removeFromChain(first, e);
/* 2149:2804 */             newCount = this.count - 1;
/* 2150:2805 */             table.set(index, newFirst);
/* 2151:2806 */             this.count = newCount;
/* 2152:2807 */             return cause == MapMaker.RemovalCause.EXPLICIT;
/* 2153:     */           }
/* 2154:     */         }
/* 2155:2811 */         return 0;
/* 2156:     */       }
/* 2157:     */       finally
/* 2158:     */       {
/* 2159:2813 */         unlock();
/* 2160:2814 */         postWriteCleanup();
/* 2161:     */       }
/* 2162:     */     }
/* 2163:     */     
/* 2164:     */     void clear()
/* 2165:     */     {
/* 2166:2819 */       if (this.count != 0)
/* 2167:     */       {
/* 2168:2820 */         lock();
/* 2169:     */         try
/* 2170:     */         {
/* 2171:2822 */           AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2172:2823 */           if (this.map.removalNotificationQueue != MapMakerInternalMap.DISCARDING_QUEUE) {
/* 2173:2824 */             for (int i = 0; i < table.length(); i++) {
/* 2174:2825 */               for (MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)table.get(i); e != null; e = e.getNext()) {
/* 2175:2827 */                 if (!e.getValueReference().isComputingReference()) {
/* 2176:2828 */                   enqueueNotification(e, MapMaker.RemovalCause.EXPLICIT);
/* 2177:     */                 }
/* 2178:     */               }
/* 2179:     */             }
/* 2180:     */           }
/* 2181:2833 */           for (int i = 0; i < table.length(); i++) {
/* 2182:2834 */             table.set(i, null);
/* 2183:     */           }
/* 2184:2836 */           clearReferenceQueues();
/* 2185:2837 */           this.evictionQueue.clear();
/* 2186:2838 */           this.expirationQueue.clear();
/* 2187:2839 */           this.readCount.set(0);
/* 2188:     */           
/* 2189:2841 */           this.modCount += 1;
/* 2190:2842 */           this.count = 0;
/* 2191:     */         }
/* 2192:     */         finally
/* 2193:     */         {
/* 2194:2844 */           unlock();
/* 2195:2845 */           postWriteCleanup();
/* 2196:     */         }
/* 2197:     */       }
/* 2198:     */     }
/* 2199:     */     
/* 2200:     */     @GuardedBy("Segment.this")
/* 2201:     */     MapMakerInternalMap.ReferenceEntry<K, V> removeFromChain(MapMakerInternalMap.ReferenceEntry<K, V> first, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2202:     */     {
/* 2203:2864 */       this.evictionQueue.remove(entry);
/* 2204:2865 */       this.expirationQueue.remove(entry);
/* 2205:     */       
/* 2206:2867 */       int newCount = this.count;
/* 2207:2868 */       MapMakerInternalMap.ReferenceEntry<K, V> newFirst = entry.getNext();
/* 2208:2869 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != entry; e = e.getNext())
/* 2209:     */       {
/* 2210:2870 */         MapMakerInternalMap.ReferenceEntry<K, V> next = copyEntry(e, newFirst);
/* 2211:2871 */         if (next != null)
/* 2212:     */         {
/* 2213:2872 */           newFirst = next;
/* 2214:     */         }
/* 2215:     */         else
/* 2216:     */         {
/* 2217:2874 */           removeCollectedEntry(e);
/* 2218:2875 */           newCount--;
/* 2219:     */         }
/* 2220:     */       }
/* 2221:2878 */       this.count = newCount;
/* 2222:2879 */       return newFirst;
/* 2223:     */     }
/* 2224:     */     
/* 2225:     */     void removeCollectedEntry(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2226:     */     {
/* 2227:2883 */       enqueueNotification(entry, MapMaker.RemovalCause.COLLECTED);
/* 2228:2884 */       this.evictionQueue.remove(entry);
/* 2229:2885 */       this.expirationQueue.remove(entry);
/* 2230:     */     }
/* 2231:     */     
/* 2232:     */     boolean reclaimKey(MapMakerInternalMap.ReferenceEntry<K, V> entry, int hash)
/* 2233:     */     {
/* 2234:2892 */       lock();
/* 2235:     */       try
/* 2236:     */       {
/* 2237:2894 */         int newCount = this.count - 1;
/* 2238:2895 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2239:2896 */         int index = hash & table.length() - 1;
/* 2240:2897 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2241:2899 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2242:2900 */           if (e == entry)
/* 2243:     */           {
/* 2244:2901 */             this.modCount += 1;
/* 2245:2902 */             enqueueNotification(e.getKey(), hash, e.getValueReference().get(), MapMaker.RemovalCause.COLLECTED);
/* 2246:     */             
/* 2247:2904 */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2248:2905 */             newCount = this.count - 1;
/* 2249:2906 */             table.set(index, newFirst);
/* 2250:2907 */             this.count = newCount;
/* 2251:2908 */             return true;
/* 2252:     */           }
/* 2253:     */         }
/* 2254:2912 */         return 0;
/* 2255:     */       }
/* 2256:     */       finally
/* 2257:     */       {
/* 2258:2914 */         unlock();
/* 2259:2915 */         postWriteCleanup();
/* 2260:     */       }
/* 2261:     */     }
/* 2262:     */     
/* 2263:     */     boolean reclaimValue(K key, int hash, MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2264:     */     {
/* 2265:2923 */       lock();
/* 2266:     */       try
/* 2267:     */       {
/* 2268:2925 */         int newCount = this.count - 1;
/* 2269:2926 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2270:2927 */         int index = hash & table.length() - 1;
/* 2271:2928 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2272:2930 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2273:     */         {
/* 2274:2931 */           K entryKey = e.getKey();
/* 2275:2932 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2276:     */           {
/* 2277:2934 */             MapMakerInternalMap.ValueReference<K, V> v = e.getValueReference();
/* 2278:     */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst;
/* 2279:2935 */             if (v == valueReference)
/* 2280:     */             {
/* 2281:2936 */               this.modCount += 1;
/* 2282:2937 */               enqueueNotification(key, hash, valueReference.get(), MapMaker.RemovalCause.COLLECTED);
/* 2283:2938 */               newFirst = removeFromChain(first, e);
/* 2284:2939 */               newCount = this.count - 1;
/* 2285:2940 */               table.set(index, newFirst);
/* 2286:2941 */               this.count = newCount;
/* 2287:2942 */               return true;
/* 2288:     */             }
/* 2289:2944 */             return 0;
/* 2290:     */           }
/* 2291:     */         }
/* 2292:2948 */         return 0;
/* 2293:     */       }
/* 2294:     */       finally
/* 2295:     */       {
/* 2296:2950 */         unlock();
/* 2297:2951 */         if (!isHeldByCurrentThread()) {
/* 2298:2952 */           postWriteCleanup();
/* 2299:     */         }
/* 2300:     */       }
/* 2301:     */     }
/* 2302:     */     
/* 2303:     */     boolean clearValue(K key, int hash, MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2304:     */     {
/* 2305:2961 */       lock();
/* 2306:     */       try
/* 2307:     */       {
/* 2308:2963 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2309:2964 */         int index = hash & table.length() - 1;
/* 2310:2965 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2311:2967 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2312:     */         {
/* 2313:2968 */           K entryKey = e.getKey();
/* 2314:2969 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2315:     */           {
/* 2316:2971 */             MapMakerInternalMap.ValueReference<K, V> v = e.getValueReference();
/* 2317:     */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst;
/* 2318:2972 */             if (v == valueReference)
/* 2319:     */             {
/* 2320:2973 */               newFirst = removeFromChain(first, e);
/* 2321:2974 */               table.set(index, newFirst);
/* 2322:2975 */               return true;
/* 2323:     */             }
/* 2324:2977 */             return 0;
/* 2325:     */           }
/* 2326:     */         }
/* 2327:2981 */         return 0;
/* 2328:     */       }
/* 2329:     */       finally
/* 2330:     */       {
/* 2331:2983 */         unlock();
/* 2332:2984 */         postWriteCleanup();
/* 2333:     */       }
/* 2334:     */     }
/* 2335:     */     
/* 2336:     */     @GuardedBy("Segment.this")
/* 2337:     */     boolean removeEntry(MapMakerInternalMap.ReferenceEntry<K, V> entry, int hash, MapMaker.RemovalCause cause)
/* 2338:     */     {
/* 2339:2990 */       int newCount = this.count - 1;
/* 2340:2991 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2341:2992 */       int index = hash & table.length() - 1;
/* 2342:2993 */       MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2343:2995 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2344:2996 */         if (e == entry)
/* 2345:     */         {
/* 2346:2997 */           this.modCount += 1;
/* 2347:2998 */           enqueueNotification(e.getKey(), hash, e.getValueReference().get(), cause);
/* 2348:2999 */           MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2349:3000 */           newCount = this.count - 1;
/* 2350:3001 */           table.set(index, newFirst);
/* 2351:3002 */           this.count = newCount;
/* 2352:3003 */           return true;
/* 2353:     */         }
/* 2354:     */       }
/* 2355:3007 */       return false;
/* 2356:     */     }
/* 2357:     */     
/* 2358:     */     boolean isCollected(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2359:     */     {
/* 2360:3015 */       if (valueReference.isComputingReference()) {
/* 2361:3016 */         return false;
/* 2362:     */       }
/* 2363:3018 */       return valueReference.get() == null;
/* 2364:     */     }
/* 2365:     */     
/* 2366:     */     V getLiveValue(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2367:     */     {
/* 2368:3026 */       if (entry.getKey() == null)
/* 2369:     */       {
/* 2370:3027 */         tryDrainReferenceQueues();
/* 2371:3028 */         return null;
/* 2372:     */       }
/* 2373:3030 */       V value = entry.getValueReference().get();
/* 2374:3031 */       if (value == null)
/* 2375:     */       {
/* 2376:3032 */         tryDrainReferenceQueues();
/* 2377:3033 */         return null;
/* 2378:     */       }
/* 2379:3036 */       if ((this.map.expires()) && (this.map.isExpired(entry)))
/* 2380:     */       {
/* 2381:3037 */         tryExpireEntries();
/* 2382:3038 */         return null;
/* 2383:     */       }
/* 2384:3040 */       return value;
/* 2385:     */     }
/* 2386:     */     
/* 2387:     */     void postReadCleanup()
/* 2388:     */     {
/* 2389:3049 */       if ((this.readCount.incrementAndGet() & 0x3F) == 0) {
/* 2390:3050 */         runCleanup();
/* 2391:     */       }
/* 2392:     */     }
/* 2393:     */     
/* 2394:     */     @GuardedBy("Segment.this")
/* 2395:     */     void preWriteCleanup()
/* 2396:     */     {
/* 2397:3062 */       runLockedCleanup();
/* 2398:     */     }
/* 2399:     */     
/* 2400:     */     void postWriteCleanup()
/* 2401:     */     {
/* 2402:3069 */       runUnlockedCleanup();
/* 2403:     */     }
/* 2404:     */     
/* 2405:     */     void runCleanup()
/* 2406:     */     {
/* 2407:3073 */       runLockedCleanup();
/* 2408:3074 */       runUnlockedCleanup();
/* 2409:     */     }
/* 2410:     */     
/* 2411:     */     void runLockedCleanup()
/* 2412:     */     {
/* 2413:3078 */       if (tryLock()) {
/* 2414:     */         try
/* 2415:     */         {
/* 2416:3080 */           drainReferenceQueues();
/* 2417:3081 */           expireEntries();
/* 2418:3082 */           this.readCount.set(0);
/* 2419:     */         }
/* 2420:     */         finally
/* 2421:     */         {
/* 2422:3084 */           unlock();
/* 2423:     */         }
/* 2424:     */       }
/* 2425:     */     }
/* 2426:     */     
/* 2427:     */     void runUnlockedCleanup()
/* 2428:     */     {
/* 2429:3091 */       if (!isHeldByCurrentThread()) {
/* 2430:3092 */         this.map.processPendingNotifications();
/* 2431:     */       }
/* 2432:     */     }
/* 2433:     */   }
/* 2434:     */   
/* 2435:     */   static final class EvictionQueue<K, V>
/* 2436:     */     extends AbstractQueue<MapMakerInternalMap.ReferenceEntry<K, V>>
/* 2437:     */   {
/* 2438:3112 */     final MapMakerInternalMap.ReferenceEntry<K, V> head = new MapMakerInternalMap.AbstractReferenceEntry()
/* 2439:     */     {
/* 2440:3114 */       MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = this;
/* 2441:     */       
/* 2442:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 2443:     */       {
/* 2444:3118 */         return this.nextEvictable;
/* 2445:     */       }
/* 2446:     */       
/* 2447:     */       public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 2448:     */       {
/* 2449:3123 */         this.nextEvictable = next;
/* 2450:     */       }
/* 2451:     */       
/* 2452:3126 */       MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = this;
/* 2453:     */       
/* 2454:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 2455:     */       {
/* 2456:3130 */         return this.previousEvictable;
/* 2457:     */       }
/* 2458:     */       
/* 2459:     */       public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2460:     */       {
/* 2461:3135 */         this.previousEvictable = previous;
/* 2462:     */       }
/* 2463:     */     };
/* 2464:     */     
/* 2465:     */     public boolean offer(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2466:     */     {
/* 2467:3144 */       MapMakerInternalMap.connectEvictables(entry.getPreviousEvictable(), entry.getNextEvictable());
/* 2468:     */       
/* 2469:     */ 
/* 2470:3147 */       MapMakerInternalMap.connectEvictables(this.head.getPreviousEvictable(), entry);
/* 2471:3148 */       MapMakerInternalMap.connectEvictables(entry, this.head);
/* 2472:     */       
/* 2473:3150 */       return true;
/* 2474:     */     }
/* 2475:     */     
/* 2476:     */     public MapMakerInternalMap.ReferenceEntry<K, V> peek()
/* 2477:     */     {
/* 2478:3155 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextEvictable();
/* 2479:3156 */       return next == this.head ? null : next;
/* 2480:     */     }
/* 2481:     */     
/* 2482:     */     public MapMakerInternalMap.ReferenceEntry<K, V> poll()
/* 2483:     */     {
/* 2484:3161 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextEvictable();
/* 2485:3162 */       if (next == this.head) {
/* 2486:3163 */         return null;
/* 2487:     */       }
/* 2488:3166 */       remove(next);
/* 2489:3167 */       return next;
/* 2490:     */     }
/* 2491:     */     
/* 2492:     */     public boolean remove(Object o)
/* 2493:     */     {
/* 2494:3173 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2495:3174 */       MapMakerInternalMap.ReferenceEntry<K, V> previous = e.getPreviousEvictable();
/* 2496:3175 */       MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextEvictable();
/* 2497:3176 */       MapMakerInternalMap.connectEvictables(previous, next);
/* 2498:3177 */       MapMakerInternalMap.nullifyEvictable(e);
/* 2499:     */       
/* 2500:3179 */       return next != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2501:     */     }
/* 2502:     */     
/* 2503:     */     public boolean contains(Object o)
/* 2504:     */     {
/* 2505:3185 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2506:3186 */       return e.getNextEvictable() != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2507:     */     }
/* 2508:     */     
/* 2509:     */     public boolean isEmpty()
/* 2510:     */     {
/* 2511:3191 */       return this.head.getNextEvictable() == this.head;
/* 2512:     */     }
/* 2513:     */     
/* 2514:     */     public int size()
/* 2515:     */     {
/* 2516:3196 */       int size = 0;
/* 2517:3197 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextEvictable(); e != this.head; e = e.getNextEvictable()) {
/* 2518:3198 */         size++;
/* 2519:     */       }
/* 2520:3200 */       return size;
/* 2521:     */     }
/* 2522:     */     
/* 2523:     */     public void clear()
/* 2524:     */     {
/* 2525:3205 */       MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextEvictable();
/* 2526:3206 */       while (e != this.head)
/* 2527:     */       {
/* 2528:3207 */         MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextEvictable();
/* 2529:3208 */         MapMakerInternalMap.nullifyEvictable(e);
/* 2530:3209 */         e = next;
/* 2531:     */       }
/* 2532:3212 */       this.head.setNextEvictable(this.head);
/* 2533:3213 */       this.head.setPreviousEvictable(this.head);
/* 2534:     */     }
/* 2535:     */     
/* 2536:     */     public Iterator<MapMakerInternalMap.ReferenceEntry<K, V>> iterator()
/* 2537:     */     {
/* 2538:3218 */       new AbstractSequentialIterator(peek())
/* 2539:     */       {
/* 2540:     */         protected MapMakerInternalMap.ReferenceEntry<K, V> computeNext(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2541:     */         {
/* 2542:3221 */           MapMakerInternalMap.ReferenceEntry<K, V> next = previous.getNextEvictable();
/* 2543:3222 */           return next == MapMakerInternalMap.EvictionQueue.this.head ? null : next;
/* 2544:     */         }
/* 2545:     */       };
/* 2546:     */     }
/* 2547:     */   }
/* 2548:     */   
/* 2549:     */   static final class ExpirationQueue<K, V>
/* 2550:     */     extends AbstractQueue<MapMakerInternalMap.ReferenceEntry<K, V>>
/* 2551:     */   {
/* 2552:3240 */     final MapMakerInternalMap.ReferenceEntry<K, V> head = new MapMakerInternalMap.AbstractReferenceEntry()
/* 2553:     */     {
/* 2554:     */       public long getExpirationTime()
/* 2555:     */       {
/* 2556:3244 */         return 9223372036854775807L;
/* 2557:     */       }
/* 2558:     */       
/* 2559:3250 */       MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = this;
/* 2560:     */       
/* 2561:     */       public void setExpirationTime(long time) {}
/* 2562:     */       
/* 2563:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 2564:     */       {
/* 2565:3254 */         return this.nextExpirable;
/* 2566:     */       }
/* 2567:     */       
/* 2568:     */       public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 2569:     */       {
/* 2570:3259 */         this.nextExpirable = next;
/* 2571:     */       }
/* 2572:     */       
/* 2573:3262 */       MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = this;
/* 2574:     */       
/* 2575:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 2576:     */       {
/* 2577:3266 */         return this.previousExpirable;
/* 2578:     */       }
/* 2579:     */       
/* 2580:     */       public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2581:     */       {
/* 2582:3271 */         this.previousExpirable = previous;
/* 2583:     */       }
/* 2584:     */     };
/* 2585:     */     
/* 2586:     */     public boolean offer(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2587:     */     {
/* 2588:3280 */       MapMakerInternalMap.connectExpirables(entry.getPreviousExpirable(), entry.getNextExpirable());
/* 2589:     */       
/* 2590:     */ 
/* 2591:3283 */       MapMakerInternalMap.connectExpirables(this.head.getPreviousExpirable(), entry);
/* 2592:3284 */       MapMakerInternalMap.connectExpirables(entry, this.head);
/* 2593:     */       
/* 2594:3286 */       return true;
/* 2595:     */     }
/* 2596:     */     
/* 2597:     */     public MapMakerInternalMap.ReferenceEntry<K, V> peek()
/* 2598:     */     {
/* 2599:3291 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextExpirable();
/* 2600:3292 */       return next == this.head ? null : next;
/* 2601:     */     }
/* 2602:     */     
/* 2603:     */     public MapMakerInternalMap.ReferenceEntry<K, V> poll()
/* 2604:     */     {
/* 2605:3297 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextExpirable();
/* 2606:3298 */       if (next == this.head) {
/* 2607:3299 */         return null;
/* 2608:     */       }
/* 2609:3302 */       remove(next);
/* 2610:3303 */       return next;
/* 2611:     */     }
/* 2612:     */     
/* 2613:     */     public boolean remove(Object o)
/* 2614:     */     {
/* 2615:3309 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2616:3310 */       MapMakerInternalMap.ReferenceEntry<K, V> previous = e.getPreviousExpirable();
/* 2617:3311 */       MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextExpirable();
/* 2618:3312 */       MapMakerInternalMap.connectExpirables(previous, next);
/* 2619:3313 */       MapMakerInternalMap.nullifyExpirable(e);
/* 2620:     */       
/* 2621:3315 */       return next != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2622:     */     }
/* 2623:     */     
/* 2624:     */     public boolean contains(Object o)
/* 2625:     */     {
/* 2626:3321 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2627:3322 */       return e.getNextExpirable() != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2628:     */     }
/* 2629:     */     
/* 2630:     */     public boolean isEmpty()
/* 2631:     */     {
/* 2632:3327 */       return this.head.getNextExpirable() == this.head;
/* 2633:     */     }
/* 2634:     */     
/* 2635:     */     public int size()
/* 2636:     */     {
/* 2637:3332 */       int size = 0;
/* 2638:3333 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextExpirable(); e != this.head; e = e.getNextExpirable()) {
/* 2639:3334 */         size++;
/* 2640:     */       }
/* 2641:3336 */       return size;
/* 2642:     */     }
/* 2643:     */     
/* 2644:     */     public void clear()
/* 2645:     */     {
/* 2646:3341 */       MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextExpirable();
/* 2647:3342 */       while (e != this.head)
/* 2648:     */       {
/* 2649:3343 */         MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextExpirable();
/* 2650:3344 */         MapMakerInternalMap.nullifyExpirable(e);
/* 2651:3345 */         e = next;
/* 2652:     */       }
/* 2653:3348 */       this.head.setNextExpirable(this.head);
/* 2654:3349 */       this.head.setPreviousExpirable(this.head);
/* 2655:     */     }
/* 2656:     */     
/* 2657:     */     public Iterator<MapMakerInternalMap.ReferenceEntry<K, V>> iterator()
/* 2658:     */     {
/* 2659:3354 */       new AbstractSequentialIterator(peek())
/* 2660:     */       {
/* 2661:     */         protected MapMakerInternalMap.ReferenceEntry<K, V> computeNext(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2662:     */         {
/* 2663:3357 */           MapMakerInternalMap.ReferenceEntry<K, V> next = previous.getNextExpirable();
/* 2664:3358 */           return next == MapMakerInternalMap.ExpirationQueue.this.head ? null : next;
/* 2665:     */         }
/* 2666:     */       };
/* 2667:     */     }
/* 2668:     */   }
/* 2669:     */   
/* 2670:     */   static final class CleanupMapTask
/* 2671:     */     implements Runnable
/* 2672:     */   {
/* 2673:     */     final WeakReference<MapMakerInternalMap<?, ?>> mapReference;
/* 2674:     */     
/* 2675:     */     public CleanupMapTask(MapMakerInternalMap<?, ?> map)
/* 2676:     */     {
/* 2677:3368 */       this.mapReference = new WeakReference(map);
/* 2678:     */     }
/* 2679:     */     
/* 2680:     */     public void run()
/* 2681:     */     {
/* 2682:3373 */       MapMakerInternalMap<?, ?> map = (MapMakerInternalMap)this.mapReference.get();
/* 2683:3374 */       if (map == null) {
/* 2684:3375 */         throw new CancellationException();
/* 2685:     */       }
/* 2686:3378 */       for (MapMakerInternalMap.Segment<?, ?> segment : map.segments) {
/* 2687:3379 */         segment.runCleanup();
/* 2688:     */       }
/* 2689:     */     }
/* 2690:     */   }
/* 2691:     */   
/* 2692:     */   public boolean isEmpty()
/* 2693:     */   {
/* 2694:3395 */     long sum = 0L;
/* 2695:3396 */     Segment<K, V>[] segments = this.segments;
/* 2696:3397 */     for (int i = 0; i < segments.length; i++)
/* 2697:     */     {
/* 2698:3398 */       if (segments[i].count != 0) {
/* 2699:3399 */         return false;
/* 2700:     */       }
/* 2701:3401 */       sum += segments[i].modCount;
/* 2702:     */     }
/* 2703:3404 */     if (sum != 0L)
/* 2704:     */     {
/* 2705:3405 */       for (int i = 0; i < segments.length; i++)
/* 2706:     */       {
/* 2707:3406 */         if (segments[i].count != 0) {
/* 2708:3407 */           return false;
/* 2709:     */         }
/* 2710:3409 */         sum -= segments[i].modCount;
/* 2711:     */       }
/* 2712:3411 */       if (sum != 0L) {
/* 2713:3412 */         return false;
/* 2714:     */       }
/* 2715:     */     }
/* 2716:3415 */     return true;
/* 2717:     */   }
/* 2718:     */   
/* 2719:     */   public int size()
/* 2720:     */   {
/* 2721:3420 */     Segment<K, V>[] segments = this.segments;
/* 2722:3421 */     long sum = 0L;
/* 2723:3422 */     for (int i = 0; i < segments.length; i++) {
/* 2724:3423 */       sum += segments[i].count;
/* 2725:     */     }
/* 2726:3425 */     return Ints.saturatedCast(sum);
/* 2727:     */   }
/* 2728:     */   
/* 2729:     */   public V get(@Nullable Object key)
/* 2730:     */   {
/* 2731:3430 */     if (key == null) {
/* 2732:3431 */       return null;
/* 2733:     */     }
/* 2734:3433 */     int hash = hash(key);
/* 2735:3434 */     return segmentFor(hash).get(key, hash);
/* 2736:     */   }
/* 2737:     */   
/* 2738:     */   ReferenceEntry<K, V> getEntry(@Nullable Object key)
/* 2739:     */   {
/* 2740:3442 */     if (key == null) {
/* 2741:3443 */       return null;
/* 2742:     */     }
/* 2743:3445 */     int hash = hash(key);
/* 2744:3446 */     return segmentFor(hash).getEntry(key, hash);
/* 2745:     */   }
/* 2746:     */   
/* 2747:     */   public boolean containsKey(@Nullable Object key)
/* 2748:     */   {
/* 2749:3451 */     if (key == null) {
/* 2750:3452 */       return false;
/* 2751:     */     }
/* 2752:3454 */     int hash = hash(key);
/* 2753:3455 */     return segmentFor(hash).containsKey(key, hash);
/* 2754:     */   }
/* 2755:     */   
/* 2756:     */   public boolean containsValue(@Nullable Object value)
/* 2757:     */   {
/* 2758:3460 */     if (value == null) {
/* 2759:3461 */       return false;
/* 2760:     */     }
/* 2761:3469 */     Segment<K, V>[] segments = this.segments;
/* 2762:3470 */     long last = -1L;
/* 2763:3471 */     for (int i = 0; i < 3; i++)
/* 2764:     */     {
/* 2765:3472 */       long sum = 0L;
/* 2766:3473 */       for (Segment<K, V> segment : segments)
/* 2767:     */       {
/* 2768:3476 */         int c = segment.count;
/* 2769:     */         
/* 2770:3478 */         AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;
/* 2771:3479 */         for (int j = 0; j < table.length(); j++) {
/* 2772:3480 */           for (ReferenceEntry<K, V> e = (ReferenceEntry)table.get(j); e != null; e = e.getNext())
/* 2773:     */           {
/* 2774:3481 */             V v = segment.getLiveValue(e);
/* 2775:3482 */             if ((v != null) && (this.valueEquivalence.equivalent(value, v))) {
/* 2776:3483 */               return true;
/* 2777:     */             }
/* 2778:     */           }
/* 2779:     */         }
/* 2780:3487 */         sum += segment.modCount;
/* 2781:     */       }
/* 2782:3489 */       if (sum == last) {
/* 2783:     */         break;
/* 2784:     */       }
/* 2785:3492 */       last = sum;
/* 2786:     */     }
/* 2787:3494 */     return false;
/* 2788:     */   }
/* 2789:     */   
/* 2790:     */   public V put(K key, V value)
/* 2791:     */   {
/* 2792:3499 */     Preconditions.checkNotNull(key);
/* 2793:3500 */     Preconditions.checkNotNull(value);
/* 2794:3501 */     int hash = hash(key);
/* 2795:3502 */     return segmentFor(hash).put(key, hash, value, false);
/* 2796:     */   }
/* 2797:     */   
/* 2798:     */   public V putIfAbsent(K key, V value)
/* 2799:     */   {
/* 2800:3507 */     Preconditions.checkNotNull(key);
/* 2801:3508 */     Preconditions.checkNotNull(value);
/* 2802:3509 */     int hash = hash(key);
/* 2803:3510 */     return segmentFor(hash).put(key, hash, value, true);
/* 2804:     */   }
/* 2805:     */   
/* 2806:     */   public void putAll(Map<? extends K, ? extends V> m)
/* 2807:     */   {
/* 2808:3515 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 2809:3516 */       put(e.getKey(), e.getValue());
/* 2810:     */     }
/* 2811:     */   }
/* 2812:     */   
/* 2813:     */   public V remove(@Nullable Object key)
/* 2814:     */   {
/* 2815:3522 */     if (key == null) {
/* 2816:3523 */       return null;
/* 2817:     */     }
/* 2818:3525 */     int hash = hash(key);
/* 2819:3526 */     return segmentFor(hash).remove(key, hash);
/* 2820:     */   }
/* 2821:     */   
/* 2822:     */   public boolean remove(@Nullable Object key, @Nullable Object value)
/* 2823:     */   {
/* 2824:3531 */     if ((key == null) || (value == null)) {
/* 2825:3532 */       return false;
/* 2826:     */     }
/* 2827:3534 */     int hash = hash(key);
/* 2828:3535 */     return segmentFor(hash).remove(key, hash, value);
/* 2829:     */   }
/* 2830:     */   
/* 2831:     */   public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 2832:     */   {
/* 2833:3540 */     Preconditions.checkNotNull(key);
/* 2834:3541 */     Preconditions.checkNotNull(newValue);
/* 2835:3542 */     if (oldValue == null) {
/* 2836:3543 */       return false;
/* 2837:     */     }
/* 2838:3545 */     int hash = hash(key);
/* 2839:3546 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/* 2840:     */   }
/* 2841:     */   
/* 2842:     */   public V replace(K key, V value)
/* 2843:     */   {
/* 2844:3551 */     Preconditions.checkNotNull(key);
/* 2845:3552 */     Preconditions.checkNotNull(value);
/* 2846:3553 */     int hash = hash(key);
/* 2847:3554 */     return segmentFor(hash).replace(key, hash, value);
/* 2848:     */   }
/* 2849:     */   
/* 2850:     */   public void clear()
/* 2851:     */   {
/* 2852:3559 */     for (Segment<K, V> segment : this.segments) {
/* 2853:3560 */       segment.clear();
/* 2854:     */     }
/* 2855:     */   }
/* 2856:     */   
/* 2857:     */   public Set<K> keySet()
/* 2858:     */   {
/* 2859:3568 */     Set<K> ks = this.keySet;
/* 2860:3569 */     return this.keySet = new KeySet();
/* 2861:     */   }
/* 2862:     */   
/* 2863:     */   public Collection<V> values()
/* 2864:     */   {
/* 2865:3576 */     Collection<V> vs = this.values;
/* 2866:3577 */     return this.values = new Values();
/* 2867:     */   }
/* 2868:     */   
/* 2869:     */   public Set<Map.Entry<K, V>> entrySet()
/* 2870:     */   {
/* 2871:3584 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 2872:3585 */     return this.entrySet = new EntrySet();
/* 2873:     */   }
/* 2874:     */   
/* 2875:     */   abstract class HashIterator<E>
/* 2876:     */     implements Iterator<E>
/* 2877:     */   {
/* 2878:     */     int nextSegmentIndex;
/* 2879:     */     int nextTableIndex;
/* 2880:     */     MapMakerInternalMap.Segment<K, V> currentSegment;
/* 2881:     */     AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> currentTable;
/* 2882:     */     MapMakerInternalMap.ReferenceEntry<K, V> nextEntry;
/* 2883:     */     MapMakerInternalMap<K, V>.WriteThroughEntry nextExternal;
/* 2884:     */     MapMakerInternalMap<K, V>.WriteThroughEntry lastReturned;
/* 2885:     */     
/* 2886:     */     HashIterator()
/* 2887:     */     {
/* 2888:3601 */       this.nextSegmentIndex = (MapMakerInternalMap.this.segments.length - 1);
/* 2889:3602 */       this.nextTableIndex = -1;
/* 2890:3603 */       advance();
/* 2891:     */     }
/* 2892:     */     
/* 2893:     */     public abstract E next();
/* 2894:     */     
/* 2895:     */     final void advance()
/* 2896:     */     {
/* 2897:3610 */       this.nextExternal = null;
/* 2898:3612 */       if (nextInChain()) {
/* 2899:3613 */         return;
/* 2900:     */       }
/* 2901:3616 */       if (nextInTable()) {
/* 2902:3617 */         return;
/* 2903:     */       }
/* 2904:3620 */       while (this.nextSegmentIndex >= 0)
/* 2905:     */       {
/* 2906:3621 */         this.currentSegment = MapMakerInternalMap.this.segments[(this.nextSegmentIndex--)];
/* 2907:3622 */         if (this.currentSegment.count != 0)
/* 2908:     */         {
/* 2909:3623 */           this.currentTable = this.currentSegment.table;
/* 2910:3624 */           this.nextTableIndex = (this.currentTable.length() - 1);
/* 2911:3625 */           if (nextInTable()) {}
/* 2912:     */         }
/* 2913:     */       }
/* 2914:     */     }
/* 2915:     */     
/* 2916:     */     boolean nextInChain()
/* 2917:     */     {
/* 2918:3636 */       if (this.nextEntry != null) {
/* 2919:3637 */         for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; this.nextEntry = this.nextEntry.getNext()) {
/* 2920:3638 */           if (advanceTo(this.nextEntry)) {
/* 2921:3639 */             return true;
/* 2922:     */           }
/* 2923:     */         }
/* 2924:     */       }
/* 2925:3643 */       return false;
/* 2926:     */     }
/* 2927:     */     
/* 2928:     */     boolean nextInTable()
/* 2929:     */     {
/* 2930:3650 */       while (this.nextTableIndex >= 0) {
/* 2931:3651 */         if (((this.nextEntry = (MapMakerInternalMap.ReferenceEntry)this.currentTable.get(this.nextTableIndex--)) != null) && (
/* 2932:3652 */           (advanceTo(this.nextEntry)) || (nextInChain()))) {
/* 2933:3653 */           return true;
/* 2934:     */         }
/* 2935:     */       }
/* 2936:3657 */       return false;
/* 2937:     */     }
/* 2938:     */     
/* 2939:     */     boolean advanceTo(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2940:     */     {
/* 2941:     */       try
/* 2942:     */       {
/* 2943:3666 */         K key = entry.getKey();
/* 2944:3667 */         V value = MapMakerInternalMap.this.getLiveValue(entry);
/* 2945:     */         boolean bool;
/* 2946:3668 */         if (value != null)
/* 2947:     */         {
/* 2948:3669 */           this.nextExternal = new MapMakerInternalMap.WriteThroughEntry(MapMakerInternalMap.this, key, value);
/* 2949:3670 */           return true;
/* 2950:     */         }
/* 2951:3673 */         return false;
/* 2952:     */       }
/* 2953:     */       finally
/* 2954:     */       {
/* 2955:3676 */         this.currentSegment.postReadCleanup();
/* 2956:     */       }
/* 2957:     */     }
/* 2958:     */     
/* 2959:     */     public boolean hasNext()
/* 2960:     */     {
/* 2961:3682 */       return this.nextExternal != null;
/* 2962:     */     }
/* 2963:     */     
/* 2964:     */     MapMakerInternalMap<K, V>.WriteThroughEntry nextEntry()
/* 2965:     */     {
/* 2966:3686 */       if (this.nextExternal == null) {
/* 2967:3687 */         throw new NoSuchElementException();
/* 2968:     */       }
/* 2969:3689 */       this.lastReturned = this.nextExternal;
/* 2970:3690 */       advance();
/* 2971:3691 */       return this.lastReturned;
/* 2972:     */     }
/* 2973:     */     
/* 2974:     */     public void remove()
/* 2975:     */     {
/* 2976:3696 */       CollectPreconditions.checkRemove(this.lastReturned != null);
/* 2977:3697 */       MapMakerInternalMap.this.remove(this.lastReturned.getKey());
/* 2978:3698 */       this.lastReturned = null;
/* 2979:     */     }
/* 2980:     */   }
/* 2981:     */   
/* 2982:     */   final class KeyIterator
/* 2983:     */     extends MapMakerInternalMap<K, V>.HashIterator<K>
/* 2984:     */   {
/* 2985:     */     KeyIterator()
/* 2986:     */     {
/* 2987:3702 */       super();
/* 2988:     */     }
/* 2989:     */     
/* 2990:     */     public K next()
/* 2991:     */     {
/* 2992:3706 */       return nextEntry().getKey();
/* 2993:     */     }
/* 2994:     */   }
/* 2995:     */   
/* 2996:     */   final class ValueIterator
/* 2997:     */     extends MapMakerInternalMap<K, V>.HashIterator<V>
/* 2998:     */   {
/* 2999:     */     ValueIterator()
/* 3000:     */     {
/* 3001:3710 */       super();
/* 3002:     */     }
/* 3003:     */     
/* 3004:     */     public V next()
/* 3005:     */     {
/* 3006:3714 */       return nextEntry().getValue();
/* 3007:     */     }
/* 3008:     */   }
/* 3009:     */   
/* 3010:     */   final class WriteThroughEntry
/* 3011:     */     extends AbstractMapEntry<K, V>
/* 3012:     */   {
/* 3013:     */     final K key;
/* 3014:     */     V value;
/* 3015:     */     
/* 3016:     */     WriteThroughEntry(V key)
/* 3017:     */     {
/* 3018:3727 */       this.key = key;
/* 3019:3728 */       this.value = value;
/* 3020:     */     }
/* 3021:     */     
/* 3022:     */     public K getKey()
/* 3023:     */     {
/* 3024:3733 */       return this.key;
/* 3025:     */     }
/* 3026:     */     
/* 3027:     */     public V getValue()
/* 3028:     */     {
/* 3029:3738 */       return this.value;
/* 3030:     */     }
/* 3031:     */     
/* 3032:     */     public boolean equals(@Nullable Object object)
/* 3033:     */     {
/* 3034:3744 */       if ((object instanceof Map.Entry))
/* 3035:     */       {
/* 3036:3745 */         Map.Entry<?, ?> that = (Map.Entry)object;
/* 3037:3746 */         return (this.key.equals(that.getKey())) && (this.value.equals(that.getValue()));
/* 3038:     */       }
/* 3039:3748 */       return false;
/* 3040:     */     }
/* 3041:     */     
/* 3042:     */     public int hashCode()
/* 3043:     */     {
/* 3044:3754 */       return this.key.hashCode() ^ this.value.hashCode();
/* 3045:     */     }
/* 3046:     */     
/* 3047:     */     public V setValue(V newValue)
/* 3048:     */     {
/* 3049:3759 */       V oldValue = MapMakerInternalMap.this.put(this.key, newValue);
/* 3050:3760 */       this.value = newValue;
/* 3051:3761 */       return oldValue;
/* 3052:     */     }
/* 3053:     */   }
/* 3054:     */   
/* 3055:     */   final class EntryIterator
/* 3056:     */     extends MapMakerInternalMap<K, V>.HashIterator<Map.Entry<K, V>>
/* 3057:     */   {
/* 3058:     */     EntryIterator()
/* 3059:     */     {
/* 3060:3765 */       super();
/* 3061:     */     }
/* 3062:     */     
/* 3063:     */     public Map.Entry<K, V> next()
/* 3064:     */     {
/* 3065:3769 */       return nextEntry();
/* 3066:     */     }
/* 3067:     */   }
/* 3068:     */   
/* 3069:     */   final class KeySet
/* 3070:     */     extends AbstractSet<K>
/* 3071:     */   {
/* 3072:     */     KeySet() {}
/* 3073:     */     
/* 3074:     */     public Iterator<K> iterator()
/* 3075:     */     {
/* 3076:3777 */       return new MapMakerInternalMap.KeyIterator(MapMakerInternalMap.this);
/* 3077:     */     }
/* 3078:     */     
/* 3079:     */     public int size()
/* 3080:     */     {
/* 3081:3782 */       return MapMakerInternalMap.this.size();
/* 3082:     */     }
/* 3083:     */     
/* 3084:     */     public boolean isEmpty()
/* 3085:     */     {
/* 3086:3787 */       return MapMakerInternalMap.this.isEmpty();
/* 3087:     */     }
/* 3088:     */     
/* 3089:     */     public boolean contains(Object o)
/* 3090:     */     {
/* 3091:3792 */       return MapMakerInternalMap.this.containsKey(o);
/* 3092:     */     }
/* 3093:     */     
/* 3094:     */     public boolean remove(Object o)
/* 3095:     */     {
/* 3096:3797 */       return MapMakerInternalMap.this.remove(o) != null;
/* 3097:     */     }
/* 3098:     */     
/* 3099:     */     public void clear()
/* 3100:     */     {
/* 3101:3802 */       MapMakerInternalMap.this.clear();
/* 3102:     */     }
/* 3103:     */   }
/* 3104:     */   
/* 3105:     */   final class Values
/* 3106:     */     extends AbstractCollection<V>
/* 3107:     */   {
/* 3108:     */     Values() {}
/* 3109:     */     
/* 3110:     */     public Iterator<V> iterator()
/* 3111:     */     {
/* 3112:3810 */       return new MapMakerInternalMap.ValueIterator(MapMakerInternalMap.this);
/* 3113:     */     }
/* 3114:     */     
/* 3115:     */     public int size()
/* 3116:     */     {
/* 3117:3815 */       return MapMakerInternalMap.this.size();
/* 3118:     */     }
/* 3119:     */     
/* 3120:     */     public boolean isEmpty()
/* 3121:     */     {
/* 3122:3820 */       return MapMakerInternalMap.this.isEmpty();
/* 3123:     */     }
/* 3124:     */     
/* 3125:     */     public boolean contains(Object o)
/* 3126:     */     {
/* 3127:3825 */       return MapMakerInternalMap.this.containsValue(o);
/* 3128:     */     }
/* 3129:     */     
/* 3130:     */     public void clear()
/* 3131:     */     {
/* 3132:3830 */       MapMakerInternalMap.this.clear();
/* 3133:     */     }
/* 3134:     */   }
/* 3135:     */   
/* 3136:     */   final class EntrySet
/* 3137:     */     extends AbstractSet<Map.Entry<K, V>>
/* 3138:     */   {
/* 3139:     */     EntrySet() {}
/* 3140:     */     
/* 3141:     */     public Iterator<Map.Entry<K, V>> iterator()
/* 3142:     */     {
/* 3143:3838 */       return new MapMakerInternalMap.EntryIterator(MapMakerInternalMap.this);
/* 3144:     */     }
/* 3145:     */     
/* 3146:     */     public boolean contains(Object o)
/* 3147:     */     {
/* 3148:3843 */       if (!(o instanceof Map.Entry)) {
/* 3149:3844 */         return false;
/* 3150:     */       }
/* 3151:3846 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3152:3847 */       Object key = e.getKey();
/* 3153:3848 */       if (key == null) {
/* 3154:3849 */         return false;
/* 3155:     */       }
/* 3156:3851 */       V v = MapMakerInternalMap.this.get(key);
/* 3157:     */       
/* 3158:3853 */       return (v != null) && (MapMakerInternalMap.this.valueEquivalence.equivalent(e.getValue(), v));
/* 3159:     */     }
/* 3160:     */     
/* 3161:     */     public boolean remove(Object o)
/* 3162:     */     {
/* 3163:3858 */       if (!(o instanceof Map.Entry)) {
/* 3164:3859 */         return false;
/* 3165:     */       }
/* 3166:3861 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3167:3862 */       Object key = e.getKey();
/* 3168:3863 */       return (key != null) && (MapMakerInternalMap.this.remove(key, e.getValue()));
/* 3169:     */     }
/* 3170:     */     
/* 3171:     */     public int size()
/* 3172:     */     {
/* 3173:3868 */       return MapMakerInternalMap.this.size();
/* 3174:     */     }
/* 3175:     */     
/* 3176:     */     public boolean isEmpty()
/* 3177:     */     {
/* 3178:3873 */       return MapMakerInternalMap.this.isEmpty();
/* 3179:     */     }
/* 3180:     */     
/* 3181:     */     public void clear()
/* 3182:     */     {
/* 3183:3878 */       MapMakerInternalMap.this.clear();
/* 3184:     */     }
/* 3185:     */   }
/* 3186:     */   
/* 3187:     */   Object writeReplace()
/* 3188:     */   {
/* 3189:3887 */     return new SerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize, this.concurrencyLevel, this.removalListener, this);
/* 3190:     */   }
/* 3191:     */   
/* 3192:     */   static abstract class AbstractSerializationProxy<K, V>
/* 3193:     */     extends ForwardingConcurrentMap<K, V>
/* 3194:     */     implements Serializable
/* 3195:     */   {
/* 3196:     */     private static final long serialVersionUID = 3L;
/* 3197:     */     final MapMakerInternalMap.Strength keyStrength;
/* 3198:     */     final MapMakerInternalMap.Strength valueStrength;
/* 3199:     */     final Equivalence<Object> keyEquivalence;
/* 3200:     */     final Equivalence<Object> valueEquivalence;
/* 3201:     */     final long expireAfterWriteNanos;
/* 3202:     */     final long expireAfterAccessNanos;
/* 3203:     */     final int maximumSize;
/* 3204:     */     final int concurrencyLevel;
/* 3205:     */     final MapMaker.RemovalListener<? super K, ? super V> removalListener;
/* 3206:     */     transient ConcurrentMap<K, V> delegate;
/* 3207:     */     
/* 3208:     */     AbstractSerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate)
/* 3209:     */     {
/* 3210:3917 */       this.keyStrength = keyStrength;
/* 3211:3918 */       this.valueStrength = valueStrength;
/* 3212:3919 */       this.keyEquivalence = keyEquivalence;
/* 3213:3920 */       this.valueEquivalence = valueEquivalence;
/* 3214:3921 */       this.expireAfterWriteNanos = expireAfterWriteNanos;
/* 3215:3922 */       this.expireAfterAccessNanos = expireAfterAccessNanos;
/* 3216:3923 */       this.maximumSize = maximumSize;
/* 3217:3924 */       this.concurrencyLevel = concurrencyLevel;
/* 3218:3925 */       this.removalListener = removalListener;
/* 3219:3926 */       this.delegate = delegate;
/* 3220:     */     }
/* 3221:     */     
/* 3222:     */     protected ConcurrentMap<K, V> delegate()
/* 3223:     */     {
/* 3224:3931 */       return this.delegate;
/* 3225:     */     }
/* 3226:     */     
/* 3227:     */     void writeMapTo(ObjectOutputStream out)
/* 3228:     */       throws IOException
/* 3229:     */     {
/* 3230:3935 */       out.writeInt(this.delegate.size());
/* 3231:3936 */       for (Map.Entry<K, V> entry : this.delegate.entrySet())
/* 3232:     */       {
/* 3233:3937 */         out.writeObject(entry.getKey());
/* 3234:3938 */         out.writeObject(entry.getValue());
/* 3235:     */       }
/* 3236:3940 */       out.writeObject(null);
/* 3237:     */     }
/* 3238:     */     
/* 3239:     */     MapMaker readMapMaker(ObjectInputStream in)
/* 3240:     */       throws IOException
/* 3241:     */     {
/* 3242:3945 */       int size = in.readInt();
/* 3243:3946 */       MapMaker mapMaker = new MapMaker().initialCapacity(size).setKeyStrength(this.keyStrength).setValueStrength(this.valueStrength).keyEquivalence(this.keyEquivalence).concurrencyLevel(this.concurrencyLevel);
/* 3244:     */       
/* 3245:     */ 
/* 3246:     */ 
/* 3247:     */ 
/* 3248:     */ 
/* 3249:3952 */       mapMaker.removalListener(this.removalListener);
/* 3250:3953 */       if (this.expireAfterWriteNanos > 0L) {
/* 3251:3954 */         mapMaker.expireAfterWrite(this.expireAfterWriteNanos, TimeUnit.NANOSECONDS);
/* 3252:     */       }
/* 3253:3956 */       if (this.expireAfterAccessNanos > 0L) {
/* 3254:3957 */         mapMaker.expireAfterAccess(this.expireAfterAccessNanos, TimeUnit.NANOSECONDS);
/* 3255:     */       }
/* 3256:3959 */       if (this.maximumSize != -1) {
/* 3257:3960 */         mapMaker.maximumSize(this.maximumSize);
/* 3258:     */       }
/* 3259:3962 */       return mapMaker;
/* 3260:     */     }
/* 3261:     */     
/* 3262:     */     void readEntries(ObjectInputStream in)
/* 3263:     */       throws IOException, ClassNotFoundException
/* 3264:     */     {
/* 3265:     */       for (;;)
/* 3266:     */       {
/* 3267:3968 */         K key = in.readObject();
/* 3268:3969 */         if (key == null) {
/* 3269:     */           break;
/* 3270:     */         }
/* 3271:3972 */         V value = in.readObject();
/* 3272:3973 */         this.delegate.put(key, value);
/* 3273:     */       }
/* 3274:     */     }
/* 3275:     */   }
/* 3276:     */   
/* 3277:     */   private static final class SerializationProxy<K, V>
/* 3278:     */     extends MapMakerInternalMap.AbstractSerializationProxy<K, V>
/* 3279:     */   {
/* 3280:     */     private static final long serialVersionUID = 3L;
/* 3281:     */     
/* 3282:     */     SerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate)
/* 3283:     */     {
/* 3284:3990 */       super(valueStrength, keyEquivalence, valueEquivalence, expireAfterWriteNanos, expireAfterAccessNanos, maximumSize, concurrencyLevel, removalListener, delegate);
/* 3285:     */     }
/* 3286:     */     
/* 3287:     */     private void writeObject(ObjectOutputStream out)
/* 3288:     */       throws IOException
/* 3289:     */     {
/* 3290:3995 */       out.defaultWriteObject();
/* 3291:3996 */       writeMapTo(out);
/* 3292:     */     }
/* 3293:     */     
/* 3294:     */     private void readObject(ObjectInputStream in)
/* 3295:     */       throws IOException, ClassNotFoundException
/* 3296:     */     {
/* 3297:4000 */       in.defaultReadObject();
/* 3298:4001 */       MapMaker mapMaker = readMapMaker(in);
/* 3299:4002 */       this.delegate = mapMaker.makeMap();
/* 3300:4003 */       readEntries(in);
/* 3301:     */     }
/* 3302:     */     
/* 3303:     */     private Object readResolve()
/* 3304:     */     {
/* 3305:4007 */       return this.delegate;
/* 3306:     */     }
/* 3307:     */   }
/* 3308:     */   
/* 3309:     */   static abstract interface ReferenceEntry<K, V>
/* 3310:     */   {
/* 3311:     */     public abstract MapMakerInternalMap.ValueReference<K, V> getValueReference();
/* 3312:     */     
/* 3313:     */     public abstract void setValueReference(MapMakerInternalMap.ValueReference<K, V> paramValueReference);
/* 3314:     */     
/* 3315:     */     public abstract ReferenceEntry<K, V> getNext();
/* 3316:     */     
/* 3317:     */     public abstract int getHash();
/* 3318:     */     
/* 3319:     */     public abstract K getKey();
/* 3320:     */     
/* 3321:     */     public abstract long getExpirationTime();
/* 3322:     */     
/* 3323:     */     public abstract void setExpirationTime(long paramLong);
/* 3324:     */     
/* 3325:     */     public abstract ReferenceEntry<K, V> getNextExpirable();
/* 3326:     */     
/* 3327:     */     public abstract void setNextExpirable(ReferenceEntry<K, V> paramReferenceEntry);
/* 3328:     */     
/* 3329:     */     public abstract ReferenceEntry<K, V> getPreviousExpirable();
/* 3330:     */     
/* 3331:     */     public abstract void setPreviousExpirable(ReferenceEntry<K, V> paramReferenceEntry);
/* 3332:     */     
/* 3333:     */     public abstract ReferenceEntry<K, V> getNextEvictable();
/* 3334:     */     
/* 3335:     */     public abstract void setNextEvictable(ReferenceEntry<K, V> paramReferenceEntry);
/* 3336:     */     
/* 3337:     */     public abstract ReferenceEntry<K, V> getPreviousEvictable();
/* 3338:     */     
/* 3339:     */     public abstract void setPreviousEvictable(ReferenceEntry<K, V> paramReferenceEntry);
/* 3340:     */   }
/* 3341:     */   
/* 3342:     */   static abstract interface ValueReference<K, V>
/* 3343:     */   {
/* 3344:     */     public abstract V get();
/* 3345:     */     
/* 3346:     */     public abstract V waitForValue()
/* 3347:     */       throws ExecutionException;
/* 3348:     */     
/* 3349:     */     public abstract MapMakerInternalMap.ReferenceEntry<K, V> getEntry();
/* 3350:     */     
/* 3351:     */     public abstract ValueReference<K, V> copyFor(ReferenceQueue<V> paramReferenceQueue, @Nullable V paramV, MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry);
/* 3352:     */     
/* 3353:     */     public abstract void clear(@Nullable ValueReference<K, V> paramValueReference);
/* 3354:     */     
/* 3355:     */     public abstract boolean isComputingReference();
/* 3356:     */   }
/* 3357:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MapMakerInternalMap
 * JD-Core Version:    0.7.0.1
 */
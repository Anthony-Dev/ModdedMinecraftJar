/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Equivalence;
/*   6:    */ import com.google.common.base.Function;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.util.concurrent.ConcurrentMap;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public final class Interners
/*  12:    */ {
/*  13:    */   public static <E> Interner<E> newStrongInterner()
/*  14:    */   {
/*  15: 45 */     ConcurrentMap<E, E> map = new MapMaker().makeMap();
/*  16: 46 */     new Interner()
/*  17:    */     {
/*  18:    */       public E intern(E sample)
/*  19:    */       {
/*  20: 48 */         E canonical = this.val$map.putIfAbsent(Preconditions.checkNotNull(sample), sample);
/*  21: 49 */         return canonical == null ? sample : canonical;
/*  22:    */       }
/*  23:    */     };
/*  24:    */   }
/*  25:    */   
/*  26:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  27:    */   public static <E> Interner<E> newWeakInterner()
/*  28:    */   {
/*  29: 63 */     return new WeakInterner(null);
/*  30:    */   }
/*  31:    */   
/*  32:    */   private static class WeakInterner<E>
/*  33:    */     implements Interner<E>
/*  34:    */   {
/*  35:    */     private final MapMakerInternalMap<E, Dummy> map;
/*  36:    */     
/*  37:    */     private WeakInterner()
/*  38:    */     {
/*  39: 68 */       this.map = new MapMaker().weakKeys().keyEquivalence(Equivalence.equals()).makeCustomMap();
/*  40:    */     }
/*  41:    */     
/*  42:    */     public E intern(E sample)
/*  43:    */     {
/*  44:    */       for (;;)
/*  45:    */       {
/*  46: 76 */         MapMakerInternalMap.ReferenceEntry<E, Dummy> entry = this.map.getEntry(sample);
/*  47: 77 */         if (entry != null)
/*  48:    */         {
/*  49: 78 */           E canonical = entry.getKey();
/*  50: 79 */           if (canonical != null) {
/*  51: 80 */             return canonical;
/*  52:    */           }
/*  53:    */         }
/*  54: 85 */         Dummy sneaky = (Dummy)this.map.putIfAbsent(sample, Dummy.VALUE);
/*  55: 86 */         if (sneaky == null) {
/*  56: 87 */           return sample;
/*  57:    */         }
/*  58:    */       }
/*  59:    */     }
/*  60:    */     
/*  61:    */     private static enum Dummy
/*  62:    */     {
/*  63: 99 */       VALUE;
/*  64:    */       
/*  65:    */       private Dummy() {}
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <E> Function<E, E> asFunction(Interner<E> interner)
/*  70:    */   {
/*  71:108 */     return new InternerFunction((Interner)Preconditions.checkNotNull(interner));
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static class InternerFunction<E>
/*  75:    */     implements Function<E, E>
/*  76:    */   {
/*  77:    */     private final Interner<E> interner;
/*  78:    */     
/*  79:    */     public InternerFunction(Interner<E> interner)
/*  80:    */     {
/*  81:116 */       this.interner = interner;
/*  82:    */     }
/*  83:    */     
/*  84:    */     public E apply(E input)
/*  85:    */     {
/*  86:120 */       return this.interner.intern(input);
/*  87:    */     }
/*  88:    */     
/*  89:    */     public int hashCode()
/*  90:    */     {
/*  91:124 */       return this.interner.hashCode();
/*  92:    */     }
/*  93:    */     
/*  94:    */     public boolean equals(Object other)
/*  95:    */     {
/*  96:128 */       if ((other instanceof InternerFunction))
/*  97:    */       {
/*  98:129 */         InternerFunction<?> that = (InternerFunction)other;
/*  99:130 */         return this.interner.equals(that.interner);
/* 100:    */       }
/* 101:133 */       return false;
/* 102:    */     }
/* 103:    */   }
/* 104:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Interners
 * JD-Core Version:    0.7.0.1
 */
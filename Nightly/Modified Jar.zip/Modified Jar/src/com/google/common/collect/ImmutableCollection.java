/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.AbstractCollection;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ImmutableCollection<E>
/*  13:    */   extends AbstractCollection<E>
/*  14:    */   implements Serializable
/*  15:    */ {
/*  16:    */   private transient ImmutableList<E> asList;
/*  17:    */   
/*  18:    */   public abstract UnmodifiableIterator<E> iterator();
/*  19:    */   
/*  20:    */   public final Object[] toArray()
/*  21:    */   {
/*  22: 60 */     int size = size();
/*  23: 61 */     if (size == 0) {
/*  24: 62 */       return ObjectArrays.EMPTY_ARRAY;
/*  25:    */     }
/*  26: 64 */     Object[] result = new Object[size()];
/*  27: 65 */     copyIntoArray(result, 0);
/*  28: 66 */     return result;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public final <T> T[] toArray(T[] other)
/*  32:    */   {
/*  33: 71 */     Preconditions.checkNotNull(other);
/*  34: 72 */     int size = size();
/*  35: 73 */     if (other.length < size) {
/*  36: 74 */       other = ObjectArrays.newArray(other, size);
/*  37: 75 */     } else if (other.length > size) {
/*  38: 76 */       other[size] = null;
/*  39:    */     }
/*  40: 78 */     copyIntoArray(other, 0);
/*  41: 79 */     return other;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean contains(@Nullable Object object)
/*  45:    */   {
/*  46: 84 */     return (object != null) && (super.contains(object));
/*  47:    */   }
/*  48:    */   
/*  49:    */   @Deprecated
/*  50:    */   public final boolean add(E e)
/*  51:    */   {
/*  52: 96 */     throw new UnsupportedOperationException();
/*  53:    */   }
/*  54:    */   
/*  55:    */   @Deprecated
/*  56:    */   public final boolean remove(Object object)
/*  57:    */   {
/*  58:108 */     throw new UnsupportedOperationException();
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Deprecated
/*  62:    */   public final boolean addAll(Collection<? extends E> newElements)
/*  63:    */   {
/*  64:120 */     throw new UnsupportedOperationException();
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Deprecated
/*  68:    */   public final boolean removeAll(Collection<?> oldElements)
/*  69:    */   {
/*  70:132 */     throw new UnsupportedOperationException();
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Deprecated
/*  74:    */   public final boolean retainAll(Collection<?> elementsToKeep)
/*  75:    */   {
/*  76:144 */     throw new UnsupportedOperationException();
/*  77:    */   }
/*  78:    */   
/*  79:    */   @Deprecated
/*  80:    */   public final void clear()
/*  81:    */   {
/*  82:156 */     throw new UnsupportedOperationException();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public ImmutableList<E> asList()
/*  86:    */   {
/*  87:171 */     ImmutableList<E> list = this.asList;
/*  88:172 */     return list == null ? (this.asList = createAsList()) : list;
/*  89:    */   }
/*  90:    */   
/*  91:    */   ImmutableList<E> createAsList()
/*  92:    */   {
/*  93:176 */     switch (size())
/*  94:    */     {
/*  95:    */     case 0: 
/*  96:178 */       return ImmutableList.of();
/*  97:    */     case 1: 
/*  98:180 */       return ImmutableList.of(iterator().next());
/*  99:    */     }
/* 100:182 */     return new RegularImmutableAsList(this, toArray());
/* 101:    */   }
/* 102:    */   
/* 103:    */   abstract boolean isPartialView();
/* 104:    */   
/* 105:    */   int copyIntoArray(Object[] dst, int offset)
/* 106:    */   {
/* 107:199 */     for (E e : this) {
/* 108:200 */       dst[(offset++)] = e;
/* 109:    */     }
/* 110:202 */     return offset;
/* 111:    */   }
/* 112:    */   
/* 113:    */   Object writeReplace()
/* 114:    */   {
/* 115:207 */     return new ImmutableList.SerializedForm(toArray());
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static abstract class Builder<E>
/* 119:    */   {
/* 120:    */     static final int DEFAULT_INITIAL_CAPACITY = 4;
/* 121:    */     
/* 122:    */     static int expandedCapacity(int oldCapacity, int minCapacity)
/* 123:    */     {
/* 124:219 */       if (minCapacity < 0) {
/* 125:220 */         throw new AssertionError("cannot store more than MAX_VALUE elements");
/* 126:    */       }
/* 127:223 */       int newCapacity = oldCapacity + (oldCapacity >> 1) + 1;
/* 128:224 */       if (newCapacity < minCapacity) {
/* 129:225 */         newCapacity = Integer.highestOneBit(minCapacity - 1) << 1;
/* 130:    */       }
/* 131:227 */       if (newCapacity < 0) {
/* 132:228 */         newCapacity = 2147483647;
/* 133:    */       }
/* 134:231 */       return newCapacity;
/* 135:    */     }
/* 136:    */     
/* 137:    */     public abstract Builder<E> add(E paramE);
/* 138:    */     
/* 139:    */     public Builder<E> add(E... elements)
/* 140:    */     {
/* 141:262 */       for (E element : elements) {
/* 142:263 */         add(element);
/* 143:    */       }
/* 144:265 */       return this;
/* 145:    */     }
/* 146:    */     
/* 147:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 148:    */     {
/* 149:281 */       for (E element : elements) {
/* 150:282 */         add(element);
/* 151:    */       }
/* 152:284 */       return this;
/* 153:    */     }
/* 154:    */     
/* 155:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 156:    */     {
/* 157:300 */       while (elements.hasNext()) {
/* 158:301 */         add(elements.next());
/* 159:    */       }
/* 160:303 */       return this;
/* 161:    */     }
/* 162:    */     
/* 163:    */     public abstract ImmutableCollection<E> build();
/* 164:    */   }
/* 165:    */   
/* 166:    */   static abstract class ArrayBasedBuilder<E>
/* 167:    */     extends ImmutableCollection.Builder<E>
/* 168:    */   {
/* 169:    */     Object[] contents;
/* 170:    */     int size;
/* 171:    */     
/* 172:    */     ArrayBasedBuilder(int initialCapacity)
/* 173:    */     {
/* 174:321 */       CollectPreconditions.checkNonnegative(initialCapacity, "initialCapacity");
/* 175:322 */       this.contents = new Object[initialCapacity];
/* 176:323 */       this.size = 0;
/* 177:    */     }
/* 178:    */     
/* 179:    */     private void ensureCapacity(int minCapacity)
/* 180:    */     {
/* 181:331 */       if (this.contents.length < minCapacity) {
/* 182:332 */         this.contents = ObjectArrays.arraysCopyOf(this.contents, expandedCapacity(this.contents.length, minCapacity));
/* 183:    */       }
/* 184:    */     }
/* 185:    */     
/* 186:    */     public ArrayBasedBuilder<E> add(E element)
/* 187:    */     {
/* 188:339 */       Preconditions.checkNotNull(element);
/* 189:340 */       ensureCapacity(this.size + 1);
/* 190:341 */       this.contents[(this.size++)] = element;
/* 191:342 */       return this;
/* 192:    */     }
/* 193:    */     
/* 194:    */     public ImmutableCollection.Builder<E> add(E... elements)
/* 195:    */     {
/* 196:347 */       ObjectArrays.checkElementsNotNull(elements);
/* 197:348 */       ensureCapacity(this.size + elements.length);
/* 198:349 */       System.arraycopy(elements, 0, this.contents, this.size, elements.length);
/* 199:350 */       this.size += elements.length;
/* 200:351 */       return this;
/* 201:    */     }
/* 202:    */     
/* 203:    */     public ImmutableCollection.Builder<E> addAll(Iterable<? extends E> elements)
/* 204:    */     {
/* 205:356 */       if ((elements instanceof Collection))
/* 206:    */       {
/* 207:357 */         Collection<?> collection = (Collection)elements;
/* 208:358 */         ensureCapacity(this.size + collection.size());
/* 209:    */       }
/* 210:360 */       super.addAll(elements);
/* 211:361 */       return this;
/* 212:    */     }
/* 213:    */   }
/* 214:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableCollection
 * JD-Core Version:    0.7.0.1
 */
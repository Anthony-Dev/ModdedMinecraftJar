/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Function;
/*  5:   */ import com.google.common.base.Predicate;
/*  6:   */ import java.lang.reflect.Array;
/*  7:   */ import java.util.Collections;
/*  8:   */ import java.util.Map;
/*  9:   */ import java.util.Map.Entry;
/* 10:   */ import java.util.NavigableMap;
/* 11:   */ import java.util.NavigableSet;
/* 12:   */ import java.util.Set;
/* 13:   */ import java.util.SortedMap;
/* 14:   */ import java.util.SortedSet;
/* 15:   */ 
/* 16:   */ @GwtCompatible(emulated=true)
/* 17:   */ final class Platform
/* 18:   */ {
/* 19:   */   static <T> T[] newArray(T[] reference, int length)
/* 20:   */   {
/* 21:48 */     Class<?> type = reference.getClass().getComponentType();
/* 22:   */     
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:53 */     T[] result = (Object[])Array.newInstance(type, length);
/* 27:54 */     return result;
/* 28:   */   }
/* 29:   */   
/* 30:   */   static <E> Set<E> newSetFromMap(Map<E, Boolean> map)
/* 31:   */   {
/* 32:58 */     return Collections.newSetFromMap(map);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static MapMaker tryWeakKeys(MapMaker mapMaker)
/* 36:   */   {
/* 37:68 */     return mapMaker.weakKeys();
/* 38:   */   }
/* 39:   */   
/* 40:   */   static <K, V1, V2> SortedMap<K, V2> mapsTransformEntriesSortedMap(SortedMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 41:   */   {
/* 42:74 */     return (fromMap instanceof NavigableMap) ? Maps.transformEntries((NavigableMap)fromMap, transformer) : Maps.transformEntriesIgnoreNavigable(fromMap, transformer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   static <K, V> SortedMap<K, V> mapsAsMapSortedSet(SortedSet<K> set, Function<? super K, V> function)
/* 46:   */   {
/* 47:81 */     return (set instanceof NavigableSet) ? Maps.asMap((NavigableSet)set, function) : Maps.asMapSortedIgnoreNavigable(set, function);
/* 48:   */   }
/* 49:   */   
/* 50:   */   static <E> SortedSet<E> setsFilterSortedSet(SortedSet<E> set, Predicate<? super E> predicate)
/* 51:   */   {
/* 52:88 */     return (set instanceof NavigableSet) ? Sets.filter((NavigableSet)set, predicate) : Sets.filterSortedIgnoreNavigable(set, predicate);
/* 53:   */   }
/* 54:   */   
/* 55:   */   static <K, V> SortedMap<K, V> mapsFilterSortedMap(SortedMap<K, V> map, Predicate<? super Map.Entry<K, V>> predicate)
/* 56:   */   {
/* 57:95 */     return (map instanceof NavigableMap) ? Maps.filterEntries((NavigableMap)map, predicate) : Maps.filterSortedIgnoreNavigable(map, predicate);
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Platform
 * JD-Core Version:    0.7.0.1
 */
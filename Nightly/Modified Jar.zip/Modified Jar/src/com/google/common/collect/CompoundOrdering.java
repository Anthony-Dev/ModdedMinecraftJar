/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.Comparator;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true)
/*  8:   */ final class CompoundOrdering<T>
/*  9:   */   extends Ordering<T>
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:   */   final ImmutableList<Comparator<? super T>> comparators;
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   CompoundOrdering(Comparator<? super T> primary, Comparator<? super T> secondary)
/* 16:   */   {
/* 17:31 */     this.comparators = ImmutableList.of(primary, secondary);
/* 18:   */   }
/* 19:   */   
/* 20:   */   CompoundOrdering(Iterable<? extends Comparator<? super T>> comparators)
/* 21:   */   {
/* 22:36 */     this.comparators = ImmutableList.copyOf(comparators);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int compare(T left, T right)
/* 26:   */   {
/* 27:41 */     int size = this.comparators.size();
/* 28:42 */     for (int i = 0; i < size; i++)
/* 29:   */     {
/* 30:43 */       int result = ((Comparator)this.comparators.get(i)).compare(left, right);
/* 31:44 */       if (result != 0) {
/* 32:45 */         return result;
/* 33:   */       }
/* 34:   */     }
/* 35:48 */     return 0;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean equals(Object object)
/* 39:   */   {
/* 40:52 */     if (object == this) {
/* 41:53 */       return true;
/* 42:   */     }
/* 43:55 */     if ((object instanceof CompoundOrdering))
/* 44:   */     {
/* 45:56 */       CompoundOrdering<?> that = (CompoundOrdering)object;
/* 46:57 */       return this.comparators.equals(that.comparators);
/* 47:   */     }
/* 48:59 */     return false;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public int hashCode()
/* 52:   */   {
/* 53:63 */     return this.comparators.hashCode();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public String toString()
/* 57:   */   {
/* 58:67 */     return "Ordering.compound(" + this.comparators + ")";
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.CompoundOrdering
 * JD-Core Version:    0.7.0.1
 */
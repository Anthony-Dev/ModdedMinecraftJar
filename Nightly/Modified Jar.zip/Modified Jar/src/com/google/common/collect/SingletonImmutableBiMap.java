/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true, emulated=true)
/*  8:   */ final class SingletonImmutableBiMap<K, V>
/*  9:   */   extends ImmutableBiMap<K, V>
/* 10:   */ {
/* 11:   */   final transient K singleKey;
/* 12:   */   final transient V singleValue;
/* 13:   */   transient ImmutableBiMap<V, K> inverse;
/* 14:   */   
/* 15:   */   SingletonImmutableBiMap(K singleKey, V singleValue)
/* 16:   */   {
/* 17:39 */     CollectPreconditions.checkEntryNotNull(singleKey, singleValue);
/* 18:40 */     this.singleKey = singleKey;
/* 19:41 */     this.singleValue = singleValue;
/* 20:   */   }
/* 21:   */   
/* 22:   */   private SingletonImmutableBiMap(K singleKey, V singleValue, ImmutableBiMap<V, K> inverse)
/* 23:   */   {
/* 24:46 */     this.singleKey = singleKey;
/* 25:47 */     this.singleValue = singleValue;
/* 26:48 */     this.inverse = inverse;
/* 27:   */   }
/* 28:   */   
/* 29:   */   SingletonImmutableBiMap(Map.Entry<? extends K, ? extends V> entry)
/* 30:   */   {
/* 31:52 */     this(entry.getKey(), entry.getValue());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public V get(@Nullable Object key)
/* 35:   */   {
/* 36:56 */     return this.singleKey.equals(key) ? this.singleValue : null;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public int size()
/* 40:   */   {
/* 41:61 */     return 1;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean containsKey(@Nullable Object key)
/* 45:   */   {
/* 46:65 */     return this.singleKey.equals(key);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean containsValue(@Nullable Object value)
/* 50:   */   {
/* 51:69 */     return this.singleValue.equals(value);
/* 52:   */   }
/* 53:   */   
/* 54:   */   boolean isPartialView()
/* 55:   */   {
/* 56:73 */     return false;
/* 57:   */   }
/* 58:   */   
/* 59:   */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 60:   */   {
/* 61:78 */     return ImmutableSet.of(Maps.immutableEntry(this.singleKey, this.singleValue));
/* 62:   */   }
/* 63:   */   
/* 64:   */   ImmutableSet<K> createKeySet()
/* 65:   */   {
/* 66:83 */     return ImmutableSet.of(this.singleKey);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public ImmutableBiMap<V, K> inverse()
/* 70:   */   {
/* 71:91 */     ImmutableBiMap<V, K> result = this.inverse;
/* 72:92 */     if (result == null) {
/* 73:93 */       return this.inverse = new SingletonImmutableBiMap(this.singleValue, this.singleKey, this);
/* 74:   */     }
/* 75:96 */     return result;
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ 
/*  6:   */ @GwtCompatible(emulated=true)
/*  7:   */ class RegularImmutableAsList<E>
/*  8:   */   extends ImmutableAsList<E>
/*  9:   */ {
/* 10:   */   private final ImmutableCollection<E> delegate;
/* 11:   */   private final ImmutableList<? extends E> delegateList;
/* 12:   */   
/* 13:   */   RegularImmutableAsList(ImmutableCollection<E> delegate, ImmutableList<? extends E> delegateList)
/* 14:   */   {
/* 15:35 */     this.delegate = delegate;
/* 16:36 */     this.delegateList = delegateList;
/* 17:   */   }
/* 18:   */   
/* 19:   */   RegularImmutableAsList(ImmutableCollection<E> delegate, Object[] array)
/* 20:   */   {
/* 21:40 */     this(delegate, ImmutableList.asImmutableList(array));
/* 22:   */   }
/* 23:   */   
/* 24:   */   ImmutableCollection<E> delegateCollection()
/* 25:   */   {
/* 26:45 */     return this.delegate;
/* 27:   */   }
/* 28:   */   
/* 29:   */   ImmutableList<? extends E> delegateList()
/* 30:   */   {
/* 31:49 */     return this.delegateList;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public UnmodifiableListIterator<E> listIterator(int index)
/* 35:   */   {
/* 36:55 */     return this.delegateList.listIterator(index);
/* 37:   */   }
/* 38:   */   
/* 39:   */   @GwtIncompatible("not present in emulated superclass")
/* 40:   */   int copyIntoArray(Object[] dst, int offset)
/* 41:   */   {
/* 42:61 */     return this.delegateList.copyIntoArray(dst, offset);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public E get(int index)
/* 46:   */   {
/* 47:66 */     return this.delegateList.get(index);
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableAsList
 * JD-Core Version:    0.7.0.1
 */
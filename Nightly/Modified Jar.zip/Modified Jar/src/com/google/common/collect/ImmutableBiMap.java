/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ public abstract class ImmutableBiMap<K, V>
/*  10:    */   extends ImmutableMap<K, V>
/*  11:    */   implements BiMap<K, V>
/*  12:    */ {
/*  13:    */   public static <K, V> ImmutableBiMap<K, V> of()
/*  14:    */   {
/*  15: 50 */     return EmptyImmutableBiMap.INSTANCE;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1)
/*  19:    */   {
/*  20: 57 */     return new SingletonImmutableBiMap(k1, v1);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2)
/*  24:    */   {
/*  25: 66 */     return new RegularImmutableBiMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  29:    */   {
/*  30: 76 */     return new RegularImmutableBiMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  34:    */   {
/*  35: 86 */     return new RegularImmutableBiMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  39:    */   {
/*  40: 97 */     return new RegularImmutableBiMap(new ImmutableMapEntry.TerminalEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <K, V> Builder<K, V> builder()
/*  44:    */   {
/*  45:108 */     return new Builder();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static final class Builder<K, V>
/*  49:    */     extends ImmutableMap.Builder<K, V>
/*  50:    */   {
/*  51:    */     public Builder<K, V> put(K key, V value)
/*  52:    */     {
/*  53:144 */       super.put(key, value);
/*  54:145 */       return this;
/*  55:    */     }
/*  56:    */     
/*  57:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/*  58:    */     {
/*  59:156 */       super.putAll(map);
/*  60:157 */       return this;
/*  61:    */     }
/*  62:    */     
/*  63:    */     public ImmutableBiMap<K, V> build()
/*  64:    */     {
/*  65:166 */       switch (this.size)
/*  66:    */       {
/*  67:    */       case 0: 
/*  68:168 */         return ImmutableBiMap.of();
/*  69:    */       case 1: 
/*  70:170 */         return ImmutableBiMap.of(this.entries[0].getKey(), this.entries[0].getValue());
/*  71:    */       }
/*  72:172 */       return new RegularImmutableBiMap(this.size, this.entries);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <K, V> ImmutableBiMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/*  77:    */   {
/*  78:192 */     if ((map instanceof ImmutableBiMap))
/*  79:    */     {
/*  80:194 */       ImmutableBiMap<K, V> bimap = (ImmutableBiMap)map;
/*  81:197 */       if (!bimap.isPartialView()) {
/*  82:198 */         return bimap;
/*  83:    */       }
/*  84:    */     }
/*  85:201 */     Map.Entry<?, ?>[] entries = (Map.Entry[])map.entrySet().toArray(EMPTY_ENTRY_ARRAY);
/*  86:202 */     switch (entries.length)
/*  87:    */     {
/*  88:    */     case 0: 
/*  89:204 */       return of();
/*  90:    */     case 1: 
/*  91:207 */       Map.Entry<K, V> entry = entries[0];
/*  92:208 */       return of(entry.getKey(), entry.getValue());
/*  93:    */     }
/*  94:210 */     return new RegularImmutableBiMap(entries);
/*  95:    */   }
/*  96:    */   
/*  97:214 */   private static final Map.Entry<?, ?>[] EMPTY_ENTRY_ARRAY = new Map.Entry[0];
/*  98:    */   
/*  99:    */   public abstract ImmutableBiMap<V, K> inverse();
/* 100:    */   
/* 101:    */   public ImmutableSet<V> values()
/* 102:    */   {
/* 103:232 */     return inverse().keySet();
/* 104:    */   }
/* 105:    */   
/* 106:    */   @Deprecated
/* 107:    */   public V forcePut(K key, V value)
/* 108:    */   {
/* 109:244 */     throw new UnsupportedOperationException();
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static class SerializedForm
/* 113:    */     extends ImmutableMap.SerializedForm
/* 114:    */   {
/* 115:    */     private static final long serialVersionUID = 0L;
/* 116:    */     
/* 117:    */     SerializedForm(ImmutableBiMap<?, ?> bimap)
/* 118:    */     {
/* 119:258 */       super();
/* 120:    */     }
/* 121:    */     
/* 122:    */     Object readResolve()
/* 123:    */     {
/* 124:261 */       ImmutableBiMap.Builder<Object, Object> builder = new ImmutableBiMap.Builder();
/* 125:262 */       return createMap(builder);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   Object writeReplace()
/* 130:    */   {
/* 131:268 */     return new SerializedForm(this);
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */
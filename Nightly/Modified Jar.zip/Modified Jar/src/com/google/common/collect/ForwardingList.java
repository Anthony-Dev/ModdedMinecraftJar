/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.ListIterator;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ public abstract class ForwardingList<E>
/*  13:    */   extends ForwardingCollection<E>
/*  14:    */   implements List<E>
/*  15:    */ {
/*  16:    */   protected abstract List<E> delegate();
/*  17:    */   
/*  18:    */   public void add(int index, E element)
/*  19:    */   {
/*  20: 66 */     delegate().add(index, element);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public boolean addAll(int index, Collection<? extends E> elements)
/*  24:    */   {
/*  25: 71 */     return delegate().addAll(index, elements);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public E get(int index)
/*  29:    */   {
/*  30: 76 */     return delegate().get(index);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public int indexOf(Object element)
/*  34:    */   {
/*  35: 81 */     return delegate().indexOf(element);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int lastIndexOf(Object element)
/*  39:    */   {
/*  40: 86 */     return delegate().lastIndexOf(element);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public ListIterator<E> listIterator()
/*  44:    */   {
/*  45: 91 */     return delegate().listIterator();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public ListIterator<E> listIterator(int index)
/*  49:    */   {
/*  50: 96 */     return delegate().listIterator(index);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public E remove(int index)
/*  54:    */   {
/*  55:101 */     return delegate().remove(index);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public E set(int index, E element)
/*  59:    */   {
/*  60:106 */     return delegate().set(index, element);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List<E> subList(int fromIndex, int toIndex)
/*  64:    */   {
/*  65:111 */     return delegate().subList(fromIndex, toIndex);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean equals(@Nullable Object object)
/*  69:    */   {
/*  70:115 */     return (object == this) || (delegate().equals(object));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public int hashCode()
/*  74:    */   {
/*  75:119 */     return delegate().hashCode();
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected boolean standardAdd(E element)
/*  79:    */   {
/*  80:131 */     add(size(), element);
/*  81:132 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected boolean standardAddAll(int index, Iterable<? extends E> elements)
/*  85:    */   {
/*  86:145 */     return Lists.addAllImpl(this, index, elements);
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected int standardIndexOf(@Nullable Object element)
/*  90:    */   {
/*  91:156 */     return Lists.indexOfImpl(this, element);
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected int standardLastIndexOf(@Nullable Object element)
/*  95:    */   {
/*  96:168 */     return Lists.lastIndexOfImpl(this, element);
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected Iterator<E> standardIterator()
/* 100:    */   {
/* 101:179 */     return listIterator();
/* 102:    */   }
/* 103:    */   
/* 104:    */   protected ListIterator<E> standardListIterator()
/* 105:    */   {
/* 106:191 */     return listIterator(0);
/* 107:    */   }
/* 108:    */   
/* 109:    */   @Beta
/* 110:    */   protected ListIterator<E> standardListIterator(int start)
/* 111:    */   {
/* 112:204 */     return Lists.listIteratorImpl(this, start);
/* 113:    */   }
/* 114:    */   
/* 115:    */   @Beta
/* 116:    */   protected List<E> standardSubList(int fromIndex, int toIndex)
/* 117:    */   {
/* 118:215 */     return Lists.subListImpl(this, fromIndex, toIndex);
/* 119:    */   }
/* 120:    */   
/* 121:    */   @Beta
/* 122:    */   protected boolean standardEquals(@Nullable Object object)
/* 123:    */   {
/* 124:226 */     return Lists.equalsImpl(this, object);
/* 125:    */   }
/* 126:    */   
/* 127:    */   @Beta
/* 128:    */   protected int standardHashCode()
/* 129:    */   {
/* 130:237 */     return Lists.hashCodeImpl(this);
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingList
 * JD-Core Version:    0.7.0.1
 */
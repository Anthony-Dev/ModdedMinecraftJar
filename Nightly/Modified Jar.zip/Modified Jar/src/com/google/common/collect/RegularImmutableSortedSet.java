/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.NoSuchElementException;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ final class RegularImmutableSortedSet<E>
/*  16:    */   extends ImmutableSortedSet<E>
/*  17:    */ {
/*  18:    */   private final transient ImmutableList<E> elements;
/*  19:    */   
/*  20:    */   RegularImmutableSortedSet(ImmutableList<E> elements, Comparator<? super E> comparator)
/*  21:    */   {
/*  22: 54 */     super(comparator);
/*  23: 55 */     this.elements = elements;
/*  24: 56 */     Preconditions.checkArgument(!elements.isEmpty());
/*  25:    */   }
/*  26:    */   
/*  27:    */   public UnmodifiableIterator<E> iterator()
/*  28:    */   {
/*  29: 60 */     return this.elements.iterator();
/*  30:    */   }
/*  31:    */   
/*  32:    */   @GwtIncompatible("NavigableSet")
/*  33:    */   public UnmodifiableIterator<E> descendingIterator()
/*  34:    */   {
/*  35: 65 */     return this.elements.reverse().iterator();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean isEmpty()
/*  39:    */   {
/*  40: 69 */     return false;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public int size()
/*  44:    */   {
/*  45: 74 */     return this.elements.size();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean contains(Object o)
/*  49:    */   {
/*  50:    */     try
/*  51:    */     {
/*  52: 79 */       return (o != null) && (unsafeBinarySearch(o) >= 0);
/*  53:    */     }
/*  54:    */     catch (ClassCastException e) {}
/*  55: 81 */     return false;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean containsAll(Collection<?> targets)
/*  59:    */   {
/*  60: 90 */     if ((targets instanceof Multiset)) {
/*  61: 91 */       targets = ((Multiset)targets).elementSet();
/*  62:    */     }
/*  63: 93 */     if ((!SortedIterables.hasSameComparator(comparator(), targets)) || (targets.size() <= 1)) {
/*  64: 95 */       return super.containsAll(targets);
/*  65:    */     }
/*  66:102 */     PeekingIterator<E> thisIterator = Iterators.peekingIterator(iterator());
/*  67:103 */     Iterator<?> thatIterator = targets.iterator();
/*  68:104 */     Object target = thatIterator.next();
/*  69:    */     try
/*  70:    */     {
/*  71:108 */       while (thisIterator.hasNext())
/*  72:    */       {
/*  73:110 */         int cmp = unsafeCompare(thisIterator.peek(), target);
/*  74:112 */         if (cmp < 0)
/*  75:    */         {
/*  76:113 */           thisIterator.next();
/*  77:    */         }
/*  78:114 */         else if (cmp == 0)
/*  79:    */         {
/*  80:116 */           if (!thatIterator.hasNext()) {
/*  81:118 */             return true;
/*  82:    */           }
/*  83:121 */           target = thatIterator.next();
/*  84:    */         }
/*  85:123 */         else if (cmp > 0)
/*  86:    */         {
/*  87:124 */           return false;
/*  88:    */         }
/*  89:    */       }
/*  90:    */     }
/*  91:    */     catch (NullPointerException e)
/*  92:    */     {
/*  93:128 */       return false;
/*  94:    */     }
/*  95:    */     catch (ClassCastException e)
/*  96:    */     {
/*  97:130 */       return false;
/*  98:    */     }
/*  99:133 */     return false;
/* 100:    */   }
/* 101:    */   
/* 102:    */   private int unsafeBinarySearch(Object key)
/* 103:    */     throws ClassCastException
/* 104:    */   {
/* 105:137 */     return Collections.binarySearch(this.elements, key, unsafeComparator());
/* 106:    */   }
/* 107:    */   
/* 108:    */   boolean isPartialView()
/* 109:    */   {
/* 110:141 */     return this.elements.isPartialView();
/* 111:    */   }
/* 112:    */   
/* 113:    */   int copyIntoArray(Object[] dst, int offset)
/* 114:    */   {
/* 115:146 */     return this.elements.copyIntoArray(dst, offset);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean equals(@Nullable Object object)
/* 119:    */   {
/* 120:150 */     if (object == this) {
/* 121:151 */       return true;
/* 122:    */     }
/* 123:153 */     if (!(object instanceof Set)) {
/* 124:154 */       return false;
/* 125:    */     }
/* 126:157 */     Set<?> that = (Set)object;
/* 127:158 */     if (size() != that.size()) {
/* 128:159 */       return false;
/* 129:    */     }
/* 130:162 */     if (SortedIterables.hasSameComparator(this.comparator, that))
/* 131:    */     {
/* 132:163 */       Iterator<?> otherIterator = that.iterator();
/* 133:    */       try
/* 134:    */       {
/* 135:165 */         Iterator<E> iterator = iterator();
/* 136:166 */         while (iterator.hasNext())
/* 137:    */         {
/* 138:167 */           Object element = iterator.next();
/* 139:168 */           Object otherElement = otherIterator.next();
/* 140:169 */           if ((otherElement == null) || (unsafeCompare(element, otherElement) != 0)) {
/* 141:171 */             return false;
/* 142:    */           }
/* 143:    */         }
/* 144:174 */         return true;
/* 145:    */       }
/* 146:    */       catch (ClassCastException e)
/* 147:    */       {
/* 148:176 */         return false;
/* 149:    */       }
/* 150:    */       catch (NoSuchElementException e)
/* 151:    */       {
/* 152:178 */         return false;
/* 153:    */       }
/* 154:    */     }
/* 155:181 */     return containsAll(that);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public E first()
/* 159:    */   {
/* 160:186 */     return this.elements.get(0);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public E last()
/* 164:    */   {
/* 165:191 */     return this.elements.get(size() - 1);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public E lower(E element)
/* 169:    */   {
/* 170:196 */     int index = headIndex(element, false) - 1;
/* 171:197 */     return index == -1 ? null : this.elements.get(index);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public E floor(E element)
/* 175:    */   {
/* 176:202 */     int index = headIndex(element, true) - 1;
/* 177:203 */     return index == -1 ? null : this.elements.get(index);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public E ceiling(E element)
/* 181:    */   {
/* 182:208 */     int index = tailIndex(element, true);
/* 183:209 */     return index == size() ? null : this.elements.get(index);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public E higher(E element)
/* 187:    */   {
/* 188:214 */     int index = tailIndex(element, false);
/* 189:215 */     return index == size() ? null : this.elements.get(index);
/* 190:    */   }
/* 191:    */   
/* 192:    */   ImmutableSortedSet<E> headSetImpl(E toElement, boolean inclusive)
/* 193:    */   {
/* 194:220 */     return getSubSet(0, headIndex(toElement, inclusive));
/* 195:    */   }
/* 196:    */   
/* 197:    */   int headIndex(E toElement, boolean inclusive)
/* 198:    */   {
/* 199:224 */     return SortedLists.binarySearch(this.elements, Preconditions.checkNotNull(toElement), comparator(), inclusive ? SortedLists.KeyPresentBehavior.FIRST_AFTER : SortedLists.KeyPresentBehavior.FIRST_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 200:    */   }
/* 201:    */   
/* 202:    */   ImmutableSortedSet<E> subSetImpl(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 203:    */   {
/* 204:232 */     return tailSetImpl(fromElement, fromInclusive).headSetImpl(toElement, toInclusive);
/* 205:    */   }
/* 206:    */   
/* 207:    */   ImmutableSortedSet<E> tailSetImpl(E fromElement, boolean inclusive)
/* 208:    */   {
/* 209:238 */     return getSubSet(tailIndex(fromElement, inclusive), size());
/* 210:    */   }
/* 211:    */   
/* 212:    */   int tailIndex(E fromElement, boolean inclusive)
/* 213:    */   {
/* 214:242 */     return SortedLists.binarySearch(this.elements, Preconditions.checkNotNull(fromElement), comparator(), inclusive ? SortedLists.KeyPresentBehavior.FIRST_PRESENT : SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 215:    */   }
/* 216:    */   
/* 217:    */   Comparator<Object> unsafeComparator()
/* 218:    */   {
/* 219:254 */     return this.comparator;
/* 220:    */   }
/* 221:    */   
/* 222:    */   ImmutableSortedSet<E> getSubSet(int newFromIndex, int newToIndex)
/* 223:    */   {
/* 224:258 */     if ((newFromIndex == 0) && (newToIndex == size())) {
/* 225:259 */       return this;
/* 226:    */     }
/* 227:260 */     if (newFromIndex < newToIndex) {
/* 228:261 */       return new RegularImmutableSortedSet(this.elements.subList(newFromIndex, newToIndex), this.comparator);
/* 229:    */     }
/* 230:264 */     return emptySet(this.comparator);
/* 231:    */   }
/* 232:    */   
/* 233:    */   int indexOf(@Nullable Object target)
/* 234:    */   {
/* 235:269 */     if (target == null) {
/* 236:270 */       return -1;
/* 237:    */     }
/* 238:    */     int position;
/* 239:    */     try
/* 240:    */     {
/* 241:274 */       position = SortedLists.binarySearch(this.elements, target, unsafeComparator(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.INVERTED_INSERTION_INDEX);
/* 242:    */     }
/* 243:    */     catch (ClassCastException e)
/* 244:    */     {
/* 245:277 */       return -1;
/* 246:    */     }
/* 247:279 */     return position >= 0 ? position : -1;
/* 248:    */   }
/* 249:    */   
/* 250:    */   ImmutableList<E> createAsList()
/* 251:    */   {
/* 252:283 */     return new ImmutableSortedAsList(this, this.elements);
/* 253:    */   }
/* 254:    */   
/* 255:    */   ImmutableSortedSet<E> createDescendingSet()
/* 256:    */   {
/* 257:288 */     return new RegularImmutableSortedSet(this.elements.reverse(), Ordering.from(this.comparator).reverse());
/* 258:    */   }
/* 259:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.EnumSet;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ final class ImmutableEnumSet<E extends Enum<E>>
/*  10:    */   extends ImmutableSet<E>
/*  11:    */ {
/*  12:    */   private final transient EnumSet<E> delegate;
/*  13:    */   private transient int hashCode;
/*  14:    */   
/*  15:    */   static <E extends Enum<E>> ImmutableSet<E> asImmutable(EnumSet<E> set)
/*  16:    */   {
/*  17: 35 */     switch (set.size())
/*  18:    */     {
/*  19:    */     case 0: 
/*  20: 37 */       return ImmutableSet.of();
/*  21:    */     case 1: 
/*  22: 39 */       return ImmutableSet.of(Iterables.getOnlyElement(set));
/*  23:    */     }
/*  24: 41 */     return new ImmutableEnumSet(set);
/*  25:    */   }
/*  26:    */   
/*  27:    */   private ImmutableEnumSet(EnumSet<E> delegate)
/*  28:    */   {
/*  29: 56 */     this.delegate = delegate;
/*  30:    */   }
/*  31:    */   
/*  32:    */   boolean isPartialView()
/*  33:    */   {
/*  34: 60 */     return false;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public UnmodifiableIterator<E> iterator()
/*  38:    */   {
/*  39: 64 */     return Iterators.unmodifiableIterator(this.delegate.iterator());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public int size()
/*  43:    */   {
/*  44: 69 */     return this.delegate.size();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean contains(Object object)
/*  48:    */   {
/*  49: 73 */     return this.delegate.contains(object);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean containsAll(Collection<?> collection)
/*  53:    */   {
/*  54: 77 */     return this.delegate.containsAll(collection);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isEmpty()
/*  58:    */   {
/*  59: 81 */     return this.delegate.isEmpty();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean equals(Object object)
/*  63:    */   {
/*  64: 85 */     return (object == this) || (this.delegate.equals(object));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int hashCode()
/*  68:    */   {
/*  69: 91 */     int result = this.hashCode;
/*  70: 92 */     return result == 0 ? (this.hashCode = this.delegate.hashCode()) : result;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public String toString()
/*  74:    */   {
/*  75: 96 */     return this.delegate.toString();
/*  76:    */   }
/*  77:    */   
/*  78:    */   Object writeReplace()
/*  79:    */   {
/*  80:101 */     return new EnumSerializedForm(this.delegate);
/*  81:    */   }
/*  82:    */   
/*  83:    */   private static class EnumSerializedForm<E extends Enum<E>>
/*  84:    */     implements Serializable
/*  85:    */   {
/*  86:    */     final EnumSet<E> delegate;
/*  87:    */     private static final long serialVersionUID = 0L;
/*  88:    */     
/*  89:    */     EnumSerializedForm(EnumSet<E> delegate)
/*  90:    */     {
/*  91:111 */       this.delegate = delegate;
/*  92:    */     }
/*  93:    */     
/*  94:    */     Object readResolve()
/*  95:    */     {
/*  96:115 */       return new ImmutableEnumSet(this.delegate.clone(), null);
/*  97:    */     }
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableEnumSet
 * JD-Core Version:    0.7.0.1
 */
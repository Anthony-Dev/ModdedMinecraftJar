/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.primitives.Primitives;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ public final class MutableClassToInstanceMap<B>
/*  8:   */   extends MapConstraints.ConstrainedMap<Class<? extends B>, B>
/*  9:   */   implements ClassToInstanceMap<B>
/* 10:   */ {
/* 11:   */   public static <B> MutableClassToInstanceMap<B> create()
/* 12:   */   {
/* 13:45 */     return new MutableClassToInstanceMap(new HashMap());
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static <B> MutableClassToInstanceMap<B> create(Map<Class<? extends B>, B> backingMap)
/* 17:   */   {
/* 18:56 */     return new MutableClassToInstanceMap(backingMap);
/* 19:   */   }
/* 20:   */   
/* 21:   */   private MutableClassToInstanceMap(Map<Class<? extends B>, B> delegate)
/* 22:   */   {
/* 23:60 */     super(delegate, VALUE_CAN_BE_CAST_TO_KEY);
/* 24:   */   }
/* 25:   */   
/* 26:63 */   private static final MapConstraint<Class<?>, Object> VALUE_CAN_BE_CAST_TO_KEY = new MapConstraint()
/* 27:   */   {
/* 28:   */     public void checkKeyValue(Class<?> key, Object value)
/* 29:   */     {
/* 30:67 */       MutableClassToInstanceMap.cast(key, value);
/* 31:   */     }
/* 32:   */   };
/* 33:   */   private static final long serialVersionUID = 0L;
/* 34:   */   
/* 35:   */   public <T extends B> T putInstance(Class<T> type, T value)
/* 36:   */   {
/* 37:73 */     return cast(type, put(type, value));
/* 38:   */   }
/* 39:   */   
/* 40:   */   public <T extends B> T getInstance(Class<T> type)
/* 41:   */   {
/* 42:78 */     return cast(type, get(type));
/* 43:   */   }
/* 44:   */   
/* 45:   */   private static <B, T extends B> T cast(Class<T> type, B value)
/* 46:   */   {
/* 47:82 */     return Primitives.wrap(type).cast(value);
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MutableClassToInstanceMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import com.google.common.base.Predicates;
/*   9:    */ import java.util.AbstractMap;
/*  10:    */ import java.util.AbstractSet;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Map;
/*  16:    */ import java.util.Map.Entry;
/*  17:    */ import java.util.NavigableMap;
/*  18:    */ import java.util.NoSuchElementException;
/*  19:    */ import java.util.Set;
/*  20:    */ import java.util.SortedMap;
/*  21:    */ import javax.annotation.Nullable;
/*  22:    */ 
/*  23:    */ @Beta
/*  24:    */ @GwtIncompatible("NavigableMap")
/*  25:    */ public final class TreeRangeMap<K extends Comparable, V>
/*  26:    */   implements RangeMap<K, V>
/*  27:    */ {
/*  28:    */   private final NavigableMap<Cut<K>, RangeMapEntry<K, V>> entriesByLowerBound;
/*  29:    */   
/*  30:    */   public static <K extends Comparable, V> TreeRangeMap<K, V> create()
/*  31:    */   {
/*  32: 61 */     return new TreeRangeMap();
/*  33:    */   }
/*  34:    */   
/*  35:    */   private TreeRangeMap()
/*  36:    */   {
/*  37: 65 */     this.entriesByLowerBound = Maps.newTreeMap();
/*  38:    */   }
/*  39:    */   
/*  40:    */   private static final class RangeMapEntry<K extends Comparable, V>
/*  41:    */     extends AbstractMapEntry<Range<K>, V>
/*  42:    */   {
/*  43:    */     private final Range<K> range;
/*  44:    */     private final V value;
/*  45:    */     
/*  46:    */     RangeMapEntry(Cut<K> lowerBound, Cut<K> upperBound, V value)
/*  47:    */     {
/*  48: 74 */       this(Range.create(lowerBound, upperBound), value);
/*  49:    */     }
/*  50:    */     
/*  51:    */     RangeMapEntry(Range<K> range, V value)
/*  52:    */     {
/*  53: 78 */       this.range = range;
/*  54: 79 */       this.value = value;
/*  55:    */     }
/*  56:    */     
/*  57:    */     public Range<K> getKey()
/*  58:    */     {
/*  59: 84 */       return this.range;
/*  60:    */     }
/*  61:    */     
/*  62:    */     public V getValue()
/*  63:    */     {
/*  64: 89 */       return this.value;
/*  65:    */     }
/*  66:    */     
/*  67:    */     public boolean contains(K value)
/*  68:    */     {
/*  69: 93 */       return this.range.contains(value);
/*  70:    */     }
/*  71:    */     
/*  72:    */     Cut<K> getLowerBound()
/*  73:    */     {
/*  74: 97 */       return this.range.lowerBound;
/*  75:    */     }
/*  76:    */     
/*  77:    */     Cut<K> getUpperBound()
/*  78:    */     {
/*  79:101 */       return this.range.upperBound;
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   @Nullable
/*  84:    */   public V get(K key)
/*  85:    */   {
/*  86:108 */     Map.Entry<Range<K>, V> entry = getEntry(key);
/*  87:109 */     return entry == null ? null : entry.getValue();
/*  88:    */   }
/*  89:    */   
/*  90:    */   @Nullable
/*  91:    */   public Map.Entry<Range<K>, V> getEntry(K key)
/*  92:    */   {
/*  93:115 */     Map.Entry<Cut<K>, RangeMapEntry<K, V>> mapEntry = this.entriesByLowerBound.floorEntry(Cut.belowValue(key));
/*  94:117 */     if ((mapEntry != null) && (((RangeMapEntry)mapEntry.getValue()).contains(key))) {
/*  95:118 */       return (Map.Entry)mapEntry.getValue();
/*  96:    */     }
/*  97:120 */     return null;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void put(Range<K> range, V value)
/* 101:    */   {
/* 102:126 */     if (!range.isEmpty())
/* 103:    */     {
/* 104:127 */       Preconditions.checkNotNull(value);
/* 105:128 */       remove(range);
/* 106:129 */       this.entriesByLowerBound.put(range.lowerBound, new RangeMapEntry(range, value));
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void putAll(RangeMap<K, V> rangeMap)
/* 111:    */   {
/* 112:135 */     for (Map.Entry<Range<K>, V> entry : rangeMap.asMapOfRanges().entrySet()) {
/* 113:136 */       put((Range)entry.getKey(), entry.getValue());
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void clear()
/* 118:    */   {
/* 119:142 */     this.entriesByLowerBound.clear();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Range<K> span()
/* 123:    */   {
/* 124:147 */     Map.Entry<Cut<K>, RangeMapEntry<K, V>> firstEntry = this.entriesByLowerBound.firstEntry();
/* 125:148 */     Map.Entry<Cut<K>, RangeMapEntry<K, V>> lastEntry = this.entriesByLowerBound.lastEntry();
/* 126:149 */     if (firstEntry == null) {
/* 127:150 */       throw new NoSuchElementException();
/* 128:    */     }
/* 129:152 */     return Range.create(((RangeMapEntry)firstEntry.getValue()).getKey().lowerBound, ((RangeMapEntry)lastEntry.getValue()).getKey().upperBound);
/* 130:    */   }
/* 131:    */   
/* 132:    */   private void putRangeMapEntry(Cut<K> lowerBound, Cut<K> upperBound, V value)
/* 133:    */   {
/* 134:158 */     this.entriesByLowerBound.put(lowerBound, new RangeMapEntry(lowerBound, upperBound, value));
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void remove(Range<K> rangeToRemove)
/* 138:    */   {
/* 139:163 */     if (rangeToRemove.isEmpty()) {
/* 140:164 */       return;
/* 141:    */     }
/* 142:171 */     Map.Entry<Cut<K>, RangeMapEntry<K, V>> mapEntryBelowToTruncate = this.entriesByLowerBound.lowerEntry(rangeToRemove.lowerBound);
/* 143:173 */     if (mapEntryBelowToTruncate != null)
/* 144:    */     {
/* 145:175 */       RangeMapEntry<K, V> rangeMapEntry = (RangeMapEntry)mapEntryBelowToTruncate.getValue();
/* 146:176 */       if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.lowerBound) > 0)
/* 147:    */       {
/* 148:178 */         if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.upperBound) > 0) {
/* 149:181 */           putRangeMapEntry(rangeToRemove.upperBound, rangeMapEntry.getUpperBound(), ((RangeMapEntry)mapEntryBelowToTruncate.getValue()).getValue());
/* 150:    */         }
/* 151:185 */         putRangeMapEntry(rangeMapEntry.getLowerBound(), rangeToRemove.lowerBound, ((RangeMapEntry)mapEntryBelowToTruncate.getValue()).getValue());
/* 152:    */       }
/* 153:    */     }
/* 154:190 */     Map.Entry<Cut<K>, RangeMapEntry<K, V>> mapEntryAboveToTruncate = this.entriesByLowerBound.lowerEntry(rangeToRemove.upperBound);
/* 155:192 */     if (mapEntryAboveToTruncate != null)
/* 156:    */     {
/* 157:194 */       RangeMapEntry<K, V> rangeMapEntry = (RangeMapEntry)mapEntryAboveToTruncate.getValue();
/* 158:195 */       if (rangeMapEntry.getUpperBound().compareTo(rangeToRemove.upperBound) > 0)
/* 159:    */       {
/* 160:198 */         putRangeMapEntry(rangeToRemove.upperBound, rangeMapEntry.getUpperBound(), ((RangeMapEntry)mapEntryAboveToTruncate.getValue()).getValue());
/* 161:    */         
/* 162:200 */         this.entriesByLowerBound.remove(rangeToRemove.lowerBound);
/* 163:    */       }
/* 164:    */     }
/* 165:203 */     this.entriesByLowerBound.subMap(rangeToRemove.lowerBound, rangeToRemove.upperBound).clear();
/* 166:    */   }
/* 167:    */   
/* 168:    */   public Map<Range<K>, V> asMapOfRanges()
/* 169:    */   {
/* 170:208 */     return new AsMapOfRanges(null);
/* 171:    */   }
/* 172:    */   
/* 173:    */   private final class AsMapOfRanges
/* 174:    */     extends AbstractMap<Range<K>, V>
/* 175:    */   {
/* 176:    */     private AsMapOfRanges() {}
/* 177:    */     
/* 178:    */     public boolean containsKey(@Nullable Object key)
/* 179:    */     {
/* 180:215 */       return get(key) != null;
/* 181:    */     }
/* 182:    */     
/* 183:    */     public V get(@Nullable Object key)
/* 184:    */     {
/* 185:220 */       if ((key instanceof Range))
/* 186:    */       {
/* 187:221 */         Range<?> range = (Range)key;
/* 188:222 */         TreeRangeMap.RangeMapEntry<K, V> rangeMapEntry = (TreeRangeMap.RangeMapEntry)TreeRangeMap.this.entriesByLowerBound.get(range.lowerBound);
/* 189:223 */         if ((rangeMapEntry != null) && (rangeMapEntry.getKey().equals(range))) {
/* 190:224 */           return rangeMapEntry.getValue();
/* 191:    */         }
/* 192:    */       }
/* 193:227 */       return null;
/* 194:    */     }
/* 195:    */     
/* 196:    */     public Set<Map.Entry<Range<K>, V>> entrySet()
/* 197:    */     {
/* 198:232 */       new AbstractSet()
/* 199:    */       {
/* 200:    */         public Iterator<Map.Entry<Range<K>, V>> iterator()
/* 201:    */         {
/* 202:237 */           return TreeRangeMap.this.entriesByLowerBound.values().iterator();
/* 203:    */         }
/* 204:    */         
/* 205:    */         public int size()
/* 206:    */         {
/* 207:242 */           return TreeRangeMap.this.entriesByLowerBound.size();
/* 208:    */         }
/* 209:    */       };
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public RangeMap<K, V> subRangeMap(Range<K> subRange)
/* 214:    */   {
/* 215:250 */     if (subRange.equals(Range.all())) {
/* 216:251 */       return this;
/* 217:    */     }
/* 218:253 */     return new SubRangeMap(subRange);
/* 219:    */   }
/* 220:    */   
/* 221:    */   private RangeMap<K, V> emptySubRangeMap()
/* 222:    */   {
/* 223:259 */     return EMPTY_SUB_RANGE_MAP;
/* 224:    */   }
/* 225:    */   
/* 226:262 */   private static final RangeMap EMPTY_SUB_RANGE_MAP = new RangeMap()
/* 227:    */   {
/* 228:    */     @Nullable
/* 229:    */     public Object get(Comparable key)
/* 230:    */     {
/* 231:267 */       return null;
/* 232:    */     }
/* 233:    */     
/* 234:    */     @Nullable
/* 235:    */     public Map.Entry<Range, Object> getEntry(Comparable key)
/* 236:    */     {
/* 237:273 */       return null;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public Range span()
/* 241:    */     {
/* 242:278 */       throw new NoSuchElementException();
/* 243:    */     }
/* 244:    */     
/* 245:    */     public void put(Range range, Object value)
/* 246:    */     {
/* 247:283 */       Preconditions.checkNotNull(range);
/* 248:284 */       throw new IllegalArgumentException("Cannot insert range " + range + " into an empty subRangeMap");
/* 249:    */     }
/* 250:    */     
/* 251:    */     public void putAll(RangeMap rangeMap)
/* 252:    */     {
/* 253:290 */       if (!rangeMap.asMapOfRanges().isEmpty()) {
/* 254:291 */         throw new IllegalArgumentException("Cannot putAll(nonEmptyRangeMap) into an empty subRangeMap");
/* 255:    */       }
/* 256:    */     }
/* 257:    */     
/* 258:    */     public void clear() {}
/* 259:    */     
/* 260:    */     public void remove(Range range)
/* 261:    */     {
/* 262:301 */       Preconditions.checkNotNull(range);
/* 263:    */     }
/* 264:    */     
/* 265:    */     public Map<Range, Object> asMapOfRanges()
/* 266:    */     {
/* 267:306 */       return Collections.emptyMap();
/* 268:    */     }
/* 269:    */     
/* 270:    */     public RangeMap subRangeMap(Range range)
/* 271:    */     {
/* 272:311 */       Preconditions.checkNotNull(range);
/* 273:312 */       return this;
/* 274:    */     }
/* 275:    */   };
/* 276:    */   
/* 277:    */   private class SubRangeMap
/* 278:    */     implements RangeMap<K, V>
/* 279:    */   {
/* 280:    */     private final Range<K> subRange;
/* 281:    */     
/* 282:    */     SubRangeMap()
/* 283:    */     {
/* 284:321 */       this.subRange = subRange;
/* 285:    */     }
/* 286:    */     
/* 287:    */     @Nullable
/* 288:    */     public V get(K key)
/* 289:    */     {
/* 290:327 */       return this.subRange.contains(key) ? TreeRangeMap.this.get(key) : null;
/* 291:    */     }
/* 292:    */     
/* 293:    */     @Nullable
/* 294:    */     public Map.Entry<Range<K>, V> getEntry(K key)
/* 295:    */     {
/* 296:335 */       if (this.subRange.contains(key))
/* 297:    */       {
/* 298:336 */         Map.Entry<Range<K>, V> entry = TreeRangeMap.this.getEntry(key);
/* 299:337 */         if (entry != null) {
/* 300:338 */           return Maps.immutableEntry(((Range)entry.getKey()).intersection(this.subRange), entry.getValue());
/* 301:    */         }
/* 302:    */       }
/* 303:341 */       return null;
/* 304:    */     }
/* 305:    */     
/* 306:    */     public Range<K> span()
/* 307:    */     {
/* 308:347 */       Map.Entry<Cut<K>, TreeRangeMap.RangeMapEntry<K, V>> lowerEntry = TreeRangeMap.this.entriesByLowerBound.floorEntry(this.subRange.lowerBound);
/* 309:    */       Cut<K> lowerBound;
/* 310:    */       Cut<K> lowerBound;
/* 311:349 */       if ((lowerEntry != null) && (((TreeRangeMap.RangeMapEntry)lowerEntry.getValue()).getUpperBound().compareTo(this.subRange.lowerBound) > 0))
/* 312:    */       {
/* 313:351 */         lowerBound = this.subRange.lowerBound;
/* 314:    */       }
/* 315:    */       else
/* 316:    */       {
/* 317:353 */         lowerBound = (Cut)TreeRangeMap.this.entriesByLowerBound.ceilingKey(this.subRange.lowerBound);
/* 318:354 */         if ((lowerBound == null) || (lowerBound.compareTo(this.subRange.upperBound) >= 0)) {
/* 319:355 */           throw new NoSuchElementException();
/* 320:    */         }
/* 321:    */       }
/* 322:360 */       Map.Entry<Cut<K>, TreeRangeMap.RangeMapEntry<K, V>> upperEntry = TreeRangeMap.this.entriesByLowerBound.lowerEntry(this.subRange.upperBound);
/* 323:362 */       if (upperEntry == null) {
/* 324:363 */         throw new NoSuchElementException();
/* 325:    */       }
/* 326:    */       Cut<K> upperBound;
/* 327:    */       Cut<K> upperBound;
/* 328:364 */       if (((TreeRangeMap.RangeMapEntry)upperEntry.getValue()).getUpperBound().compareTo(this.subRange.upperBound) >= 0) {
/* 329:365 */         upperBound = this.subRange.upperBound;
/* 330:    */       } else {
/* 331:367 */         upperBound = ((TreeRangeMap.RangeMapEntry)upperEntry.getValue()).getUpperBound();
/* 332:    */       }
/* 333:369 */       return Range.create(lowerBound, upperBound);
/* 334:    */     }
/* 335:    */     
/* 336:    */     public void put(Range<K> range, V value)
/* 337:    */     {
/* 338:374 */       Preconditions.checkArgument(this.subRange.encloses(range), "Cannot put range %s into a subRangeMap(%s)", new Object[] { range, this.subRange });
/* 339:    */       
/* 340:376 */       TreeRangeMap.this.put(range, value);
/* 341:    */     }
/* 342:    */     
/* 343:    */     public void putAll(RangeMap<K, V> rangeMap)
/* 344:    */     {
/* 345:381 */       if (rangeMap.asMapOfRanges().isEmpty()) {
/* 346:382 */         return;
/* 347:    */       }
/* 348:384 */       Range<K> span = rangeMap.span();
/* 349:385 */       Preconditions.checkArgument(this.subRange.encloses(span), "Cannot putAll rangeMap with span %s into a subRangeMap(%s)", new Object[] { span, this.subRange });
/* 350:    */       
/* 351:387 */       TreeRangeMap.this.putAll(rangeMap);
/* 352:    */     }
/* 353:    */     
/* 354:    */     public void clear()
/* 355:    */     {
/* 356:392 */       TreeRangeMap.this.remove(this.subRange);
/* 357:    */     }
/* 358:    */     
/* 359:    */     public void remove(Range<K> range)
/* 360:    */     {
/* 361:397 */       if (range.isConnected(this.subRange)) {
/* 362:398 */         TreeRangeMap.this.remove(range.intersection(this.subRange));
/* 363:    */       }
/* 364:    */     }
/* 365:    */     
/* 366:    */     public RangeMap<K, V> subRangeMap(Range<K> range)
/* 367:    */     {
/* 368:404 */       if (!range.isConnected(this.subRange)) {
/* 369:405 */         return TreeRangeMap.this.emptySubRangeMap();
/* 370:    */       }
/* 371:407 */       return TreeRangeMap.this.subRangeMap(range.intersection(this.subRange));
/* 372:    */     }
/* 373:    */     
/* 374:    */     public Map<Range<K>, V> asMapOfRanges()
/* 375:    */     {
/* 376:413 */       return new SubRangeMapAsMap();
/* 377:    */     }
/* 378:    */     
/* 379:    */     public boolean equals(@Nullable Object o)
/* 380:    */     {
/* 381:418 */       if ((o instanceof RangeMap))
/* 382:    */       {
/* 383:419 */         RangeMap<?, ?> rangeMap = (RangeMap)o;
/* 384:420 */         return asMapOfRanges().equals(rangeMap.asMapOfRanges());
/* 385:    */       }
/* 386:422 */       return false;
/* 387:    */     }
/* 388:    */     
/* 389:    */     public int hashCode()
/* 390:    */     {
/* 391:427 */       return asMapOfRanges().hashCode();
/* 392:    */     }
/* 393:    */     
/* 394:    */     public String toString()
/* 395:    */     {
/* 396:432 */       return asMapOfRanges().toString();
/* 397:    */     }
/* 398:    */     
/* 399:    */     class SubRangeMapAsMap
/* 400:    */       extends AbstractMap<Range<K>, V>
/* 401:    */     {
/* 402:    */       SubRangeMapAsMap() {}
/* 403:    */       
/* 404:    */       public boolean containsKey(Object key)
/* 405:    */       {
/* 406:439 */         return get(key) != null;
/* 407:    */       }
/* 408:    */       
/* 409:    */       public V get(Object key)
/* 410:    */       {
/* 411:    */         try
/* 412:    */         {
/* 413:445 */           if ((key instanceof Range))
/* 414:    */           {
/* 415:447 */             Range<K> r = (Range)key;
/* 416:448 */             if ((!TreeRangeMap.SubRangeMap.this.subRange.encloses(r)) || (r.isEmpty())) {
/* 417:449 */               return null;
/* 418:    */             }
/* 419:451 */             TreeRangeMap.RangeMapEntry<K, V> candidate = null;
/* 420:452 */             if (r.lowerBound.compareTo(TreeRangeMap.SubRangeMap.this.subRange.lowerBound) == 0)
/* 421:    */             {
/* 422:454 */               Map.Entry<Cut<K>, TreeRangeMap.RangeMapEntry<K, V>> entry = TreeRangeMap.this.entriesByLowerBound.floorEntry(r.lowerBound);
/* 423:456 */               if (entry != null) {
/* 424:457 */                 candidate = (TreeRangeMap.RangeMapEntry)entry.getValue();
/* 425:    */               }
/* 426:    */             }
/* 427:    */             else
/* 428:    */             {
/* 429:460 */               candidate = (TreeRangeMap.RangeMapEntry)TreeRangeMap.this.entriesByLowerBound.get(r.lowerBound);
/* 430:    */             }
/* 431:463 */             if ((candidate != null) && (candidate.getKey().isConnected(TreeRangeMap.SubRangeMap.this.subRange)) && (candidate.getKey().intersection(TreeRangeMap.SubRangeMap.this.subRange).equals(r))) {
/* 432:465 */               return candidate.getValue();
/* 433:    */             }
/* 434:    */           }
/* 435:    */         }
/* 436:    */         catch (ClassCastException e)
/* 437:    */         {
/* 438:469 */           return null;
/* 439:    */         }
/* 440:471 */         return null;
/* 441:    */       }
/* 442:    */       
/* 443:    */       public V remove(Object key)
/* 444:    */       {
/* 445:476 */         V value = get(key);
/* 446:477 */         if (value != null)
/* 447:    */         {
/* 448:479 */           Range<K> range = (Range)key;
/* 449:480 */           TreeRangeMap.this.remove(range);
/* 450:481 */           return value;
/* 451:    */         }
/* 452:483 */         return null;
/* 453:    */       }
/* 454:    */       
/* 455:    */       public void clear()
/* 456:    */       {
/* 457:488 */         TreeRangeMap.SubRangeMap.this.clear();
/* 458:    */       }
/* 459:    */       
/* 460:    */       private boolean removeEntryIf(Predicate<? super Map.Entry<Range<K>, V>> predicate)
/* 461:    */       {
/* 462:492 */         List<Range<K>> toRemove = Lists.newArrayList();
/* 463:493 */         for (Map.Entry<Range<K>, V> entry : entrySet()) {
/* 464:494 */           if (predicate.apply(entry)) {
/* 465:495 */             toRemove.add(entry.getKey());
/* 466:    */           }
/* 467:    */         }
/* 468:498 */         for (Range<K> range : toRemove) {
/* 469:499 */           TreeRangeMap.this.remove(range);
/* 470:    */         }
/* 471:501 */         return !toRemove.isEmpty();
/* 472:    */       }
/* 473:    */       
/* 474:    */       public Set<Range<K>> keySet()
/* 475:    */       {
/* 476:506 */         new Maps.KeySet(this)
/* 477:    */         {
/* 478:    */           public boolean remove(@Nullable Object o)
/* 479:    */           {
/* 480:509 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this.remove(o) != null;
/* 481:    */           }
/* 482:    */           
/* 483:    */           public boolean retainAll(Collection<?> c)
/* 484:    */           {
/* 485:514 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this.removeEntryIf(Predicates.compose(Predicates.not(Predicates.in(c)), Maps.keyFunction()));
/* 486:    */           }
/* 487:    */         };
/* 488:    */       }
/* 489:    */       
/* 490:    */       public Set<Map.Entry<Range<K>, V>> entrySet()
/* 491:    */       {
/* 492:521 */         new Maps.EntrySet()
/* 493:    */         {
/* 494:    */           Map<Range<K>, V> map()
/* 495:    */           {
/* 496:524 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this;
/* 497:    */           }
/* 498:    */           
/* 499:    */           public Iterator<Map.Entry<Range<K>, V>> iterator()
/* 500:    */           {
/* 501:529 */             if (TreeRangeMap.SubRangeMap.this.subRange.isEmpty()) {
/* 502:530 */               return Iterators.emptyIterator();
/* 503:    */             }
/* 504:532 */             Cut<K> cutToStart = (Cut)Objects.firstNonNull(TreeRangeMap.this.entriesByLowerBound.floorKey(TreeRangeMap.SubRangeMap.this.subRange.lowerBound), TreeRangeMap.SubRangeMap.this.subRange.lowerBound);
/* 505:    */             
/* 506:    */ 
/* 507:535 */             final Iterator<TreeRangeMap.RangeMapEntry<K, V>> backingItr = TreeRangeMap.this.entriesByLowerBound.tailMap(cutToStart, true).values().iterator();
/* 508:    */             
/* 509:537 */             new AbstractIterator()
/* 510:    */             {
/* 511:    */               protected Map.Entry<Range<K>, V> computeNext()
/* 512:    */               {
/* 513:541 */                 while (backingItr.hasNext())
/* 514:    */                 {
/* 515:542 */                   TreeRangeMap.RangeMapEntry<K, V> entry = (TreeRangeMap.RangeMapEntry)backingItr.next();
/* 516:543 */                   if (entry.getLowerBound().compareTo(TreeRangeMap.SubRangeMap.this.subRange.upperBound) >= 0) {
/* 517:    */                     break;
/* 518:    */                   }
/* 519:545 */                   if (entry.getUpperBound().compareTo(TreeRangeMap.SubRangeMap.this.subRange.lowerBound) > 0) {
/* 520:547 */                     return Maps.immutableEntry(entry.getKey().intersection(TreeRangeMap.SubRangeMap.this.subRange), entry.getValue());
/* 521:    */                   }
/* 522:    */                 }
/* 523:551 */                 return (Map.Entry)endOfData();
/* 524:    */               }
/* 525:    */             };
/* 526:    */           }
/* 527:    */           
/* 528:    */           public boolean retainAll(Collection<?> c)
/* 529:    */           {
/* 530:558 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this.removeEntryIf(Predicates.not(Predicates.in(c)));
/* 531:    */           }
/* 532:    */           
/* 533:    */           public int size()
/* 534:    */           {
/* 535:563 */             return Iterators.size(iterator());
/* 536:    */           }
/* 537:    */           
/* 538:    */           public boolean isEmpty()
/* 539:    */           {
/* 540:568 */             return !iterator().hasNext();
/* 541:    */           }
/* 542:    */         };
/* 543:    */       }
/* 544:    */       
/* 545:    */       public Collection<V> values()
/* 546:    */       {
/* 547:575 */         new Maps.Values(this)
/* 548:    */         {
/* 549:    */           public boolean removeAll(Collection<?> c)
/* 550:    */           {
/* 551:578 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this.removeEntryIf(Predicates.compose(Predicates.in(c), Maps.valueFunction()));
/* 552:    */           }
/* 553:    */           
/* 554:    */           public boolean retainAll(Collection<?> c)
/* 555:    */           {
/* 556:583 */             return TreeRangeMap.SubRangeMap.SubRangeMapAsMap.this.removeEntryIf(Predicates.compose(Predicates.not(Predicates.in(c)), Maps.valueFunction()));
/* 557:    */           }
/* 558:    */         };
/* 559:    */       }
/* 560:    */     }
/* 561:    */   }
/* 562:    */   
/* 563:    */   public boolean equals(@Nullable Object o)
/* 564:    */   {
/* 565:592 */     if ((o instanceof RangeMap))
/* 566:    */     {
/* 567:593 */       RangeMap<?, ?> rangeMap = (RangeMap)o;
/* 568:594 */       return asMapOfRanges().equals(rangeMap.asMapOfRanges());
/* 569:    */     }
/* 570:596 */     return false;
/* 571:    */   }
/* 572:    */   
/* 573:    */   public int hashCode()
/* 574:    */   {
/* 575:601 */     return asMapOfRanges().hashCode();
/* 576:    */   }
/* 577:    */   
/* 578:    */   public String toString()
/* 579:    */   {
/* 580:606 */     return this.entriesByLowerBound.values().toString();
/* 581:    */   }
/* 582:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.TreeRangeMap
 * JD-Core Version:    0.7.0.1
 */
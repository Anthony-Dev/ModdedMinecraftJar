/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.NoSuchElementException;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ public final class ImmutableRangeSet<C extends Comparable>
/*  14:    */   extends AbstractRangeSet<C>
/*  15:    */   implements Serializable
/*  16:    */ {
/*  17: 46 */   private static final ImmutableRangeSet<Comparable<?>> EMPTY = new ImmutableRangeSet(ImmutableList.of());
/*  18: 49 */   private static final ImmutableRangeSet<Comparable<?>> ALL = new ImmutableRangeSet(ImmutableList.of(Range.all()));
/*  19:    */   private final transient ImmutableList<Range<C>> ranges;
/*  20:    */   private transient ImmutableRangeSet<C> complement;
/*  21:    */   
/*  22:    */   public static <C extends Comparable> ImmutableRangeSet<C> of()
/*  23:    */   {
/*  24: 57 */     return EMPTY;
/*  25:    */   }
/*  26:    */   
/*  27:    */   static <C extends Comparable> ImmutableRangeSet<C> all()
/*  28:    */   {
/*  29: 65 */     return ALL;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <C extends Comparable> ImmutableRangeSet<C> of(Range<C> range)
/*  33:    */   {
/*  34: 73 */     Preconditions.checkNotNull(range);
/*  35: 74 */     if (range.isEmpty()) {
/*  36: 75 */       return of();
/*  37:    */     }
/*  38: 76 */     if (range.equals(Range.all())) {
/*  39: 77 */       return all();
/*  40:    */     }
/*  41: 79 */     return new ImmutableRangeSet(ImmutableList.of(range));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <C extends Comparable> ImmutableRangeSet<C> copyOf(RangeSet<C> rangeSet)
/*  45:    */   {
/*  46: 87 */     Preconditions.checkNotNull(rangeSet);
/*  47: 88 */     if (rangeSet.isEmpty()) {
/*  48: 89 */       return of();
/*  49:    */     }
/*  50: 90 */     if (rangeSet.encloses(Range.all())) {
/*  51: 91 */       return all();
/*  52:    */     }
/*  53: 94 */     if ((rangeSet instanceof ImmutableRangeSet))
/*  54:    */     {
/*  55: 95 */       ImmutableRangeSet<C> immutableRangeSet = (ImmutableRangeSet)rangeSet;
/*  56: 96 */       if (!immutableRangeSet.isPartialView()) {
/*  57: 97 */         return immutableRangeSet;
/*  58:    */       }
/*  59:    */     }
/*  60:100 */     return new ImmutableRangeSet(ImmutableList.copyOf(rangeSet.asRanges()));
/*  61:    */   }
/*  62:    */   
/*  63:    */   ImmutableRangeSet(ImmutableList<Range<C>> ranges)
/*  64:    */   {
/*  65:104 */     this.ranges = ranges;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private ImmutableRangeSet(ImmutableList<Range<C>> ranges, ImmutableRangeSet<C> complement)
/*  69:    */   {
/*  70:108 */     this.ranges = ranges;
/*  71:109 */     this.complement = complement;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean encloses(Range<C> otherRange)
/*  75:    */   {
/*  76:116 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), otherRange.lowerBound, Ordering.natural(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/*  77:    */     
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:122 */     return (index != -1) && (((Range)this.ranges.get(index)).encloses(otherRange));
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Range<C> rangeContaining(C value)
/*  86:    */   {
/*  87:127 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(value), Ordering.natural(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/*  88:133 */     if (index != -1)
/*  89:    */     {
/*  90:134 */       Range<C> range = (Range)this.ranges.get(index);
/*  91:135 */       return range.contains(value) ? range : null;
/*  92:    */     }
/*  93:137 */     return null;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Range<C> span()
/*  97:    */   {
/*  98:142 */     if (this.ranges.isEmpty()) {
/*  99:143 */       throw new NoSuchElementException();
/* 100:    */     }
/* 101:145 */     return Range.create(((Range)this.ranges.get(0)).lowerBound, ((Range)this.ranges.get(this.ranges.size() - 1)).upperBound);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean isEmpty()
/* 105:    */   {
/* 106:152 */     return this.ranges.isEmpty();
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void add(Range<C> range)
/* 110:    */   {
/* 111:157 */     throw new UnsupportedOperationException();
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void addAll(RangeSet<C> other)
/* 115:    */   {
/* 116:162 */     throw new UnsupportedOperationException();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void remove(Range<C> range)
/* 120:    */   {
/* 121:167 */     throw new UnsupportedOperationException();
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void removeAll(RangeSet<C> other)
/* 125:    */   {
/* 126:172 */     throw new UnsupportedOperationException();
/* 127:    */   }
/* 128:    */   
/* 129:    */   public ImmutableSet<Range<C>> asRanges()
/* 130:    */   {
/* 131:177 */     if (this.ranges.isEmpty()) {
/* 132:178 */       return ImmutableSet.of();
/* 133:    */     }
/* 134:180 */     return new RegularImmutableSortedSet(this.ranges, Range.RANGE_LEX_ORDERING);
/* 135:    */   }
/* 136:    */   
/* 137:    */   private final class ComplementRanges
/* 138:    */     extends ImmutableList<Range<C>>
/* 139:    */   {
/* 140:    */     private final boolean positiveBoundedBelow;
/* 141:    */     private final boolean positiveBoundedAbove;
/* 142:    */     private final int size;
/* 143:    */     
/* 144:    */     ComplementRanges()
/* 145:    */     {
/* 146:195 */       this.positiveBoundedBelow = ((Range)ImmutableRangeSet.this.ranges.get(0)).hasLowerBound();
/* 147:196 */       this.positiveBoundedAbove = ((Range)Iterables.getLast(ImmutableRangeSet.this.ranges)).hasUpperBound();
/* 148:    */       
/* 149:198 */       int size = ImmutableRangeSet.this.ranges.size() - 1;
/* 150:199 */       if (this.positiveBoundedBelow) {
/* 151:200 */         size++;
/* 152:    */       }
/* 153:202 */       if (this.positiveBoundedAbove) {
/* 154:203 */         size++;
/* 155:    */       }
/* 156:205 */       this.size = size;
/* 157:    */     }
/* 158:    */     
/* 159:    */     public int size()
/* 160:    */     {
/* 161:210 */       return this.size;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public Range<C> get(int index)
/* 165:    */     {
/* 166:215 */       Preconditions.checkElementIndex(index, this.size);
/* 167:    */       Cut<C> lowerBound;
/* 168:    */       Cut<C> lowerBound;
/* 169:218 */       if (this.positiveBoundedBelow) {
/* 170:219 */         lowerBound = index == 0 ? Cut.belowAll() : ((Range)ImmutableRangeSet.this.ranges.get(index - 1)).upperBound;
/* 171:    */       } else {
/* 172:221 */         lowerBound = ((Range)ImmutableRangeSet.this.ranges.get(index)).upperBound;
/* 173:    */       }
/* 174:    */       Cut<C> upperBound;
/* 175:    */       Cut<C> upperBound;
/* 176:225 */       if ((this.positiveBoundedAbove) && (index == this.size - 1)) {
/* 177:226 */         upperBound = Cut.aboveAll();
/* 178:    */       } else {
/* 179:228 */         upperBound = ((Range)ImmutableRangeSet.this.ranges.get(index + (this.positiveBoundedBelow ? 0 : 1))).lowerBound;
/* 180:    */       }
/* 181:231 */       return Range.create(lowerBound, upperBound);
/* 182:    */     }
/* 183:    */     
/* 184:    */     boolean isPartialView()
/* 185:    */     {
/* 186:236 */       return true;
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public ImmutableRangeSet<C> complement()
/* 191:    */   {
/* 192:242 */     ImmutableRangeSet<C> result = this.complement;
/* 193:243 */     if (result != null) {
/* 194:244 */       return result;
/* 195:    */     }
/* 196:245 */     if (this.ranges.isEmpty()) {
/* 197:246 */       return this.complement = all();
/* 198:    */     }
/* 199:247 */     if ((this.ranges.size() == 1) && (((Range)this.ranges.get(0)).equals(Range.all()))) {
/* 200:248 */       return this.complement = of();
/* 201:    */     }
/* 202:250 */     ImmutableList<Range<C>> complementRanges = new ComplementRanges();
/* 203:251 */     result = this.complement = new ImmutableRangeSet(complementRanges, this);
/* 204:    */     
/* 205:253 */     return result;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private ImmutableList<Range<C>> intersectRanges(final Range<C> range)
/* 209:    */   {
/* 210:261 */     if ((this.ranges.isEmpty()) || (range.isEmpty())) {
/* 211:262 */       return ImmutableList.of();
/* 212:    */     }
/* 213:263 */     if (range.encloses(span())) {
/* 214:264 */       return this.ranges;
/* 215:    */     }
/* 216:    */     int fromIndex;
/* 217:    */     final int fromIndex;
/* 218:268 */     if (range.hasLowerBound()) {
/* 219:269 */       fromIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 220:    */     } else {
/* 221:273 */       fromIndex = 0;
/* 222:    */     }
/* 223:    */     int toIndex;
/* 224:    */     int toIndex;
/* 225:277 */     if (range.hasUpperBound()) {
/* 226:278 */       toIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, SortedLists.KeyPresentBehavior.FIRST_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 227:    */     } else {
/* 228:282 */       toIndex = this.ranges.size();
/* 229:    */     }
/* 230:284 */     final int length = toIndex - fromIndex;
/* 231:285 */     if (length == 0) {
/* 232:286 */       return ImmutableList.of();
/* 233:    */     }
/* 234:288 */     new ImmutableList()
/* 235:    */     {
/* 236:    */       public int size()
/* 237:    */       {
/* 238:291 */         return length;
/* 239:    */       }
/* 240:    */       
/* 241:    */       public Range<C> get(int index)
/* 242:    */       {
/* 243:296 */         Preconditions.checkElementIndex(index, length);
/* 244:297 */         if ((index == 0) || (index == length - 1)) {
/* 245:298 */           return ((Range)ImmutableRangeSet.this.ranges.get(index + fromIndex)).intersection(range);
/* 246:    */         }
/* 247:300 */         return (Range)ImmutableRangeSet.this.ranges.get(index + fromIndex);
/* 248:    */       }
/* 249:    */       
/* 250:    */       boolean isPartialView()
/* 251:    */       {
/* 252:306 */         return true;
/* 253:    */       }
/* 254:    */     };
/* 255:    */   }
/* 256:    */   
/* 257:    */   public ImmutableRangeSet<C> subRangeSet(Range<C> range)
/* 258:    */   {
/* 259:317 */     if (!isEmpty())
/* 260:    */     {
/* 261:318 */       Range<C> span = span();
/* 262:319 */       if (range.encloses(span)) {
/* 263:320 */         return this;
/* 264:    */       }
/* 265:321 */       if (range.isConnected(span)) {
/* 266:322 */         return new ImmutableRangeSet(intersectRanges(range));
/* 267:    */       }
/* 268:    */     }
/* 269:325 */     return of();
/* 270:    */   }
/* 271:    */   
/* 272:    */   public ImmutableSortedSet<C> asSet(DiscreteDomain<C> domain)
/* 273:    */   {
/* 274:348 */     Preconditions.checkNotNull(domain);
/* 275:349 */     if (isEmpty()) {
/* 276:350 */       return ImmutableSortedSet.of();
/* 277:    */     }
/* 278:352 */     Range<C> span = span().canonical(domain);
/* 279:353 */     if (!span.hasLowerBound()) {
/* 280:356 */       throw new IllegalArgumentException("Neither the DiscreteDomain nor this range set are bounded below");
/* 281:    */     }
/* 282:358 */     if (!span.hasUpperBound()) {
/* 283:    */       try
/* 284:    */       {
/* 285:360 */         domain.maxValue();
/* 286:    */       }
/* 287:    */       catch (NoSuchElementException e)
/* 288:    */       {
/* 289:362 */         throw new IllegalArgumentException("Neither the DiscreteDomain nor this range set are bounded above");
/* 290:    */       }
/* 291:    */     }
/* 292:367 */     return new AsSet(domain);
/* 293:    */   }
/* 294:    */   
/* 295:    */   private final class AsSet
/* 296:    */     extends ImmutableSortedSet<C>
/* 297:    */   {
/* 298:    */     private final DiscreteDomain<C> domain;
/* 299:    */     private transient Integer size;
/* 300:    */     
/* 301:    */     AsSet()
/* 302:    */     {
/* 303:374 */       super();
/* 304:375 */       this.domain = domain;
/* 305:    */     }
/* 306:    */     
/* 307:    */     public int size()
/* 308:    */     {
/* 309:383 */       Integer result = this.size;
/* 310:384 */       if (result == null)
/* 311:    */       {
/* 312:385 */         long total = 0L;
/* 313:386 */         for (Range<C> range : ImmutableRangeSet.this.ranges)
/* 314:    */         {
/* 315:387 */           total += ContiguousSet.create(range, this.domain).size();
/* 316:388 */           if (total >= 2147483647L) {
/* 317:    */             break;
/* 318:    */           }
/* 319:    */         }
/* 320:392 */         result = this.size = Integer.valueOf(Ints.saturatedCast(total));
/* 321:    */       }
/* 322:394 */       return result.intValue();
/* 323:    */     }
/* 324:    */     
/* 325:    */     public UnmodifiableIterator<C> iterator()
/* 326:    */     {
/* 327:399 */       new AbstractIterator()
/* 328:    */       {
/* 329:400 */         final Iterator<Range<C>> rangeItr = ImmutableRangeSet.this.ranges.iterator();
/* 330:401 */         Iterator<C> elemItr = Iterators.emptyIterator();
/* 331:    */         
/* 332:    */         protected C computeNext()
/* 333:    */         {
/* 334:405 */           while (!this.elemItr.hasNext()) {
/* 335:406 */             if (this.rangeItr.hasNext()) {
/* 336:407 */               this.elemItr = ContiguousSet.create((Range)this.rangeItr.next(), ImmutableRangeSet.AsSet.this.domain).iterator();
/* 337:    */             } else {
/* 338:409 */               return (Comparable)endOfData();
/* 339:    */             }
/* 340:    */           }
/* 341:412 */           return (Comparable)this.elemItr.next();
/* 342:    */         }
/* 343:    */       };
/* 344:    */     }
/* 345:    */     
/* 346:    */     @GwtIncompatible("NavigableSet")
/* 347:    */     public UnmodifiableIterator<C> descendingIterator()
/* 348:    */     {
/* 349:420 */       new AbstractIterator()
/* 350:    */       {
/* 351:421 */         final Iterator<Range<C>> rangeItr = ImmutableRangeSet.this.ranges.reverse().iterator();
/* 352:422 */         Iterator<C> elemItr = Iterators.emptyIterator();
/* 353:    */         
/* 354:    */         protected C computeNext()
/* 355:    */         {
/* 356:426 */           while (!this.elemItr.hasNext()) {
/* 357:427 */             if (this.rangeItr.hasNext()) {
/* 358:428 */               this.elemItr = ContiguousSet.create((Range)this.rangeItr.next(), ImmutableRangeSet.AsSet.this.domain).descendingIterator();
/* 359:    */             } else {
/* 360:430 */               return (Comparable)endOfData();
/* 361:    */             }
/* 362:    */           }
/* 363:433 */           return (Comparable)this.elemItr.next();
/* 364:    */         }
/* 365:    */       };
/* 366:    */     }
/* 367:    */     
/* 368:    */     ImmutableSortedSet<C> subSet(Range<C> range)
/* 369:    */     {
/* 370:439 */       return ImmutableRangeSet.this.subRangeSet(range).asSet(this.domain);
/* 371:    */     }
/* 372:    */     
/* 373:    */     ImmutableSortedSet<C> headSetImpl(C toElement, boolean inclusive)
/* 374:    */     {
/* 375:444 */       return subSet(Range.upTo(toElement, BoundType.forBoolean(inclusive)));
/* 376:    */     }
/* 377:    */     
/* 378:    */     ImmutableSortedSet<C> subSetImpl(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/* 379:    */     {
/* 380:450 */       if ((!fromInclusive) && (!toInclusive) && (Range.compareOrThrow(fromElement, toElement) == 0)) {
/* 381:451 */         return ImmutableSortedSet.of();
/* 382:    */       }
/* 383:453 */       return subSet(Range.range(fromElement, BoundType.forBoolean(fromInclusive), toElement, BoundType.forBoolean(toInclusive)));
/* 384:    */     }
/* 385:    */     
/* 386:    */     ImmutableSortedSet<C> tailSetImpl(C fromElement, boolean inclusive)
/* 387:    */     {
/* 388:460 */       return subSet(Range.downTo(fromElement, BoundType.forBoolean(inclusive)));
/* 389:    */     }
/* 390:    */     
/* 391:    */     public boolean contains(@Nullable Object o)
/* 392:    */     {
/* 393:465 */       if (o == null) {
/* 394:466 */         return false;
/* 395:    */       }
/* 396:    */       try
/* 397:    */       {
/* 398:470 */         C c = (Comparable)o;
/* 399:471 */         return ImmutableRangeSet.this.contains(c);
/* 400:    */       }
/* 401:    */       catch (ClassCastException e) {}
/* 402:473 */       return false;
/* 403:    */     }
/* 404:    */     
/* 405:    */     int indexOf(Object target)
/* 406:    */     {
/* 407:479 */       if (contains(target))
/* 408:    */       {
/* 409:481 */         C c = (Comparable)target;
/* 410:482 */         long total = 0L;
/* 411:483 */         for (Range<C> range : ImmutableRangeSet.this.ranges)
/* 412:    */         {
/* 413:484 */           if (range.contains(c)) {
/* 414:485 */             return Ints.saturatedCast(total + ContiguousSet.create(range, this.domain).indexOf(c));
/* 415:    */           }
/* 416:487 */           total += ContiguousSet.create(range, this.domain).size();
/* 417:    */         }
/* 418:490 */         throw new AssertionError("impossible");
/* 419:    */       }
/* 420:492 */       return -1;
/* 421:    */     }
/* 422:    */     
/* 423:    */     boolean isPartialView()
/* 424:    */     {
/* 425:497 */       return ImmutableRangeSet.this.ranges.isPartialView();
/* 426:    */     }
/* 427:    */     
/* 428:    */     public String toString()
/* 429:    */     {
/* 430:502 */       return ImmutableRangeSet.this.ranges.toString();
/* 431:    */     }
/* 432:    */     
/* 433:    */     Object writeReplace()
/* 434:    */     {
/* 435:507 */       return new ImmutableRangeSet.AsSetSerializedForm(ImmutableRangeSet.this.ranges, this.domain);
/* 436:    */     }
/* 437:    */   }
/* 438:    */   
/* 439:    */   private static class AsSetSerializedForm<C extends Comparable>
/* 440:    */     implements Serializable
/* 441:    */   {
/* 442:    */     private final ImmutableList<Range<C>> ranges;
/* 443:    */     private final DiscreteDomain<C> domain;
/* 444:    */     
/* 445:    */     AsSetSerializedForm(ImmutableList<Range<C>> ranges, DiscreteDomain<C> domain)
/* 446:    */     {
/* 447:516 */       this.ranges = ranges;
/* 448:517 */       this.domain = domain;
/* 449:    */     }
/* 450:    */     
/* 451:    */     Object readResolve()
/* 452:    */     {
/* 453:521 */       return new ImmutableRangeSet(this.ranges).asSet(this.domain);
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   boolean isPartialView()
/* 458:    */   {
/* 459:532 */     return this.ranges.isPartialView();
/* 460:    */   }
/* 461:    */   
/* 462:    */   public static <C extends Comparable<?>> Builder<C> builder()
/* 463:    */   {
/* 464:539 */     return new Builder();
/* 465:    */   }
/* 466:    */   
/* 467:    */   public static class Builder<C extends Comparable<?>>
/* 468:    */   {
/* 469:    */     private final RangeSet<C> rangeSet;
/* 470:    */     
/* 471:    */     public Builder()
/* 472:    */     {
/* 473:549 */       this.rangeSet = TreeRangeSet.create();
/* 474:    */     }
/* 475:    */     
/* 476:    */     public Builder<C> add(Range<C> range)
/* 477:    */     {
/* 478:560 */       if (range.isEmpty()) {
/* 479:561 */         throw new IllegalArgumentException("range must not be empty, but was " + range);
/* 480:    */       }
/* 481:562 */       if (!this.rangeSet.complement().encloses(range))
/* 482:    */       {
/* 483:563 */         for (Range<C> currentRange : this.rangeSet.asRanges()) {
/* 484:564 */           Preconditions.checkArgument((!currentRange.isConnected(range)) || (currentRange.intersection(range).isEmpty()), "Ranges may not overlap, but received %s and %s", new Object[] { currentRange, range });
/* 485:    */         }
/* 486:568 */         throw new AssertionError("should have thrown an IAE above");
/* 487:    */       }
/* 488:570 */       this.rangeSet.add(range);
/* 489:571 */       return this;
/* 490:    */     }
/* 491:    */     
/* 492:    */     public Builder<C> addAll(RangeSet<C> ranges)
/* 493:    */     {
/* 494:579 */       for (Range<C> range : ranges.asRanges()) {
/* 495:580 */         add(range);
/* 496:    */       }
/* 497:582 */       return this;
/* 498:    */     }
/* 499:    */     
/* 500:    */     public ImmutableRangeSet<C> build()
/* 501:    */     {
/* 502:589 */       return ImmutableRangeSet.copyOf(this.rangeSet);
/* 503:    */     }
/* 504:    */   }
/* 505:    */   
/* 506:    */   private static final class SerializedForm<C extends Comparable>
/* 507:    */     implements Serializable
/* 508:    */   {
/* 509:    */     private final ImmutableList<Range<C>> ranges;
/* 510:    */     
/* 511:    */     SerializedForm(ImmutableList<Range<C>> ranges)
/* 512:    */     {
/* 513:597 */       this.ranges = ranges;
/* 514:    */     }
/* 515:    */     
/* 516:    */     Object readResolve()
/* 517:    */     {
/* 518:601 */       if (this.ranges.isEmpty()) {
/* 519:602 */         return ImmutableRangeSet.of();
/* 520:    */       }
/* 521:603 */       if (this.ranges.equals(ImmutableList.of(Range.all()))) {
/* 522:604 */         return ImmutableRangeSet.all();
/* 523:    */       }
/* 524:606 */       return new ImmutableRangeSet(this.ranges);
/* 525:    */     }
/* 526:    */   }
/* 527:    */   
/* 528:    */   Object writeReplace()
/* 529:    */   {
/* 530:612 */     return new SerializedForm(this.ranges);
/* 531:    */   }
/* 532:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableRangeSet
 * JD-Core Version:    0.7.0.1
 */
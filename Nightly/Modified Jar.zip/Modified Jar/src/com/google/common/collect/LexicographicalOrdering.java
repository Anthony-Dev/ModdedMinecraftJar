/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.Iterator;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class LexicographicalOrdering<T>
/* 10:   */   extends Ordering<Iterable<T>>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:   */   final Ordering<? super T> elementOrder;
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   LexicographicalOrdering(Ordering<? super T> elementOrder)
/* 17:   */   {
/* 18:36 */     this.elementOrder = elementOrder;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int compare(Iterable<T> leftIterable, Iterable<T> rightIterable)
/* 22:   */   {
/* 23:41 */     Iterator<T> left = leftIterable.iterator();
/* 24:42 */     Iterator<T> right = rightIterable.iterator();
/* 25:43 */     while (left.hasNext())
/* 26:   */     {
/* 27:44 */       if (!right.hasNext()) {
/* 28:45 */         return 1;
/* 29:   */       }
/* 30:47 */       int result = this.elementOrder.compare(left.next(), right.next());
/* 31:48 */       if (result != 0) {
/* 32:49 */         return result;
/* 33:   */       }
/* 34:   */     }
/* 35:52 */     if (right.hasNext()) {
/* 36:53 */       return -1;
/* 37:   */     }
/* 38:55 */     return 0;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean equals(@Nullable Object object)
/* 42:   */   {
/* 43:59 */     if (object == this) {
/* 44:60 */       return true;
/* 45:   */     }
/* 46:62 */     if ((object instanceof LexicographicalOrdering))
/* 47:   */     {
/* 48:63 */       LexicographicalOrdering<?> that = (LexicographicalOrdering)object;
/* 49:64 */       return this.elementOrder.equals(that.elementOrder);
/* 50:   */     }
/* 51:66 */     return false;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public int hashCode()
/* 55:   */   {
/* 56:70 */     return this.elementOrder.hashCode() ^ 0x7BB78CF5;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public String toString()
/* 60:   */   {
/* 61:74 */     return this.elementOrder + ".lexicographical()";
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.LexicographicalOrdering
 * JD-Core Version:    0.7.0.1
 */
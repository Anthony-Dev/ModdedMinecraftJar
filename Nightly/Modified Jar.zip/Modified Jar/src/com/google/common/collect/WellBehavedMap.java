/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Iterator;
/*  5:   */ import java.util.Map;
/*  6:   */ import java.util.Map.Entry;
/*  7:   */ import java.util.Set;
/*  8:   */ 
/*  9:   */ @GwtCompatible
/* 10:   */ final class WellBehavedMap<K, V>
/* 11:   */   extends ForwardingMap<K, V>
/* 12:   */ {
/* 13:   */   private final Map<K, V> delegate;
/* 14:   */   private Set<Map.Entry<K, V>> entrySet;
/* 15:   */   
/* 16:   */   private WellBehavedMap(Map<K, V> delegate)
/* 17:   */   {
/* 18:42 */     this.delegate = delegate;
/* 19:   */   }
/* 20:   */   
/* 21:   */   static <K, V> WellBehavedMap<K, V> wrap(Map<K, V> delegate)
/* 22:   */   {
/* 23:52 */     return new WellBehavedMap(delegate);
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected Map<K, V> delegate()
/* 27:   */   {
/* 28:56 */     return this.delegate;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Set<Map.Entry<K, V>> entrySet()
/* 32:   */   {
/* 33:60 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 34:61 */     if (es != null) {
/* 35:62 */       return es;
/* 36:   */     }
/* 37:64 */     return this.entrySet = new EntrySet(null);
/* 38:   */   }
/* 39:   */   
/* 40:   */   private final class EntrySet
/* 41:   */     extends Maps.EntrySet<K, V>
/* 42:   */   {
/* 43:   */     private EntrySet() {}
/* 44:   */     
/* 45:   */     Map<K, V> map()
/* 46:   */     {
/* 47:70 */       return WellBehavedMap.this;
/* 48:   */     }
/* 49:   */     
/* 50:   */     public Iterator<Map.Entry<K, V>> iterator()
/* 51:   */     {
/* 52:75 */       new TransformedIterator(WellBehavedMap.this.keySet().iterator())
/* 53:   */       {
/* 54:   */         Map.Entry<K, V> transform(final K key)
/* 55:   */         {
/* 56:78 */           new AbstractMapEntry()
/* 57:   */           {
/* 58:   */             public K getKey()
/* 59:   */             {
/* 60:81 */               return key;
/* 61:   */             }
/* 62:   */             
/* 63:   */             public V getValue()
/* 64:   */             {
/* 65:86 */               return WellBehavedMap.this.get(key);
/* 66:   */             }
/* 67:   */             
/* 68:   */             public V setValue(V value)
/* 69:   */             {
/* 70:91 */               return WellBehavedMap.this.put(key, value);
/* 71:   */             }
/* 72:   */           };
/* 73:   */         }
/* 74:   */       };
/* 75:   */     }
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.WellBehavedMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @GwtCompatible(serializable=true, emulated=true)
/*  16:    */ public final class HashMultimap<K, V>
/*  17:    */   extends AbstractSetMultimap<K, V>
/*  18:    */ {
/*  19:    */   private static final int DEFAULT_VALUES_PER_KEY = 2;
/*  20:    */   @VisibleForTesting
/*  21: 53 */   transient int expectedValuesPerKey = 2;
/*  22:    */   @GwtIncompatible("Not needed in emulated source")
/*  23:    */   private static final long serialVersionUID = 0L;
/*  24:    */   
/*  25:    */   public static <K, V> HashMultimap<K, V> create()
/*  26:    */   {
/*  27: 61 */     return new HashMultimap();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K, V> HashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  31:    */   {
/*  32: 75 */     return new HashMultimap(expectedKeys, expectedValuesPerKey);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <K, V> HashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  36:    */   {
/*  37: 87 */     return new HashMultimap(multimap);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private HashMultimap()
/*  41:    */   {
/*  42: 91 */     super(new HashMap());
/*  43:    */   }
/*  44:    */   
/*  45:    */   private HashMultimap(int expectedKeys, int expectedValuesPerKey)
/*  46:    */   {
/*  47: 95 */     super(Maps.newHashMapWithExpectedSize(expectedKeys));
/*  48: 96 */     Preconditions.checkArgument(expectedValuesPerKey >= 0);
/*  49: 97 */     this.expectedValuesPerKey = expectedValuesPerKey;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private HashMultimap(Multimap<? extends K, ? extends V> multimap)
/*  53:    */   {
/*  54:101 */     super(Maps.newHashMapWithExpectedSize(multimap.keySet().size()));
/*  55:    */     
/*  56:103 */     putAll(multimap);
/*  57:    */   }
/*  58:    */   
/*  59:    */   Set<V> createCollection()
/*  60:    */   {
/*  61:114 */     return Sets.newHashSetWithExpectedSize(this.expectedValuesPerKey);
/*  62:    */   }
/*  63:    */   
/*  64:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  65:    */   private void writeObject(ObjectOutputStream stream)
/*  66:    */     throws IOException
/*  67:    */   {
/*  68:124 */     stream.defaultWriteObject();
/*  69:125 */     stream.writeInt(this.expectedValuesPerKey);
/*  70:126 */     Serialization.writeMultimap(this, stream);
/*  71:    */   }
/*  72:    */   
/*  73:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  74:    */   private void readObject(ObjectInputStream stream)
/*  75:    */     throws IOException, ClassNotFoundException
/*  76:    */   {
/*  77:132 */     stream.defaultReadObject();
/*  78:133 */     this.expectedValuesPerKey = stream.readInt();
/*  79:134 */     int distinctKeys = Serialization.readCount(stream);
/*  80:135 */     Map<K, Collection<V>> map = Maps.newHashMapWithExpectedSize(distinctKeys);
/*  81:136 */     setMap(map);
/*  82:137 */     Serialization.populateMultimap(this, stream, distinctKeys);
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.HashMultimap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.ObjectInputStream;
/*   7:    */ import java.io.ObjectOutputStream;
/*   8:    */ import java.util.LinkedHashMap;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true, emulated=true)
/*  11:    */ public final class LinkedHashMultiset<E>
/*  12:    */   extends AbstractMapBasedMultiset<E>
/*  13:    */ {
/*  14:    */   @GwtIncompatible("not needed in emulated source")
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   public static <E> LinkedHashMultiset<E> create()
/*  18:    */   {
/*  19: 52 */     return new LinkedHashMultiset();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static <E> LinkedHashMultiset<E> create(int distinctElements)
/*  23:    */   {
/*  24: 63 */     return new LinkedHashMultiset(distinctElements);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <E> LinkedHashMultiset<E> create(Iterable<? extends E> elements)
/*  28:    */   {
/*  29: 76 */     LinkedHashMultiset<E> multiset = create(Multisets.inferDistinctElements(elements));
/*  30:    */     
/*  31: 78 */     Iterables.addAll(multiset, elements);
/*  32: 79 */     return multiset;
/*  33:    */   }
/*  34:    */   
/*  35:    */   private LinkedHashMultiset()
/*  36:    */   {
/*  37: 83 */     super(new LinkedHashMap());
/*  38:    */   }
/*  39:    */   
/*  40:    */   private LinkedHashMultiset(int distinctElements)
/*  41:    */   {
/*  42: 88 */     super(new LinkedHashMap(Maps.capacity(distinctElements)));
/*  43:    */   }
/*  44:    */   
/*  45:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  46:    */   private void writeObject(ObjectOutputStream stream)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 97 */     stream.defaultWriteObject();
/*  50: 98 */     Serialization.writeMultiset(this, stream);
/*  51:    */   }
/*  52:    */   
/*  53:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  54:    */   private void readObject(ObjectInputStream stream)
/*  55:    */     throws IOException, ClassNotFoundException
/*  56:    */   {
/*  57:104 */     stream.defaultReadObject();
/*  58:105 */     int distinctElements = Serialization.readCount(stream);
/*  59:106 */     setBackingMap(new LinkedHashMap(Maps.capacity(distinctElements)));
/*  60:    */     
/*  61:108 */     Serialization.populateMultiset(this, stream, distinctElements);
/*  62:    */   }
/*  63:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.LinkedHashMultiset
 * JD-Core Version:    0.7.0.1
 */
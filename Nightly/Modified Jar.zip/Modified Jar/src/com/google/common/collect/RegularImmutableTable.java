/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.List;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ abstract class RegularImmutableTable<R, C, V>
/*  12:    */   extends ImmutableTable<R, C, V>
/*  13:    */ {
/*  14:    */   abstract Table.Cell<R, C, V> getCell(int paramInt);
/*  15:    */   
/*  16:    */   final ImmutableSet<Table.Cell<R, C, V>> createCellSet()
/*  17:    */   {
/*  18: 41 */     return isEmpty() ? ImmutableSet.of() : new CellSet(null);
/*  19:    */   }
/*  20:    */   
/*  21:    */   abstract V getValue(int paramInt);
/*  22:    */   
/*  23:    */   private final class CellSet
/*  24:    */     extends ImmutableSet<Table.Cell<R, C, V>>
/*  25:    */   {
/*  26:    */     private CellSet() {}
/*  27:    */     
/*  28:    */     public int size()
/*  29:    */     {
/*  30: 47 */       return RegularImmutableTable.this.size();
/*  31:    */     }
/*  32:    */     
/*  33:    */     public UnmodifiableIterator<Table.Cell<R, C, V>> iterator()
/*  34:    */     {
/*  35: 52 */       return asList().iterator();
/*  36:    */     }
/*  37:    */     
/*  38:    */     ImmutableList<Table.Cell<R, C, V>> createAsList()
/*  39:    */     {
/*  40: 57 */       new ImmutableAsList()
/*  41:    */       {
/*  42:    */         public Table.Cell<R, C, V> get(int index)
/*  43:    */         {
/*  44: 60 */           return RegularImmutableTable.this.getCell(index);
/*  45:    */         }
/*  46:    */         
/*  47:    */         ImmutableCollection<Table.Cell<R, C, V>> delegateCollection()
/*  48:    */         {
/*  49: 65 */           return RegularImmutableTable.CellSet.this;
/*  50:    */         }
/*  51:    */       };
/*  52:    */     }
/*  53:    */     
/*  54:    */     public boolean contains(@Nullable Object object)
/*  55:    */     {
/*  56: 72 */       if ((object instanceof Table.Cell))
/*  57:    */       {
/*  58: 73 */         Table.Cell<?, ?, ?> cell = (Table.Cell)object;
/*  59: 74 */         Object value = RegularImmutableTable.this.get(cell.getRowKey(), cell.getColumnKey());
/*  60: 75 */         return (value != null) && (value.equals(cell.getValue()));
/*  61:    */       }
/*  62: 77 */       return false;
/*  63:    */     }
/*  64:    */     
/*  65:    */     boolean isPartialView()
/*  66:    */     {
/*  67: 82 */       return false;
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   final ImmutableCollection<V> createValues()
/*  72:    */   {
/*  73: 90 */     return isEmpty() ? ImmutableList.of() : new Values(null);
/*  74:    */   }
/*  75:    */   
/*  76:    */   private final class Values
/*  77:    */     extends ImmutableList<V>
/*  78:    */   {
/*  79:    */     private Values() {}
/*  80:    */     
/*  81:    */     public int size()
/*  82:    */     {
/*  83: 96 */       return RegularImmutableTable.this.size();
/*  84:    */     }
/*  85:    */     
/*  86:    */     public V get(int index)
/*  87:    */     {
/*  88:101 */       return RegularImmutableTable.this.getValue(index);
/*  89:    */     }
/*  90:    */     
/*  91:    */     boolean isPartialView()
/*  92:    */     {
/*  93:106 */       return true;
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   static <R, C, V> RegularImmutableTable<R, C, V> forCells(List<Table.Cell<R, C, V>> cells, @Nullable Comparator<? super R> rowComparator, @Nullable final Comparator<? super C> columnComparator)
/*  98:    */   {
/*  99:114 */     Preconditions.checkNotNull(cells);
/* 100:115 */     if ((rowComparator != null) || (columnComparator != null))
/* 101:    */     {
/* 102:123 */       Comparator<Table.Cell<R, C, V>> comparator = new Comparator()
/* 103:    */       {
/* 104:    */         public int compare(Table.Cell<R, C, V> cell1, Table.Cell<R, C, V> cell2)
/* 105:    */         {
/* 106:125 */           int rowCompare = this.val$rowComparator == null ? 0 : this.val$rowComparator.compare(cell1.getRowKey(), cell2.getRowKey());
/* 107:127 */           if (rowCompare != 0) {
/* 108:128 */             return rowCompare;
/* 109:    */           }
/* 110:130 */           return columnComparator == null ? 0 : columnComparator.compare(cell1.getColumnKey(), cell2.getColumnKey());
/* 111:    */         }
/* 112:133 */       };
/* 113:134 */       Collections.sort(cells, comparator);
/* 114:    */     }
/* 115:136 */     return forCellsInternal(cells, rowComparator, columnComparator);
/* 116:    */   }
/* 117:    */   
/* 118:    */   static <R, C, V> RegularImmutableTable<R, C, V> forCells(Iterable<Table.Cell<R, C, V>> cells)
/* 119:    */   {
/* 120:141 */     return forCellsInternal(cells, null, null);
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static final <R, C, V> RegularImmutableTable<R, C, V> forCellsInternal(Iterable<Table.Cell<R, C, V>> cells, @Nullable Comparator<? super R> rowComparator, @Nullable Comparator<? super C> columnComparator)
/* 124:    */   {
/* 125:152 */     ImmutableSet.Builder<R> rowSpaceBuilder = ImmutableSet.builder();
/* 126:153 */     ImmutableSet.Builder<C> columnSpaceBuilder = ImmutableSet.builder();
/* 127:154 */     ImmutableList<Table.Cell<R, C, V>> cellList = ImmutableList.copyOf(cells);
/* 128:155 */     for (Table.Cell<R, C, V> cell : cellList)
/* 129:    */     {
/* 130:156 */       rowSpaceBuilder.add(cell.getRowKey());
/* 131:157 */       columnSpaceBuilder.add(cell.getColumnKey());
/* 132:    */     }
/* 133:160 */     ImmutableSet<R> rowSpace = rowSpaceBuilder.build();
/* 134:161 */     if (rowComparator != null)
/* 135:    */     {
/* 136:162 */       List<R> rowList = Lists.newArrayList(rowSpace);
/* 137:163 */       Collections.sort(rowList, rowComparator);
/* 138:164 */       rowSpace = ImmutableSet.copyOf(rowList);
/* 139:    */     }
/* 140:166 */     ImmutableSet<C> columnSpace = columnSpaceBuilder.build();
/* 141:167 */     if (columnComparator != null)
/* 142:    */     {
/* 143:168 */       List<C> columnList = Lists.newArrayList(columnSpace);
/* 144:169 */       Collections.sort(columnList, columnComparator);
/* 145:170 */       columnSpace = ImmutableSet.copyOf(columnList);
/* 146:    */     }
/* 147:175 */     return cellList.size() > rowSpace.size() * columnSpace.size() / 2L ? new DenseImmutableTable(cellList, rowSpace, columnSpace) : new SparseImmutableTable(cellList, rowSpace, columnSpace);
/* 148:    */   }
/* 149:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableTable
 * JD-Core Version:    0.7.0.1
 */
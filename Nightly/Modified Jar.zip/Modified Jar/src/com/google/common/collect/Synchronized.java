/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.annotations.VisibleForTesting;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import java.io.IOException;
/*    8:     */ import java.io.ObjectOutputStream;
/*    9:     */ import java.io.Serializable;
/*   10:     */ import java.util.Collection;
/*   11:     */ import java.util.Comparator;
/*   12:     */ import java.util.Deque;
/*   13:     */ import java.util.Iterator;
/*   14:     */ import java.util.List;
/*   15:     */ import java.util.ListIterator;
/*   16:     */ import java.util.Map;
/*   17:     */ import java.util.Map.Entry;
/*   18:     */ import java.util.NavigableMap;
/*   19:     */ import java.util.NavigableSet;
/*   20:     */ import java.util.Queue;
/*   21:     */ import java.util.RandomAccess;
/*   22:     */ import java.util.Set;
/*   23:     */ import java.util.SortedMap;
/*   24:     */ import java.util.SortedSet;
/*   25:     */ import javax.annotation.Nullable;
/*   26:     */ 
/*   27:     */ @GwtCompatible(emulated=true)
/*   28:     */ final class Synchronized
/*   29:     */ {
/*   30:     */   static class SynchronizedObject
/*   31:     */     implements Serializable
/*   32:     */   {
/*   33:     */     final Object delegate;
/*   34:     */     final Object mutex;
/*   35:     */     @GwtIncompatible("not needed in emulated source")
/*   36:     */     private static final long serialVersionUID = 0L;
/*   37:     */     
/*   38:     */     SynchronizedObject(Object delegate, @Nullable Object mutex)
/*   39:     */     {
/*   40:  68 */       this.delegate = Preconditions.checkNotNull(delegate);
/*   41:  69 */       this.mutex = (mutex == null ? this : mutex);
/*   42:     */     }
/*   43:     */     
/*   44:     */     Object delegate()
/*   45:     */     {
/*   46:  73 */       return this.delegate;
/*   47:     */     }
/*   48:     */     
/*   49:     */     public String toString()
/*   50:     */     {
/*   51:  79 */       synchronized (this.mutex)
/*   52:     */       {
/*   53:  80 */         return this.delegate.toString();
/*   54:     */       }
/*   55:     */     }
/*   56:     */     
/*   57:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*   58:     */     private void writeObject(ObjectOutputStream stream)
/*   59:     */       throws IOException
/*   60:     */     {
/*   61:  91 */       synchronized (this.mutex)
/*   62:     */       {
/*   63:  92 */         stream.defaultWriteObject();
/*   64:     */       }
/*   65:     */     }
/*   66:     */   }
/*   67:     */   
/*   68:     */   private static <E> Collection<E> collection(Collection<E> collection, @Nullable Object mutex)
/*   69:     */   {
/*   70: 102 */     return new SynchronizedCollection(collection, mutex, null);
/*   71:     */   }
/*   72:     */   
/*   73:     */   @VisibleForTesting
/*   74:     */   static class SynchronizedCollection<E>
/*   75:     */     extends Synchronized.SynchronizedObject
/*   76:     */     implements Collection<E>
/*   77:     */   {
/*   78:     */     private static final long serialVersionUID = 0L;
/*   79:     */     
/*   80:     */     private SynchronizedCollection(Collection<E> delegate, @Nullable Object mutex)
/*   81:     */     {
/*   82: 109 */       super(mutex);
/*   83:     */     }
/*   84:     */     
/*   85:     */     Collection<E> delegate()
/*   86:     */     {
/*   87: 114 */       return (Collection)super.delegate();
/*   88:     */     }
/*   89:     */     
/*   90:     */     public boolean add(E e)
/*   91:     */     {
/*   92: 119 */       synchronized (this.mutex)
/*   93:     */       {
/*   94: 120 */         return delegate().add(e);
/*   95:     */       }
/*   96:     */     }
/*   97:     */     
/*   98:     */     public boolean addAll(Collection<? extends E> c)
/*   99:     */     {
/*  100: 126 */       synchronized (this.mutex)
/*  101:     */       {
/*  102: 127 */         return delegate().addAll(c);
/*  103:     */       }
/*  104:     */     }
/*  105:     */     
/*  106:     */     public void clear()
/*  107:     */     {
/*  108: 133 */       synchronized (this.mutex)
/*  109:     */       {
/*  110: 134 */         delegate().clear();
/*  111:     */       }
/*  112:     */     }
/*  113:     */     
/*  114:     */     public boolean contains(Object o)
/*  115:     */     {
/*  116: 140 */       synchronized (this.mutex)
/*  117:     */       {
/*  118: 141 */         return delegate().contains(o);
/*  119:     */       }
/*  120:     */     }
/*  121:     */     
/*  122:     */     public boolean containsAll(Collection<?> c)
/*  123:     */     {
/*  124: 147 */       synchronized (this.mutex)
/*  125:     */       {
/*  126: 148 */         return delegate().containsAll(c);
/*  127:     */       }
/*  128:     */     }
/*  129:     */     
/*  130:     */     public boolean isEmpty()
/*  131:     */     {
/*  132: 154 */       synchronized (this.mutex)
/*  133:     */       {
/*  134: 155 */         return delegate().isEmpty();
/*  135:     */       }
/*  136:     */     }
/*  137:     */     
/*  138:     */     public Iterator<E> iterator()
/*  139:     */     {
/*  140: 161 */       return delegate().iterator();
/*  141:     */     }
/*  142:     */     
/*  143:     */     public boolean remove(Object o)
/*  144:     */     {
/*  145: 166 */       synchronized (this.mutex)
/*  146:     */       {
/*  147: 167 */         return delegate().remove(o);
/*  148:     */       }
/*  149:     */     }
/*  150:     */     
/*  151:     */     public boolean removeAll(Collection<?> c)
/*  152:     */     {
/*  153: 173 */       synchronized (this.mutex)
/*  154:     */       {
/*  155: 174 */         return delegate().removeAll(c);
/*  156:     */       }
/*  157:     */     }
/*  158:     */     
/*  159:     */     public boolean retainAll(Collection<?> c)
/*  160:     */     {
/*  161: 180 */       synchronized (this.mutex)
/*  162:     */       {
/*  163: 181 */         return delegate().retainAll(c);
/*  164:     */       }
/*  165:     */     }
/*  166:     */     
/*  167:     */     public int size()
/*  168:     */     {
/*  169: 187 */       synchronized (this.mutex)
/*  170:     */       {
/*  171: 188 */         return delegate().size();
/*  172:     */       }
/*  173:     */     }
/*  174:     */     
/*  175:     */     public Object[] toArray()
/*  176:     */     {
/*  177: 194 */       synchronized (this.mutex)
/*  178:     */       {
/*  179: 195 */         return delegate().toArray();
/*  180:     */       }
/*  181:     */     }
/*  182:     */     
/*  183:     */     public <T> T[] toArray(T[] a)
/*  184:     */     {
/*  185: 201 */       synchronized (this.mutex)
/*  186:     */       {
/*  187: 202 */         return delegate().toArray(a);
/*  188:     */       }
/*  189:     */     }
/*  190:     */   }
/*  191:     */   
/*  192:     */   @VisibleForTesting
/*  193:     */   static <E> Set<E> set(Set<E> set, @Nullable Object mutex)
/*  194:     */   {
/*  195: 210 */     return new SynchronizedSet(set, mutex);
/*  196:     */   }
/*  197:     */   
/*  198:     */   static class SynchronizedSet<E>
/*  199:     */     extends Synchronized.SynchronizedCollection<E>
/*  200:     */     implements Set<E>
/*  201:     */   {
/*  202:     */     private static final long serialVersionUID = 0L;
/*  203:     */     
/*  204:     */     SynchronizedSet(Set<E> delegate, @Nullable Object mutex)
/*  205:     */     {
/*  206: 217 */       super(mutex, null);
/*  207:     */     }
/*  208:     */     
/*  209:     */     Set<E> delegate()
/*  210:     */     {
/*  211: 221 */       return (Set)super.delegate();
/*  212:     */     }
/*  213:     */     
/*  214:     */     public boolean equals(Object o)
/*  215:     */     {
/*  216: 225 */       if (o == this) {
/*  217: 226 */         return true;
/*  218:     */       }
/*  219: 228 */       synchronized (this.mutex)
/*  220:     */       {
/*  221: 229 */         return delegate().equals(o);
/*  222:     */       }
/*  223:     */     }
/*  224:     */     
/*  225:     */     public int hashCode()
/*  226:     */     {
/*  227: 234 */       synchronized (this.mutex)
/*  228:     */       {
/*  229: 235 */         return delegate().hashCode();
/*  230:     */       }
/*  231:     */     }
/*  232:     */   }
/*  233:     */   
/*  234:     */   private static <E> SortedSet<E> sortedSet(SortedSet<E> set, @Nullable Object mutex)
/*  235:     */   {
/*  236: 244 */     return new SynchronizedSortedSet(set, mutex);
/*  237:     */   }
/*  238:     */   
/*  239:     */   static class SynchronizedSortedSet<E>
/*  240:     */     extends Synchronized.SynchronizedSet<E>
/*  241:     */     implements SortedSet<E>
/*  242:     */   {
/*  243:     */     private static final long serialVersionUID = 0L;
/*  244:     */     
/*  245:     */     SynchronizedSortedSet(SortedSet<E> delegate, @Nullable Object mutex)
/*  246:     */     {
/*  247: 250 */       super(mutex);
/*  248:     */     }
/*  249:     */     
/*  250:     */     SortedSet<E> delegate()
/*  251:     */     {
/*  252: 254 */       return (SortedSet)super.delegate();
/*  253:     */     }
/*  254:     */     
/*  255:     */     public Comparator<? super E> comparator()
/*  256:     */     {
/*  257: 259 */       synchronized (this.mutex)
/*  258:     */       {
/*  259: 260 */         return delegate().comparator();
/*  260:     */       }
/*  261:     */     }
/*  262:     */     
/*  263:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  264:     */     {
/*  265: 266 */       synchronized (this.mutex)
/*  266:     */       {
/*  267: 267 */         return Synchronized.sortedSet(delegate().subSet(fromElement, toElement), this.mutex);
/*  268:     */       }
/*  269:     */     }
/*  270:     */     
/*  271:     */     public SortedSet<E> headSet(E toElement)
/*  272:     */     {
/*  273: 273 */       synchronized (this.mutex)
/*  274:     */       {
/*  275: 274 */         return Synchronized.sortedSet(delegate().headSet(toElement), this.mutex);
/*  276:     */       }
/*  277:     */     }
/*  278:     */     
/*  279:     */     public SortedSet<E> tailSet(E fromElement)
/*  280:     */     {
/*  281: 280 */       synchronized (this.mutex)
/*  282:     */       {
/*  283: 281 */         return Synchronized.sortedSet(delegate().tailSet(fromElement), this.mutex);
/*  284:     */       }
/*  285:     */     }
/*  286:     */     
/*  287:     */     public E first()
/*  288:     */     {
/*  289: 287 */       synchronized (this.mutex)
/*  290:     */       {
/*  291: 288 */         return delegate().first();
/*  292:     */       }
/*  293:     */     }
/*  294:     */     
/*  295:     */     public E last()
/*  296:     */     {
/*  297: 294 */       synchronized (this.mutex)
/*  298:     */       {
/*  299: 295 */         return delegate().last();
/*  300:     */       }
/*  301:     */     }
/*  302:     */   }
/*  303:     */   
/*  304:     */   private static <E> List<E> list(List<E> list, @Nullable Object mutex)
/*  305:     */   {
/*  306: 303 */     return (list instanceof RandomAccess) ? new SynchronizedRandomAccessList(list, mutex) : new SynchronizedList(list, mutex);
/*  307:     */   }
/*  308:     */   
/*  309:     */   private static class SynchronizedList<E>
/*  310:     */     extends Synchronized.SynchronizedCollection<E>
/*  311:     */     implements List<E>
/*  312:     */   {
/*  313:     */     private static final long serialVersionUID = 0L;
/*  314:     */     
/*  315:     */     SynchronizedList(List<E> delegate, @Nullable Object mutex)
/*  316:     */     {
/*  317: 311 */       super(mutex, null);
/*  318:     */     }
/*  319:     */     
/*  320:     */     List<E> delegate()
/*  321:     */     {
/*  322: 315 */       return (List)super.delegate();
/*  323:     */     }
/*  324:     */     
/*  325:     */     public void add(int index, E element)
/*  326:     */     {
/*  327: 320 */       synchronized (this.mutex)
/*  328:     */       {
/*  329: 321 */         delegate().add(index, element);
/*  330:     */       }
/*  331:     */     }
/*  332:     */     
/*  333:     */     public boolean addAll(int index, Collection<? extends E> c)
/*  334:     */     {
/*  335: 327 */       synchronized (this.mutex)
/*  336:     */       {
/*  337: 328 */         return delegate().addAll(index, c);
/*  338:     */       }
/*  339:     */     }
/*  340:     */     
/*  341:     */     public E get(int index)
/*  342:     */     {
/*  343: 334 */       synchronized (this.mutex)
/*  344:     */       {
/*  345: 335 */         return delegate().get(index);
/*  346:     */       }
/*  347:     */     }
/*  348:     */     
/*  349:     */     public int indexOf(Object o)
/*  350:     */     {
/*  351: 341 */       synchronized (this.mutex)
/*  352:     */       {
/*  353: 342 */         return delegate().indexOf(o);
/*  354:     */       }
/*  355:     */     }
/*  356:     */     
/*  357:     */     public int lastIndexOf(Object o)
/*  358:     */     {
/*  359: 348 */       synchronized (this.mutex)
/*  360:     */       {
/*  361: 349 */         return delegate().lastIndexOf(o);
/*  362:     */       }
/*  363:     */     }
/*  364:     */     
/*  365:     */     public ListIterator<E> listIterator()
/*  366:     */     {
/*  367: 355 */       return delegate().listIterator();
/*  368:     */     }
/*  369:     */     
/*  370:     */     public ListIterator<E> listIterator(int index)
/*  371:     */     {
/*  372: 360 */       return delegate().listIterator(index);
/*  373:     */     }
/*  374:     */     
/*  375:     */     public E remove(int index)
/*  376:     */     {
/*  377: 365 */       synchronized (this.mutex)
/*  378:     */       {
/*  379: 366 */         return delegate().remove(index);
/*  380:     */       }
/*  381:     */     }
/*  382:     */     
/*  383:     */     public E set(int index, E element)
/*  384:     */     {
/*  385: 372 */       synchronized (this.mutex)
/*  386:     */       {
/*  387: 373 */         return delegate().set(index, element);
/*  388:     */       }
/*  389:     */     }
/*  390:     */     
/*  391:     */     public List<E> subList(int fromIndex, int toIndex)
/*  392:     */     {
/*  393: 379 */       synchronized (this.mutex)
/*  394:     */       {
/*  395: 380 */         return Synchronized.list(delegate().subList(fromIndex, toIndex), this.mutex);
/*  396:     */       }
/*  397:     */     }
/*  398:     */     
/*  399:     */     public boolean equals(Object o)
/*  400:     */     {
/*  401: 385 */       if (o == this) {
/*  402: 386 */         return true;
/*  403:     */       }
/*  404: 388 */       synchronized (this.mutex)
/*  405:     */       {
/*  406: 389 */         return delegate().equals(o);
/*  407:     */       }
/*  408:     */     }
/*  409:     */     
/*  410:     */     public int hashCode()
/*  411:     */     {
/*  412: 394 */       synchronized (this.mutex)
/*  413:     */       {
/*  414: 395 */         return delegate().hashCode();
/*  415:     */       }
/*  416:     */     }
/*  417:     */   }
/*  418:     */   
/*  419:     */   private static class SynchronizedRandomAccessList<E>
/*  420:     */     extends Synchronized.SynchronizedList<E>
/*  421:     */     implements RandomAccess
/*  422:     */   {
/*  423:     */     private static final long serialVersionUID = 0L;
/*  424:     */     
/*  425:     */     SynchronizedRandomAccessList(List<E> list, @Nullable Object mutex)
/*  426:     */     {
/*  427: 405 */       super(mutex);
/*  428:     */     }
/*  429:     */   }
/*  430:     */   
/*  431:     */   static <E> Multiset<E> multiset(Multiset<E> multiset, @Nullable Object mutex)
/*  432:     */   {
/*  433: 412 */     if (((multiset instanceof SynchronizedMultiset)) || ((multiset instanceof ImmutableMultiset))) {
/*  434: 414 */       return multiset;
/*  435:     */     }
/*  436: 416 */     return new SynchronizedMultiset(multiset, mutex);
/*  437:     */   }
/*  438:     */   
/*  439:     */   private static class SynchronizedMultiset<E>
/*  440:     */     extends Synchronized.SynchronizedCollection<E>
/*  441:     */     implements Multiset<E>
/*  442:     */   {
/*  443:     */     transient Set<E> elementSet;
/*  444:     */     transient Set<Multiset.Entry<E>> entrySet;
/*  445:     */     private static final long serialVersionUID = 0L;
/*  446:     */     
/*  447:     */     SynchronizedMultiset(Multiset<E> delegate, @Nullable Object mutex)
/*  448:     */     {
/*  449: 425 */       super(mutex, null);
/*  450:     */     }
/*  451:     */     
/*  452:     */     Multiset<E> delegate()
/*  453:     */     {
/*  454: 429 */       return (Multiset)super.delegate();
/*  455:     */     }
/*  456:     */     
/*  457:     */     public int count(Object o)
/*  458:     */     {
/*  459: 434 */       synchronized (this.mutex)
/*  460:     */       {
/*  461: 435 */         return delegate().count(o);
/*  462:     */       }
/*  463:     */     }
/*  464:     */     
/*  465:     */     public int add(E e, int n)
/*  466:     */     {
/*  467: 441 */       synchronized (this.mutex)
/*  468:     */       {
/*  469: 442 */         return delegate().add(e, n);
/*  470:     */       }
/*  471:     */     }
/*  472:     */     
/*  473:     */     public int remove(Object o, int n)
/*  474:     */     {
/*  475: 448 */       synchronized (this.mutex)
/*  476:     */       {
/*  477: 449 */         return delegate().remove(o, n);
/*  478:     */       }
/*  479:     */     }
/*  480:     */     
/*  481:     */     public int setCount(E element, int count)
/*  482:     */     {
/*  483: 455 */       synchronized (this.mutex)
/*  484:     */       {
/*  485: 456 */         return delegate().setCount(element, count);
/*  486:     */       }
/*  487:     */     }
/*  488:     */     
/*  489:     */     public boolean setCount(E element, int oldCount, int newCount)
/*  490:     */     {
/*  491: 462 */       synchronized (this.mutex)
/*  492:     */       {
/*  493: 463 */         return delegate().setCount(element, oldCount, newCount);
/*  494:     */       }
/*  495:     */     }
/*  496:     */     
/*  497:     */     public Set<E> elementSet()
/*  498:     */     {
/*  499: 469 */       synchronized (this.mutex)
/*  500:     */       {
/*  501: 470 */         if (this.elementSet == null) {
/*  502: 471 */           this.elementSet = Synchronized.typePreservingSet(delegate().elementSet(), this.mutex);
/*  503:     */         }
/*  504: 473 */         return this.elementSet;
/*  505:     */       }
/*  506:     */     }
/*  507:     */     
/*  508:     */     public Set<Multiset.Entry<E>> entrySet()
/*  509:     */     {
/*  510: 479 */       synchronized (this.mutex)
/*  511:     */       {
/*  512: 480 */         if (this.entrySet == null) {
/*  513: 481 */           this.entrySet = Synchronized.typePreservingSet(delegate().entrySet(), this.mutex);
/*  514:     */         }
/*  515: 483 */         return this.entrySet;
/*  516:     */       }
/*  517:     */     }
/*  518:     */     
/*  519:     */     public boolean equals(Object o)
/*  520:     */     {
/*  521: 488 */       if (o == this) {
/*  522: 489 */         return true;
/*  523:     */       }
/*  524: 491 */       synchronized (this.mutex)
/*  525:     */       {
/*  526: 492 */         return delegate().equals(o);
/*  527:     */       }
/*  528:     */     }
/*  529:     */     
/*  530:     */     public int hashCode()
/*  531:     */     {
/*  532: 497 */       synchronized (this.mutex)
/*  533:     */       {
/*  534: 498 */         return delegate().hashCode();
/*  535:     */       }
/*  536:     */     }
/*  537:     */   }
/*  538:     */   
/*  539:     */   static <K, V> Multimap<K, V> multimap(Multimap<K, V> multimap, @Nullable Object mutex)
/*  540:     */   {
/*  541: 507 */     if (((multimap instanceof SynchronizedMultimap)) || ((multimap instanceof ImmutableMultimap))) {
/*  542: 509 */       return multimap;
/*  543:     */     }
/*  544: 511 */     return new SynchronizedMultimap(multimap, mutex);
/*  545:     */   }
/*  546:     */   
/*  547:     */   private static class SynchronizedMultimap<K, V>
/*  548:     */     extends Synchronized.SynchronizedObject
/*  549:     */     implements Multimap<K, V>
/*  550:     */   {
/*  551:     */     transient Set<K> keySet;
/*  552:     */     transient Collection<V> valuesCollection;
/*  553:     */     transient Collection<Map.Entry<K, V>> entries;
/*  554:     */     transient Map<K, Collection<V>> asMap;
/*  555:     */     transient Multiset<K> keys;
/*  556:     */     private static final long serialVersionUID = 0L;
/*  557:     */     
/*  558:     */     Multimap<K, V> delegate()
/*  559:     */     {
/*  560: 524 */       return (Multimap)super.delegate();
/*  561:     */     }
/*  562:     */     
/*  563:     */     SynchronizedMultimap(Multimap<K, V> delegate, @Nullable Object mutex)
/*  564:     */     {
/*  565: 528 */       super(mutex);
/*  566:     */     }
/*  567:     */     
/*  568:     */     public int size()
/*  569:     */     {
/*  570: 533 */       synchronized (this.mutex)
/*  571:     */       {
/*  572: 534 */         return delegate().size();
/*  573:     */       }
/*  574:     */     }
/*  575:     */     
/*  576:     */     public boolean isEmpty()
/*  577:     */     {
/*  578: 540 */       synchronized (this.mutex)
/*  579:     */       {
/*  580: 541 */         return delegate().isEmpty();
/*  581:     */       }
/*  582:     */     }
/*  583:     */     
/*  584:     */     public boolean containsKey(Object key)
/*  585:     */     {
/*  586: 547 */       synchronized (this.mutex)
/*  587:     */       {
/*  588: 548 */         return delegate().containsKey(key);
/*  589:     */       }
/*  590:     */     }
/*  591:     */     
/*  592:     */     public boolean containsValue(Object value)
/*  593:     */     {
/*  594: 554 */       synchronized (this.mutex)
/*  595:     */       {
/*  596: 555 */         return delegate().containsValue(value);
/*  597:     */       }
/*  598:     */     }
/*  599:     */     
/*  600:     */     public boolean containsEntry(Object key, Object value)
/*  601:     */     {
/*  602: 561 */       synchronized (this.mutex)
/*  603:     */       {
/*  604: 562 */         return delegate().containsEntry(key, value);
/*  605:     */       }
/*  606:     */     }
/*  607:     */     
/*  608:     */     public Collection<V> get(K key)
/*  609:     */     {
/*  610: 568 */       synchronized (this.mutex)
/*  611:     */       {
/*  612: 569 */         return Synchronized.typePreservingCollection(delegate().get(key), this.mutex);
/*  613:     */       }
/*  614:     */     }
/*  615:     */     
/*  616:     */     public boolean put(K key, V value)
/*  617:     */     {
/*  618: 575 */       synchronized (this.mutex)
/*  619:     */       {
/*  620: 576 */         return delegate().put(key, value);
/*  621:     */       }
/*  622:     */     }
/*  623:     */     
/*  624:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  625:     */     {
/*  626: 582 */       synchronized (this.mutex)
/*  627:     */       {
/*  628: 583 */         return delegate().putAll(key, values);
/*  629:     */       }
/*  630:     */     }
/*  631:     */     
/*  632:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  633:     */     {
/*  634: 589 */       synchronized (this.mutex)
/*  635:     */       {
/*  636: 590 */         return delegate().putAll(multimap);
/*  637:     */       }
/*  638:     */     }
/*  639:     */     
/*  640:     */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*  641:     */     {
/*  642: 596 */       synchronized (this.mutex)
/*  643:     */       {
/*  644: 597 */         return delegate().replaceValues(key, values);
/*  645:     */       }
/*  646:     */     }
/*  647:     */     
/*  648:     */     public boolean remove(Object key, Object value)
/*  649:     */     {
/*  650: 603 */       synchronized (this.mutex)
/*  651:     */       {
/*  652: 604 */         return delegate().remove(key, value);
/*  653:     */       }
/*  654:     */     }
/*  655:     */     
/*  656:     */     public Collection<V> removeAll(Object key)
/*  657:     */     {
/*  658: 610 */       synchronized (this.mutex)
/*  659:     */       {
/*  660: 611 */         return delegate().removeAll(key);
/*  661:     */       }
/*  662:     */     }
/*  663:     */     
/*  664:     */     public void clear()
/*  665:     */     {
/*  666: 617 */       synchronized (this.mutex)
/*  667:     */       {
/*  668: 618 */         delegate().clear();
/*  669:     */       }
/*  670:     */     }
/*  671:     */     
/*  672:     */     public Set<K> keySet()
/*  673:     */     {
/*  674: 624 */       synchronized (this.mutex)
/*  675:     */       {
/*  676: 625 */         if (this.keySet == null) {
/*  677: 626 */           this.keySet = Synchronized.typePreservingSet(delegate().keySet(), this.mutex);
/*  678:     */         }
/*  679: 628 */         return this.keySet;
/*  680:     */       }
/*  681:     */     }
/*  682:     */     
/*  683:     */     public Collection<V> values()
/*  684:     */     {
/*  685: 634 */       synchronized (this.mutex)
/*  686:     */       {
/*  687: 635 */         if (this.valuesCollection == null) {
/*  688: 636 */           this.valuesCollection = Synchronized.collection(delegate().values(), this.mutex);
/*  689:     */         }
/*  690: 638 */         return this.valuesCollection;
/*  691:     */       }
/*  692:     */     }
/*  693:     */     
/*  694:     */     public Collection<Map.Entry<K, V>> entries()
/*  695:     */     {
/*  696: 644 */       synchronized (this.mutex)
/*  697:     */       {
/*  698: 645 */         if (this.entries == null) {
/*  699: 646 */           this.entries = Synchronized.typePreservingCollection(delegate().entries(), this.mutex);
/*  700:     */         }
/*  701: 648 */         return this.entries;
/*  702:     */       }
/*  703:     */     }
/*  704:     */     
/*  705:     */     public Map<K, Collection<V>> asMap()
/*  706:     */     {
/*  707: 654 */       synchronized (this.mutex)
/*  708:     */       {
/*  709: 655 */         if (this.asMap == null) {
/*  710: 656 */           this.asMap = new Synchronized.SynchronizedAsMap(delegate().asMap(), this.mutex);
/*  711:     */         }
/*  712: 658 */         return this.asMap;
/*  713:     */       }
/*  714:     */     }
/*  715:     */     
/*  716:     */     public Multiset<K> keys()
/*  717:     */     {
/*  718: 664 */       synchronized (this.mutex)
/*  719:     */       {
/*  720: 665 */         if (this.keys == null) {
/*  721: 666 */           this.keys = Synchronized.multiset(delegate().keys(), this.mutex);
/*  722:     */         }
/*  723: 668 */         return this.keys;
/*  724:     */       }
/*  725:     */     }
/*  726:     */     
/*  727:     */     public boolean equals(Object o)
/*  728:     */     {
/*  729: 673 */       if (o == this) {
/*  730: 674 */         return true;
/*  731:     */       }
/*  732: 676 */       synchronized (this.mutex)
/*  733:     */       {
/*  734: 677 */         return delegate().equals(o);
/*  735:     */       }
/*  736:     */     }
/*  737:     */     
/*  738:     */     public int hashCode()
/*  739:     */     {
/*  740: 682 */       synchronized (this.mutex)
/*  741:     */       {
/*  742: 683 */         return delegate().hashCode();
/*  743:     */       }
/*  744:     */     }
/*  745:     */   }
/*  746:     */   
/*  747:     */   static <K, V> ListMultimap<K, V> listMultimap(ListMultimap<K, V> multimap, @Nullable Object mutex)
/*  748:     */   {
/*  749: 692 */     if (((multimap instanceof SynchronizedListMultimap)) || ((multimap instanceof ImmutableListMultimap))) {
/*  750: 694 */       return multimap;
/*  751:     */     }
/*  752: 696 */     return new SynchronizedListMultimap(multimap, mutex);
/*  753:     */   }
/*  754:     */   
/*  755:     */   private static class SynchronizedListMultimap<K, V>
/*  756:     */     extends Synchronized.SynchronizedMultimap<K, V>
/*  757:     */     implements ListMultimap<K, V>
/*  758:     */   {
/*  759:     */     private static final long serialVersionUID = 0L;
/*  760:     */     
/*  761:     */     SynchronizedListMultimap(ListMultimap<K, V> delegate, @Nullable Object mutex)
/*  762:     */     {
/*  763: 703 */       super(mutex);
/*  764:     */     }
/*  765:     */     
/*  766:     */     ListMultimap<K, V> delegate()
/*  767:     */     {
/*  768: 706 */       return (ListMultimap)super.delegate();
/*  769:     */     }
/*  770:     */     
/*  771:     */     public List<V> get(K key)
/*  772:     */     {
/*  773: 709 */       synchronized (this.mutex)
/*  774:     */       {
/*  775: 710 */         return Synchronized.list(delegate().get(key), this.mutex);
/*  776:     */       }
/*  777:     */     }
/*  778:     */     
/*  779:     */     public List<V> removeAll(Object key)
/*  780:     */     {
/*  781: 714 */       synchronized (this.mutex)
/*  782:     */       {
/*  783: 715 */         return delegate().removeAll(key);
/*  784:     */       }
/*  785:     */     }
/*  786:     */     
/*  787:     */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/*  788:     */     {
/*  789: 720 */       synchronized (this.mutex)
/*  790:     */       {
/*  791: 721 */         return delegate().replaceValues(key, values);
/*  792:     */       }
/*  793:     */     }
/*  794:     */   }
/*  795:     */   
/*  796:     */   static <K, V> SetMultimap<K, V> setMultimap(SetMultimap<K, V> multimap, @Nullable Object mutex)
/*  797:     */   {
/*  798: 729 */     if (((multimap instanceof SynchronizedSetMultimap)) || ((multimap instanceof ImmutableSetMultimap))) {
/*  799: 731 */       return multimap;
/*  800:     */     }
/*  801: 733 */     return new SynchronizedSetMultimap(multimap, mutex);
/*  802:     */   }
/*  803:     */   
/*  804:     */   private static class SynchronizedSetMultimap<K, V>
/*  805:     */     extends Synchronized.SynchronizedMultimap<K, V>
/*  806:     */     implements SetMultimap<K, V>
/*  807:     */   {
/*  808:     */     transient Set<Map.Entry<K, V>> entrySet;
/*  809:     */     private static final long serialVersionUID = 0L;
/*  810:     */     
/*  811:     */     SynchronizedSetMultimap(SetMultimap<K, V> delegate, @Nullable Object mutex)
/*  812:     */     {
/*  813: 742 */       super(mutex);
/*  814:     */     }
/*  815:     */     
/*  816:     */     SetMultimap<K, V> delegate()
/*  817:     */     {
/*  818: 745 */       return (SetMultimap)super.delegate();
/*  819:     */     }
/*  820:     */     
/*  821:     */     public Set<V> get(K key)
/*  822:     */     {
/*  823: 748 */       synchronized (this.mutex)
/*  824:     */       {
/*  825: 749 */         return Synchronized.set(delegate().get(key), this.mutex);
/*  826:     */       }
/*  827:     */     }
/*  828:     */     
/*  829:     */     public Set<V> removeAll(Object key)
/*  830:     */     {
/*  831: 753 */       synchronized (this.mutex)
/*  832:     */       {
/*  833: 754 */         return delegate().removeAll(key);
/*  834:     */       }
/*  835:     */     }
/*  836:     */     
/*  837:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  838:     */     {
/*  839: 759 */       synchronized (this.mutex)
/*  840:     */       {
/*  841: 760 */         return delegate().replaceValues(key, values);
/*  842:     */       }
/*  843:     */     }
/*  844:     */     
/*  845:     */     public Set<Map.Entry<K, V>> entries()
/*  846:     */     {
/*  847: 764 */       synchronized (this.mutex)
/*  848:     */       {
/*  849: 765 */         if (this.entrySet == null) {
/*  850: 766 */           this.entrySet = Synchronized.set(delegate().entries(), this.mutex);
/*  851:     */         }
/*  852: 768 */         return this.entrySet;
/*  853:     */       }
/*  854:     */     }
/*  855:     */   }
/*  856:     */   
/*  857:     */   static <K, V> SortedSetMultimap<K, V> sortedSetMultimap(SortedSetMultimap<K, V> multimap, @Nullable Object mutex)
/*  858:     */   {
/*  859: 776 */     if ((multimap instanceof SynchronizedSortedSetMultimap)) {
/*  860: 777 */       return multimap;
/*  861:     */     }
/*  862: 779 */     return new SynchronizedSortedSetMultimap(multimap, mutex);
/*  863:     */   }
/*  864:     */   
/*  865:     */   private static class SynchronizedSortedSetMultimap<K, V>
/*  866:     */     extends Synchronized.SynchronizedSetMultimap<K, V>
/*  867:     */     implements SortedSetMultimap<K, V>
/*  868:     */   {
/*  869:     */     private static final long serialVersionUID = 0L;
/*  870:     */     
/*  871:     */     SynchronizedSortedSetMultimap(SortedSetMultimap<K, V> delegate, @Nullable Object mutex)
/*  872:     */     {
/*  873: 786 */       super(mutex);
/*  874:     */     }
/*  875:     */     
/*  876:     */     SortedSetMultimap<K, V> delegate()
/*  877:     */     {
/*  878: 789 */       return (SortedSetMultimap)super.delegate();
/*  879:     */     }
/*  880:     */     
/*  881:     */     public SortedSet<V> get(K key)
/*  882:     */     {
/*  883: 792 */       synchronized (this.mutex)
/*  884:     */       {
/*  885: 793 */         return Synchronized.sortedSet(delegate().get(key), this.mutex);
/*  886:     */       }
/*  887:     */     }
/*  888:     */     
/*  889:     */     public SortedSet<V> removeAll(Object key)
/*  890:     */     {
/*  891: 797 */       synchronized (this.mutex)
/*  892:     */       {
/*  893: 798 */         return delegate().removeAll(key);
/*  894:     */       }
/*  895:     */     }
/*  896:     */     
/*  897:     */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/*  898:     */     {
/*  899: 803 */       synchronized (this.mutex)
/*  900:     */       {
/*  901: 804 */         return delegate().replaceValues(key, values);
/*  902:     */       }
/*  903:     */     }
/*  904:     */     
/*  905:     */     public Comparator<? super V> valueComparator()
/*  906:     */     {
/*  907: 809 */       synchronized (this.mutex)
/*  908:     */       {
/*  909: 810 */         return delegate().valueComparator();
/*  910:     */       }
/*  911:     */     }
/*  912:     */   }
/*  913:     */   
/*  914:     */   private static <E> Collection<E> typePreservingCollection(Collection<E> collection, @Nullable Object mutex)
/*  915:     */   {
/*  916: 818 */     if ((collection instanceof SortedSet)) {
/*  917: 819 */       return sortedSet((SortedSet)collection, mutex);
/*  918:     */     }
/*  919: 821 */     if ((collection instanceof Set)) {
/*  920: 822 */       return set((Set)collection, mutex);
/*  921:     */     }
/*  922: 824 */     if ((collection instanceof List)) {
/*  923: 825 */       return list((List)collection, mutex);
/*  924:     */     }
/*  925: 827 */     return collection(collection, mutex);
/*  926:     */   }
/*  927:     */   
/*  928:     */   private static <E> Set<E> typePreservingSet(Set<E> set, @Nullable Object mutex)
/*  929:     */   {
/*  930: 832 */     if ((set instanceof SortedSet)) {
/*  931: 833 */       return sortedSet((SortedSet)set, mutex);
/*  932:     */     }
/*  933: 835 */     return set(set, mutex);
/*  934:     */   }
/*  935:     */   
/*  936:     */   private static class SynchronizedAsMapEntries<K, V>
/*  937:     */     extends Synchronized.SynchronizedSet<Map.Entry<K, Collection<V>>>
/*  938:     */   {
/*  939:     */     private static final long serialVersionUID = 0L;
/*  940:     */     
/*  941:     */     SynchronizedAsMapEntries(Set<Map.Entry<K, Collection<V>>> delegate, @Nullable Object mutex)
/*  942:     */     {
/*  943: 843 */       super(mutex);
/*  944:     */     }
/*  945:     */     
/*  946:     */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/*  947:     */     {
/*  948: 848 */       final Iterator<Map.Entry<K, Collection<V>>> iterator = super.iterator();
/*  949: 849 */       new ForwardingIterator()
/*  950:     */       {
/*  951:     */         protected Iterator<Map.Entry<K, Collection<V>>> delegate()
/*  952:     */         {
/*  953: 851 */           return iterator;
/*  954:     */         }
/*  955:     */         
/*  956:     */         public Map.Entry<K, Collection<V>> next()
/*  957:     */         {
/*  958: 855 */           final Map.Entry<K, Collection<V>> entry = (Map.Entry)super.next();
/*  959: 856 */           new ForwardingMapEntry()
/*  960:     */           {
/*  961:     */             protected Map.Entry<K, Collection<V>> delegate()
/*  962:     */             {
/*  963: 858 */               return entry;
/*  964:     */             }
/*  965:     */             
/*  966:     */             public Collection<V> getValue()
/*  967:     */             {
/*  968: 861 */               return Synchronized.typePreservingCollection((Collection)entry.getValue(), Synchronized.SynchronizedAsMapEntries.this.mutex);
/*  969:     */             }
/*  970:     */           };
/*  971:     */         }
/*  972:     */       };
/*  973:     */     }
/*  974:     */     
/*  975:     */     public Object[] toArray()
/*  976:     */     {
/*  977: 871 */       synchronized (this.mutex)
/*  978:     */       {
/*  979: 872 */         return ObjectArrays.toArrayImpl(delegate());
/*  980:     */       }
/*  981:     */     }
/*  982:     */     
/*  983:     */     public <T> T[] toArray(T[] array)
/*  984:     */     {
/*  985: 876 */       synchronized (this.mutex)
/*  986:     */       {
/*  987: 877 */         return ObjectArrays.toArrayImpl(delegate(), array);
/*  988:     */       }
/*  989:     */     }
/*  990:     */     
/*  991:     */     public boolean contains(Object o)
/*  992:     */     {
/*  993: 881 */       synchronized (this.mutex)
/*  994:     */       {
/*  995: 882 */         return Maps.containsEntryImpl(delegate(), o);
/*  996:     */       }
/*  997:     */     }
/*  998:     */     
/*  999:     */     public boolean containsAll(Collection<?> c)
/* 1000:     */     {
/* 1001: 886 */       synchronized (this.mutex)
/* 1002:     */       {
/* 1003: 887 */         return Collections2.containsAllImpl(delegate(), c);
/* 1004:     */       }
/* 1005:     */     }
/* 1006:     */     
/* 1007:     */     public boolean equals(Object o)
/* 1008:     */     {
/* 1009: 891 */       if (o == this) {
/* 1010: 892 */         return true;
/* 1011:     */       }
/* 1012: 894 */       synchronized (this.mutex)
/* 1013:     */       {
/* 1014: 895 */         return Sets.equalsImpl(delegate(), o);
/* 1015:     */       }
/* 1016:     */     }
/* 1017:     */     
/* 1018:     */     public boolean remove(Object o)
/* 1019:     */     {
/* 1020: 899 */       synchronized (this.mutex)
/* 1021:     */       {
/* 1022: 900 */         return Maps.removeEntryImpl(delegate(), o);
/* 1023:     */       }
/* 1024:     */     }
/* 1025:     */     
/* 1026:     */     public boolean removeAll(Collection<?> c)
/* 1027:     */     {
/* 1028: 904 */       synchronized (this.mutex)
/* 1029:     */       {
/* 1030: 905 */         return Iterators.removeAll(delegate().iterator(), c);
/* 1031:     */       }
/* 1032:     */     }
/* 1033:     */     
/* 1034:     */     public boolean retainAll(Collection<?> c)
/* 1035:     */     {
/* 1036: 909 */       synchronized (this.mutex)
/* 1037:     */       {
/* 1038: 910 */         return Iterators.retainAll(delegate().iterator(), c);
/* 1039:     */       }
/* 1040:     */     }
/* 1041:     */   }
/* 1042:     */   
/* 1043:     */   @VisibleForTesting
/* 1044:     */   static <K, V> Map<K, V> map(Map<K, V> map, @Nullable Object mutex)
/* 1045:     */   {
/* 1046: 919 */     return new SynchronizedMap(map, mutex);
/* 1047:     */   }
/* 1048:     */   
/* 1049:     */   private static class SynchronizedMap<K, V>
/* 1050:     */     extends Synchronized.SynchronizedObject
/* 1051:     */     implements Map<K, V>
/* 1052:     */   {
/* 1053:     */     transient Set<K> keySet;
/* 1054:     */     transient Collection<V> values;
/* 1055:     */     transient Set<Map.Entry<K, V>> entrySet;
/* 1056:     */     private static final long serialVersionUID = 0L;
/* 1057:     */     
/* 1058:     */     SynchronizedMap(Map<K, V> delegate, @Nullable Object mutex)
/* 1059:     */     {
/* 1060: 929 */       super(mutex);
/* 1061:     */     }
/* 1062:     */     
/* 1063:     */     Map<K, V> delegate()
/* 1064:     */     {
/* 1065: 934 */       return (Map)super.delegate();
/* 1066:     */     }
/* 1067:     */     
/* 1068:     */     public void clear()
/* 1069:     */     {
/* 1070: 939 */       synchronized (this.mutex)
/* 1071:     */       {
/* 1072: 940 */         delegate().clear();
/* 1073:     */       }
/* 1074:     */     }
/* 1075:     */     
/* 1076:     */     public boolean containsKey(Object key)
/* 1077:     */     {
/* 1078: 946 */       synchronized (this.mutex)
/* 1079:     */       {
/* 1080: 947 */         return delegate().containsKey(key);
/* 1081:     */       }
/* 1082:     */     }
/* 1083:     */     
/* 1084:     */     public boolean containsValue(Object value)
/* 1085:     */     {
/* 1086: 953 */       synchronized (this.mutex)
/* 1087:     */       {
/* 1088: 954 */         return delegate().containsValue(value);
/* 1089:     */       }
/* 1090:     */     }
/* 1091:     */     
/* 1092:     */     public Set<Map.Entry<K, V>> entrySet()
/* 1093:     */     {
/* 1094: 960 */       synchronized (this.mutex)
/* 1095:     */       {
/* 1096: 961 */         if (this.entrySet == null) {
/* 1097: 962 */           this.entrySet = Synchronized.set(delegate().entrySet(), this.mutex);
/* 1098:     */         }
/* 1099: 964 */         return this.entrySet;
/* 1100:     */       }
/* 1101:     */     }
/* 1102:     */     
/* 1103:     */     public V get(Object key)
/* 1104:     */     {
/* 1105: 970 */       synchronized (this.mutex)
/* 1106:     */       {
/* 1107: 971 */         return delegate().get(key);
/* 1108:     */       }
/* 1109:     */     }
/* 1110:     */     
/* 1111:     */     public boolean isEmpty()
/* 1112:     */     {
/* 1113: 977 */       synchronized (this.mutex)
/* 1114:     */       {
/* 1115: 978 */         return delegate().isEmpty();
/* 1116:     */       }
/* 1117:     */     }
/* 1118:     */     
/* 1119:     */     public Set<K> keySet()
/* 1120:     */     {
/* 1121: 984 */       synchronized (this.mutex)
/* 1122:     */       {
/* 1123: 985 */         if (this.keySet == null) {
/* 1124: 986 */           this.keySet = Synchronized.set(delegate().keySet(), this.mutex);
/* 1125:     */         }
/* 1126: 988 */         return this.keySet;
/* 1127:     */       }
/* 1128:     */     }
/* 1129:     */     
/* 1130:     */     public V put(K key, V value)
/* 1131:     */     {
/* 1132: 994 */       synchronized (this.mutex)
/* 1133:     */       {
/* 1134: 995 */         return delegate().put(key, value);
/* 1135:     */       }
/* 1136:     */     }
/* 1137:     */     
/* 1138:     */     public void putAll(Map<? extends K, ? extends V> map)
/* 1139:     */     {
/* 1140:1001 */       synchronized (this.mutex)
/* 1141:     */       {
/* 1142:1002 */         delegate().putAll(map);
/* 1143:     */       }
/* 1144:     */     }
/* 1145:     */     
/* 1146:     */     public V remove(Object key)
/* 1147:     */     {
/* 1148:1008 */       synchronized (this.mutex)
/* 1149:     */       {
/* 1150:1009 */         return delegate().remove(key);
/* 1151:     */       }
/* 1152:     */     }
/* 1153:     */     
/* 1154:     */     public int size()
/* 1155:     */     {
/* 1156:1015 */       synchronized (this.mutex)
/* 1157:     */       {
/* 1158:1016 */         return delegate().size();
/* 1159:     */       }
/* 1160:     */     }
/* 1161:     */     
/* 1162:     */     public Collection<V> values()
/* 1163:     */     {
/* 1164:1022 */       synchronized (this.mutex)
/* 1165:     */       {
/* 1166:1023 */         if (this.values == null) {
/* 1167:1024 */           this.values = Synchronized.collection(delegate().values(), this.mutex);
/* 1168:     */         }
/* 1169:1026 */         return this.values;
/* 1170:     */       }
/* 1171:     */     }
/* 1172:     */     
/* 1173:     */     public boolean equals(Object o)
/* 1174:     */     {
/* 1175:1031 */       if (o == this) {
/* 1176:1032 */         return true;
/* 1177:     */       }
/* 1178:1034 */       synchronized (this.mutex)
/* 1179:     */       {
/* 1180:1035 */         return delegate().equals(o);
/* 1181:     */       }
/* 1182:     */     }
/* 1183:     */     
/* 1184:     */     public int hashCode()
/* 1185:     */     {
/* 1186:1040 */       synchronized (this.mutex)
/* 1187:     */       {
/* 1188:1041 */         return delegate().hashCode();
/* 1189:     */       }
/* 1190:     */     }
/* 1191:     */   }
/* 1192:     */   
/* 1193:     */   static <K, V> SortedMap<K, V> sortedMap(SortedMap<K, V> sortedMap, @Nullable Object mutex)
/* 1194:     */   {
/* 1195:1050 */     return new SynchronizedSortedMap(sortedMap, mutex);
/* 1196:     */   }
/* 1197:     */   
/* 1198:     */   static class SynchronizedSortedMap<K, V>
/* 1199:     */     extends Synchronized.SynchronizedMap<K, V>
/* 1200:     */     implements SortedMap<K, V>
/* 1201:     */   {
/* 1202:     */     private static final long serialVersionUID = 0L;
/* 1203:     */     
/* 1204:     */     SynchronizedSortedMap(SortedMap<K, V> delegate, @Nullable Object mutex)
/* 1205:     */     {
/* 1206:1057 */       super(mutex);
/* 1207:     */     }
/* 1208:     */     
/* 1209:     */     SortedMap<K, V> delegate()
/* 1210:     */     {
/* 1211:1061 */       return (SortedMap)super.delegate();
/* 1212:     */     }
/* 1213:     */     
/* 1214:     */     public Comparator<? super K> comparator()
/* 1215:     */     {
/* 1216:1065 */       synchronized (this.mutex)
/* 1217:     */       {
/* 1218:1066 */         return delegate().comparator();
/* 1219:     */       }
/* 1220:     */     }
/* 1221:     */     
/* 1222:     */     public K firstKey()
/* 1223:     */     {
/* 1224:1071 */       synchronized (this.mutex)
/* 1225:     */       {
/* 1226:1072 */         return delegate().firstKey();
/* 1227:     */       }
/* 1228:     */     }
/* 1229:     */     
/* 1230:     */     public SortedMap<K, V> headMap(K toKey)
/* 1231:     */     {
/* 1232:1077 */       synchronized (this.mutex)
/* 1233:     */       {
/* 1234:1078 */         return Synchronized.sortedMap(delegate().headMap(toKey), this.mutex);
/* 1235:     */       }
/* 1236:     */     }
/* 1237:     */     
/* 1238:     */     public K lastKey()
/* 1239:     */     {
/* 1240:1083 */       synchronized (this.mutex)
/* 1241:     */       {
/* 1242:1084 */         return delegate().lastKey();
/* 1243:     */       }
/* 1244:     */     }
/* 1245:     */     
/* 1246:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1247:     */     {
/* 1248:1089 */       synchronized (this.mutex)
/* 1249:     */       {
/* 1250:1090 */         return Synchronized.sortedMap(delegate().subMap(fromKey, toKey), this.mutex);
/* 1251:     */       }
/* 1252:     */     }
/* 1253:     */     
/* 1254:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1255:     */     {
/* 1256:1095 */       synchronized (this.mutex)
/* 1257:     */       {
/* 1258:1096 */         return Synchronized.sortedMap(delegate().tailMap(fromKey), this.mutex);
/* 1259:     */       }
/* 1260:     */     }
/* 1261:     */   }
/* 1262:     */   
/* 1263:     */   static <K, V> BiMap<K, V> biMap(BiMap<K, V> bimap, @Nullable Object mutex)
/* 1264:     */   {
/* 1265:1104 */     if (((bimap instanceof SynchronizedBiMap)) || ((bimap instanceof ImmutableBiMap))) {
/* 1266:1106 */       return bimap;
/* 1267:     */     }
/* 1268:1108 */     return new SynchronizedBiMap(bimap, mutex, null, null);
/* 1269:     */   }
/* 1270:     */   
/* 1271:     */   @VisibleForTesting
/* 1272:     */   static class SynchronizedBiMap<K, V>
/* 1273:     */     extends Synchronized.SynchronizedMap<K, V>
/* 1274:     */     implements BiMap<K, V>, Serializable
/* 1275:     */   {
/* 1276:     */     private transient Set<V> valueSet;
/* 1277:     */     private transient BiMap<V, K> inverse;
/* 1278:     */     private static final long serialVersionUID = 0L;
/* 1279:     */     
/* 1280:     */     private SynchronizedBiMap(BiMap<K, V> delegate, @Nullable Object mutex, @Nullable BiMap<V, K> inverse)
/* 1281:     */     {
/* 1282:1118 */       super(mutex);
/* 1283:1119 */       this.inverse = inverse;
/* 1284:     */     }
/* 1285:     */     
/* 1286:     */     BiMap<K, V> delegate()
/* 1287:     */     {
/* 1288:1123 */       return (BiMap)super.delegate();
/* 1289:     */     }
/* 1290:     */     
/* 1291:     */     public Set<V> values()
/* 1292:     */     {
/* 1293:1127 */       synchronized (this.mutex)
/* 1294:     */       {
/* 1295:1128 */         if (this.valueSet == null) {
/* 1296:1129 */           this.valueSet = Synchronized.set(delegate().values(), this.mutex);
/* 1297:     */         }
/* 1298:1131 */         return this.valueSet;
/* 1299:     */       }
/* 1300:     */     }
/* 1301:     */     
/* 1302:     */     public V forcePut(K key, V value)
/* 1303:     */     {
/* 1304:1137 */       synchronized (this.mutex)
/* 1305:     */       {
/* 1306:1138 */         return delegate().forcePut(key, value);
/* 1307:     */       }
/* 1308:     */     }
/* 1309:     */     
/* 1310:     */     public BiMap<V, K> inverse()
/* 1311:     */     {
/* 1312:1144 */       synchronized (this.mutex)
/* 1313:     */       {
/* 1314:1145 */         if (this.inverse == null) {
/* 1315:1146 */           this.inverse = new SynchronizedBiMap(delegate().inverse(), this.mutex, this);
/* 1316:     */         }
/* 1317:1149 */         return this.inverse;
/* 1318:     */       }
/* 1319:     */     }
/* 1320:     */   }
/* 1321:     */   
/* 1322:     */   private static class SynchronizedAsMap<K, V>
/* 1323:     */     extends Synchronized.SynchronizedMap<K, Collection<V>>
/* 1324:     */   {
/* 1325:     */     transient Set<Map.Entry<K, Collection<V>>> asMapEntrySet;
/* 1326:     */     transient Collection<Collection<V>> asMapValues;
/* 1327:     */     private static final long serialVersionUID = 0L;
/* 1328:     */     
/* 1329:     */     SynchronizedAsMap(Map<K, Collection<V>> delegate, @Nullable Object mutex)
/* 1330:     */     {
/* 1331:1162 */       super(mutex);
/* 1332:     */     }
/* 1333:     */     
/* 1334:     */     public Collection<V> get(Object key)
/* 1335:     */     {
/* 1336:1166 */       synchronized (this.mutex)
/* 1337:     */       {
/* 1338:1167 */         Collection<V> collection = (Collection)super.get(key);
/* 1339:1168 */         return collection == null ? null : Synchronized.typePreservingCollection(collection, this.mutex);
/* 1340:     */       }
/* 1341:     */     }
/* 1342:     */     
/* 1343:     */     public Set<Map.Entry<K, Collection<V>>> entrySet()
/* 1344:     */     {
/* 1345:1174 */       synchronized (this.mutex)
/* 1346:     */       {
/* 1347:1175 */         if (this.asMapEntrySet == null) {
/* 1348:1176 */           this.asMapEntrySet = new Synchronized.SynchronizedAsMapEntries(delegate().entrySet(), this.mutex);
/* 1349:     */         }
/* 1350:1179 */         return this.asMapEntrySet;
/* 1351:     */       }
/* 1352:     */     }
/* 1353:     */     
/* 1354:     */     public Collection<Collection<V>> values()
/* 1355:     */     {
/* 1356:1184 */       synchronized (this.mutex)
/* 1357:     */       {
/* 1358:1185 */         if (this.asMapValues == null) {
/* 1359:1186 */           this.asMapValues = new Synchronized.SynchronizedAsMapValues(delegate().values(), this.mutex);
/* 1360:     */         }
/* 1361:1189 */         return this.asMapValues;
/* 1362:     */       }
/* 1363:     */     }
/* 1364:     */     
/* 1365:     */     public boolean containsValue(Object o)
/* 1366:     */     {
/* 1367:1195 */       return values().contains(o);
/* 1368:     */     }
/* 1369:     */   }
/* 1370:     */   
/* 1371:     */   private static class SynchronizedAsMapValues<V>
/* 1372:     */     extends Synchronized.SynchronizedCollection<Collection<V>>
/* 1373:     */   {
/* 1374:     */     private static final long serialVersionUID = 0L;
/* 1375:     */     
/* 1376:     */     SynchronizedAsMapValues(Collection<Collection<V>> delegate, @Nullable Object mutex)
/* 1377:     */     {
/* 1378:1205 */       super(mutex, null);
/* 1379:     */     }
/* 1380:     */     
/* 1381:     */     public Iterator<Collection<V>> iterator()
/* 1382:     */     {
/* 1383:1210 */       final Iterator<Collection<V>> iterator = super.iterator();
/* 1384:1211 */       new ForwardingIterator()
/* 1385:     */       {
/* 1386:     */         protected Iterator<Collection<V>> delegate()
/* 1387:     */         {
/* 1388:1213 */           return iterator;
/* 1389:     */         }
/* 1390:     */         
/* 1391:     */         public Collection<V> next()
/* 1392:     */         {
/* 1393:1216 */           return Synchronized.typePreservingCollection((Collection)super.next(), Synchronized.SynchronizedAsMapValues.this.mutex);
/* 1394:     */         }
/* 1395:     */       };
/* 1396:     */     }
/* 1397:     */   }
/* 1398:     */   
/* 1399:     */   @GwtIncompatible("NavigableSet")
/* 1400:     */   @VisibleForTesting
/* 1401:     */   static class SynchronizedNavigableSet<E>
/* 1402:     */     extends Synchronized.SynchronizedSortedSet<E>
/* 1403:     */     implements NavigableSet<E>
/* 1404:     */   {
/* 1405:     */     transient NavigableSet<E> descendingSet;
/* 1406:     */     private static final long serialVersionUID = 0L;
/* 1407:     */     
/* 1408:     */     SynchronizedNavigableSet(NavigableSet<E> delegate, @Nullable Object mutex)
/* 1409:     */     {
/* 1410:1229 */       super(mutex);
/* 1411:     */     }
/* 1412:     */     
/* 1413:     */     NavigableSet<E> delegate()
/* 1414:     */     {
/* 1415:1233 */       return (NavigableSet)super.delegate();
/* 1416:     */     }
/* 1417:     */     
/* 1418:     */     public E ceiling(E e)
/* 1419:     */     {
/* 1420:1237 */       synchronized (this.mutex)
/* 1421:     */       {
/* 1422:1238 */         return delegate().ceiling(e);
/* 1423:     */       }
/* 1424:     */     }
/* 1425:     */     
/* 1426:     */     public Iterator<E> descendingIterator()
/* 1427:     */     {
/* 1428:1243 */       return delegate().descendingIterator();
/* 1429:     */     }
/* 1430:     */     
/* 1431:     */     public NavigableSet<E> descendingSet()
/* 1432:     */     {
/* 1433:1249 */       synchronized (this.mutex)
/* 1434:     */       {
/* 1435:1250 */         if (this.descendingSet == null)
/* 1436:     */         {
/* 1437:1251 */           NavigableSet<E> dS = Synchronized.navigableSet(delegate().descendingSet(), this.mutex);
/* 1438:     */           
/* 1439:1253 */           this.descendingSet = dS;
/* 1440:1254 */           return dS;
/* 1441:     */         }
/* 1442:1256 */         return this.descendingSet;
/* 1443:     */       }
/* 1444:     */     }
/* 1445:     */     
/* 1446:     */     public E floor(E e)
/* 1447:     */     {
/* 1448:1261 */       synchronized (this.mutex)
/* 1449:     */       {
/* 1450:1262 */         return delegate().floor(e);
/* 1451:     */       }
/* 1452:     */     }
/* 1453:     */     
/* 1454:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 1455:     */     {
/* 1456:1267 */       synchronized (this.mutex)
/* 1457:     */       {
/* 1458:1268 */         return Synchronized.navigableSet(delegate().headSet(toElement, inclusive), this.mutex);
/* 1459:     */       }
/* 1460:     */     }
/* 1461:     */     
/* 1462:     */     public E higher(E e)
/* 1463:     */     {
/* 1464:1274 */       synchronized (this.mutex)
/* 1465:     */       {
/* 1466:1275 */         return delegate().higher(e);
/* 1467:     */       }
/* 1468:     */     }
/* 1469:     */     
/* 1470:     */     public E lower(E e)
/* 1471:     */     {
/* 1472:1280 */       synchronized (this.mutex)
/* 1473:     */       {
/* 1474:1281 */         return delegate().lower(e);
/* 1475:     */       }
/* 1476:     */     }
/* 1477:     */     
/* 1478:     */     public E pollFirst()
/* 1479:     */     {
/* 1480:1286 */       synchronized (this.mutex)
/* 1481:     */       {
/* 1482:1287 */         return delegate().pollFirst();
/* 1483:     */       }
/* 1484:     */     }
/* 1485:     */     
/* 1486:     */     public E pollLast()
/* 1487:     */     {
/* 1488:1292 */       synchronized (this.mutex)
/* 1489:     */       {
/* 1490:1293 */         return delegate().pollLast();
/* 1491:     */       }
/* 1492:     */     }
/* 1493:     */     
/* 1494:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 1495:     */     {
/* 1496:1299 */       synchronized (this.mutex)
/* 1497:     */       {
/* 1498:1300 */         return Synchronized.navigableSet(delegate().subSet(fromElement, fromInclusive, toElement, toInclusive), this.mutex);
/* 1499:     */       }
/* 1500:     */     }
/* 1501:     */     
/* 1502:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 1503:     */     {
/* 1504:1306 */       synchronized (this.mutex)
/* 1505:     */       {
/* 1506:1307 */         return Synchronized.navigableSet(delegate().tailSet(fromElement, inclusive), this.mutex);
/* 1507:     */       }
/* 1508:     */     }
/* 1509:     */     
/* 1510:     */     public SortedSet<E> headSet(E toElement)
/* 1511:     */     {
/* 1512:1313 */       return headSet(toElement, false);
/* 1513:     */     }
/* 1514:     */     
/* 1515:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/* 1516:     */     {
/* 1517:1317 */       return subSet(fromElement, true, toElement, false);
/* 1518:     */     }
/* 1519:     */     
/* 1520:     */     public SortedSet<E> tailSet(E fromElement)
/* 1521:     */     {
/* 1522:1321 */       return tailSet(fromElement, true);
/* 1523:     */     }
/* 1524:     */   }
/* 1525:     */   
/* 1526:     */   @GwtIncompatible("NavigableSet")
/* 1527:     */   static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet, @Nullable Object mutex)
/* 1528:     */   {
/* 1529:1330 */     return new SynchronizedNavigableSet(navigableSet, mutex);
/* 1530:     */   }
/* 1531:     */   
/* 1532:     */   @GwtIncompatible("NavigableSet")
/* 1533:     */   static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet)
/* 1534:     */   {
/* 1535:1335 */     return navigableSet(navigableSet, null);
/* 1536:     */   }
/* 1537:     */   
/* 1538:     */   @GwtIncompatible("NavigableMap")
/* 1539:     */   static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap)
/* 1540:     */   {
/* 1541:1341 */     return navigableMap(navigableMap, null);
/* 1542:     */   }
/* 1543:     */   
/* 1544:     */   @GwtIncompatible("NavigableMap")
/* 1545:     */   static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap, @Nullable Object mutex)
/* 1546:     */   {
/* 1547:1347 */     return new SynchronizedNavigableMap(navigableMap, mutex);
/* 1548:     */   }
/* 1549:     */   
/* 1550:     */   @GwtIncompatible("NavigableMap")
/* 1551:     */   @VisibleForTesting
/* 1552:     */   static class SynchronizedNavigableMap<K, V>
/* 1553:     */     extends Synchronized.SynchronizedSortedMap<K, V>
/* 1554:     */     implements NavigableMap<K, V>
/* 1555:     */   {
/* 1556:     */     transient NavigableSet<K> descendingKeySet;
/* 1557:     */     transient NavigableMap<K, V> descendingMap;
/* 1558:     */     transient NavigableSet<K> navigableKeySet;
/* 1559:     */     private static final long serialVersionUID = 0L;
/* 1560:     */     
/* 1561:     */     SynchronizedNavigableMap(NavigableMap<K, V> delegate, @Nullable Object mutex)
/* 1562:     */     {
/* 1563:1356 */       super(mutex);
/* 1564:     */     }
/* 1565:     */     
/* 1566:     */     NavigableMap<K, V> delegate()
/* 1567:     */     {
/* 1568:1360 */       return (NavigableMap)super.delegate();
/* 1569:     */     }
/* 1570:     */     
/* 1571:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 1572:     */     {
/* 1573:1364 */       synchronized (this.mutex)
/* 1574:     */       {
/* 1575:1365 */         return Synchronized.nullableSynchronizedEntry(delegate().ceilingEntry(key), this.mutex);
/* 1576:     */       }
/* 1577:     */     }
/* 1578:     */     
/* 1579:     */     public K ceilingKey(K key)
/* 1580:     */     {
/* 1581:1370 */       synchronized (this.mutex)
/* 1582:     */       {
/* 1583:1371 */         return delegate().ceilingKey(key);
/* 1584:     */       }
/* 1585:     */     }
/* 1586:     */     
/* 1587:     */     public NavigableSet<K> descendingKeySet()
/* 1588:     */     {
/* 1589:1378 */       synchronized (this.mutex)
/* 1590:     */       {
/* 1591:1379 */         if (this.descendingKeySet == null) {
/* 1592:1380 */           return this.descendingKeySet = Synchronized.navigableSet(delegate().descendingKeySet(), this.mutex);
/* 1593:     */         }
/* 1594:1383 */         return this.descendingKeySet;
/* 1595:     */       }
/* 1596:     */     }
/* 1597:     */     
/* 1598:     */     public NavigableMap<K, V> descendingMap()
/* 1599:     */     {
/* 1600:1390 */       synchronized (this.mutex)
/* 1601:     */       {
/* 1602:1391 */         if (this.descendingMap == null) {
/* 1603:1392 */           return this.descendingMap = Synchronized.navigableMap(delegate().descendingMap(), this.mutex);
/* 1604:     */         }
/* 1605:1395 */         return this.descendingMap;
/* 1606:     */       }
/* 1607:     */     }
/* 1608:     */     
/* 1609:     */     public Map.Entry<K, V> firstEntry()
/* 1610:     */     {
/* 1611:1400 */       synchronized (this.mutex)
/* 1612:     */       {
/* 1613:1401 */         return Synchronized.nullableSynchronizedEntry(delegate().firstEntry(), this.mutex);
/* 1614:     */       }
/* 1615:     */     }
/* 1616:     */     
/* 1617:     */     public Map.Entry<K, V> floorEntry(K key)
/* 1618:     */     {
/* 1619:1406 */       synchronized (this.mutex)
/* 1620:     */       {
/* 1621:1407 */         return Synchronized.nullableSynchronizedEntry(delegate().floorEntry(key), this.mutex);
/* 1622:     */       }
/* 1623:     */     }
/* 1624:     */     
/* 1625:     */     public K floorKey(K key)
/* 1626:     */     {
/* 1627:1412 */       synchronized (this.mutex)
/* 1628:     */       {
/* 1629:1413 */         return delegate().floorKey(key);
/* 1630:     */       }
/* 1631:     */     }
/* 1632:     */     
/* 1633:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 1634:     */     {
/* 1635:1418 */       synchronized (this.mutex)
/* 1636:     */       {
/* 1637:1419 */         return Synchronized.navigableMap(delegate().headMap(toKey, inclusive), this.mutex);
/* 1638:     */       }
/* 1639:     */     }
/* 1640:     */     
/* 1641:     */     public Map.Entry<K, V> higherEntry(K key)
/* 1642:     */     {
/* 1643:1425 */       synchronized (this.mutex)
/* 1644:     */       {
/* 1645:1426 */         return Synchronized.nullableSynchronizedEntry(delegate().higherEntry(key), this.mutex);
/* 1646:     */       }
/* 1647:     */     }
/* 1648:     */     
/* 1649:     */     public K higherKey(K key)
/* 1650:     */     {
/* 1651:1431 */       synchronized (this.mutex)
/* 1652:     */       {
/* 1653:1432 */         return delegate().higherKey(key);
/* 1654:     */       }
/* 1655:     */     }
/* 1656:     */     
/* 1657:     */     public Map.Entry<K, V> lastEntry()
/* 1658:     */     {
/* 1659:1437 */       synchronized (this.mutex)
/* 1660:     */       {
/* 1661:1438 */         return Synchronized.nullableSynchronizedEntry(delegate().lastEntry(), this.mutex);
/* 1662:     */       }
/* 1663:     */     }
/* 1664:     */     
/* 1665:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 1666:     */     {
/* 1667:1443 */       synchronized (this.mutex)
/* 1668:     */       {
/* 1669:1444 */         return Synchronized.nullableSynchronizedEntry(delegate().lowerEntry(key), this.mutex);
/* 1670:     */       }
/* 1671:     */     }
/* 1672:     */     
/* 1673:     */     public K lowerKey(K key)
/* 1674:     */     {
/* 1675:1449 */       synchronized (this.mutex)
/* 1676:     */       {
/* 1677:1450 */         return delegate().lowerKey(key);
/* 1678:     */       }
/* 1679:     */     }
/* 1680:     */     
/* 1681:     */     public Set<K> keySet()
/* 1682:     */     {
/* 1683:1455 */       return navigableKeySet();
/* 1684:     */     }
/* 1685:     */     
/* 1686:     */     public NavigableSet<K> navigableKeySet()
/* 1687:     */     {
/* 1688:1461 */       synchronized (this.mutex)
/* 1689:     */       {
/* 1690:1462 */         if (this.navigableKeySet == null) {
/* 1691:1463 */           return this.navigableKeySet = Synchronized.navigableSet(delegate().navigableKeySet(), this.mutex);
/* 1692:     */         }
/* 1693:1466 */         return this.navigableKeySet;
/* 1694:     */       }
/* 1695:     */     }
/* 1696:     */     
/* 1697:     */     public Map.Entry<K, V> pollFirstEntry()
/* 1698:     */     {
/* 1699:1471 */       synchronized (this.mutex)
/* 1700:     */       {
/* 1701:1472 */         return Synchronized.nullableSynchronizedEntry(delegate().pollFirstEntry(), this.mutex);
/* 1702:     */       }
/* 1703:     */     }
/* 1704:     */     
/* 1705:     */     public Map.Entry<K, V> pollLastEntry()
/* 1706:     */     {
/* 1707:1477 */       synchronized (this.mutex)
/* 1708:     */       {
/* 1709:1478 */         return Synchronized.nullableSynchronizedEntry(delegate().pollLastEntry(), this.mutex);
/* 1710:     */       }
/* 1711:     */     }
/* 1712:     */     
/* 1713:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1714:     */     {
/* 1715:1484 */       synchronized (this.mutex)
/* 1716:     */       {
/* 1717:1485 */         return Synchronized.navigableMap(delegate().subMap(fromKey, fromInclusive, toKey, toInclusive), this.mutex);
/* 1718:     */       }
/* 1719:     */     }
/* 1720:     */     
/* 1721:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 1722:     */     {
/* 1723:1492 */       synchronized (this.mutex)
/* 1724:     */       {
/* 1725:1493 */         return Synchronized.navigableMap(delegate().tailMap(fromKey, inclusive), this.mutex);
/* 1726:     */       }
/* 1727:     */     }
/* 1728:     */     
/* 1729:     */     public SortedMap<K, V> headMap(K toKey)
/* 1730:     */     {
/* 1731:1499 */       return headMap(toKey, false);
/* 1732:     */     }
/* 1733:     */     
/* 1734:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1735:     */     {
/* 1736:1503 */       return subMap(fromKey, true, toKey, false);
/* 1737:     */     }
/* 1738:     */     
/* 1739:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1740:     */     {
/* 1741:1507 */       return tailMap(fromKey, true);
/* 1742:     */     }
/* 1743:     */   }
/* 1744:     */   
/* 1745:     */   @GwtIncompatible("works but is needed only for NavigableMap")
/* 1746:     */   private static <K, V> Map.Entry<K, V> nullableSynchronizedEntry(@Nullable Map.Entry<K, V> entry, @Nullable Object mutex)
/* 1747:     */   {
/* 1748:1516 */     if (entry == null) {
/* 1749:1517 */       return null;
/* 1750:     */     }
/* 1751:1519 */     return new SynchronizedEntry(entry, mutex);
/* 1752:     */   }
/* 1753:     */   
/* 1754:     */   @GwtIncompatible("works but is needed only for NavigableMap")
/* 1755:     */   private static class SynchronizedEntry<K, V>
/* 1756:     */     extends Synchronized.SynchronizedObject
/* 1757:     */     implements Map.Entry<K, V>
/* 1758:     */   {
/* 1759:     */     private static final long serialVersionUID = 0L;
/* 1760:     */     
/* 1761:     */     SynchronizedEntry(Map.Entry<K, V> delegate, @Nullable Object mutex)
/* 1762:     */     {
/* 1763:1527 */       super(mutex);
/* 1764:     */     }
/* 1765:     */     
/* 1766:     */     Map.Entry<K, V> delegate()
/* 1767:     */     {
/* 1768:1532 */       return (Map.Entry)super.delegate();
/* 1769:     */     }
/* 1770:     */     
/* 1771:     */     public boolean equals(Object obj)
/* 1772:     */     {
/* 1773:1536 */       synchronized (this.mutex)
/* 1774:     */       {
/* 1775:1537 */         return delegate().equals(obj);
/* 1776:     */       }
/* 1777:     */     }
/* 1778:     */     
/* 1779:     */     public int hashCode()
/* 1780:     */     {
/* 1781:1542 */       synchronized (this.mutex)
/* 1782:     */       {
/* 1783:1543 */         return delegate().hashCode();
/* 1784:     */       }
/* 1785:     */     }
/* 1786:     */     
/* 1787:     */     public K getKey()
/* 1788:     */     {
/* 1789:1548 */       synchronized (this.mutex)
/* 1790:     */       {
/* 1791:1549 */         return delegate().getKey();
/* 1792:     */       }
/* 1793:     */     }
/* 1794:     */     
/* 1795:     */     public V getValue()
/* 1796:     */     {
/* 1797:1554 */       synchronized (this.mutex)
/* 1798:     */       {
/* 1799:1555 */         return delegate().getValue();
/* 1800:     */       }
/* 1801:     */     }
/* 1802:     */     
/* 1803:     */     public V setValue(V value)
/* 1804:     */     {
/* 1805:1560 */       synchronized (this.mutex)
/* 1806:     */       {
/* 1807:1561 */         return delegate().setValue(value);
/* 1808:     */       }
/* 1809:     */     }
/* 1810:     */   }
/* 1811:     */   
/* 1812:     */   static <E> Queue<E> queue(Queue<E> queue, @Nullable Object mutex)
/* 1813:     */   {
/* 1814:1569 */     return (queue instanceof SynchronizedQueue) ? queue : new SynchronizedQueue(queue, mutex);
/* 1815:     */   }
/* 1816:     */   
/* 1817:     */   private static class SynchronizedQueue<E>
/* 1818:     */     extends Synchronized.SynchronizedCollection<E>
/* 1819:     */     implements Queue<E>
/* 1820:     */   {
/* 1821:     */     private static final long serialVersionUID = 0L;
/* 1822:     */     
/* 1823:     */     SynchronizedQueue(Queue<E> delegate, @Nullable Object mutex)
/* 1824:     */     {
/* 1825:1578 */       super(mutex, null);
/* 1826:     */     }
/* 1827:     */     
/* 1828:     */     Queue<E> delegate()
/* 1829:     */     {
/* 1830:1582 */       return (Queue)super.delegate();
/* 1831:     */     }
/* 1832:     */     
/* 1833:     */     public E element()
/* 1834:     */     {
/* 1835:1587 */       synchronized (this.mutex)
/* 1836:     */       {
/* 1837:1588 */         return delegate().element();
/* 1838:     */       }
/* 1839:     */     }
/* 1840:     */     
/* 1841:     */     public boolean offer(E e)
/* 1842:     */     {
/* 1843:1594 */       synchronized (this.mutex)
/* 1844:     */       {
/* 1845:1595 */         return delegate().offer(e);
/* 1846:     */       }
/* 1847:     */     }
/* 1848:     */     
/* 1849:     */     public E peek()
/* 1850:     */     {
/* 1851:1601 */       synchronized (this.mutex)
/* 1852:     */       {
/* 1853:1602 */         return delegate().peek();
/* 1854:     */       }
/* 1855:     */     }
/* 1856:     */     
/* 1857:     */     public E poll()
/* 1858:     */     {
/* 1859:1608 */       synchronized (this.mutex)
/* 1860:     */       {
/* 1861:1609 */         return delegate().poll();
/* 1862:     */       }
/* 1863:     */     }
/* 1864:     */     
/* 1865:     */     public E remove()
/* 1866:     */     {
/* 1867:1615 */       synchronized (this.mutex)
/* 1868:     */       {
/* 1869:1616 */         return delegate().remove();
/* 1870:     */       }
/* 1871:     */     }
/* 1872:     */   }
/* 1873:     */   
/* 1874:     */   @GwtIncompatible("Deque")
/* 1875:     */   static <E> Deque<E> deque(Deque<E> deque, @Nullable Object mutex)
/* 1876:     */   {
/* 1877:1625 */     return new SynchronizedDeque(deque, mutex);
/* 1878:     */   }
/* 1879:     */   
/* 1880:     */   @GwtIncompatible("Deque")
/* 1881:     */   private static final class SynchronizedDeque<E>
/* 1882:     */     extends Synchronized.SynchronizedQueue<E>
/* 1883:     */     implements Deque<E>
/* 1884:     */   {
/* 1885:     */     private static final long serialVersionUID = 0L;
/* 1886:     */     
/* 1887:     */     SynchronizedDeque(Deque<E> delegate, @Nullable Object mutex)
/* 1888:     */     {
/* 1889:1633 */       super(mutex);
/* 1890:     */     }
/* 1891:     */     
/* 1892:     */     Deque<E> delegate()
/* 1893:     */     {
/* 1894:1637 */       return (Deque)super.delegate();
/* 1895:     */     }
/* 1896:     */     
/* 1897:     */     public void addFirst(E e)
/* 1898:     */     {
/* 1899:1642 */       synchronized (this.mutex)
/* 1900:     */       {
/* 1901:1643 */         delegate().addFirst(e);
/* 1902:     */       }
/* 1903:     */     }
/* 1904:     */     
/* 1905:     */     public void addLast(E e)
/* 1906:     */     {
/* 1907:1649 */       synchronized (this.mutex)
/* 1908:     */       {
/* 1909:1650 */         delegate().addLast(e);
/* 1910:     */       }
/* 1911:     */     }
/* 1912:     */     
/* 1913:     */     public boolean offerFirst(E e)
/* 1914:     */     {
/* 1915:1656 */       synchronized (this.mutex)
/* 1916:     */       {
/* 1917:1657 */         return delegate().offerFirst(e);
/* 1918:     */       }
/* 1919:     */     }
/* 1920:     */     
/* 1921:     */     public boolean offerLast(E e)
/* 1922:     */     {
/* 1923:1663 */       synchronized (this.mutex)
/* 1924:     */       {
/* 1925:1664 */         return delegate().offerLast(e);
/* 1926:     */       }
/* 1927:     */     }
/* 1928:     */     
/* 1929:     */     public E removeFirst()
/* 1930:     */     {
/* 1931:1670 */       synchronized (this.mutex)
/* 1932:     */       {
/* 1933:1671 */         return delegate().removeFirst();
/* 1934:     */       }
/* 1935:     */     }
/* 1936:     */     
/* 1937:     */     public E removeLast()
/* 1938:     */     {
/* 1939:1677 */       synchronized (this.mutex)
/* 1940:     */       {
/* 1941:1678 */         return delegate().removeLast();
/* 1942:     */       }
/* 1943:     */     }
/* 1944:     */     
/* 1945:     */     public E pollFirst()
/* 1946:     */     {
/* 1947:1684 */       synchronized (this.mutex)
/* 1948:     */       {
/* 1949:1685 */         return delegate().pollFirst();
/* 1950:     */       }
/* 1951:     */     }
/* 1952:     */     
/* 1953:     */     public E pollLast()
/* 1954:     */     {
/* 1955:1691 */       synchronized (this.mutex)
/* 1956:     */       {
/* 1957:1692 */         return delegate().pollLast();
/* 1958:     */       }
/* 1959:     */     }
/* 1960:     */     
/* 1961:     */     public E getFirst()
/* 1962:     */     {
/* 1963:1698 */       synchronized (this.mutex)
/* 1964:     */       {
/* 1965:1699 */         return delegate().getFirst();
/* 1966:     */       }
/* 1967:     */     }
/* 1968:     */     
/* 1969:     */     public E getLast()
/* 1970:     */     {
/* 1971:1705 */       synchronized (this.mutex)
/* 1972:     */       {
/* 1973:1706 */         return delegate().getLast();
/* 1974:     */       }
/* 1975:     */     }
/* 1976:     */     
/* 1977:     */     public E peekFirst()
/* 1978:     */     {
/* 1979:1712 */       synchronized (this.mutex)
/* 1980:     */       {
/* 1981:1713 */         return delegate().peekFirst();
/* 1982:     */       }
/* 1983:     */     }
/* 1984:     */     
/* 1985:     */     public E peekLast()
/* 1986:     */     {
/* 1987:1719 */       synchronized (this.mutex)
/* 1988:     */       {
/* 1989:1720 */         return delegate().peekLast();
/* 1990:     */       }
/* 1991:     */     }
/* 1992:     */     
/* 1993:     */     public boolean removeFirstOccurrence(Object o)
/* 1994:     */     {
/* 1995:1726 */       synchronized (this.mutex)
/* 1996:     */       {
/* 1997:1727 */         return delegate().removeFirstOccurrence(o);
/* 1998:     */       }
/* 1999:     */     }
/* 2000:     */     
/* 2001:     */     public boolean removeLastOccurrence(Object o)
/* 2002:     */     {
/* 2003:1733 */       synchronized (this.mutex)
/* 2004:     */       {
/* 2005:1734 */         return delegate().removeLastOccurrence(o);
/* 2006:     */       }
/* 2007:     */     }
/* 2008:     */     
/* 2009:     */     public void push(E e)
/* 2010:     */     {
/* 2011:1740 */       synchronized (this.mutex)
/* 2012:     */       {
/* 2013:1741 */         delegate().push(e);
/* 2014:     */       }
/* 2015:     */     }
/* 2016:     */     
/* 2017:     */     public E pop()
/* 2018:     */     {
/* 2019:1747 */       synchronized (this.mutex)
/* 2020:     */       {
/* 2021:1748 */         return delegate().pop();
/* 2022:     */       }
/* 2023:     */     }
/* 2024:     */     
/* 2025:     */     public Iterator<E> descendingIterator()
/* 2026:     */     {
/* 2027:1754 */       synchronized (this.mutex)
/* 2028:     */       {
/* 2029:1755 */         return delegate().descendingIterator();
/* 2030:     */       }
/* 2031:     */     }
/* 2032:     */   }
/* 2033:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Synchronized
 * JD-Core Version:    0.7.0.1
 */
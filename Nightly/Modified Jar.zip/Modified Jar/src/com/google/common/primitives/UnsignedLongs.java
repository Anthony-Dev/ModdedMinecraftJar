/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import java.util.Comparator;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public final class UnsignedLongs
/*  12:    */ {
/*  13:    */   public static final long MAX_VALUE = -1L;
/*  14:    */   
/*  15:    */   private static long flip(long a)
/*  16:    */   {
/*  17: 63 */     return a ^ 0x0;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static int compare(long a, long b)
/*  21:    */   {
/*  22: 76 */     return Longs.compare(flip(a), flip(b));
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static long min(long... array)
/*  26:    */   {
/*  27: 88 */     Preconditions.checkArgument(array.length > 0);
/*  28: 89 */     long min = flip(array[0]);
/*  29: 90 */     for (int i = 1; i < array.length; i++)
/*  30:    */     {
/*  31: 91 */       long next = flip(array[i]);
/*  32: 92 */       if (next < min) {
/*  33: 93 */         min = next;
/*  34:    */       }
/*  35:    */     }
/*  36: 96 */     return flip(min);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static long max(long... array)
/*  40:    */   {
/*  41:108 */     Preconditions.checkArgument(array.length > 0);
/*  42:109 */     long max = flip(array[0]);
/*  43:110 */     for (int i = 1; i < array.length; i++)
/*  44:    */     {
/*  45:111 */       long next = flip(array[i]);
/*  46:112 */       if (next > max) {
/*  47:113 */         max = next;
/*  48:    */       }
/*  49:    */     }
/*  50:116 */     return flip(max);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static String join(String separator, long... array)
/*  54:    */   {
/*  55:128 */     Preconditions.checkNotNull(separator);
/*  56:129 */     if (array.length == 0) {
/*  57:130 */       return "";
/*  58:    */     }
/*  59:134 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  60:135 */     builder.append(toString(array[0]));
/*  61:136 */     for (int i = 1; i < array.length; i++) {
/*  62:137 */       builder.append(separator).append(toString(array[i]));
/*  63:    */     }
/*  64:139 */     return builder.toString();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static Comparator<long[]> lexicographicalComparator()
/*  68:    */   {
/*  69:156 */     return LexicographicalComparator.INSTANCE;
/*  70:    */   }
/*  71:    */   
/*  72:    */   static enum LexicographicalComparator
/*  73:    */     implements Comparator<long[]>
/*  74:    */   {
/*  75:160 */     INSTANCE;
/*  76:    */     
/*  77:    */     private LexicographicalComparator() {}
/*  78:    */     
/*  79:    */     public int compare(long[] left, long[] right)
/*  80:    */     {
/*  81:164 */       int minLength = Math.min(left.length, right.length);
/*  82:165 */       for (int i = 0; i < minLength; i++) {
/*  83:166 */         if (left[i] != right[i]) {
/*  84:167 */           return UnsignedLongs.compare(left[i], right[i]);
/*  85:    */         }
/*  86:    */       }
/*  87:170 */       return left.length - right.length;
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static long divide(long dividend, long divisor)
/*  92:    */   {
/*  93:183 */     if (divisor < 0L)
/*  94:    */     {
/*  95:184 */       if (compare(dividend, divisor) < 0) {
/*  96:185 */         return 0L;
/*  97:    */       }
/*  98:187 */       return 1L;
/*  99:    */     }
/* 100:192 */     if (dividend >= 0L) {
/* 101:193 */       return dividend / divisor;
/* 102:    */     }
/* 103:202 */     long quotient = (dividend >>> 1) / divisor << 1;
/* 104:203 */     long rem = dividend - quotient * divisor;
/* 105:204 */     return quotient + (compare(rem, divisor) >= 0 ? 1 : 0);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static long remainder(long dividend, long divisor)
/* 109:    */   {
/* 110:217 */     if (divisor < 0L)
/* 111:    */     {
/* 112:218 */       if (compare(dividend, divisor) < 0) {
/* 113:219 */         return dividend;
/* 114:    */       }
/* 115:221 */       return dividend - divisor;
/* 116:    */     }
/* 117:226 */     if (dividend >= 0L) {
/* 118:227 */       return dividend % divisor;
/* 119:    */     }
/* 120:236 */     long quotient = (dividend >>> 1) / divisor << 1;
/* 121:237 */     long rem = dividend - quotient * divisor;
/* 122:238 */     return rem - (compare(rem, divisor) >= 0 ? divisor : 0L);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static long parseUnsignedLong(String s)
/* 126:    */   {
/* 127:250 */     return parseUnsignedLong(s, 10);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static long decode(String stringValue)
/* 131:    */   {
/* 132:270 */     ParseRequest request = ParseRequest.fromString(stringValue);
/* 133:    */     try
/* 134:    */     {
/* 135:273 */       return parseUnsignedLong(request.rawValue, request.radix);
/* 136:    */     }
/* 137:    */     catch (NumberFormatException e)
/* 138:    */     {
/* 139:275 */       NumberFormatException decodeException = new NumberFormatException("Error parsing value: " + stringValue);
/* 140:    */       
/* 141:277 */       decodeException.initCause(e);
/* 142:278 */       throw decodeException;
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static long parseUnsignedLong(String s, int radix)
/* 147:    */   {
/* 148:294 */     Preconditions.checkNotNull(s);
/* 149:295 */     if (s.length() == 0) {
/* 150:296 */       throw new NumberFormatException("empty string");
/* 151:    */     }
/* 152:298 */     if ((radix < 2) || (radix > 36)) {
/* 153:299 */       throw new NumberFormatException("illegal radix: " + radix);
/* 154:    */     }
/* 155:302 */     int max_safe_pos = maxSafeDigits[radix] - 1;
/* 156:303 */     long value = 0L;
/* 157:304 */     for (int pos = 0; pos < s.length(); pos++)
/* 158:    */     {
/* 159:305 */       int digit = Character.digit(s.charAt(pos), radix);
/* 160:306 */       if (digit == -1) {
/* 161:307 */         throw new NumberFormatException(s);
/* 162:    */       }
/* 163:309 */       if ((pos > max_safe_pos) && (overflowInParse(value, digit, radix))) {
/* 164:310 */         throw new NumberFormatException("Too large for unsigned long: " + s);
/* 165:    */       }
/* 166:312 */       value = value * radix + digit;
/* 167:    */     }
/* 168:315 */     return value;
/* 169:    */   }
/* 170:    */   
/* 171:    */   private static boolean overflowInParse(long current, int digit, int radix)
/* 172:    */   {
/* 173:325 */     if (current >= 0L)
/* 174:    */     {
/* 175:326 */       if (current < maxValueDivs[radix]) {
/* 176:327 */         return false;
/* 177:    */       }
/* 178:329 */       if (current > maxValueDivs[radix]) {
/* 179:330 */         return true;
/* 180:    */       }
/* 181:333 */       return digit > maxValueMods[radix];
/* 182:    */     }
/* 183:337 */     return true;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static String toString(long x)
/* 187:    */   {
/* 188:344 */     return toString(x, 10);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static String toString(long x, int radix)
/* 192:    */   {
/* 193:357 */     Preconditions.checkArgument((radix >= 2) && (radix <= 36), "radix (%s) must be between Character.MIN_RADIX and Character.MAX_RADIX", new Object[] { Integer.valueOf(radix) });
/* 194:359 */     if (x == 0L) {
/* 195:361 */       return "0";
/* 196:    */     }
/* 197:363 */     char[] buf = new char[64];
/* 198:364 */     int i = buf.length;
/* 199:365 */     if (x < 0L)
/* 200:    */     {
/* 201:368 */       long quotient = divide(x, radix);
/* 202:369 */       long rem = x - quotient * radix;
/* 203:370 */       buf[(--i)] = Character.forDigit((int)rem, radix);
/* 204:371 */       x = quotient;
/* 205:    */     }
/* 206:374 */     while (x > 0L)
/* 207:    */     {
/* 208:375 */       buf[(--i)] = Character.forDigit((int)(x % radix), radix);
/* 209:376 */       x /= radix;
/* 210:    */     }
/* 211:379 */     return new String(buf, i, buf.length - i);
/* 212:    */   }
/* 213:    */   
/* 214:384 */   private static final long[] maxValueDivs = new long[37];
/* 215:385 */   private static final int[] maxValueMods = new int[37];
/* 216:386 */   private static final int[] maxSafeDigits = new int[37];
/* 217:    */   
/* 218:    */   static
/* 219:    */   {
/* 220:388 */     BigInteger overflow = new BigInteger("10000000000000000", 16);
/* 221:389 */     for (int i = 2; i <= 36; i++)
/* 222:    */     {
/* 223:390 */       maxValueDivs[i] = divide(-1L, i);
/* 224:391 */       maxValueMods[i] = ((int)remainder(-1L, i));
/* 225:392 */       maxSafeDigits[i] = (overflow.toString(i).length() - 1);
/* 226:    */     }
/* 227:    */   }
/* 228:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.UnsignedLongs
 * JD-Core Version:    0.7.0.1
 */
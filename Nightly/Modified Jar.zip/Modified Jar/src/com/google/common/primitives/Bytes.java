/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.AbstractList;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.RandomAccess;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ public final class Bytes
/*  14:    */ {
/*  15:    */   public static int hashCode(byte value)
/*  16:    */   {
/*  17: 62 */     return value;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static boolean contains(byte[] array, byte target)
/*  21:    */   {
/*  22: 75 */     for (byte value : array) {
/*  23: 76 */       if (value == target) {
/*  24: 77 */         return true;
/*  25:    */       }
/*  26:    */     }
/*  27: 80 */     return false;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static int indexOf(byte[] array, byte target)
/*  31:    */   {
/*  32: 93 */     return indexOf(array, target, 0, array.length);
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static int indexOf(byte[] array, byte target, int start, int end)
/*  36:    */   {
/*  37: 99 */     for (int i = start; i < end; i++) {
/*  38:100 */       if (array[i] == target) {
/*  39:101 */         return i;
/*  40:    */       }
/*  41:    */     }
/*  42:104 */     return -1;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static int indexOf(byte[] array, byte[] target)
/*  46:    */   {
/*  47:119 */     Preconditions.checkNotNull(array, "array");
/*  48:120 */     Preconditions.checkNotNull(target, "target");
/*  49:121 */     if (target.length == 0) {
/*  50:122 */       return 0;
/*  51:    */     }
/*  52:    */     label64:
/*  53:126 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  54:    */     {
/*  55:127 */       for (int j = 0; j < target.length; j++) {
/*  56:128 */         if (array[(i + j)] != target[j]) {
/*  57:    */           break label64;
/*  58:    */         }
/*  59:    */       }
/*  60:132 */       return i;
/*  61:    */     }
/*  62:134 */     return -1;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static int lastIndexOf(byte[] array, byte target)
/*  66:    */   {
/*  67:147 */     return lastIndexOf(array, target, 0, array.length);
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static int lastIndexOf(byte[] array, byte target, int start, int end)
/*  71:    */   {
/*  72:153 */     for (int i = end - 1; i >= start; i--) {
/*  73:154 */       if (array[i] == target) {
/*  74:155 */         return i;
/*  75:    */       }
/*  76:    */     }
/*  77:158 */     return -1;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static byte[] concat(byte[]... arrays)
/*  81:    */   {
/*  82:171 */     int length = 0;
/*  83:172 */     for (byte[] array : arrays) {
/*  84:173 */       length += array.length;
/*  85:    */     }
/*  86:175 */     byte[] result = new byte[length];
/*  87:176 */     int pos = 0;
/*  88:177 */     for (byte[] array : arrays)
/*  89:    */     {
/*  90:178 */       System.arraycopy(array, 0, result, pos, array.length);
/*  91:179 */       pos += array.length;
/*  92:    */     }
/*  93:181 */     return result;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static byte[] ensureCapacity(byte[] array, int minLength, int padding)
/*  97:    */   {
/*  98:202 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/*  99:203 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 100:204 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static byte[] copyOf(byte[] original, int length)
/* 104:    */   {
/* 105:211 */     byte[] copy = new byte[length];
/* 106:212 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 107:213 */     return copy;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static byte[] toArray(Collection<? extends Number> collection)
/* 111:    */   {
/* 112:232 */     if ((collection instanceof ByteArrayAsList)) {
/* 113:233 */       return ((ByteArrayAsList)collection).toByteArray();
/* 114:    */     }
/* 115:236 */     Object[] boxedArray = collection.toArray();
/* 116:237 */     int len = boxedArray.length;
/* 117:238 */     byte[] array = new byte[len];
/* 118:239 */     for (int i = 0; i < len; i++) {
/* 119:241 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).byteValue();
/* 120:    */     }
/* 121:243 */     return array;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static List<Byte> asList(byte... backingArray)
/* 125:    */   {
/* 126:261 */     if (backingArray.length == 0) {
/* 127:262 */       return Collections.emptyList();
/* 128:    */     }
/* 129:264 */     return new ByteArrayAsList(backingArray);
/* 130:    */   }
/* 131:    */   
/* 132:    */   @GwtCompatible
/* 133:    */   private static class ByteArrayAsList
/* 134:    */     extends AbstractList<Byte>
/* 135:    */     implements RandomAccess, Serializable
/* 136:    */   {
/* 137:    */     final byte[] array;
/* 138:    */     final int start;
/* 139:    */     final int end;
/* 140:    */     private static final long serialVersionUID = 0L;
/* 141:    */     
/* 142:    */     ByteArrayAsList(byte[] array)
/* 143:    */     {
/* 144:275 */       this(array, 0, array.length);
/* 145:    */     }
/* 146:    */     
/* 147:    */     ByteArrayAsList(byte[] array, int start, int end)
/* 148:    */     {
/* 149:279 */       this.array = array;
/* 150:280 */       this.start = start;
/* 151:281 */       this.end = end;
/* 152:    */     }
/* 153:    */     
/* 154:    */     public int size()
/* 155:    */     {
/* 156:285 */       return this.end - this.start;
/* 157:    */     }
/* 158:    */     
/* 159:    */     public boolean isEmpty()
/* 160:    */     {
/* 161:289 */       return false;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public Byte get(int index)
/* 165:    */     {
/* 166:293 */       Preconditions.checkElementIndex(index, size());
/* 167:294 */       return Byte.valueOf(this.array[(this.start + index)]);
/* 168:    */     }
/* 169:    */     
/* 170:    */     public boolean contains(Object target)
/* 171:    */     {
/* 172:299 */       return ((target instanceof Byte)) && (Bytes.indexOf(this.array, ((Byte)target).byteValue(), this.start, this.end) != -1);
/* 173:    */     }
/* 174:    */     
/* 175:    */     public int indexOf(Object target)
/* 176:    */     {
/* 177:305 */       if ((target instanceof Byte))
/* 178:    */       {
/* 179:306 */         int i = Bytes.indexOf(this.array, ((Byte)target).byteValue(), this.start, this.end);
/* 180:307 */         if (i >= 0) {
/* 181:308 */           return i - this.start;
/* 182:    */         }
/* 183:    */       }
/* 184:311 */       return -1;
/* 185:    */     }
/* 186:    */     
/* 187:    */     public int lastIndexOf(Object target)
/* 188:    */     {
/* 189:316 */       if ((target instanceof Byte))
/* 190:    */       {
/* 191:317 */         int i = Bytes.lastIndexOf(this.array, ((Byte)target).byteValue(), this.start, this.end);
/* 192:318 */         if (i >= 0) {
/* 193:319 */           return i - this.start;
/* 194:    */         }
/* 195:    */       }
/* 196:322 */       return -1;
/* 197:    */     }
/* 198:    */     
/* 199:    */     public Byte set(int index, Byte element)
/* 200:    */     {
/* 201:326 */       Preconditions.checkElementIndex(index, size());
/* 202:327 */       byte oldValue = this.array[(this.start + index)];
/* 203:    */       
/* 204:329 */       this.array[(this.start + index)] = ((Byte)Preconditions.checkNotNull(element)).byteValue();
/* 205:330 */       return Byte.valueOf(oldValue);
/* 206:    */     }
/* 207:    */     
/* 208:    */     public List<Byte> subList(int fromIndex, int toIndex)
/* 209:    */     {
/* 210:334 */       int size = size();
/* 211:335 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 212:336 */       if (fromIndex == toIndex) {
/* 213:337 */         return Collections.emptyList();
/* 214:    */       }
/* 215:339 */       return new ByteArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 216:    */     }
/* 217:    */     
/* 218:    */     public boolean equals(Object object)
/* 219:    */     {
/* 220:343 */       if (object == this) {
/* 221:344 */         return true;
/* 222:    */       }
/* 223:346 */       if ((object instanceof ByteArrayAsList))
/* 224:    */       {
/* 225:347 */         ByteArrayAsList that = (ByteArrayAsList)object;
/* 226:348 */         int size = size();
/* 227:349 */         if (that.size() != size) {
/* 228:350 */           return false;
/* 229:    */         }
/* 230:352 */         for (int i = 0; i < size; i++) {
/* 231:353 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 232:354 */             return false;
/* 233:    */           }
/* 234:    */         }
/* 235:357 */         return true;
/* 236:    */       }
/* 237:359 */       return super.equals(object);
/* 238:    */     }
/* 239:    */     
/* 240:    */     public int hashCode()
/* 241:    */     {
/* 242:363 */       int result = 1;
/* 243:364 */       for (int i = this.start; i < this.end; i++) {
/* 244:365 */         result = 31 * result + Bytes.hashCode(this.array[i]);
/* 245:    */       }
/* 246:367 */       return result;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public String toString()
/* 250:    */     {
/* 251:371 */       StringBuilder builder = new StringBuilder(size() * 5);
/* 252:372 */       builder.append('[').append(this.array[this.start]);
/* 253:373 */       for (int i = this.start + 1; i < this.end; i++) {
/* 254:374 */         builder.append(", ").append(this.array[i]);
/* 255:    */       }
/* 256:376 */       return ']';
/* 257:    */     }
/* 258:    */     
/* 259:    */     byte[] toByteArray()
/* 260:    */     {
/* 261:381 */       int size = size();
/* 262:382 */       byte[] result = new byte[size];
/* 263:383 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 264:384 */       return result;
/* 265:    */     }
/* 266:    */   }
/* 267:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Bytes
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ public final class UnsignedLong
/*  12:    */   extends Number
/*  13:    */   implements Comparable<UnsignedLong>, Serializable
/*  14:    */ {
/*  15:    */   private static final long UNSIGNED_MASK = 9223372036854775807L;
/*  16: 47 */   public static final UnsignedLong ZERO = new UnsignedLong(0L);
/*  17: 48 */   public static final UnsignedLong ONE = new UnsignedLong(1L);
/*  18: 49 */   public static final UnsignedLong MAX_VALUE = new UnsignedLong(-1L);
/*  19:    */   private final long value;
/*  20:    */   
/*  21:    */   private UnsignedLong(long value)
/*  22:    */   {
/*  23: 54 */     this.value = value;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static UnsignedLong fromLongBits(long bits)
/*  27:    */   {
/*  28: 72 */     return new UnsignedLong(bits);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static UnsignedLong valueOf(long value)
/*  32:    */   {
/*  33: 82 */     Preconditions.checkArgument(value >= 0L, "value (%s) is outside the range for an unsigned long value", new Object[] { Long.valueOf(value) });
/*  34:    */     
/*  35: 84 */     return fromLongBits(value);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static UnsignedLong valueOf(BigInteger value)
/*  39:    */   {
/*  40: 94 */     Preconditions.checkNotNull(value);
/*  41: 95 */     Preconditions.checkArgument((value.signum() >= 0) && (value.bitLength() <= 64), "value (%s) is outside the range for an unsigned long value", new Object[] { value });
/*  42:    */     
/*  43: 97 */     return fromLongBits(value.longValue());
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static UnsignedLong valueOf(String string)
/*  47:    */   {
/*  48:108 */     return valueOf(string, 10);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static UnsignedLong valueOf(String string, int radix)
/*  52:    */   {
/*  53:120 */     return fromLongBits(UnsignedLongs.parseUnsignedLong(string, radix));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public UnsignedLong plus(UnsignedLong val)
/*  57:    */   {
/*  58:130 */     return fromLongBits(this.value + ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public UnsignedLong minus(UnsignedLong val)
/*  62:    */   {
/*  63:140 */     return fromLongBits(this.value - ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  64:    */   }
/*  65:    */   
/*  66:    */   @CheckReturnValue
/*  67:    */   public UnsignedLong times(UnsignedLong val)
/*  68:    */   {
/*  69:151 */     return fromLongBits(this.value * ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  70:    */   }
/*  71:    */   
/*  72:    */   @CheckReturnValue
/*  73:    */   public UnsignedLong dividedBy(UnsignedLong val)
/*  74:    */   {
/*  75:161 */     return fromLongBits(UnsignedLongs.divide(this.value, ((UnsignedLong)Preconditions.checkNotNull(val)).value));
/*  76:    */   }
/*  77:    */   
/*  78:    */   @CheckReturnValue
/*  79:    */   public UnsignedLong mod(UnsignedLong val)
/*  80:    */   {
/*  81:171 */     return fromLongBits(UnsignedLongs.remainder(this.value, ((UnsignedLong)Preconditions.checkNotNull(val)).value));
/*  82:    */   }
/*  83:    */   
/*  84:    */   public int intValue()
/*  85:    */   {
/*  86:179 */     return (int)this.value;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public long longValue()
/*  90:    */   {
/*  91:191 */     return this.value;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public float floatValue()
/*  95:    */   {
/*  96:201 */     float fValue = (float)(this.value & 0xFFFFFFFF);
/*  97:202 */     if (this.value < 0L) {
/*  98:203 */       fValue += 9.223372E+018F;
/*  99:    */     }
/* 100:205 */     return fValue;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public double doubleValue()
/* 104:    */   {
/* 105:215 */     double dValue = this.value & 0xFFFFFFFF;
/* 106:216 */     if (this.value < 0L) {
/* 107:217 */       dValue += 9.223372036854776E+018D;
/* 108:    */     }
/* 109:219 */     return dValue;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public BigInteger bigIntegerValue()
/* 113:    */   {
/* 114:226 */     BigInteger bigInt = BigInteger.valueOf(this.value & 0xFFFFFFFF);
/* 115:227 */     if (this.value < 0L) {
/* 116:228 */       bigInt = bigInt.setBit(63);
/* 117:    */     }
/* 118:230 */     return bigInt;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int compareTo(UnsignedLong o)
/* 122:    */   {
/* 123:235 */     Preconditions.checkNotNull(o);
/* 124:236 */     return UnsignedLongs.compare(this.value, o.value);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public int hashCode()
/* 128:    */   {
/* 129:241 */     return Longs.hashCode(this.value);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean equals(@Nullable Object obj)
/* 133:    */   {
/* 134:246 */     if ((obj instanceof UnsignedLong))
/* 135:    */     {
/* 136:247 */       UnsignedLong other = (UnsignedLong)obj;
/* 137:248 */       return this.value == other.value;
/* 138:    */     }
/* 139:250 */     return false;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public String toString()
/* 143:    */   {
/* 144:258 */     return UnsignedLongs.toString(this.value);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public String toString(int radix)
/* 148:    */   {
/* 149:267 */     return UnsignedLongs.toString(this.value, radix);
/* 150:    */   }
/* 151:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.UnsignedLong
 * JD-Core Version:    0.7.0.1
 */
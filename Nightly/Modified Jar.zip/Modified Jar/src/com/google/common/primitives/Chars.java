/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.AbstractList;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.RandomAccess;
/*  13:    */ 
/*  14:    */ @GwtCompatible(emulated=true)
/*  15:    */ public final class Chars
/*  16:    */ {
/*  17:    */   public static final int BYTES = 2;
/*  18:    */   
/*  19:    */   public static int hashCode(char value)
/*  20:    */   {
/*  21: 68 */     return value;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static char checkedCast(long value)
/*  25:    */   {
/*  26: 80 */     char result = (char)(int)value;
/*  27: 81 */     if (result != value) {
/*  28: 83 */       throw new IllegalArgumentException("Out of range: " + value);
/*  29:    */     }
/*  30: 85 */     return result;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static char saturatedCast(long value)
/*  34:    */   {
/*  35: 97 */     if (value > 65535L) {
/*  36: 98 */       return 65535;
/*  37:    */     }
/*  38:100 */     if (value < 0L) {
/*  39:101 */       return '\000';
/*  40:    */     }
/*  41:103 */     return (char)(int)value;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static int compare(char a, char b)
/*  45:    */   {
/*  46:119 */     return a - b;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static boolean contains(char[] array, char target)
/*  50:    */   {
/*  51:132 */     for (char value : array) {
/*  52:133 */       if (value == target) {
/*  53:134 */         return true;
/*  54:    */       }
/*  55:    */     }
/*  56:137 */     return false;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static int indexOf(char[] array, char target)
/*  60:    */   {
/*  61:150 */     return indexOf(array, target, 0, array.length);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static int indexOf(char[] array, char target, int start, int end)
/*  65:    */   {
/*  66:156 */     for (int i = start; i < end; i++) {
/*  67:157 */       if (array[i] == target) {
/*  68:158 */         return i;
/*  69:    */       }
/*  70:    */     }
/*  71:161 */     return -1;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static int indexOf(char[] array, char[] target)
/*  75:    */   {
/*  76:176 */     Preconditions.checkNotNull(array, "array");
/*  77:177 */     Preconditions.checkNotNull(target, "target");
/*  78:178 */     if (target.length == 0) {
/*  79:179 */       return 0;
/*  80:    */     }
/*  81:    */     label64:
/*  82:183 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  83:    */     {
/*  84:184 */       for (int j = 0; j < target.length; j++) {
/*  85:185 */         if (array[(i + j)] != target[j]) {
/*  86:    */           break label64;
/*  87:    */         }
/*  88:    */       }
/*  89:189 */       return i;
/*  90:    */     }
/*  91:191 */     return -1;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static int lastIndexOf(char[] array, char target)
/*  95:    */   {
/*  96:204 */     return lastIndexOf(array, target, 0, array.length);
/*  97:    */   }
/*  98:    */   
/*  99:    */   private static int lastIndexOf(char[] array, char target, int start, int end)
/* 100:    */   {
/* 101:210 */     for (int i = end - 1; i >= start; i--) {
/* 102:211 */       if (array[i] == target) {
/* 103:212 */         return i;
/* 104:    */       }
/* 105:    */     }
/* 106:215 */     return -1;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static char min(char... array)
/* 110:    */   {
/* 111:227 */     Preconditions.checkArgument(array.length > 0);
/* 112:228 */     char min = array[0];
/* 113:229 */     for (int i = 1; i < array.length; i++) {
/* 114:230 */       if (array[i] < min) {
/* 115:231 */         min = array[i];
/* 116:    */       }
/* 117:    */     }
/* 118:234 */     return min;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static char max(char... array)
/* 122:    */   {
/* 123:246 */     Preconditions.checkArgument(array.length > 0);
/* 124:247 */     char max = array[0];
/* 125:248 */     for (int i = 1; i < array.length; i++) {
/* 126:249 */       if (array[i] > max) {
/* 127:250 */         max = array[i];
/* 128:    */       }
/* 129:    */     }
/* 130:253 */     return max;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static char[] concat(char[]... arrays)
/* 134:    */   {
/* 135:266 */     int length = 0;
/* 136:267 */     for (char[] array : arrays) {
/* 137:268 */       length += array.length;
/* 138:    */     }
/* 139:270 */     char[] result = new char[length];
/* 140:271 */     int pos = 0;
/* 141:272 */     for (char[] array : arrays)
/* 142:    */     {
/* 143:273 */       System.arraycopy(array, 0, result, pos, array.length);
/* 144:274 */       pos += array.length;
/* 145:    */     }
/* 146:276 */     return result;
/* 147:    */   }
/* 148:    */   
/* 149:    */   @GwtIncompatible("doesn't work")
/* 150:    */   public static byte[] toByteArray(char value)
/* 151:    */   {
/* 152:292 */     return new byte[] { (byte)(value >> '\b'), (byte)value };
/* 153:    */   }
/* 154:    */   
/* 155:    */   @GwtIncompatible("doesn't work")
/* 156:    */   public static char fromByteArray(byte[] bytes)
/* 157:    */   {
/* 158:311 */     Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(2) });
/* 159:    */     
/* 160:313 */     return fromBytes(bytes[0], bytes[1]);
/* 161:    */   }
/* 162:    */   
/* 163:    */   @GwtIncompatible("doesn't work")
/* 164:    */   public static char fromBytes(byte b1, byte b2)
/* 165:    */   {
/* 166:325 */     return (char)(b1 << 8 | b2 & 0xFF);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static char[] ensureCapacity(char[] array, int minLength, int padding)
/* 170:    */   {
/* 171:346 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 172:347 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 173:348 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private static char[] copyOf(char[] original, int length)
/* 177:    */   {
/* 178:355 */     char[] copy = new char[length];
/* 179:356 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 180:357 */     return copy;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static String join(String separator, char... array)
/* 184:    */   {
/* 185:370 */     Preconditions.checkNotNull(separator);
/* 186:371 */     int len = array.length;
/* 187:372 */     if (len == 0) {
/* 188:373 */       return "";
/* 189:    */     }
/* 190:376 */     StringBuilder builder = new StringBuilder(len + separator.length() * (len - 1));
/* 191:    */     
/* 192:378 */     builder.append(array[0]);
/* 193:379 */     for (int i = 1; i < len; i++) {
/* 194:380 */       builder.append(separator).append(array[i]);
/* 195:    */     }
/* 196:382 */     return builder.toString();
/* 197:    */   }
/* 198:    */   
/* 199:    */   public static Comparator<char[]> lexicographicalComparator()
/* 200:    */   {
/* 201:402 */     return LexicographicalComparator.INSTANCE;
/* 202:    */   }
/* 203:    */   
/* 204:    */   private static enum LexicographicalComparator
/* 205:    */     implements Comparator<char[]>
/* 206:    */   {
/* 207:406 */     INSTANCE;
/* 208:    */     
/* 209:    */     private LexicographicalComparator() {}
/* 210:    */     
/* 211:    */     public int compare(char[] left, char[] right)
/* 212:    */     {
/* 213:410 */       int minLength = Math.min(left.length, right.length);
/* 214:411 */       for (int i = 0; i < minLength; i++)
/* 215:    */       {
/* 216:412 */         int result = Chars.compare(left[i], right[i]);
/* 217:413 */         if (result != 0) {
/* 218:414 */           return result;
/* 219:    */         }
/* 220:    */       }
/* 221:417 */       return left.length - right.length;
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static char[] toArray(Collection<Character> collection)
/* 226:    */   {
/* 227:436 */     if ((collection instanceof CharArrayAsList)) {
/* 228:437 */       return ((CharArrayAsList)collection).toCharArray();
/* 229:    */     }
/* 230:440 */     Object[] boxedArray = collection.toArray();
/* 231:441 */     int len = boxedArray.length;
/* 232:442 */     char[] array = new char[len];
/* 233:443 */     for (int i = 0; i < len; i++) {
/* 234:445 */       array[i] = ((Character)Preconditions.checkNotNull(boxedArray[i])).charValue();
/* 235:    */     }
/* 236:447 */     return array;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static List<Character> asList(char... backingArray)
/* 240:    */   {
/* 241:465 */     if (backingArray.length == 0) {
/* 242:466 */       return Collections.emptyList();
/* 243:    */     }
/* 244:468 */     return new CharArrayAsList(backingArray);
/* 245:    */   }
/* 246:    */   
/* 247:    */   @GwtCompatible
/* 248:    */   private static class CharArrayAsList
/* 249:    */     extends AbstractList<Character>
/* 250:    */     implements RandomAccess, Serializable
/* 251:    */   {
/* 252:    */     final char[] array;
/* 253:    */     final int start;
/* 254:    */     final int end;
/* 255:    */     private static final long serialVersionUID = 0L;
/* 256:    */     
/* 257:    */     CharArrayAsList(char[] array)
/* 258:    */     {
/* 259:479 */       this(array, 0, array.length);
/* 260:    */     }
/* 261:    */     
/* 262:    */     CharArrayAsList(char[] array, int start, int end)
/* 263:    */     {
/* 264:483 */       this.array = array;
/* 265:484 */       this.start = start;
/* 266:485 */       this.end = end;
/* 267:    */     }
/* 268:    */     
/* 269:    */     public int size()
/* 270:    */     {
/* 271:489 */       return this.end - this.start;
/* 272:    */     }
/* 273:    */     
/* 274:    */     public boolean isEmpty()
/* 275:    */     {
/* 276:493 */       return false;
/* 277:    */     }
/* 278:    */     
/* 279:    */     public Character get(int index)
/* 280:    */     {
/* 281:497 */       Preconditions.checkElementIndex(index, size());
/* 282:498 */       return Character.valueOf(this.array[(this.start + index)]);
/* 283:    */     }
/* 284:    */     
/* 285:    */     public boolean contains(Object target)
/* 286:    */     {
/* 287:503 */       return ((target instanceof Character)) && (Chars.indexOf(this.array, ((Character)target).charValue(), this.start, this.end) != -1);
/* 288:    */     }
/* 289:    */     
/* 290:    */     public int indexOf(Object target)
/* 291:    */     {
/* 292:509 */       if ((target instanceof Character))
/* 293:    */       {
/* 294:510 */         int i = Chars.indexOf(this.array, ((Character)target).charValue(), this.start, this.end);
/* 295:511 */         if (i >= 0) {
/* 296:512 */           return i - this.start;
/* 297:    */         }
/* 298:    */       }
/* 299:515 */       return -1;
/* 300:    */     }
/* 301:    */     
/* 302:    */     public int lastIndexOf(Object target)
/* 303:    */     {
/* 304:520 */       if ((target instanceof Character))
/* 305:    */       {
/* 306:521 */         int i = Chars.lastIndexOf(this.array, ((Character)target).charValue(), this.start, this.end);
/* 307:522 */         if (i >= 0) {
/* 308:523 */           return i - this.start;
/* 309:    */         }
/* 310:    */       }
/* 311:526 */       return -1;
/* 312:    */     }
/* 313:    */     
/* 314:    */     public Character set(int index, Character element)
/* 315:    */     {
/* 316:530 */       Preconditions.checkElementIndex(index, size());
/* 317:531 */       char oldValue = this.array[(this.start + index)];
/* 318:    */       
/* 319:533 */       this.array[(this.start + index)] = ((Character)Preconditions.checkNotNull(element)).charValue();
/* 320:534 */       return Character.valueOf(oldValue);
/* 321:    */     }
/* 322:    */     
/* 323:    */     public List<Character> subList(int fromIndex, int toIndex)
/* 324:    */     {
/* 325:538 */       int size = size();
/* 326:539 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 327:540 */       if (fromIndex == toIndex) {
/* 328:541 */         return Collections.emptyList();
/* 329:    */       }
/* 330:543 */       return new CharArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 331:    */     }
/* 332:    */     
/* 333:    */     public boolean equals(Object object)
/* 334:    */     {
/* 335:547 */       if (object == this) {
/* 336:548 */         return true;
/* 337:    */       }
/* 338:550 */       if ((object instanceof CharArrayAsList))
/* 339:    */       {
/* 340:551 */         CharArrayAsList that = (CharArrayAsList)object;
/* 341:552 */         int size = size();
/* 342:553 */         if (that.size() != size) {
/* 343:554 */           return false;
/* 344:    */         }
/* 345:556 */         for (int i = 0; i < size; i++) {
/* 346:557 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 347:558 */             return false;
/* 348:    */           }
/* 349:    */         }
/* 350:561 */         return true;
/* 351:    */       }
/* 352:563 */       return super.equals(object);
/* 353:    */     }
/* 354:    */     
/* 355:    */     public int hashCode()
/* 356:    */     {
/* 357:567 */       int result = 1;
/* 358:568 */       for (int i = this.start; i < this.end; i++) {
/* 359:569 */         result = 31 * result + Chars.hashCode(this.array[i]);
/* 360:    */       }
/* 361:571 */       return result;
/* 362:    */     }
/* 363:    */     
/* 364:    */     public String toString()
/* 365:    */     {
/* 366:575 */       StringBuilder builder = new StringBuilder(size() * 3);
/* 367:576 */       builder.append('[').append(this.array[this.start]);
/* 368:577 */       for (int i = this.start + 1; i < this.end; i++) {
/* 369:578 */         builder.append(", ").append(this.array[i]);
/* 370:    */       }
/* 371:580 */       return ']';
/* 372:    */     }
/* 373:    */     
/* 374:    */     char[] toCharArray()
/* 375:    */     {
/* 376:585 */       int size = size();
/* 377:586 */       char[] result = new char[size];
/* 378:587 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 379:588 */       return result;
/* 380:    */     }
/* 381:    */   }
/* 382:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Chars
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.lang.reflect.Field;
/*   7:    */ import java.nio.ByteOrder;
/*   8:    */ import java.security.AccessController;
/*   9:    */ import java.security.PrivilegedActionException;
/*  10:    */ import java.security.PrivilegedExceptionAction;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import sun.misc.Unsafe;
/*  13:    */ 
/*  14:    */ public final class UnsignedBytes
/*  15:    */ {
/*  16:    */   public static final byte MAX_POWER_OF_TWO = -128;
/*  17:    */   public static final byte MAX_VALUE = -1;
/*  18:    */   private static final int UNSIGNED_MASK = 255;
/*  19:    */   
/*  20:    */   public static int toInt(byte value)
/*  21:    */   {
/*  22: 75 */     return value & 0xFF;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static byte checkedCast(long value)
/*  26:    */   {
/*  27: 89 */     if (value >> 8 != 0L) {
/*  28: 91 */       throw new IllegalArgumentException("Out of range: " + value);
/*  29:    */     }
/*  30: 93 */     return (byte)(int)value;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static byte saturatedCast(long value)
/*  34:    */   {
/*  35:105 */     if (value > toInt((byte)-1)) {
/*  36:106 */       return -1;
/*  37:    */     }
/*  38:108 */     if (value < 0L) {
/*  39:109 */       return 0;
/*  40:    */     }
/*  41:111 */     return (byte)(int)value;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static int compare(byte a, byte b)
/*  45:    */   {
/*  46:126 */     return toInt(a) - toInt(b);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static byte min(byte... array)
/*  50:    */   {
/*  51:138 */     Preconditions.checkArgument(array.length > 0);
/*  52:139 */     int min = toInt(array[0]);
/*  53:140 */     for (int i = 1; i < array.length; i++)
/*  54:    */     {
/*  55:141 */       int next = toInt(array[i]);
/*  56:142 */       if (next < min) {
/*  57:143 */         min = next;
/*  58:    */       }
/*  59:    */     }
/*  60:146 */     return (byte)min;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static byte max(byte... array)
/*  64:    */   {
/*  65:158 */     Preconditions.checkArgument(array.length > 0);
/*  66:159 */     int max = toInt(array[0]);
/*  67:160 */     for (int i = 1; i < array.length; i++)
/*  68:    */     {
/*  69:161 */       int next = toInt(array[i]);
/*  70:162 */       if (next > max) {
/*  71:163 */         max = next;
/*  72:    */       }
/*  73:    */     }
/*  74:166 */     return (byte)max;
/*  75:    */   }
/*  76:    */   
/*  77:    */   @Beta
/*  78:    */   public static String toString(byte x)
/*  79:    */   {
/*  80:176 */     return toString(x, 10);
/*  81:    */   }
/*  82:    */   
/*  83:    */   @Beta
/*  84:    */   public static String toString(byte x, int radix)
/*  85:    */   {
/*  86:191 */     Preconditions.checkArgument((radix >= 2) && (radix <= 36), "radix (%s) must be between Character.MIN_RADIX and Character.MAX_RADIX", new Object[] { Integer.valueOf(radix) });
/*  87:    */     
/*  88:    */ 
/*  89:194 */     return Integer.toString(toInt(x), radix);
/*  90:    */   }
/*  91:    */   
/*  92:    */   @Beta
/*  93:    */   public static byte parseUnsignedByte(String string)
/*  94:    */   {
/*  95:208 */     return parseUnsignedByte(string, 10);
/*  96:    */   }
/*  97:    */   
/*  98:    */   @Beta
/*  99:    */   public static byte parseUnsignedByte(String string, int radix)
/* 100:    */   {
/* 101:225 */     int parse = Integer.parseInt((String)Preconditions.checkNotNull(string), radix);
/* 102:227 */     if (parse >> 8 == 0) {
/* 103:228 */       return (byte)parse;
/* 104:    */     }
/* 105:230 */     throw new NumberFormatException("out of range: " + parse);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static String join(String separator, byte... array)
/* 109:    */   {
/* 110:244 */     Preconditions.checkNotNull(separator);
/* 111:245 */     if (array.length == 0) {
/* 112:246 */       return "";
/* 113:    */     }
/* 114:250 */     StringBuilder builder = new StringBuilder(array.length * (3 + separator.length()));
/* 115:251 */     builder.append(toInt(array[0]));
/* 116:252 */     for (int i = 1; i < array.length; i++) {
/* 117:253 */       builder.append(separator).append(toString(array[i]));
/* 118:    */     }
/* 119:255 */     return builder.toString();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static Comparator<byte[]> lexicographicalComparator()
/* 123:    */   {
/* 124:275 */     return LexicographicalComparatorHolder.BEST_COMPARATOR;
/* 125:    */   }
/* 126:    */   
/* 127:    */   @VisibleForTesting
/* 128:    */   static Comparator<byte[]> lexicographicalComparatorJavaImpl()
/* 129:    */   {
/* 130:280 */     return UnsignedBytes.LexicographicalComparatorHolder.PureJavaComparator.INSTANCE;
/* 131:    */   }
/* 132:    */   
/* 133:    */   @VisibleForTesting
/* 134:    */   static class LexicographicalComparatorHolder
/* 135:    */   {
/* 136:292 */     static final String UNSAFE_COMPARATOR_NAME = LexicographicalComparatorHolder.class.getName() + "$UnsafeComparator";
/* 137:295 */     static final Comparator<byte[]> BEST_COMPARATOR = getBestComparator();
/* 138:    */     
/* 139:    */     @VisibleForTesting
/* 140:    */     static enum UnsafeComparator
/* 141:    */       implements Comparator<byte[]>
/* 142:    */     {
/* 143:299 */       INSTANCE;
/* 144:    */       
/* 145:    */       static final boolean BIG_ENDIAN;
/* 146:    */       static final Unsafe theUnsafe;
/* 147:    */       static final int BYTE_ARRAY_BASE_OFFSET;
/* 148:    */       
/* 149:    */       static
/* 150:    */       {
/* 151:301 */         BIG_ENDIAN = ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN);
/* 152:    */         
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:329 */         theUnsafe = getUnsafe();
/* 180:    */         
/* 181:331 */         BYTE_ARRAY_BASE_OFFSET = theUnsafe.arrayBaseOffset([B.class);
/* 182:334 */         if (theUnsafe.arrayIndexScale([B.class) != 1) {
/* 183:335 */           throw new AssertionError();
/* 184:    */         }
/* 185:    */       }
/* 186:    */       
/* 187:    */       private static Unsafe getUnsafe()
/* 188:    */       {
/* 189:    */         try
/* 190:    */         {
/* 191:348 */           return Unsafe.getUnsafe();
/* 192:    */         }
/* 193:    */         catch (SecurityException tryReflectionInstead)
/* 194:    */         {
/* 195:    */           try
/* 196:    */           {
/* 197:351 */             (Unsafe)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 198:    */             {
/* 199:    */               public Unsafe run()
/* 200:    */                 throws Exception
/* 201:    */               {
/* 202:354 */                 Class<Unsafe> k = Unsafe.class;
/* 203:355 */                 for (Field f : k.getDeclaredFields())
/* 204:    */                 {
/* 205:356 */                   f.setAccessible(true);
/* 206:357 */                   Object x = f.get(null);
/* 207:358 */                   if (k.isInstance(x)) {
/* 208:359 */                     return (Unsafe)k.cast(x);
/* 209:    */                   }
/* 210:    */                 }
/* 211:361 */                 throw new NoSuchFieldError("the Unsafe");
/* 212:    */               }
/* 213:    */             });
/* 214:    */           }
/* 215:    */           catch (PrivilegedActionException e)
/* 216:    */           {
/* 217:364 */             throw new RuntimeException("Could not initialize intrinsics", e.getCause());
/* 218:    */           }
/* 219:    */         }
/* 220:    */       }
/* 221:    */       
/* 222:    */       public int compare(byte[] left, byte[] right)
/* 223:    */       {
/* 224:370 */         int minLength = Math.min(left.length, right.length);
/* 225:371 */         int minWords = minLength / 8;
/* 226:378 */         for (int i = 0; i < minWords * 8; i += 8)
/* 227:    */         {
/* 228:379 */           long lw = theUnsafe.getLong(left, BYTE_ARRAY_BASE_OFFSET + i);
/* 229:380 */           long rw = theUnsafe.getLong(right, BYTE_ARRAY_BASE_OFFSET + i);
/* 230:381 */           if (lw != rw)
/* 231:    */           {
/* 232:382 */             if (BIG_ENDIAN) {
/* 233:383 */               return UnsignedLongs.compare(lw, rw);
/* 234:    */             }
/* 235:393 */             int n = Long.numberOfTrailingZeros(lw ^ rw) & 0xFFFFFFF8;
/* 236:394 */             return (int)((lw >>> n & 0xFF) - (rw >>> n & 0xFF));
/* 237:    */           }
/* 238:    */         }
/* 239:399 */         for (int i = minWords * 8; i < minLength; i++)
/* 240:    */         {
/* 241:400 */           int result = UnsignedBytes.compare(left[i], right[i]);
/* 242:401 */           if (result != 0) {
/* 243:402 */             return result;
/* 244:    */           }
/* 245:    */         }
/* 246:405 */         return left.length - right.length;
/* 247:    */       }
/* 248:    */       
/* 249:    */       private UnsafeComparator() {}
/* 250:    */     }
/* 251:    */     
/* 252:    */     static enum PureJavaComparator
/* 253:    */       implements Comparator<byte[]>
/* 254:    */     {
/* 255:410 */       INSTANCE;
/* 256:    */       
/* 257:    */       private PureJavaComparator() {}
/* 258:    */       
/* 259:    */       public int compare(byte[] left, byte[] right)
/* 260:    */       {
/* 261:413 */         int minLength = Math.min(left.length, right.length);
/* 262:414 */         for (int i = 0; i < minLength; i++)
/* 263:    */         {
/* 264:415 */           int result = UnsignedBytes.compare(left[i], right[i]);
/* 265:416 */           if (result != 0) {
/* 266:417 */             return result;
/* 267:    */           }
/* 268:    */         }
/* 269:420 */         return left.length - right.length;
/* 270:    */       }
/* 271:    */     }
/* 272:    */     
/* 273:    */     static Comparator<byte[]> getBestComparator()
/* 274:    */     {
/* 275:    */       try
/* 276:    */       {
/* 277:430 */         Class<?> theClass = Class.forName(UNSAFE_COMPARATOR_NAME);
/* 278:    */         
/* 279:    */ 
/* 280:    */ 
/* 281:434 */         return (Comparator)theClass.getEnumConstants()[0];
/* 282:    */       }
/* 283:    */       catch (Throwable t) {}
/* 284:438 */       return UnsignedBytes.lexicographicalComparatorJavaImpl();
/* 285:    */     }
/* 286:    */   }
/* 287:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.UnsignedBytes
 * JD-Core Version:    0.7.0.1
 */
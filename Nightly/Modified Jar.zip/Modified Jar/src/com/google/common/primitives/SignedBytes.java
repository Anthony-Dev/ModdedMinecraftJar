/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Comparator;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ public final class SignedBytes
/*   9:    */ {
/*  10:    */   public static final byte MAX_POWER_OF_TWO = 64;
/*  11:    */   
/*  12:    */   public static byte checkedCast(long value)
/*  13:    */   {
/*  14: 61 */     byte result = (byte)(int)value;
/*  15: 62 */     if (result != value) {
/*  16: 64 */       throw new IllegalArgumentException("Out of range: " + value);
/*  17:    */     }
/*  18: 66 */     return result;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static byte saturatedCast(long value)
/*  22:    */   {
/*  23: 78 */     if (value > 127L) {
/*  24: 79 */       return 127;
/*  25:    */     }
/*  26: 81 */     if (value < -128L) {
/*  27: 82 */       return -128;
/*  28:    */     }
/*  29: 84 */     return (byte)(int)value;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static int compare(byte a, byte b)
/*  33:    */   {
/*  34:102 */     return a - b;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static byte min(byte... array)
/*  38:    */   {
/*  39:114 */     Preconditions.checkArgument(array.length > 0);
/*  40:115 */     byte min = array[0];
/*  41:116 */     for (int i = 1; i < array.length; i++) {
/*  42:117 */       if (array[i] < min) {
/*  43:118 */         min = array[i];
/*  44:    */       }
/*  45:    */     }
/*  46:121 */     return min;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static byte max(byte... array)
/*  50:    */   {
/*  51:133 */     Preconditions.checkArgument(array.length > 0);
/*  52:134 */     byte max = array[0];
/*  53:135 */     for (int i = 1; i < array.length; i++) {
/*  54:136 */       if (array[i] > max) {
/*  55:137 */         max = array[i];
/*  56:    */       }
/*  57:    */     }
/*  58:140 */     return max;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static String join(String separator, byte... array)
/*  62:    */   {
/*  63:153 */     Preconditions.checkNotNull(separator);
/*  64:154 */     if (array.length == 0) {
/*  65:155 */       return "";
/*  66:    */     }
/*  67:159 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  68:160 */     builder.append(array[0]);
/*  69:161 */     for (int i = 1; i < array.length; i++) {
/*  70:162 */       builder.append(separator).append(array[i]);
/*  71:    */     }
/*  72:164 */     return builder.toString();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static Comparator<byte[]> lexicographicalComparator()
/*  76:    */   {
/*  77:184 */     return LexicographicalComparator.INSTANCE;
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static enum LexicographicalComparator
/*  81:    */     implements Comparator<byte[]>
/*  82:    */   {
/*  83:188 */     INSTANCE;
/*  84:    */     
/*  85:    */     private LexicographicalComparator() {}
/*  86:    */     
/*  87:    */     public int compare(byte[] left, byte[] right)
/*  88:    */     {
/*  89:192 */       int minLength = Math.min(left.length, right.length);
/*  90:193 */       for (int i = 0; i < minLength; i++)
/*  91:    */       {
/*  92:194 */         int result = SignedBytes.compare(left[i], right[i]);
/*  93:195 */         if (result != 0) {
/*  94:196 */           return result;
/*  95:    */         }
/*  96:    */       }
/*  97:199 */       return left.length - right.length;
/*  98:    */     }
/*  99:    */   }
/* 100:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.SignedBytes
 * JD-Core Version:    0.7.0.1
 */
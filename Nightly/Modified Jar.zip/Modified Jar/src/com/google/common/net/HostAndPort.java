/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Strings;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ import javax.annotation.concurrent.Immutable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ @Immutable
/*  14:    */ @GwtCompatible
/*  15:    */ public final class HostAndPort
/*  16:    */   implements Serializable
/*  17:    */ {
/*  18:    */   private static final int NO_PORT = -1;
/*  19:    */   private final String host;
/*  20:    */   private final int port;
/*  21:    */   private final boolean hasBracketlessColons;
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   private HostAndPort(String host, int port, boolean hasBracketlessColons)
/*  25:    */   {
/*  26: 81 */     this.host = host;
/*  27: 82 */     this.port = port;
/*  28: 83 */     this.hasBracketlessColons = hasBracketlessColons;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String getHostText()
/*  32:    */   {
/*  33: 94 */     return this.host;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean hasPort()
/*  37:    */   {
/*  38: 99 */     return this.port >= 0;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int getPort()
/*  42:    */   {
/*  43:110 */     Preconditions.checkState(hasPort());
/*  44:111 */     return this.port;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getPortOrDefault(int defaultPort)
/*  48:    */   {
/*  49:118 */     return hasPort() ? this.port : defaultPort;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static HostAndPort fromParts(String host, int port)
/*  53:    */   {
/*  54:134 */     Preconditions.checkArgument(isValidPort(port), "Port out of range: %s", new Object[] { Integer.valueOf(port) });
/*  55:135 */     HostAndPort parsedHost = fromString(host);
/*  56:136 */     Preconditions.checkArgument(!parsedHost.hasPort(), "Host has a port: %s", new Object[] { host });
/*  57:137 */     return new HostAndPort(parsedHost.host, port, parsedHost.hasBracketlessColons);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static HostAndPort fromHost(String host)
/*  61:    */   {
/*  62:152 */     HostAndPort parsedHost = fromString(host);
/*  63:153 */     Preconditions.checkArgument(!parsedHost.hasPort(), "Host has a port: %s", new Object[] { host });
/*  64:154 */     return parsedHost;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static HostAndPort fromString(String hostPortString)
/*  68:    */   {
/*  69:168 */     Preconditions.checkNotNull(hostPortString);
/*  70:    */     
/*  71:170 */     String portString = null;
/*  72:171 */     boolean hasBracketlessColons = false;
/*  73:    */     String host;
/*  74:173 */     if (hostPortString.startsWith("["))
/*  75:    */     {
/*  76:174 */       String[] hostAndPort = getHostAndPortFromBracketedHost(hostPortString);
/*  77:175 */       String host = hostAndPort[0];
/*  78:176 */       portString = hostAndPort[1];
/*  79:    */     }
/*  80:    */     else
/*  81:    */     {
/*  82:178 */       int colonPos = hostPortString.indexOf(':');
/*  83:179 */       if ((colonPos >= 0) && (hostPortString.indexOf(':', colonPos + 1) == -1))
/*  84:    */       {
/*  85:181 */         String host = hostPortString.substring(0, colonPos);
/*  86:182 */         portString = hostPortString.substring(colonPos + 1);
/*  87:    */       }
/*  88:    */       else
/*  89:    */       {
/*  90:185 */         host = hostPortString;
/*  91:186 */         hasBracketlessColons = colonPos >= 0;
/*  92:    */       }
/*  93:    */     }
/*  94:190 */     int port = -1;
/*  95:191 */     if (!Strings.isNullOrEmpty(portString))
/*  96:    */     {
/*  97:194 */       Preconditions.checkArgument(!portString.startsWith("+"), "Unparseable port number: %s", new Object[] { hostPortString });
/*  98:    */       try
/*  99:    */       {
/* 100:196 */         port = Integer.parseInt(portString);
/* 101:    */       }
/* 102:    */       catch (NumberFormatException e)
/* 103:    */       {
/* 104:198 */         throw new IllegalArgumentException("Unparseable port number: " + hostPortString);
/* 105:    */       }
/* 106:200 */       Preconditions.checkArgument(isValidPort(port), "Port number out of range: %s", new Object[] { hostPortString });
/* 107:    */     }
/* 108:203 */     return new HostAndPort(host, port, hasBracketlessColons);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static String[] getHostAndPortFromBracketedHost(String hostPortString)
/* 112:    */   {
/* 113:214 */     int colonIndex = 0;
/* 114:215 */     int closeBracketIndex = 0;
/* 115:216 */     boolean hasPort = false;
/* 116:217 */     Preconditions.checkArgument(hostPortString.charAt(0) == '[', "Bracketed host-port string must start with a bracket: %s", new Object[] { hostPortString });
/* 117:    */     
/* 118:219 */     colonIndex = hostPortString.indexOf(':');
/* 119:220 */     closeBracketIndex = hostPortString.lastIndexOf(']');
/* 120:221 */     Preconditions.checkArgument((colonIndex > -1) && (closeBracketIndex > colonIndex), "Invalid bracketed host/port: %s", new Object[] { hostPortString });
/* 121:    */     
/* 122:    */ 
/* 123:224 */     String host = hostPortString.substring(1, closeBracketIndex);
/* 124:225 */     if (closeBracketIndex + 1 == hostPortString.length()) {
/* 125:226 */       return new String[] { host, "" };
/* 126:    */     }
/* 127:228 */     Preconditions.checkArgument(hostPortString.charAt(closeBracketIndex + 1) == ':', "Only a colon may follow a close bracket: %s", new Object[] { hostPortString });
/* 128:230 */     for (int i = closeBracketIndex + 2; i < hostPortString.length(); i++) {
/* 129:231 */       Preconditions.checkArgument(Character.isDigit(hostPortString.charAt(i)), "Port must be numeric: %s", new Object[] { hostPortString });
/* 130:    */     }
/* 131:234 */     return new String[] { host, hostPortString.substring(closeBracketIndex + 2) };
/* 132:    */   }
/* 133:    */   
/* 134:    */   public HostAndPort withDefaultPort(int defaultPort)
/* 135:    */   {
/* 136:249 */     Preconditions.checkArgument(isValidPort(defaultPort));
/* 137:250 */     if ((hasPort()) || (this.port == defaultPort)) {
/* 138:251 */       return this;
/* 139:    */     }
/* 140:253 */     return new HostAndPort(this.host, defaultPort, this.hasBracketlessColons);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public HostAndPort requireBracketsForIPv6()
/* 144:    */   {
/* 145:272 */     Preconditions.checkArgument(!this.hasBracketlessColons, "Possible bracketless IPv6 literal: %s", new Object[] { this.host });
/* 146:273 */     return this;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean equals(@Nullable Object other)
/* 150:    */   {
/* 151:278 */     if (this == other) {
/* 152:279 */       return true;
/* 153:    */     }
/* 154:281 */     if ((other instanceof HostAndPort))
/* 155:    */     {
/* 156:282 */       HostAndPort that = (HostAndPort)other;
/* 157:283 */       return (Objects.equal(this.host, that.host)) && (this.port == that.port) && (this.hasBracketlessColons == that.hasBracketlessColons);
/* 158:    */     }
/* 159:287 */     return false;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public int hashCode()
/* 163:    */   {
/* 164:292 */     return Objects.hashCode(new Object[] { this.host, Integer.valueOf(this.port), Boolean.valueOf(this.hasBracketlessColons) });
/* 165:    */   }
/* 166:    */   
/* 167:    */   public String toString()
/* 168:    */   {
/* 169:299 */     StringBuilder builder = new StringBuilder(this.host.length() + 8);
/* 170:300 */     if (this.host.indexOf(':') >= 0) {
/* 171:301 */       builder.append('[').append(this.host).append(']');
/* 172:    */     } else {
/* 173:303 */       builder.append(this.host);
/* 174:    */     }
/* 175:305 */     if (hasPort()) {
/* 176:306 */       builder.append(':').append(this.port);
/* 177:    */     }
/* 178:308 */     return builder.toString();
/* 179:    */   }
/* 180:    */   
/* 181:    */   private static boolean isValidPort(int port)
/* 182:    */   {
/* 183:313 */     return (port >= 0) && (port <= 65535);
/* 184:    */   }
/* 185:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.net.HostAndPort
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.CharMatcher;
/*   7:    */ import com.google.common.base.Charsets;
/*   8:    */ import com.google.common.base.Function;
/*   9:    */ import com.google.common.base.Joiner;
/*  10:    */ import com.google.common.base.Joiner.MapJoiner;
/*  11:    */ import com.google.common.base.Objects;
/*  12:    */ import com.google.common.base.Optional;
/*  13:    */ import com.google.common.base.Preconditions;
/*  14:    */ import com.google.common.collect.ImmutableCollection;
/*  15:    */ import com.google.common.collect.ImmutableListMultimap;
/*  16:    */ import com.google.common.collect.ImmutableListMultimap.Builder;
/*  17:    */ import com.google.common.collect.ImmutableMultiset;
/*  18:    */ import com.google.common.collect.ImmutableSet;
/*  19:    */ import com.google.common.collect.Iterables;
/*  20:    */ import com.google.common.collect.Maps;
/*  21:    */ import com.google.common.collect.Multimap;
/*  22:    */ import com.google.common.collect.Multimaps;
/*  23:    */ import java.nio.charset.Charset;
/*  24:    */ import java.util.Collection;
/*  25:    */ import java.util.Map;
/*  26:    */ import java.util.Map.Entry;
/*  27:    */ import javax.annotation.Nullable;
/*  28:    */ import javax.annotation.concurrent.Immutable;
/*  29:    */ 
/*  30:    */ @Beta
/*  31:    */ @GwtCompatible
/*  32:    */ @Immutable
/*  33:    */ public final class MediaType
/*  34:    */ {
/*  35:    */   private static final String CHARSET_ATTRIBUTE = "charset";
/*  36: 84 */   private static final ImmutableListMultimap<String, String> UTF_8_CONSTANT_PARAMETERS = ImmutableListMultimap.of("charset", Ascii.toLowerCase(Charsets.UTF_8.name()));
/*  37: 88 */   private static final CharMatcher TOKEN_MATCHER = CharMatcher.ASCII.and(CharMatcher.JAVA_ISO_CONTROL.negate()).and(CharMatcher.isNot(' ')).and(CharMatcher.noneOf("()<>@,;:\\\"/[]?="));
/*  38: 91 */   private static final CharMatcher QUOTED_TEXT_MATCHER = CharMatcher.ASCII.and(CharMatcher.noneOf("\"\\\r"));
/*  39: 97 */   private static final CharMatcher LINEAR_WHITE_SPACE = CharMatcher.anyOf(" \t\r\n");
/*  40:    */   private static final String APPLICATION_TYPE = "application";
/*  41:    */   private static final String AUDIO_TYPE = "audio";
/*  42:    */   private static final String IMAGE_TYPE = "image";
/*  43:    */   private static final String TEXT_TYPE = "text";
/*  44:    */   private static final String VIDEO_TYPE = "video";
/*  45:    */   private static final String WILDCARD = "*";
/*  46:108 */   private static final Map<MediaType, MediaType> KNOWN_TYPES = Maps.newHashMap();
/*  47:    */   
/*  48:    */   private static MediaType createConstant(String type, String subtype)
/*  49:    */   {
/*  50:111 */     return addKnownType(new MediaType(type, subtype, ImmutableListMultimap.of()));
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static MediaType createConstantUtf8(String type, String subtype)
/*  54:    */   {
/*  55:115 */     return addKnownType(new MediaType(type, subtype, UTF_8_CONSTANT_PARAMETERS));
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static MediaType addKnownType(MediaType mediaType)
/*  59:    */   {
/*  60:119 */     KNOWN_TYPES.put(mediaType, mediaType);
/*  61:120 */     return mediaType;
/*  62:    */   }
/*  63:    */   
/*  64:133 */   public static final MediaType ANY_TYPE = createConstant("*", "*");
/*  65:134 */   public static final MediaType ANY_TEXT_TYPE = createConstant("text", "*");
/*  66:135 */   public static final MediaType ANY_IMAGE_TYPE = createConstant("image", "*");
/*  67:136 */   public static final MediaType ANY_AUDIO_TYPE = createConstant("audio", "*");
/*  68:137 */   public static final MediaType ANY_VIDEO_TYPE = createConstant("video", "*");
/*  69:138 */   public static final MediaType ANY_APPLICATION_TYPE = createConstant("application", "*");
/*  70:141 */   public static final MediaType CACHE_MANIFEST_UTF_8 = createConstantUtf8("text", "cache-manifest");
/*  71:143 */   public static final MediaType CSS_UTF_8 = createConstantUtf8("text", "css");
/*  72:144 */   public static final MediaType CSV_UTF_8 = createConstantUtf8("text", "csv");
/*  73:145 */   public static final MediaType HTML_UTF_8 = createConstantUtf8("text", "html");
/*  74:146 */   public static final MediaType I_CALENDAR_UTF_8 = createConstantUtf8("text", "calendar");
/*  75:147 */   public static final MediaType PLAIN_TEXT_UTF_8 = createConstantUtf8("text", "plain");
/*  76:153 */   public static final MediaType TEXT_JAVASCRIPT_UTF_8 = createConstantUtf8("text", "javascript");
/*  77:160 */   public static final MediaType TSV_UTF_8 = createConstantUtf8("text", "tab-separated-values");
/*  78:161 */   public static final MediaType VCARD_UTF_8 = createConstantUtf8("text", "vcard");
/*  79:162 */   public static final MediaType WML_UTF_8 = createConstantUtf8("text", "vnd.wap.wml");
/*  80:168 */   public static final MediaType XML_UTF_8 = createConstantUtf8("text", "xml");
/*  81:171 */   public static final MediaType BMP = createConstant("image", "bmp");
/*  82:181 */   public static final MediaType CRW = createConstant("image", "x-canon-crw");
/*  83:182 */   public static final MediaType GIF = createConstant("image", "gif");
/*  84:183 */   public static final MediaType ICO = createConstant("image", "vnd.microsoft.icon");
/*  85:184 */   public static final MediaType JPEG = createConstant("image", "jpeg");
/*  86:185 */   public static final MediaType PNG = createConstant("image", "png");
/*  87:202 */   public static final MediaType PSD = createConstant("image", "vnd.adobe.photoshop");
/*  88:203 */   public static final MediaType SVG_UTF_8 = createConstantUtf8("image", "svg+xml");
/*  89:204 */   public static final MediaType TIFF = createConstant("image", "tiff");
/*  90:205 */   public static final MediaType WEBP = createConstant("image", "webp");
/*  91:208 */   public static final MediaType MP4_AUDIO = createConstant("audio", "mp4");
/*  92:209 */   public static final MediaType MPEG_AUDIO = createConstant("audio", "mpeg");
/*  93:210 */   public static final MediaType OGG_AUDIO = createConstant("audio", "ogg");
/*  94:211 */   public static final MediaType WEBM_AUDIO = createConstant("audio", "webm");
/*  95:214 */   public static final MediaType MP4_VIDEO = createConstant("video", "mp4");
/*  96:215 */   public static final MediaType MPEG_VIDEO = createConstant("video", "mpeg");
/*  97:216 */   public static final MediaType OGG_VIDEO = createConstant("video", "ogg");
/*  98:217 */   public static final MediaType QUICKTIME = createConstant("video", "quicktime");
/*  99:218 */   public static final MediaType WEBM_VIDEO = createConstant("video", "webm");
/* 100:219 */   public static final MediaType WMV = createConstant("video", "x-ms-wmv");
/* 101:227 */   public static final MediaType APPLICATION_XML_UTF_8 = createConstantUtf8("application", "xml");
/* 102:228 */   public static final MediaType ATOM_UTF_8 = createConstantUtf8("application", "atom+xml");
/* 103:229 */   public static final MediaType BZIP2 = createConstant("application", "x-bzip2");
/* 104:238 */   public static final MediaType EOT = createConstant("application", "vnd.ms-fontobject");
/* 105:248 */   public static final MediaType EPUB = createConstant("application", "epub+zip");
/* 106:249 */   public static final MediaType FORM_DATA = createConstant("application", "x-www-form-urlencoded");
/* 107:258 */   public static final MediaType KEY_ARCHIVE = createConstant("application", "pkcs12");
/* 108:270 */   public static final MediaType APPLICATION_BINARY = createConstant("application", "binary");
/* 109:271 */   public static final MediaType GZIP = createConstant("application", "x-gzip");
/* 110:277 */   public static final MediaType JAVASCRIPT_UTF_8 = createConstantUtf8("application", "javascript");
/* 111:279 */   public static final MediaType JSON_UTF_8 = createConstantUtf8("application", "json");
/* 112:280 */   public static final MediaType KML = createConstant("application", "vnd.google-earth.kml+xml");
/* 113:281 */   public static final MediaType KMZ = createConstant("application", "vnd.google-earth.kmz");
/* 114:282 */   public static final MediaType MBOX = createConstant("application", "mbox");
/* 115:283 */   public static final MediaType MICROSOFT_EXCEL = createConstant("application", "vnd.ms-excel");
/* 116:284 */   public static final MediaType MICROSOFT_POWERPOINT = createConstant("application", "vnd.ms-powerpoint");
/* 117:286 */   public static final MediaType MICROSOFT_WORD = createConstant("application", "msword");
/* 118:287 */   public static final MediaType OCTET_STREAM = createConstant("application", "octet-stream");
/* 119:288 */   public static final MediaType OGG_CONTAINER = createConstant("application", "ogg");
/* 120:289 */   public static final MediaType OOXML_DOCUMENT = createConstant("application", "vnd.openxmlformats-officedocument.wordprocessingml.document");
/* 121:291 */   public static final MediaType OOXML_PRESENTATION = createConstant("application", "vnd.openxmlformats-officedocument.presentationml.presentation");
/* 122:293 */   public static final MediaType OOXML_SHEET = createConstant("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet");
/* 123:295 */   public static final MediaType OPENDOCUMENT_GRAPHICS = createConstant("application", "vnd.oasis.opendocument.graphics");
/* 124:297 */   public static final MediaType OPENDOCUMENT_PRESENTATION = createConstant("application", "vnd.oasis.opendocument.presentation");
/* 125:299 */   public static final MediaType OPENDOCUMENT_SPREADSHEET = createConstant("application", "vnd.oasis.opendocument.spreadsheet");
/* 126:301 */   public static final MediaType OPENDOCUMENT_TEXT = createConstant("application", "vnd.oasis.opendocument.text");
/* 127:303 */   public static final MediaType PDF = createConstant("application", "pdf");
/* 128:304 */   public static final MediaType POSTSCRIPT = createConstant("application", "postscript");
/* 129:310 */   public static final MediaType PROTOBUF = createConstant("application", "protobuf");
/* 130:311 */   public static final MediaType RDF_XML_UTF_8 = createConstantUtf8("application", "rdf+xml");
/* 131:312 */   public static final MediaType RTF_UTF_8 = createConstantUtf8("application", "rtf");
/* 132:322 */   public static final MediaType SFNT = createConstant("application", "font-sfnt");
/* 133:323 */   public static final MediaType SHOCKWAVE_FLASH = createConstant("application", "x-shockwave-flash");
/* 134:325 */   public static final MediaType SKETCHUP = createConstant("application", "vnd.sketchup.skp");
/* 135:326 */   public static final MediaType TAR = createConstant("application", "x-tar");
/* 136:336 */   public static final MediaType WOFF = createConstant("application", "font-woff");
/* 137:337 */   public static final MediaType XHTML_UTF_8 = createConstantUtf8("application", "xhtml+xml");
/* 138:345 */   public static final MediaType XRD_UTF_8 = createConstantUtf8("application", "xrd+xml");
/* 139:346 */   public static final MediaType ZIP = createConstant("application", "zip");
/* 140:    */   private final String type;
/* 141:    */   private final String subtype;
/* 142:    */   private final ImmutableListMultimap<String, String> parameters;
/* 143:    */   
/* 144:    */   private MediaType(String type, String subtype, ImmutableListMultimap<String, String> parameters)
/* 145:    */   {
/* 146:354 */     this.type = type;
/* 147:355 */     this.subtype = subtype;
/* 148:356 */     this.parameters = parameters;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public String type()
/* 152:    */   {
/* 153:361 */     return this.type;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public String subtype()
/* 157:    */   {
/* 158:366 */     return this.subtype;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public ImmutableListMultimap<String, String> parameters()
/* 162:    */   {
/* 163:371 */     return this.parameters;
/* 164:    */   }
/* 165:    */   
/* 166:    */   private Map<String, ImmutableMultiset<String>> parametersAsMap()
/* 167:    */   {
/* 168:375 */     Maps.transformValues(this.parameters.asMap(), new Function()
/* 169:    */     {
/* 170:    */       public ImmutableMultiset<String> apply(Collection<String> input)
/* 171:    */       {
/* 172:378 */         return ImmutableMultiset.copyOf(input);
/* 173:    */       }
/* 174:    */     });
/* 175:    */   }
/* 176:    */   
/* 177:    */   public Optional<Charset> charset()
/* 178:    */   {
/* 179:392 */     ImmutableSet<String> charsetValues = ImmutableSet.copyOf(this.parameters.get("charset"));
/* 180:393 */     switch (charsetValues.size())
/* 181:    */     {
/* 182:    */     case 0: 
/* 183:395 */       return Optional.absent();
/* 184:    */     case 1: 
/* 185:397 */       return Optional.of(Charset.forName((String)Iterables.getOnlyElement(charsetValues)));
/* 186:    */     }
/* 187:399 */     throw new IllegalStateException("Multiple charset values defined: " + charsetValues);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public MediaType withoutParameters()
/* 191:    */   {
/* 192:408 */     return this.parameters.isEmpty() ? this : create(this.type, this.subtype);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public MediaType withParameters(Multimap<String, String> parameters)
/* 196:    */   {
/* 197:417 */     return create(this.type, this.subtype, parameters);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public MediaType withParameter(String attribute, String value)
/* 201:    */   {
/* 202:429 */     Preconditions.checkNotNull(attribute);
/* 203:430 */     Preconditions.checkNotNull(value);
/* 204:431 */     String normalizedAttribute = normalizeToken(attribute);
/* 205:432 */     ImmutableListMultimap.Builder<String, String> builder = ImmutableListMultimap.builder();
/* 206:433 */     for (Map.Entry<String, String> entry : this.parameters.entries())
/* 207:    */     {
/* 208:434 */       String key = (String)entry.getKey();
/* 209:435 */       if (!normalizedAttribute.equals(key)) {
/* 210:436 */         builder.put(key, entry.getValue());
/* 211:    */       }
/* 212:    */     }
/* 213:439 */     builder.put(normalizedAttribute, normalizeParameterValue(normalizedAttribute, value));
/* 214:440 */     MediaType mediaType = new MediaType(this.type, this.subtype, builder.build());
/* 215:    */     
/* 216:442 */     return (MediaType)Objects.firstNonNull(KNOWN_TYPES.get(mediaType), mediaType);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public MediaType withCharset(Charset charset)
/* 220:    */   {
/* 221:455 */     Preconditions.checkNotNull(charset);
/* 222:456 */     return withParameter("charset", charset.name());
/* 223:    */   }
/* 224:    */   
/* 225:    */   public boolean hasWildcard()
/* 226:    */   {
/* 227:461 */     return ("*".equals(this.type)) || ("*".equals(this.subtype));
/* 228:    */   }
/* 229:    */   
/* 230:    */   public boolean is(MediaType mediaTypeRange)
/* 231:    */   {
/* 232:491 */     return ((mediaTypeRange.type.equals("*")) || (mediaTypeRange.type.equals(this.type))) && ((mediaTypeRange.subtype.equals("*")) || (mediaTypeRange.subtype.equals(this.subtype))) && (this.parameters.entries().containsAll(mediaTypeRange.parameters.entries()));
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static MediaType create(String type, String subtype)
/* 236:    */   {
/* 237:503 */     return create(type, subtype, ImmutableListMultimap.of());
/* 238:    */   }
/* 239:    */   
/* 240:    */   static MediaType createApplicationType(String subtype)
/* 241:    */   {
/* 242:512 */     return create("application", subtype);
/* 243:    */   }
/* 244:    */   
/* 245:    */   static MediaType createAudioType(String subtype)
/* 246:    */   {
/* 247:521 */     return create("audio", subtype);
/* 248:    */   }
/* 249:    */   
/* 250:    */   static MediaType createImageType(String subtype)
/* 251:    */   {
/* 252:530 */     return create("image", subtype);
/* 253:    */   }
/* 254:    */   
/* 255:    */   static MediaType createTextType(String subtype)
/* 256:    */   {
/* 257:539 */     return create("text", subtype);
/* 258:    */   }
/* 259:    */   
/* 260:    */   static MediaType createVideoType(String subtype)
/* 261:    */   {
/* 262:548 */     return create("video", subtype);
/* 263:    */   }
/* 264:    */   
/* 265:    */   private static MediaType create(String type, String subtype, Multimap<String, String> parameters)
/* 266:    */   {
/* 267:553 */     Preconditions.checkNotNull(type);
/* 268:554 */     Preconditions.checkNotNull(subtype);
/* 269:555 */     Preconditions.checkNotNull(parameters);
/* 270:556 */     String normalizedType = normalizeToken(type);
/* 271:557 */     String normalizedSubtype = normalizeToken(subtype);
/* 272:558 */     Preconditions.checkArgument((!"*".equals(normalizedType)) || ("*".equals(normalizedSubtype)), "A wildcard type cannot be used with a non-wildcard subtype");
/* 273:    */     
/* 274:560 */     ImmutableListMultimap.Builder<String, String> builder = ImmutableListMultimap.builder();
/* 275:561 */     for (Map.Entry<String, String> entry : parameters.entries())
/* 276:    */     {
/* 277:562 */       String attribute = normalizeToken((String)entry.getKey());
/* 278:563 */       builder.put(attribute, normalizeParameterValue(attribute, (String)entry.getValue()));
/* 279:    */     }
/* 280:565 */     MediaType mediaType = new MediaType(normalizedType, normalizedSubtype, builder.build());
/* 281:    */     
/* 282:567 */     return (MediaType)Objects.firstNonNull(KNOWN_TYPES.get(mediaType), mediaType);
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static String normalizeToken(String token)
/* 286:    */   {
/* 287:571 */     Preconditions.checkArgument(TOKEN_MATCHER.matchesAllOf(token));
/* 288:572 */     return Ascii.toLowerCase(token);
/* 289:    */   }
/* 290:    */   
/* 291:    */   private static String normalizeParameterValue(String attribute, String value)
/* 292:    */   {
/* 293:576 */     return "charset".equals(attribute) ? Ascii.toLowerCase(value) : value;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public static MediaType parse(String input)
/* 297:    */   {
/* 298:585 */     Preconditions.checkNotNull(input);
/* 299:586 */     Tokenizer tokenizer = new Tokenizer(input);
/* 300:    */     try
/* 301:    */     {
/* 302:588 */       String type = tokenizer.consumeToken(TOKEN_MATCHER);
/* 303:589 */       tokenizer.consumeCharacter('/');
/* 304:590 */       String subtype = tokenizer.consumeToken(TOKEN_MATCHER);
/* 305:591 */       ImmutableListMultimap.Builder<String, String> parameters = ImmutableListMultimap.builder();
/* 306:592 */       while (tokenizer.hasMore())
/* 307:    */       {
/* 308:593 */         tokenizer.consumeCharacter(';');
/* 309:594 */         tokenizer.consumeTokenIfPresent(LINEAR_WHITE_SPACE);
/* 310:595 */         String attribute = tokenizer.consumeToken(TOKEN_MATCHER);
/* 311:596 */         tokenizer.consumeCharacter('=');
/* 312:    */         String value;
/* 313:598 */         if ('"' == tokenizer.previewChar())
/* 314:    */         {
/* 315:599 */           tokenizer.consumeCharacter('"');
/* 316:600 */           StringBuilder valueBuilder = new StringBuilder();
/* 317:601 */           while ('"' != tokenizer.previewChar()) {
/* 318:602 */             if ('\\' == tokenizer.previewChar())
/* 319:    */             {
/* 320:603 */               tokenizer.consumeCharacter('\\');
/* 321:604 */               valueBuilder.append(tokenizer.consumeCharacter(CharMatcher.ASCII));
/* 322:    */             }
/* 323:    */             else
/* 324:    */             {
/* 325:606 */               valueBuilder.append(tokenizer.consumeToken(QUOTED_TEXT_MATCHER));
/* 326:    */             }
/* 327:    */           }
/* 328:609 */           String value = valueBuilder.toString();
/* 329:610 */           tokenizer.consumeCharacter('"');
/* 330:    */         }
/* 331:    */         else
/* 332:    */         {
/* 333:612 */           value = tokenizer.consumeToken(TOKEN_MATCHER);
/* 334:    */         }
/* 335:614 */         parameters.put(attribute, value);
/* 336:    */       }
/* 337:616 */       return create(type, subtype, parameters.build());
/* 338:    */     }
/* 339:    */     catch (IllegalStateException e)
/* 340:    */     {
/* 341:618 */       throw new IllegalArgumentException("Could not parse '" + input + "'", e);
/* 342:    */     }
/* 343:    */   }
/* 344:    */   
/* 345:    */   private static final class Tokenizer
/* 346:    */   {
/* 347:    */     final String input;
/* 348:624 */     int position = 0;
/* 349:    */     
/* 350:    */     Tokenizer(String input)
/* 351:    */     {
/* 352:627 */       this.input = input;
/* 353:    */     }
/* 354:    */     
/* 355:    */     String consumeTokenIfPresent(CharMatcher matcher)
/* 356:    */     {
/* 357:631 */       Preconditions.checkState(hasMore());
/* 358:632 */       int startPosition = this.position;
/* 359:633 */       this.position = matcher.negate().indexIn(this.input, startPosition);
/* 360:634 */       return hasMore() ? this.input.substring(startPosition, this.position) : this.input.substring(startPosition);
/* 361:    */     }
/* 362:    */     
/* 363:    */     String consumeToken(CharMatcher matcher)
/* 364:    */     {
/* 365:638 */       int startPosition = this.position;
/* 366:639 */       String token = consumeTokenIfPresent(matcher);
/* 367:640 */       Preconditions.checkState(this.position != startPosition);
/* 368:641 */       return token;
/* 369:    */     }
/* 370:    */     
/* 371:    */     char consumeCharacter(CharMatcher matcher)
/* 372:    */     {
/* 373:645 */       Preconditions.checkState(hasMore());
/* 374:646 */       char c = previewChar();
/* 375:647 */       Preconditions.checkState(matcher.matches(c));
/* 376:648 */       this.position += 1;
/* 377:649 */       return c;
/* 378:    */     }
/* 379:    */     
/* 380:    */     char consumeCharacter(char c)
/* 381:    */     {
/* 382:653 */       Preconditions.checkState(hasMore());
/* 383:654 */       Preconditions.checkState(previewChar() == c);
/* 384:655 */       this.position += 1;
/* 385:656 */       return c;
/* 386:    */     }
/* 387:    */     
/* 388:    */     char previewChar()
/* 389:    */     {
/* 390:660 */       Preconditions.checkState(hasMore());
/* 391:661 */       return this.input.charAt(this.position);
/* 392:    */     }
/* 393:    */     
/* 394:    */     boolean hasMore()
/* 395:    */     {
/* 396:665 */       return (this.position >= 0) && (this.position < this.input.length());
/* 397:    */     }
/* 398:    */   }
/* 399:    */   
/* 400:    */   public boolean equals(@Nullable Object obj)
/* 401:    */   {
/* 402:670 */     if (obj == this) {
/* 403:671 */       return true;
/* 404:    */     }
/* 405:672 */     if ((obj instanceof MediaType))
/* 406:    */     {
/* 407:673 */       MediaType that = (MediaType)obj;
/* 408:674 */       return (this.type.equals(that.type)) && (this.subtype.equals(that.subtype)) && (parametersAsMap().equals(that.parametersAsMap()));
/* 409:    */     }
/* 410:679 */     return false;
/* 411:    */   }
/* 412:    */   
/* 413:    */   public int hashCode()
/* 414:    */   {
/* 415:684 */     return Objects.hashCode(new Object[] { this.type, this.subtype, parametersAsMap() });
/* 416:    */   }
/* 417:    */   
/* 418:687 */   private static final Joiner.MapJoiner PARAMETER_JOINER = Joiner.on("; ").withKeyValueSeparator("=");
/* 419:    */   
/* 420:    */   public String toString()
/* 421:    */   {
/* 422:694 */     StringBuilder builder = new StringBuilder().append(this.type).append('/').append(this.subtype);
/* 423:695 */     if (!this.parameters.isEmpty())
/* 424:    */     {
/* 425:696 */       builder.append("; ");
/* 426:697 */       Multimap<String, String> quotedParameters = Multimaps.transformValues(this.parameters, new Function()
/* 427:    */       {
/* 428:    */         public String apply(String value)
/* 429:    */         {
/* 430:700 */           return MediaType.TOKEN_MATCHER.matchesAllOf(value) ? value : MediaType.escapeAndQuote(value);
/* 431:    */         }
/* 432:702 */       });
/* 433:703 */       PARAMETER_JOINER.appendTo(builder, quotedParameters.entries());
/* 434:    */     }
/* 435:705 */     return builder.toString();
/* 436:    */   }
/* 437:    */   
/* 438:    */   private static String escapeAndQuote(String value)
/* 439:    */   {
/* 440:709 */     StringBuilder escaped = new StringBuilder(value.length() + 16).append('"');
/* 441:710 */     for (char ch : value.toCharArray())
/* 442:    */     {
/* 443:711 */       if ((ch == '\r') || (ch == '\\') || (ch == '"')) {
/* 444:712 */         escaped.append('\\');
/* 445:    */       }
/* 446:714 */       escaped.append(ch);
/* 447:    */     }
/* 448:716 */     return '"';
/* 449:    */   }
/* 450:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.net.MediaType
 * JD-Core Version:    0.7.0.1
 */
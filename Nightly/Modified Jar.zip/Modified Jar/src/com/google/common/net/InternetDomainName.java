/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.CharMatcher;
/*   7:    */ import com.google.common.base.Joiner;
/*   8:    */ import com.google.common.base.Preconditions;
/*   9:    */ import com.google.common.base.Splitter;
/*  10:    */ import com.google.common.collect.ImmutableList;
/*  11:    */ import com.google.common.collect.ImmutableMap;
/*  12:    */ import com.google.thirdparty.publicsuffix.PublicSuffixPatterns;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @Beta
/*  17:    */ @GwtCompatible
/*  18:    */ public final class InternetDomainName
/*  19:    */ {
/*  20: 79 */   private static final CharMatcher DOTS_MATCHER = CharMatcher.anyOf(".。．｡");
/*  21: 81 */   private static final Splitter DOT_SPLITTER = Splitter.on('.');
/*  22: 82 */   private static final Joiner DOT_JOINER = Joiner.on('.');
/*  23:    */   private static final int NO_PUBLIC_SUFFIX_FOUND = -1;
/*  24:    */   private static final String DOT_REGEX = "\\.";
/*  25:    */   private static final int MAX_PARTS = 127;
/*  26:    */   private static final int MAX_LENGTH = 253;
/*  27:    */   private static final int MAX_DOMAIN_PART_LENGTH = 63;
/*  28:    */   private final String name;
/*  29:    */   private final ImmutableList<String> parts;
/*  30:    */   private final int publicSuffixIndex;
/*  31:    */   
/*  32:    */   InternetDomainName(String name)
/*  33:    */   {
/*  34:143 */     name = Ascii.toLowerCase(DOTS_MATCHER.replaceFrom(name, '.'));
/*  35:145 */     if (name.endsWith(".")) {
/*  36:146 */       name = name.substring(0, name.length() - 1);
/*  37:    */     }
/*  38:149 */     Preconditions.checkArgument(name.length() <= 253, "Domain name too long: '%s':", new Object[] { name });
/*  39:    */     
/*  40:151 */     this.name = name;
/*  41:    */     
/*  42:153 */     this.parts = ImmutableList.copyOf(DOT_SPLITTER.split(name));
/*  43:154 */     Preconditions.checkArgument(this.parts.size() <= 127, "Domain has too many parts: '%s'", new Object[] { name });
/*  44:    */     
/*  45:156 */     Preconditions.checkArgument(validateSyntax(this.parts), "Not a valid domain name: '%s'", new Object[] { name });
/*  46:    */     
/*  47:158 */     this.publicSuffixIndex = findPublicSuffix();
/*  48:    */   }
/*  49:    */   
/*  50:    */   private int findPublicSuffix()
/*  51:    */   {
/*  52:168 */     int partsSize = this.parts.size();
/*  53:170 */     for (int i = 0; i < partsSize; i++)
/*  54:    */     {
/*  55:171 */       String ancestorName = DOT_JOINER.join(this.parts.subList(i, partsSize));
/*  56:173 */       if (PublicSuffixPatterns.EXACT.containsKey(ancestorName)) {
/*  57:174 */         return i;
/*  58:    */       }
/*  59:180 */       if (PublicSuffixPatterns.EXCLUDED.containsKey(ancestorName)) {
/*  60:181 */         return i + 1;
/*  61:    */       }
/*  62:184 */       if (matchesWildcardPublicSuffix(ancestorName)) {
/*  63:185 */         return i;
/*  64:    */       }
/*  65:    */     }
/*  66:189 */     return -1;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static InternetDomainName from(String domain)
/*  70:    */   {
/*  71:213 */     return new InternetDomainName((String)Preconditions.checkNotNull(domain));
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static boolean validateSyntax(List<String> parts)
/*  75:    */   {
/*  76:223 */     int lastIndex = parts.size() - 1;
/*  77:227 */     if (!validatePart((String)parts.get(lastIndex), true)) {
/*  78:228 */       return false;
/*  79:    */     }
/*  80:231 */     for (int i = 0; i < lastIndex; i++)
/*  81:    */     {
/*  82:232 */       String part = (String)parts.get(i);
/*  83:233 */       if (!validatePart(part, false)) {
/*  84:234 */         return false;
/*  85:    */       }
/*  86:    */     }
/*  87:238 */     return true;
/*  88:    */   }
/*  89:    */   
/*  90:241 */   private static final CharMatcher DASH_MATCHER = CharMatcher.anyOf("-_");
/*  91:243 */   private static final CharMatcher PART_CHAR_MATCHER = CharMatcher.JAVA_LETTER_OR_DIGIT.or(DASH_MATCHER);
/*  92:    */   
/*  93:    */   private static boolean validatePart(String part, boolean isFinalPart)
/*  94:    */   {
/*  95:259 */     if ((part.length() < 1) || (part.length() > 63)) {
/*  96:260 */       return false;
/*  97:    */     }
/*  98:273 */     String asciiChars = CharMatcher.ASCII.retainFrom(part);
/*  99:275 */     if (!PART_CHAR_MATCHER.matchesAllOf(asciiChars)) {
/* 100:276 */       return false;
/* 101:    */     }
/* 102:281 */     if ((DASH_MATCHER.matches(part.charAt(0))) || (DASH_MATCHER.matches(part.charAt(part.length() - 1)))) {
/* 103:283 */       return false;
/* 104:    */     }
/* 105:294 */     if ((isFinalPart) && (CharMatcher.DIGIT.matches(part.charAt(0)))) {
/* 106:295 */       return false;
/* 107:    */     }
/* 108:298 */     return true;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public ImmutableList<String> parts()
/* 112:    */   {
/* 113:307 */     return this.parts;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isPublicSuffix()
/* 117:    */   {
/* 118:324 */     return this.publicSuffixIndex == 0;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean hasPublicSuffix()
/* 122:    */   {
/* 123:338 */     return this.publicSuffixIndex != -1;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public InternetDomainName publicSuffix()
/* 127:    */   {
/* 128:348 */     return hasPublicSuffix() ? ancestor(this.publicSuffixIndex) : null;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean isUnderPublicSuffix()
/* 132:    */   {
/* 133:371 */     return this.publicSuffixIndex > 0;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean isTopPrivateDomain()
/* 137:    */   {
/* 138:395 */     return this.publicSuffixIndex == 1;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public InternetDomainName topPrivateDomain()
/* 142:    */   {
/* 143:421 */     if (isTopPrivateDomain()) {
/* 144:422 */       return this;
/* 145:    */     }
/* 146:424 */     Preconditions.checkState(isUnderPublicSuffix(), "Not under a public suffix: %s", new Object[] { this.name });
/* 147:425 */     return ancestor(this.publicSuffixIndex - 1);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public boolean hasParent()
/* 151:    */   {
/* 152:432 */     return this.parts.size() > 1;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public InternetDomainName parent()
/* 156:    */   {
/* 157:444 */     Preconditions.checkState(hasParent(), "Domain '%s' has no parent", new Object[] { this.name });
/* 158:445 */     return ancestor(1);
/* 159:    */   }
/* 160:    */   
/* 161:    */   private InternetDomainName ancestor(int levels)
/* 162:    */   {
/* 163:457 */     return from(DOT_JOINER.join(this.parts.subList(levels, this.parts.size())));
/* 164:    */   }
/* 165:    */   
/* 166:    */   public InternetDomainName child(String leftParts)
/* 167:    */   {
/* 168:471 */     return from((String)Preconditions.checkNotNull(leftParts) + "." + this.name);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static boolean isValid(String name)
/* 172:    */   {
/* 173:    */     try
/* 174:    */     {
/* 175:498 */       from(name);
/* 176:499 */       return true;
/* 177:    */     }
/* 178:    */     catch (IllegalArgumentException e) {}
/* 179:501 */     return false;
/* 180:    */   }
/* 181:    */   
/* 182:    */   private static boolean matchesWildcardPublicSuffix(String domain)
/* 183:    */   {
/* 184:510 */     String[] pieces = domain.split("\\.", 2);
/* 185:511 */     return (pieces.length == 2) && (PublicSuffixPatterns.UNDER.containsKey(pieces[1]));
/* 186:    */   }
/* 187:    */   
/* 188:    */   public String toString()
/* 189:    */   {
/* 190:519 */     return this.name;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public boolean equals(@Nullable Object object)
/* 194:    */   {
/* 195:531 */     if (object == this) {
/* 196:532 */       return true;
/* 197:    */     }
/* 198:535 */     if ((object instanceof InternetDomainName))
/* 199:    */     {
/* 200:536 */       InternetDomainName that = (InternetDomainName)object;
/* 201:537 */       return this.name.equals(that.name);
/* 202:    */     }
/* 203:540 */     return false;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public int hashCode()
/* 207:    */   {
/* 208:545 */     return this.name.hashCode();
/* 209:    */   }
/* 210:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.net.InternetDomainName
 * JD-Core Version:    0.7.0.1
 */
/*    1:     */ package com.google.common.net;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Objects;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.hash.HashCode;
/*    7:     */ import com.google.common.hash.HashFunction;
/*    8:     */ import com.google.common.hash.Hashing;
/*    9:     */ import com.google.common.io.ByteArrayDataInput;
/*   10:     */ import com.google.common.io.ByteStreams;
/*   11:     */ import com.google.common.primitives.Ints;
/*   12:     */ import java.net.Inet4Address;
/*   13:     */ import java.net.Inet6Address;
/*   14:     */ import java.net.InetAddress;
/*   15:     */ import java.net.UnknownHostException;
/*   16:     */ import java.nio.ByteBuffer;
/*   17:     */ import java.util.Arrays;
/*   18:     */ import javax.annotation.Nullable;
/*   19:     */ 
/*   20:     */ @Beta
/*   21:     */ public final class InetAddresses
/*   22:     */ {
/*   23:     */   private static final int IPV4_PART_COUNT = 4;
/*   24:     */   private static final int IPV6_PART_COUNT = 8;
/*   25: 117 */   private static final Inet4Address LOOPBACK4 = (Inet4Address)forString("127.0.0.1");
/*   26: 118 */   private static final Inet4Address ANY4 = (Inet4Address)forString("0.0.0.0");
/*   27:     */   
/*   28:     */   private static Inet4Address getInet4Address(byte[] bytes)
/*   29:     */   {
/*   30: 130 */     Preconditions.checkArgument(bytes.length == 4, "Byte array has invalid length for an IPv4 address: %s != 4.", new Object[] { Integer.valueOf(bytes.length) });
/*   31:     */     
/*   32:     */ 
/*   33:     */ 
/*   34:     */ 
/*   35: 135 */     return (Inet4Address)bytesToInetAddress(bytes);
/*   36:     */   }
/*   37:     */   
/*   38:     */   public static InetAddress forString(String ipString)
/*   39:     */   {
/*   40: 149 */     byte[] addr = ipStringToBytes(ipString);
/*   41: 152 */     if (addr == null) {
/*   42: 153 */       throw new IllegalArgumentException(String.format("'%s' is not an IP string literal.", new Object[] { ipString }));
/*   43:     */     }
/*   44: 157 */     return bytesToInetAddress(addr);
/*   45:     */   }
/*   46:     */   
/*   47:     */   public static boolean isInetAddress(String ipString)
/*   48:     */   {
/*   49: 168 */     return ipStringToBytes(ipString) != null;
/*   50:     */   }
/*   51:     */   
/*   52:     */   private static byte[] ipStringToBytes(String ipString)
/*   53:     */   {
/*   54: 173 */     boolean hasColon = false;
/*   55: 174 */     boolean hasDot = false;
/*   56: 175 */     for (int i = 0; i < ipString.length(); i++)
/*   57:     */     {
/*   58: 176 */       char c = ipString.charAt(i);
/*   59: 177 */       if (c == '.')
/*   60:     */       {
/*   61: 178 */         hasDot = true;
/*   62:     */       }
/*   63: 179 */       else if (c == ':')
/*   64:     */       {
/*   65: 180 */         if (hasDot) {
/*   66: 181 */           return null;
/*   67:     */         }
/*   68: 183 */         hasColon = true;
/*   69:     */       }
/*   70: 184 */       else if (Character.digit(c, 16) == -1)
/*   71:     */       {
/*   72: 185 */         return null;
/*   73:     */       }
/*   74:     */     }
/*   75: 190 */     if (hasColon)
/*   76:     */     {
/*   77: 191 */       if (hasDot)
/*   78:     */       {
/*   79: 192 */         ipString = convertDottedQuadToHex(ipString);
/*   80: 193 */         if (ipString == null) {
/*   81: 194 */           return null;
/*   82:     */         }
/*   83:     */       }
/*   84: 197 */       return textToNumericFormatV6(ipString);
/*   85:     */     }
/*   86: 198 */     if (hasDot) {
/*   87: 199 */       return textToNumericFormatV4(ipString);
/*   88:     */     }
/*   89: 201 */     return null;
/*   90:     */   }
/*   91:     */   
/*   92:     */   private static byte[] textToNumericFormatV4(String ipString)
/*   93:     */   {
/*   94: 205 */     String[] address = ipString.split("\\.", 5);
/*   95: 206 */     if (address.length != 4) {
/*   96: 207 */       return null;
/*   97:     */     }
/*   98: 210 */     byte[] bytes = new byte[4];
/*   99:     */     try
/*  100:     */     {
/*  101: 212 */       for (int i = 0; i < bytes.length; i++) {
/*  102: 213 */         bytes[i] = parseOctet(address[i]);
/*  103:     */       }
/*  104:     */     }
/*  105:     */     catch (NumberFormatException ex)
/*  106:     */     {
/*  107: 216 */       return null;
/*  108:     */     }
/*  109: 219 */     return bytes;
/*  110:     */   }
/*  111:     */   
/*  112:     */   private static byte[] textToNumericFormatV6(String ipString)
/*  113:     */   {
/*  114: 224 */     String[] parts = ipString.split(":", 10);
/*  115: 225 */     if ((parts.length < 3) || (parts.length > 9)) {
/*  116: 226 */       return null;
/*  117:     */     }
/*  118: 231 */     int skipIndex = -1;
/*  119: 232 */     for (int i = 1; i < parts.length - 1; i++) {
/*  120: 233 */       if (parts[i].length() == 0)
/*  121:     */       {
/*  122: 234 */         if (skipIndex >= 0) {
/*  123: 235 */           return null;
/*  124:     */         }
/*  125: 237 */         skipIndex = i;
/*  126:     */       }
/*  127:     */     }
/*  128:     */     int partsHi;
/*  129:     */     int partsLo;
/*  130: 243 */     if (skipIndex >= 0)
/*  131:     */     {
/*  132: 245 */       int partsHi = skipIndex;
/*  133: 246 */       int partsLo = parts.length - skipIndex - 1;
/*  134: 247 */       if (parts[0].length() == 0)
/*  135:     */       {
/*  136: 247 */         partsHi--;
/*  137: 247 */         if (partsHi != 0) {
/*  138: 248 */           return null;
/*  139:     */         }
/*  140:     */       }
/*  141: 250 */       if (parts[(parts.length - 1)].length() == 0)
/*  142:     */       {
/*  143: 250 */         partsLo--;
/*  144: 250 */         if (partsLo != 0) {
/*  145: 251 */           return null;
/*  146:     */         }
/*  147:     */       }
/*  148:     */     }
/*  149:     */     else
/*  150:     */     {
/*  151: 256 */       partsHi = parts.length;
/*  152: 257 */       partsLo = 0;
/*  153:     */     }
/*  154: 262 */     int partsSkipped = 8 - (partsHi + partsLo);
/*  155: 263 */     if (skipIndex >= 0 ? partsSkipped < 1 : partsSkipped != 0) {
/*  156: 264 */       return null;
/*  157:     */     }
/*  158: 268 */     ByteBuffer rawBytes = ByteBuffer.allocate(16);
/*  159:     */     try
/*  160:     */     {
/*  161: 270 */       for (int i = 0; i < partsHi; i++) {
/*  162: 271 */         rawBytes.putShort(parseHextet(parts[i]));
/*  163:     */       }
/*  164: 273 */       for (int i = 0; i < partsSkipped; i++) {
/*  165: 274 */         rawBytes.putShort((short)0);
/*  166:     */       }
/*  167: 276 */       for (int i = partsLo; i > 0; i--) {
/*  168: 277 */         rawBytes.putShort(parseHextet(parts[(parts.length - i)]));
/*  169:     */       }
/*  170:     */     }
/*  171:     */     catch (NumberFormatException ex)
/*  172:     */     {
/*  173: 280 */       return null;
/*  174:     */     }
/*  175: 282 */     return rawBytes.array();
/*  176:     */   }
/*  177:     */   
/*  178:     */   private static String convertDottedQuadToHex(String ipString)
/*  179:     */   {
/*  180: 286 */     int lastColon = ipString.lastIndexOf(':');
/*  181: 287 */     String initialPart = ipString.substring(0, lastColon + 1);
/*  182: 288 */     String dottedQuad = ipString.substring(lastColon + 1);
/*  183: 289 */     byte[] quad = textToNumericFormatV4(dottedQuad);
/*  184: 290 */     if (quad == null) {
/*  185: 291 */       return null;
/*  186:     */     }
/*  187: 293 */     String penultimate = Integer.toHexString((quad[0] & 0xFF) << 8 | quad[1] & 0xFF);
/*  188: 294 */     String ultimate = Integer.toHexString((quad[2] & 0xFF) << 8 | quad[3] & 0xFF);
/*  189: 295 */     return initialPart + penultimate + ":" + ultimate;
/*  190:     */   }
/*  191:     */   
/*  192:     */   private static byte parseOctet(String ipPart)
/*  193:     */   {
/*  194: 300 */     int octet = Integer.parseInt(ipPart);
/*  195: 303 */     if ((octet > 255) || ((ipPart.startsWith("0")) && (ipPart.length() > 1))) {
/*  196: 304 */       throw new NumberFormatException();
/*  197:     */     }
/*  198: 306 */     return (byte)octet;
/*  199:     */   }
/*  200:     */   
/*  201:     */   private static short parseHextet(String ipPart)
/*  202:     */   {
/*  203: 311 */     int hextet = Integer.parseInt(ipPart, 16);
/*  204: 312 */     if (hextet > 65535) {
/*  205: 313 */       throw new NumberFormatException();
/*  206:     */     }
/*  207: 315 */     return (short)hextet;
/*  208:     */   }
/*  209:     */   
/*  210:     */   private static InetAddress bytesToInetAddress(byte[] addr)
/*  211:     */   {
/*  212:     */     try
/*  213:     */     {
/*  214: 331 */       return InetAddress.getByAddress(addr);
/*  215:     */     }
/*  216:     */     catch (UnknownHostException e)
/*  217:     */     {
/*  218: 333 */       throw new AssertionError(e);
/*  219:     */     }
/*  220:     */   }
/*  221:     */   
/*  222:     */   public static String toAddrString(InetAddress ip)
/*  223:     */   {
/*  224: 355 */     Preconditions.checkNotNull(ip);
/*  225: 356 */     if ((ip instanceof Inet4Address)) {
/*  226: 358 */       return ip.getHostAddress();
/*  227:     */     }
/*  228: 360 */     Preconditions.checkArgument(ip instanceof Inet6Address);
/*  229: 361 */     byte[] bytes = ip.getAddress();
/*  230: 362 */     int[] hextets = new int[8];
/*  231: 363 */     for (int i = 0; i < hextets.length; i++) {
/*  232: 364 */       hextets[i] = Ints.fromBytes(0, 0, bytes[(2 * i)], bytes[(2 * i + 1)]);
/*  233:     */     }
/*  234: 367 */     compressLongestRunOfZeroes(hextets);
/*  235: 368 */     return hextetsToIPv6String(hextets);
/*  236:     */   }
/*  237:     */   
/*  238:     */   private static void compressLongestRunOfZeroes(int[] hextets)
/*  239:     */   {
/*  240: 381 */     int bestRunStart = -1;
/*  241: 382 */     int bestRunLength = -1;
/*  242: 383 */     int runStart = -1;
/*  243: 384 */     for (int i = 0; i < hextets.length + 1; i++) {
/*  244: 385 */       if ((i < hextets.length) && (hextets[i] == 0))
/*  245:     */       {
/*  246: 386 */         if (runStart < 0) {
/*  247: 387 */           runStart = i;
/*  248:     */         }
/*  249:     */       }
/*  250: 389 */       else if (runStart >= 0)
/*  251:     */       {
/*  252: 390 */         int runLength = i - runStart;
/*  253: 391 */         if (runLength > bestRunLength)
/*  254:     */         {
/*  255: 392 */           bestRunStart = runStart;
/*  256: 393 */           bestRunLength = runLength;
/*  257:     */         }
/*  258: 395 */         runStart = -1;
/*  259:     */       }
/*  260:     */     }
/*  261: 398 */     if (bestRunLength >= 2) {
/*  262: 399 */       Arrays.fill(hextets, bestRunStart, bestRunStart + bestRunLength, -1);
/*  263:     */     }
/*  264:     */   }
/*  265:     */   
/*  266:     */   private static String hextetsToIPv6String(int[] hextets)
/*  267:     */   {
/*  268: 418 */     StringBuilder buf = new StringBuilder(39);
/*  269: 419 */     boolean lastWasNumber = false;
/*  270: 420 */     for (int i = 0; i < hextets.length; i++)
/*  271:     */     {
/*  272: 421 */       boolean thisIsNumber = hextets[i] >= 0;
/*  273: 422 */       if (thisIsNumber)
/*  274:     */       {
/*  275: 423 */         if (lastWasNumber) {
/*  276: 424 */           buf.append(':');
/*  277:     */         }
/*  278: 426 */         buf.append(Integer.toHexString(hextets[i]));
/*  279:     */       }
/*  280: 428 */       else if ((i == 0) || (lastWasNumber))
/*  281:     */       {
/*  282: 429 */         buf.append("::");
/*  283:     */       }
/*  284: 432 */       lastWasNumber = thisIsNumber;
/*  285:     */     }
/*  286: 434 */     return buf.toString();
/*  287:     */   }
/*  288:     */   
/*  289:     */   public static String toUriString(InetAddress ip)
/*  290:     */   {
/*  291: 463 */     if ((ip instanceof Inet6Address)) {
/*  292: 464 */       return "[" + toAddrString(ip) + "]";
/*  293:     */     }
/*  294: 466 */     return toAddrString(ip);
/*  295:     */   }
/*  296:     */   
/*  297:     */   public static InetAddress forUriString(String hostAddr)
/*  298:     */   {
/*  299: 485 */     Preconditions.checkNotNull(hostAddr);
/*  300:     */     int expectBytes;
/*  301:     */     String ipString;
/*  302:     */     int expectBytes;
/*  303: 490 */     if ((hostAddr.startsWith("[")) && (hostAddr.endsWith("]")))
/*  304:     */     {
/*  305: 491 */       String ipString = hostAddr.substring(1, hostAddr.length() - 1);
/*  306: 492 */       expectBytes = 16;
/*  307:     */     }
/*  308:     */     else
/*  309:     */     {
/*  310: 494 */       ipString = hostAddr;
/*  311: 495 */       expectBytes = 4;
/*  312:     */     }
/*  313: 499 */     byte[] addr = ipStringToBytes(ipString);
/*  314: 500 */     if ((addr == null) || (addr.length != expectBytes)) {
/*  315: 501 */       throw new IllegalArgumentException(String.format("Not a valid URI IP literal: '%s'", new Object[] { hostAddr }));
/*  316:     */     }
/*  317: 505 */     return bytesToInetAddress(addr);
/*  318:     */   }
/*  319:     */   
/*  320:     */   public static boolean isUriInetAddress(String ipString)
/*  321:     */   {
/*  322:     */     try
/*  323:     */     {
/*  324: 517 */       forUriString(ipString);
/*  325: 518 */       return true;
/*  326:     */     }
/*  327:     */     catch (IllegalArgumentException e) {}
/*  328: 520 */     return false;
/*  329:     */   }
/*  330:     */   
/*  331:     */   public static boolean isCompatIPv4Address(Inet6Address ip)
/*  332:     */   {
/*  333: 549 */     if (!ip.isIPv4CompatibleAddress()) {
/*  334: 550 */       return false;
/*  335:     */     }
/*  336: 553 */     byte[] bytes = ip.getAddress();
/*  337: 554 */     if ((bytes[12] == 0) && (bytes[13] == 0) && (bytes[14] == 0) && ((bytes[15] == 0) || (bytes[15] == 1))) {
/*  338: 556 */       return false;
/*  339:     */     }
/*  340: 559 */     return true;
/*  341:     */   }
/*  342:     */   
/*  343:     */   public static Inet4Address getCompatIPv4Address(Inet6Address ip)
/*  344:     */   {
/*  345: 570 */     Preconditions.checkArgument(isCompatIPv4Address(ip), "Address '%s' is not IPv4-compatible.", new Object[] { toAddrString(ip) });
/*  346:     */     
/*  347:     */ 
/*  348: 573 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 12, 16));
/*  349:     */   }
/*  350:     */   
/*  351:     */   public static boolean is6to4Address(Inet6Address ip)
/*  352:     */   {
/*  353: 591 */     byte[] bytes = ip.getAddress();
/*  354: 592 */     return (bytes[0] == 32) && (bytes[1] == 2);
/*  355:     */   }
/*  356:     */   
/*  357:     */   public static Inet4Address get6to4IPv4Address(Inet6Address ip)
/*  358:     */   {
/*  359: 603 */     Preconditions.checkArgument(is6to4Address(ip), "Address '%s' is not a 6to4 address.", new Object[] { toAddrString(ip) });
/*  360:     */     
/*  361:     */ 
/*  362: 606 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 2, 6));
/*  363:     */   }
/*  364:     */   
/*  365:     */   @Beta
/*  366:     */   public static final class TeredoInfo
/*  367:     */   {
/*  368:     */     private final Inet4Address server;
/*  369:     */     private final Inet4Address client;
/*  370:     */     private final int port;
/*  371:     */     private final int flags;
/*  372:     */     
/*  373:     */     public TeredoInfo(@Nullable Inet4Address server, @Nullable Inet4Address client, int port, int flags)
/*  374:     */     {
/*  375: 644 */       Preconditions.checkArgument((port >= 0) && (port <= 65535), "port '%s' is out of range (0 <= port <= 0xffff)", new Object[] { Integer.valueOf(port) });
/*  376:     */       
/*  377: 646 */       Preconditions.checkArgument((flags >= 0) && (flags <= 65535), "flags '%s' is out of range (0 <= flags <= 0xffff)", new Object[] { Integer.valueOf(flags) });
/*  378:     */       
/*  379:     */ 
/*  380: 649 */       this.server = ((Inet4Address)Objects.firstNonNull(server, InetAddresses.ANY4));
/*  381: 650 */       this.client = ((Inet4Address)Objects.firstNonNull(client, InetAddresses.ANY4));
/*  382: 651 */       this.port = port;
/*  383: 652 */       this.flags = flags;
/*  384:     */     }
/*  385:     */     
/*  386:     */     public Inet4Address getServer()
/*  387:     */     {
/*  388: 656 */       return this.server;
/*  389:     */     }
/*  390:     */     
/*  391:     */     public Inet4Address getClient()
/*  392:     */     {
/*  393: 660 */       return this.client;
/*  394:     */     }
/*  395:     */     
/*  396:     */     public int getPort()
/*  397:     */     {
/*  398: 664 */       return this.port;
/*  399:     */     }
/*  400:     */     
/*  401:     */     public int getFlags()
/*  402:     */     {
/*  403: 668 */       return this.flags;
/*  404:     */     }
/*  405:     */   }
/*  406:     */   
/*  407:     */   public static boolean isTeredoAddress(Inet6Address ip)
/*  408:     */   {
/*  409: 681 */     byte[] bytes = ip.getAddress();
/*  410: 682 */     return (bytes[0] == 32) && (bytes[1] == 1) && (bytes[2] == 0) && (bytes[3] == 0);
/*  411:     */   }
/*  412:     */   
/*  413:     */   public static TeredoInfo getTeredoInfo(Inet6Address ip)
/*  414:     */   {
/*  415: 694 */     Preconditions.checkArgument(isTeredoAddress(ip), "Address '%s' is not a Teredo address.", new Object[] { toAddrString(ip) });
/*  416:     */     
/*  417:     */ 
/*  418: 697 */     byte[] bytes = ip.getAddress();
/*  419: 698 */     Inet4Address server = getInet4Address(Arrays.copyOfRange(bytes, 4, 8));
/*  420:     */     
/*  421: 700 */     int flags = ByteStreams.newDataInput(bytes, 8).readShort() & 0xFFFF;
/*  422:     */     
/*  423:     */ 
/*  424: 703 */     int port = (ByteStreams.newDataInput(bytes, 10).readShort() ^ 0xFFFFFFFF) & 0xFFFF;
/*  425:     */     
/*  426: 705 */     byte[] clientBytes = Arrays.copyOfRange(bytes, 12, 16);
/*  427: 706 */     for (int i = 0; i < clientBytes.length; i++) {
/*  428: 708 */       clientBytes[i] = ((byte)(clientBytes[i] ^ 0xFFFFFFFF));
/*  429:     */     }
/*  430: 710 */     Inet4Address client = getInet4Address(clientBytes);
/*  431:     */     
/*  432: 712 */     return new TeredoInfo(server, client, port, flags);
/*  433:     */   }
/*  434:     */   
/*  435:     */   public static boolean isIsatapAddress(Inet6Address ip)
/*  436:     */   {
/*  437: 734 */     if (isTeredoAddress(ip)) {
/*  438: 735 */       return false;
/*  439:     */     }
/*  440: 738 */     byte[] bytes = ip.getAddress();
/*  441: 740 */     if ((bytes[8] | 0x3) != 3) {
/*  442: 744 */       return false;
/*  443:     */     }
/*  444: 747 */     return (bytes[9] == 0) && (bytes[10] == 94) && (bytes[11] == -2);
/*  445:     */   }
/*  446:     */   
/*  447:     */   public static Inet4Address getIsatapIPv4Address(Inet6Address ip)
/*  448:     */   {
/*  449: 759 */     Preconditions.checkArgument(isIsatapAddress(ip), "Address '%s' is not an ISATAP address.", new Object[] { toAddrString(ip) });
/*  450:     */     
/*  451:     */ 
/*  452: 762 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 12, 16));
/*  453:     */   }
/*  454:     */   
/*  455:     */   public static boolean hasEmbeddedIPv4ClientAddress(Inet6Address ip)
/*  456:     */   {
/*  457: 778 */     return (isCompatIPv4Address(ip)) || (is6to4Address(ip)) || (isTeredoAddress(ip));
/*  458:     */   }
/*  459:     */   
/*  460:     */   public static Inet4Address getEmbeddedIPv4ClientAddress(Inet6Address ip)
/*  461:     */   {
/*  462: 795 */     if (isCompatIPv4Address(ip)) {
/*  463: 796 */       return getCompatIPv4Address(ip);
/*  464:     */     }
/*  465: 799 */     if (is6to4Address(ip)) {
/*  466: 800 */       return get6to4IPv4Address(ip);
/*  467:     */     }
/*  468: 803 */     if (isTeredoAddress(ip)) {
/*  469: 804 */       return getTeredoInfo(ip).getClient();
/*  470:     */     }
/*  471: 807 */     throw new IllegalArgumentException(String.format("'%s' has no embedded IPv4 address.", new Object[] { toAddrString(ip) }));
/*  472:     */   }
/*  473:     */   
/*  474:     */   public static boolean isMappedIPv4Address(String ipString)
/*  475:     */   {
/*  476: 834 */     byte[] bytes = ipStringToBytes(ipString);
/*  477: 835 */     if ((bytes != null) && (bytes.length == 16))
/*  478:     */     {
/*  479: 836 */       for (int i = 0; i < 10; i++) {
/*  480: 837 */         if (bytes[i] != 0) {
/*  481: 838 */           return false;
/*  482:     */         }
/*  483:     */       }
/*  484: 841 */       for (int i = 10; i < 12; i++) {
/*  485: 842 */         if (bytes[i] != -1) {
/*  486: 843 */           return false;
/*  487:     */         }
/*  488:     */       }
/*  489: 846 */       return true;
/*  490:     */     }
/*  491: 848 */     return false;
/*  492:     */   }
/*  493:     */   
/*  494:     */   public static Inet4Address getCoercedIPv4Address(InetAddress ip)
/*  495:     */   {
/*  496: 872 */     if ((ip instanceof Inet4Address)) {
/*  497: 873 */       return (Inet4Address)ip;
/*  498:     */     }
/*  499: 877 */     byte[] bytes = ip.getAddress();
/*  500: 878 */     boolean leadingBytesOfZero = true;
/*  501: 879 */     for (int i = 0; i < 15; i++) {
/*  502: 880 */       if (bytes[i] != 0)
/*  503:     */       {
/*  504: 881 */         leadingBytesOfZero = false;
/*  505: 882 */         break;
/*  506:     */       }
/*  507:     */     }
/*  508: 885 */     if ((leadingBytesOfZero) && (bytes[15] == 1)) {
/*  509: 886 */       return LOOPBACK4;
/*  510:     */     }
/*  511: 887 */     if ((leadingBytesOfZero) && (bytes[15] == 0)) {
/*  512: 888 */       return ANY4;
/*  513:     */     }
/*  514: 891 */     Inet6Address ip6 = (Inet6Address)ip;
/*  515: 892 */     long addressAsLong = 0L;
/*  516: 893 */     if (hasEmbeddedIPv4ClientAddress(ip6)) {
/*  517: 894 */       addressAsLong = getEmbeddedIPv4ClientAddress(ip6).hashCode();
/*  518:     */     } else {
/*  519: 898 */       addressAsLong = ByteBuffer.wrap(ip6.getAddress(), 0, 8).getLong();
/*  520:     */     }
/*  521: 902 */     int coercedHash = Hashing.murmur3_32().hashLong(addressAsLong).asInt();
/*  522:     */     
/*  523:     */ 
/*  524: 905 */     coercedHash |= 0xE0000000;
/*  525: 909 */     if (coercedHash == -1) {
/*  526: 910 */       coercedHash = -2;
/*  527:     */     }
/*  528: 913 */     return getInet4Address(Ints.toByteArray(coercedHash));
/*  529:     */   }
/*  530:     */   
/*  531:     */   public static int coerceToInteger(InetAddress ip)
/*  532:     */   {
/*  533: 938 */     return ByteStreams.newDataInput(getCoercedIPv4Address(ip).getAddress()).readInt();
/*  534:     */   }
/*  535:     */   
/*  536:     */   public static Inet4Address fromInteger(int address)
/*  537:     */   {
/*  538: 949 */     return getInet4Address(Ints.toByteArray(address));
/*  539:     */   }
/*  540:     */   
/*  541:     */   public static InetAddress fromLittleEndianByteArray(byte[] addr)
/*  542:     */     throws UnknownHostException
/*  543:     */   {
/*  544: 964 */     byte[] reversed = new byte[addr.length];
/*  545: 965 */     for (int i = 0; i < addr.length; i++) {
/*  546: 966 */       reversed[i] = addr[(addr.length - i - 1)];
/*  547:     */     }
/*  548: 968 */     return InetAddress.getByAddress(reversed);
/*  549:     */   }
/*  550:     */   
/*  551:     */   public static InetAddress increment(InetAddress address)
/*  552:     */   {
/*  553: 981 */     byte[] addr = address.getAddress();
/*  554: 982 */     int i = addr.length - 1;
/*  555: 983 */     while ((i >= 0) && (addr[i] == -1))
/*  556:     */     {
/*  557: 984 */       addr[i] = 0;
/*  558: 985 */       i--;
/*  559:     */     }
/*  560: 988 */     Preconditions.checkArgument(i >= 0, "Incrementing %s would wrap.", new Object[] { address }); int 
/*  561:     */     
/*  562: 990 */       tmp55_54 = i; byte[] tmp55_53 = addr;tmp55_53[tmp55_54] = ((byte)(tmp55_53[tmp55_54] + 1));
/*  563: 991 */     return bytesToInetAddress(addr);
/*  564:     */   }
/*  565:     */   
/*  566:     */   public static boolean isMaximum(InetAddress address)
/*  567:     */   {
/*  568:1003 */     byte[] addr = address.getAddress();
/*  569:1004 */     for (int i = 0; i < addr.length; i++) {
/*  570:1005 */       if (addr[i] != -1) {
/*  571:1006 */         return false;
/*  572:     */       }
/*  573:     */     }
/*  574:1009 */     return true;
/*  575:     */   }
/*  576:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.net.InetAddresses
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.xml;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.escape.Escaper;
/*   6:    */ import com.google.common.escape.Escapers;
/*   7:    */ import com.google.common.escape.Escapers.Builder;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public class XmlEscapers
/*  12:    */ {
/*  13:    */   private static final char MIN_ASCII_CONTROL_CHAR = '\000';
/*  14:    */   private static final char MAX_ASCII_CONTROL_CHAR = '\037';
/*  15:    */   private static final Escaper XML_ESCAPER;
/*  16:    */   private static final Escaper XML_CONTENT_ESCAPER;
/*  17:    */   private static final Escaper XML_ATTRIBUTE_ESCAPER;
/*  18:    */   
/*  19:    */   public static Escaper xmlContentEscaper()
/*  20:    */   {
/*  21: 87 */     return XML_CONTENT_ESCAPER;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static Escaper xmlAttributeEscaper()
/*  25:    */   {
/*  26:108 */     return XML_ATTRIBUTE_ESCAPER;
/*  27:    */   }
/*  28:    */   
/*  29:    */   static
/*  30:    */   {
/*  31:115 */     Escapers.Builder builder = Escapers.builder();
/*  32:    */     
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:120 */     builder.setSafeRange('\000', 65535);
/*  37:    */     
/*  38:122 */     builder.setUnsafeReplacement("");
/*  39:129 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/*  40:130 */       if ((c != '\t') && (c != '\n') && (c != '\r')) {
/*  41:131 */         builder.addEscape(c, "");
/*  42:    */       }
/*  43:    */     }
/*  44:137 */     builder.addEscape('&', "&amp;");
/*  45:138 */     builder.addEscape('<', "&lt;");
/*  46:139 */     builder.addEscape('>', "&gt;");
/*  47:140 */     XML_CONTENT_ESCAPER = builder.build();
/*  48:141 */     builder.addEscape('\'', "&apos;");
/*  49:142 */     builder.addEscape('"', "&quot;");
/*  50:143 */     XML_ESCAPER = builder.build();
/*  51:144 */     builder.addEscape('\t', "&#x9;");
/*  52:145 */     builder.addEscape('\n', "&#xA;");
/*  53:146 */     builder.addEscape('\r', "&#xD;");
/*  54:147 */     XML_ATTRIBUTE_ESCAPER = builder.build();
/*  55:    */   }
/*  56:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.xml.XmlEscapers
 * JD-Core Version:    0.7.0.1
 */
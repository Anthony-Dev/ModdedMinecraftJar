/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Ascii;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.ImmutableList;
/*   7:    */ import com.google.common.hash.Funnels;
/*   8:    */ import com.google.common.hash.HashCode;
/*   9:    */ import com.google.common.hash.HashFunction;
/*  10:    */ import com.google.common.hash.Hasher;
/*  11:    */ import java.io.BufferedInputStream;
/*  12:    */ import java.io.ByteArrayInputStream;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.io.InputStream;
/*  15:    */ import java.io.InputStreamReader;
/*  16:    */ import java.io.OutputStream;
/*  17:    */ import java.io.Reader;
/*  18:    */ import java.nio.charset.Charset;
/*  19:    */ import java.util.Iterator;
/*  20:    */ 
/*  21:    */ public abstract class ByteSource
/*  22:    */   implements InputSupplier<InputStream>
/*  23:    */ {
/*  24:    */   private static final int BUF_SIZE = 4096;
/*  25:    */   
/*  26:    */   public CharSource asCharSource(Charset charset)
/*  27:    */   {
/*  28: 73 */     return new AsCharSource(charset, null);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public abstract InputStream openStream()
/*  32:    */     throws IOException;
/*  33:    */   
/*  34:    */   @Deprecated
/*  35:    */   public final InputStream getInput()
/*  36:    */     throws IOException
/*  37:    */   {
/*  38: 98 */     return openStream();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public InputStream openBufferedStream()
/*  42:    */     throws IOException
/*  43:    */   {
/*  44:114 */     InputStream in = openStream();
/*  45:115 */     return (in instanceof BufferedInputStream) ? (BufferedInputStream)in : new BufferedInputStream(in);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public ByteSource slice(long offset, long length)
/*  49:    */   {
/*  50:127 */     return new SlicedByteSource(offset, length, null);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isEmpty()
/*  54:    */     throws IOException
/*  55:    */   {
/*  56:138 */     Closer closer = Closer.create();
/*  57:    */     try
/*  58:    */     {
/*  59:140 */       InputStream in = (InputStream)closer.register(openStream());
/*  60:141 */       return in.read() == -1;
/*  61:    */     }
/*  62:    */     catch (Throwable e)
/*  63:    */     {
/*  64:143 */       throw closer.rethrow(e);
/*  65:    */     }
/*  66:    */     finally
/*  67:    */     {
/*  68:145 */       closer.close();
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public long size()
/*  73:    */     throws IOException
/*  74:    */   {
/*  75:165 */     Closer closer = Closer.create();
/*  76:    */     long l;
/*  77:    */     try
/*  78:    */     {
/*  79:167 */       InputStream in = (InputStream)closer.register(openStream());
/*  80:168 */       return countBySkipping(in);
/*  81:    */     }
/*  82:    */     catch (IOException e) {}finally
/*  83:    */     {
/*  84:172 */       closer.close();
/*  85:    */     }
/*  86:175 */     closer = Closer.create();
/*  87:    */     try
/*  88:    */     {
/*  89:177 */       InputStream in = (InputStream)closer.register(openStream());
/*  90:178 */       return countByReading(in);
/*  91:    */     }
/*  92:    */     catch (Throwable e)
/*  93:    */     {
/*  94:180 */       throw closer.rethrow(e);
/*  95:    */     }
/*  96:    */     finally
/*  97:    */     {
/*  98:182 */       closer.close();
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   private long countBySkipping(InputStream in)
/* 103:    */     throws IOException
/* 104:    */   {
/* 105:191 */     long count = 0L;
/* 106:    */     for (;;)
/* 107:    */     {
/* 108:195 */       long skipped = in.skip(Math.min(in.available(), 2147483647));
/* 109:196 */       if (skipped <= 0L)
/* 110:    */       {
/* 111:197 */         if (in.read() == -1) {
/* 112:198 */           return count;
/* 113:    */         }
/* 114:199 */         if ((count == 0L) && (in.available() == 0)) {
/* 115:202 */           throw new IOException();
/* 116:    */         }
/* 117:204 */         count += 1L;
/* 118:    */       }
/* 119:    */       else
/* 120:    */       {
/* 121:206 */         count += skipped;
/* 122:    */       }
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:211 */   private static final byte[] countBuffer = new byte[4096];
/* 127:    */   
/* 128:    */   private long countByReading(InputStream in)
/* 129:    */     throws IOException
/* 130:    */   {
/* 131:214 */     long count = 0L;
/* 132:    */     long read;
/* 133:216 */     while ((read = in.read(countBuffer)) != -1L) {
/* 134:217 */       count += read;
/* 135:    */     }
/* 136:219 */     return count;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public long copyTo(OutputStream output)
/* 140:    */     throws IOException
/* 141:    */   {
/* 142:230 */     Preconditions.checkNotNull(output);
/* 143:    */     
/* 144:232 */     Closer closer = Closer.create();
/* 145:    */     try
/* 146:    */     {
/* 147:234 */       InputStream in = (InputStream)closer.register(openStream());
/* 148:235 */       return ByteStreams.copy(in, output);
/* 149:    */     }
/* 150:    */     catch (Throwable e)
/* 151:    */     {
/* 152:237 */       throw closer.rethrow(e);
/* 153:    */     }
/* 154:    */     finally
/* 155:    */     {
/* 156:239 */       closer.close();
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   public long copyTo(ByteSink sink)
/* 161:    */     throws IOException
/* 162:    */   {
/* 163:250 */     Preconditions.checkNotNull(sink);
/* 164:    */     
/* 165:252 */     Closer closer = Closer.create();
/* 166:    */     try
/* 167:    */     {
/* 168:254 */       InputStream in = (InputStream)closer.register(openStream());
/* 169:255 */       OutputStream out = (OutputStream)closer.register(sink.openStream());
/* 170:256 */       return ByteStreams.copy(in, out);
/* 171:    */     }
/* 172:    */     catch (Throwable e)
/* 173:    */     {
/* 174:258 */       throw closer.rethrow(e);
/* 175:    */     }
/* 176:    */     finally
/* 177:    */     {
/* 178:260 */       closer.close();
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   public byte[] read()
/* 183:    */     throws IOException
/* 184:    */   {
/* 185:270 */     Closer closer = Closer.create();
/* 186:    */     try
/* 187:    */     {
/* 188:272 */       InputStream in = (InputStream)closer.register(openStream());
/* 189:273 */       return ByteStreams.toByteArray(in);
/* 190:    */     }
/* 191:    */     catch (Throwable e)
/* 192:    */     {
/* 193:275 */       throw closer.rethrow(e);
/* 194:    */     }
/* 195:    */     finally
/* 196:    */     {
/* 197:277 */       closer.close();
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   @Beta
/* 202:    */   public <T> T read(ByteProcessor<T> processor)
/* 203:    */     throws IOException
/* 204:    */   {
/* 205:292 */     Preconditions.checkNotNull(processor);
/* 206:    */     
/* 207:294 */     Closer closer = Closer.create();
/* 208:    */     try
/* 209:    */     {
/* 210:296 */       InputStream in = (InputStream)closer.register(openStream());
/* 211:297 */       return ByteStreams.readBytes(in, processor);
/* 212:    */     }
/* 213:    */     catch (Throwable e)
/* 214:    */     {
/* 215:299 */       throw closer.rethrow(e);
/* 216:    */     }
/* 217:    */     finally
/* 218:    */     {
/* 219:301 */       closer.close();
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   public HashCode hash(HashFunction hashFunction)
/* 224:    */     throws IOException
/* 225:    */   {
/* 226:311 */     Hasher hasher = hashFunction.newHasher();
/* 227:312 */     copyTo(Funnels.asOutputStream(hasher));
/* 228:313 */     return hasher.hash();
/* 229:    */   }
/* 230:    */   
/* 231:    */   /* Error */
/* 232:    */   public boolean contentEquals(ByteSource other)
/* 233:    */     throws IOException
/* 234:    */   {
/* 235:    */     // Byte code:
/* 236:    */     //   0: aload_1
/* 237:    */     //   1: invokestatic 222	com/google/common/base/Preconditions:checkNotNull	(Ljava/lang/Object;)Ljava/lang/Object;
/* 238:    */     //   4: pop
/* 239:    */     //   5: sipush 4096
/* 240:    */     //   8: newarray byte
/* 241:    */     //   10: astore_2
/* 242:    */     //   11: sipush 4096
/* 243:    */     //   14: newarray byte
/* 244:    */     //   16: astore_3
/* 245:    */     //   17: invokestatic 243	com/google/common/io/Closer:create	()Lcom/google/common/io/Closer;
/* 246:    */     //   20: astore 4
/* 247:    */     //   22: aload 4
/* 248:    */     //   24: aload_0
/* 249:    */     //   25: invokevirtual 228	com/google/common/io/ByteSource:openStream	()Ljava/io/InputStream;
/* 250:    */     //   28: invokevirtual 244	com/google/common/io/Closer:register	(Ljava/io/Closeable;)Ljava/io/Closeable;
/* 251:    */     //   31: checkcast 123	java/io/InputStream
/* 252:    */     //   34: astore 5
/* 253:    */     //   36: aload 4
/* 254:    */     //   38: aload_1
/* 255:    */     //   39: invokevirtual 228	com/google/common/io/ByteSource:openStream	()Ljava/io/InputStream;
/* 256:    */     //   42: invokevirtual 244	com/google/common/io/Closer:register	(Ljava/io/Closeable;)Ljava/io/Closeable;
/* 257:    */     //   45: checkcast 123	java/io/InputStream
/* 258:    */     //   48: astore 6
/* 259:    */     //   50: aload 5
/* 260:    */     //   52: aload_2
/* 261:    */     //   53: iconst_0
/* 262:    */     //   54: sipush 4096
/* 263:    */     //   57: invokestatic 239	com/google/common/io/ByteStreams:read	(Ljava/io/InputStream;[BII)I
/* 264:    */     //   60: istore 7
/* 265:    */     //   62: aload 6
/* 266:    */     //   64: aload_3
/* 267:    */     //   65: iconst_0
/* 268:    */     //   66: sipush 4096
/* 269:    */     //   69: invokestatic 239	com/google/common/io/ByteStreams:read	(Ljava/io/InputStream;[BII)I
/* 270:    */     //   72: istore 8
/* 271:    */     //   74: iload 7
/* 272:    */     //   76: iload 8
/* 273:    */     //   78: if_icmpne +11 -> 89
/* 274:    */     //   81: aload_2
/* 275:    */     //   82: aload_3
/* 276:    */     //   83: invokestatic 254	java/util/Arrays:equals	([B[B)Z
/* 277:    */     //   86: ifne +14 -> 100
/* 278:    */     //   89: iconst_0
/* 279:    */     //   90: istore 9
/* 280:    */     //   92: aload 4
/* 281:    */     //   94: invokevirtual 242	com/google/common/io/Closer:close	()V
/* 282:    */     //   97: iload 9
/* 283:    */     //   99: ireturn
/* 284:    */     //   100: iload 7
/* 285:    */     //   102: sipush 4096
/* 286:    */     //   105: if_icmpeq +14 -> 119
/* 287:    */     //   108: iconst_1
/* 288:    */     //   109: istore 9
/* 289:    */     //   111: aload 4
/* 290:    */     //   113: invokevirtual 242	com/google/common/io/Closer:close	()V
/* 291:    */     //   116: iload 9
/* 292:    */     //   118: ireturn
/* 293:    */     //   119: goto -69 -> 50
/* 294:    */     //   122: astore 5
/* 295:    */     //   124: aload 4
/* 296:    */     //   126: aload 5
/* 297:    */     //   128: invokevirtual 245	com/google/common/io/Closer:rethrow	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
/* 298:    */     //   131: athrow
/* 299:    */     //   132: astore 10
/* 300:    */     //   134: aload 4
/* 301:    */     //   136: invokevirtual 242	com/google/common/io/Closer:close	()V
/* 302:    */     //   139: aload 10
/* 303:    */     //   141: athrow
/* 304:    */     // Line number table:
/* 305:    */     //   Java source line #324	-> byte code offset #0
/* 306:    */     //   Java source line #326	-> byte code offset #5
/* 307:    */     //   Java source line #327	-> byte code offset #11
/* 308:    */     //   Java source line #329	-> byte code offset #17
/* 309:    */     //   Java source line #331	-> byte code offset #22
/* 310:    */     //   Java source line #332	-> byte code offset #36
/* 311:    */     //   Java source line #334	-> byte code offset #50
/* 312:    */     //   Java source line #335	-> byte code offset #62
/* 313:    */     //   Java source line #336	-> byte code offset #74
/* 314:    */     //   Java source line #337	-> byte code offset #89
/* 315:    */     //   Java source line #345	-> byte code offset #92
/* 316:    */     //   Java source line #338	-> byte code offset #100
/* 317:    */     //   Java source line #339	-> byte code offset #108
/* 318:    */     //   Java source line #345	-> byte code offset #111
/* 319:    */     //   Java source line #341	-> byte code offset #119
/* 320:    */     //   Java source line #342	-> byte code offset #122
/* 321:    */     //   Java source line #343	-> byte code offset #124
/* 322:    */     //   Java source line #345	-> byte code offset #132
/* 323:    */     // Local variable table:
/* 324:    */     //   start	length	slot	name	signature
/* 325:    */     //   0	142	0	this	ByteSource
/* 326:    */     //   0	142	1	other	ByteSource
/* 327:    */     //   10	72	2	buf1	byte[]
/* 328:    */     //   16	67	3	buf2	byte[]
/* 329:    */     //   20	115	4	closer	Closer
/* 330:    */     //   34	17	5	in1	InputStream
/* 331:    */     //   122	5	5	e	Throwable
/* 332:    */     //   48	15	6	in2	InputStream
/* 333:    */     //   60	41	7	read1	int
/* 334:    */     //   72	5	8	read2	int
/* 335:    */     //   90	27	9	bool	boolean
/* 336:    */     //   132	8	10	localObject	Object
/* 337:    */     // Exception table:
/* 338:    */     //   from	to	target	type
/* 339:    */     //   22	92	122	java/lang/Throwable
/* 340:    */     //   100	111	122	java/lang/Throwable
/* 341:    */     //   119	122	122	java/lang/Throwable
/* 342:    */     //   22	92	132	finally
/* 343:    */     //   100	111	132	finally
/* 344:    */     //   119	134	132	finally
/* 345:    */   }
/* 346:    */   
/* 347:    */   public static ByteSource concat(Iterable<? extends ByteSource> sources)
/* 348:    */   {
/* 349:361 */     return new ConcatenatedByteSource(sources);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public static ByteSource concat(Iterator<? extends ByteSource> sources)
/* 353:    */   {
/* 354:383 */     return concat(ImmutableList.copyOf(sources));
/* 355:    */   }
/* 356:    */   
/* 357:    */   public static ByteSource concat(ByteSource... sources)
/* 358:    */   {
/* 359:399 */     return concat(ImmutableList.copyOf(sources));
/* 360:    */   }
/* 361:    */   
/* 362:    */   public static ByteSource wrap(byte[] b)
/* 363:    */   {
/* 364:409 */     return new ByteArrayByteSource(b);
/* 365:    */   }
/* 366:    */   
/* 367:    */   public static ByteSource empty()
/* 368:    */   {
/* 369:418 */     return EmptyByteSource.INSTANCE;
/* 370:    */   }
/* 371:    */   
/* 372:    */   private final class AsCharSource
/* 373:    */     extends CharSource
/* 374:    */   {
/* 375:    */     private final Charset charset;
/* 376:    */     
/* 377:    */     private AsCharSource(Charset charset)
/* 378:    */     {
/* 379:430 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/* 380:    */     }
/* 381:    */     
/* 382:    */     public Reader openStream()
/* 383:    */       throws IOException
/* 384:    */     {
/* 385:435 */       return new InputStreamReader(ByteSource.this.openStream(), this.charset);
/* 386:    */     }
/* 387:    */     
/* 388:    */     public String toString()
/* 389:    */     {
/* 390:440 */       return ByteSource.this.toString() + ".asCharSource(" + this.charset + ")";
/* 391:    */     }
/* 392:    */   }
/* 393:    */   
/* 394:    */   private final class SlicedByteSource
/* 395:    */     extends ByteSource
/* 396:    */   {
/* 397:    */     private final long offset;
/* 398:    */     private final long length;
/* 399:    */     
/* 400:    */     private SlicedByteSource(long offset, long length)
/* 401:    */     {
/* 402:453 */       Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[] { Long.valueOf(offset) });
/* 403:454 */       Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[] { Long.valueOf(length) });
/* 404:455 */       this.offset = offset;
/* 405:456 */       this.length = length;
/* 406:    */     }
/* 407:    */     
/* 408:    */     public InputStream openStream()
/* 409:    */       throws IOException
/* 410:    */     {
/* 411:461 */       return sliceStream(ByteSource.this.openStream());
/* 412:    */     }
/* 413:    */     
/* 414:    */     public InputStream openBufferedStream()
/* 415:    */       throws IOException
/* 416:    */     {
/* 417:466 */       return sliceStream(ByteSource.this.openBufferedStream());
/* 418:    */     }
/* 419:    */     
/* 420:    */     private InputStream sliceStream(InputStream in)
/* 421:    */       throws IOException
/* 422:    */     {
/* 423:470 */       if (this.offset > 0L) {
/* 424:    */         try
/* 425:    */         {
/* 426:472 */           ByteStreams.skipFully(in, this.offset);
/* 427:    */         }
/* 428:    */         catch (Throwable e)
/* 429:    */         {
/* 430:474 */           Closer closer = Closer.create();
/* 431:475 */           closer.register(in);
/* 432:    */           try
/* 433:    */           {
/* 434:477 */             throw closer.rethrow(e);
/* 435:    */           }
/* 436:    */           finally
/* 437:    */           {
/* 438:479 */             closer.close();
/* 439:    */           }
/* 440:    */         }
/* 441:    */       }
/* 442:483 */       return ByteStreams.limit(in, this.length);
/* 443:    */     }
/* 444:    */     
/* 445:    */     public ByteSource slice(long offset, long length)
/* 446:    */     {
/* 447:488 */       Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[] { Long.valueOf(offset) });
/* 448:489 */       Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[] { Long.valueOf(length) });
/* 449:490 */       long maxLength = this.length - offset;
/* 450:491 */       return ByteSource.this.slice(this.offset + offset, Math.min(length, maxLength));
/* 451:    */     }
/* 452:    */     
/* 453:    */     public boolean isEmpty()
/* 454:    */       throws IOException
/* 455:    */     {
/* 456:496 */       return (this.length == 0L) || (super.isEmpty());
/* 457:    */     }
/* 458:    */     
/* 459:    */     public String toString()
/* 460:    */     {
/* 461:501 */       return ByteSource.this.toString() + ".slice(" + this.offset + ", " + this.length + ")";
/* 462:    */     }
/* 463:    */   }
/* 464:    */   
/* 465:    */   private static class ByteArrayByteSource
/* 466:    */     extends ByteSource
/* 467:    */   {
/* 468:    */     protected final byte[] bytes;
/* 469:    */     
/* 470:    */     protected ByteArrayByteSource(byte[] bytes)
/* 471:    */     {
/* 472:510 */       this.bytes = ((byte[])Preconditions.checkNotNull(bytes));
/* 473:    */     }
/* 474:    */     
/* 475:    */     public InputStream openStream()
/* 476:    */     {
/* 477:515 */       return new ByteArrayInputStream(this.bytes);
/* 478:    */     }
/* 479:    */     
/* 480:    */     public InputStream openBufferedStream()
/* 481:    */       throws IOException
/* 482:    */     {
/* 483:520 */       return openStream();
/* 484:    */     }
/* 485:    */     
/* 486:    */     public boolean isEmpty()
/* 487:    */     {
/* 488:525 */       return this.bytes.length == 0;
/* 489:    */     }
/* 490:    */     
/* 491:    */     public long size()
/* 492:    */     {
/* 493:530 */       return this.bytes.length;
/* 494:    */     }
/* 495:    */     
/* 496:    */     public byte[] read()
/* 497:    */     {
/* 498:535 */       return (byte[])this.bytes.clone();
/* 499:    */     }
/* 500:    */     
/* 501:    */     public long copyTo(OutputStream output)
/* 502:    */       throws IOException
/* 503:    */     {
/* 504:540 */       output.write(this.bytes);
/* 505:541 */       return this.bytes.length;
/* 506:    */     }
/* 507:    */     
/* 508:    */     public <T> T read(ByteProcessor<T> processor)
/* 509:    */       throws IOException
/* 510:    */     {
/* 511:546 */       processor.processBytes(this.bytes, 0, this.bytes.length);
/* 512:547 */       return processor.getResult();
/* 513:    */     }
/* 514:    */     
/* 515:    */     public HashCode hash(HashFunction hashFunction)
/* 516:    */       throws IOException
/* 517:    */     {
/* 518:552 */       return hashFunction.hashBytes(this.bytes);
/* 519:    */     }
/* 520:    */     
/* 521:    */     public String toString()
/* 522:    */     {
/* 523:559 */       return "ByteSource.wrap(" + Ascii.truncate(BaseEncoding.base16().encode(this.bytes), 30, "...") + ")";
/* 524:    */     }
/* 525:    */   }
/* 526:    */   
/* 527:    */   private static final class EmptyByteSource
/* 528:    */     extends ByteSource.ByteArrayByteSource
/* 529:    */   {
/* 530:566 */     private static final EmptyByteSource INSTANCE = new EmptyByteSource();
/* 531:    */     
/* 532:    */     private EmptyByteSource()
/* 533:    */     {
/* 534:569 */       super();
/* 535:    */     }
/* 536:    */     
/* 537:    */     public CharSource asCharSource(Charset charset)
/* 538:    */     {
/* 539:574 */       Preconditions.checkNotNull(charset);
/* 540:575 */       return CharSource.empty();
/* 541:    */     }
/* 542:    */     
/* 543:    */     public byte[] read()
/* 544:    */     {
/* 545:580 */       return this.bytes;
/* 546:    */     }
/* 547:    */     
/* 548:    */     public String toString()
/* 549:    */     {
/* 550:585 */       return "ByteSource.empty()";
/* 551:    */     }
/* 552:    */   }
/* 553:    */   
/* 554:    */   private static final class ConcatenatedByteSource
/* 555:    */     extends ByteSource
/* 556:    */   {
/* 557:    */     private final Iterable<? extends ByteSource> sources;
/* 558:    */     
/* 559:    */     ConcatenatedByteSource(Iterable<? extends ByteSource> sources)
/* 560:    */     {
/* 561:594 */       this.sources = ((Iterable)Preconditions.checkNotNull(sources));
/* 562:    */     }
/* 563:    */     
/* 564:    */     public InputStream openStream()
/* 565:    */       throws IOException
/* 566:    */     {
/* 567:599 */       return new MultiInputStream(this.sources.iterator());
/* 568:    */     }
/* 569:    */     
/* 570:    */     public boolean isEmpty()
/* 571:    */       throws IOException
/* 572:    */     {
/* 573:604 */       for (ByteSource source : this.sources) {
/* 574:605 */         if (!source.isEmpty()) {
/* 575:606 */           return false;
/* 576:    */         }
/* 577:    */       }
/* 578:609 */       return true;
/* 579:    */     }
/* 580:    */     
/* 581:    */     public long size()
/* 582:    */       throws IOException
/* 583:    */     {
/* 584:614 */       long result = 0L;
/* 585:615 */       for (ByteSource source : this.sources) {
/* 586:616 */         result += source.size();
/* 587:    */       }
/* 588:618 */       return result;
/* 589:    */     }
/* 590:    */     
/* 591:    */     public String toString()
/* 592:    */     {
/* 593:623 */       return "ByteSource.concat(" + this.sources + ")";
/* 594:    */     }
/* 595:    */   }
/* 596:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.ByteSource
 * JD-Core Version:    0.7.0.1
 */
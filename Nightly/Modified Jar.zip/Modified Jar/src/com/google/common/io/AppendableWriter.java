/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.Closeable;
/*   5:    */ import java.io.Flushable;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.Writer;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ class AppendableWriter
/*  11:    */   extends Writer
/*  12:    */ {
/*  13:    */   private final Appendable target;
/*  14:    */   private boolean closed;
/*  15:    */   
/*  16:    */   AppendableWriter(Appendable target)
/*  17:    */   {
/*  18: 47 */     this.target = ((Appendable)Preconditions.checkNotNull(target));
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void write(char[] cbuf, int off, int len)
/*  22:    */     throws IOException
/*  23:    */   {
/*  24: 56 */     checkNotClosed();
/*  25:    */     
/*  26:    */ 
/*  27: 59 */     this.target.append(new String(cbuf, off, len));
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void flush()
/*  31:    */     throws IOException
/*  32:    */   {
/*  33: 63 */     checkNotClosed();
/*  34: 64 */     if ((this.target instanceof Flushable)) {
/*  35: 65 */       ((Flushable)this.target).flush();
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void close()
/*  40:    */     throws IOException
/*  41:    */   {
/*  42: 70 */     this.closed = true;
/*  43: 71 */     if ((this.target instanceof Closeable)) {
/*  44: 72 */       ((Closeable)this.target).close();
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void write(int c)
/*  49:    */     throws IOException
/*  50:    */   {
/*  51: 82 */     checkNotClosed();
/*  52: 83 */     this.target.append((char)c);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void write(@Nullable String str)
/*  56:    */     throws IOException
/*  57:    */   {
/*  58: 87 */     checkNotClosed();
/*  59: 88 */     this.target.append(str);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void write(@Nullable String str, int off, int len)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65: 92 */     checkNotClosed();
/*  66:    */     
/*  67: 94 */     this.target.append(str, off, off + len);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Writer append(char c)
/*  71:    */     throws IOException
/*  72:    */   {
/*  73: 98 */     checkNotClosed();
/*  74: 99 */     this.target.append(c);
/*  75:100 */     return this;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Writer append(@Nullable CharSequence charSeq)
/*  79:    */     throws IOException
/*  80:    */   {
/*  81:104 */     checkNotClosed();
/*  82:105 */     this.target.append(charSeq);
/*  83:106 */     return this;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Writer append(@Nullable CharSequence charSeq, int start, int end)
/*  87:    */     throws IOException
/*  88:    */   {
/*  89:111 */     checkNotClosed();
/*  90:112 */     this.target.append(charSeq, start, end);
/*  91:113 */     return this;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private void checkNotClosed()
/*  95:    */     throws IOException
/*  96:    */   {
/*  97:117 */     if (this.closed) {
/*  98:118 */       throw new IOException("Cannot write to a closed writer.");
/*  99:    */     }
/* 100:    */   }
/* 101:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.AppendableWriter
 * JD-Core Version:    0.7.0.1
 */
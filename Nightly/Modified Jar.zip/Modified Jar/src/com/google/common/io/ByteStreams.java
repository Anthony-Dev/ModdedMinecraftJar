/*    1:     */ package com.google.common.io;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Function;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.collect.Iterables;
/*    7:     */ import com.google.common.hash.HashCode;
/*    8:     */ import com.google.common.hash.HashFunction;
/*    9:     */ import java.io.ByteArrayInputStream;
/*   10:     */ import java.io.ByteArrayOutputStream;
/*   11:     */ import java.io.Closeable;
/*   12:     */ import java.io.DataInput;
/*   13:     */ import java.io.DataInputStream;
/*   14:     */ import java.io.DataOutput;
/*   15:     */ import java.io.DataOutputStream;
/*   16:     */ import java.io.EOFException;
/*   17:     */ import java.io.FilterInputStream;
/*   18:     */ import java.io.IOException;
/*   19:     */ import java.io.InputStream;
/*   20:     */ import java.io.OutputStream;
/*   21:     */ import java.nio.ByteBuffer;
/*   22:     */ import java.nio.channels.ReadableByteChannel;
/*   23:     */ import java.nio.channels.WritableByteChannel;
/*   24:     */ import java.util.Arrays;
/*   25:     */ 
/*   26:     */ @Beta
/*   27:     */ public final class ByteStreams
/*   28:     */ {
/*   29:     */   private static final int BUF_SIZE = 4096;
/*   30:     */   
/*   31:     */   @Deprecated
/*   32:     */   public static InputSupplier<ByteArrayInputStream> newInputStreamSupplier(byte[] b)
/*   33:     */   {
/*   34:  70 */     return asInputSupplier(ByteSource.wrap(b));
/*   35:     */   }
/*   36:     */   
/*   37:     */   @Deprecated
/*   38:     */   public static InputSupplier<ByteArrayInputStream> newInputStreamSupplier(byte[] b, int off, int len)
/*   39:     */   {
/*   40:  87 */     return asInputSupplier(ByteSource.wrap(b).slice(off, len));
/*   41:     */   }
/*   42:     */   
/*   43:     */   @Deprecated
/*   44:     */   public static void write(byte[] from, OutputSupplier<? extends OutputStream> to)
/*   45:     */     throws IOException
/*   46:     */   {
/*   47: 102 */     asByteSink(to).write(from);
/*   48:     */   }
/*   49:     */   
/*   50:     */   @Deprecated
/*   51:     */   public static long copy(InputSupplier<? extends InputStream> from, OutputSupplier<? extends OutputStream> to)
/*   52:     */     throws IOException
/*   53:     */   {
/*   54: 119 */     return asByteSource(from).copyTo(asByteSink(to));
/*   55:     */   }
/*   56:     */   
/*   57:     */   @Deprecated
/*   58:     */   public static long copy(InputSupplier<? extends InputStream> from, OutputStream to)
/*   59:     */     throws IOException
/*   60:     */   {
/*   61: 137 */     return asByteSource(from).copyTo(to);
/*   62:     */   }
/*   63:     */   
/*   64:     */   @Deprecated
/*   65:     */   public static long copy(InputStream from, OutputSupplier<? extends OutputStream> to)
/*   66:     */     throws IOException
/*   67:     */   {
/*   68: 156 */     return asByteSink(to).writeFrom(from);
/*   69:     */   }
/*   70:     */   
/*   71:     */   public static long copy(InputStream from, OutputStream to)
/*   72:     */     throws IOException
/*   73:     */   {
/*   74: 170 */     Preconditions.checkNotNull(from);
/*   75: 171 */     Preconditions.checkNotNull(to);
/*   76: 172 */     byte[] buf = new byte[4096];
/*   77: 173 */     long total = 0L;
/*   78:     */     for (;;)
/*   79:     */     {
/*   80: 175 */       int r = from.read(buf);
/*   81: 176 */       if (r == -1) {
/*   82:     */         break;
/*   83:     */       }
/*   84: 179 */       to.write(buf, 0, r);
/*   85: 180 */       total += r;
/*   86:     */     }
/*   87: 182 */     return total;
/*   88:     */   }
/*   89:     */   
/*   90:     */   public static long copy(ReadableByteChannel from, WritableByteChannel to)
/*   91:     */     throws IOException
/*   92:     */   {
/*   93: 196 */     Preconditions.checkNotNull(from);
/*   94: 197 */     Preconditions.checkNotNull(to);
/*   95: 198 */     ByteBuffer buf = ByteBuffer.allocate(4096);
/*   96: 199 */     long total = 0L;
/*   97: 200 */     while (from.read(buf) != -1)
/*   98:     */     {
/*   99: 201 */       buf.flip();
/*  100: 202 */       while (buf.hasRemaining()) {
/*  101: 203 */         total += to.write(buf);
/*  102:     */       }
/*  103: 205 */       buf.clear();
/*  104:     */     }
/*  105: 207 */     return total;
/*  106:     */   }
/*  107:     */   
/*  108:     */   public static byte[] toByteArray(InputStream in)
/*  109:     */     throws IOException
/*  110:     */   {
/*  111: 219 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  112: 220 */     copy(in, out);
/*  113: 221 */     return out.toByteArray();
/*  114:     */   }
/*  115:     */   
/*  116:     */   static byte[] toByteArray(InputStream in, int expectedSize)
/*  117:     */     throws IOException
/*  118:     */   {
/*  119: 232 */     byte[] bytes = new byte[expectedSize];
/*  120: 233 */     int remaining = expectedSize;
/*  121: 235 */     while (remaining > 0)
/*  122:     */     {
/*  123: 236 */       int off = expectedSize - remaining;
/*  124: 237 */       int read = in.read(bytes, off, remaining);
/*  125: 238 */       if (read == -1) {
/*  126: 241 */         return Arrays.copyOf(bytes, off);
/*  127:     */       }
/*  128: 243 */       remaining -= read;
/*  129:     */     }
/*  130: 247 */     int b = in.read();
/*  131: 248 */     if (b == -1) {
/*  132: 249 */       return bytes;
/*  133:     */     }
/*  134: 253 */     FastByteArrayOutputStream out = new FastByteArrayOutputStream(null);
/*  135: 254 */     out.write(b);
/*  136: 255 */     copy(in, out);
/*  137:     */     
/*  138: 257 */     byte[] result = new byte[bytes.length + out.size()];
/*  139: 258 */     System.arraycopy(bytes, 0, result, 0, bytes.length);
/*  140: 259 */     out.writeTo(result, bytes.length);
/*  141: 260 */     return result;
/*  142:     */   }
/*  143:     */   
/*  144:     */   private static final class FastByteArrayOutputStream
/*  145:     */     extends ByteArrayOutputStream
/*  146:     */   {
/*  147:     */     void writeTo(byte[] b, int off)
/*  148:     */     {
/*  149: 273 */       System.arraycopy(this.buf, 0, b, off, this.count);
/*  150:     */     }
/*  151:     */   }
/*  152:     */   
/*  153:     */   @Deprecated
/*  154:     */   public static byte[] toByteArray(InputSupplier<? extends InputStream> supplier)
/*  155:     */     throws IOException
/*  156:     */   {
/*  157: 288 */     return asByteSource(supplier).read();
/*  158:     */   }
/*  159:     */   
/*  160:     */   public static ByteArrayDataInput newDataInput(byte[] bytes)
/*  161:     */   {
/*  162: 296 */     return newDataInput(new ByteArrayInputStream(bytes));
/*  163:     */   }
/*  164:     */   
/*  165:     */   public static ByteArrayDataInput newDataInput(byte[] bytes, int start)
/*  166:     */   {
/*  167: 307 */     Preconditions.checkPositionIndex(start, bytes.length);
/*  168: 308 */     return newDataInput(new ByteArrayInputStream(bytes, start, bytes.length - start));
/*  169:     */   }
/*  170:     */   
/*  171:     */   public static ByteArrayDataInput newDataInput(ByteArrayInputStream byteArrayInputStream)
/*  172:     */   {
/*  173: 321 */     return new ByteArrayDataInputStream((ByteArrayInputStream)Preconditions.checkNotNull(byteArrayInputStream));
/*  174:     */   }
/*  175:     */   
/*  176:     */   private static class ByteArrayDataInputStream
/*  177:     */     implements ByteArrayDataInput
/*  178:     */   {
/*  179:     */     final DataInput input;
/*  180:     */     
/*  181:     */     ByteArrayDataInputStream(ByteArrayInputStream byteArrayInputStream)
/*  182:     */     {
/*  183: 328 */       this.input = new DataInputStream(byteArrayInputStream);
/*  184:     */     }
/*  185:     */     
/*  186:     */     public void readFully(byte[] b)
/*  187:     */     {
/*  188:     */       try
/*  189:     */       {
/*  190: 333 */         this.input.readFully(b);
/*  191:     */       }
/*  192:     */       catch (IOException e)
/*  193:     */       {
/*  194: 335 */         throw new IllegalStateException(e);
/*  195:     */       }
/*  196:     */     }
/*  197:     */     
/*  198:     */     public void readFully(byte[] b, int off, int len)
/*  199:     */     {
/*  200:     */       try
/*  201:     */       {
/*  202: 341 */         this.input.readFully(b, off, len);
/*  203:     */       }
/*  204:     */       catch (IOException e)
/*  205:     */       {
/*  206: 343 */         throw new IllegalStateException(e);
/*  207:     */       }
/*  208:     */     }
/*  209:     */     
/*  210:     */     public int skipBytes(int n)
/*  211:     */     {
/*  212:     */       try
/*  213:     */       {
/*  214: 349 */         return this.input.skipBytes(n);
/*  215:     */       }
/*  216:     */       catch (IOException e)
/*  217:     */       {
/*  218: 351 */         throw new IllegalStateException(e);
/*  219:     */       }
/*  220:     */     }
/*  221:     */     
/*  222:     */     public boolean readBoolean()
/*  223:     */     {
/*  224:     */       try
/*  225:     */       {
/*  226: 357 */         return this.input.readBoolean();
/*  227:     */       }
/*  228:     */       catch (IOException e)
/*  229:     */       {
/*  230: 359 */         throw new IllegalStateException(e);
/*  231:     */       }
/*  232:     */     }
/*  233:     */     
/*  234:     */     public byte readByte()
/*  235:     */     {
/*  236:     */       try
/*  237:     */       {
/*  238: 365 */         return this.input.readByte();
/*  239:     */       }
/*  240:     */       catch (EOFException e)
/*  241:     */       {
/*  242: 367 */         throw new IllegalStateException(e);
/*  243:     */       }
/*  244:     */       catch (IOException impossible)
/*  245:     */       {
/*  246: 369 */         throw new AssertionError(impossible);
/*  247:     */       }
/*  248:     */     }
/*  249:     */     
/*  250:     */     public int readUnsignedByte()
/*  251:     */     {
/*  252:     */       try
/*  253:     */       {
/*  254: 375 */         return this.input.readUnsignedByte();
/*  255:     */       }
/*  256:     */       catch (IOException e)
/*  257:     */       {
/*  258: 377 */         throw new IllegalStateException(e);
/*  259:     */       }
/*  260:     */     }
/*  261:     */     
/*  262:     */     public short readShort()
/*  263:     */     {
/*  264:     */       try
/*  265:     */       {
/*  266: 383 */         return this.input.readShort();
/*  267:     */       }
/*  268:     */       catch (IOException e)
/*  269:     */       {
/*  270: 385 */         throw new IllegalStateException(e);
/*  271:     */       }
/*  272:     */     }
/*  273:     */     
/*  274:     */     public int readUnsignedShort()
/*  275:     */     {
/*  276:     */       try
/*  277:     */       {
/*  278: 391 */         return this.input.readUnsignedShort();
/*  279:     */       }
/*  280:     */       catch (IOException e)
/*  281:     */       {
/*  282: 393 */         throw new IllegalStateException(e);
/*  283:     */       }
/*  284:     */     }
/*  285:     */     
/*  286:     */     public char readChar()
/*  287:     */     {
/*  288:     */       try
/*  289:     */       {
/*  290: 399 */         return this.input.readChar();
/*  291:     */       }
/*  292:     */       catch (IOException e)
/*  293:     */       {
/*  294: 401 */         throw new IllegalStateException(e);
/*  295:     */       }
/*  296:     */     }
/*  297:     */     
/*  298:     */     public int readInt()
/*  299:     */     {
/*  300:     */       try
/*  301:     */       {
/*  302: 407 */         return this.input.readInt();
/*  303:     */       }
/*  304:     */       catch (IOException e)
/*  305:     */       {
/*  306: 409 */         throw new IllegalStateException(e);
/*  307:     */       }
/*  308:     */     }
/*  309:     */     
/*  310:     */     public long readLong()
/*  311:     */     {
/*  312:     */       try
/*  313:     */       {
/*  314: 415 */         return this.input.readLong();
/*  315:     */       }
/*  316:     */       catch (IOException e)
/*  317:     */       {
/*  318: 417 */         throw new IllegalStateException(e);
/*  319:     */       }
/*  320:     */     }
/*  321:     */     
/*  322:     */     public float readFloat()
/*  323:     */     {
/*  324:     */       try
/*  325:     */       {
/*  326: 423 */         return this.input.readFloat();
/*  327:     */       }
/*  328:     */       catch (IOException e)
/*  329:     */       {
/*  330: 425 */         throw new IllegalStateException(e);
/*  331:     */       }
/*  332:     */     }
/*  333:     */     
/*  334:     */     public double readDouble()
/*  335:     */     {
/*  336:     */       try
/*  337:     */       {
/*  338: 431 */         return this.input.readDouble();
/*  339:     */       }
/*  340:     */       catch (IOException e)
/*  341:     */       {
/*  342: 433 */         throw new IllegalStateException(e);
/*  343:     */       }
/*  344:     */     }
/*  345:     */     
/*  346:     */     public String readLine()
/*  347:     */     {
/*  348:     */       try
/*  349:     */       {
/*  350: 439 */         return this.input.readLine();
/*  351:     */       }
/*  352:     */       catch (IOException e)
/*  353:     */       {
/*  354: 441 */         throw new IllegalStateException(e);
/*  355:     */       }
/*  356:     */     }
/*  357:     */     
/*  358:     */     public String readUTF()
/*  359:     */     {
/*  360:     */       try
/*  361:     */       {
/*  362: 447 */         return this.input.readUTF();
/*  363:     */       }
/*  364:     */       catch (IOException e)
/*  365:     */       {
/*  366: 449 */         throw new IllegalStateException(e);
/*  367:     */       }
/*  368:     */     }
/*  369:     */   }
/*  370:     */   
/*  371:     */   public static ByteArrayDataOutput newDataOutput()
/*  372:     */   {
/*  373: 458 */     return newDataOutput(new ByteArrayOutputStream());
/*  374:     */   }
/*  375:     */   
/*  376:     */   public static ByteArrayDataOutput newDataOutput(int size)
/*  377:     */   {
/*  378: 468 */     Preconditions.checkArgument(size >= 0, "Invalid size: %s", new Object[] { Integer.valueOf(size) });
/*  379: 469 */     return newDataOutput(new ByteArrayOutputStream(size));
/*  380:     */   }
/*  381:     */   
/*  382:     */   public static ByteArrayDataOutput newDataOutput(ByteArrayOutputStream byteArrayOutputSteam)
/*  383:     */   {
/*  384: 488 */     return new ByteArrayDataOutputStream((ByteArrayOutputStream)Preconditions.checkNotNull(byteArrayOutputSteam));
/*  385:     */   }
/*  386:     */   
/*  387:     */   private static class ByteArrayDataOutputStream
/*  388:     */     implements ByteArrayDataOutput
/*  389:     */   {
/*  390:     */     final DataOutput output;
/*  391:     */     final ByteArrayOutputStream byteArrayOutputSteam;
/*  392:     */     
/*  393:     */     ByteArrayDataOutputStream(ByteArrayOutputStream byteArrayOutputSteam)
/*  394:     */     {
/*  395: 499 */       this.byteArrayOutputSteam = byteArrayOutputSteam;
/*  396: 500 */       this.output = new DataOutputStream(byteArrayOutputSteam);
/*  397:     */     }
/*  398:     */     
/*  399:     */     public void write(int b)
/*  400:     */     {
/*  401:     */       try
/*  402:     */       {
/*  403: 505 */         this.output.write(b);
/*  404:     */       }
/*  405:     */       catch (IOException impossible)
/*  406:     */       {
/*  407: 507 */         throw new AssertionError(impossible);
/*  408:     */       }
/*  409:     */     }
/*  410:     */     
/*  411:     */     public void write(byte[] b)
/*  412:     */     {
/*  413:     */       try
/*  414:     */       {
/*  415: 513 */         this.output.write(b);
/*  416:     */       }
/*  417:     */       catch (IOException impossible)
/*  418:     */       {
/*  419: 515 */         throw new AssertionError(impossible);
/*  420:     */       }
/*  421:     */     }
/*  422:     */     
/*  423:     */     public void write(byte[] b, int off, int len)
/*  424:     */     {
/*  425:     */       try
/*  426:     */       {
/*  427: 521 */         this.output.write(b, off, len);
/*  428:     */       }
/*  429:     */       catch (IOException impossible)
/*  430:     */       {
/*  431: 523 */         throw new AssertionError(impossible);
/*  432:     */       }
/*  433:     */     }
/*  434:     */     
/*  435:     */     public void writeBoolean(boolean v)
/*  436:     */     {
/*  437:     */       try
/*  438:     */       {
/*  439: 529 */         this.output.writeBoolean(v);
/*  440:     */       }
/*  441:     */       catch (IOException impossible)
/*  442:     */       {
/*  443: 531 */         throw new AssertionError(impossible);
/*  444:     */       }
/*  445:     */     }
/*  446:     */     
/*  447:     */     public void writeByte(int v)
/*  448:     */     {
/*  449:     */       try
/*  450:     */       {
/*  451: 537 */         this.output.writeByte(v);
/*  452:     */       }
/*  453:     */       catch (IOException impossible)
/*  454:     */       {
/*  455: 539 */         throw new AssertionError(impossible);
/*  456:     */       }
/*  457:     */     }
/*  458:     */     
/*  459:     */     public void writeBytes(String s)
/*  460:     */     {
/*  461:     */       try
/*  462:     */       {
/*  463: 545 */         this.output.writeBytes(s);
/*  464:     */       }
/*  465:     */       catch (IOException impossible)
/*  466:     */       {
/*  467: 547 */         throw new AssertionError(impossible);
/*  468:     */       }
/*  469:     */     }
/*  470:     */     
/*  471:     */     public void writeChar(int v)
/*  472:     */     {
/*  473:     */       try
/*  474:     */       {
/*  475: 553 */         this.output.writeChar(v);
/*  476:     */       }
/*  477:     */       catch (IOException impossible)
/*  478:     */       {
/*  479: 555 */         throw new AssertionError(impossible);
/*  480:     */       }
/*  481:     */     }
/*  482:     */     
/*  483:     */     public void writeChars(String s)
/*  484:     */     {
/*  485:     */       try
/*  486:     */       {
/*  487: 561 */         this.output.writeChars(s);
/*  488:     */       }
/*  489:     */       catch (IOException impossible)
/*  490:     */       {
/*  491: 563 */         throw new AssertionError(impossible);
/*  492:     */       }
/*  493:     */     }
/*  494:     */     
/*  495:     */     public void writeDouble(double v)
/*  496:     */     {
/*  497:     */       try
/*  498:     */       {
/*  499: 569 */         this.output.writeDouble(v);
/*  500:     */       }
/*  501:     */       catch (IOException impossible)
/*  502:     */       {
/*  503: 571 */         throw new AssertionError(impossible);
/*  504:     */       }
/*  505:     */     }
/*  506:     */     
/*  507:     */     public void writeFloat(float v)
/*  508:     */     {
/*  509:     */       try
/*  510:     */       {
/*  511: 577 */         this.output.writeFloat(v);
/*  512:     */       }
/*  513:     */       catch (IOException impossible)
/*  514:     */       {
/*  515: 579 */         throw new AssertionError(impossible);
/*  516:     */       }
/*  517:     */     }
/*  518:     */     
/*  519:     */     public void writeInt(int v)
/*  520:     */     {
/*  521:     */       try
/*  522:     */       {
/*  523: 585 */         this.output.writeInt(v);
/*  524:     */       }
/*  525:     */       catch (IOException impossible)
/*  526:     */       {
/*  527: 587 */         throw new AssertionError(impossible);
/*  528:     */       }
/*  529:     */     }
/*  530:     */     
/*  531:     */     public void writeLong(long v)
/*  532:     */     {
/*  533:     */       try
/*  534:     */       {
/*  535: 593 */         this.output.writeLong(v);
/*  536:     */       }
/*  537:     */       catch (IOException impossible)
/*  538:     */       {
/*  539: 595 */         throw new AssertionError(impossible);
/*  540:     */       }
/*  541:     */     }
/*  542:     */     
/*  543:     */     public void writeShort(int v)
/*  544:     */     {
/*  545:     */       try
/*  546:     */       {
/*  547: 601 */         this.output.writeShort(v);
/*  548:     */       }
/*  549:     */       catch (IOException impossible)
/*  550:     */       {
/*  551: 603 */         throw new AssertionError(impossible);
/*  552:     */       }
/*  553:     */     }
/*  554:     */     
/*  555:     */     public void writeUTF(String s)
/*  556:     */     {
/*  557:     */       try
/*  558:     */       {
/*  559: 609 */         this.output.writeUTF(s);
/*  560:     */       }
/*  561:     */       catch (IOException impossible)
/*  562:     */       {
/*  563: 611 */         throw new AssertionError(impossible);
/*  564:     */       }
/*  565:     */     }
/*  566:     */     
/*  567:     */     public byte[] toByteArray()
/*  568:     */     {
/*  569: 616 */       return this.byteArrayOutputSteam.toByteArray();
/*  570:     */     }
/*  571:     */   }
/*  572:     */   
/*  573: 620 */   private static final OutputStream NULL_OUTPUT_STREAM = new OutputStream()
/*  574:     */   {
/*  575:     */     public void write(int b) {}
/*  576:     */     
/*  577:     */     public void write(byte[] b)
/*  578:     */     {
/*  579: 627 */       Preconditions.checkNotNull(b);
/*  580:     */     }
/*  581:     */     
/*  582:     */     public void write(byte[] b, int off, int len)
/*  583:     */     {
/*  584: 631 */       Preconditions.checkNotNull(b);
/*  585:     */     }
/*  586:     */     
/*  587:     */     public String toString()
/*  588:     */     {
/*  589: 636 */       return "ByteStreams.nullOutputStream()";
/*  590:     */     }
/*  591:     */   };
/*  592:     */   
/*  593:     */   public static OutputStream nullOutputStream()
/*  594:     */   {
/*  595: 646 */     return NULL_OUTPUT_STREAM;
/*  596:     */   }
/*  597:     */   
/*  598:     */   public static InputStream limit(InputStream in, long limit)
/*  599:     */   {
/*  600: 659 */     return new LimitedInputStream(in, limit);
/*  601:     */   }
/*  602:     */   
/*  603:     */   private static final class LimitedInputStream
/*  604:     */     extends FilterInputStream
/*  605:     */   {
/*  606:     */     private long left;
/*  607: 665 */     private long mark = -1L;
/*  608:     */     
/*  609:     */     LimitedInputStream(InputStream in, long limit)
/*  610:     */     {
/*  611: 668 */       super();
/*  612: 669 */       Preconditions.checkNotNull(in);
/*  613: 670 */       Preconditions.checkArgument(limit >= 0L, "limit must be non-negative");
/*  614: 671 */       this.left = limit;
/*  615:     */     }
/*  616:     */     
/*  617:     */     public int available()
/*  618:     */       throws IOException
/*  619:     */     {
/*  620: 675 */       return (int)Math.min(this.in.available(), this.left);
/*  621:     */     }
/*  622:     */     
/*  623:     */     public synchronized void mark(int readLimit)
/*  624:     */     {
/*  625: 680 */       this.in.mark(readLimit);
/*  626: 681 */       this.mark = this.left;
/*  627:     */     }
/*  628:     */     
/*  629:     */     public int read()
/*  630:     */       throws IOException
/*  631:     */     {
/*  632: 685 */       if (this.left == 0L) {
/*  633: 686 */         return -1;
/*  634:     */       }
/*  635: 689 */       int result = this.in.read();
/*  636: 690 */       if (result != -1) {
/*  637: 691 */         this.left -= 1L;
/*  638:     */       }
/*  639: 693 */       return result;
/*  640:     */     }
/*  641:     */     
/*  642:     */     public int read(byte[] b, int off, int len)
/*  643:     */       throws IOException
/*  644:     */     {
/*  645: 697 */       if (this.left == 0L) {
/*  646: 698 */         return -1;
/*  647:     */       }
/*  648: 701 */       len = (int)Math.min(len, this.left);
/*  649: 702 */       int result = this.in.read(b, off, len);
/*  650: 703 */       if (result != -1) {
/*  651: 704 */         this.left -= result;
/*  652:     */       }
/*  653: 706 */       return result;
/*  654:     */     }
/*  655:     */     
/*  656:     */     public synchronized void reset()
/*  657:     */       throws IOException
/*  658:     */     {
/*  659: 710 */       if (!this.in.markSupported()) {
/*  660: 711 */         throw new IOException("Mark not supported");
/*  661:     */       }
/*  662: 713 */       if (this.mark == -1L) {
/*  663: 714 */         throw new IOException("Mark not set");
/*  664:     */       }
/*  665: 717 */       this.in.reset();
/*  666: 718 */       this.left = this.mark;
/*  667:     */     }
/*  668:     */     
/*  669:     */     public long skip(long n)
/*  670:     */       throws IOException
/*  671:     */     {
/*  672: 722 */       n = Math.min(n, this.left);
/*  673: 723 */       long skipped = this.in.skip(n);
/*  674: 724 */       this.left -= skipped;
/*  675: 725 */       return skipped;
/*  676:     */     }
/*  677:     */   }
/*  678:     */   
/*  679:     */   @Deprecated
/*  680:     */   public static long length(InputSupplier<? extends InputStream> supplier)
/*  681:     */     throws IOException
/*  682:     */   {
/*  683: 738 */     return asByteSource(supplier).size();
/*  684:     */   }
/*  685:     */   
/*  686:     */   @Deprecated
/*  687:     */   public static boolean equal(InputSupplier<? extends InputStream> supplier1, InputSupplier<? extends InputStream> supplier2)
/*  688:     */     throws IOException
/*  689:     */   {
/*  690: 751 */     return asByteSource(supplier1).contentEquals(asByteSource(supplier2));
/*  691:     */   }
/*  692:     */   
/*  693:     */   public static void readFully(InputStream in, byte[] b)
/*  694:     */     throws IOException
/*  695:     */   {
/*  696: 766 */     readFully(in, b, 0, b.length);
/*  697:     */   }
/*  698:     */   
/*  699:     */   public static void readFully(InputStream in, byte[] b, int off, int len)
/*  700:     */     throws IOException
/*  701:     */   {
/*  702: 785 */     int read = read(in, b, off, len);
/*  703: 786 */     if (read != len) {
/*  704: 787 */       throw new EOFException("reached end of stream after reading " + read + " bytes; " + len + " bytes expected");
/*  705:     */     }
/*  706:     */   }
/*  707:     */   
/*  708:     */   public static void skipFully(InputStream in, long n)
/*  709:     */     throws IOException
/*  710:     */   {
/*  711: 805 */     long toSkip = n;
/*  712: 806 */     while (n > 0L)
/*  713:     */     {
/*  714: 807 */       long amt = in.skip(n);
/*  715: 808 */       if (amt == 0L)
/*  716:     */       {
/*  717: 810 */         if (in.read() == -1)
/*  718:     */         {
/*  719: 811 */           long skipped = toSkip - n;
/*  720: 812 */           throw new EOFException("reached end of stream after skipping " + skipped + " bytes; " + toSkip + " bytes expected");
/*  721:     */         }
/*  722: 815 */         n -= 1L;
/*  723:     */       }
/*  724:     */       else
/*  725:     */       {
/*  726: 817 */         n -= amt;
/*  727:     */       }
/*  728:     */     }
/*  729:     */   }
/*  730:     */   
/*  731:     */   @Deprecated
/*  732:     */   public static <T> T readBytes(InputSupplier<? extends InputStream> supplier, ByteProcessor<T> processor)
/*  733:     */     throws IOException
/*  734:     */   {
/*  735: 836 */     Preconditions.checkNotNull(supplier);
/*  736: 837 */     Preconditions.checkNotNull(processor);
/*  737:     */     
/*  738: 839 */     Closer closer = Closer.create();
/*  739:     */     try
/*  740:     */     {
/*  741: 841 */       InputStream in = (InputStream)closer.register((Closeable)supplier.getInput());
/*  742: 842 */       return readBytes(in, processor);
/*  743:     */     }
/*  744:     */     catch (Throwable e)
/*  745:     */     {
/*  746: 844 */       throw closer.rethrow(e);
/*  747:     */     }
/*  748:     */     finally
/*  749:     */     {
/*  750: 846 */       closer.close();
/*  751:     */     }
/*  752:     */   }
/*  753:     */   
/*  754:     */   public static <T> T readBytes(InputStream input, ByteProcessor<T> processor)
/*  755:     */     throws IOException
/*  756:     */   {
/*  757: 861 */     Preconditions.checkNotNull(input);
/*  758: 862 */     Preconditions.checkNotNull(processor);
/*  759:     */     
/*  760: 864 */     byte[] buf = new byte[4096];
/*  761:     */     int read;
/*  762:     */     do
/*  763:     */     {
/*  764: 867 */       read = input.read(buf);
/*  765: 868 */     } while ((read != -1) && (processor.processBytes(buf, 0, read)));
/*  766: 869 */     return processor.getResult();
/*  767:     */   }
/*  768:     */   
/*  769:     */   @Deprecated
/*  770:     */   public static HashCode hash(InputSupplier<? extends InputStream> supplier, HashFunction hashFunction)
/*  771:     */     throws IOException
/*  772:     */   {
/*  773: 888 */     return asByteSource(supplier).hash(hashFunction);
/*  774:     */   }
/*  775:     */   
/*  776:     */   public static int read(InputStream in, byte[] b, int off, int len)
/*  777:     */     throws IOException
/*  778:     */   {
/*  779: 917 */     Preconditions.checkNotNull(in);
/*  780: 918 */     Preconditions.checkNotNull(b);
/*  781: 919 */     if (len < 0) {
/*  782: 920 */       throw new IndexOutOfBoundsException("len is negative");
/*  783:     */     }
/*  784: 922 */     int total = 0;
/*  785: 923 */     while (total < len)
/*  786:     */     {
/*  787: 924 */       int result = in.read(b, off + total, len - total);
/*  788: 925 */       if (result == -1) {
/*  789:     */         break;
/*  790:     */       }
/*  791: 928 */       total += result;
/*  792:     */     }
/*  793: 930 */     return total;
/*  794:     */   }
/*  795:     */   
/*  796:     */   @Deprecated
/*  797:     */   public static InputSupplier<InputStream> slice(InputSupplier<? extends InputStream> supplier, long offset, long length)
/*  798:     */   {
/*  799: 951 */     return asInputSupplier(asByteSource(supplier).slice(offset, length));
/*  800:     */   }
/*  801:     */   
/*  802:     */   @Deprecated
/*  803:     */   public static InputSupplier<InputStream> join(Iterable<? extends InputSupplier<? extends InputStream>> suppliers)
/*  804:     */   {
/*  805: 974 */     Preconditions.checkNotNull(suppliers);
/*  806: 975 */     Iterable<ByteSource> sources = Iterables.transform(suppliers, new Function()
/*  807:     */     {
/*  808:     */       public ByteSource apply(InputSupplier<? extends InputStream> input)
/*  809:     */       {
/*  810: 979 */         return ByteStreams.asByteSource(input);
/*  811:     */       }
/*  812: 981 */     });
/*  813: 982 */     return asInputSupplier(ByteSource.concat(sources));
/*  814:     */   }
/*  815:     */   
/*  816:     */   @Deprecated
/*  817:     */   public static InputSupplier<InputStream> join(InputSupplier<? extends InputStream>... suppliers)
/*  818:     */   {
/*  819: 995 */     return join(Arrays.asList(suppliers));
/*  820:     */   }
/*  821:     */   
/*  822:     */   @Deprecated
/*  823:     */   public static ByteSource asByteSource(InputSupplier<? extends InputStream> supplier)
/*  824:     */   {
/*  825:1016 */     Preconditions.checkNotNull(supplier);
/*  826:1017 */     new ByteSource()
/*  827:     */     {
/*  828:     */       public InputStream openStream()
/*  829:     */         throws IOException
/*  830:     */       {
/*  831:1020 */         return (InputStream)this.val$supplier.getInput();
/*  832:     */       }
/*  833:     */       
/*  834:     */       public String toString()
/*  835:     */       {
/*  836:1025 */         return "ByteStreams.asByteSource(" + this.val$supplier + ")";
/*  837:     */       }
/*  838:     */     };
/*  839:     */   }
/*  840:     */   
/*  841:     */   @Deprecated
/*  842:     */   public static ByteSink asByteSink(OutputSupplier<? extends OutputStream> supplier)
/*  843:     */   {
/*  844:1046 */     Preconditions.checkNotNull(supplier);
/*  845:1047 */     new ByteSink()
/*  846:     */     {
/*  847:     */       public OutputStream openStream()
/*  848:     */         throws IOException
/*  849:     */       {
/*  850:1050 */         return (OutputStream)this.val$supplier.getOutput();
/*  851:     */       }
/*  852:     */       
/*  853:     */       public String toString()
/*  854:     */       {
/*  855:1055 */         return "ByteStreams.asByteSink(" + this.val$supplier + ")";
/*  856:     */       }
/*  857:     */     };
/*  858:     */   }
/*  859:     */   
/*  860:     */   static <S extends InputStream> InputSupplier<S> asInputSupplier(ByteSource source)
/*  861:     */   {
/*  862:1063 */     return (InputSupplier)Preconditions.checkNotNull(source);
/*  863:     */   }
/*  864:     */   
/*  865:     */   static <S extends OutputStream> OutputSupplier<S> asOutputSupplier(ByteSink sink)
/*  866:     */   {
/*  867:1069 */     return (OutputSupplier)Preconditions.checkNotNull(sink);
/*  868:     */   }
/*  869:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.ByteStreams
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.BufferedOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.OutputStream;
/*   8:    */ import java.io.OutputStreamWriter;
/*   9:    */ import java.io.Writer;
/*  10:    */ import java.nio.charset.Charset;
/*  11:    */ 
/*  12:    */ public abstract class ByteSink
/*  13:    */   implements OutputSupplier<OutputStream>
/*  14:    */ {
/*  15:    */   public CharSink asCharSink(Charset charset)
/*  16:    */   {
/*  17: 59 */     return new AsCharSink(charset, null);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public abstract OutputStream openStream()
/*  21:    */     throws IOException;
/*  22:    */   
/*  23:    */   @Deprecated
/*  24:    */   public final OutputStream getOutput()
/*  25:    */     throws IOException
/*  26:    */   {
/*  27: 84 */     return openStream();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public OutputStream openBufferedStream()
/*  31:    */     throws IOException
/*  32:    */   {
/*  33:100 */     OutputStream out = openStream();
/*  34:101 */     return (out instanceof BufferedOutputStream) ? (BufferedOutputStream)out : new BufferedOutputStream(out);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void write(byte[] bytes)
/*  38:    */     throws IOException
/*  39:    */   {
/*  40:112 */     Preconditions.checkNotNull(bytes);
/*  41:    */     
/*  42:114 */     Closer closer = Closer.create();
/*  43:    */     try
/*  44:    */     {
/*  45:116 */       OutputStream out = (OutputStream)closer.register(openStream());
/*  46:117 */       out.write(bytes);
/*  47:118 */       out.flush();
/*  48:    */     }
/*  49:    */     catch (Throwable e)
/*  50:    */     {
/*  51:120 */       throw closer.rethrow(e);
/*  52:    */     }
/*  53:    */     finally
/*  54:    */     {
/*  55:122 */       closer.close();
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public long writeFrom(InputStream input)
/*  60:    */     throws IOException
/*  61:    */   {
/*  62:134 */     Preconditions.checkNotNull(input);
/*  63:    */     
/*  64:136 */     Closer closer = Closer.create();
/*  65:    */     try
/*  66:    */     {
/*  67:138 */       OutputStream out = (OutputStream)closer.register(openStream());
/*  68:139 */       long written = ByteStreams.copy(input, out);
/*  69:140 */       out.flush();
/*  70:141 */       return written;
/*  71:    */     }
/*  72:    */     catch (Throwable e)
/*  73:    */     {
/*  74:143 */       throw closer.rethrow(e);
/*  75:    */     }
/*  76:    */     finally
/*  77:    */     {
/*  78:145 */       closer.close();
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   private final class AsCharSink
/*  83:    */     extends CharSink
/*  84:    */   {
/*  85:    */     private final Charset charset;
/*  86:    */     
/*  87:    */     private AsCharSink(Charset charset)
/*  88:    */     {
/*  89:158 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/*  90:    */     }
/*  91:    */     
/*  92:    */     public Writer openStream()
/*  93:    */       throws IOException
/*  94:    */     {
/*  95:163 */       return new OutputStreamWriter(ByteSink.this.openStream(), this.charset);
/*  96:    */     }
/*  97:    */     
/*  98:    */     public String toString()
/*  99:    */     {
/* 100:168 */       return ByteSink.this.toString() + ".asCharSink(" + this.charset + ")";
/* 101:    */     }
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.ByteSink
 * JD-Core Version:    0.7.0.1
 */
package joptsimple;

import java.util.Comparator;

class BuiltinHelpFormatter$1 implements Comparator<OptionDescriptor> {
    public int compare(final OptionDescriptor first, final OptionDescriptor second) {
        return first.options().iterator().next().compareTo((String)second.options().iterator().next());
    }
}
package joptsimple;

static final class OptionParserState$1 extends OptionParserState {
    protected void handleArgument(final OptionParser parser, final ArgumentList arguments, final OptionSet detectedOptions) {
        parser.handleNonOptionArgument(arguments.next(), arguments, detectedOptions);
    }
}
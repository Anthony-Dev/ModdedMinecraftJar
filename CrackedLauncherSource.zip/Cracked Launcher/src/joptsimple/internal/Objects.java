package joptsimple.internal;

public final class Objects
{
    private Objects() {
        super();
        throw new UnsupportedOperationException();
    }
    
    public static void ensureNotNull(final Object target) {
        if (target == null) {
            throw new NullPointerException();
        }
    }
}

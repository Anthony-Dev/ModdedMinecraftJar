package joptsimple;

public interface ValueConverter<V>
{
    V convert(String p0);
    
    Class<V> valueType();
    
    String valuePattern();
}

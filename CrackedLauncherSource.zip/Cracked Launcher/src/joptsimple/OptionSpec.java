package joptsimple;

import java.util.Collection;
import java.util.List;

public interface OptionSpec<V>
{
    List<V> values(OptionSet p0);
    
    V value(OptionSet p0);
    
    Collection<String> options();
    
    boolean isForHelp();
}

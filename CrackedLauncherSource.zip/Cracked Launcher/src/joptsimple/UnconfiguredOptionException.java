package joptsimple;

import java.util.Collection;
import java.util.Collections;

class UnconfiguredOptionException extends OptionException
{
    private static final long serialVersionUID = -1L;
    
    UnconfiguredOptionException(final String option) {
        this(Collections.singletonList(option));
    }
    
    UnconfiguredOptionException(final Collection<String> options) {
        super(options);
    }
    
    public String getMessage() {
        return "Option " + this.multipleOptionMessage() + " has not been configured on this parser";
    }
}

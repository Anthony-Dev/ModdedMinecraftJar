package joptsimple;

static final class OptionParserState$2 extends OptionParserState {
    final /* synthetic */ boolean val$posixlyCorrect;
    
    protected void handleArgument(final OptionParser parser, final ArgumentList arguments, final OptionSet detectedOptions) {
        final String candidate = arguments.next();
        try {
            if (ParserRules.isOptionTerminator(candidate)) {
                parser.noMoreOptions();
                return;
            }
            if (ParserRules.isLongOptionToken(candidate)) {
                parser.handleLongOptionToken(candidate, arguments, detectedOptions);
                return;
            }
            if (ParserRules.isShortOptionToken(candidate)) {
                parser.handleShortOptionToken(candidate, arguments, detectedOptions);
                return;
            }
        }
        catch (UnrecognizedOptionException e) {
            if (!parser.doesAllowsUnrecognizedOptions()) {
                throw e;
            }
        }
        if (this.val$posixlyCorrect) {
            parser.noMoreOptions();
        }
        parser.handleNonOptionArgument(candidate, arguments, detectedOptions);
    }
}
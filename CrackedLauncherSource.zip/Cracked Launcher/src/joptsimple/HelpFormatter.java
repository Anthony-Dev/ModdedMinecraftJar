package joptsimple;

import java.util.Map;

public interface HelpFormatter
{
    String format(Map<String, ? extends OptionDescriptor> p0);
}

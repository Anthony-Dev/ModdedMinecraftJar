package net.minecraft.bootstrap;

public class BootstrapConstants
{
    public static final int BOOTSTRAP_VERSION_NUMBER = 5;
}

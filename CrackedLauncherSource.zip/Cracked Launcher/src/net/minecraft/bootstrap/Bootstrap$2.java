package net.minecraft.bootstrap;

import java.net.PasswordAuthentication;
import java.net.Authenticator;

static final class Bootstrap$2 extends Authenticator {
    final /* synthetic */ PasswordAuthentication val$auth;
    
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return this.val$auth;
    }
}
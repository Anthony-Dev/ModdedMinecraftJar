package net.minecraft.bootstrap;

public enum OS
{
    WINDOWS, 
    MACOS, 
    SOLARIS, 
    LINUX, 
    UNKNOWN;
}

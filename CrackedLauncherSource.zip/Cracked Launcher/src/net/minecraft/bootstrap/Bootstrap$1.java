package net.minecraft.bootstrap;

import javax.swing.JScrollBar;

class Bootstrap$1 implements Runnable {
    final /* synthetic */ JScrollBar val$scrollBar;
    
    @Override
    public void run() {
        this.val$scrollBar.setValue(Integer.MAX_VALUE);
    }
}
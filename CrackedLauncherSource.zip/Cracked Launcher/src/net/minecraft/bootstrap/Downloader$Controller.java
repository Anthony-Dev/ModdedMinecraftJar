package net.minecraft.bootstrap;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.CountDownLatch;

public static class Controller
{
    public final CountDownLatch foundUpdateLatch;
    public final AtomicBoolean foundUpdate;
    public final CountDownLatch hasDownloadedLatch;
    
    public Controller() {
        super();
        this.foundUpdateLatch = new CountDownLatch(1);
        this.foundUpdate = new AtomicBoolean(false);
        this.hasDownloadedLatch = new CountDownLatch(1);
    }
}

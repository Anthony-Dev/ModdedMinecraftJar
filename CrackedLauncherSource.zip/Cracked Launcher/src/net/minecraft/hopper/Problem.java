package net.minecraft.hopper;

public class Problem
{
    private String title;
    private String description;
    private String url;
    
    public String getTitle() {
        return this.title;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public String getUrl() {
        return this.url;
    }
}

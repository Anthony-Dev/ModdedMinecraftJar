package com.google.gson;

static class TreeTypeAdapter$1 {}
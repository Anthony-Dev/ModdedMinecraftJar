package com.google.gson.internal;

import java.util.LinkedHashSet;

class ConstructorConstructor$4 implements ObjectConstructor<T> {
    public T construct() {
        return (T)new LinkedHashSet();
    }
}
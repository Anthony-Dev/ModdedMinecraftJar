package com.google.gson.internal;

import java.util.Iterator;
import java.util.Map;
import java.util.AbstractSet;

private final class EntrySet extends AbstractSet<Map.Entry<String, V>>
{
    public Iterator<Map.Entry<String, V>> iterator() {
        return new LinkedHashIterator<Map.Entry<String, V>>() {
            public final Map.Entry<String, V> next() {
                return this.nextEntry();
            }
        };
    }
    
    public boolean contains(final Object o) {
        if (!(o instanceof Map.Entry)) {
            return false;
        }
        final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
        final V mappedValue = (V)StringMap.this.get(e.getKey());
        return mappedValue != null && mappedValue.equals(e.getValue());
    }
    
    public boolean remove(final Object o) {
        if (!(o instanceof Map.Entry)) {
            return false;
        }
        final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
        return StringMap.access$600(StringMap.this, e.getKey(), e.getValue());
    }
    
    public int size() {
        return StringMap.access$500(StringMap.this);
    }
    
    public void clear() {
        StringMap.this.clear();
    }
}

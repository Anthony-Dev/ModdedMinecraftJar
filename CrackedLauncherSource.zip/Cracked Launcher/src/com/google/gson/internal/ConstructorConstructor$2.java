package com.google.gson.internal;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Constructor;

class ConstructorConstructor$2 implements ObjectConstructor<T> {
    final /* synthetic */ Constructor val$constructor;
    
    public T construct() {
        try {
            final Object[] args = null;
            return this.val$constructor.newInstance(args);
        }
        catch (InstantiationException e) {
            throw new RuntimeException("Failed to invoke " + this.val$constructor + " with no args", e);
        }
        catch (InvocationTargetException e2) {
            throw new RuntimeException("Failed to invoke " + this.val$constructor + " with no args", e2.getTargetException());
        }
        catch (IllegalAccessException e3) {
            throw new AssertionError((Object)e3);
        }
    }
}
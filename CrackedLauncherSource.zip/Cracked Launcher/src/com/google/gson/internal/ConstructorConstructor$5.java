package com.google.gson.internal;

import java.util.LinkedList;

class ConstructorConstructor$5 implements ObjectConstructor<T> {
    public T construct() {
        return (T)new LinkedList();
    }
}
package com.google.gson.internal;

static class Streams$1 {}
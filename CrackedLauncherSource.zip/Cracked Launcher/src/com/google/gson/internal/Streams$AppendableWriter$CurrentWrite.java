package com.google.gson.internal;

static class CurrentWrite implements CharSequence
{
    char[] chars;
    
    public int length() {
        return this.chars.length;
    }
    
    public char charAt(final int i) {
        return this.chars[i];
    }
    
    public CharSequence subSequence(final int start, final int end) {
        return new String(this.chars, start, end - start);
    }
}

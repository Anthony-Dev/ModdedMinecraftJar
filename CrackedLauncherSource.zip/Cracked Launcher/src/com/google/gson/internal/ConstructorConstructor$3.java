package com.google.gson.internal;

import java.util.TreeSet;

class ConstructorConstructor$3 implements ObjectConstructor<T> {
    public T construct() {
        return (T)new TreeSet();
    }
}
package com.google.gson.internal;

class StringMap$Values$1 extends LinkedHashIterator<V> {
    public final V next() {
        return this.nextEntry().value;
    }
}
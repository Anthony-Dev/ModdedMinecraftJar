package com.google.gson.internal;

import java.util.Iterator;
import java.util.AbstractCollection;

private final class Values extends AbstractCollection<V>
{
    public Iterator<V> iterator() {
        return new LinkedHashIterator<V>() {
            public final V next() {
                return this.nextEntry().value;
            }
        };
    }
    
    public int size() {
        return StringMap.access$500(StringMap.this);
    }
    
    public boolean contains(final Object o) {
        return StringMap.this.containsValue(o);
    }
    
    public void clear() {
        StringMap.this.clear();
    }
}

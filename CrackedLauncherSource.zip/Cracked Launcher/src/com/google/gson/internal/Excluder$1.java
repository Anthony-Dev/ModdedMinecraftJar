package com.google.gson.internal;

import com.google.gson.TypeAdapterFactory;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonReader;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;

class Excluder$1 extends TypeAdapter<T> {
    private TypeAdapter<T> delegate;
    final /* synthetic */ boolean val$skipDeserialize;
    final /* synthetic */ boolean val$skipSerialize;
    final /* synthetic */ Gson val$gson;
    final /* synthetic */ TypeToken val$type;
    
    public T read(final JsonReader in) throws IOException {
        if (this.val$skipDeserialize) {
            in.skipValue();
            return null;
        }
        return this.delegate().read(in);
    }
    
    public void write(final JsonWriter out, final T value) throws IOException {
        if (this.val$skipSerialize) {
            out.nullValue();
            return;
        }
        this.delegate().write(out, value);
    }
    
    private TypeAdapter<T> delegate() {
        final TypeAdapter<T> d = this.delegate;
        return (d != null) ? d : (this.delegate = this.val$gson.getDelegateAdapter(Excluder.this, (TypeToken<T>)this.val$type));
    }
}
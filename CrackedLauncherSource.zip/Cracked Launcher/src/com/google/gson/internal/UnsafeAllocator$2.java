package com.google.gson.internal;

import java.lang.reflect.Method;

static final class UnsafeAllocator$2 extends UnsafeAllocator {
    final /* synthetic */ Method val$newInstance;
    
    public <T> T newInstance(final Class<T> c) throws Exception {
        return (T)this.val$newInstance.invoke(null, c, Object.class);
    }
}
package com.google.gson.internal;

import java.util.ArrayList;

class ConstructorConstructor$6 implements ObjectConstructor<T> {
    public T construct() {
        return (T)new ArrayList();
    }
}
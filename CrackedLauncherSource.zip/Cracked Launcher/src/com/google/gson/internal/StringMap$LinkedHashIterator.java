package com.google.gson.internal;

import java.util.NoSuchElementException;
import java.util.Iterator;

private abstract class LinkedHashIterator<T> implements Iterator<T>
{
    LinkedEntry<V> next;
    LinkedEntry<V> lastReturned;
    
    private LinkedHashIterator() {
        super();
        this.next = (LinkedEntry<V>)StringMap.access$300(StringMap.this).nxt;
        this.lastReturned = null;
    }
    
    public final boolean hasNext() {
        return this.next != StringMap.access$300(StringMap.this);
    }
    
    final LinkedEntry<V> nextEntry() {
        final LinkedEntry<V> e = this.next;
        if (e == StringMap.access$300(StringMap.this)) {
            throw new NoSuchElementException();
        }
        this.next = e.nxt;
        return this.lastReturned = e;
    }
    
    public final void remove() {
        if (this.lastReturned == null) {
            throw new IllegalStateException();
        }
        StringMap.this.remove(this.lastReturned.key);
        this.lastReturned = null;
    }
}

package com.google.gson.internal;

import java.util.LinkedHashMap;

class ConstructorConstructor$7 implements ObjectConstructor<T> {
    public T construct() {
        return (T)new LinkedHashMap();
    }
}
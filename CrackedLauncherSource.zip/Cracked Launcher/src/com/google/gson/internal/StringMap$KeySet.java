package com.google.gson.internal;

import java.util.Iterator;
import java.util.AbstractSet;

private final class KeySet extends AbstractSet<String>
{
    public Iterator<String> iterator() {
        return new LinkedHashIterator<String>() {
            public final String next() {
                return this.nextEntry().key;
            }
        };
    }
    
    public int size() {
        return StringMap.access$500(StringMap.this);
    }
    
    public boolean contains(final Object o) {
        return StringMap.this.containsKey(o);
    }
    
    public boolean remove(final Object o) {
        final int oldSize = StringMap.access$500(StringMap.this);
        StringMap.this.remove(o);
        return StringMap.access$500(StringMap.this) != oldSize;
    }
    
    public void clear() {
        StringMap.this.clear();
    }
}

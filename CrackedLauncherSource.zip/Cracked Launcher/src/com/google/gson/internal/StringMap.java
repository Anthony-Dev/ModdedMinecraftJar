package com.google.gson.internal;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.Random;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import java.util.Map;
import java.util.AbstractMap;

public final class StringMap<V> extends AbstractMap<String, V>
{
    private static final int MINIMUM_CAPACITY = 4;
    private static final int MAXIMUM_CAPACITY = 1073741824;
    private LinkedEntry<V> header;
    private static final Map.Entry[] EMPTY_TABLE;
    private LinkedEntry<V>[] table;
    private int size;
    private int threshold;
    private Set<String> keySet;
    private Set<Map.Entry<String, V>> entrySet;
    private Collection<V> values;
    private static final int seed;
    
    public StringMap() {
        super();
        this.table = (LinkedEntry<V>[])StringMap.EMPTY_TABLE;
        this.threshold = -1;
        this.header = new LinkedEntry<V>();
    }
    
    public int size() {
        return this.size;
    }
    
    public boolean containsKey(final Object key) {
        return key instanceof String && this.getEntry((String)key) != null;
    }
    
    public V get(final Object key) {
        if (key instanceof String) {
            final LinkedEntry<V> entry = this.getEntry((String)key);
            return (entry != null) ? entry.value : null;
        }
        return null;
    }
    
    private LinkedEntry<V> getEntry(final String key) {
        if (key == null) {
            return null;
        }
        final int hash = hash(key);
        final LinkedEntry<V>[] tab = this.table;
        for (LinkedEntry<V> e = tab[hash & tab.length - 1]; e != null; e = e.next) {
            final String eKey = e.key;
            if (eKey == key || (e.hash == hash && key.equals(eKey))) {
                return e;
            }
        }
        return null;
    }
    
    public V put(final String key, final V value) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }
        final int hash = hash(key);
        LinkedEntry<V>[] tab = this.table;
        int index = hash & tab.length - 1;
        for (LinkedEntry<V> e = tab[index]; e != null; e = e.next) {
            if (e.hash == hash && key.equals(e.key)) {
                final V oldValue = e.value;
                e.value = value;
                return oldValue;
            }
        }
        if (this.size++ > this.threshold) {
            tab = this.doubleCapacity();
            index = (hash & tab.length - 1);
        }
        this.addNewEntry(key, value, hash, index);
        return null;
    }
    
    private void addNewEntry(final String key, final V value, final int hash, final int index) {
        final LinkedEntry<V> header = this.header;
        final LinkedEntry<V> oldTail = header.prv;
        final LinkedEntry<V> newTail = new LinkedEntry<V>(key, value, hash, this.table[index], header, oldTail);
        final LinkedEntry<V>[] table = this.table;
        final LinkedEntry<V> linkedEntry = oldTail;
        final LinkedEntry<V> linkedEntry2 = header;
        final LinkedEntry<V> linkedEntry3 = newTail;
        linkedEntry2.prv = linkedEntry3;
        table[index] = (linkedEntry.nxt = linkedEntry3);
    }
    
    private LinkedEntry<V>[] makeTable(final int newCapacity) {
        final LinkedEntry<V>[] newTable = (LinkedEntry<V>[])new LinkedEntry[newCapacity];
        this.table = newTable;
        this.threshold = (newCapacity >> 1) + (newCapacity >> 2);
        return newTable;
    }
    
    private LinkedEntry<V>[] doubleCapacity() {
        final LinkedEntry<V>[] oldTable = this.table;
        final int oldCapacity = oldTable.length;
        if (oldCapacity == 1073741824) {
            return oldTable;
        }
        final int newCapacity = oldCapacity * 2;
        final LinkedEntry<V>[] newTable = this.makeTable(newCapacity);
        if (this.size == 0) {
            return newTable;
        }
        for (int j = 0; j < oldCapacity; ++j) {
            LinkedEntry<V> e = oldTable[j];
            if (e != null) {
                int highBit = e.hash & oldCapacity;
                LinkedEntry<V> broken = null;
                newTable[j | highBit] = e;
                for (LinkedEntry<V> n = e.next; n != null; n = n.next) {
                    final int nextHighBit = n.hash & oldCapacity;
                    if (nextHighBit != highBit) {
                        if (broken == null) {
                            newTable[j | nextHighBit] = n;
                        }
                        else {
                            broken.next = n;
                        }
                        broken = e;
                        highBit = nextHighBit;
                    }
                    e = n;
                }
                if (broken != null) {
                    broken.next = null;
                }
            }
        }
        return newTable;
    }
    
    public V remove(final Object key) {
        if (key == null || !(key instanceof String)) {
            return null;
        }
        final int hash = hash((String)key);
        final LinkedEntry<V>[] tab = this.table;
        final int index = hash & tab.length - 1;
        LinkedEntry<V> e = tab[index];
        LinkedEntry<V> prev = null;
        while (e != null) {
            if (e.hash == hash && key.equals(e.key)) {
                if (prev == null) {
                    tab[index] = e.next;
                }
                else {
                    prev.next = e.next;
                }
                --this.size;
                this.unlink(e);
                return e.value;
            }
            prev = e;
            e = e.next;
        }
        return null;
    }
    
    private void unlink(final LinkedEntry<V> e) {
        e.prv.nxt = e.nxt;
        e.nxt.prv = e.prv;
        final LinkedEntry<V> linkedEntry = null;
        e.prv = (LinkedEntry<V>)linkedEntry;
        e.nxt = (LinkedEntry<V>)linkedEntry;
    }
    
    public void clear() {
        if (this.size != 0) {
            Arrays.fill(this.table, null);
            this.size = 0;
        }
        final LinkedEntry<V> header = this.header;
        LinkedEntry<V> nxt;
        for (LinkedEntry<V> e = header.nxt; e != header; e = nxt) {
            nxt = e.nxt;
            final LinkedEntry<V> linkedEntry = e;
            final LinkedEntry<V> linkedEntry2 = e;
            final LinkedEntry<V> linkedEntry3 = null;
            linkedEntry2.prv = (LinkedEntry<V>)linkedEntry3;
            linkedEntry.nxt = (LinkedEntry<V>)linkedEntry3;
        }
        final LinkedEntry<V> linkedEntry4 = header;
        final LinkedEntry<V> linkedEntry5 = header;
        final LinkedEntry<V> linkedEntry6 = header;
        linkedEntry5.prv = linkedEntry6;
        linkedEntry4.nxt = linkedEntry6;
    }
    
    public Set<String> keySet() {
        final Set<String> ks = this.keySet;
        return (ks != null) ? ks : (this.keySet = new KeySet());
    }
    
    public Collection<V> values() {
        final Collection<V> vs = this.values;
        return (vs != null) ? vs : (this.values = new Values());
    }
    
    public Set<Map.Entry<String, V>> entrySet() {
        final Set<Map.Entry<String, V>> es = this.entrySet;
        return (es != null) ? es : (this.entrySet = new EntrySet());
    }
    
    private boolean removeMapping(final Object key, final Object value) {
        if (key == null || !(key instanceof String)) {
            return false;
        }
        final int hash = hash((String)key);
        final LinkedEntry<V>[] tab = this.table;
        final int index = hash & tab.length - 1;
        LinkedEntry<V> e = tab[index];
        LinkedEntry<V> prev = null;
        while (e != null) {
            if (e.hash == hash && key.equals(e.key)) {
                Label_0101: {
                    if (value == null) {
                        if (e.value == null) {
                            break Label_0101;
                        }
                    }
                    else if (value.equals(e.value)) {
                        break Label_0101;
                    }
                    return false;
                }
                if (prev == null) {
                    tab[index] = e.next;
                }
                else {
                    prev.next = e.next;
                }
                --this.size;
                this.unlink(e);
                return true;
            }
            prev = e;
            e = e.next;
        }
        return false;
    }
    
    private static int hash(final String key) {
        int h = StringMap.seed;
        for (int i = 0; i < key.length(); ++i) {
            final int h2 = h + key.charAt(i);
            final int h3 = h2 + h2 << 10;
            h = (h3 ^ h3 >>> 6);
        }
        h ^= (h >>> 20 ^ h >>> 12);
        return h ^ h >>> 7 ^ h >>> 4;
    }
    
    static {
        EMPTY_TABLE = new LinkedEntry[2];
        seed = new Random().nextInt();
    }
    
    static class LinkedEntry<V> implements Map.Entry<String, V>
    {
        final String key;
        V value;
        final int hash;
        LinkedEntry<V> next;
        LinkedEntry<V> nxt;
        LinkedEntry<V> prv;
        
        LinkedEntry() {
            this(null, null, 0, null, null, null);
            this.prv = this;
            this.nxt = this;
        }
        
        LinkedEntry(final String key, final V value, final int hash, final LinkedEntry<V> next, final LinkedEntry<V> nxt, final LinkedEntry<V> prv) {
            super();
            this.key = key;
            this.value = value;
            this.hash = hash;
            this.next = next;
            this.nxt = nxt;
            this.prv = prv;
        }
        
        public final String getKey() {
            return this.key;
        }
        
        public final V getValue() {
            return this.value;
        }
        
        public final V setValue(final V value) {
            final V oldValue = this.value;
            this.value = value;
            return oldValue;
        }
        
        public final boolean equals(final Object o) {
            if (!(o instanceof Map.Entry)) {
                return false;
            }
            final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
            final Object eValue = e.getValue();
            return this.key.equals(e.getKey()) && ((this.value != null) ? this.value.equals(eValue) : (eValue == null));
        }
        
        public final int hashCode() {
            return ((this.key == null) ? 0 : this.key.hashCode()) ^ ((this.value == null) ? 0 : this.value.hashCode());
        }
        
        public final String toString() {
            return this.key + "=" + this.value;
        }
    }
    
    private abstract class LinkedHashIterator<T> implements Iterator<T>
    {
        LinkedEntry<V> next;
        LinkedEntry<V> lastReturned;
        
        private LinkedHashIterator() {
            super();
            this.next = StringMap.this.header.nxt;
            this.lastReturned = null;
        }
        
        public final boolean hasNext() {
            return this.next != StringMap.this.header;
        }
        
        final LinkedEntry<V> nextEntry() {
            final LinkedEntry<V> e = this.next;
            if (e == StringMap.this.header) {
                throw new NoSuchElementException();
            }
            this.next = e.nxt;
            return this.lastReturned = e;
        }
        
        public final void remove() {
            if (this.lastReturned == null) {
                throw new IllegalStateException();
            }
            StringMap.this.remove(this.lastReturned.key);
            this.lastReturned = null;
        }
    }
    
    private final class KeySet extends AbstractSet<String>
    {
        public Iterator<String> iterator() {
            return new LinkedHashIterator<String>() {
                public final String next() {
                    return this.nextEntry().key;
                }
            };
        }
        
        public int size() {
            return StringMap.this.size;
        }
        
        public boolean contains(final Object o) {
            return StringMap.this.containsKey(o);
        }
        
        public boolean remove(final Object o) {
            final int oldSize = StringMap.this.size;
            StringMap.this.remove(o);
            return StringMap.this.size != oldSize;
        }
        
        public void clear() {
            StringMap.this.clear();
        }
    }
    
    private final class Values extends AbstractCollection<V>
    {
        public Iterator<V> iterator() {
            return new LinkedHashIterator<V>() {
                public final V next() {
                    return this.nextEntry().value;
                }
            };
        }
        
        public int size() {
            return StringMap.this.size;
        }
        
        public boolean contains(final Object o) {
            return StringMap.this.containsValue(o);
        }
        
        public void clear() {
            StringMap.this.clear();
        }
    }
    
    private final class EntrySet extends AbstractSet<Map.Entry<String, V>>
    {
        public Iterator<Map.Entry<String, V>> iterator() {
            return new LinkedHashIterator<Map.Entry<String, V>>() {
                public final Map.Entry<String, V> next() {
                    return this.nextEntry();
                }
            };
        }
        
        public boolean contains(final Object o) {
            if (!(o instanceof Map.Entry)) {
                return false;
            }
            final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
            final V mappedValue = (V)StringMap.this.get(e.getKey());
            return mappedValue != null && mappedValue.equals(e.getValue());
        }
        
        public boolean remove(final Object o) {
            if (!(o instanceof Map.Entry)) {
                return false;
            }
            final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
            return StringMap.this.removeMapping(e.getKey(), e.getValue());
        }
        
        public int size() {
            return StringMap.this.size;
        }
        
        public void clear() {
            StringMap.this.clear();
        }
    }
}

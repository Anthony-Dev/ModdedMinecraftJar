package com.google.gson.internal;

import java.util.Map;

static class LinkedEntry<V> implements Map.Entry<String, V>
{
    final String key;
    V value;
    final int hash;
    LinkedEntry<V> next;
    LinkedEntry<V> nxt;
    LinkedEntry<V> prv;
    
    LinkedEntry() {
        this(null, null, 0, null, null, null);
        this.prv = this;
        this.nxt = this;
    }
    
    LinkedEntry(final String key, final V value, final int hash, final LinkedEntry<V> next, final LinkedEntry<V> nxt, final LinkedEntry<V> prv) {
        super();
        this.key = key;
        this.value = value;
        this.hash = hash;
        this.next = next;
        this.nxt = nxt;
        this.prv = prv;
    }
    
    public final String getKey() {
        return this.key;
    }
    
    public final V getValue() {
        return this.value;
    }
    
    public final V setValue(final V value) {
        final V oldValue = this.value;
        this.value = value;
        return oldValue;
    }
    
    public final boolean equals(final Object o) {
        if (!(o instanceof Map.Entry)) {
            return false;
        }
        final Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
        final Object eValue = e.getValue();
        return this.key.equals(e.getKey()) && ((this.value != null) ? this.value.equals(eValue) : (eValue == null));
    }
    
    public final int hashCode() {
        return ((this.key == null) ? 0 : this.key.hashCode()) ^ ((this.value == null) ? 0 : this.value.hashCode());
    }
    
    public final String toString() {
        return this.key + "=" + this.value;
    }
}

package com.google.gson.internal;

import java.lang.reflect.Type;
import com.google.gson.InstanceCreator;

class ConstructorConstructor$1 implements ObjectConstructor<T> {
    final /* synthetic */ InstanceCreator val$creator;
    final /* synthetic */ Type val$type;
    
    public T construct() {
        return this.val$creator.createInstance(this.val$type);
    }
}
package com.google.gson.internal;

import java.util.Map;

class StringMap$EntrySet$1 extends LinkedHashIterator<Map.Entry<String, V>> {
    public final Map.Entry<String, V> next() {
        return this.nextEntry();
    }
}
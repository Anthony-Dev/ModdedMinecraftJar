package com.google.gson.internal;

import java.lang.reflect.Method;

static final class UnsafeAllocator$1 extends UnsafeAllocator {
    final /* synthetic */ Method val$allocateInstance;
    final /* synthetic */ Object val$unsafe;
    
    public <T> T newInstance(final Class<T> c) throws Exception {
        return (T)this.val$allocateInstance.invoke(this.val$unsafe, c);
    }
}
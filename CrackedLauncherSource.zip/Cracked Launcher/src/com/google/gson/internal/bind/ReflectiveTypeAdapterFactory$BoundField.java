package com.google.gson.internal.bind;

import com.google.gson.stream.JsonReader;
import java.io.IOException;
import com.google.gson.stream.JsonWriter;

abstract static class BoundField
{
    final String name;
    final boolean serialized;
    final boolean deserialized;
    
    protected BoundField(final String name, final boolean serialized, final boolean deserialized) {
        super();
        this.name = name;
        this.serialized = serialized;
        this.deserialized = deserialized;
    }
    
    abstract void write(final JsonWriter p0, final Object p1) throws IOException, IllegalAccessException;
    
    abstract void read(final JsonReader p0, final Object p1) throws IOException, IllegalAccessException;
}

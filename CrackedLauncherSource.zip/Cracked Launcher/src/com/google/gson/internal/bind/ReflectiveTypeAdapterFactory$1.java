package com.google.gson.internal.bind;

import com.google.gson.stream.JsonReader;
import java.io.IOException;
import com.google.gson.stream.JsonWriter;
import java.lang.reflect.Field;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;

class ReflectiveTypeAdapterFactory$1 extends BoundField {
    final TypeAdapter<?> typeAdapter = this.val$context.getAdapter((TypeToken<?>)this.val$fieldType);
    final /* synthetic */ Gson val$context;
    final /* synthetic */ TypeToken val$fieldType;
    final /* synthetic */ Field val$field;
    final /* synthetic */ boolean val$isPrimitive;
    
    void write(final JsonWriter writer, final Object value) throws IOException, IllegalAccessException {
        final Object fieldValue = this.val$field.get(value);
        final TypeAdapter t = new TypeAdapterRuntimeTypeWrapper(this.val$context, this.typeAdapter, this.val$fieldType.getType());
        t.write(writer, fieldValue);
    }
    
    void read(final JsonReader reader, final Object value) throws IOException, IllegalAccessException {
        final Object fieldValue = this.typeAdapter.read(reader);
        if (fieldValue != null || !this.val$isPrimitive) {
            this.val$field.set(value, fieldValue);
        }
    }
}
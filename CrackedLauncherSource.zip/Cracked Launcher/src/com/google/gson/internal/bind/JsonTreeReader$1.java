package com.google.gson.internal.bind;

import java.io.IOException;
import java.io.Reader;

static final class JsonTreeReader$1 extends Reader {
    public int read(final char[] buffer, final int offset, final int count) throws IOException {
        throw new AssertionError();
    }
    
    public void close() throws IOException {
        throw new AssertionError();
    }
}
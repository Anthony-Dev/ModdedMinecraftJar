package com.google.gson.internal.bind;

import com.google.gson.stream.JsonToken;
import java.util.Iterator;
import java.util.Map;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonReader;
import com.google.gson.JsonElement;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$25 extends TypeAdapter<JsonElement> {
    public JsonElement read(final JsonReader in) throws IOException {
        switch (in.peek()) {
            case STRING: {
                return new JsonPrimitive(in.nextString());
            }
            case NUMBER: {
                final String number = in.nextString();
                return new JsonPrimitive(new LazilyParsedNumber(number));
            }
            case BOOLEAN: {
                return new JsonPrimitive(Boolean.valueOf(in.nextBoolean()));
            }
            case NULL: {
                in.nextNull();
                return JsonNull.INSTANCE;
            }
            case BEGIN_ARRAY: {
                final JsonArray array = new JsonArray();
                in.beginArray();
                while (in.hasNext()) {
                    array.add(this.read(in));
                }
                in.endArray();
                return array;
            }
            case BEGIN_OBJECT: {
                final JsonObject object = new JsonObject();
                in.beginObject();
                while (in.hasNext()) {
                    object.add(in.nextName(), this.read(in));
                }
                in.endObject();
                return object;
            }
            default: {
                throw new IllegalArgumentException();
            }
        }
    }
    
    public void write(final JsonWriter out, final JsonElement value) throws IOException {
        if (value == null || value.isJsonNull()) {
            out.nullValue();
        }
        else if (value.isJsonPrimitive()) {
            final JsonPrimitive primitive = value.getAsJsonPrimitive();
            if (primitive.isNumber()) {
                out.value(primitive.getAsNumber());
            }
            else if (primitive.isBoolean()) {
                out.value(primitive.getAsBoolean());
            }
            else {
                out.value(primitive.getAsString());
            }
        }
        else if (value.isJsonArray()) {
            out.beginArray();
            for (final JsonElement e : value.getAsJsonArray()) {
                this.write(out, e);
            }
            out.endArray();
        }
        else {
            if (!value.isJsonObject()) {
                throw new IllegalArgumentException("Couldn't write " + value.getClass());
            }
            out.beginObject();
            for (final Map.Entry<String, JsonElement> e2 : value.getAsJsonObject().entrySet()) {
                out.name(e2.getKey());
                this.write(out, e2.getValue());
            }
            out.endObject();
        }
    }
}
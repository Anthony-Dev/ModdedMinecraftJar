package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.StringTokenizer;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.util.Locale;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$24 extends TypeAdapter<Locale> {
    public Locale read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        final String locale = in.nextString();
        final StringTokenizer tokenizer = new StringTokenizer(locale, "_");
        String language = null;
        String country = null;
        String variant = null;
        if (tokenizer.hasMoreElements()) {
            language = tokenizer.nextToken();
        }
        if (tokenizer.hasMoreElements()) {
            country = tokenizer.nextToken();
        }
        if (tokenizer.hasMoreElements()) {
            variant = tokenizer.nextToken();
        }
        if (country == null && variant == null) {
            return new Locale(language);
        }
        if (variant == null) {
            return new Locale(language, country);
        }
        return new Locale(language, country, variant);
    }
    
    public void write(final JsonWriter out, final Locale value) throws IOException {
        out.value((value == null) ? null : value.toString());
    }
}
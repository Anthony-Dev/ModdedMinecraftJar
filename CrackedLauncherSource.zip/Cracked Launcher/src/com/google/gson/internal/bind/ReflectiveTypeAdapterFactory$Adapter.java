package com.google.gson.internal.bind;

import java.util.Iterator;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.util.Map;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.TypeAdapter;

public final class Adapter<T> extends TypeAdapter<T>
{
    private final ObjectConstructor<T> constructor;
    private final Map<String, BoundField> boundFields;
    
    private Adapter(final ObjectConstructor<T> constructor, final Map<String, BoundField> boundFields) {
        super();
        this.constructor = constructor;
        this.boundFields = boundFields;
    }
    
    public T read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        final T instance = this.constructor.construct();
        try {
            in.beginObject();
            while (in.hasNext()) {
                final String name = in.nextName();
                final BoundField field = this.boundFields.get(name);
                if (field == null || !field.deserialized) {
                    in.skipValue();
                }
                else {
                    field.read(in, instance);
                }
            }
        }
        catch (IllegalStateException e) {
            throw new JsonSyntaxException(e);
        }
        catch (IllegalAccessException e2) {
            throw new AssertionError((Object)e2);
        }
        in.endObject();
        return instance;
    }
    
    public void write(final JsonWriter out, final T value) throws IOException {
        if (value == null) {
            out.nullValue();
            return;
        }
        out.beginObject();
        try {
            for (final BoundField boundField : this.boundFields.values()) {
                if (boundField.serialized) {
                    out.name(boundField.name);
                    boundField.write(out, value);
                }
            }
        }
        catch (IllegalAccessException e) {
            throw new AssertionError();
        }
        out.endObject();
    }
}

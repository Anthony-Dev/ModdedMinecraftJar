package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import com.google.gson.JsonIOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.net.URI;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$19 extends TypeAdapter<URI> {
    public URI read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        try {
            final String nextString = in.nextString();
            return "null".equals(nextString) ? null : new URI(nextString);
        }
        catch (URISyntaxException e) {
            throw new JsonIOException(e);
        }
    }
    
    public void write(final JsonWriter out, final URI value) throws IOException {
        out.value((value == null) ? null : value.toASCIIString());
    }
}
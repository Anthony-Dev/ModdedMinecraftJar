package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$12 extends TypeAdapter<Character> {
    public Character read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        final String str = in.nextString();
        if (str.length() != 1) {
            throw new JsonSyntaxException("Expecting character, got: " + str);
        }
        return str.charAt(0);
    }
    
    public void write(final JsonWriter out, final Character value) throws IOException {
        out.value((value == null) ? null : String.valueOf(value));
    }
}
package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonReader;
import java.util.Date;
import java.sql.Timestamp;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.TypeAdapterFactory;

static final class TypeAdapters$22 implements TypeAdapterFactory {
    public <T> TypeAdapter<T> create(final Gson gson, final TypeToken<T> typeToken) {
        if (typeToken.getRawType() != Timestamp.class) {
            return null;
        }
        final TypeAdapter<Date> dateTypeAdapter = gson.getAdapter(Date.class);
        return (TypeAdapter<T>)new TypeAdapter<Timestamp>() {
            public Timestamp read(final JsonReader in) throws IOException {
                final Date date = dateTypeAdapter.read(in);
                return (date != null) ? new Timestamp(date.getTime()) : null;
            }
            
            public void write(final JsonWriter out, final Timestamp value) throws IOException {
                dateTypeAdapter.write(out, value);
            }
        };
    }
}
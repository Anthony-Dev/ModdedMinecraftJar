package com.google.gson.internal.bind;

import java.io.IOException;
import java.io.Writer;

static final class JsonTreeWriter$1 extends Writer {
    public void write(final char[] buffer, final int offset, final int counter) {
        throw new AssertionError();
    }
    
    public void flush() throws IOException {
        throw new AssertionError();
    }
    
    public void close() throws IOException {
        throw new AssertionError();
    }
}
package com.google.gson.internal.bind;

import com.google.gson.stream.JsonReader;
import java.io.IOException;
import com.google.gson.stream.JsonWriter;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$1 extends TypeAdapter<Class> {
    public void write(final JsonWriter out, final Class value) throws IOException {
        throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + value.getName() + ". Forgot to register a type adapter?");
    }
    
    public Class read(final JsonReader in) throws IOException {
        throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
    }
}
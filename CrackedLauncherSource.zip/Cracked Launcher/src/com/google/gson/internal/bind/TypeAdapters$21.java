package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.util.UUID;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$21 extends TypeAdapter<UUID> {
    public UUID read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return UUID.fromString(in.nextString());
    }
    
    public void write(final JsonWriter out, final UUID value) throws IOException {
        out.value((value == null) ? null : value.toString());
    }
}
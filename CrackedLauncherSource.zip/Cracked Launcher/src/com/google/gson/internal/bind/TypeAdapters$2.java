package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.util.BitSet;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$2 extends TypeAdapter<BitSet> {
    public BitSet read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        final BitSet bitset = new BitSet();
        in.beginArray();
        int i = 0;
        for (JsonToken tokenType = in.peek(); tokenType != JsonToken.END_ARRAY; tokenType = in.peek()) {
            boolean set = false;
            switch (tokenType) {
                case NUMBER: {
                    set = (in.nextInt() != 0);
                    break;
                }
                case BOOLEAN: {
                    set = in.nextBoolean();
                    break;
                }
                case STRING: {
                    final String stringValue = in.nextString();
                    try {
                        set = (Integer.parseInt(stringValue) != 0);
                        break;
                    }
                    catch (NumberFormatException e) {
                        throw new JsonSyntaxException("Error: Expecting: bitset number value (1, 0), Found: " + stringValue);
                    }
                    throw new JsonSyntaxException("Invalid bitset value type: " + tokenType);
                }
            }
            if (set) {
                bitset.set(i);
            }
            ++i;
        }
        in.endArray();
        return bitset;
    }
    
    public void write(final JsonWriter out, final BitSet src) throws IOException {
        if (src == null) {
            out.nullValue();
            return;
        }
        out.beginArray();
        for (int i = 0; i < src.length(); ++i) {
            final int value = src.get(i) ? 1 : 0;
            out.value(value);
        }
        out.endArray();
    }
}
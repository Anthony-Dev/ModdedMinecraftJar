package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.stream.JsonReader;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$11 extends TypeAdapter<Number> {
    public Number read(final JsonReader in) throws IOException {
        final JsonToken jsonToken = in.peek();
        switch (jsonToken) {
            case NULL: {
                in.nextNull();
                return null;
            }
            case NUMBER: {
                return new LazilyParsedNumber(in.nextString());
            }
            default: {
                throw new JsonSyntaxException("Expecting number, got: " + jsonToken);
            }
        }
    }
    
    public void write(final JsonWriter out, final Number value) throws IOException {
        out.value(value);
    }
}
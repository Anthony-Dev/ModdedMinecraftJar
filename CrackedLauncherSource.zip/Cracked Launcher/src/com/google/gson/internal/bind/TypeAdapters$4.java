package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$4 extends TypeAdapter<Boolean> {
    public Boolean read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return Boolean.valueOf(in.nextString());
    }
    
    public void write(final JsonWriter out, final Boolean value) throws IOException {
        out.value((value == null) ? "null" : value.toString());
    }
}
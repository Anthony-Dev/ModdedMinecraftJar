package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.annotations.SerializedName;
import java.util.HashMap;
import java.util.Map;
import com.google.gson.TypeAdapter;

private static final class EnumTypeAdapter<T extends Enum<T>> extends TypeAdapter<T>
{
    private final Map<String, T> nameToConstant;
    private final Map<T, String> constantToName;
    
    public EnumTypeAdapter(final Class<T> classOfT) {
        super();
        this.nameToConstant = new HashMap<String, T>();
        this.constantToName = new HashMap<T, String>();
        try {
            for (final T constant : classOfT.getEnumConstants()) {
                String name = constant.name();
                final SerializedName annotation = classOfT.getField(name).getAnnotation(SerializedName.class);
                if (annotation != null) {
                    name = annotation.value();
                }
                this.nameToConstant.put(name, constant);
                this.constantToName.put(constant, name);
            }
        }
        catch (NoSuchFieldException e) {
            throw new AssertionError();
        }
    }
    
    public T read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return this.nameToConstant.get(in.nextString());
    }
    
    public void write(final JsonWriter out, final T value) throws IOException {
        out.value((value == null) ? null : this.constantToName.get(value));
    }
}

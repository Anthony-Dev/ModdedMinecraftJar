package com.google.gson.internal.bind;

import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;

static final class TypeAdapters$31 implements TypeAdapterFactory {
    final /* synthetic */ Class val$clazz;
    final /* synthetic */ TypeAdapter val$typeAdapter;
    
    public <T> TypeAdapter<T> create(final Gson gson, final TypeToken<T> typeToken) {
        return (TypeAdapter<T>)(this.val$clazz.isAssignableFrom(typeToken.getRawType()) ? this.val$typeAdapter : null);
    }
    
    public String toString() {
        return "Factory[typeHierarchy=" + this.val$clazz.getName() + ",adapter=" + this.val$typeAdapter + "]";
    }
}
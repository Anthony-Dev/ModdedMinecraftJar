package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.net.InetAddress;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$20 extends TypeAdapter<InetAddress> {
    public InetAddress read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return InetAddress.getByName(in.nextString());
    }
    
    public void write(final JsonWriter out, final InetAddress value) throws IOException {
        out.value((value == null) ? null : value.getHostAddress());
    }
}
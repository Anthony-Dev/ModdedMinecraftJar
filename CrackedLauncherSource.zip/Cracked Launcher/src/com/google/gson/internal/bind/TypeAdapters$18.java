package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.net.URL;
import com.google.gson.TypeAdapter;

static final class TypeAdapters$18 extends TypeAdapter<URL> {
    public URL read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        final String nextString = in.nextString();
        return "null".equals(nextString) ? null : new URL(nextString);
    }
    
    public void write(final JsonWriter out, final URL value) throws IOException {
        out.value((value == null) ? null : value.toExternalForm());
    }
}
package com.google.gson.internal.bind;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Date;
import com.google.gson.stream.JsonReader;
import java.sql.Timestamp;
import com.google.gson.TypeAdapter;

class TypeAdapters$22$1 extends TypeAdapter<Timestamp> {
    final /* synthetic */ TypeAdapter val$dateTypeAdapter;
    
    public Timestamp read(final JsonReader in) throws IOException {
        final Date date = this.val$dateTypeAdapter.read(in);
        return (date != null) ? new Timestamp(date.getTime()) : null;
    }
    
    public void write(final JsonWriter out, final Timestamp value) throws IOException {
        this.val$dateTypeAdapter.write(out, value);
    }
}
package com.google.gson.internal;

import java.lang.reflect.Type;
import java.io.Serializable;
import java.lang.reflect.GenericArrayType;

private static final class GenericArrayTypeImpl implements GenericArrayType, Serializable
{
    private final Type componentType;
    private static final long serialVersionUID = 0L;
    
    public GenericArrayTypeImpl(final Type componentType) {
        super();
        this.componentType = $Gson$Types.canonicalize(componentType);
    }
    
    public Type getGenericComponentType() {
        return this.componentType;
    }
    
    public boolean equals(final Object o) {
        return o instanceof GenericArrayType && $Gson$Types.equals(this, (Type)o);
    }
    
    public int hashCode() {
        return this.componentType.hashCode();
    }
    
    public String toString() {
        return $Gson$Types.typeToString(this.componentType) + "[]";
    }
}

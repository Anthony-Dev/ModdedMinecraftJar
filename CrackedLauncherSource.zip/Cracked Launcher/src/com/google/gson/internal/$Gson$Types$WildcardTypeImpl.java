package com.google.gson.internal;

import java.lang.reflect.Type;
import java.io.Serializable;
import java.lang.reflect.WildcardType;

private static final class WildcardTypeImpl implements WildcardType, Serializable
{
    private final Type upperBound;
    private final Type lowerBound;
    private static final long serialVersionUID = 0L;
    
    public WildcardTypeImpl(final Type[] upperBounds, final Type[] lowerBounds) {
        super();
        $Gson$Preconditions.checkArgument(lowerBounds.length <= 1);
        $Gson$Preconditions.checkArgument(upperBounds.length == 1);
        if (lowerBounds.length == 1) {
            $Gson$Preconditions.checkNotNull(lowerBounds[0]);
            $Gson$Types.access$000(lowerBounds[0]);
            $Gson$Preconditions.checkArgument(upperBounds[0] == Object.class);
            this.lowerBound = $Gson$Types.canonicalize(lowerBounds[0]);
            this.upperBound = Object.class;
        }
        else {
            $Gson$Preconditions.checkNotNull(upperBounds[0]);
            $Gson$Types.access$000(upperBounds[0]);
            this.lowerBound = null;
            this.upperBound = $Gson$Types.canonicalize(upperBounds[0]);
        }
    }
    
    public Type[] getUpperBounds() {
        return new Type[] { this.upperBound };
    }
    
    public Type[] getLowerBounds() {
        final Type[] array;
        if (this.lowerBound != null) {
            array = new Type[] { this.lowerBound };
        }
        else {
            final Type[] empty_TYPE_ARRAY = $Gson$Types.EMPTY_TYPE_ARRAY;
        }
        return array;
    }
    
    public boolean equals(final Object other) {
        return other instanceof WildcardType && $Gson$Types.equals(this, (Type)other);
    }
    
    public int hashCode() {
        return ((this.lowerBound != null) ? (31 + this.lowerBound.hashCode()) : 1) ^ 31 + this.upperBound.hashCode();
    }
    
    public String toString() {
        if (this.lowerBound != null) {
            return "? super " + $Gson$Types.typeToString(this.lowerBound);
        }
        if (this.upperBound == Object.class) {
            return "?";
        }
        return "? extends " + $Gson$Types.typeToString(this.upperBound);
    }
}

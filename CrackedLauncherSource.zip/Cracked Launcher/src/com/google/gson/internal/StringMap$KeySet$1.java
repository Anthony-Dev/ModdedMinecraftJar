package com.google.gson.internal;

class StringMap$KeySet$1 extends LinkedHashIterator<String> {
    public final String next() {
        return this.nextEntry().key;
    }
}
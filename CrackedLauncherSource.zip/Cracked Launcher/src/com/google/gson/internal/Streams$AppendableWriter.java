package com.google.gson.internal;

import java.io.IOException;
import java.io.Writer;

private static class AppendableWriter extends Writer
{
    private final Appendable appendable;
    private final CurrentWrite currentWrite;
    
    private AppendableWriter(final Appendable appendable) {
        super();
        this.currentWrite = new CurrentWrite();
        this.appendable = appendable;
    }
    
    public void write(final char[] chars, final int offset, final int length) throws IOException {
        this.currentWrite.chars = chars;
        this.appendable.append(this.currentWrite, offset, offset + length);
    }
    
    public void write(final int i) throws IOException {
        this.appendable.append((char)i);
    }
    
    public void flush() {
    }
    
    public void close() {
    }
    
    static class CurrentWrite implements CharSequence
    {
        char[] chars;
        
        public int length() {
            return this.chars.length;
        }
        
        public char charAt(final int i) {
            return this.chars[i];
        }
        
        public CharSequence subSequence(final int start, final int end) {
            return new String(this.chars, start, end - start);
        }
    }
}

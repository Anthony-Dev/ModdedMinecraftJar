package com.google.gson.internal;

static class StringMap$1 {}
package com.google.gson;

import java.lang.reflect.Field;

enum FieldNamingPolicy$2
{
    public String translateName(final Field f) {
        return FieldNamingPolicy.access$100(f.getName());
    }
}
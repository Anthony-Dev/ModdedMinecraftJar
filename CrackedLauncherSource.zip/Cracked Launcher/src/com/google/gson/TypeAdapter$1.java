package com.google.gson;

import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import com.google.gson.stream.JsonWriter;

class TypeAdapter$1 extends TypeAdapter<T> {
    public void write(final JsonWriter out, final T value) throws IOException {
        if (value == null) {
            out.nullValue();
        }
        else {
            TypeAdapter.this.write(out, value);
        }
    }
    
    public T read(final JsonReader reader) throws IOException {
        if (reader.peek() == JsonToken.NULL) {
            reader.nextNull();
            return null;
        }
        return (T)TypeAdapter.this.read(reader);
    }
}
package com.google.gson;

enum LongSerializationPolicy$1
{
    public JsonElement serialize(final Long value) {
        return new JsonPrimitive(value);
    }
}
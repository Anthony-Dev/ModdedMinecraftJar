package com.google.gson;

import java.lang.reflect.Type;

class Gson$3 implements JsonSerializationContext {
    public JsonElement serialize(final Object src) {
        return Gson.this.toJsonTree(src);
    }
    
    public JsonElement serialize(final Object src, final Type typeOfSrc) {
        return Gson.this.toJsonTree(src, typeOfSrc);
    }
}
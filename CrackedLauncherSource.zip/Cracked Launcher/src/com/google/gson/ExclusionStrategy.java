package com.google.gson;

public interface ExclusionStrategy
{
    boolean shouldSkipField(FieldAttributes p0);
    
    boolean shouldSkipClass(Class<?> p0);
}

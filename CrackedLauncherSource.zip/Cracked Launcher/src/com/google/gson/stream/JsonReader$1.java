package com.google.gson.stream;

import java.io.IOException;
import com.google.gson.internal.bind.JsonTreeReader;
import com.google.gson.internal.JsonReaderInternalAccess;

static final class JsonReader$1 extends JsonReaderInternalAccess {
    public void promoteNameToValue(final JsonReader reader) throws IOException {
        if (reader instanceof JsonTreeReader) {
            ((JsonTreeReader)reader).promoteNameToValue();
            return;
        }
        reader.peek();
        if (JsonReader.access$000(reader) != JsonToken.NAME) {
            throw new IllegalStateException("Expected a name but was " + reader.peek() + " " + " at line " + JsonReader.access$100(reader) + " column " + JsonReader.access$200(reader));
        }
        JsonReader.access$302(reader, JsonReader.access$400(reader));
        JsonReader.access$402(reader, null);
        JsonReader.access$002(reader, JsonToken.STRING);
    }
}
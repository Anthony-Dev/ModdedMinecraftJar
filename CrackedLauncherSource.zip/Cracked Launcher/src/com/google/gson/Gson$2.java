package com.google.gson;

import java.lang.reflect.Type;

class Gson$2 implements JsonDeserializationContext {
    public <T> T deserialize(final JsonElement json, final Type typeOfT) throws JsonParseException {
        return Gson.this.fromJson(json, typeOfT);
    }
}
package com.google.gson;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;

class Gson$5 extends TypeAdapter<Number> {
    public Float read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return (float)in.nextDouble();
    }
    
    public void write(final JsonWriter out, final Number value) throws IOException {
        if (value == null) {
            out.nullValue();
            return;
        }
        final float floatValue = value.floatValue();
        Gson.access$000(Gson.this, floatValue);
        out.value(value);
    }
}
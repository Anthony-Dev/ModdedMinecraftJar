package com.google.gson;

import java.lang.reflect.Field;

enum FieldNamingPolicy$1
{
    public String translateName(final Field f) {
        return f.getName();
    }
}
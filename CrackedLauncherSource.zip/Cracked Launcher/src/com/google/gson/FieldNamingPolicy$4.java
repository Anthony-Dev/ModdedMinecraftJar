package com.google.gson;

import java.lang.reflect.Field;

enum FieldNamingPolicy$4
{
    public String translateName(final Field f) {
        return FieldNamingPolicy.access$200(f.getName(), "_").toLowerCase();
    }
}
package com.google.gson;

enum LongSerializationPolicy$2
{
    public JsonElement serialize(final Long value) {
        return new JsonPrimitive(String.valueOf(value));
    }
}
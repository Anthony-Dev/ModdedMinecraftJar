package com.google.gson;

import java.util.HashMap;
import com.google.gson.reflect.TypeToken;
import java.util.Map;

class Gson$1 extends ThreadLocal<Map<TypeToken<?>, FutureTypeAdapter<?>>> {
    protected Map<TypeToken<?>, FutureTypeAdapter<?>> initialValue() {
        return new HashMap<TypeToken<?>, FutureTypeAdapter<?>>();
    }
}
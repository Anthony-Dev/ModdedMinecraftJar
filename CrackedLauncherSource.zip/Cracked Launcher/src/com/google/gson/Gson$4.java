package com.google.gson;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;

class Gson$4 extends TypeAdapter<Number> {
    public Double read(final JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }
        return in.nextDouble();
    }
    
    public void write(final JsonWriter out, final Number value) throws IOException {
        if (value == null) {
            out.nullValue();
            return;
        }
        final double doubleValue = value.doubleValue();
        Gson.access$000(Gson.this, doubleValue);
        out.value(value);
    }
}
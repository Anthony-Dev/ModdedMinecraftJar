package com.google.gson;

import com.google.gson.internal.$Gson$Preconditions;
import com.google.gson.reflect.TypeToken;

private static class SingleTypeFactory implements TypeAdapterFactory
{
    private final TypeToken<?> exactType;
    private final boolean matchRawType;
    private final Class<?> hierarchyType;
    private final JsonSerializer<?> serializer;
    private final JsonDeserializer<?> deserializer;
    
    private SingleTypeFactory(final Object typeAdapter, final TypeToken<?> exactType, final boolean matchRawType, final Class<?> hierarchyType) {
        super();
        this.serializer = (JsonSerializer<?>)((typeAdapter instanceof JsonSerializer) ? ((JsonSerializer)typeAdapter) : null);
        this.deserializer = (JsonDeserializer<?>)((typeAdapter instanceof JsonDeserializer) ? ((JsonDeserializer)typeAdapter) : null);
        $Gson$Preconditions.checkArgument(this.serializer != null || this.deserializer != null);
        this.exactType = exactType;
        this.matchRawType = matchRawType;
        this.hierarchyType = hierarchyType;
    }
    
    public <T> TypeAdapter<T> create(final Gson gson, final TypeToken<T> type) {
        final boolean matches = (this.exactType != null) ? (this.exactType.equals(type) || (this.matchRawType && this.exactType.getType() == type.getRawType())) : this.hierarchyType.isAssignableFrom(type.getRawType());
        return matches ? new TreeTypeAdapter<T>(this.serializer, this.deserializer, gson, type, this, null) : null;
    }
}

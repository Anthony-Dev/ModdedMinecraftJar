/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.math.BigInteger;
/*   5:    */ 
/*   6:    */ final class DoubleUtils
/*   7:    */ {
/*   8:    */   static final long SIGNIFICAND_MASK = 4503599627370495L;
/*   9:    */   static final long EXPONENT_MASK = 9218868437227405312L;
/*  10:    */   static final long SIGN_MASK = -9223372036854775808L;
/*  11:    */   static final int SIGNIFICAND_BITS = 52;
/*  12:    */   static final int EXPONENT_BIAS = 1023;
/*  13:    */   static final long IMPLICIT_BIT = 4503599627370496L;
/*  14:    */   
/*  15:    */   static double nextDown(double d)
/*  16:    */   {
/*  17: 40 */     return -Math.nextUp(-d);
/*  18:    */   }
/*  19:    */   
/*  20:    */   static long getSignificand(double d)
/*  21:    */   {
/*  22: 65 */     Preconditions.checkArgument(isFinite(d), "not a normal value");
/*  23: 66 */     int exponent = Math.getExponent(d);
/*  24: 67 */     long bits = Double.doubleToRawLongBits(d);
/*  25: 68 */     bits &= 0xFFFFFFFF;
/*  26: 69 */     return exponent == -1023 ? bits << 1 : bits | 0x0;
/*  27:    */   }
/*  28:    */   
/*  29:    */   static boolean isFinite(double d)
/*  30:    */   {
/*  31: 75 */     return Math.getExponent(d) <= 1023;
/*  32:    */   }
/*  33:    */   
/*  34:    */   static boolean isNormal(double d)
/*  35:    */   {
/*  36: 79 */     return Math.getExponent(d) >= -1022;
/*  37:    */   }
/*  38:    */   
/*  39:    */   static double scaleNormalize(double x)
/*  40:    */   {
/*  41: 87 */     long significand = Double.doubleToRawLongBits(x) & 0xFFFFFFFF;
/*  42: 88 */     return Double.longBitsToDouble(significand | ONE_BITS);
/*  43:    */   }
/*  44:    */   
/*  45:    */   static double bigToDouble(BigInteger x)
/*  46:    */   {
/*  47: 93 */     BigInteger absX = x.abs();
/*  48: 94 */     int exponent = absX.bitLength() - 1;
/*  49: 96 */     if (exponent < 63) {
/*  50: 97 */       return x.longValue();
/*  51:    */     }
/*  52: 98 */     if (exponent > 1023) {
/*  53: 99 */       return x.signum() * (1.0D / 0.0D);
/*  54:    */     }
/*  55:110 */     int shift = exponent - 52 - 1;
/*  56:111 */     long twiceSignifFloor = absX.shiftRight(shift).longValue();
/*  57:112 */     long signifFloor = twiceSignifFloor >> 1;
/*  58:113 */     signifFloor &= 0xFFFFFFFF;
/*  59:    */     
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:120 */     boolean increment = ((twiceSignifFloor & 1L) != 0L) && (((signifFloor & 1L) != 0L) || (absX.getLowestSetBit() < shift));
/*  66:    */     
/*  67:122 */     long signifRounded = increment ? signifFloor + 1L : signifFloor;
/*  68:123 */     long bits = exponent + 1023 << 52;
/*  69:124 */     bits += signifRounded;
/*  70:    */     
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:131 */     bits |= x.signum() & 0x0;
/*  77:132 */     return Double.longBitsToDouble(bits);
/*  78:    */   }
/*  79:    */   
/*  80:    */   static double ensureNonNegative(double value)
/*  81:    */   {
/*  82:139 */     Preconditions.checkArgument(!Double.isNaN(value));
/*  83:140 */     if (value > 0.0D) {
/*  84:141 */       return value;
/*  85:    */     }
/*  86:143 */     return 0.0D;
/*  87:    */   }
/*  88:    */   
/*  89:147 */   private static final long ONE_BITS = Double.doubleToRawLongBits(1.0D);
/*  90:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.math.DoubleUtils
 * JD-Core Version:    0.7.0.1
 */
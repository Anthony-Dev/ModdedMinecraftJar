/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.math.BigDecimal;
/*   8:    */ import java.math.BigInteger;
/*   9:    */ import java.math.RoundingMode;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ 
/*  13:    */ @GwtCompatible(emulated=true)
/*  14:    */ public final class BigIntegerMath
/*  15:    */ {
/*  16:    */   @VisibleForTesting
/*  17:    */   static final int SQRT2_PRECOMPUTE_THRESHOLD = 256;
/*  18:    */   
/*  19:    */   public static boolean isPowerOfTwo(BigInteger x)
/*  20:    */   {
/*  21: 56 */     Preconditions.checkNotNull(x);
/*  22: 57 */     return (x.signum() > 0) && (x.getLowestSetBit() == x.bitLength() - 1);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static int log2(BigInteger x, RoundingMode mode)
/*  26:    */   {
/*  27: 70 */     MathPreconditions.checkPositive("x", (BigInteger)Preconditions.checkNotNull(x));
/*  28: 71 */     int logFloor = x.bitLength() - 1;
/*  29: 72 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  30:    */     {
/*  31:    */     case 1: 
/*  32: 74 */       MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
/*  33:    */     case 2: 
/*  34:    */     case 3: 
/*  35: 77 */       return logFloor;
/*  36:    */     case 4: 
/*  37:    */     case 5: 
/*  38: 81 */       return isPowerOfTwo(x) ? logFloor : logFloor + 1;
/*  39:    */     case 6: 
/*  40:    */     case 7: 
/*  41:    */     case 8: 
/*  42: 86 */       if (logFloor < 256)
/*  43:    */       {
/*  44: 87 */         BigInteger halfPower = SQRT2_PRECOMPUTED_BITS.shiftRight(256 - logFloor);
/*  45: 89 */         if (x.compareTo(halfPower) <= 0) {
/*  46: 90 */           return logFloor;
/*  47:    */         }
/*  48: 92 */         return logFloor + 1;
/*  49:    */       }
/*  50:101 */       BigInteger x2 = x.pow(2);
/*  51:102 */       int logX2Floor = x2.bitLength() - 1;
/*  52:103 */       return logX2Floor < 2 * logFloor + 1 ? logFloor : logFloor + 1;
/*  53:    */     }
/*  54:106 */     throw new AssertionError();
/*  55:    */   }
/*  56:    */   
/*  57:    */   @VisibleForTesting
/*  58:117 */   static final BigInteger SQRT2_PRECOMPUTED_BITS = new BigInteger("16a09e667f3bcc908b2fb1366ea957d3e3adec17512775099da2f590b0667322a", 16);
/*  59:    */   
/*  60:    */   @GwtIncompatible("TODO")
/*  61:    */   public static int log10(BigInteger x, RoundingMode mode)
/*  62:    */   {
/*  63:130 */     MathPreconditions.checkPositive("x", x);
/*  64:131 */     if (fitsInLong(x)) {
/*  65:132 */       return LongMath.log10(x.longValue(), mode);
/*  66:    */     }
/*  67:135 */     int approxLog10 = (int)(log2(x, RoundingMode.FLOOR) * LN_2 / LN_10);
/*  68:136 */     BigInteger approxPow = BigInteger.TEN.pow(approxLog10);
/*  69:137 */     int approxCmp = approxPow.compareTo(x);
/*  70:144 */     if (approxCmp > 0)
/*  71:    */     {
/*  72:    */       do
/*  73:    */       {
/*  74:151 */         approxLog10--;
/*  75:152 */         approxPow = approxPow.divide(BigInteger.TEN);
/*  76:153 */         approxCmp = approxPow.compareTo(x);
/*  77:154 */       } while (approxCmp > 0);
/*  78:    */     }
/*  79:    */     else
/*  80:    */     {
/*  81:156 */       BigInteger nextPow = BigInteger.TEN.multiply(approxPow);
/*  82:157 */       int nextCmp = nextPow.compareTo(x);
/*  83:158 */       while (nextCmp <= 0)
/*  84:    */       {
/*  85:159 */         approxLog10++;
/*  86:160 */         approxPow = nextPow;
/*  87:161 */         approxCmp = nextCmp;
/*  88:162 */         nextPow = BigInteger.TEN.multiply(approxPow);
/*  89:163 */         nextCmp = nextPow.compareTo(x);
/*  90:    */       }
/*  91:    */     }
/*  92:167 */     int floorLog = approxLog10;
/*  93:168 */     BigInteger floorPow = approxPow;
/*  94:169 */     int floorCmp = approxCmp;
/*  95:171 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  96:    */     {
/*  97:    */     case 1: 
/*  98:173 */       MathPreconditions.checkRoundingUnnecessary(floorCmp == 0);
/*  99:    */     case 2: 
/* 100:    */     case 3: 
/* 101:177 */       return floorLog;
/* 102:    */     case 4: 
/* 103:    */     case 5: 
/* 104:181 */       return floorPow.equals(x) ? floorLog : floorLog + 1;
/* 105:    */     case 6: 
/* 106:    */     case 7: 
/* 107:    */     case 8: 
/* 108:187 */       BigInteger x2 = x.pow(2);
/* 109:188 */       BigInteger halfPowerSquared = floorPow.pow(2).multiply(BigInteger.TEN);
/* 110:189 */       return x2.compareTo(halfPowerSquared) <= 0 ? floorLog : floorLog + 1;
/* 111:    */     }
/* 112:191 */     throw new AssertionError();
/* 113:    */   }
/* 114:    */   
/* 115:195 */   private static final double LN_10 = Math.log(10.0D);
/* 116:196 */   private static final double LN_2 = Math.log(2.0D);
/* 117:    */   
/* 118:    */   @GwtIncompatible("TODO")
/* 119:    */   public static BigInteger sqrt(BigInteger x, RoundingMode mode)
/* 120:    */   {
/* 121:208 */     MathPreconditions.checkNonNegative("x", x);
/* 122:209 */     if (fitsInLong(x)) {
/* 123:210 */       return BigInteger.valueOf(LongMath.sqrt(x.longValue(), mode));
/* 124:    */     }
/* 125:212 */     BigInteger sqrtFloor = sqrtFloor(x);
/* 126:213 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 127:    */     {
/* 128:    */     case 1: 
/* 129:215 */       MathPreconditions.checkRoundingUnnecessary(sqrtFloor.pow(2).equals(x));
/* 130:    */     case 2: 
/* 131:    */     case 3: 
/* 132:218 */       return sqrtFloor;
/* 133:    */     case 4: 
/* 134:    */     case 5: 
/* 135:221 */       int sqrtFloorInt = sqrtFloor.intValue();
/* 136:222 */       boolean sqrtFloorIsExact = (sqrtFloorInt * sqrtFloorInt == x.intValue()) && (sqrtFloor.pow(2).equals(x));
/* 137:    */       
/* 138:    */ 
/* 139:225 */       return sqrtFloorIsExact ? sqrtFloor : sqrtFloor.add(BigInteger.ONE);
/* 140:    */     case 6: 
/* 141:    */     case 7: 
/* 142:    */     case 8: 
/* 143:229 */       BigInteger halfSquare = sqrtFloor.pow(2).add(sqrtFloor);
/* 144:    */       
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:235 */       return halfSquare.compareTo(x) >= 0 ? sqrtFloor : sqrtFloor.add(BigInteger.ONE);
/* 150:    */     }
/* 151:237 */     throw new AssertionError();
/* 152:    */   }
/* 153:    */   
/* 154:    */   @GwtIncompatible("TODO")
/* 155:    */   private static BigInteger sqrtFloor(BigInteger x)
/* 156:    */   {
/* 157:263 */     int log2 = log2(x, RoundingMode.FLOOR);
/* 158:    */     BigInteger sqrt0;
/* 159:    */     BigInteger sqrt0;
/* 160:264 */     if (log2 < 1023)
/* 161:    */     {
/* 162:265 */       sqrt0 = sqrtApproxWithDoubles(x);
/* 163:    */     }
/* 164:    */     else
/* 165:    */     {
/* 166:267 */       int shift = log2 - 52 & 0xFFFFFFFE;
/* 167:    */       
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:272 */       sqrt0 = sqrtApproxWithDoubles(x.shiftRight(shift)).shiftLeft(shift >> 1);
/* 172:    */     }
/* 173:274 */     BigInteger sqrt1 = sqrt0.add(x.divide(sqrt0)).shiftRight(1);
/* 174:275 */     if (sqrt0.equals(sqrt1)) {
/* 175:276 */       return sqrt0;
/* 176:    */     }
/* 177:    */     do
/* 178:    */     {
/* 179:279 */       sqrt0 = sqrt1;
/* 180:280 */       sqrt1 = sqrt0.add(x.divide(sqrt0)).shiftRight(1);
/* 181:281 */     } while (sqrt1.compareTo(sqrt0) < 0);
/* 182:282 */     return sqrt0;
/* 183:    */   }
/* 184:    */   
/* 185:    */   @GwtIncompatible("TODO")
/* 186:    */   private static BigInteger sqrtApproxWithDoubles(BigInteger x)
/* 187:    */   {
/* 188:287 */     return DoubleMath.roundToBigInteger(Math.sqrt(DoubleUtils.bigToDouble(x)), RoundingMode.HALF_EVEN);
/* 189:    */   }
/* 190:    */   
/* 191:    */   @GwtIncompatible("TODO")
/* 192:    */   public static BigInteger divide(BigInteger p, BigInteger q, RoundingMode mode)
/* 193:    */   {
/* 194:299 */     BigDecimal pDec = new BigDecimal(p);
/* 195:300 */     BigDecimal qDec = new BigDecimal(q);
/* 196:301 */     return pDec.divide(qDec, 0, mode).toBigIntegerExact();
/* 197:    */   }
/* 198:    */   
/* 199:    */   public static BigInteger factorial(int n)
/* 200:    */   {
/* 201:317 */     MathPreconditions.checkNonNegative("n", n);
/* 202:320 */     if (n < LongMath.factorials.length) {
/* 203:321 */       return BigInteger.valueOf(LongMath.factorials[n]);
/* 204:    */     }
/* 205:325 */     int approxSize = IntMath.divide(n * IntMath.log2(n, RoundingMode.CEILING), 64, RoundingMode.CEILING);
/* 206:326 */     ArrayList<BigInteger> bignums = new ArrayList(approxSize);
/* 207:    */     
/* 208:    */ 
/* 209:329 */     int startingNumber = LongMath.factorials.length;
/* 210:330 */     long product = LongMath.factorials[(startingNumber - 1)];
/* 211:    */     
/* 212:332 */     int shift = Long.numberOfTrailingZeros(product);
/* 213:333 */     product >>= shift;
/* 214:    */     
/* 215:    */ 
/* 216:336 */     int productBits = LongMath.log2(product, RoundingMode.FLOOR) + 1;
/* 217:337 */     int bits = LongMath.log2(startingNumber, RoundingMode.FLOOR) + 1;
/* 218:    */     
/* 219:339 */     int nextPowerOfTwo = 1 << bits - 1;
/* 220:342 */     for (long num = startingNumber; num <= n; num += 1L)
/* 221:    */     {
/* 222:344 */       if ((num & nextPowerOfTwo) != 0L)
/* 223:    */       {
/* 224:345 */         nextPowerOfTwo <<= 1;
/* 225:346 */         bits++;
/* 226:    */       }
/* 227:349 */       int tz = Long.numberOfTrailingZeros(num);
/* 228:350 */       long normalizedNum = num >> tz;
/* 229:351 */       shift += tz;
/* 230:    */       
/* 231:353 */       int normalizedBits = bits - tz;
/* 232:355 */       if (normalizedBits + productBits >= 64)
/* 233:    */       {
/* 234:356 */         bignums.add(BigInteger.valueOf(product));
/* 235:357 */         product = 1L;
/* 236:358 */         productBits = 0;
/* 237:    */       }
/* 238:360 */       product *= normalizedNum;
/* 239:361 */       productBits = LongMath.log2(product, RoundingMode.FLOOR) + 1;
/* 240:    */     }
/* 241:364 */     if (product > 1L) {
/* 242:365 */       bignums.add(BigInteger.valueOf(product));
/* 243:    */     }
/* 244:368 */     return listProduct(bignums).shiftLeft(shift);
/* 245:    */   }
/* 246:    */   
/* 247:    */   static BigInteger listProduct(List<BigInteger> nums)
/* 248:    */   {
/* 249:372 */     return listProduct(nums, 0, nums.size());
/* 250:    */   }
/* 251:    */   
/* 252:    */   static BigInteger listProduct(List<BigInteger> nums, int start, int end)
/* 253:    */   {
/* 254:376 */     switch (end - start)
/* 255:    */     {
/* 256:    */     case 0: 
/* 257:378 */       return BigInteger.ONE;
/* 258:    */     case 1: 
/* 259:380 */       return (BigInteger)nums.get(start);
/* 260:    */     case 2: 
/* 261:382 */       return ((BigInteger)nums.get(start)).multiply((BigInteger)nums.get(start + 1));
/* 262:    */     case 3: 
/* 263:384 */       return ((BigInteger)nums.get(start)).multiply((BigInteger)nums.get(start + 1)).multiply((BigInteger)nums.get(start + 2));
/* 264:    */     }
/* 265:387 */     int m = end + start >>> 1;
/* 266:388 */     return listProduct(nums, start, m).multiply(listProduct(nums, m, end));
/* 267:    */   }
/* 268:    */   
/* 269:    */   public static BigInteger binomial(int n, int k)
/* 270:    */   {
/* 271:401 */     MathPreconditions.checkNonNegative("n", n);
/* 272:402 */     MathPreconditions.checkNonNegative("k", k);
/* 273:403 */     Preconditions.checkArgument(k <= n, "k (%s) > n (%s)", new Object[] { Integer.valueOf(k), Integer.valueOf(n) });
/* 274:404 */     if (k > n >> 1) {
/* 275:405 */       k = n - k;
/* 276:    */     }
/* 277:407 */     if ((k < LongMath.biggestBinomials.length) && (n <= LongMath.biggestBinomials[k])) {
/* 278:408 */       return BigInteger.valueOf(LongMath.binomial(n, k));
/* 279:    */     }
/* 280:411 */     BigInteger accum = BigInteger.ONE;
/* 281:    */     
/* 282:413 */     long numeratorAccum = n;
/* 283:414 */     long denominatorAccum = 1L;
/* 284:    */     
/* 285:416 */     int bits = LongMath.log2(n, RoundingMode.CEILING);
/* 286:    */     
/* 287:418 */     int numeratorBits = bits;
/* 288:420 */     for (int i = 1; i < k; i++)
/* 289:    */     {
/* 290:421 */       int p = n - i;
/* 291:422 */       int q = i + 1;
/* 292:426 */       if (numeratorBits + bits >= 63)
/* 293:    */       {
/* 294:429 */         accum = accum.multiply(BigInteger.valueOf(numeratorAccum)).divide(BigInteger.valueOf(denominatorAccum));
/* 295:    */         
/* 296:    */ 
/* 297:432 */         numeratorAccum = p;
/* 298:433 */         denominatorAccum = q;
/* 299:434 */         numeratorBits = bits;
/* 300:    */       }
/* 301:    */       else
/* 302:    */       {
/* 303:437 */         numeratorAccum *= p;
/* 304:438 */         denominatorAccum *= q;
/* 305:439 */         numeratorBits += bits;
/* 306:    */       }
/* 307:    */     }
/* 308:442 */     return accum.multiply(BigInteger.valueOf(numeratorAccum)).divide(BigInteger.valueOf(denominatorAccum));
/* 309:    */   }
/* 310:    */   
/* 311:    */   @GwtIncompatible("TODO")
/* 312:    */   static boolean fitsInLong(BigInteger x)
/* 313:    */   {
/* 314:450 */     return x.bitLength() <= 63;
/* 315:    */   }
/* 316:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.math.BigIntegerMath
 * JD-Core Version:    0.7.0.1
 */
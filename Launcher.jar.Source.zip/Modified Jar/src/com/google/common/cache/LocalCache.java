/*    1:     */ package com.google.common.cache;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.annotations.VisibleForTesting;
/*    6:     */ import com.google.common.base.Equivalence;
/*    7:     */ import com.google.common.base.Function;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.base.Stopwatch;
/*   10:     */ import com.google.common.base.Supplier;
/*   11:     */ import com.google.common.base.Ticker;
/*   12:     */ import com.google.common.collect.AbstractSequentialIterator;
/*   13:     */ import com.google.common.collect.ImmutableMap;
/*   14:     */ import com.google.common.collect.Iterators;
/*   15:     */ import com.google.common.collect.Maps;
/*   16:     */ import com.google.common.collect.Sets;
/*   17:     */ import com.google.common.primitives.Ints;
/*   18:     */ import com.google.common.util.concurrent.ExecutionError;
/*   19:     */ import com.google.common.util.concurrent.Futures;
/*   20:     */ import com.google.common.util.concurrent.ListenableFuture;
/*   21:     */ import com.google.common.util.concurrent.ListeningExecutorService;
/*   22:     */ import com.google.common.util.concurrent.MoreExecutors;
/*   23:     */ import com.google.common.util.concurrent.SettableFuture;
/*   24:     */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*   25:     */ import com.google.common.util.concurrent.Uninterruptibles;
/*   26:     */ import java.io.IOException;
/*   27:     */ import java.io.ObjectInputStream;
/*   28:     */ import java.io.Serializable;
/*   29:     */ import java.lang.ref.Reference;
/*   30:     */ import java.lang.ref.ReferenceQueue;
/*   31:     */ import java.lang.ref.SoftReference;
/*   32:     */ import java.lang.ref.WeakReference;
/*   33:     */ import java.util.AbstractCollection;
/*   34:     */ import java.util.AbstractMap;
/*   35:     */ import java.util.AbstractQueue;
/*   36:     */ import java.util.AbstractSet;
/*   37:     */ import java.util.Collection;
/*   38:     */ import java.util.Iterator;
/*   39:     */ import java.util.Map;
/*   40:     */ import java.util.Map.Entry;
/*   41:     */ import java.util.NoSuchElementException;
/*   42:     */ import java.util.Queue;
/*   43:     */ import java.util.Set;
/*   44:     */ import java.util.concurrent.Callable;
/*   45:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   46:     */ import java.util.concurrent.ConcurrentMap;
/*   47:     */ import java.util.concurrent.ExecutionException;
/*   48:     */ import java.util.concurrent.TimeUnit;
/*   49:     */ import java.util.concurrent.atomic.AtomicInteger;
/*   50:     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*   51:     */ import java.util.concurrent.locks.ReentrantLock;
/*   52:     */ import java.util.logging.Level;
/*   53:     */ import java.util.logging.Logger;
/*   54:     */ import javax.annotation.Nullable;
/*   55:     */ import javax.annotation.concurrent.GuardedBy;
/*   56:     */ 
/*   57:     */ @GwtCompatible(emulated=true)
/*   58:     */ class LocalCache<K, V>
/*   59:     */   extends AbstractMap<K, V>
/*   60:     */   implements ConcurrentMap<K, V>
/*   61:     */ {
/*   62:     */   static final int MAXIMUM_CAPACITY = 1073741824;
/*   63:     */   static final int MAX_SEGMENTS = 65536;
/*   64:     */   static final int CONTAINS_VALUE_RETRIES = 3;
/*   65:     */   static final int DRAIN_THRESHOLD = 63;
/*   66:     */   static final int DRAIN_MAX = 16;
/*   67: 158 */   static final Logger logger = Logger.getLogger(LocalCache.class.getName());
/*   68: 160 */   static final ListeningExecutorService sameThreadExecutor = MoreExecutors.sameThreadExecutor();
/*   69:     */   final int segmentMask;
/*   70:     */   final int segmentShift;
/*   71:     */   final Segment<K, V>[] segments;
/*   72:     */   final int concurrencyLevel;
/*   73:     */   final Equivalence<Object> keyEquivalence;
/*   74:     */   final Equivalence<Object> valueEquivalence;
/*   75:     */   final Strength keyStrength;
/*   76:     */   final Strength valueStrength;
/*   77:     */   final long maxWeight;
/*   78:     */   final Weigher<K, V> weigher;
/*   79:     */   final long expireAfterAccessNanos;
/*   80:     */   final long expireAfterWriteNanos;
/*   81:     */   final long refreshNanos;
/*   82:     */   final Queue<RemovalNotification<K, V>> removalNotificationQueue;
/*   83:     */   final RemovalListener<K, V> removalListener;
/*   84:     */   final Ticker ticker;
/*   85:     */   final EntryFactory entryFactory;
/*   86:     */   final AbstractCache.StatsCounter globalStatsCounter;
/*   87:     */   @Nullable
/*   88:     */   final CacheLoader<? super K, V> defaultLoader;
/*   89:     */   
/*   90:     */   LocalCache(CacheBuilder<? super K, ? super V> builder, @Nullable CacheLoader<? super K, V> loader)
/*   91:     */   {
/*   92: 240 */     this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
/*   93:     */     
/*   94: 242 */     this.keyStrength = builder.getKeyStrength();
/*   95: 243 */     this.valueStrength = builder.getValueStrength();
/*   96:     */     
/*   97: 245 */     this.keyEquivalence = builder.getKeyEquivalence();
/*   98: 246 */     this.valueEquivalence = builder.getValueEquivalence();
/*   99:     */     
/*  100: 248 */     this.maxWeight = builder.getMaximumWeight();
/*  101: 249 */     this.weigher = builder.getWeigher();
/*  102: 250 */     this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
/*  103: 251 */     this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
/*  104: 252 */     this.refreshNanos = builder.getRefreshNanos();
/*  105:     */     
/*  106: 254 */     this.removalListener = builder.getRemovalListener();
/*  107: 255 */     this.removalNotificationQueue = (this.removalListener == CacheBuilder.NullListener.INSTANCE ? discardingQueue() : new ConcurrentLinkedQueue());
/*  108:     */     
/*  109:     */ 
/*  110:     */ 
/*  111: 259 */     this.ticker = builder.getTicker(recordsTime());
/*  112: 260 */     this.entryFactory = EntryFactory.getFactory(this.keyStrength, usesAccessEntries(), usesWriteEntries());
/*  113: 261 */     this.globalStatsCounter = ((AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  114: 262 */     this.defaultLoader = loader;
/*  115:     */     
/*  116: 264 */     int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
/*  117: 265 */     if ((evictsBySize()) && (!customWeigher())) {
/*  118: 266 */       initialCapacity = Math.min(initialCapacity, (int)this.maxWeight);
/*  119:     */     }
/*  120: 274 */     int segmentShift = 0;
/*  121: 275 */     int segmentCount = 1;
/*  122: 277 */     while ((segmentCount < this.concurrencyLevel) && ((!evictsBySize()) || (segmentCount * 20 <= this.maxWeight)))
/*  123:     */     {
/*  124: 278 */       segmentShift++;
/*  125: 279 */       segmentCount <<= 1;
/*  126:     */     }
/*  127: 281 */     this.segmentShift = (32 - segmentShift);
/*  128: 282 */     this.segmentMask = (segmentCount - 1);
/*  129:     */     
/*  130: 284 */     this.segments = newSegmentArray(segmentCount);
/*  131:     */     
/*  132: 286 */     int segmentCapacity = initialCapacity / segmentCount;
/*  133: 287 */     if (segmentCapacity * segmentCount < initialCapacity) {
/*  134: 288 */       segmentCapacity++;
/*  135:     */     }
/*  136: 291 */     int segmentSize = 1;
/*  137: 292 */     while (segmentSize < segmentCapacity) {
/*  138: 293 */       segmentSize <<= 1;
/*  139:     */     }
/*  140: 296 */     if (evictsBySize())
/*  141:     */     {
/*  142: 298 */       long maxSegmentWeight = this.maxWeight / segmentCount + 1L;
/*  143: 299 */       long remainder = this.maxWeight % segmentCount;
/*  144: 300 */       for (int i = 0; i < this.segments.length; i++)
/*  145:     */       {
/*  146: 301 */         if (i == remainder) {
/*  147: 302 */           maxSegmentWeight -= 1L;
/*  148:     */         }
/*  149: 304 */         this.segments[i] = createSegment(segmentSize, maxSegmentWeight, (AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  150:     */       }
/*  151:     */     }
/*  152:     */     else
/*  153:     */     {
/*  154: 308 */       for (int i = 0; i < this.segments.length; i++) {
/*  155: 309 */         this.segments[i] = createSegment(segmentSize, -1L, (AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  156:     */       }
/*  157:     */     }
/*  158:     */   }
/*  159:     */   
/*  160:     */   boolean evictsBySize()
/*  161:     */   {
/*  162: 316 */     return this.maxWeight >= 0L;
/*  163:     */   }
/*  164:     */   
/*  165:     */   boolean customWeigher()
/*  166:     */   {
/*  167: 320 */     return this.weigher != CacheBuilder.OneWeigher.INSTANCE;
/*  168:     */   }
/*  169:     */   
/*  170:     */   boolean expires()
/*  171:     */   {
/*  172: 324 */     return (expiresAfterWrite()) || (expiresAfterAccess());
/*  173:     */   }
/*  174:     */   
/*  175:     */   boolean expiresAfterWrite()
/*  176:     */   {
/*  177: 328 */     return this.expireAfterWriteNanos > 0L;
/*  178:     */   }
/*  179:     */   
/*  180:     */   boolean expiresAfterAccess()
/*  181:     */   {
/*  182: 332 */     return this.expireAfterAccessNanos > 0L;
/*  183:     */   }
/*  184:     */   
/*  185:     */   boolean refreshes()
/*  186:     */   {
/*  187: 336 */     return this.refreshNanos > 0L;
/*  188:     */   }
/*  189:     */   
/*  190:     */   boolean usesAccessQueue()
/*  191:     */   {
/*  192: 340 */     return (expiresAfterAccess()) || (evictsBySize());
/*  193:     */   }
/*  194:     */   
/*  195:     */   boolean usesWriteQueue()
/*  196:     */   {
/*  197: 344 */     return expiresAfterWrite();
/*  198:     */   }
/*  199:     */   
/*  200:     */   boolean recordsWrite()
/*  201:     */   {
/*  202: 348 */     return (expiresAfterWrite()) || (refreshes());
/*  203:     */   }
/*  204:     */   
/*  205:     */   boolean recordsAccess()
/*  206:     */   {
/*  207: 352 */     return expiresAfterAccess();
/*  208:     */   }
/*  209:     */   
/*  210:     */   boolean recordsTime()
/*  211:     */   {
/*  212: 356 */     return (recordsWrite()) || (recordsAccess());
/*  213:     */   }
/*  214:     */   
/*  215:     */   boolean usesWriteEntries()
/*  216:     */   {
/*  217: 360 */     return (usesWriteQueue()) || (recordsWrite());
/*  218:     */   }
/*  219:     */   
/*  220:     */   boolean usesAccessEntries()
/*  221:     */   {
/*  222: 364 */     return (usesAccessQueue()) || (recordsAccess());
/*  223:     */   }
/*  224:     */   
/*  225:     */   boolean usesKeyReferences()
/*  226:     */   {
/*  227: 368 */     return this.keyStrength != Strength.STRONG;
/*  228:     */   }
/*  229:     */   
/*  230:     */   boolean usesValueReferences()
/*  231:     */   {
/*  232: 372 */     return this.valueStrength != Strength.STRONG;
/*  233:     */   }
/*  234:     */   
/*  235:     */   static abstract enum Strength
/*  236:     */   {
/*  237: 381 */     STRONG,  SOFT,  WEAK;
/*  238:     */     
/*  239:     */     private Strength() {}
/*  240:     */     
/*  241:     */     abstract <K, V> LocalCache.ValueReference<K, V> referenceValue(LocalCache.Segment<K, V> paramSegment, LocalCache.ReferenceEntry<K, V> paramReferenceEntry, V paramV, int paramInt);
/*  242:     */     
/*  243:     */     abstract Equivalence<Object> defaultEquivalence();
/*  244:     */   }
/*  245:     */   
/*  246:     */   static abstract enum EntryFactory
/*  247:     */   {
/*  248: 446 */     STRONG,  STRONG_ACCESS,  STRONG_WRITE,  STRONG_ACCESS_WRITE,  WEAK,  WEAK_ACCESS,  WEAK_WRITE,  WEAK_ACCESS_WRITE;
/*  249:     */     
/*  250:     */     static final int ACCESS_MASK = 1;
/*  251:     */     static final int WRITE_MASK = 2;
/*  252:     */     static final int WEAK_MASK = 4;
/*  253: 564 */     static final EntryFactory[] factories = { STRONG, STRONG_ACCESS, STRONG_WRITE, STRONG_ACCESS_WRITE, WEAK, WEAK_ACCESS, WEAK_WRITE, WEAK_ACCESS_WRITE };
/*  254:     */     
/*  255:     */     private EntryFactory() {}
/*  256:     */     
/*  257:     */     static EntryFactory getFactory(LocalCache.Strength keyStrength, boolean usesAccessQueue, boolean usesWriteQueue)
/*  258:     */     {
/*  259: 571 */       int flags = (keyStrength == LocalCache.Strength.WEAK ? 4 : 0) | (usesAccessQueue ? 1 : 0) | (usesWriteQueue ? 2 : 0);
/*  260:     */       
/*  261:     */ 
/*  262: 574 */       return factories[flags];
/*  263:     */     }
/*  264:     */     
/*  265:     */     abstract <K, V> LocalCache.ReferenceEntry<K, V> newEntry(LocalCache.Segment<K, V> paramSegment, K paramK, int paramInt, @Nullable LocalCache.ReferenceEntry<K, V> paramReferenceEntry);
/*  266:     */     
/*  267:     */     @GuardedBy("Segment.this")
/*  268:     */     <K, V> LocalCache.ReferenceEntry<K, V> copyEntry(LocalCache.Segment<K, V> segment, LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newNext)
/*  269:     */     {
/*  270: 597 */       return newEntry(segment, original.getKey(), original.getHash(), newNext);
/*  271:     */     }
/*  272:     */     
/*  273:     */     @GuardedBy("Segment.this")
/*  274:     */     <K, V> void copyAccessEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newEntry)
/*  275:     */     {
/*  276: 604 */       newEntry.setAccessTime(original.getAccessTime());
/*  277:     */       
/*  278: 606 */       LocalCache.connectAccessOrder(original.getPreviousInAccessQueue(), newEntry);
/*  279: 607 */       LocalCache.connectAccessOrder(newEntry, original.getNextInAccessQueue());
/*  280:     */       
/*  281: 609 */       LocalCache.nullifyAccessOrder(original);
/*  282:     */     }
/*  283:     */     
/*  284:     */     @GuardedBy("Segment.this")
/*  285:     */     <K, V> void copyWriteEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newEntry)
/*  286:     */     {
/*  287: 616 */       newEntry.setWriteTime(original.getWriteTime());
/*  288:     */       
/*  289: 618 */       LocalCache.connectWriteOrder(original.getPreviousInWriteQueue(), newEntry);
/*  290: 619 */       LocalCache.connectWriteOrder(newEntry, original.getNextInWriteQueue());
/*  291:     */       
/*  292: 621 */       LocalCache.nullifyWriteOrder(original);
/*  293:     */     }
/*  294:     */   }
/*  295:     */   
/*  296: 690 */   static final ValueReference<Object, Object> UNSET = new ValueReference()
/*  297:     */   {
/*  298:     */     public Object get()
/*  299:     */     {
/*  300: 693 */       return null;
/*  301:     */     }
/*  302:     */     
/*  303:     */     public int getWeight()
/*  304:     */     {
/*  305: 698 */       return 0;
/*  306:     */     }
/*  307:     */     
/*  308:     */     public LocalCache.ReferenceEntry<Object, Object> getEntry()
/*  309:     */     {
/*  310: 703 */       return null;
/*  311:     */     }
/*  312:     */     
/*  313:     */     public LocalCache.ValueReference<Object, Object> copyFor(ReferenceQueue<Object> queue, @Nullable Object value, LocalCache.ReferenceEntry<Object, Object> entry)
/*  314:     */     {
/*  315: 709 */       return this;
/*  316:     */     }
/*  317:     */     
/*  318:     */     public boolean isLoading()
/*  319:     */     {
/*  320: 714 */       return false;
/*  321:     */     }
/*  322:     */     
/*  323:     */     public boolean isActive()
/*  324:     */     {
/*  325: 719 */       return false;
/*  326:     */     }
/*  327:     */     
/*  328:     */     public Object waitForValue()
/*  329:     */     {
/*  330: 724 */       return null;
/*  331:     */     }
/*  332:     */     
/*  333:     */     public void notifyNewValue(Object newValue) {}
/*  334:     */   };
/*  335:     */   
/*  336:     */   static <K, V> ValueReference<K, V> unset()
/*  337:     */   {
/*  338: 736 */     return UNSET;
/*  339:     */   }
/*  340:     */   
/*  341:     */   private static enum NullEntry
/*  342:     */     implements LocalCache.ReferenceEntry<Object, Object>
/*  343:     */   {
/*  344: 855 */     INSTANCE;
/*  345:     */     
/*  346:     */     private NullEntry() {}
/*  347:     */     
/*  348:     */     public LocalCache.ValueReference<Object, Object> getValueReference()
/*  349:     */     {
/*  350: 859 */       return null;
/*  351:     */     }
/*  352:     */     
/*  353:     */     public void setValueReference(LocalCache.ValueReference<Object, Object> valueReference) {}
/*  354:     */     
/*  355:     */     public LocalCache.ReferenceEntry<Object, Object> getNext()
/*  356:     */     {
/*  357: 867 */       return null;
/*  358:     */     }
/*  359:     */     
/*  360:     */     public int getHash()
/*  361:     */     {
/*  362: 872 */       return 0;
/*  363:     */     }
/*  364:     */     
/*  365:     */     public Object getKey()
/*  366:     */     {
/*  367: 877 */       return null;
/*  368:     */     }
/*  369:     */     
/*  370:     */     public long getAccessTime()
/*  371:     */     {
/*  372: 882 */       return 0L;
/*  373:     */     }
/*  374:     */     
/*  375:     */     public void setAccessTime(long time) {}
/*  376:     */     
/*  377:     */     public LocalCache.ReferenceEntry<Object, Object> getNextInAccessQueue()
/*  378:     */     {
/*  379: 890 */       return this;
/*  380:     */     }
/*  381:     */     
/*  382:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<Object, Object> next) {}
/*  383:     */     
/*  384:     */     public LocalCache.ReferenceEntry<Object, Object> getPreviousInAccessQueue()
/*  385:     */     {
/*  386: 898 */       return this;
/*  387:     */     }
/*  388:     */     
/*  389:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<Object, Object> previous) {}
/*  390:     */     
/*  391:     */     public long getWriteTime()
/*  392:     */     {
/*  393: 906 */       return 0L;
/*  394:     */     }
/*  395:     */     
/*  396:     */     public void setWriteTime(long time) {}
/*  397:     */     
/*  398:     */     public LocalCache.ReferenceEntry<Object, Object> getNextInWriteQueue()
/*  399:     */     {
/*  400: 914 */       return this;
/*  401:     */     }
/*  402:     */     
/*  403:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<Object, Object> next) {}
/*  404:     */     
/*  405:     */     public LocalCache.ReferenceEntry<Object, Object> getPreviousInWriteQueue()
/*  406:     */     {
/*  407: 922 */       return this;
/*  408:     */     }
/*  409:     */     
/*  410:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<Object, Object> previous) {}
/*  411:     */   }
/*  412:     */   
/*  413:     */   static abstract class AbstractReferenceEntry<K, V>
/*  414:     */     implements LocalCache.ReferenceEntry<K, V>
/*  415:     */   {
/*  416:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  417:     */     {
/*  418: 932 */       throw new UnsupportedOperationException();
/*  419:     */     }
/*  420:     */     
/*  421:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  422:     */     {
/*  423: 937 */       throw new UnsupportedOperationException();
/*  424:     */     }
/*  425:     */     
/*  426:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  427:     */     {
/*  428: 942 */       throw new UnsupportedOperationException();
/*  429:     */     }
/*  430:     */     
/*  431:     */     public int getHash()
/*  432:     */     {
/*  433: 947 */       throw new UnsupportedOperationException();
/*  434:     */     }
/*  435:     */     
/*  436:     */     public K getKey()
/*  437:     */     {
/*  438: 952 */       throw new UnsupportedOperationException();
/*  439:     */     }
/*  440:     */     
/*  441:     */     public long getAccessTime()
/*  442:     */     {
/*  443: 957 */       throw new UnsupportedOperationException();
/*  444:     */     }
/*  445:     */     
/*  446:     */     public void setAccessTime(long time)
/*  447:     */     {
/*  448: 962 */       throw new UnsupportedOperationException();
/*  449:     */     }
/*  450:     */     
/*  451:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  452:     */     {
/*  453: 967 */       throw new UnsupportedOperationException();
/*  454:     */     }
/*  455:     */     
/*  456:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  457:     */     {
/*  458: 972 */       throw new UnsupportedOperationException();
/*  459:     */     }
/*  460:     */     
/*  461:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  462:     */     {
/*  463: 977 */       throw new UnsupportedOperationException();
/*  464:     */     }
/*  465:     */     
/*  466:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  467:     */     {
/*  468: 982 */       throw new UnsupportedOperationException();
/*  469:     */     }
/*  470:     */     
/*  471:     */     public long getWriteTime()
/*  472:     */     {
/*  473: 987 */       throw new UnsupportedOperationException();
/*  474:     */     }
/*  475:     */     
/*  476:     */     public void setWriteTime(long time)
/*  477:     */     {
/*  478: 992 */       throw new UnsupportedOperationException();
/*  479:     */     }
/*  480:     */     
/*  481:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  482:     */     {
/*  483: 997 */       throw new UnsupportedOperationException();
/*  484:     */     }
/*  485:     */     
/*  486:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  487:     */     {
/*  488:1002 */       throw new UnsupportedOperationException();
/*  489:     */     }
/*  490:     */     
/*  491:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  492:     */     {
/*  493:1007 */       throw new UnsupportedOperationException();
/*  494:     */     }
/*  495:     */     
/*  496:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  497:     */     {
/*  498:1012 */       throw new UnsupportedOperationException();
/*  499:     */     }
/*  500:     */   }
/*  501:     */   
/*  502:     */   static <K, V> ReferenceEntry<K, V> nullEntry()
/*  503:     */   {
/*  504:1018 */     return NullEntry.INSTANCE;
/*  505:     */   }
/*  506:     */   
/*  507:1021 */   static final Queue<? extends Object> DISCARDING_QUEUE = new AbstractQueue()
/*  508:     */   {
/*  509:     */     public boolean offer(Object o)
/*  510:     */     {
/*  511:1024 */       return true;
/*  512:     */     }
/*  513:     */     
/*  514:     */     public Object peek()
/*  515:     */     {
/*  516:1029 */       return null;
/*  517:     */     }
/*  518:     */     
/*  519:     */     public Object poll()
/*  520:     */     {
/*  521:1034 */       return null;
/*  522:     */     }
/*  523:     */     
/*  524:     */     public int size()
/*  525:     */     {
/*  526:1039 */       return 0;
/*  527:     */     }
/*  528:     */     
/*  529:     */     public Iterator<Object> iterator()
/*  530:     */     {
/*  531:1044 */       return Iterators.emptyIterator();
/*  532:     */     }
/*  533:     */   };
/*  534:     */   Set<K> keySet;
/*  535:     */   Collection<V> values;
/*  536:     */   Set<Map.Entry<K, V>> entrySet;
/*  537:     */   
/*  538:     */   static <E> Queue<E> discardingQueue()
/*  539:     */   {
/*  540:1053 */     return DISCARDING_QUEUE;
/*  541:     */   }
/*  542:     */   
/*  543:     */   static class StrongEntry<K, V>
/*  544:     */     extends LocalCache.AbstractReferenceEntry<K, V>
/*  545:     */   {
/*  546:     */     final K key;
/*  547:     */     final int hash;
/*  548:     */     final LocalCache.ReferenceEntry<K, V> next;
/*  549:     */     
/*  550:     */     StrongEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  551:     */     {
/*  552:1071 */       this.key = key;
/*  553:1072 */       this.hash = hash;
/*  554:1073 */       this.next = next;
/*  555:     */     }
/*  556:     */     
/*  557:     */     public K getKey()
/*  558:     */     {
/*  559:1078 */       return this.key;
/*  560:     */     }
/*  561:     */     
/*  562:1085 */     volatile LocalCache.ValueReference<K, V> valueReference = LocalCache.unset();
/*  563:     */     
/*  564:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  565:     */     {
/*  566:1089 */       return this.valueReference;
/*  567:     */     }
/*  568:     */     
/*  569:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  570:     */     {
/*  571:1094 */       this.valueReference = valueReference;
/*  572:     */     }
/*  573:     */     
/*  574:     */     public int getHash()
/*  575:     */     {
/*  576:1099 */       return this.hash;
/*  577:     */     }
/*  578:     */     
/*  579:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  580:     */     {
/*  581:1104 */       return this.next;
/*  582:     */     }
/*  583:     */   }
/*  584:     */   
/*  585:     */   static final class StrongAccessEntry<K, V>
/*  586:     */     extends LocalCache.StrongEntry<K, V>
/*  587:     */   {
/*  588:     */     StrongAccessEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  589:     */     {
/*  590:1110 */       super(hash, next);
/*  591:     */     }
/*  592:     */     
/*  593:1115 */     volatile long accessTime = 9223372036854775807L;
/*  594:     */     
/*  595:     */     public long getAccessTime()
/*  596:     */     {
/*  597:1119 */       return this.accessTime;
/*  598:     */     }
/*  599:     */     
/*  600:     */     public void setAccessTime(long time)
/*  601:     */     {
/*  602:1124 */       this.accessTime = time;
/*  603:     */     }
/*  604:     */     
/*  605:     */     @GuardedBy("Segment.this")
/*  606:1127 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  607:     */     
/*  608:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  609:     */     {
/*  610:1132 */       return this.nextAccess;
/*  611:     */     }
/*  612:     */     
/*  613:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  614:     */     {
/*  615:1137 */       this.nextAccess = next;
/*  616:     */     }
/*  617:     */     
/*  618:     */     @GuardedBy("Segment.this")
/*  619:1140 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  620:     */     
/*  621:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  622:     */     {
/*  623:1145 */       return this.previousAccess;
/*  624:     */     }
/*  625:     */     
/*  626:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  627:     */     {
/*  628:1150 */       this.previousAccess = previous;
/*  629:     */     }
/*  630:     */   }
/*  631:     */   
/*  632:     */   static final class StrongWriteEntry<K, V>
/*  633:     */     extends LocalCache.StrongEntry<K, V>
/*  634:     */   {
/*  635:     */     StrongWriteEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  636:     */     {
/*  637:1156 */       super(hash, next);
/*  638:     */     }
/*  639:     */     
/*  640:1161 */     volatile long writeTime = 9223372036854775807L;
/*  641:     */     
/*  642:     */     public long getWriteTime()
/*  643:     */     {
/*  644:1165 */       return this.writeTime;
/*  645:     */     }
/*  646:     */     
/*  647:     */     public void setWriteTime(long time)
/*  648:     */     {
/*  649:1170 */       this.writeTime = time;
/*  650:     */     }
/*  651:     */     
/*  652:     */     @GuardedBy("Segment.this")
/*  653:1173 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  654:     */     
/*  655:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  656:     */     {
/*  657:1178 */       return this.nextWrite;
/*  658:     */     }
/*  659:     */     
/*  660:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  661:     */     {
/*  662:1183 */       this.nextWrite = next;
/*  663:     */     }
/*  664:     */     
/*  665:     */     @GuardedBy("Segment.this")
/*  666:1186 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  667:     */     
/*  668:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  669:     */     {
/*  670:1191 */       return this.previousWrite;
/*  671:     */     }
/*  672:     */     
/*  673:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  674:     */     {
/*  675:1196 */       this.previousWrite = previous;
/*  676:     */     }
/*  677:     */   }
/*  678:     */   
/*  679:     */   static final class StrongAccessWriteEntry<K, V>
/*  680:     */     extends LocalCache.StrongEntry<K, V>
/*  681:     */   {
/*  682:     */     StrongAccessWriteEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  683:     */     {
/*  684:1202 */       super(hash, next);
/*  685:     */     }
/*  686:     */     
/*  687:1207 */     volatile long accessTime = 9223372036854775807L;
/*  688:     */     
/*  689:     */     public long getAccessTime()
/*  690:     */     {
/*  691:1211 */       return this.accessTime;
/*  692:     */     }
/*  693:     */     
/*  694:     */     public void setAccessTime(long time)
/*  695:     */     {
/*  696:1216 */       this.accessTime = time;
/*  697:     */     }
/*  698:     */     
/*  699:     */     @GuardedBy("Segment.this")
/*  700:1219 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  701:     */     
/*  702:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  703:     */     {
/*  704:1224 */       return this.nextAccess;
/*  705:     */     }
/*  706:     */     
/*  707:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  708:     */     {
/*  709:1229 */       this.nextAccess = next;
/*  710:     */     }
/*  711:     */     
/*  712:     */     @GuardedBy("Segment.this")
/*  713:1232 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  714:     */     
/*  715:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  716:     */     {
/*  717:1237 */       return this.previousAccess;
/*  718:     */     }
/*  719:     */     
/*  720:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  721:     */     {
/*  722:1242 */       this.previousAccess = previous;
/*  723:     */     }
/*  724:     */     
/*  725:1247 */     volatile long writeTime = 9223372036854775807L;
/*  726:     */     
/*  727:     */     public long getWriteTime()
/*  728:     */     {
/*  729:1251 */       return this.writeTime;
/*  730:     */     }
/*  731:     */     
/*  732:     */     public void setWriteTime(long time)
/*  733:     */     {
/*  734:1256 */       this.writeTime = time;
/*  735:     */     }
/*  736:     */     
/*  737:     */     @GuardedBy("Segment.this")
/*  738:1259 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  739:     */     
/*  740:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  741:     */     {
/*  742:1264 */       return this.nextWrite;
/*  743:     */     }
/*  744:     */     
/*  745:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  746:     */     {
/*  747:1269 */       this.nextWrite = next;
/*  748:     */     }
/*  749:     */     
/*  750:     */     @GuardedBy("Segment.this")
/*  751:1272 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  752:     */     
/*  753:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  754:     */     {
/*  755:1277 */       return this.previousWrite;
/*  756:     */     }
/*  757:     */     
/*  758:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  759:     */     {
/*  760:1282 */       this.previousWrite = previous;
/*  761:     */     }
/*  762:     */   }
/*  763:     */   
/*  764:     */   static class WeakEntry<K, V>
/*  765:     */     extends WeakReference<K>
/*  766:     */     implements LocalCache.ReferenceEntry<K, V>
/*  767:     */   {
/*  768:     */     final int hash;
/*  769:     */     final LocalCache.ReferenceEntry<K, V> next;
/*  770:     */     
/*  771:     */     WeakEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  772:     */     {
/*  773:1291 */       super(queue);
/*  774:1292 */       this.hash = hash;
/*  775:1293 */       this.next = next;
/*  776:     */     }
/*  777:     */     
/*  778:     */     public K getKey()
/*  779:     */     {
/*  780:1298 */       return get();
/*  781:     */     }
/*  782:     */     
/*  783:     */     public long getAccessTime()
/*  784:     */     {
/*  785:1310 */       throw new UnsupportedOperationException();
/*  786:     */     }
/*  787:     */     
/*  788:     */     public void setAccessTime(long time)
/*  789:     */     {
/*  790:1315 */       throw new UnsupportedOperationException();
/*  791:     */     }
/*  792:     */     
/*  793:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  794:     */     {
/*  795:1320 */       throw new UnsupportedOperationException();
/*  796:     */     }
/*  797:     */     
/*  798:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  799:     */     {
/*  800:1325 */       throw new UnsupportedOperationException();
/*  801:     */     }
/*  802:     */     
/*  803:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  804:     */     {
/*  805:1330 */       throw new UnsupportedOperationException();
/*  806:     */     }
/*  807:     */     
/*  808:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  809:     */     {
/*  810:1335 */       throw new UnsupportedOperationException();
/*  811:     */     }
/*  812:     */     
/*  813:     */     public long getWriteTime()
/*  814:     */     {
/*  815:1342 */       throw new UnsupportedOperationException();
/*  816:     */     }
/*  817:     */     
/*  818:     */     public void setWriteTime(long time)
/*  819:     */     {
/*  820:1347 */       throw new UnsupportedOperationException();
/*  821:     */     }
/*  822:     */     
/*  823:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  824:     */     {
/*  825:1352 */       throw new UnsupportedOperationException();
/*  826:     */     }
/*  827:     */     
/*  828:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  829:     */     {
/*  830:1357 */       throw new UnsupportedOperationException();
/*  831:     */     }
/*  832:     */     
/*  833:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  834:     */     {
/*  835:1362 */       throw new UnsupportedOperationException();
/*  836:     */     }
/*  837:     */     
/*  838:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  839:     */     {
/*  840:1367 */       throw new UnsupportedOperationException();
/*  841:     */     }
/*  842:     */     
/*  843:1374 */     volatile LocalCache.ValueReference<K, V> valueReference = LocalCache.unset();
/*  844:     */     
/*  845:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  846:     */     {
/*  847:1378 */       return this.valueReference;
/*  848:     */     }
/*  849:     */     
/*  850:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  851:     */     {
/*  852:1383 */       this.valueReference = valueReference;
/*  853:     */     }
/*  854:     */     
/*  855:     */     public int getHash()
/*  856:     */     {
/*  857:1388 */       return this.hash;
/*  858:     */     }
/*  859:     */     
/*  860:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  861:     */     {
/*  862:1393 */       return this.next;
/*  863:     */     }
/*  864:     */   }
/*  865:     */   
/*  866:     */   static final class WeakAccessEntry<K, V>
/*  867:     */     extends LocalCache.WeakEntry<K, V>
/*  868:     */   {
/*  869:     */     WeakAccessEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  870:     */     {
/*  871:1400 */       super(key, hash, next);
/*  872:     */     }
/*  873:     */     
/*  874:1405 */     volatile long accessTime = 9223372036854775807L;
/*  875:     */     
/*  876:     */     public long getAccessTime()
/*  877:     */     {
/*  878:1409 */       return this.accessTime;
/*  879:     */     }
/*  880:     */     
/*  881:     */     public void setAccessTime(long time)
/*  882:     */     {
/*  883:1414 */       this.accessTime = time;
/*  884:     */     }
/*  885:     */     
/*  886:     */     @GuardedBy("Segment.this")
/*  887:1417 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  888:     */     
/*  889:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  890:     */     {
/*  891:1422 */       return this.nextAccess;
/*  892:     */     }
/*  893:     */     
/*  894:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  895:     */     {
/*  896:1427 */       this.nextAccess = next;
/*  897:     */     }
/*  898:     */     
/*  899:     */     @GuardedBy("Segment.this")
/*  900:1430 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  901:     */     
/*  902:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  903:     */     {
/*  904:1435 */       return this.previousAccess;
/*  905:     */     }
/*  906:     */     
/*  907:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  908:     */     {
/*  909:1440 */       this.previousAccess = previous;
/*  910:     */     }
/*  911:     */   }
/*  912:     */   
/*  913:     */   static final class WeakWriteEntry<K, V>
/*  914:     */     extends LocalCache.WeakEntry<K, V>
/*  915:     */   {
/*  916:     */     WeakWriteEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  917:     */     {
/*  918:1447 */       super(key, hash, next);
/*  919:     */     }
/*  920:     */     
/*  921:1452 */     volatile long writeTime = 9223372036854775807L;
/*  922:     */     
/*  923:     */     public long getWriteTime()
/*  924:     */     {
/*  925:1456 */       return this.writeTime;
/*  926:     */     }
/*  927:     */     
/*  928:     */     public void setWriteTime(long time)
/*  929:     */     {
/*  930:1461 */       this.writeTime = time;
/*  931:     */     }
/*  932:     */     
/*  933:     */     @GuardedBy("Segment.this")
/*  934:1464 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  935:     */     
/*  936:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  937:     */     {
/*  938:1469 */       return this.nextWrite;
/*  939:     */     }
/*  940:     */     
/*  941:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  942:     */     {
/*  943:1474 */       this.nextWrite = next;
/*  944:     */     }
/*  945:     */     
/*  946:     */     @GuardedBy("Segment.this")
/*  947:1477 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  948:     */     
/*  949:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  950:     */     {
/*  951:1482 */       return this.previousWrite;
/*  952:     */     }
/*  953:     */     
/*  954:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  955:     */     {
/*  956:1487 */       this.previousWrite = previous;
/*  957:     */     }
/*  958:     */   }
/*  959:     */   
/*  960:     */   static final class WeakAccessWriteEntry<K, V>
/*  961:     */     extends LocalCache.WeakEntry<K, V>
/*  962:     */   {
/*  963:     */     WeakAccessWriteEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  964:     */     {
/*  965:1494 */       super(key, hash, next);
/*  966:     */     }
/*  967:     */     
/*  968:1499 */     volatile long accessTime = 9223372036854775807L;
/*  969:     */     
/*  970:     */     public long getAccessTime()
/*  971:     */     {
/*  972:1503 */       return this.accessTime;
/*  973:     */     }
/*  974:     */     
/*  975:     */     public void setAccessTime(long time)
/*  976:     */     {
/*  977:1508 */       this.accessTime = time;
/*  978:     */     }
/*  979:     */     
/*  980:     */     @GuardedBy("Segment.this")
/*  981:1511 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  982:     */     
/*  983:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  984:     */     {
/*  985:1516 */       return this.nextAccess;
/*  986:     */     }
/*  987:     */     
/*  988:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  989:     */     {
/*  990:1521 */       this.nextAccess = next;
/*  991:     */     }
/*  992:     */     
/*  993:     */     @GuardedBy("Segment.this")
/*  994:1524 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  995:     */     
/*  996:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  997:     */     {
/*  998:1529 */       return this.previousAccess;
/*  999:     */     }
/* 1000:     */     
/* 1001:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 1002:     */     {
/* 1003:1534 */       this.previousAccess = previous;
/* 1004:     */     }
/* 1005:     */     
/* 1006:1539 */     volatile long writeTime = 9223372036854775807L;
/* 1007:     */     
/* 1008:     */     public long getWriteTime()
/* 1009:     */     {
/* 1010:1543 */       return this.writeTime;
/* 1011:     */     }
/* 1012:     */     
/* 1013:     */     public void setWriteTime(long time)
/* 1014:     */     {
/* 1015:1548 */       this.writeTime = time;
/* 1016:     */     }
/* 1017:     */     
/* 1018:     */     @GuardedBy("Segment.this")
/* 1019:1551 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/* 1020:     */     
/* 1021:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/* 1022:     */     {
/* 1023:1556 */       return this.nextWrite;
/* 1024:     */     }
/* 1025:     */     
/* 1026:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/* 1027:     */     {
/* 1028:1561 */       this.nextWrite = next;
/* 1029:     */     }
/* 1030:     */     
/* 1031:     */     @GuardedBy("Segment.this")
/* 1032:1564 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/* 1033:     */     
/* 1034:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/* 1035:     */     {
/* 1036:1569 */       return this.previousWrite;
/* 1037:     */     }
/* 1038:     */     
/* 1039:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 1040:     */     {
/* 1041:1574 */       this.previousWrite = previous;
/* 1042:     */     }
/* 1043:     */   }
/* 1044:     */   
/* 1045:     */   static class WeakValueReference<K, V>
/* 1046:     */     extends WeakReference<V>
/* 1047:     */     implements LocalCache.ValueReference<K, V>
/* 1048:     */   {
/* 1049:     */     final LocalCache.ReferenceEntry<K, V> entry;
/* 1050:     */     
/* 1051:     */     WeakValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry)
/* 1052:     */     {
/* 1053:1586 */       super(queue);
/* 1054:1587 */       this.entry = entry;
/* 1055:     */     }
/* 1056:     */     
/* 1057:     */     public int getWeight()
/* 1058:     */     {
/* 1059:1592 */       return 1;
/* 1060:     */     }
/* 1061:     */     
/* 1062:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1063:     */     {
/* 1064:1597 */       return this.entry;
/* 1065:     */     }
/* 1066:     */     
/* 1067:     */     public void notifyNewValue(V newValue) {}
/* 1068:     */     
/* 1069:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1070:     */     {
/* 1071:1606 */       return new WeakValueReference(queue, value, entry);
/* 1072:     */     }
/* 1073:     */     
/* 1074:     */     public boolean isLoading()
/* 1075:     */     {
/* 1076:1611 */       return false;
/* 1077:     */     }
/* 1078:     */     
/* 1079:     */     public boolean isActive()
/* 1080:     */     {
/* 1081:1616 */       return true;
/* 1082:     */     }
/* 1083:     */     
/* 1084:     */     public V waitForValue()
/* 1085:     */     {
/* 1086:1621 */       return get();
/* 1087:     */     }
/* 1088:     */   }
/* 1089:     */   
/* 1090:     */   static class SoftValueReference<K, V>
/* 1091:     */     extends SoftReference<V>
/* 1092:     */     implements LocalCache.ValueReference<K, V>
/* 1093:     */   {
/* 1094:     */     final LocalCache.ReferenceEntry<K, V> entry;
/* 1095:     */     
/* 1096:     */     SoftValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry)
/* 1097:     */     {
/* 1098:1633 */       super(queue);
/* 1099:1634 */       this.entry = entry;
/* 1100:     */     }
/* 1101:     */     
/* 1102:     */     public int getWeight()
/* 1103:     */     {
/* 1104:1639 */       return 1;
/* 1105:     */     }
/* 1106:     */     
/* 1107:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1108:     */     {
/* 1109:1644 */       return this.entry;
/* 1110:     */     }
/* 1111:     */     
/* 1112:     */     public void notifyNewValue(V newValue) {}
/* 1113:     */     
/* 1114:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1115:     */     {
/* 1116:1653 */       return new SoftValueReference(queue, value, entry);
/* 1117:     */     }
/* 1118:     */     
/* 1119:     */     public boolean isLoading()
/* 1120:     */     {
/* 1121:1658 */       return false;
/* 1122:     */     }
/* 1123:     */     
/* 1124:     */     public boolean isActive()
/* 1125:     */     {
/* 1126:1663 */       return true;
/* 1127:     */     }
/* 1128:     */     
/* 1129:     */     public V waitForValue()
/* 1130:     */     {
/* 1131:1668 */       return get();
/* 1132:     */     }
/* 1133:     */   }
/* 1134:     */   
/* 1135:     */   static class StrongValueReference<K, V>
/* 1136:     */     implements LocalCache.ValueReference<K, V>
/* 1137:     */   {
/* 1138:     */     final V referent;
/* 1139:     */     
/* 1140:     */     StrongValueReference(V referent)
/* 1141:     */     {
/* 1142:1679 */       this.referent = referent;
/* 1143:     */     }
/* 1144:     */     
/* 1145:     */     public V get()
/* 1146:     */     {
/* 1147:1684 */       return this.referent;
/* 1148:     */     }
/* 1149:     */     
/* 1150:     */     public int getWeight()
/* 1151:     */     {
/* 1152:1689 */       return 1;
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1156:     */     {
/* 1157:1694 */       return null;
/* 1158:     */     }
/* 1159:     */     
/* 1160:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1161:     */     {
/* 1162:1700 */       return this;
/* 1163:     */     }
/* 1164:     */     
/* 1165:     */     public boolean isLoading()
/* 1166:     */     {
/* 1167:1705 */       return false;
/* 1168:     */     }
/* 1169:     */     
/* 1170:     */     public boolean isActive()
/* 1171:     */     {
/* 1172:1710 */       return true;
/* 1173:     */     }
/* 1174:     */     
/* 1175:     */     public V waitForValue()
/* 1176:     */     {
/* 1177:1715 */       return get();
/* 1178:     */     }
/* 1179:     */     
/* 1180:     */     public void notifyNewValue(V newValue) {}
/* 1181:     */   }
/* 1182:     */   
/* 1183:     */   static final class WeightedWeakValueReference<K, V>
/* 1184:     */     extends LocalCache.WeakValueReference<K, V>
/* 1185:     */   {
/* 1186:     */     final int weight;
/* 1187:     */     
/* 1188:     */     WeightedWeakValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry, int weight)
/* 1189:     */     {
/* 1190:1730 */       super(referent, entry);
/* 1191:1731 */       this.weight = weight;
/* 1192:     */     }
/* 1193:     */     
/* 1194:     */     public int getWeight()
/* 1195:     */     {
/* 1196:1736 */       return this.weight;
/* 1197:     */     }
/* 1198:     */     
/* 1199:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1200:     */     {
/* 1201:1742 */       return new WeightedWeakValueReference(queue, value, entry, this.weight);
/* 1202:     */     }
/* 1203:     */   }
/* 1204:     */   
/* 1205:     */   static final class WeightedSoftValueReference<K, V>
/* 1206:     */     extends LocalCache.SoftValueReference<K, V>
/* 1207:     */   {
/* 1208:     */     final int weight;
/* 1209:     */     
/* 1210:     */     WeightedSoftValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry, int weight)
/* 1211:     */     {
/* 1212:1754 */       super(referent, entry);
/* 1213:1755 */       this.weight = weight;
/* 1214:     */     }
/* 1215:     */     
/* 1216:     */     public int getWeight()
/* 1217:     */     {
/* 1218:1760 */       return this.weight;
/* 1219:     */     }
/* 1220:     */     
/* 1221:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1222:     */     {
/* 1223:1765 */       return new WeightedSoftValueReference(queue, value, entry, this.weight);
/* 1224:     */     }
/* 1225:     */   }
/* 1226:     */   
/* 1227:     */   static final class WeightedStrongValueReference<K, V>
/* 1228:     */     extends LocalCache.StrongValueReference<K, V>
/* 1229:     */   {
/* 1230:     */     final int weight;
/* 1231:     */     
/* 1232:     */     WeightedStrongValueReference(V referent, int weight)
/* 1233:     */     {
/* 1234:1777 */       super();
/* 1235:1778 */       this.weight = weight;
/* 1236:     */     }
/* 1237:     */     
/* 1238:     */     public int getWeight()
/* 1239:     */     {
/* 1240:1783 */       return this.weight;
/* 1241:     */     }
/* 1242:     */   }
/* 1243:     */   
/* 1244:     */   static int rehash(int h)
/* 1245:     */   {
/* 1246:1799 */     h += (h << 15 ^ 0xFFFFCD7D);
/* 1247:1800 */     h ^= h >>> 10;
/* 1248:1801 */     h += (h << 3);
/* 1249:1802 */     h ^= h >>> 6;
/* 1250:1803 */     h += (h << 2) + (h << 14);
/* 1251:1804 */     return h ^ h >>> 16;
/* 1252:     */   }
/* 1253:     */   
/* 1254:     */   @GuardedBy("Segment.this")
/* 1255:     */   @VisibleForTesting
/* 1256:     */   ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next)
/* 1257:     */   {
/* 1258:1813 */     return segmentFor(hash).newEntry(key, hash, next);
/* 1259:     */   }
/* 1260:     */   
/* 1261:     */   @GuardedBy("Segment.this")
/* 1262:     */   @VisibleForTesting
/* 1263:     */   ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext)
/* 1264:     */   {
/* 1265:1822 */     int hash = original.getHash();
/* 1266:1823 */     return segmentFor(hash).copyEntry(original, newNext);
/* 1267:     */   }
/* 1268:     */   
/* 1269:     */   @GuardedBy("Segment.this")
/* 1270:     */   @VisibleForTesting
/* 1271:     */   ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value, int weight)
/* 1272:     */   {
/* 1273:1832 */     int hash = entry.getHash();
/* 1274:1833 */     return this.valueStrength.referenceValue(segmentFor(hash), entry, Preconditions.checkNotNull(value), weight);
/* 1275:     */   }
/* 1276:     */   
/* 1277:     */   int hash(@Nullable Object key)
/* 1278:     */   {
/* 1279:1837 */     int h = this.keyEquivalence.hash(key);
/* 1280:1838 */     return rehash(h);
/* 1281:     */   }
/* 1282:     */   
/* 1283:     */   void reclaimValue(ValueReference<K, V> valueReference)
/* 1284:     */   {
/* 1285:1842 */     ReferenceEntry<K, V> entry = valueReference.getEntry();
/* 1286:1843 */     int hash = entry.getHash();
/* 1287:1844 */     segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
/* 1288:     */   }
/* 1289:     */   
/* 1290:     */   void reclaimKey(ReferenceEntry<K, V> entry)
/* 1291:     */   {
/* 1292:1848 */     int hash = entry.getHash();
/* 1293:1849 */     segmentFor(hash).reclaimKey(entry, hash);
/* 1294:     */   }
/* 1295:     */   
/* 1296:     */   @VisibleForTesting
/* 1297:     */   boolean isLive(ReferenceEntry<K, V> entry, long now)
/* 1298:     */   {
/* 1299:1858 */     return segmentFor(entry.getHash()).getLiveValue(entry, now) != null;
/* 1300:     */   }
/* 1301:     */   
/* 1302:     */   Segment<K, V> segmentFor(int hash)
/* 1303:     */   {
/* 1304:1869 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/* 1305:     */   }
/* 1306:     */   
/* 1307:     */   Segment<K, V> createSegment(int initialCapacity, long maxSegmentWeight, AbstractCache.StatsCounter statsCounter)
/* 1308:     */   {
/* 1309:1874 */     return new Segment(this, initialCapacity, maxSegmentWeight, statsCounter);
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   @Nullable
/* 1313:     */   V getLiveValue(ReferenceEntry<K, V> entry, long now)
/* 1314:     */   {
/* 1315:1885 */     if (entry.getKey() == null) {
/* 1316:1886 */       return null;
/* 1317:     */     }
/* 1318:1888 */     V value = entry.getValueReference().get();
/* 1319:1889 */     if (value == null) {
/* 1320:1890 */       return null;
/* 1321:     */     }
/* 1322:1893 */     if (isExpired(entry, now)) {
/* 1323:1894 */       return null;
/* 1324:     */     }
/* 1325:1896 */     return value;
/* 1326:     */   }
/* 1327:     */   
/* 1328:     */   boolean isExpired(ReferenceEntry<K, V> entry, long now)
/* 1329:     */   {
/* 1330:1905 */     Preconditions.checkNotNull(entry);
/* 1331:1906 */     if ((expiresAfterAccess()) && (now - entry.getAccessTime() >= this.expireAfterAccessNanos)) {
/* 1332:1908 */       return true;
/* 1333:     */     }
/* 1334:1910 */     if ((expiresAfterWrite()) && (now - entry.getWriteTime() >= this.expireAfterWriteNanos)) {
/* 1335:1912 */       return true;
/* 1336:     */     }
/* 1337:1914 */     return false;
/* 1338:     */   }
/* 1339:     */   
/* 1340:     */   @GuardedBy("Segment.this")
/* 1341:     */   static <K, V> void connectAccessOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1342:     */   {
/* 1343:1921 */     previous.setNextInAccessQueue(next);
/* 1344:1922 */     next.setPreviousInAccessQueue(previous);
/* 1345:     */   }
/* 1346:     */   
/* 1347:     */   @GuardedBy("Segment.this")
/* 1348:     */   static <K, V> void nullifyAccessOrder(ReferenceEntry<K, V> nulled)
/* 1349:     */   {
/* 1350:1927 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1351:1928 */     nulled.setNextInAccessQueue(nullEntry);
/* 1352:1929 */     nulled.setPreviousInAccessQueue(nullEntry);
/* 1353:     */   }
/* 1354:     */   
/* 1355:     */   @GuardedBy("Segment.this")
/* 1356:     */   static <K, V> void connectWriteOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1357:     */   {
/* 1358:1934 */     previous.setNextInWriteQueue(next);
/* 1359:1935 */     next.setPreviousInWriteQueue(previous);
/* 1360:     */   }
/* 1361:     */   
/* 1362:     */   @GuardedBy("Segment.this")
/* 1363:     */   static <K, V> void nullifyWriteOrder(ReferenceEntry<K, V> nulled)
/* 1364:     */   {
/* 1365:1940 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1366:1941 */     nulled.setNextInWriteQueue(nullEntry);
/* 1367:1942 */     nulled.setPreviousInWriteQueue(nullEntry);
/* 1368:     */   }
/* 1369:     */   
/* 1370:     */   void processPendingNotifications()
/* 1371:     */   {
/* 1372:     */     RemovalNotification<K, V> notification;
/* 1373:1952 */     while ((notification = (RemovalNotification)this.removalNotificationQueue.poll()) != null) {
/* 1374:     */       try
/* 1375:     */       {
/* 1376:1954 */         this.removalListener.onRemoval(notification);
/* 1377:     */       }
/* 1378:     */       catch (Throwable e)
/* 1379:     */       {
/* 1380:1956 */         logger.log(Level.WARNING, "Exception thrown by removal listener", e);
/* 1381:     */       }
/* 1382:     */     }
/* 1383:     */   }
/* 1384:     */   
/* 1385:     */   final Segment<K, V>[] newSegmentArray(int ssize)
/* 1386:     */   {
/* 1387:1963 */     return new Segment[ssize];
/* 1388:     */   }
/* 1389:     */   
/* 1390:     */   static class Segment<K, V>
/* 1391:     */     extends ReentrantLock
/* 1392:     */   {
/* 1393:     */     final LocalCache<K, V> map;
/* 1394:     */     volatile int count;
/* 1395:     */     @GuardedBy("Segment.this")
/* 1396:     */     int totalWeight;
/* 1397:     */     int modCount;
/* 1398:     */     int threshold;
/* 1399:     */     volatile AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table;
/* 1400:     */     final long maxSegmentWeight;
/* 1401:     */     final ReferenceQueue<K> keyReferenceQueue;
/* 1402:     */     final ReferenceQueue<V> valueReferenceQueue;
/* 1403:     */     final Queue<LocalCache.ReferenceEntry<K, V>> recencyQueue;
/* 1404:2068 */     final AtomicInteger readCount = new AtomicInteger();
/* 1405:     */     @GuardedBy("Segment.this")
/* 1406:     */     final Queue<LocalCache.ReferenceEntry<K, V>> writeQueue;
/* 1407:     */     @GuardedBy("Segment.this")
/* 1408:     */     final Queue<LocalCache.ReferenceEntry<K, V>> accessQueue;
/* 1409:     */     final AbstractCache.StatsCounter statsCounter;
/* 1410:     */     
/* 1411:     */     Segment(LocalCache<K, V> map, int initialCapacity, long maxSegmentWeight, AbstractCache.StatsCounter statsCounter)
/* 1412:     */     {
/* 1413:2089 */       this.map = map;
/* 1414:2090 */       this.maxSegmentWeight = maxSegmentWeight;
/* 1415:2091 */       this.statsCounter = ((AbstractCache.StatsCounter)Preconditions.checkNotNull(statsCounter));
/* 1416:2092 */       initTable(newEntryArray(initialCapacity));
/* 1417:     */       
/* 1418:2094 */       this.keyReferenceQueue = (map.usesKeyReferences() ? new ReferenceQueue() : null);
/* 1419:     */       
/* 1420:     */ 
/* 1421:2097 */       this.valueReferenceQueue = (map.usesValueReferences() ? new ReferenceQueue() : null);
/* 1422:     */       
/* 1423:     */ 
/* 1424:2100 */       this.recencyQueue = (map.usesAccessQueue() ? new ConcurrentLinkedQueue() : LocalCache.discardingQueue());
/* 1425:     */       
/* 1426:     */ 
/* 1427:     */ 
/* 1428:2104 */       this.writeQueue = (map.usesWriteQueue() ? new LocalCache.WriteQueue() : LocalCache.discardingQueue());
/* 1429:     */       
/* 1430:     */ 
/* 1431:     */ 
/* 1432:2108 */       this.accessQueue = (map.usesAccessQueue() ? new LocalCache.AccessQueue() : LocalCache.discardingQueue());
/* 1433:     */     }
/* 1434:     */     
/* 1435:     */     AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newEntryArray(int size)
/* 1436:     */     {
/* 1437:2114 */       return new AtomicReferenceArray(size);
/* 1438:     */     }
/* 1439:     */     
/* 1440:     */     void initTable(AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newTable)
/* 1441:     */     {
/* 1442:2118 */       this.threshold = (newTable.length() * 3 / 4);
/* 1443:2119 */       if ((!this.map.customWeigher()) && (this.threshold == this.maxSegmentWeight)) {
/* 1444:2121 */         this.threshold += 1;
/* 1445:     */       }
/* 1446:2123 */       this.table = newTable;
/* 1447:     */     }
/* 1448:     */     
/* 1449:     */     @GuardedBy("Segment.this")
/* 1450:     */     LocalCache.ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/* 1451:     */     {
/* 1452:2128 */       return this.map.entryFactory.newEntry(this, Preconditions.checkNotNull(key), hash, next);
/* 1453:     */     }
/* 1454:     */     
/* 1455:     */     @GuardedBy("Segment.this")
/* 1456:     */     LocalCache.ReferenceEntry<K, V> copyEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newNext)
/* 1457:     */     {
/* 1458:2137 */       if (original.getKey() == null) {
/* 1459:2139 */         return null;
/* 1460:     */       }
/* 1461:2142 */       LocalCache.ValueReference<K, V> valueReference = original.getValueReference();
/* 1462:2143 */       V value = valueReference.get();
/* 1463:2144 */       if ((value == null) && (valueReference.isActive())) {
/* 1464:2146 */         return null;
/* 1465:     */       }
/* 1466:2149 */       LocalCache.ReferenceEntry<K, V> newEntry = this.map.entryFactory.copyEntry(this, original, newNext);
/* 1467:2150 */       newEntry.setValueReference(valueReference.copyFor(this.valueReferenceQueue, value, newEntry));
/* 1468:2151 */       return newEntry;
/* 1469:     */     }
/* 1470:     */     
/* 1471:     */     @GuardedBy("Segment.this")
/* 1472:     */     void setValue(LocalCache.ReferenceEntry<K, V> entry, K key, V value, long now)
/* 1473:     */     {
/* 1474:2159 */       LocalCache.ValueReference<K, V> previous = entry.getValueReference();
/* 1475:2160 */       int weight = this.map.weigher.weigh(key, value);
/* 1476:2161 */       Preconditions.checkState(weight >= 0, "Weights must be non-negative");
/* 1477:     */       
/* 1478:2163 */       LocalCache.ValueReference<K, V> valueReference = this.map.valueStrength.referenceValue(this, entry, value, weight);
/* 1479:     */       
/* 1480:2165 */       entry.setValueReference(valueReference);
/* 1481:2166 */       recordWrite(entry, weight, now);
/* 1482:2167 */       previous.notifyNewValue(value);
/* 1483:     */     }
/* 1484:     */     
/* 1485:     */     V get(K key, int hash, CacheLoader<? super K, V> loader)
/* 1486:     */       throws ExecutionException
/* 1487:     */     {
/* 1488:2173 */       Preconditions.checkNotNull(key);
/* 1489:2174 */       Preconditions.checkNotNull(loader);
/* 1490:     */       try
/* 1491:     */       {
/* 1492:     */         LocalCache.ReferenceEntry<K, V> e;
/* 1493:2176 */         if (this.count != 0)
/* 1494:     */         {
/* 1495:2178 */           e = getEntry(key, hash);
/* 1496:2179 */           if (e != null)
/* 1497:     */           {
/* 1498:2180 */             long now = this.map.ticker.read();
/* 1499:2181 */             V value = getLiveValue(e, now);
/* 1500:2182 */             if (value != null)
/* 1501:     */             {
/* 1502:2183 */               recordRead(e, now);
/* 1503:2184 */               this.statsCounter.recordHits(1);
/* 1504:2185 */               return scheduleRefresh(e, key, hash, value, now, loader);
/* 1505:     */             }
/* 1506:2187 */             Object valueReference = e.getValueReference();
/* 1507:2188 */             if (((LocalCache.ValueReference)valueReference).isLoading()) {
/* 1508:2189 */               return waitForLoadingValue(e, key, (LocalCache.ValueReference)valueReference);
/* 1509:     */             }
/* 1510:     */           }
/* 1511:     */         }
/* 1512:2195 */         return lockedGetOrLoad(key, hash, loader);
/* 1513:     */       }
/* 1514:     */       catch (ExecutionException ee)
/* 1515:     */       {
/* 1516:2197 */         Throwable cause = ee.getCause();
/* 1517:2198 */         if ((cause instanceof Error)) {
/* 1518:2199 */           throw new ExecutionError((Error)cause);
/* 1519:     */         }
/* 1520:2200 */         if ((cause instanceof RuntimeException)) {
/* 1521:2201 */           throw new UncheckedExecutionException(cause);
/* 1522:     */         }
/* 1523:2203 */         throw ee;
/* 1524:     */       }
/* 1525:     */       finally
/* 1526:     */       {
/* 1527:2205 */         postReadCleanup();
/* 1528:     */       }
/* 1529:     */     }
/* 1530:     */     
/* 1531:     */     V lockedGetOrLoad(K key, int hash, CacheLoader<? super K, V> loader)
/* 1532:     */       throws ExecutionException
/* 1533:     */     {
/* 1534:2212 */       valueReference = null;
/* 1535:2213 */       LocalCache.LoadingValueReference<K, V> loadingValueReference = null;
/* 1536:2214 */       boolean createNewEntry = true;
/* 1537:     */       
/* 1538:2216 */       lock();
/* 1539:     */       try
/* 1540:     */       {
/* 1541:2219 */         long now = this.map.ticker.read();
/* 1542:2220 */         preWriteCleanup(now);
/* 1543:     */         
/* 1544:2222 */         int newCount = this.count - 1;
/* 1545:2223 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 1546:2224 */         int index = hash & table.length() - 1;
/* 1547:2225 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 1548:2227 */         for (e = first; e != null; e = e.getNext())
/* 1549:     */         {
/* 1550:2228 */           K entryKey = e.getKey();
/* 1551:2229 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1552:     */           {
/* 1553:2231 */             valueReference = e.getValueReference();
/* 1554:2232 */             if (valueReference.isLoading())
/* 1555:     */             {
/* 1556:2233 */               createNewEntry = false; break;
/* 1557:     */             }
/* 1558:2235 */             V value = valueReference.get();
/* 1559:2236 */             if (value == null)
/* 1560:     */             {
/* 1561:2237 */               enqueueNotification(entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 1562:     */             }
/* 1563:2238 */             else if (this.map.isExpired(e, now))
/* 1564:     */             {
/* 1565:2241 */               enqueueNotification(entryKey, hash, valueReference, RemovalCause.EXPIRED);
/* 1566:     */             }
/* 1567:     */             else
/* 1568:     */             {
/* 1569:2243 */               recordLockedRead(e, now);
/* 1570:2244 */               this.statsCounter.recordHits(1);
/* 1571:     */               
/* 1572:2246 */               return value;
/* 1573:     */             }
/* 1574:2250 */             this.writeQueue.remove(e);
/* 1575:2251 */             this.accessQueue.remove(e);
/* 1576:2252 */             this.count = newCount;
/* 1577:     */             
/* 1578:2254 */             break;
/* 1579:     */           }
/* 1580:     */         }
/* 1581:2258 */         if (createNewEntry)
/* 1582:     */         {
/* 1583:2259 */           loadingValueReference = new LocalCache.LoadingValueReference();
/* 1584:2261 */           if (e == null)
/* 1585:     */           {
/* 1586:2262 */             e = newEntry(key, hash, first);
/* 1587:2263 */             e.setValueReference(loadingValueReference);
/* 1588:2264 */             table.set(index, e);
/* 1589:     */           }
/* 1590:     */           else
/* 1591:     */           {
/* 1592:2266 */             e.setValueReference(loadingValueReference);
/* 1593:     */           }
/* 1594:     */         }
/* 1595:     */       }
/* 1596:     */       finally
/* 1597:     */       {
/* 1598:2270 */         unlock();
/* 1599:2271 */         postWriteCleanup();
/* 1600:     */       }
/* 1601:2274 */       if (createNewEntry) {
/* 1602:     */         try
/* 1603:     */         {
/* 1604:2279 */           synchronized (e)
/* 1605:     */           {
/* 1606:2280 */             return loadSync(key, hash, loadingValueReference, loader);
/* 1607:     */           }
/* 1608:2287 */           return waitForLoadingValue(e, key, valueReference);
/* 1609:     */         }
/* 1610:     */         finally
/* 1611:     */         {
/* 1612:2283 */           this.statsCounter.recordMisses(1);
/* 1613:     */         }
/* 1614:     */       }
/* 1615:     */     }
/* 1616:     */     
/* 1617:     */     V waitForLoadingValue(LocalCache.ReferenceEntry<K, V> e, K key, LocalCache.ValueReference<K, V> valueReference)
/* 1618:     */       throws ExecutionException
/* 1619:     */     {
/* 1620:2293 */       if (!valueReference.isLoading()) {
/* 1621:2294 */         throw new AssertionError();
/* 1622:     */       }
/* 1623:2297 */       Preconditions.checkState(!Thread.holdsLock(e), "Recursive load of: %s", new Object[] { key });
/* 1624:     */       try
/* 1625:     */       {
/* 1626:2300 */         V value = valueReference.waitForValue();
/* 1627:2301 */         if (value == null) {
/* 1628:2302 */           throw new CacheLoader.InvalidCacheLoadException("CacheLoader returned null for key " + key + ".");
/* 1629:     */         }
/* 1630:2305 */         long now = this.map.ticker.read();
/* 1631:2306 */         recordRead(e, now);
/* 1632:2307 */         return value;
/* 1633:     */       }
/* 1634:     */       finally
/* 1635:     */       {
/* 1636:2309 */         this.statsCounter.recordMisses(1);
/* 1637:     */       }
/* 1638:     */     }
/* 1639:     */     
/* 1640:     */     V loadSync(K key, int hash, LocalCache.LoadingValueReference<K, V> loadingValueReference, CacheLoader<? super K, V> loader)
/* 1641:     */       throws ExecutionException
/* 1642:     */     {
/* 1643:2317 */       ListenableFuture<V> loadingFuture = loadingValueReference.loadFuture(key, loader);
/* 1644:2318 */       return getAndRecordStats(key, hash, loadingValueReference, loadingFuture);
/* 1645:     */     }
/* 1646:     */     
/* 1647:     */     ListenableFuture<V> loadAsync(final K key, final int hash, final LocalCache.LoadingValueReference<K, V> loadingValueReference, CacheLoader<? super K, V> loader)
/* 1648:     */     {
/* 1649:2323 */       final ListenableFuture<V> loadingFuture = loadingValueReference.loadFuture(key, loader);
/* 1650:2324 */       loadingFuture.addListener(new Runnable()
/* 1651:     */       {
/* 1652:     */         public void run()
/* 1653:     */         {
/* 1654:     */           try
/* 1655:     */           {
/* 1656:2329 */             newValue = LocalCache.Segment.this.getAndRecordStats(key, hash, loadingValueReference, loadingFuture);
/* 1657:     */           }
/* 1658:     */           catch (Throwable t)
/* 1659:     */           {
/* 1660:     */             V newValue;
/* 1661:2331 */             LocalCache.logger.log(Level.WARNING, "Exception thrown during refresh", t);
/* 1662:2332 */             loadingValueReference.setException(t);
/* 1663:     */           }
/* 1664:     */         }
/* 1665:2332 */       }, LocalCache.sameThreadExecutor);
/* 1666:     */       
/* 1667:     */ 
/* 1668:     */ 
/* 1669:2336 */       return loadingFuture;
/* 1670:     */     }
/* 1671:     */     
/* 1672:     */     V getAndRecordStats(K key, int hash, LocalCache.LoadingValueReference<K, V> loadingValueReference, ListenableFuture<V> newValue)
/* 1673:     */       throws ExecutionException
/* 1674:     */     {
/* 1675:2344 */       V value = null;
/* 1676:     */       try
/* 1677:     */       {
/* 1678:2346 */         value = Uninterruptibles.getUninterruptibly(newValue);
/* 1679:2347 */         if (value == null) {
/* 1680:2348 */           throw new CacheLoader.InvalidCacheLoadException("CacheLoader returned null for key " + key + ".");
/* 1681:     */         }
/* 1682:2350 */         this.statsCounter.recordLoadSuccess(loadingValueReference.elapsedNanos());
/* 1683:2351 */         storeLoadedValue(key, hash, loadingValueReference, value);
/* 1684:2352 */         return value;
/* 1685:     */       }
/* 1686:     */       finally
/* 1687:     */       {
/* 1688:2354 */         if (value == null)
/* 1689:     */         {
/* 1690:2355 */           this.statsCounter.recordLoadException(loadingValueReference.elapsedNanos());
/* 1691:2356 */           removeLoadingValue(key, hash, loadingValueReference);
/* 1692:     */         }
/* 1693:     */       }
/* 1694:     */     }
/* 1695:     */     
/* 1696:     */     V scheduleRefresh(LocalCache.ReferenceEntry<K, V> entry, K key, int hash, V oldValue, long now, CacheLoader<? super K, V> loader)
/* 1697:     */     {
/* 1698:2363 */       if ((this.map.refreshes()) && (now - entry.getWriteTime() > this.map.refreshNanos) && (!entry.getValueReference().isLoading()))
/* 1699:     */       {
/* 1700:2365 */         V newValue = refresh(key, hash, loader, true);
/* 1701:2366 */         if (newValue != null) {
/* 1702:2367 */           return newValue;
/* 1703:     */         }
/* 1704:     */       }
/* 1705:2370 */       return oldValue;
/* 1706:     */     }
/* 1707:     */     
/* 1708:     */     @Nullable
/* 1709:     */     V refresh(K key, int hash, CacheLoader<? super K, V> loader, boolean checkTime)
/* 1710:     */     {
/* 1711:2381 */       LocalCache.LoadingValueReference<K, V> loadingValueReference = insertLoadingValueReference(key, hash, checkTime);
/* 1712:2383 */       if (loadingValueReference == null) {
/* 1713:2384 */         return null;
/* 1714:     */       }
/* 1715:2387 */       ListenableFuture<V> result = loadAsync(key, hash, loadingValueReference, loader);
/* 1716:2388 */       if (result.isDone()) {
/* 1717:     */         try
/* 1718:     */         {
/* 1719:2390 */           return Uninterruptibles.getUninterruptibly(result);
/* 1720:     */         }
/* 1721:     */         catch (Throwable t) {}
/* 1722:     */       }
/* 1723:2395 */       return null;
/* 1724:     */     }
/* 1725:     */     
/* 1726:     */     @Nullable
/* 1727:     */     LocalCache.LoadingValueReference<K, V> insertLoadingValueReference(K key, int hash, boolean checkTime)
/* 1728:     */     {
/* 1729:2405 */       LocalCache.ReferenceEntry<K, V> e = null;
/* 1730:2406 */       lock();
/* 1731:     */       try
/* 1732:     */       {
/* 1733:2408 */         long now = this.map.ticker.read();
/* 1734:2409 */         preWriteCleanup(now);
/* 1735:     */         
/* 1736:2411 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 1737:2412 */         int index = hash & table.length() - 1;
/* 1738:2413 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 1739:     */         LocalCache.ValueReference<K, V> valueReference;
/* 1740:2416 */         for (e = first; e != null; e = e.getNext())
/* 1741:     */         {
/* 1742:2417 */           K entryKey = e.getKey();
/* 1743:2418 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1744:     */           {
/* 1745:2422 */             valueReference = e.getValueReference();
/* 1746:2423 */             if ((valueReference.isLoading()) || ((checkTime) && (now - e.getWriteTime() < this.map.refreshNanos))) {
/* 1747:2428 */               return null;
/* 1748:     */             }
/* 1749:2432 */             this.modCount += 1;
/* 1750:2433 */             Object loadingValueReference = new LocalCache.LoadingValueReference(valueReference);
/* 1751:     */             
/* 1752:2435 */             e.setValueReference((LocalCache.ValueReference)loadingValueReference);
/* 1753:2436 */             return loadingValueReference;
/* 1754:     */           }
/* 1755:     */         }
/* 1756:2440 */         this.modCount += 1;
/* 1757:2441 */         LocalCache.LoadingValueReference<K, V> loadingValueReference = new LocalCache.LoadingValueReference();
/* 1758:2442 */         e = newEntry(key, hash, first);
/* 1759:2443 */         e.setValueReference(loadingValueReference);
/* 1760:2444 */         table.set(index, e);
/* 1761:2445 */         return loadingValueReference;
/* 1762:     */       }
/* 1763:     */       finally
/* 1764:     */       {
/* 1765:2447 */         unlock();
/* 1766:2448 */         postWriteCleanup();
/* 1767:     */       }
/* 1768:     */     }
/* 1769:     */     
/* 1770:     */     void tryDrainReferenceQueues()
/* 1771:     */     {
/* 1772:2458 */       if (tryLock()) {
/* 1773:     */         try
/* 1774:     */         {
/* 1775:2460 */           drainReferenceQueues();
/* 1776:     */         }
/* 1777:     */         finally
/* 1778:     */         {
/* 1779:2462 */           unlock();
/* 1780:     */         }
/* 1781:     */       }
/* 1782:     */     }
/* 1783:     */     
/* 1784:     */     @GuardedBy("Segment.this")
/* 1785:     */     void drainReferenceQueues()
/* 1786:     */     {
/* 1787:2473 */       if (this.map.usesKeyReferences()) {
/* 1788:2474 */         drainKeyReferenceQueue();
/* 1789:     */       }
/* 1790:2476 */       if (this.map.usesValueReferences()) {
/* 1791:2477 */         drainValueReferenceQueue();
/* 1792:     */       }
/* 1793:     */     }
/* 1794:     */     
/* 1795:     */     @GuardedBy("Segment.this")
/* 1796:     */     void drainKeyReferenceQueue()
/* 1797:     */     {
/* 1798:2484 */       int i = 0;
/* 1799:     */       Reference<? extends K> ref;
/* 1800:2485 */       for (; (ref = this.keyReferenceQueue.poll()) != null; i == 16)
/* 1801:     */       {
/* 1802:2487 */         LocalCache.ReferenceEntry<K, V> entry = (LocalCache.ReferenceEntry)ref;
/* 1803:2488 */         this.map.reclaimKey(entry);
/* 1804:2489 */         i++;
/* 1805:     */       }
/* 1806:     */     }
/* 1807:     */     
/* 1808:     */     @GuardedBy("Segment.this")
/* 1809:     */     void drainValueReferenceQueue()
/* 1810:     */     {
/* 1811:2498 */       int i = 0;
/* 1812:     */       Reference<? extends V> ref;
/* 1813:2499 */       for (; (ref = this.valueReferenceQueue.poll()) != null; i == 16)
/* 1814:     */       {
/* 1815:2501 */         LocalCache.ValueReference<K, V> valueReference = (LocalCache.ValueReference)ref;
/* 1816:2502 */         this.map.reclaimValue(valueReference);
/* 1817:2503 */         i++;
/* 1818:     */       }
/* 1819:     */     }
/* 1820:     */     
/* 1821:     */     void clearReferenceQueues()
/* 1822:     */     {
/* 1823:2513 */       if (this.map.usesKeyReferences()) {
/* 1824:2514 */         clearKeyReferenceQueue();
/* 1825:     */       }
/* 1826:2516 */       if (this.map.usesValueReferences()) {
/* 1827:2517 */         clearValueReferenceQueue();
/* 1828:     */       }
/* 1829:     */     }
/* 1830:     */     
/* 1831:     */     void clearKeyReferenceQueue()
/* 1832:     */     {
/* 1833:2522 */       while (this.keyReferenceQueue.poll() != null) {}
/* 1834:     */     }
/* 1835:     */     
/* 1836:     */     void clearValueReferenceQueue()
/* 1837:     */     {
/* 1838:2526 */       while (this.valueReferenceQueue.poll() != null) {}
/* 1839:     */     }
/* 1840:     */     
/* 1841:     */     void recordRead(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 1842:     */     {
/* 1843:2539 */       if (this.map.recordsAccess()) {
/* 1844:2540 */         entry.setAccessTime(now);
/* 1845:     */       }
/* 1846:2542 */       this.recencyQueue.add(entry);
/* 1847:     */     }
/* 1848:     */     
/* 1849:     */     @GuardedBy("Segment.this")
/* 1850:     */     void recordLockedRead(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 1851:     */     {
/* 1852:2554 */       if (this.map.recordsAccess()) {
/* 1853:2555 */         entry.setAccessTime(now);
/* 1854:     */       }
/* 1855:2557 */       this.accessQueue.add(entry);
/* 1856:     */     }
/* 1857:     */     
/* 1858:     */     @GuardedBy("Segment.this")
/* 1859:     */     void recordWrite(LocalCache.ReferenceEntry<K, V> entry, int weight, long now)
/* 1860:     */     {
/* 1861:2567 */       drainRecencyQueue();
/* 1862:2568 */       this.totalWeight += weight;
/* 1863:2570 */       if (this.map.recordsAccess()) {
/* 1864:2571 */         entry.setAccessTime(now);
/* 1865:     */       }
/* 1866:2573 */       if (this.map.recordsWrite()) {
/* 1867:2574 */         entry.setWriteTime(now);
/* 1868:     */       }
/* 1869:2576 */       this.accessQueue.add(entry);
/* 1870:2577 */       this.writeQueue.add(entry);
/* 1871:     */     }
/* 1872:     */     
/* 1873:     */     @GuardedBy("Segment.this")
/* 1874:     */     void drainRecencyQueue()
/* 1875:     */     {
/* 1876:     */       LocalCache.ReferenceEntry<K, V> e;
/* 1877:2589 */       while ((e = (LocalCache.ReferenceEntry)this.recencyQueue.poll()) != null) {
/* 1878:2594 */         if (this.accessQueue.contains(e)) {
/* 1879:2595 */           this.accessQueue.add(e);
/* 1880:     */         }
/* 1881:     */       }
/* 1882:     */     }
/* 1883:     */     
/* 1884:     */     void tryExpireEntries(long now)
/* 1885:     */     {
/* 1886:2606 */       if (tryLock()) {
/* 1887:     */         try
/* 1888:     */         {
/* 1889:2608 */           expireEntries(now);
/* 1890:     */         }
/* 1891:     */         finally
/* 1892:     */         {
/* 1893:2610 */           unlock();
/* 1894:     */         }
/* 1895:     */       }
/* 1896:     */     }
/* 1897:     */     
/* 1898:     */     @GuardedBy("Segment.this")
/* 1899:     */     void expireEntries(long now)
/* 1900:     */     {
/* 1901:2618 */       drainRecencyQueue();
/* 1902:     */       LocalCache.ReferenceEntry<K, V> e;
/* 1903:2621 */       while (((e = (LocalCache.ReferenceEntry)this.writeQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1904:2622 */         if (!removeEntry(e, e.getHash(), RemovalCause.EXPIRED)) {
/* 1905:2623 */           throw new AssertionError();
/* 1906:     */         }
/* 1907:     */       }
/* 1908:2626 */       while (((e = (LocalCache.ReferenceEntry)this.accessQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1909:2627 */         if (!removeEntry(e, e.getHash(), RemovalCause.EXPIRED)) {
/* 1910:2628 */           throw new AssertionError();
/* 1911:     */         }
/* 1912:     */       }
/* 1913:     */     }
/* 1914:     */     
/* 1915:     */     @GuardedBy("Segment.this")
/* 1916:     */     void enqueueNotification(LocalCache.ReferenceEntry<K, V> entry, RemovalCause cause)
/* 1917:     */     {
/* 1918:2637 */       enqueueNotification(entry.getKey(), entry.getHash(), entry.getValueReference(), cause);
/* 1919:     */     }
/* 1920:     */     
/* 1921:     */     @GuardedBy("Segment.this")
/* 1922:     */     void enqueueNotification(@Nullable K key, int hash, LocalCache.ValueReference<K, V> valueReference, RemovalCause cause)
/* 1923:     */     {
/* 1924:2643 */       this.totalWeight -= valueReference.getWeight();
/* 1925:2644 */       if (cause.wasEvicted()) {
/* 1926:2645 */         this.statsCounter.recordEviction();
/* 1927:     */       }
/* 1928:2647 */       if (this.map.removalNotificationQueue != LocalCache.DISCARDING_QUEUE)
/* 1929:     */       {
/* 1930:2648 */         V value = valueReference.get();
/* 1931:2649 */         RemovalNotification<K, V> notification = new RemovalNotification(key, value, cause);
/* 1932:2650 */         this.map.removalNotificationQueue.offer(notification);
/* 1933:     */       }
/* 1934:     */     }
/* 1935:     */     
/* 1936:     */     @GuardedBy("Segment.this")
/* 1937:     */     void evictEntries()
/* 1938:     */     {
/* 1939:2660 */       if (!this.map.evictsBySize()) {
/* 1940:2661 */         return;
/* 1941:     */       }
/* 1942:2664 */       drainRecencyQueue();
/* 1943:2665 */       while (this.totalWeight > this.maxSegmentWeight)
/* 1944:     */       {
/* 1945:2666 */         LocalCache.ReferenceEntry<K, V> e = getNextEvictable();
/* 1946:2667 */         if (!removeEntry(e, e.getHash(), RemovalCause.SIZE)) {
/* 1947:2668 */           throw new AssertionError();
/* 1948:     */         }
/* 1949:     */       }
/* 1950:     */     }
/* 1951:     */     
/* 1952:     */     LocalCache.ReferenceEntry<K, V> getNextEvictable()
/* 1953:     */     {
/* 1954:2675 */       for (LocalCache.ReferenceEntry<K, V> e : this.accessQueue)
/* 1955:     */       {
/* 1956:2676 */         int weight = e.getValueReference().getWeight();
/* 1957:2677 */         if (weight > 0) {
/* 1958:2678 */           return e;
/* 1959:     */         }
/* 1960:     */       }
/* 1961:2681 */       throw new AssertionError();
/* 1962:     */     }
/* 1963:     */     
/* 1964:     */     LocalCache.ReferenceEntry<K, V> getFirst(int hash)
/* 1965:     */     {
/* 1966:2689 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 1967:2690 */       return (LocalCache.ReferenceEntry)table.get(hash & table.length() - 1);
/* 1968:     */     }
/* 1969:     */     
/* 1970:     */     @Nullable
/* 1971:     */     LocalCache.ReferenceEntry<K, V> getEntry(Object key, int hash)
/* 1972:     */     {
/* 1973:2697 */       for (LocalCache.ReferenceEntry<K, V> e = getFirst(hash); e != null; e = e.getNext()) {
/* 1974:2698 */         if (e.getHash() == hash)
/* 1975:     */         {
/* 1976:2702 */           K entryKey = e.getKey();
/* 1977:2703 */           if (entryKey == null) {
/* 1978:2704 */             tryDrainReferenceQueues();
/* 1979:2708 */           } else if (this.map.keyEquivalence.equivalent(key, entryKey)) {
/* 1980:2709 */             return e;
/* 1981:     */           }
/* 1982:     */         }
/* 1983:     */       }
/* 1984:2713 */       return null;
/* 1985:     */     }
/* 1986:     */     
/* 1987:     */     @Nullable
/* 1988:     */     LocalCache.ReferenceEntry<K, V> getLiveEntry(Object key, int hash, long now)
/* 1989:     */     {
/* 1990:2718 */       LocalCache.ReferenceEntry<K, V> e = getEntry(key, hash);
/* 1991:2719 */       if (e == null) {
/* 1992:2720 */         return null;
/* 1993:     */       }
/* 1994:2721 */       if (this.map.isExpired(e, now))
/* 1995:     */       {
/* 1996:2722 */         tryExpireEntries(now);
/* 1997:2723 */         return null;
/* 1998:     */       }
/* 1999:2725 */       return e;
/* 2000:     */     }
/* 2001:     */     
/* 2002:     */     V getLiveValue(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 2003:     */     {
/* 2004:2733 */       if (entry.getKey() == null)
/* 2005:     */       {
/* 2006:2734 */         tryDrainReferenceQueues();
/* 2007:2735 */         return null;
/* 2008:     */       }
/* 2009:2737 */       V value = entry.getValueReference().get();
/* 2010:2738 */       if (value == null)
/* 2011:     */       {
/* 2012:2739 */         tryDrainReferenceQueues();
/* 2013:2740 */         return null;
/* 2014:     */       }
/* 2015:2743 */       if (this.map.isExpired(entry, now))
/* 2016:     */       {
/* 2017:2744 */         tryExpireEntries(now);
/* 2018:2745 */         return null;
/* 2019:     */       }
/* 2020:2747 */       return value;
/* 2021:     */     }
/* 2022:     */     
/* 2023:     */     @Nullable
/* 2024:     */     V get(Object key, int hash)
/* 2025:     */     {
/* 2026:     */       try
/* 2027:     */       {
/* 2028:     */         long now;
/* 2029:2753 */         if (this.count != 0)
/* 2030:     */         {
/* 2031:2754 */           now = this.map.ticker.read();
/* 2032:2755 */           LocalCache.ReferenceEntry<K, V> e = getLiveEntry(key, hash, now);
/* 2033:2756 */           if (e == null) {
/* 2034:2757 */             return null;
/* 2035:     */           }
/* 2036:2760 */           Object value = e.getValueReference().get();
/* 2037:2761 */           if (value != null)
/* 2038:     */           {
/* 2039:2762 */             recordRead(e, now);
/* 2040:2763 */             return scheduleRefresh(e, e.getKey(), hash, value, now, this.map.defaultLoader);
/* 2041:     */           }
/* 2042:2765 */           tryDrainReferenceQueues();
/* 2043:     */         }
/* 2044:2767 */         return null;
/* 2045:     */       }
/* 2046:     */       finally
/* 2047:     */       {
/* 2048:2769 */         postReadCleanup();
/* 2049:     */       }
/* 2050:     */     }
/* 2051:     */     
/* 2052:     */     boolean containsKey(Object key, int hash)
/* 2053:     */     {
/* 2054:     */       try
/* 2055:     */       {
/* 2056:     */         long now;
/* 2057:2775 */         if (this.count != 0)
/* 2058:     */         {
/* 2059:2776 */           now = this.map.ticker.read();
/* 2060:2777 */           LocalCache.ReferenceEntry<K, V> e = getLiveEntry(key, hash, now);
/* 2061:     */           boolean bool;
/* 2062:2778 */           if (e == null) {
/* 2063:2779 */             return false;
/* 2064:     */           }
/* 2065:2781 */           return e.getValueReference().get() != null;
/* 2066:     */         }
/* 2067:2784 */         return 0;
/* 2068:     */       }
/* 2069:     */       finally
/* 2070:     */       {
/* 2071:2786 */         postReadCleanup();
/* 2072:     */       }
/* 2073:     */     }
/* 2074:     */     
/* 2075:     */     @VisibleForTesting
/* 2076:     */     boolean containsValue(Object value)
/* 2077:     */     {
/* 2078:     */       try
/* 2079:     */       {
/* 2080:     */         long now;
/* 2081:2797 */         if (this.count != 0)
/* 2082:     */         {
/* 2083:2798 */           now = this.map.ticker.read();
/* 2084:2799 */           AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2085:2800 */           int length = table.length();
/* 2086:2801 */           for (int i = 0; i < length; i++) {
/* 2087:2802 */             for (LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)table.get(i); e != null; e = e.getNext())
/* 2088:     */             {
/* 2089:2803 */               V entryValue = getLiveValue(e, now);
/* 2090:2804 */               if (entryValue != null) {
/* 2091:2807 */                 if (this.map.valueEquivalence.equivalent(value, entryValue)) {
/* 2092:2808 */                   return true;
/* 2093:     */                 }
/* 2094:     */               }
/* 2095:     */             }
/* 2096:     */           }
/* 2097:     */         }
/* 2098:2814 */         return 0;
/* 2099:     */       }
/* 2100:     */       finally
/* 2101:     */       {
/* 2102:2816 */         postReadCleanup();
/* 2103:     */       }
/* 2104:     */     }
/* 2105:     */     
/* 2106:     */     @Nullable
/* 2107:     */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/* 2108:     */     {
/* 2109:2822 */       lock();
/* 2110:     */       try
/* 2111:     */       {
/* 2112:2824 */         long now = this.map.ticker.read();
/* 2113:2825 */         preWriteCleanup(now);
/* 2114:     */         
/* 2115:2827 */         int newCount = this.count + 1;
/* 2116:2828 */         if (newCount > this.threshold)
/* 2117:     */         {
/* 2118:2829 */           expand();
/* 2119:2830 */           newCount = this.count + 1;
/* 2120:     */         }
/* 2121:2833 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2122:2834 */         int index = hash & table.length() - 1;
/* 2123:2835 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2124:     */         K entryKey;
/* 2125:2838 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2126:     */         {
/* 2127:2839 */           entryKey = e.getKey();
/* 2128:2840 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2129:     */           {
/* 2130:2844 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2131:2845 */             V entryValue = valueReference.get();
/* 2132:     */             V ?;
/* 2133:2847 */             if (entryValue == null)
/* 2134:     */             {
/* 2135:2848 */               this.modCount += 1;
/* 2136:2849 */               if (valueReference.isActive())
/* 2137:     */               {
/* 2138:2850 */                 enqueueNotification(key, hash, valueReference, RemovalCause.COLLECTED);
/* 2139:2851 */                 setValue(e, key, value, now);
/* 2140:2852 */                 newCount = this.count;
/* 2141:     */               }
/* 2142:     */               else
/* 2143:     */               {
/* 2144:2854 */                 setValue(e, key, value, now);
/* 2145:2855 */                 newCount = this.count + 1;
/* 2146:     */               }
/* 2147:2857 */               this.count = newCount;
/* 2148:2858 */               evictEntries();
/* 2149:2859 */               return null;
/* 2150:     */             }
/* 2151:2860 */             if (onlyIfAbsent)
/* 2152:     */             {
/* 2153:2864 */               recordLockedRead(e, now);
/* 2154:2865 */               return entryValue;
/* 2155:     */             }
/* 2156:2868 */             this.modCount += 1;
/* 2157:2869 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2158:2870 */             setValue(e, key, value, now);
/* 2159:2871 */             evictEntries();
/* 2160:2872 */             return entryValue;
/* 2161:     */           }
/* 2162:     */         }
/* 2163:2878 */         this.modCount += 1;
/* 2164:2879 */         LocalCache.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 2165:2880 */         setValue(newEntry, key, value, now);
/* 2166:2881 */         table.set(index, newEntry);
/* 2167:2882 */         newCount = this.count + 1;
/* 2168:2883 */         this.count = newCount;
/* 2169:2884 */         evictEntries();
/* 2170:2885 */         return null;
/* 2171:     */       }
/* 2172:     */       finally
/* 2173:     */       {
/* 2174:2887 */         unlock();
/* 2175:2888 */         postWriteCleanup();
/* 2176:     */       }
/* 2177:     */     }
/* 2178:     */     
/* 2179:     */     @GuardedBy("Segment.this")
/* 2180:     */     void expand()
/* 2181:     */     {
/* 2182:2897 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> oldTable = this.table;
/* 2183:2898 */       int oldCapacity = oldTable.length();
/* 2184:2899 */       if (oldCapacity >= 1073741824) {
/* 2185:2900 */         return;
/* 2186:     */       }
/* 2187:2913 */       int newCount = this.count;
/* 2188:2914 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newTable = newEntryArray(oldCapacity << 1);
/* 2189:2915 */       this.threshold = (newTable.length() * 3 / 4);
/* 2190:2916 */       int newMask = newTable.length() - 1;
/* 2191:2917 */       for (int oldIndex = 0; oldIndex < oldCapacity; oldIndex++)
/* 2192:     */       {
/* 2193:2920 */         LocalCache.ReferenceEntry<K, V> head = (LocalCache.ReferenceEntry)oldTable.get(oldIndex);
/* 2194:2922 */         if (head != null)
/* 2195:     */         {
/* 2196:2923 */           LocalCache.ReferenceEntry<K, V> next = head.getNext();
/* 2197:2924 */           int headIndex = head.getHash() & newMask;
/* 2198:2927 */           if (next == null)
/* 2199:     */           {
/* 2200:2928 */             newTable.set(headIndex, head);
/* 2201:     */           }
/* 2202:     */           else
/* 2203:     */           {
/* 2204:2933 */             LocalCache.ReferenceEntry<K, V> tail = head;
/* 2205:2934 */             int tailIndex = headIndex;
/* 2206:2935 */             for (LocalCache.ReferenceEntry<K, V> e = next; e != null; e = e.getNext())
/* 2207:     */             {
/* 2208:2936 */               int newIndex = e.getHash() & newMask;
/* 2209:2937 */               if (newIndex != tailIndex)
/* 2210:     */               {
/* 2211:2939 */                 tailIndex = newIndex;
/* 2212:2940 */                 tail = e;
/* 2213:     */               }
/* 2214:     */             }
/* 2215:2943 */             newTable.set(tailIndex, tail);
/* 2216:2946 */             for (LocalCache.ReferenceEntry<K, V> e = head; e != tail; e = e.getNext())
/* 2217:     */             {
/* 2218:2947 */               int newIndex = e.getHash() & newMask;
/* 2219:2948 */               LocalCache.ReferenceEntry<K, V> newNext = (LocalCache.ReferenceEntry)newTable.get(newIndex);
/* 2220:2949 */               LocalCache.ReferenceEntry<K, V> newFirst = copyEntry(e, newNext);
/* 2221:2950 */               if (newFirst != null)
/* 2222:     */               {
/* 2223:2951 */                 newTable.set(newIndex, newFirst);
/* 2224:     */               }
/* 2225:     */               else
/* 2226:     */               {
/* 2227:2953 */                 removeCollectedEntry(e);
/* 2228:2954 */                 newCount--;
/* 2229:     */               }
/* 2230:     */             }
/* 2231:     */           }
/* 2232:     */         }
/* 2233:     */       }
/* 2234:2960 */       this.table = newTable;
/* 2235:2961 */       this.count = newCount;
/* 2236:     */     }
/* 2237:     */     
/* 2238:     */     boolean replace(K key, int hash, V oldValue, V newValue)
/* 2239:     */     {
/* 2240:2965 */       lock();
/* 2241:     */       try
/* 2242:     */       {
/* 2243:2967 */         long now = this.map.ticker.read();
/* 2244:2968 */         preWriteCleanup(now);
/* 2245:     */         
/* 2246:2970 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2247:2971 */         int index = hash & table.length() - 1;
/* 2248:2972 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2249:2974 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2250:     */         {
/* 2251:2975 */           K entryKey = e.getKey();
/* 2252:2976 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2253:     */           {
/* 2254:2978 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2255:2979 */             V entryValue = valueReference.get();
/* 2256:     */             int newCount;
/* 2257:2980 */             if (entryValue == null)
/* 2258:     */             {
/* 2259:2981 */               if (valueReference.isActive())
/* 2260:     */               {
/* 2261:2983 */                 newCount = this.count - 1;
/* 2262:2984 */                 this.modCount += 1;
/* 2263:2985 */                 LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2264:     */                 
/* 2265:2987 */                 newCount = this.count - 1;
/* 2266:2988 */                 table.set(index, newFirst);
/* 2267:2989 */                 this.count = newCount;
/* 2268:     */               }
/* 2269:2991 */               return 0;
/* 2270:     */             }
/* 2271:2994 */             if (this.map.valueEquivalence.equivalent(oldValue, entryValue))
/* 2272:     */             {
/* 2273:2995 */               this.modCount += 1;
/* 2274:2996 */               enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2275:2997 */               setValue(e, key, newValue, now);
/* 2276:2998 */               evictEntries();
/* 2277:2999 */               return 1;
/* 2278:     */             }
/* 2279:3003 */             recordLockedRead(e, now);
/* 2280:3004 */             return 0;
/* 2281:     */           }
/* 2282:     */         }
/* 2283:3009 */         return 0;
/* 2284:     */       }
/* 2285:     */       finally
/* 2286:     */       {
/* 2287:3011 */         unlock();
/* 2288:3012 */         postWriteCleanup();
/* 2289:     */       }
/* 2290:     */     }
/* 2291:     */     
/* 2292:     */     @Nullable
/* 2293:     */     V replace(K key, int hash, V newValue)
/* 2294:     */     {
/* 2295:3018 */       lock();
/* 2296:     */       try
/* 2297:     */       {
/* 2298:3020 */         long now = this.map.ticker.read();
/* 2299:3021 */         preWriteCleanup(now);
/* 2300:     */         
/* 2301:3023 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2302:3024 */         int index = hash & table.length() - 1;
/* 2303:3025 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2304:3027 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2305:     */         {
/* 2306:3028 */           K entryKey = e.getKey();
/* 2307:3029 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2308:     */           {
/* 2309:3031 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2310:3032 */             V entryValue = valueReference.get();
/* 2311:     */             int newCount;
/* 2312:3033 */             if (entryValue == null)
/* 2313:     */             {
/* 2314:3034 */               if (valueReference.isActive())
/* 2315:     */               {
/* 2316:3036 */                 newCount = this.count - 1;
/* 2317:3037 */                 this.modCount += 1;
/* 2318:3038 */                 LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2319:     */                 
/* 2320:3040 */                 newCount = this.count - 1;
/* 2321:3041 */                 table.set(index, newFirst);
/* 2322:3042 */                 this.count = newCount;
/* 2323:     */               }
/* 2324:3044 */               return null;
/* 2325:     */             }
/* 2326:3047 */             this.modCount += 1;
/* 2327:3048 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2328:3049 */             setValue(e, key, newValue, now);
/* 2329:3050 */             evictEntries();
/* 2330:3051 */             return entryValue;
/* 2331:     */           }
/* 2332:     */         }
/* 2333:3055 */         return null;
/* 2334:     */       }
/* 2335:     */       finally
/* 2336:     */       {
/* 2337:3057 */         unlock();
/* 2338:3058 */         postWriteCleanup();
/* 2339:     */       }
/* 2340:     */     }
/* 2341:     */     
/* 2342:     */     @Nullable
/* 2343:     */     V remove(Object key, int hash)
/* 2344:     */     {
/* 2345:3064 */       lock();
/* 2346:     */       try
/* 2347:     */       {
/* 2348:3066 */         long now = this.map.ticker.read();
/* 2349:3067 */         preWriteCleanup(now);
/* 2350:     */         
/* 2351:3069 */         int newCount = this.count - 1;
/* 2352:3070 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2353:3071 */         int index = hash & table.length() - 1;
/* 2354:3072 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2355:3074 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2356:     */         {
/* 2357:3075 */           K entryKey = e.getKey();
/* 2358:3076 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2359:     */           {
/* 2360:3078 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2361:3079 */             V entryValue = valueReference.get();
/* 2362:     */             RemovalCause cause;
/* 2363:3082 */             if (entryValue != null)
/* 2364:     */             {
/* 2365:3083 */               cause = RemovalCause.EXPLICIT;
/* 2366:     */             }
/* 2367:     */             else
/* 2368:     */             {
/* 2369:     */               RemovalCause cause;
/* 2370:3084 */               if (valueReference.isActive()) {
/* 2371:3085 */                 cause = RemovalCause.COLLECTED;
/* 2372:     */               } else {
/* 2373:3088 */                 return null;
/* 2374:     */               }
/* 2375:     */             }
/* 2376:     */             RemovalCause cause;
/* 2377:3091 */             this.modCount += 1;
/* 2378:3092 */             Object newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, cause);
/* 2379:     */             
/* 2380:3094 */             newCount = this.count - 1;
/* 2381:3095 */             table.set(index, newFirst);
/* 2382:3096 */             this.count = newCount;
/* 2383:3097 */             return entryValue;
/* 2384:     */           }
/* 2385:     */         }
/* 2386:3101 */         return null;
/* 2387:     */       }
/* 2388:     */       finally
/* 2389:     */       {
/* 2390:3103 */         unlock();
/* 2391:3104 */         postWriteCleanup();
/* 2392:     */       }
/* 2393:     */     }
/* 2394:     */     
/* 2395:     */     boolean storeLoadedValue(K key, int hash, LocalCache.LoadingValueReference<K, V> oldValueReference, V newValue)
/* 2396:     */     {
/* 2397:3110 */       lock();
/* 2398:     */       try
/* 2399:     */       {
/* 2400:3112 */         long now = this.map.ticker.read();
/* 2401:3113 */         preWriteCleanup(now);
/* 2402:     */         
/* 2403:3115 */         int newCount = this.count + 1;
/* 2404:3116 */         if (newCount > this.threshold)
/* 2405:     */         {
/* 2406:3117 */           expand();
/* 2407:3118 */           newCount = this.count + 1;
/* 2408:     */         }
/* 2409:3121 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2410:3122 */         int index = hash & table.length() - 1;
/* 2411:3123 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2412:     */         K entryKey;
/* 2413:3125 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2414:     */         {
/* 2415:3126 */           entryKey = e.getKey();
/* 2416:3127 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2417:     */           {
/* 2418:3129 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2419:3130 */             V entryValue = valueReference.get();
/* 2420:     */             RemovalCause cause;
/* 2421:3133 */             if ((oldValueReference == valueReference) || ((entryValue == null) && (valueReference != LocalCache.UNSET)))
/* 2422:     */             {
/* 2423:3135 */               this.modCount += 1;
/* 2424:3136 */               if (oldValueReference.isActive())
/* 2425:     */               {
/* 2426:3137 */                 cause = entryValue == null ? RemovalCause.COLLECTED : RemovalCause.REPLACED;
/* 2427:     */                 
/* 2428:3139 */                 enqueueNotification(key, hash, oldValueReference, cause);
/* 2429:3140 */                 newCount--;
/* 2430:     */               }
/* 2431:3142 */               setValue(e, key, newValue, now);
/* 2432:3143 */               this.count = newCount;
/* 2433:3144 */               evictEntries();
/* 2434:3145 */               return 1;
/* 2435:     */             }
/* 2436:3149 */             valueReference = new LocalCache.WeightedStrongValueReference(newValue, 0);
/* 2437:3150 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2438:3151 */             return 0;
/* 2439:     */           }
/* 2440:     */         }
/* 2441:3155 */         this.modCount += 1;
/* 2442:3156 */         LocalCache.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 2443:3157 */         setValue(newEntry, key, newValue, now);
/* 2444:3158 */         table.set(index, newEntry);
/* 2445:3159 */         this.count = newCount;
/* 2446:3160 */         evictEntries();
/* 2447:3161 */         return 1;
/* 2448:     */       }
/* 2449:     */       finally
/* 2450:     */       {
/* 2451:3163 */         unlock();
/* 2452:3164 */         postWriteCleanup();
/* 2453:     */       }
/* 2454:     */     }
/* 2455:     */     
/* 2456:     */     boolean remove(Object key, int hash, Object value)
/* 2457:     */     {
/* 2458:3169 */       lock();
/* 2459:     */       try
/* 2460:     */       {
/* 2461:3171 */         long now = this.map.ticker.read();
/* 2462:3172 */         preWriteCleanup(now);
/* 2463:     */         
/* 2464:3174 */         int newCount = this.count - 1;
/* 2465:3175 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2466:3176 */         int index = hash & table.length() - 1;
/* 2467:3177 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2468:3179 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2469:     */         {
/* 2470:3180 */           K entryKey = e.getKey();
/* 2471:3181 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2472:     */           {
/* 2473:3183 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2474:3184 */             V entryValue = valueReference.get();
/* 2475:     */             RemovalCause cause;
/* 2476:3187 */             if (this.map.valueEquivalence.equivalent(value, entryValue))
/* 2477:     */             {
/* 2478:3188 */               cause = RemovalCause.EXPLICIT;
/* 2479:     */             }
/* 2480:     */             else
/* 2481:     */             {
/* 2482:     */               RemovalCause cause;
/* 2483:3189 */               if ((entryValue == null) && (valueReference.isActive())) {
/* 2484:3190 */                 cause = RemovalCause.COLLECTED;
/* 2485:     */               } else {
/* 2486:3193 */                 return false;
/* 2487:     */               }
/* 2488:     */             }
/* 2489:     */             RemovalCause cause;
/* 2490:3196 */             this.modCount += 1;
/* 2491:3197 */             Object newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, cause);
/* 2492:     */             
/* 2493:3199 */             newCount = this.count - 1;
/* 2494:3200 */             table.set(index, newFirst);
/* 2495:3201 */             this.count = newCount;
/* 2496:3202 */             return cause == RemovalCause.EXPLICIT;
/* 2497:     */           }
/* 2498:     */         }
/* 2499:3206 */         return 0;
/* 2500:     */       }
/* 2501:     */       finally
/* 2502:     */       {
/* 2503:3208 */         unlock();
/* 2504:3209 */         postWriteCleanup();
/* 2505:     */       }
/* 2506:     */     }
/* 2507:     */     
/* 2508:     */     void clear()
/* 2509:     */     {
/* 2510:3214 */       if (this.count != 0)
/* 2511:     */       {
/* 2512:3215 */         lock();
/* 2513:     */         try
/* 2514:     */         {
/* 2515:3217 */           AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2516:3218 */           for (int i = 0; i < table.length(); i++) {
/* 2517:3219 */             for (LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)table.get(i); e != null; e = e.getNext()) {
/* 2518:3221 */               if (e.getValueReference().isActive()) {
/* 2519:3222 */                 enqueueNotification(e, RemovalCause.EXPLICIT);
/* 2520:     */               }
/* 2521:     */             }
/* 2522:     */           }
/* 2523:3226 */           for (int i = 0; i < table.length(); i++) {
/* 2524:3227 */             table.set(i, null);
/* 2525:     */           }
/* 2526:3229 */           clearReferenceQueues();
/* 2527:3230 */           this.writeQueue.clear();
/* 2528:3231 */           this.accessQueue.clear();
/* 2529:3232 */           this.readCount.set(0);
/* 2530:     */           
/* 2531:3234 */           this.modCount += 1;
/* 2532:3235 */           this.count = 0;
/* 2533:     */         }
/* 2534:     */         finally
/* 2535:     */         {
/* 2536:3237 */           unlock();
/* 2537:3238 */           postWriteCleanup();
/* 2538:     */         }
/* 2539:     */       }
/* 2540:     */     }
/* 2541:     */     
/* 2542:     */     @Nullable
/* 2543:     */     @GuardedBy("Segment.this")
/* 2544:     */     LocalCache.ReferenceEntry<K, V> removeValueFromChain(LocalCache.ReferenceEntry<K, V> first, LocalCache.ReferenceEntry<K, V> entry, @Nullable K key, int hash, LocalCache.ValueReference<K, V> valueReference, RemovalCause cause)
/* 2545:     */     {
/* 2546:3248 */       enqueueNotification(key, hash, valueReference, cause);
/* 2547:3249 */       this.writeQueue.remove(entry);
/* 2548:3250 */       this.accessQueue.remove(entry);
/* 2549:3252 */       if (valueReference.isLoading())
/* 2550:     */       {
/* 2551:3253 */         valueReference.notifyNewValue(null);
/* 2552:3254 */         return first;
/* 2553:     */       }
/* 2554:3256 */       return removeEntryFromChain(first, entry);
/* 2555:     */     }
/* 2556:     */     
/* 2557:     */     @Nullable
/* 2558:     */     @GuardedBy("Segment.this")
/* 2559:     */     LocalCache.ReferenceEntry<K, V> removeEntryFromChain(LocalCache.ReferenceEntry<K, V> first, LocalCache.ReferenceEntry<K, V> entry)
/* 2560:     */     {
/* 2561:3264 */       int newCount = this.count;
/* 2562:3265 */       LocalCache.ReferenceEntry<K, V> newFirst = entry.getNext();
/* 2563:3266 */       for (LocalCache.ReferenceEntry<K, V> e = first; e != entry; e = e.getNext())
/* 2564:     */       {
/* 2565:3267 */         LocalCache.ReferenceEntry<K, V> next = copyEntry(e, newFirst);
/* 2566:3268 */         if (next != null)
/* 2567:     */         {
/* 2568:3269 */           newFirst = next;
/* 2569:     */         }
/* 2570:     */         else
/* 2571:     */         {
/* 2572:3271 */           removeCollectedEntry(e);
/* 2573:3272 */           newCount--;
/* 2574:     */         }
/* 2575:     */       }
/* 2576:3275 */       this.count = newCount;
/* 2577:3276 */       return newFirst;
/* 2578:     */     }
/* 2579:     */     
/* 2580:     */     @GuardedBy("Segment.this")
/* 2581:     */     void removeCollectedEntry(LocalCache.ReferenceEntry<K, V> entry)
/* 2582:     */     {
/* 2583:3281 */       enqueueNotification(entry, RemovalCause.COLLECTED);
/* 2584:3282 */       this.writeQueue.remove(entry);
/* 2585:3283 */       this.accessQueue.remove(entry);
/* 2586:     */     }
/* 2587:     */     
/* 2588:     */     boolean reclaimKey(LocalCache.ReferenceEntry<K, V> entry, int hash)
/* 2589:     */     {
/* 2590:3290 */       lock();
/* 2591:     */       try
/* 2592:     */       {
/* 2593:3292 */         int newCount = this.count - 1;
/* 2594:3293 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2595:3294 */         int index = hash & table.length() - 1;
/* 2596:3295 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2597:3297 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2598:3298 */           if (e == entry)
/* 2599:     */           {
/* 2600:3299 */             this.modCount += 1;
/* 2601:3300 */             LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, e.getKey(), hash, e.getValueReference(), RemovalCause.COLLECTED);
/* 2602:     */             
/* 2603:3302 */             newCount = this.count - 1;
/* 2604:3303 */             table.set(index, newFirst);
/* 2605:3304 */             this.count = newCount;
/* 2606:3305 */             return true;
/* 2607:     */           }
/* 2608:     */         }
/* 2609:3309 */         return 0;
/* 2610:     */       }
/* 2611:     */       finally
/* 2612:     */       {
/* 2613:3311 */         unlock();
/* 2614:3312 */         postWriteCleanup();
/* 2615:     */       }
/* 2616:     */     }
/* 2617:     */     
/* 2618:     */     boolean reclaimValue(K key, int hash, LocalCache.ValueReference<K, V> valueReference)
/* 2619:     */     {
/* 2620:3320 */       lock();
/* 2621:     */       try
/* 2622:     */       {
/* 2623:3322 */         int newCount = this.count - 1;
/* 2624:3323 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2625:3324 */         int index = hash & table.length() - 1;
/* 2626:3325 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2627:3327 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2628:     */         {
/* 2629:3328 */           K entryKey = e.getKey();
/* 2630:3329 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2631:     */           {
/* 2632:3331 */             LocalCache.ValueReference<K, V> v = e.getValueReference();
/* 2633:     */             LocalCache.ReferenceEntry<K, V> newFirst;
/* 2634:3332 */             if (v == valueReference)
/* 2635:     */             {
/* 2636:3333 */               this.modCount += 1;
/* 2637:3334 */               newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2638:     */               
/* 2639:3336 */               newCount = this.count - 1;
/* 2640:3337 */               table.set(index, newFirst);
/* 2641:3338 */               this.count = newCount;
/* 2642:3339 */               return true;
/* 2643:     */             }
/* 2644:3341 */             return 0;
/* 2645:     */           }
/* 2646:     */         }
/* 2647:3345 */         return 0;
/* 2648:     */       }
/* 2649:     */       finally
/* 2650:     */       {
/* 2651:3347 */         unlock();
/* 2652:3348 */         if (!isHeldByCurrentThread()) {
/* 2653:3349 */           postWriteCleanup();
/* 2654:     */         }
/* 2655:     */       }
/* 2656:     */     }
/* 2657:     */     
/* 2658:     */     boolean removeLoadingValue(K key, int hash, LocalCache.LoadingValueReference<K, V> valueReference)
/* 2659:     */     {
/* 2660:3355 */       lock();
/* 2661:     */       try
/* 2662:     */       {
/* 2663:3357 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2664:3358 */         int index = hash & table.length() - 1;
/* 2665:3359 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2666:3361 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2667:     */         {
/* 2668:3362 */           K entryKey = e.getKey();
/* 2669:3363 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2670:     */           {
/* 2671:3365 */             LocalCache.ValueReference<K, V> v = e.getValueReference();
/* 2672:     */             LocalCache.ReferenceEntry<K, V> newFirst;
/* 2673:3366 */             if (v == valueReference)
/* 2674:     */             {
/* 2675:3367 */               if (valueReference.isActive())
/* 2676:     */               {
/* 2677:3368 */                 e.setValueReference(valueReference.getOldValue());
/* 2678:     */               }
/* 2679:     */               else
/* 2680:     */               {
/* 2681:3370 */                 newFirst = removeEntryFromChain(first, e);
/* 2682:3371 */                 table.set(index, newFirst);
/* 2683:     */               }
/* 2684:3373 */               return 1;
/* 2685:     */             }
/* 2686:3375 */             return 0;
/* 2687:     */           }
/* 2688:     */         }
/* 2689:3379 */         return 0;
/* 2690:     */       }
/* 2691:     */       finally
/* 2692:     */       {
/* 2693:3381 */         unlock();
/* 2694:3382 */         postWriteCleanup();
/* 2695:     */       }
/* 2696:     */     }
/* 2697:     */     
/* 2698:     */     @GuardedBy("Segment.this")
/* 2699:     */     boolean removeEntry(LocalCache.ReferenceEntry<K, V> entry, int hash, RemovalCause cause)
/* 2700:     */     {
/* 2701:3388 */       int newCount = this.count - 1;
/* 2702:3389 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2703:3390 */       int index = hash & table.length() - 1;
/* 2704:3391 */       LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2705:3393 */       for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2706:3394 */         if (e == entry)
/* 2707:     */         {
/* 2708:3395 */           this.modCount += 1;
/* 2709:3396 */           LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, e.getKey(), hash, e.getValueReference(), cause);
/* 2710:     */           
/* 2711:3398 */           newCount = this.count - 1;
/* 2712:3399 */           table.set(index, newFirst);
/* 2713:3400 */           this.count = newCount;
/* 2714:3401 */           return true;
/* 2715:     */         }
/* 2716:     */       }
/* 2717:3405 */       return false;
/* 2718:     */     }
/* 2719:     */     
/* 2720:     */     void postReadCleanup()
/* 2721:     */     {
/* 2722:3413 */       if ((this.readCount.incrementAndGet() & 0x3F) == 0) {
/* 2723:3414 */         cleanUp();
/* 2724:     */       }
/* 2725:     */     }
/* 2726:     */     
/* 2727:     */     @GuardedBy("Segment.this")
/* 2728:     */     void preWriteCleanup(long now)
/* 2729:     */     {
/* 2730:3426 */       runLockedCleanup(now);
/* 2731:     */     }
/* 2732:     */     
/* 2733:     */     void postWriteCleanup()
/* 2734:     */     {
/* 2735:3433 */       runUnlockedCleanup();
/* 2736:     */     }
/* 2737:     */     
/* 2738:     */     void cleanUp()
/* 2739:     */     {
/* 2740:3437 */       long now = this.map.ticker.read();
/* 2741:3438 */       runLockedCleanup(now);
/* 2742:3439 */       runUnlockedCleanup();
/* 2743:     */     }
/* 2744:     */     
/* 2745:     */     void runLockedCleanup(long now)
/* 2746:     */     {
/* 2747:3443 */       if (tryLock()) {
/* 2748:     */         try
/* 2749:     */         {
/* 2750:3445 */           drainReferenceQueues();
/* 2751:3446 */           expireEntries(now);
/* 2752:3447 */           this.readCount.set(0);
/* 2753:     */         }
/* 2754:     */         finally
/* 2755:     */         {
/* 2756:3449 */           unlock();
/* 2757:     */         }
/* 2758:     */       }
/* 2759:     */     }
/* 2760:     */     
/* 2761:     */     void runUnlockedCleanup()
/* 2762:     */     {
/* 2763:3456 */       if (!isHeldByCurrentThread()) {
/* 2764:3457 */         this.map.processPendingNotifications();
/* 2765:     */       }
/* 2766:     */     }
/* 2767:     */   }
/* 2768:     */   
/* 2769:     */   static class LoadingValueReference<K, V>
/* 2770:     */     implements LocalCache.ValueReference<K, V>
/* 2771:     */   {
/* 2772:     */     volatile LocalCache.ValueReference<K, V> oldValue;
/* 2773:3467 */     final SettableFuture<V> futureValue = SettableFuture.create();
/* 2774:3468 */     final Stopwatch stopwatch = Stopwatch.createUnstarted();
/* 2775:     */     
/* 2776:     */     public LoadingValueReference()
/* 2777:     */     {
/* 2778:3471 */       this(LocalCache.unset());
/* 2779:     */     }
/* 2780:     */     
/* 2781:     */     public LoadingValueReference(LocalCache.ValueReference<K, V> oldValue)
/* 2782:     */     {
/* 2783:3475 */       this.oldValue = oldValue;
/* 2784:     */     }
/* 2785:     */     
/* 2786:     */     public boolean isLoading()
/* 2787:     */     {
/* 2788:3480 */       return true;
/* 2789:     */     }
/* 2790:     */     
/* 2791:     */     public boolean isActive()
/* 2792:     */     {
/* 2793:3485 */       return this.oldValue.isActive();
/* 2794:     */     }
/* 2795:     */     
/* 2796:     */     public int getWeight()
/* 2797:     */     {
/* 2798:3490 */       return this.oldValue.getWeight();
/* 2799:     */     }
/* 2800:     */     
/* 2801:     */     public boolean set(@Nullable V newValue)
/* 2802:     */     {
/* 2803:3494 */       return this.futureValue.set(newValue);
/* 2804:     */     }
/* 2805:     */     
/* 2806:     */     public boolean setException(Throwable t)
/* 2807:     */     {
/* 2808:3498 */       return this.futureValue.setException(t);
/* 2809:     */     }
/* 2810:     */     
/* 2811:     */     private ListenableFuture<V> fullyFailedFuture(Throwable t)
/* 2812:     */     {
/* 2813:3502 */       return Futures.immediateFailedFuture(t);
/* 2814:     */     }
/* 2815:     */     
/* 2816:     */     public void notifyNewValue(@Nullable V newValue)
/* 2817:     */     {
/* 2818:3507 */       if (newValue != null) {
/* 2819:3510 */         set(newValue);
/* 2820:     */       } else {
/* 2821:3513 */         this.oldValue = LocalCache.unset();
/* 2822:     */       }
/* 2823:     */     }
/* 2824:     */     
/* 2825:     */     public ListenableFuture<V> loadFuture(K key, CacheLoader<? super K, V> loader)
/* 2826:     */     {
/* 2827:3520 */       this.stopwatch.start();
/* 2828:3521 */       V previousValue = this.oldValue.get();
/* 2829:     */       try
/* 2830:     */       {
/* 2831:3523 */         if (previousValue == null)
/* 2832:     */         {
/* 2833:3524 */           V newValue = loader.load(key);
/* 2834:3525 */           return set(newValue) ? this.futureValue : Futures.immediateFuture(newValue);
/* 2835:     */         }
/* 2836:3527 */         ListenableFuture<V> newValue = loader.reload(key, previousValue);
/* 2837:3528 */         if (newValue == null) {
/* 2838:3529 */           return Futures.immediateFuture(null);
/* 2839:     */         }
/* 2840:3533 */         Futures.transform(newValue, new Function()
/* 2841:     */         {
/* 2842:     */           public V apply(V newValue)
/* 2843:     */           {
/* 2844:3536 */             LocalCache.LoadingValueReference.this.set(newValue);
/* 2845:3537 */             return newValue;
/* 2846:     */           }
/* 2847:     */         });
/* 2848:     */       }
/* 2849:     */       catch (Throwable t)
/* 2850:     */       {
/* 2851:3541 */         if ((t instanceof InterruptedException)) {
/* 2852:3542 */           Thread.currentThread().interrupt();
/* 2853:     */         }
/* 2854:3544 */         return setException(t) ? this.futureValue : fullyFailedFuture(t);
/* 2855:     */       }
/* 2856:     */     }
/* 2857:     */     
/* 2858:     */     public long elapsedNanos()
/* 2859:     */     {
/* 2860:3549 */       return this.stopwatch.elapsed(TimeUnit.NANOSECONDS);
/* 2861:     */     }
/* 2862:     */     
/* 2863:     */     public V waitForValue()
/* 2864:     */       throws ExecutionException
/* 2865:     */     {
/* 2866:3554 */       return Uninterruptibles.getUninterruptibly(this.futureValue);
/* 2867:     */     }
/* 2868:     */     
/* 2869:     */     public V get()
/* 2870:     */     {
/* 2871:3559 */       return this.oldValue.get();
/* 2872:     */     }
/* 2873:     */     
/* 2874:     */     public LocalCache.ValueReference<K, V> getOldValue()
/* 2875:     */     {
/* 2876:3563 */       return this.oldValue;
/* 2877:     */     }
/* 2878:     */     
/* 2879:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 2880:     */     {
/* 2881:3568 */       return null;
/* 2882:     */     }
/* 2883:     */     
/* 2884:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, @Nullable V value, LocalCache.ReferenceEntry<K, V> entry)
/* 2885:     */     {
/* 2886:3574 */       return this;
/* 2887:     */     }
/* 2888:     */   }
/* 2889:     */   
/* 2890:     */   static final class WriteQueue<K, V>
/* 2891:     */     extends AbstractQueue<LocalCache.ReferenceEntry<K, V>>
/* 2892:     */   {
/* 2893:3592 */     final LocalCache.ReferenceEntry<K, V> head = new LocalCache.AbstractReferenceEntry()
/* 2894:     */     {
/* 2895:     */       public long getWriteTime()
/* 2896:     */       {
/* 2897:3596 */         return 9223372036854775807L;
/* 2898:     */       }
/* 2899:     */       
/* 2900:3602 */       LocalCache.ReferenceEntry<K, V> nextWrite = this;
/* 2901:     */       
/* 2902:     */       public void setWriteTime(long time) {}
/* 2903:     */       
/* 2904:     */       public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/* 2905:     */       {
/* 2906:3606 */         return this.nextWrite;
/* 2907:     */       }
/* 2908:     */       
/* 2909:     */       public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/* 2910:     */       {
/* 2911:3611 */         this.nextWrite = next;
/* 2912:     */       }
/* 2913:     */       
/* 2914:3614 */       LocalCache.ReferenceEntry<K, V> previousWrite = this;
/* 2915:     */       
/* 2916:     */       public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/* 2917:     */       {
/* 2918:3618 */         return this.previousWrite;
/* 2919:     */       }
/* 2920:     */       
/* 2921:     */       public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 2922:     */       {
/* 2923:3623 */         this.previousWrite = previous;
/* 2924:     */       }
/* 2925:     */     };
/* 2926:     */     
/* 2927:     */     public boolean offer(LocalCache.ReferenceEntry<K, V> entry)
/* 2928:     */     {
/* 2929:3632 */       LocalCache.connectWriteOrder(entry.getPreviousInWriteQueue(), entry.getNextInWriteQueue());
/* 2930:     */       
/* 2931:     */ 
/* 2932:3635 */       LocalCache.connectWriteOrder(this.head.getPreviousInWriteQueue(), entry);
/* 2933:3636 */       LocalCache.connectWriteOrder(entry, this.head);
/* 2934:     */       
/* 2935:3638 */       return true;
/* 2936:     */     }
/* 2937:     */     
/* 2938:     */     public LocalCache.ReferenceEntry<K, V> peek()
/* 2939:     */     {
/* 2940:3643 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInWriteQueue();
/* 2941:3644 */       return next == this.head ? null : next;
/* 2942:     */     }
/* 2943:     */     
/* 2944:     */     public LocalCache.ReferenceEntry<K, V> poll()
/* 2945:     */     {
/* 2946:3649 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInWriteQueue();
/* 2947:3650 */       if (next == this.head) {
/* 2948:3651 */         return null;
/* 2949:     */       }
/* 2950:3654 */       remove(next);
/* 2951:3655 */       return next;
/* 2952:     */     }
/* 2953:     */     
/* 2954:     */     public boolean remove(Object o)
/* 2955:     */     {
/* 2956:3661 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 2957:3662 */       LocalCache.ReferenceEntry<K, V> previous = e.getPreviousInWriteQueue();
/* 2958:3663 */       LocalCache.ReferenceEntry<K, V> next = e.getNextInWriteQueue();
/* 2959:3664 */       LocalCache.connectWriteOrder(previous, next);
/* 2960:3665 */       LocalCache.nullifyWriteOrder(e);
/* 2961:     */       
/* 2962:3667 */       return next != LocalCache.NullEntry.INSTANCE;
/* 2963:     */     }
/* 2964:     */     
/* 2965:     */     public boolean contains(Object o)
/* 2966:     */     {
/* 2967:3673 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 2968:3674 */       return e.getNextInWriteQueue() != LocalCache.NullEntry.INSTANCE;
/* 2969:     */     }
/* 2970:     */     
/* 2971:     */     public boolean isEmpty()
/* 2972:     */     {
/* 2973:3679 */       return this.head.getNextInWriteQueue() == this.head;
/* 2974:     */     }
/* 2975:     */     
/* 2976:     */     public int size()
/* 2977:     */     {
/* 2978:3684 */       int size = 0;
/* 2979:3685 */       for (LocalCache.ReferenceEntry<K, V> e = this.head.getNextInWriteQueue(); e != this.head; e = e.getNextInWriteQueue()) {
/* 2980:3687 */         size++;
/* 2981:     */       }
/* 2982:3689 */       return size;
/* 2983:     */     }
/* 2984:     */     
/* 2985:     */     public void clear()
/* 2986:     */     {
/* 2987:3694 */       LocalCache.ReferenceEntry<K, V> e = this.head.getNextInWriteQueue();
/* 2988:3695 */       while (e != this.head)
/* 2989:     */       {
/* 2990:3696 */         LocalCache.ReferenceEntry<K, V> next = e.getNextInWriteQueue();
/* 2991:3697 */         LocalCache.nullifyWriteOrder(e);
/* 2992:3698 */         e = next;
/* 2993:     */       }
/* 2994:3701 */       this.head.setNextInWriteQueue(this.head);
/* 2995:3702 */       this.head.setPreviousInWriteQueue(this.head);
/* 2996:     */     }
/* 2997:     */     
/* 2998:     */     public Iterator<LocalCache.ReferenceEntry<K, V>> iterator()
/* 2999:     */     {
/* 3000:3707 */       new AbstractSequentialIterator(peek())
/* 3001:     */       {
/* 3002:     */         protected LocalCache.ReferenceEntry<K, V> computeNext(LocalCache.ReferenceEntry<K, V> previous)
/* 3003:     */         {
/* 3004:3710 */           LocalCache.ReferenceEntry<K, V> next = previous.getNextInWriteQueue();
/* 3005:3711 */           return next == LocalCache.WriteQueue.this.head ? null : next;
/* 3006:     */         }
/* 3007:     */       };
/* 3008:     */     }
/* 3009:     */   }
/* 3010:     */   
/* 3011:     */   static final class AccessQueue<K, V>
/* 3012:     */     extends AbstractQueue<LocalCache.ReferenceEntry<K, V>>
/* 3013:     */   {
/* 3014:3729 */     final LocalCache.ReferenceEntry<K, V> head = new LocalCache.AbstractReferenceEntry()
/* 3015:     */     {
/* 3016:     */       public long getAccessTime()
/* 3017:     */       {
/* 3018:3733 */         return 9223372036854775807L;
/* 3019:     */       }
/* 3020:     */       
/* 3021:3739 */       LocalCache.ReferenceEntry<K, V> nextAccess = this;
/* 3022:     */       
/* 3023:     */       public void setAccessTime(long time) {}
/* 3024:     */       
/* 3025:     */       public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/* 3026:     */       {
/* 3027:3743 */         return this.nextAccess;
/* 3028:     */       }
/* 3029:     */       
/* 3030:     */       public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/* 3031:     */       {
/* 3032:3748 */         this.nextAccess = next;
/* 3033:     */       }
/* 3034:     */       
/* 3035:3751 */       LocalCache.ReferenceEntry<K, V> previousAccess = this;
/* 3036:     */       
/* 3037:     */       public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/* 3038:     */       {
/* 3039:3755 */         return this.previousAccess;
/* 3040:     */       }
/* 3041:     */       
/* 3042:     */       public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 3043:     */       {
/* 3044:3760 */         this.previousAccess = previous;
/* 3045:     */       }
/* 3046:     */     };
/* 3047:     */     
/* 3048:     */     public boolean offer(LocalCache.ReferenceEntry<K, V> entry)
/* 3049:     */     {
/* 3050:3769 */       LocalCache.connectAccessOrder(entry.getPreviousInAccessQueue(), entry.getNextInAccessQueue());
/* 3051:     */       
/* 3052:     */ 
/* 3053:3772 */       LocalCache.connectAccessOrder(this.head.getPreviousInAccessQueue(), entry);
/* 3054:3773 */       LocalCache.connectAccessOrder(entry, this.head);
/* 3055:     */       
/* 3056:3775 */       return true;
/* 3057:     */     }
/* 3058:     */     
/* 3059:     */     public LocalCache.ReferenceEntry<K, V> peek()
/* 3060:     */     {
/* 3061:3780 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInAccessQueue();
/* 3062:3781 */       return next == this.head ? null : next;
/* 3063:     */     }
/* 3064:     */     
/* 3065:     */     public LocalCache.ReferenceEntry<K, V> poll()
/* 3066:     */     {
/* 3067:3786 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInAccessQueue();
/* 3068:3787 */       if (next == this.head) {
/* 3069:3788 */         return null;
/* 3070:     */       }
/* 3071:3791 */       remove(next);
/* 3072:3792 */       return next;
/* 3073:     */     }
/* 3074:     */     
/* 3075:     */     public boolean remove(Object o)
/* 3076:     */     {
/* 3077:3798 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3078:3799 */       LocalCache.ReferenceEntry<K, V> previous = e.getPreviousInAccessQueue();
/* 3079:3800 */       LocalCache.ReferenceEntry<K, V> next = e.getNextInAccessQueue();
/* 3080:3801 */       LocalCache.connectAccessOrder(previous, next);
/* 3081:3802 */       LocalCache.nullifyAccessOrder(e);
/* 3082:     */       
/* 3083:3804 */       return next != LocalCache.NullEntry.INSTANCE;
/* 3084:     */     }
/* 3085:     */     
/* 3086:     */     public boolean contains(Object o)
/* 3087:     */     {
/* 3088:3810 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3089:3811 */       return e.getNextInAccessQueue() != LocalCache.NullEntry.INSTANCE;
/* 3090:     */     }
/* 3091:     */     
/* 3092:     */     public boolean isEmpty()
/* 3093:     */     {
/* 3094:3816 */       return this.head.getNextInAccessQueue() == this.head;
/* 3095:     */     }
/* 3096:     */     
/* 3097:     */     public int size()
/* 3098:     */     {
/* 3099:3821 */       int size = 0;
/* 3100:3822 */       for (LocalCache.ReferenceEntry<K, V> e = this.head.getNextInAccessQueue(); e != this.head; e = e.getNextInAccessQueue()) {
/* 3101:3824 */         size++;
/* 3102:     */       }
/* 3103:3826 */       return size;
/* 3104:     */     }
/* 3105:     */     
/* 3106:     */     public void clear()
/* 3107:     */     {
/* 3108:3831 */       LocalCache.ReferenceEntry<K, V> e = this.head.getNextInAccessQueue();
/* 3109:3832 */       while (e != this.head)
/* 3110:     */       {
/* 3111:3833 */         LocalCache.ReferenceEntry<K, V> next = e.getNextInAccessQueue();
/* 3112:3834 */         LocalCache.nullifyAccessOrder(e);
/* 3113:3835 */         e = next;
/* 3114:     */       }
/* 3115:3838 */       this.head.setNextInAccessQueue(this.head);
/* 3116:3839 */       this.head.setPreviousInAccessQueue(this.head);
/* 3117:     */     }
/* 3118:     */     
/* 3119:     */     public Iterator<LocalCache.ReferenceEntry<K, V>> iterator()
/* 3120:     */     {
/* 3121:3844 */       new AbstractSequentialIterator(peek())
/* 3122:     */       {
/* 3123:     */         protected LocalCache.ReferenceEntry<K, V> computeNext(LocalCache.ReferenceEntry<K, V> previous)
/* 3124:     */         {
/* 3125:3847 */           LocalCache.ReferenceEntry<K, V> next = previous.getNextInAccessQueue();
/* 3126:3848 */           return next == LocalCache.AccessQueue.this.head ? null : next;
/* 3127:     */         }
/* 3128:     */       };
/* 3129:     */     }
/* 3130:     */   }
/* 3131:     */   
/* 3132:     */   public void cleanUp()
/* 3133:     */   {
/* 3134:3857 */     for (Segment<?, ?> segment : this.segments) {
/* 3135:3858 */       segment.cleanUp();
/* 3136:     */     }
/* 3137:     */   }
/* 3138:     */   
/* 3139:     */   public boolean isEmpty()
/* 3140:     */   {
/* 3141:3873 */     long sum = 0L;
/* 3142:3874 */     Segment<K, V>[] segments = this.segments;
/* 3143:3875 */     for (int i = 0; i < segments.length; i++)
/* 3144:     */     {
/* 3145:3876 */       if (segments[i].count != 0) {
/* 3146:3877 */         return false;
/* 3147:     */       }
/* 3148:3879 */       sum += segments[i].modCount;
/* 3149:     */     }
/* 3150:3882 */     if (sum != 0L)
/* 3151:     */     {
/* 3152:3883 */       for (int i = 0; i < segments.length; i++)
/* 3153:     */       {
/* 3154:3884 */         if (segments[i].count != 0) {
/* 3155:3885 */           return false;
/* 3156:     */         }
/* 3157:3887 */         sum -= segments[i].modCount;
/* 3158:     */       }
/* 3159:3889 */       if (sum != 0L) {
/* 3160:3890 */         return false;
/* 3161:     */       }
/* 3162:     */     }
/* 3163:3893 */     return true;
/* 3164:     */   }
/* 3165:     */   
/* 3166:     */   long longSize()
/* 3167:     */   {
/* 3168:3897 */     Segment<K, V>[] segments = this.segments;
/* 3169:3898 */     long sum = 0L;
/* 3170:3899 */     for (int i = 0; i < segments.length; i++) {
/* 3171:3900 */       sum += segments[i].count;
/* 3172:     */     }
/* 3173:3902 */     return sum;
/* 3174:     */   }
/* 3175:     */   
/* 3176:     */   public int size()
/* 3177:     */   {
/* 3178:3907 */     return Ints.saturatedCast(longSize());
/* 3179:     */   }
/* 3180:     */   
/* 3181:     */   @Nullable
/* 3182:     */   public V get(@Nullable Object key)
/* 3183:     */   {
/* 3184:3913 */     if (key == null) {
/* 3185:3914 */       return null;
/* 3186:     */     }
/* 3187:3916 */     int hash = hash(key);
/* 3188:3917 */     return segmentFor(hash).get(key, hash);
/* 3189:     */   }
/* 3190:     */   
/* 3191:     */   @Nullable
/* 3192:     */   public V getIfPresent(Object key)
/* 3193:     */   {
/* 3194:3922 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3195:3923 */     V value = segmentFor(hash).get(key, hash);
/* 3196:3924 */     if (value == null) {
/* 3197:3925 */       this.globalStatsCounter.recordMisses(1);
/* 3198:     */     } else {
/* 3199:3927 */       this.globalStatsCounter.recordHits(1);
/* 3200:     */     }
/* 3201:3929 */     return value;
/* 3202:     */   }
/* 3203:     */   
/* 3204:     */   V get(K key, CacheLoader<? super K, V> loader)
/* 3205:     */     throws ExecutionException
/* 3206:     */   {
/* 3207:3933 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3208:3934 */     return segmentFor(hash).get(key, hash, loader);
/* 3209:     */   }
/* 3210:     */   
/* 3211:     */   V getOrLoad(K key)
/* 3212:     */     throws ExecutionException
/* 3213:     */   {
/* 3214:3938 */     return get(key, this.defaultLoader);
/* 3215:     */   }
/* 3216:     */   
/* 3217:     */   ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/* 3218:     */   {
/* 3219:3942 */     int hits = 0;
/* 3220:3943 */     int misses = 0;
/* 3221:     */     
/* 3222:3945 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 3223:3946 */     for (Object key : keys)
/* 3224:     */     {
/* 3225:3947 */       V value = get(key);
/* 3226:3948 */       if (value == null)
/* 3227:     */       {
/* 3228:3949 */         misses++;
/* 3229:     */       }
/* 3230:     */       else
/* 3231:     */       {
/* 3232:3953 */         K castKey = key;
/* 3233:3954 */         result.put(castKey, value);
/* 3234:3955 */         hits++;
/* 3235:     */       }
/* 3236:     */     }
/* 3237:3958 */     this.globalStatsCounter.recordHits(hits);
/* 3238:3959 */     this.globalStatsCounter.recordMisses(misses);
/* 3239:3960 */     return ImmutableMap.copyOf(result);
/* 3240:     */   }
/* 3241:     */   
/* 3242:     */   ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 3243:     */     throws ExecutionException
/* 3244:     */   {
/* 3245:3964 */     int hits = 0;
/* 3246:3965 */     int misses = 0;
/* 3247:     */     
/* 3248:3967 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 3249:3968 */     Set<K> keysToLoad = Sets.newLinkedHashSet();
/* 3250:3969 */     for (K key : keys)
/* 3251:     */     {
/* 3252:3970 */       V value = get(key);
/* 3253:3971 */       if (!result.containsKey(key))
/* 3254:     */       {
/* 3255:3972 */         result.put(key, value);
/* 3256:3973 */         if (value == null)
/* 3257:     */         {
/* 3258:3974 */           misses++;
/* 3259:3975 */           keysToLoad.add(key);
/* 3260:     */         }
/* 3261:     */         else
/* 3262:     */         {
/* 3263:3977 */           hits++;
/* 3264:     */         }
/* 3265:     */       }
/* 3266:     */     }
/* 3267:     */     try
/* 3268:     */     {
/* 3269:3983 */       if (!keysToLoad.isEmpty())
/* 3270:     */       {
/* 3271:     */         Iterator i$;
/* 3272:     */         try
/* 3273:     */         {
/* 3274:3985 */           newEntries = loadAll(keysToLoad, this.defaultLoader);
/* 3275:3986 */           for (K key : keysToLoad)
/* 3276:     */           {
/* 3277:3987 */             V value = newEntries.get(key);
/* 3278:3988 */             if (value == null) {
/* 3279:3989 */               throw new CacheLoader.InvalidCacheLoadException("loadAll failed to return a value for " + key);
/* 3280:     */             }
/* 3281:3991 */             result.put(key, value);
/* 3282:     */           }
/* 3283:     */         }
/* 3284:     */         catch (CacheLoader.UnsupportedLoadingOperationException e)
/* 3285:     */         {
/* 3286:     */           Map<K, V> newEntries;
/* 3287:3995 */           i$ = keysToLoad.iterator();
/* 3288:     */         }
/* 3289:3995 */         while (i$.hasNext())
/* 3290:     */         {
/* 3291:3995 */           K key = i$.next();
/* 3292:3996 */           misses--;
/* 3293:3997 */           result.put(key, get(key, this.defaultLoader));
/* 3294:     */         }
/* 3295:     */       }
/* 3296:4001 */       return ImmutableMap.copyOf(result);
/* 3297:     */     }
/* 3298:     */     finally
/* 3299:     */     {
/* 3300:4003 */       this.globalStatsCounter.recordHits(hits);
/* 3301:4004 */       this.globalStatsCounter.recordMisses(misses);
/* 3302:     */     }
/* 3303:     */   }
/* 3304:     */   
/* 3305:     */   @Nullable
/* 3306:     */   Map<K, V> loadAll(Set<? extends K> keys, CacheLoader<? super K, V> loader)
/* 3307:     */     throws ExecutionException
/* 3308:     */   {
/* 3309:4015 */     Preconditions.checkNotNull(loader);
/* 3310:4016 */     Preconditions.checkNotNull(keys);
/* 3311:4017 */     Stopwatch stopwatch = Stopwatch.createStarted();
/* 3312:     */     
/* 3313:4019 */     boolean success = false;
/* 3314:     */     Map<K, V> result;
/* 3315:     */     try
/* 3316:     */     {
/* 3317:4022 */       Map<K, V> map = loader.loadAll(keys);
/* 3318:4023 */       result = map;
/* 3319:4024 */       success = true;
/* 3320:     */     }
/* 3321:     */     catch (CacheLoader.UnsupportedLoadingOperationException e)
/* 3322:     */     {
/* 3323:4026 */       success = true;
/* 3324:4027 */       throw e;
/* 3325:     */     }
/* 3326:     */     catch (InterruptedException e)
/* 3327:     */     {
/* 3328:4029 */       Thread.currentThread().interrupt();
/* 3329:4030 */       throw new ExecutionException(e);
/* 3330:     */     }
/* 3331:     */     catch (RuntimeException e)
/* 3332:     */     {
/* 3333:4032 */       throw new UncheckedExecutionException(e);
/* 3334:     */     }
/* 3335:     */     catch (Exception e)
/* 3336:     */     {
/* 3337:4034 */       throw new ExecutionException(e);
/* 3338:     */     }
/* 3339:     */     catch (Error e)
/* 3340:     */     {
/* 3341:4036 */       throw new ExecutionError(e);
/* 3342:     */     }
/* 3343:     */     finally
/* 3344:     */     {
/* 3345:4038 */       if (!success) {
/* 3346:4039 */         this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3347:     */       }
/* 3348:     */     }
/* 3349:4043 */     if (result == null)
/* 3350:     */     {
/* 3351:4044 */       this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3352:4045 */       throw new CacheLoader.InvalidCacheLoadException(loader + " returned null map from loadAll");
/* 3353:     */     }
/* 3354:4048 */     stopwatch.stop();
/* 3355:     */     
/* 3356:4050 */     boolean nullsPresent = false;
/* 3357:4051 */     for (Map.Entry<K, V> entry : result.entrySet())
/* 3358:     */     {
/* 3359:4052 */       K key = entry.getKey();
/* 3360:4053 */       V value = entry.getValue();
/* 3361:4054 */       if ((key == null) || (value == null)) {
/* 3362:4056 */         nullsPresent = true;
/* 3363:     */       } else {
/* 3364:4058 */         put(key, value);
/* 3365:     */       }
/* 3366:     */     }
/* 3367:4062 */     if (nullsPresent)
/* 3368:     */     {
/* 3369:4063 */       this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3370:4064 */       throw new CacheLoader.InvalidCacheLoadException(loader + " returned null keys or values from loadAll");
/* 3371:     */     }
/* 3372:4068 */     this.globalStatsCounter.recordLoadSuccess(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3373:4069 */     return result;
/* 3374:     */   }
/* 3375:     */   
/* 3376:     */   ReferenceEntry<K, V> getEntry(@Nullable Object key)
/* 3377:     */   {
/* 3378:4078 */     if (key == null) {
/* 3379:4079 */       return null;
/* 3380:     */     }
/* 3381:4081 */     int hash = hash(key);
/* 3382:4082 */     return segmentFor(hash).getEntry(key, hash);
/* 3383:     */   }
/* 3384:     */   
/* 3385:     */   void refresh(K key)
/* 3386:     */   {
/* 3387:4086 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3388:4087 */     segmentFor(hash).refresh(key, hash, this.defaultLoader, false);
/* 3389:     */   }
/* 3390:     */   
/* 3391:     */   public boolean containsKey(@Nullable Object key)
/* 3392:     */   {
/* 3393:4093 */     if (key == null) {
/* 3394:4094 */       return false;
/* 3395:     */     }
/* 3396:4096 */     int hash = hash(key);
/* 3397:4097 */     return segmentFor(hash).containsKey(key, hash);
/* 3398:     */   }
/* 3399:     */   
/* 3400:     */   public boolean containsValue(@Nullable Object value)
/* 3401:     */   {
/* 3402:4103 */     if (value == null) {
/* 3403:4104 */       return false;
/* 3404:     */     }
/* 3405:4112 */     long now = this.ticker.read();
/* 3406:4113 */     Segment<K, V>[] segments = this.segments;
/* 3407:4114 */     long last = -1L;
/* 3408:4115 */     for (int i = 0; i < 3; i++)
/* 3409:     */     {
/* 3410:4116 */       long sum = 0L;
/* 3411:4117 */       for (Segment<K, V> segment : segments)
/* 3412:     */       {
/* 3413:4120 */         int c = segment.count;
/* 3414:     */         
/* 3415:4122 */         AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;
/* 3416:4123 */         for (int j = 0; j < table.length(); j++) {
/* 3417:4124 */           for (ReferenceEntry<K, V> e = (ReferenceEntry)table.get(j); e != null; e = e.getNext())
/* 3418:     */           {
/* 3419:4125 */             V v = segment.getLiveValue(e, now);
/* 3420:4126 */             if ((v != null) && (this.valueEquivalence.equivalent(value, v))) {
/* 3421:4127 */               return true;
/* 3422:     */             }
/* 3423:     */           }
/* 3424:     */         }
/* 3425:4131 */         sum += segment.modCount;
/* 3426:     */       }
/* 3427:4133 */       if (sum == last) {
/* 3428:     */         break;
/* 3429:     */       }
/* 3430:4136 */       last = sum;
/* 3431:     */     }
/* 3432:4138 */     return false;
/* 3433:     */   }
/* 3434:     */   
/* 3435:     */   public V put(K key, V value)
/* 3436:     */   {
/* 3437:4143 */     Preconditions.checkNotNull(key);
/* 3438:4144 */     Preconditions.checkNotNull(value);
/* 3439:4145 */     int hash = hash(key);
/* 3440:4146 */     return segmentFor(hash).put(key, hash, value, false);
/* 3441:     */   }
/* 3442:     */   
/* 3443:     */   public V putIfAbsent(K key, V value)
/* 3444:     */   {
/* 3445:4151 */     Preconditions.checkNotNull(key);
/* 3446:4152 */     Preconditions.checkNotNull(value);
/* 3447:4153 */     int hash = hash(key);
/* 3448:4154 */     return segmentFor(hash).put(key, hash, value, true);
/* 3449:     */   }
/* 3450:     */   
/* 3451:     */   public void putAll(Map<? extends K, ? extends V> m)
/* 3452:     */   {
/* 3453:4159 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 3454:4160 */       put(e.getKey(), e.getValue());
/* 3455:     */     }
/* 3456:     */   }
/* 3457:     */   
/* 3458:     */   public V remove(@Nullable Object key)
/* 3459:     */   {
/* 3460:4166 */     if (key == null) {
/* 3461:4167 */       return null;
/* 3462:     */     }
/* 3463:4169 */     int hash = hash(key);
/* 3464:4170 */     return segmentFor(hash).remove(key, hash);
/* 3465:     */   }
/* 3466:     */   
/* 3467:     */   public boolean remove(@Nullable Object key, @Nullable Object value)
/* 3468:     */   {
/* 3469:4175 */     if ((key == null) || (value == null)) {
/* 3470:4176 */       return false;
/* 3471:     */     }
/* 3472:4178 */     int hash = hash(key);
/* 3473:4179 */     return segmentFor(hash).remove(key, hash, value);
/* 3474:     */   }
/* 3475:     */   
/* 3476:     */   public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 3477:     */   {
/* 3478:4184 */     Preconditions.checkNotNull(key);
/* 3479:4185 */     Preconditions.checkNotNull(newValue);
/* 3480:4186 */     if (oldValue == null) {
/* 3481:4187 */       return false;
/* 3482:     */     }
/* 3483:4189 */     int hash = hash(key);
/* 3484:4190 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/* 3485:     */   }
/* 3486:     */   
/* 3487:     */   public V replace(K key, V value)
/* 3488:     */   {
/* 3489:4195 */     Preconditions.checkNotNull(key);
/* 3490:4196 */     Preconditions.checkNotNull(value);
/* 3491:4197 */     int hash = hash(key);
/* 3492:4198 */     return segmentFor(hash).replace(key, hash, value);
/* 3493:     */   }
/* 3494:     */   
/* 3495:     */   public void clear()
/* 3496:     */   {
/* 3497:4203 */     for (Segment<K, V> segment : this.segments) {
/* 3498:4204 */       segment.clear();
/* 3499:     */     }
/* 3500:     */   }
/* 3501:     */   
/* 3502:     */   void invalidateAll(Iterable<?> keys)
/* 3503:     */   {
/* 3504:4210 */     for (Object key : keys) {
/* 3505:4211 */       remove(key);
/* 3506:     */     }
/* 3507:     */   }
/* 3508:     */   
/* 3509:     */   public Set<K> keySet()
/* 3510:     */   {
/* 3511:4220 */     Set<K> ks = this.keySet;
/* 3512:4221 */     return this.keySet = new KeySet(this);
/* 3513:     */   }
/* 3514:     */   
/* 3515:     */   public Collection<V> values()
/* 3516:     */   {
/* 3517:4229 */     Collection<V> vs = this.values;
/* 3518:4230 */     return this.values = new Values(this);
/* 3519:     */   }
/* 3520:     */   
/* 3521:     */   @GwtIncompatible("Not supported.")
/* 3522:     */   public Set<Map.Entry<K, V>> entrySet()
/* 3523:     */   {
/* 3524:4239 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 3525:4240 */     return this.entrySet = new EntrySet(this);
/* 3526:     */   }
/* 3527:     */   
/* 3528:     */   abstract class HashIterator<T>
/* 3529:     */     implements Iterator<T>
/* 3530:     */   {
/* 3531:     */     int nextSegmentIndex;
/* 3532:     */     int nextTableIndex;
/* 3533:     */     LocalCache.Segment<K, V> currentSegment;
/* 3534:     */     AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> currentTable;
/* 3535:     */     LocalCache.ReferenceEntry<K, V> nextEntry;
/* 3536:     */     LocalCache<K, V>.WriteThroughEntry nextExternal;
/* 3537:     */     LocalCache<K, V>.WriteThroughEntry lastReturned;
/* 3538:     */     
/* 3539:     */     HashIterator()
/* 3540:     */     {
/* 3541:4256 */       this.nextSegmentIndex = (LocalCache.this.segments.length - 1);
/* 3542:4257 */       this.nextTableIndex = -1;
/* 3543:4258 */       advance();
/* 3544:     */     }
/* 3545:     */     
/* 3546:     */     public abstract T next();
/* 3547:     */     
/* 3548:     */     final void advance()
/* 3549:     */     {
/* 3550:4265 */       this.nextExternal = null;
/* 3551:4267 */       if (nextInChain()) {
/* 3552:4268 */         return;
/* 3553:     */       }
/* 3554:4271 */       if (nextInTable()) {
/* 3555:4272 */         return;
/* 3556:     */       }
/* 3557:4275 */       while (this.nextSegmentIndex >= 0)
/* 3558:     */       {
/* 3559:4276 */         this.currentSegment = LocalCache.this.segments[(this.nextSegmentIndex--)];
/* 3560:4277 */         if (this.currentSegment.count != 0)
/* 3561:     */         {
/* 3562:4278 */           this.currentTable = this.currentSegment.table;
/* 3563:4279 */           this.nextTableIndex = (this.currentTable.length() - 1);
/* 3564:4280 */           if (nextInTable()) {}
/* 3565:     */         }
/* 3566:     */       }
/* 3567:     */     }
/* 3568:     */     
/* 3569:     */     boolean nextInChain()
/* 3570:     */     {
/* 3571:4291 */       if (this.nextEntry != null) {
/* 3572:4292 */         for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; this.nextEntry = this.nextEntry.getNext()) {
/* 3573:4293 */           if (advanceTo(this.nextEntry)) {
/* 3574:4294 */             return true;
/* 3575:     */           }
/* 3576:     */         }
/* 3577:     */       }
/* 3578:4298 */       return false;
/* 3579:     */     }
/* 3580:     */     
/* 3581:     */     boolean nextInTable()
/* 3582:     */     {
/* 3583:4305 */       while (this.nextTableIndex >= 0) {
/* 3584:4306 */         if (((this.nextEntry = (LocalCache.ReferenceEntry)this.currentTable.get(this.nextTableIndex--)) != null) && (
/* 3585:4307 */           (advanceTo(this.nextEntry)) || (nextInChain()))) {
/* 3586:4308 */           return true;
/* 3587:     */         }
/* 3588:     */       }
/* 3589:4312 */       return false;
/* 3590:     */     }
/* 3591:     */     
/* 3592:     */     boolean advanceTo(LocalCache.ReferenceEntry<K, V> entry)
/* 3593:     */     {
/* 3594:     */       try
/* 3595:     */       {
/* 3596:4321 */         long now = LocalCache.this.ticker.read();
/* 3597:4322 */         K key = entry.getKey();
/* 3598:4323 */         V value = LocalCache.this.getLiveValue(entry, now);
/* 3599:     */         boolean bool;
/* 3600:4324 */         if (value != null)
/* 3601:     */         {
/* 3602:4325 */           this.nextExternal = new LocalCache.WriteThroughEntry(LocalCache.this, key, value);
/* 3603:4326 */           return true;
/* 3604:     */         }
/* 3605:4329 */         return false;
/* 3606:     */       }
/* 3607:     */       finally
/* 3608:     */       {
/* 3609:4332 */         this.currentSegment.postReadCleanup();
/* 3610:     */       }
/* 3611:     */     }
/* 3612:     */     
/* 3613:     */     public boolean hasNext()
/* 3614:     */     {
/* 3615:4338 */       return this.nextExternal != null;
/* 3616:     */     }
/* 3617:     */     
/* 3618:     */     LocalCache<K, V>.WriteThroughEntry nextEntry()
/* 3619:     */     {
/* 3620:4342 */       if (this.nextExternal == null) {
/* 3621:4343 */         throw new NoSuchElementException();
/* 3622:     */       }
/* 3623:4345 */       this.lastReturned = this.nextExternal;
/* 3624:4346 */       advance();
/* 3625:4347 */       return this.lastReturned;
/* 3626:     */     }
/* 3627:     */     
/* 3628:     */     public void remove()
/* 3629:     */     {
/* 3630:4352 */       Preconditions.checkState(this.lastReturned != null);
/* 3631:4353 */       LocalCache.this.remove(this.lastReturned.getKey());
/* 3632:4354 */       this.lastReturned = null;
/* 3633:     */     }
/* 3634:     */   }
/* 3635:     */   
/* 3636:     */   final class KeyIterator
/* 3637:     */     extends LocalCache<K, V>.HashIterator<K>
/* 3638:     */   {
/* 3639:     */     KeyIterator()
/* 3640:     */     {
/* 3641:4358 */       super();
/* 3642:     */     }
/* 3643:     */     
/* 3644:     */     public K next()
/* 3645:     */     {
/* 3646:4362 */       return nextEntry().getKey();
/* 3647:     */     }
/* 3648:     */   }
/* 3649:     */   
/* 3650:     */   final class ValueIterator
/* 3651:     */     extends LocalCache<K, V>.HashIterator<V>
/* 3652:     */   {
/* 3653:     */     ValueIterator()
/* 3654:     */     {
/* 3655:4366 */       super();
/* 3656:     */     }
/* 3657:     */     
/* 3658:     */     public V next()
/* 3659:     */     {
/* 3660:4370 */       return nextEntry().getValue();
/* 3661:     */     }
/* 3662:     */   }
/* 3663:     */   
/* 3664:     */   final class WriteThroughEntry
/* 3665:     */     implements Map.Entry<K, V>
/* 3666:     */   {
/* 3667:     */     final K key;
/* 3668:     */     V value;
/* 3669:     */     
/* 3670:     */     WriteThroughEntry(V key)
/* 3671:     */     {
/* 3672:4383 */       this.key = key;
/* 3673:4384 */       this.value = value;
/* 3674:     */     }
/* 3675:     */     
/* 3676:     */     public K getKey()
/* 3677:     */     {
/* 3678:4389 */       return this.key;
/* 3679:     */     }
/* 3680:     */     
/* 3681:     */     public V getValue()
/* 3682:     */     {
/* 3683:4394 */       return this.value;
/* 3684:     */     }
/* 3685:     */     
/* 3686:     */     public boolean equals(@Nullable Object object)
/* 3687:     */     {
/* 3688:4400 */       if ((object instanceof Map.Entry))
/* 3689:     */       {
/* 3690:4401 */         Map.Entry<?, ?> that = (Map.Entry)object;
/* 3691:4402 */         return (this.key.equals(that.getKey())) && (this.value.equals(that.getValue()));
/* 3692:     */       }
/* 3693:4404 */       return false;
/* 3694:     */     }
/* 3695:     */     
/* 3696:     */     public int hashCode()
/* 3697:     */     {
/* 3698:4410 */       return this.key.hashCode() ^ this.value.hashCode();
/* 3699:     */     }
/* 3700:     */     
/* 3701:     */     public V setValue(V newValue)
/* 3702:     */     {
/* 3703:4415 */       throw new UnsupportedOperationException();
/* 3704:     */     }
/* 3705:     */     
/* 3706:     */     public String toString()
/* 3707:     */     {
/* 3708:4422 */       return getKey() + "=" + getValue();
/* 3709:     */     }
/* 3710:     */   }
/* 3711:     */   
/* 3712:     */   final class EntryIterator
/* 3713:     */     extends LocalCache<K, V>.HashIterator<Map.Entry<K, V>>
/* 3714:     */   {
/* 3715:     */     EntryIterator()
/* 3716:     */     {
/* 3717:4426 */       super();
/* 3718:     */     }
/* 3719:     */     
/* 3720:     */     public Map.Entry<K, V> next()
/* 3721:     */     {
/* 3722:4430 */       return nextEntry();
/* 3723:     */     }
/* 3724:     */   }
/* 3725:     */   
/* 3726:     */   abstract class AbstractCacheSet<T>
/* 3727:     */     extends AbstractSet<T>
/* 3728:     */   {
/* 3729:     */     final ConcurrentMap<?, ?> map;
/* 3730:     */     
/* 3731:     */     AbstractCacheSet()
/* 3732:     */     {
/* 3733:4438 */       this.map = map;
/* 3734:     */     }
/* 3735:     */     
/* 3736:     */     public int size()
/* 3737:     */     {
/* 3738:4443 */       return this.map.size();
/* 3739:     */     }
/* 3740:     */     
/* 3741:     */     public boolean isEmpty()
/* 3742:     */     {
/* 3743:4448 */       return this.map.isEmpty();
/* 3744:     */     }
/* 3745:     */     
/* 3746:     */     public void clear()
/* 3747:     */     {
/* 3748:4453 */       this.map.clear();
/* 3749:     */     }
/* 3750:     */   }
/* 3751:     */   
/* 3752:     */   final class KeySet
/* 3753:     */     extends LocalCache<K, V>.AbstractCacheSet<K>
/* 3754:     */   {
/* 3755:     */     KeySet()
/* 3756:     */     {
/* 3757:4460 */       super(map);
/* 3758:     */     }
/* 3759:     */     
/* 3760:     */     public Iterator<K> iterator()
/* 3761:     */     {
/* 3762:4465 */       return new LocalCache.KeyIterator(LocalCache.this);
/* 3763:     */     }
/* 3764:     */     
/* 3765:     */     public boolean contains(Object o)
/* 3766:     */     {
/* 3767:4470 */       return this.map.containsKey(o);
/* 3768:     */     }
/* 3769:     */     
/* 3770:     */     public boolean remove(Object o)
/* 3771:     */     {
/* 3772:4475 */       return this.map.remove(o) != null;
/* 3773:     */     }
/* 3774:     */   }
/* 3775:     */   
/* 3776:     */   final class Values
/* 3777:     */     extends AbstractCollection<V>
/* 3778:     */   {
/* 3779:     */     private final ConcurrentMap<?, ?> map;
/* 3780:     */     
/* 3781:     */     Values()
/* 3782:     */     {
/* 3783:4483 */       this.map = map;
/* 3784:     */     }
/* 3785:     */     
/* 3786:     */     public int size()
/* 3787:     */     {
/* 3788:4487 */       return this.map.size();
/* 3789:     */     }
/* 3790:     */     
/* 3791:     */     public boolean isEmpty()
/* 3792:     */     {
/* 3793:4491 */       return this.map.isEmpty();
/* 3794:     */     }
/* 3795:     */     
/* 3796:     */     public void clear()
/* 3797:     */     {
/* 3798:4495 */       this.map.clear();
/* 3799:     */     }
/* 3800:     */     
/* 3801:     */     public Iterator<V> iterator()
/* 3802:     */     {
/* 3803:4500 */       return new LocalCache.ValueIterator(LocalCache.this);
/* 3804:     */     }
/* 3805:     */     
/* 3806:     */     public boolean contains(Object o)
/* 3807:     */     {
/* 3808:4505 */       return this.map.containsValue(o);
/* 3809:     */     }
/* 3810:     */   }
/* 3811:     */   
/* 3812:     */   final class EntrySet
/* 3813:     */     extends LocalCache<K, V>.AbstractCacheSet<Map.Entry<K, V>>
/* 3814:     */   {
/* 3815:     */     EntrySet()
/* 3816:     */     {
/* 3817:4512 */       super(map);
/* 3818:     */     }
/* 3819:     */     
/* 3820:     */     public Iterator<Map.Entry<K, V>> iterator()
/* 3821:     */     {
/* 3822:4517 */       return new LocalCache.EntryIterator(LocalCache.this);
/* 3823:     */     }
/* 3824:     */     
/* 3825:     */     public boolean contains(Object o)
/* 3826:     */     {
/* 3827:4522 */       if (!(o instanceof Map.Entry)) {
/* 3828:4523 */         return false;
/* 3829:     */       }
/* 3830:4525 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3831:4526 */       Object key = e.getKey();
/* 3832:4527 */       if (key == null) {
/* 3833:4528 */         return false;
/* 3834:     */       }
/* 3835:4530 */       V v = LocalCache.this.get(key);
/* 3836:     */       
/* 3837:4532 */       return (v != null) && (LocalCache.this.valueEquivalence.equivalent(e.getValue(), v));
/* 3838:     */     }
/* 3839:     */     
/* 3840:     */     public boolean remove(Object o)
/* 3841:     */     {
/* 3842:4537 */       if (!(o instanceof Map.Entry)) {
/* 3843:4538 */         return false;
/* 3844:     */       }
/* 3845:4540 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3846:4541 */       Object key = e.getKey();
/* 3847:4542 */       return (key != null) && (LocalCache.this.remove(key, e.getValue()));
/* 3848:     */     }
/* 3849:     */   }
/* 3850:     */   
/* 3851:     */   static class ManualSerializationProxy<K, V>
/* 3852:     */     extends ForwardingCache<K, V>
/* 3853:     */     implements Serializable
/* 3854:     */   {
/* 3855:     */     private static final long serialVersionUID = 1L;
/* 3856:     */     final LocalCache.Strength keyStrength;
/* 3857:     */     final LocalCache.Strength valueStrength;
/* 3858:     */     final Equivalence<Object> keyEquivalence;
/* 3859:     */     final Equivalence<Object> valueEquivalence;
/* 3860:     */     final long expireAfterWriteNanos;
/* 3861:     */     final long expireAfterAccessNanos;
/* 3862:     */     final long maxWeight;
/* 3863:     */     final Weigher<K, V> weigher;
/* 3864:     */     final int concurrencyLevel;
/* 3865:     */     final RemovalListener<? super K, ? super V> removalListener;
/* 3866:     */     final Ticker ticker;
/* 3867:     */     final CacheLoader<? super K, V> loader;
/* 3868:     */     transient Cache<K, V> delegate;
/* 3869:     */     
/* 3870:     */     ManualSerializationProxy(LocalCache<K, V> cache)
/* 3871:     */     {
/* 3872:4576 */       this(cache.keyStrength, cache.valueStrength, cache.keyEquivalence, cache.valueEquivalence, cache.expireAfterWriteNanos, cache.expireAfterAccessNanos, cache.maxWeight, cache.weigher, cache.concurrencyLevel, cache.removalListener, cache.ticker, cache.defaultLoader);
/* 3873:     */     }
/* 3874:     */     
/* 3875:     */     private ManualSerializationProxy(LocalCache.Strength keyStrength, LocalCache.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, long maxWeight, Weigher<K, V> weigher, int concurrencyLevel, RemovalListener<? super K, ? super V> removalListener, Ticker ticker, CacheLoader<? super K, V> loader)
/* 3876:     */     {
/* 3877:4598 */       this.keyStrength = keyStrength;
/* 3878:4599 */       this.valueStrength = valueStrength;
/* 3879:4600 */       this.keyEquivalence = keyEquivalence;
/* 3880:4601 */       this.valueEquivalence = valueEquivalence;
/* 3881:4602 */       this.expireAfterWriteNanos = expireAfterWriteNanos;
/* 3882:4603 */       this.expireAfterAccessNanos = expireAfterAccessNanos;
/* 3883:4604 */       this.maxWeight = maxWeight;
/* 3884:4605 */       this.weigher = weigher;
/* 3885:4606 */       this.concurrencyLevel = concurrencyLevel;
/* 3886:4607 */       this.removalListener = removalListener;
/* 3887:4608 */       this.ticker = ((ticker == Ticker.systemTicker()) || (ticker == CacheBuilder.NULL_TICKER) ? null : ticker);
/* 3888:     */       
/* 3889:4610 */       this.loader = loader;
/* 3890:     */     }
/* 3891:     */     
/* 3892:     */     CacheBuilder<K, V> recreateCacheBuilder()
/* 3893:     */     {
/* 3894:4614 */       CacheBuilder<K, V> builder = CacheBuilder.newBuilder().setKeyStrength(this.keyStrength).setValueStrength(this.valueStrength).keyEquivalence(this.keyEquivalence).valueEquivalence(this.valueEquivalence).concurrencyLevel(this.concurrencyLevel).removalListener(this.removalListener);
/* 3895:     */       
/* 3896:     */ 
/* 3897:     */ 
/* 3898:     */ 
/* 3899:     */ 
/* 3900:     */ 
/* 3901:4621 */       builder.strictParsing = false;
/* 3902:4622 */       if (this.expireAfterWriteNanos > 0L) {
/* 3903:4623 */         builder.expireAfterWrite(this.expireAfterWriteNanos, TimeUnit.NANOSECONDS);
/* 3904:     */       }
/* 3905:4625 */       if (this.expireAfterAccessNanos > 0L) {
/* 3906:4626 */         builder.expireAfterAccess(this.expireAfterAccessNanos, TimeUnit.NANOSECONDS);
/* 3907:     */       }
/* 3908:4628 */       if (this.weigher != CacheBuilder.OneWeigher.INSTANCE)
/* 3909:     */       {
/* 3910:4629 */         builder.weigher(this.weigher);
/* 3911:4630 */         if (this.maxWeight != -1L) {
/* 3912:4631 */           builder.maximumWeight(this.maxWeight);
/* 3913:     */         }
/* 3914:     */       }
/* 3915:4634 */       else if (this.maxWeight != -1L)
/* 3916:     */       {
/* 3917:4635 */         builder.maximumSize(this.maxWeight);
/* 3918:     */       }
/* 3919:4638 */       if (this.ticker != null) {
/* 3920:4639 */         builder.ticker(this.ticker);
/* 3921:     */       }
/* 3922:4641 */       return builder;
/* 3923:     */     }
/* 3924:     */     
/* 3925:     */     private void readObject(ObjectInputStream in)
/* 3926:     */       throws IOException, ClassNotFoundException
/* 3927:     */     {
/* 3928:4645 */       in.defaultReadObject();
/* 3929:4646 */       CacheBuilder<K, V> builder = recreateCacheBuilder();
/* 3930:4647 */       this.delegate = builder.build();
/* 3931:     */     }
/* 3932:     */     
/* 3933:     */     private Object readResolve()
/* 3934:     */     {
/* 3935:4651 */       return this.delegate;
/* 3936:     */     }
/* 3937:     */     
/* 3938:     */     protected Cache<K, V> delegate()
/* 3939:     */     {
/* 3940:4656 */       return this.delegate;
/* 3941:     */     }
/* 3942:     */   }
/* 3943:     */   
/* 3944:     */   static final class LoadingSerializationProxy<K, V>
/* 3945:     */     extends LocalCache.ManualSerializationProxy<K, V>
/* 3946:     */     implements LoadingCache<K, V>, Serializable
/* 3947:     */   {
/* 3948:     */     private static final long serialVersionUID = 1L;
/* 3949:     */     transient LoadingCache<K, V> autoDelegate;
/* 3950:     */     
/* 3951:     */     LoadingSerializationProxy(LocalCache<K, V> cache)
/* 3952:     */     {
/* 3953:4675 */       super();
/* 3954:     */     }
/* 3955:     */     
/* 3956:     */     private void readObject(ObjectInputStream in)
/* 3957:     */       throws IOException, ClassNotFoundException
/* 3958:     */     {
/* 3959:4679 */       in.defaultReadObject();
/* 3960:4680 */       CacheBuilder<K, V> builder = recreateCacheBuilder();
/* 3961:4681 */       this.autoDelegate = builder.build(this.loader);
/* 3962:     */     }
/* 3963:     */     
/* 3964:     */     public V get(K key)
/* 3965:     */       throws ExecutionException
/* 3966:     */     {
/* 3967:4686 */       return this.autoDelegate.get(key);
/* 3968:     */     }
/* 3969:     */     
/* 3970:     */     public V getUnchecked(K key)
/* 3971:     */     {
/* 3972:4691 */       return this.autoDelegate.getUnchecked(key);
/* 3973:     */     }
/* 3974:     */     
/* 3975:     */     public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 3976:     */       throws ExecutionException
/* 3977:     */     {
/* 3978:4696 */       return this.autoDelegate.getAll(keys);
/* 3979:     */     }
/* 3980:     */     
/* 3981:     */     public final V apply(K key)
/* 3982:     */     {
/* 3983:4701 */       return this.autoDelegate.apply(key);
/* 3984:     */     }
/* 3985:     */     
/* 3986:     */     public void refresh(K key)
/* 3987:     */     {
/* 3988:4706 */       this.autoDelegate.refresh(key);
/* 3989:     */     }
/* 3990:     */     
/* 3991:     */     private Object readResolve()
/* 3992:     */     {
/* 3993:4710 */       return this.autoDelegate;
/* 3994:     */     }
/* 3995:     */   }
/* 3996:     */   
/* 3997:     */   static class LocalManualCache<K, V>
/* 3998:     */     implements Cache<K, V>, Serializable
/* 3999:     */   {
/* 4000:     */     final LocalCache<K, V> localCache;
/* 4001:     */     private static final long serialVersionUID = 1L;
/* 4002:     */     
/* 4003:     */     LocalManualCache(CacheBuilder<? super K, ? super V> builder)
/* 4004:     */     {
/* 4005:4718 */       this(new LocalCache(builder, null));
/* 4006:     */     }
/* 4007:     */     
/* 4008:     */     private LocalManualCache(LocalCache<K, V> localCache)
/* 4009:     */     {
/* 4010:4722 */       this.localCache = localCache;
/* 4011:     */     }
/* 4012:     */     
/* 4013:     */     @Nullable
/* 4014:     */     public V getIfPresent(Object key)
/* 4015:     */     {
/* 4016:4730 */       return this.localCache.getIfPresent(key);
/* 4017:     */     }
/* 4018:     */     
/* 4019:     */     public V get(K key, final Callable<? extends V> valueLoader)
/* 4020:     */       throws ExecutionException
/* 4021:     */     {
/* 4022:4735 */       Preconditions.checkNotNull(valueLoader);
/* 4023:4736 */       this.localCache.get(key, new CacheLoader()
/* 4024:     */       {
/* 4025:     */         public V load(Object key)
/* 4026:     */           throws Exception
/* 4027:     */         {
/* 4028:4739 */           return valueLoader.call();
/* 4029:     */         }
/* 4030:     */       });
/* 4031:     */     }
/* 4032:     */     
/* 4033:     */     public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/* 4034:     */     {
/* 4035:4746 */       return this.localCache.getAllPresent(keys);
/* 4036:     */     }
/* 4037:     */     
/* 4038:     */     public void put(K key, V value)
/* 4039:     */     {
/* 4040:4751 */       this.localCache.put(key, value);
/* 4041:     */     }
/* 4042:     */     
/* 4043:     */     public void putAll(Map<? extends K, ? extends V> m)
/* 4044:     */     {
/* 4045:4756 */       this.localCache.putAll(m);
/* 4046:     */     }
/* 4047:     */     
/* 4048:     */     public void invalidate(Object key)
/* 4049:     */     {
/* 4050:4761 */       Preconditions.checkNotNull(key);
/* 4051:4762 */       this.localCache.remove(key);
/* 4052:     */     }
/* 4053:     */     
/* 4054:     */     public void invalidateAll(Iterable<?> keys)
/* 4055:     */     {
/* 4056:4767 */       this.localCache.invalidateAll(keys);
/* 4057:     */     }
/* 4058:     */     
/* 4059:     */     public void invalidateAll()
/* 4060:     */     {
/* 4061:4772 */       this.localCache.clear();
/* 4062:     */     }
/* 4063:     */     
/* 4064:     */     public long size()
/* 4065:     */     {
/* 4066:4777 */       return this.localCache.longSize();
/* 4067:     */     }
/* 4068:     */     
/* 4069:     */     public ConcurrentMap<K, V> asMap()
/* 4070:     */     {
/* 4071:4782 */       return this.localCache;
/* 4072:     */     }
/* 4073:     */     
/* 4074:     */     public CacheStats stats()
/* 4075:     */     {
/* 4076:4787 */       AbstractCache.SimpleStatsCounter aggregator = new AbstractCache.SimpleStatsCounter();
/* 4077:4788 */       aggregator.incrementBy(this.localCache.globalStatsCounter);
/* 4078:4789 */       for (LocalCache.Segment<K, V> segment : this.localCache.segments) {
/* 4079:4790 */         aggregator.incrementBy(segment.statsCounter);
/* 4080:     */       }
/* 4081:4792 */       return aggregator.snapshot();
/* 4082:     */     }
/* 4083:     */     
/* 4084:     */     public void cleanUp()
/* 4085:     */     {
/* 4086:4797 */       this.localCache.cleanUp();
/* 4087:     */     }
/* 4088:     */     
/* 4089:     */     Object writeReplace()
/* 4090:     */     {
/* 4091:4805 */       return new LocalCache.ManualSerializationProxy(this.localCache);
/* 4092:     */     }
/* 4093:     */   }
/* 4094:     */   
/* 4095:     */   static class LocalLoadingCache<K, V>
/* 4096:     */     extends LocalCache.LocalManualCache<K, V>
/* 4097:     */     implements LoadingCache<K, V>
/* 4098:     */   {
/* 4099:     */     private static final long serialVersionUID = 1L;
/* 4100:     */     
/* 4101:     */     LocalLoadingCache(CacheBuilder<? super K, ? super V> builder, CacheLoader<? super K, V> loader)
/* 4102:     */     {
/* 4103:4814 */       super(null);
/* 4104:     */     }
/* 4105:     */     
/* 4106:     */     public V get(K key)
/* 4107:     */       throws ExecutionException
/* 4108:     */     {
/* 4109:4821 */       return this.localCache.getOrLoad(key);
/* 4110:     */     }
/* 4111:     */     
/* 4112:     */     public V getUnchecked(K key)
/* 4113:     */     {
/* 4114:     */       try
/* 4115:     */       {
/* 4116:4827 */         return get(key);
/* 4117:     */       }
/* 4118:     */       catch (ExecutionException e)
/* 4119:     */       {
/* 4120:4829 */         throw new UncheckedExecutionException(e.getCause());
/* 4121:     */       }
/* 4122:     */     }
/* 4123:     */     
/* 4124:     */     public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 4125:     */       throws ExecutionException
/* 4126:     */     {
/* 4127:4835 */       return this.localCache.getAll(keys);
/* 4128:     */     }
/* 4129:     */     
/* 4130:     */     public void refresh(K key)
/* 4131:     */     {
/* 4132:4840 */       this.localCache.refresh(key);
/* 4133:     */     }
/* 4134:     */     
/* 4135:     */     public final V apply(K key)
/* 4136:     */     {
/* 4137:4845 */       return getUnchecked(key);
/* 4138:     */     }
/* 4139:     */     
/* 4140:     */     Object writeReplace()
/* 4141:     */     {
/* 4142:4854 */       return new LocalCache.LoadingSerializationProxy(this.localCache);
/* 4143:     */     }
/* 4144:     */   }
/* 4145:     */   
/* 4146:     */   static abstract interface ReferenceEntry<K, V>
/* 4147:     */   {
/* 4148:     */     public abstract LocalCache.ValueReference<K, V> getValueReference();
/* 4149:     */     
/* 4150:     */     public abstract void setValueReference(LocalCache.ValueReference<K, V> paramValueReference);
/* 4151:     */     
/* 4152:     */     @Nullable
/* 4153:     */     public abstract ReferenceEntry<K, V> getNext();
/* 4154:     */     
/* 4155:     */     public abstract int getHash();
/* 4156:     */     
/* 4157:     */     @Nullable
/* 4158:     */     public abstract K getKey();
/* 4159:     */     
/* 4160:     */     public abstract long getAccessTime();
/* 4161:     */     
/* 4162:     */     public abstract void setAccessTime(long paramLong);
/* 4163:     */     
/* 4164:     */     public abstract ReferenceEntry<K, V> getNextInAccessQueue();
/* 4165:     */     
/* 4166:     */     public abstract void setNextInAccessQueue(ReferenceEntry<K, V> paramReferenceEntry);
/* 4167:     */     
/* 4168:     */     public abstract ReferenceEntry<K, V> getPreviousInAccessQueue();
/* 4169:     */     
/* 4170:     */     public abstract void setPreviousInAccessQueue(ReferenceEntry<K, V> paramReferenceEntry);
/* 4171:     */     
/* 4172:     */     public abstract long getWriteTime();
/* 4173:     */     
/* 4174:     */     public abstract void setWriteTime(long paramLong);
/* 4175:     */     
/* 4176:     */     public abstract ReferenceEntry<K, V> getNextInWriteQueue();
/* 4177:     */     
/* 4178:     */     public abstract void setNextInWriteQueue(ReferenceEntry<K, V> paramReferenceEntry);
/* 4179:     */     
/* 4180:     */     public abstract ReferenceEntry<K, V> getPreviousInWriteQueue();
/* 4181:     */     
/* 4182:     */     public abstract void setPreviousInWriteQueue(ReferenceEntry<K, V> paramReferenceEntry);
/* 4183:     */   }
/* 4184:     */   
/* 4185:     */   static abstract interface ValueReference<K, V>
/* 4186:     */   {
/* 4187:     */     @Nullable
/* 4188:     */     public abstract V get();
/* 4189:     */     
/* 4190:     */     public abstract V waitForValue()
/* 4191:     */       throws ExecutionException;
/* 4192:     */     
/* 4193:     */     public abstract int getWeight();
/* 4194:     */     
/* 4195:     */     @Nullable
/* 4196:     */     public abstract LocalCache.ReferenceEntry<K, V> getEntry();
/* 4197:     */     
/* 4198:     */     public abstract ValueReference<K, V> copyFor(ReferenceQueue<V> paramReferenceQueue, @Nullable V paramV, LocalCache.ReferenceEntry<K, V> paramReferenceEntry);
/* 4199:     */     
/* 4200:     */     public abstract void notifyNewValue(@Nullable V paramV);
/* 4201:     */     
/* 4202:     */     public abstract boolean isLoading();
/* 4203:     */     
/* 4204:     */     public abstract boolean isActive();
/* 4205:     */   }
/* 4206:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.LocalCache
 * JD-Core Version:    0.7.0.1
 */
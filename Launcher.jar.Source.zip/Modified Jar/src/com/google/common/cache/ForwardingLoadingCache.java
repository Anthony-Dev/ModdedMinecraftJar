/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import com.google.common.collect.ImmutableMap;
/*  6:   */ import java.util.concurrent.ExecutionException;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public abstract class ForwardingLoadingCache<K, V>
/* 10:   */   extends ForwardingCache<K, V>
/* 11:   */   implements LoadingCache<K, V>
/* 12:   */ {
/* 13:   */   protected abstract LoadingCache<K, V> delegate();
/* 14:   */   
/* 15:   */   public V get(K key)
/* 16:   */     throws ExecutionException
/* 17:   */   {
/* 18:48 */     return delegate().get(key);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public V getUnchecked(K key)
/* 22:   */   {
/* 23:53 */     return delegate().getUnchecked(key);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 27:   */     throws ExecutionException
/* 28:   */   {
/* 29:58 */     return delegate().getAll(keys);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public V apply(K key)
/* 33:   */   {
/* 34:63 */     return delegate().apply(key);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void refresh(K key)
/* 38:   */   {
/* 39:68 */     delegate().refresh(key);
/* 40:   */   }
/* 41:   */   
/* 42:   */   @Beta
/* 43:   */   public static abstract class SimpleForwardingLoadingCache<K, V>
/* 44:   */     extends ForwardingLoadingCache<K, V>
/* 45:   */   {
/* 46:   */     private final LoadingCache<K, V> delegate;
/* 47:   */     
/* 48:   */     protected SimpleForwardingLoadingCache(LoadingCache<K, V> delegate)
/* 49:   */     {
/* 50:83 */       this.delegate = ((LoadingCache)Preconditions.checkNotNull(delegate));
/* 51:   */     }
/* 52:   */     
/* 53:   */     protected final LoadingCache<K, V> delegate()
/* 54:   */     {
/* 55:88 */       return this.delegate;
/* 56:   */     }
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.ForwardingLoadingCache
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Supplier;
/*  5:   */ import java.util.concurrent.atomic.AtomicLong;
/*  6:   */ 
/*  7:   */ @GwtCompatible(emulated=true)
/*  8:   */ final class LongAddables
/*  9:   */ {
/* 10:   */   private static final Supplier<LongAddable> SUPPLIER;
/* 11:   */   
/* 12:   */   static
/* 13:   */   {
/* 14:   */     Supplier<LongAddable> supplier;
/* 15:   */     try
/* 16:   */     {
/* 17:37 */       new LongAdder();
/* 18:38 */       supplier = new Supplier()
/* 19:   */       {
/* 20:   */         public LongAddable get()
/* 21:   */         {
/* 22:41 */           return new LongAdder();
/* 23:   */         }
/* 24:   */       };
/* 25:   */     }
/* 26:   */     catch (Throwable t)
/* 27:   */     {
/* 28:45 */       supplier = new Supplier()
/* 29:   */       {
/* 30:   */         public LongAddable get()
/* 31:   */         {
/* 32:48 */           return new LongAddables.PureJavaLongAddable(null);
/* 33:   */         }
/* 34:   */       };
/* 35:   */     }
/* 36:52 */     SUPPLIER = supplier;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static LongAddable create()
/* 40:   */   {
/* 41:56 */     return (LongAddable)SUPPLIER.get();
/* 42:   */   }
/* 43:   */   
/* 44:   */   private static final class PureJavaLongAddable
/* 45:   */     extends AtomicLong
/* 46:   */     implements LongAddable
/* 47:   */   {
/* 48:   */     public void increment()
/* 49:   */     {
/* 50:62 */       getAndIncrement();
/* 51:   */     }
/* 52:   */     
/* 53:   */     public void add(long x)
/* 54:   */     {
/* 55:67 */       getAndAdd(x);
/* 56:   */     }
/* 57:   */     
/* 58:   */     public long sum()
/* 59:   */     {
/* 60:72 */       return get();
/* 61:   */     }
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.LongAddables
 * JD-Core Version:    0.7.0.1
 */
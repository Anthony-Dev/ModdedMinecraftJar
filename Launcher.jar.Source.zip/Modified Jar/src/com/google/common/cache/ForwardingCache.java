/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.collect.ForwardingObject;
/*   6:    */ import com.google.common.collect.ImmutableMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.concurrent.Callable;
/*   9:    */ import java.util.concurrent.ConcurrentMap;
/*  10:    */ import java.util.concurrent.ExecutionException;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @Beta
/*  14:    */ public abstract class ForwardingCache<K, V>
/*  15:    */   extends ForwardingObject
/*  16:    */   implements Cache<K, V>
/*  17:    */ {
/*  18:    */   protected abstract Cache<K, V> delegate();
/*  19:    */   
/*  20:    */   @Nullable
/*  21:    */   public V getIfPresent(Object key)
/*  22:    */   {
/*  23: 54 */     return delegate().getIfPresent(key);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public V get(K key, Callable<? extends V> valueLoader)
/*  27:    */     throws ExecutionException
/*  28:    */   {
/*  29: 62 */     return delegate().get(key, valueLoader);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/*  33:    */   {
/*  34: 70 */     return delegate().getAllPresent(keys);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void put(K key, V value)
/*  38:    */   {
/*  39: 78 */     delegate().put(key, value);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void putAll(Map<? extends K, ? extends V> m)
/*  43:    */   {
/*  44: 86 */     delegate().putAll(m);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void invalidate(Object key)
/*  48:    */   {
/*  49: 91 */     delegate().invalidate(key);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void invalidateAll(Iterable<?> keys)
/*  53:    */   {
/*  54: 99 */     delegate().invalidateAll(keys);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void invalidateAll()
/*  58:    */   {
/*  59:104 */     delegate().invalidateAll();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public long size()
/*  63:    */   {
/*  64:109 */     return delegate().size();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public CacheStats stats()
/*  68:    */   {
/*  69:114 */     return delegate().stats();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public ConcurrentMap<K, V> asMap()
/*  73:    */   {
/*  74:119 */     return delegate().asMap();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void cleanUp()
/*  78:    */   {
/*  79:124 */     delegate().cleanUp();
/*  80:    */   }
/*  81:    */   
/*  82:    */   @Beta
/*  83:    */   public static abstract class SimpleForwardingCache<K, V>
/*  84:    */     extends ForwardingCache<K, V>
/*  85:    */   {
/*  86:    */     private final Cache<K, V> delegate;
/*  87:    */     
/*  88:    */     protected SimpleForwardingCache(Cache<K, V> delegate)
/*  89:    */     {
/*  90:138 */       this.delegate = ((Cache)Preconditions.checkNotNull(delegate));
/*  91:    */     }
/*  92:    */     
/*  93:    */     protected final Cache<K, V> delegate()
/*  94:    */     {
/*  95:143 */       return this.delegate;
/*  96:    */     }
/*  97:    */   }
/*  98:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.cache.ForwardingCache
 * JD-Core Version:    0.7.0.1
 */
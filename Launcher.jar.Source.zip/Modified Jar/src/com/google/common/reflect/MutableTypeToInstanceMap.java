/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.ForwardingMap;
/*   7:    */ import com.google.common.collect.ForwardingMapEntry;
/*   8:    */ import com.google.common.collect.ForwardingSet;
/*   9:    */ import com.google.common.collect.Iterators;
/*  10:    */ import com.google.common.collect.Maps;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @Beta
/*  18:    */ public final class MutableTypeToInstanceMap<B>
/*  19:    */   extends ForwardingMap<TypeToken<? extends B>, B>
/*  20:    */   implements TypeToInstanceMap<B>
/*  21:    */ {
/*  22:    */   private final Map<TypeToken<? extends B>, B> backingMap;
/*  23:    */   
/*  24:    */   public MutableTypeToInstanceMap()
/*  25:    */   {
/*  26: 46 */     this.backingMap = Maps.newHashMap();
/*  27:    */   }
/*  28:    */   
/*  29:    */   @Nullable
/*  30:    */   public <T extends B> T getInstance(Class<T> type)
/*  31:    */   {
/*  32: 51 */     return trustedGet(TypeToken.of(type));
/*  33:    */   }
/*  34:    */   
/*  35:    */   @Nullable
/*  36:    */   public <T extends B> T putInstance(Class<T> type, @Nullable T value)
/*  37:    */   {
/*  38: 57 */     return trustedPut(TypeToken.of(type), value);
/*  39:    */   }
/*  40:    */   
/*  41:    */   @Nullable
/*  42:    */   public <T extends B> T getInstance(TypeToken<T> type)
/*  43:    */   {
/*  44: 63 */     return trustedGet(type.rejectTypeVariables());
/*  45:    */   }
/*  46:    */   
/*  47:    */   @Nullable
/*  48:    */   public <T extends B> T putInstance(TypeToken<T> type, @Nullable T value)
/*  49:    */   {
/*  50: 69 */     return trustedPut(type.rejectTypeVariables(), value);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public B put(TypeToken<? extends B> key, B value)
/*  54:    */   {
/*  55: 74 */     throw new UnsupportedOperationException("Please use putInstance() instead.");
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void putAll(Map<? extends TypeToken<? extends B>, ? extends B> map)
/*  59:    */   {
/*  60: 79 */     throw new UnsupportedOperationException("Please use putInstance() instead.");
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Set<Map.Entry<TypeToken<? extends B>, B>> entrySet()
/*  64:    */   {
/*  65: 83 */     return UnmodifiableEntry.transformEntries(super.entrySet());
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected Map<TypeToken<? extends B>, B> delegate()
/*  69:    */   {
/*  70: 87 */     return this.backingMap;
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Nullable
/*  74:    */   private <T extends B> T trustedPut(TypeToken<T> type, @Nullable T value)
/*  75:    */   {
/*  76: 93 */     return this.backingMap.put(type, value);
/*  77:    */   }
/*  78:    */   
/*  79:    */   @Nullable
/*  80:    */   private <T extends B> T trustedGet(TypeToken<T> type)
/*  81:    */   {
/*  82: 99 */     return this.backingMap.get(type);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static final class UnmodifiableEntry<K, V>
/*  86:    */     extends ForwardingMapEntry<K, V>
/*  87:    */   {
/*  88:    */     private final Map.Entry<K, V> delegate;
/*  89:    */     
/*  90:    */     static <K, V> Set<Map.Entry<K, V>> transformEntries(Set<Map.Entry<K, V>> entries)
/*  91:    */     {
/*  92:107 */       new ForwardingSet()
/*  93:    */       {
/*  94:    */         protected Set<Map.Entry<K, V>> delegate()
/*  95:    */         {
/*  96:109 */           return this.val$entries;
/*  97:    */         }
/*  98:    */         
/*  99:    */         public Iterator<Map.Entry<K, V>> iterator()
/* 100:    */         {
/* 101:112 */           return MutableTypeToInstanceMap.UnmodifiableEntry.transformEntries(super.iterator());
/* 102:    */         }
/* 103:    */         
/* 104:    */         public Object[] toArray()
/* 105:    */         {
/* 106:115 */           return standardToArray();
/* 107:    */         }
/* 108:    */         
/* 109:    */         public <T> T[] toArray(T[] array)
/* 110:    */         {
/* 111:118 */           return standardToArray(array);
/* 112:    */         }
/* 113:    */       };
/* 114:    */     }
/* 115:    */     
/* 116:    */     private static <K, V> Iterator<Map.Entry<K, V>> transformEntries(Iterator<Map.Entry<K, V>> entries)
/* 117:    */     {
/* 118:124 */       Iterators.transform(entries, new Function()
/* 119:    */       {
/* 120:    */         public Map.Entry<K, V> apply(Map.Entry<K, V> entry)
/* 121:    */         {
/* 122:126 */           return new MutableTypeToInstanceMap.UnmodifiableEntry(entry, null);
/* 123:    */         }
/* 124:    */       });
/* 125:    */     }
/* 126:    */     
/* 127:    */     private UnmodifiableEntry(Map.Entry<K, V> delegate)
/* 128:    */     {
/* 129:132 */       this.delegate = ((Map.Entry)Preconditions.checkNotNull(delegate));
/* 130:    */     }
/* 131:    */     
/* 132:    */     protected Map.Entry<K, V> delegate()
/* 133:    */     {
/* 134:136 */       return this.delegate;
/* 135:    */     }
/* 136:    */     
/* 137:    */     public V setValue(V value)
/* 138:    */     {
/* 139:140 */       throw new UnsupportedOperationException();
/* 140:    */     }
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.MutableTypeToInstanceMap
 * JD-Core Version:    0.7.0.1
 */
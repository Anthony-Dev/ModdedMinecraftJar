/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.lang.annotation.Annotation;
/*   5:    */ import java.lang.reflect.AccessibleObject;
/*   6:    */ import java.lang.reflect.Member;
/*   7:    */ import java.lang.reflect.Modifier;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ class Element
/*  11:    */   extends AccessibleObject
/*  12:    */   implements Member
/*  13:    */ {
/*  14:    */   private final AccessibleObject accessibleObject;
/*  15:    */   private final Member member;
/*  16:    */   
/*  17:    */   <M extends AccessibleObject,  extends Member> Element(M member)
/*  18:    */   {
/*  19: 43 */     Preconditions.checkNotNull(member);
/*  20: 44 */     this.accessibleObject = member;
/*  21: 45 */     this.member = ((Member)member);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public TypeToken<?> getOwnerType()
/*  25:    */   {
/*  26: 49 */     return TypeToken.of(getDeclaringClass());
/*  27:    */   }
/*  28:    */   
/*  29:    */   public final boolean isAnnotationPresent(Class<? extends Annotation> annotationClass)
/*  30:    */   {
/*  31: 53 */     return this.accessibleObject.isAnnotationPresent(annotationClass);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public final <A extends Annotation> A getAnnotation(Class<A> annotationClass)
/*  35:    */   {
/*  36: 57 */     return this.accessibleObject.getAnnotation(annotationClass);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public final Annotation[] getAnnotations()
/*  40:    */   {
/*  41: 61 */     return this.accessibleObject.getAnnotations();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public final Annotation[] getDeclaredAnnotations()
/*  45:    */   {
/*  46: 65 */     return this.accessibleObject.getDeclaredAnnotations();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public final void setAccessible(boolean flag)
/*  50:    */     throws SecurityException
/*  51:    */   {
/*  52: 69 */     this.accessibleObject.setAccessible(flag);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public final boolean isAccessible()
/*  56:    */   {
/*  57: 73 */     return this.accessibleObject.isAccessible();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Class<?> getDeclaringClass()
/*  61:    */   {
/*  62: 77 */     return this.member.getDeclaringClass();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public final String getName()
/*  66:    */   {
/*  67: 81 */     return this.member.getName();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public final int getModifiers()
/*  71:    */   {
/*  72: 85 */     return this.member.getModifiers();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public final boolean isSynthetic()
/*  76:    */   {
/*  77: 89 */     return this.member.isSynthetic();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public final boolean isPublic()
/*  81:    */   {
/*  82: 94 */     return Modifier.isPublic(getModifiers());
/*  83:    */   }
/*  84:    */   
/*  85:    */   public final boolean isProtected()
/*  86:    */   {
/*  87: 99 */     return Modifier.isProtected(getModifiers());
/*  88:    */   }
/*  89:    */   
/*  90:    */   public final boolean isPackagePrivate()
/*  91:    */   {
/*  92:104 */     return (!isPrivate()) && (!isPublic()) && (!isProtected());
/*  93:    */   }
/*  94:    */   
/*  95:    */   public final boolean isPrivate()
/*  96:    */   {
/*  97:109 */     return Modifier.isPrivate(getModifiers());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public final boolean isStatic()
/* 101:    */   {
/* 102:114 */     return Modifier.isStatic(getModifiers());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public final boolean isFinal()
/* 106:    */   {
/* 107:125 */     return Modifier.isFinal(getModifiers());
/* 108:    */   }
/* 109:    */   
/* 110:    */   public final boolean isAbstract()
/* 111:    */   {
/* 112:130 */     return Modifier.isAbstract(getModifiers());
/* 113:    */   }
/* 114:    */   
/* 115:    */   public final boolean isNative()
/* 116:    */   {
/* 117:135 */     return Modifier.isNative(getModifiers());
/* 118:    */   }
/* 119:    */   
/* 120:    */   public final boolean isSynchronized()
/* 121:    */   {
/* 122:140 */     return Modifier.isSynchronized(getModifiers());
/* 123:    */   }
/* 124:    */   
/* 125:    */   final boolean isVolatile()
/* 126:    */   {
/* 127:145 */     return Modifier.isVolatile(getModifiers());
/* 128:    */   }
/* 129:    */   
/* 130:    */   final boolean isTransient()
/* 131:    */   {
/* 132:150 */     return Modifier.isTransient(getModifiers());
/* 133:    */   }
/* 134:    */   
/* 135:    */   public boolean equals(@Nullable Object obj)
/* 136:    */   {
/* 137:154 */     if ((obj instanceof Element))
/* 138:    */     {
/* 139:155 */       Element that = (Element)obj;
/* 140:156 */       return (getOwnerType().equals(that.getOwnerType())) && (this.member.equals(that.member));
/* 141:    */     }
/* 142:158 */     return false;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public int hashCode()
/* 146:    */   {
/* 147:162 */     return this.member.hashCode();
/* 148:    */   }
/* 149:    */   
/* 150:    */   public String toString()
/* 151:    */   {
/* 152:166 */     return this.member.toString();
/* 153:    */   }
/* 154:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.Element
 * JD-Core Version:    0.7.0.1
 */
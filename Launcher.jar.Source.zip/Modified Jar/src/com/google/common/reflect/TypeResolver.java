/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Joiner;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.collect.ImmutableMap;
/*   8:    */ import com.google.common.collect.ImmutableMap.Builder;
/*   9:    */ import com.google.common.collect.Maps;
/*  10:    */ import java.lang.reflect.GenericArrayType;
/*  11:    */ import java.lang.reflect.ParameterizedType;
/*  12:    */ import java.lang.reflect.Type;
/*  13:    */ import java.lang.reflect.TypeVariable;
/*  14:    */ import java.lang.reflect.WildcardType;
/*  15:    */ import java.util.Arrays;
/*  16:    */ import java.util.Map;
/*  17:    */ import java.util.Map.Entry;
/*  18:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @Beta
/*  22:    */ public final class TypeResolver
/*  23:    */ {
/*  24:    */   private final TypeTable typeTable;
/*  25:    */   
/*  26:    */   public TypeResolver()
/*  27:    */   {
/*  28: 60 */     this.typeTable = new TypeTable();
/*  29:    */   }
/*  30:    */   
/*  31:    */   private TypeResolver(TypeTable typeTable)
/*  32:    */   {
/*  33: 64 */     this.typeTable = typeTable;
/*  34:    */   }
/*  35:    */   
/*  36:    */   static TypeResolver accordingTo(Type type)
/*  37:    */   {
/*  38: 68 */     return new TypeResolver().where(TypeMappingIntrospector.getTypeMappings(type));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public TypeResolver where(Type formal, Type actual)
/*  42:    */   {
/*  43: 91 */     Map<TypeVariableKey, Type> mappings = Maps.newHashMap();
/*  44: 92 */     populateTypeMappings(mappings, (Type)Preconditions.checkNotNull(formal), (Type)Preconditions.checkNotNull(actual));
/*  45: 93 */     return where(mappings);
/*  46:    */   }
/*  47:    */   
/*  48:    */   TypeResolver where(Map<TypeVariableKey, ? extends Type> mappings)
/*  49:    */   {
/*  50: 98 */     return new TypeResolver(this.typeTable.where(mappings));
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static void populateTypeMappings(Map<TypeVariableKey, Type> mappings, Type from, final Type to)
/*  54:    */   {
/*  55:103 */     if (from.equals(to)) {
/*  56:104 */       return;
/*  57:    */     }
/*  58:106 */     new TypeVisitor()
/*  59:    */     {
/*  60:    */       void visitTypeVariable(TypeVariable<?> typeVariable)
/*  61:    */       {
/*  62:108 */         this.val$mappings.put(new TypeResolver.TypeVariableKey(typeVariable), to);
/*  63:    */       }
/*  64:    */       
/*  65:    */       void visitWildcardType(WildcardType fromWildcardType)
/*  66:    */       {
/*  67:111 */         WildcardType toWildcardType = (WildcardType)TypeResolver.expectArgument(WildcardType.class, to);
/*  68:112 */         Type[] fromUpperBounds = fromWildcardType.getUpperBounds();
/*  69:113 */         Type[] toUpperBounds = toWildcardType.getUpperBounds();
/*  70:114 */         Type[] fromLowerBounds = fromWildcardType.getLowerBounds();
/*  71:115 */         Type[] toLowerBounds = toWildcardType.getLowerBounds();
/*  72:116 */         Preconditions.checkArgument((fromUpperBounds.length == toUpperBounds.length) && (fromLowerBounds.length == toLowerBounds.length), "Incompatible type: %s vs. %s", new Object[] { fromWildcardType, to });
/*  73:120 */         for (int i = 0; i < fromUpperBounds.length; i++) {
/*  74:121 */           TypeResolver.populateTypeMappings(this.val$mappings, fromUpperBounds[i], toUpperBounds[i]);
/*  75:    */         }
/*  76:123 */         for (int i = 0; i < fromLowerBounds.length; i++) {
/*  77:124 */           TypeResolver.populateTypeMappings(this.val$mappings, fromLowerBounds[i], toLowerBounds[i]);
/*  78:    */         }
/*  79:    */       }
/*  80:    */       
/*  81:    */       void visitParameterizedType(ParameterizedType fromParameterizedType)
/*  82:    */       {
/*  83:128 */         ParameterizedType toParameterizedType = (ParameterizedType)TypeResolver.expectArgument(ParameterizedType.class, to);
/*  84:129 */         Preconditions.checkArgument(fromParameterizedType.getRawType().equals(toParameterizedType.getRawType()), "Inconsistent raw type: %s vs. %s", new Object[] { fromParameterizedType, to });
/*  85:    */         
/*  86:131 */         Type[] fromArgs = fromParameterizedType.getActualTypeArguments();
/*  87:132 */         Type[] toArgs = toParameterizedType.getActualTypeArguments();
/*  88:133 */         Preconditions.checkArgument(fromArgs.length == toArgs.length, "%s not compatible with %s", new Object[] { fromParameterizedType, toParameterizedType });
/*  89:135 */         for (int i = 0; i < fromArgs.length; i++) {
/*  90:136 */           TypeResolver.populateTypeMappings(this.val$mappings, fromArgs[i], toArgs[i]);
/*  91:    */         }
/*  92:    */       }
/*  93:    */       
/*  94:    */       void visitGenericArrayType(GenericArrayType fromArrayType)
/*  95:    */       {
/*  96:140 */         Type componentType = Types.getComponentType(to);
/*  97:141 */         Preconditions.checkArgument(componentType != null, "%s is not an array type.", new Object[] { to });
/*  98:142 */         TypeResolver.populateTypeMappings(this.val$mappings, fromArrayType.getGenericComponentType(), componentType);
/*  99:    */       }
/* 100:    */       
/* 101:    */       void visitClass(Class<?> fromClass)
/* 102:    */       {
/* 103:148 */         throw new IllegalArgumentException("No type mapping from " + fromClass);
/* 104:    */       }
/* 105:148 */     }.visit(new Type[] { from });
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Type resolveType(Type type)
/* 109:    */   {
/* 110:158 */     Preconditions.checkNotNull(type);
/* 111:159 */     if ((type instanceof TypeVariable)) {
/* 112:160 */       return this.typeTable.resolve((TypeVariable)type);
/* 113:    */     }
/* 114:161 */     if ((type instanceof ParameterizedType)) {
/* 115:162 */       return resolveParameterizedType((ParameterizedType)type);
/* 116:    */     }
/* 117:163 */     if ((type instanceof GenericArrayType)) {
/* 118:164 */       return resolveGenericArrayType((GenericArrayType)type);
/* 119:    */     }
/* 120:165 */     if ((type instanceof WildcardType)) {
/* 121:166 */       return resolveWildcardType((WildcardType)type);
/* 122:    */     }
/* 123:169 */     return type;
/* 124:    */   }
/* 125:    */   
/* 126:    */   private Type[] resolveTypes(Type[] types)
/* 127:    */   {
/* 128:174 */     Type[] result = new Type[types.length];
/* 129:175 */     for (int i = 0; i < types.length; i++) {
/* 130:176 */       result[i] = resolveType(types[i]);
/* 131:    */     }
/* 132:178 */     return result;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private WildcardType resolveWildcardType(WildcardType type)
/* 136:    */   {
/* 137:182 */     Type[] lowerBounds = type.getLowerBounds();
/* 138:183 */     Type[] upperBounds = type.getUpperBounds();
/* 139:184 */     return new Types.WildcardTypeImpl(resolveTypes(lowerBounds), resolveTypes(upperBounds));
/* 140:    */   }
/* 141:    */   
/* 142:    */   private Type resolveGenericArrayType(GenericArrayType type)
/* 143:    */   {
/* 144:189 */     Type componentType = type.getGenericComponentType();
/* 145:190 */     Type resolvedComponentType = resolveType(componentType);
/* 146:191 */     return Types.newArrayType(resolvedComponentType);
/* 147:    */   }
/* 148:    */   
/* 149:    */   private ParameterizedType resolveParameterizedType(ParameterizedType type)
/* 150:    */   {
/* 151:195 */     Type owner = type.getOwnerType();
/* 152:196 */     Type resolvedOwner = owner == null ? null : resolveType(owner);
/* 153:197 */     Type resolvedRawType = resolveType(type.getRawType());
/* 154:    */     
/* 155:199 */     Type[] args = type.getActualTypeArguments();
/* 156:200 */     Type[] resolvedArgs = resolveTypes(args);
/* 157:201 */     return Types.newParameterizedTypeWithOwner(resolvedOwner, (Class)resolvedRawType, resolvedArgs);
/* 158:    */   }
/* 159:    */   
/* 160:    */   private static <T> T expectArgument(Class<T> type, Object arg)
/* 161:    */   {
/* 162:    */     try
/* 163:    */     {
/* 164:207 */       return type.cast(arg);
/* 165:    */     }
/* 166:    */     catch (ClassCastException e)
/* 167:    */     {
/* 168:209 */       throw new IllegalArgumentException(arg + " is not a " + type.getSimpleName());
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   private static class TypeTable
/* 173:    */   {
/* 174:    */     private final ImmutableMap<TypeResolver.TypeVariableKey, Type> map;
/* 175:    */     
/* 176:    */     TypeTable()
/* 177:    */     {
/* 178:218 */       this.map = ImmutableMap.of();
/* 179:    */     }
/* 180:    */     
/* 181:    */     private TypeTable(ImmutableMap<TypeResolver.TypeVariableKey, Type> map)
/* 182:    */     {
/* 183:222 */       this.map = map;
/* 184:    */     }
/* 185:    */     
/* 186:    */     final TypeTable where(Map<TypeResolver.TypeVariableKey, ? extends Type> mappings)
/* 187:    */     {
/* 188:227 */       ImmutableMap.Builder<TypeResolver.TypeVariableKey, Type> builder = ImmutableMap.builder();
/* 189:228 */       builder.putAll(this.map);
/* 190:229 */       for (Map.Entry<TypeResolver.TypeVariableKey, ? extends Type> mapping : mappings.entrySet())
/* 191:    */       {
/* 192:230 */         TypeResolver.TypeVariableKey variable = (TypeResolver.TypeVariableKey)mapping.getKey();
/* 193:231 */         Type type = (Type)mapping.getValue();
/* 194:232 */         Preconditions.checkArgument(!variable.equalsType(type), "Type variable %s bound to itself", new Object[] { variable });
/* 195:233 */         builder.put(variable, type);
/* 196:    */       }
/* 197:235 */       return new TypeTable(builder.build());
/* 198:    */     }
/* 199:    */     
/* 200:    */     final Type resolve(final TypeVariable<?> var)
/* 201:    */     {
/* 202:239 */       final TypeTable unguarded = this;
/* 203:240 */       TypeTable guarded = new TypeTable()
/* 204:    */       {
/* 205:    */         public Type resolveInternal(TypeVariable<?> intermediateVar, TypeResolver.TypeTable forDependent)
/* 206:    */         {
/* 207:243 */           if (intermediateVar.getGenericDeclaration().equals(var.getGenericDeclaration())) {
/* 208:244 */             return intermediateVar;
/* 209:    */           }
/* 210:246 */           return unguarded.resolveInternal(intermediateVar, forDependent);
/* 211:    */         }
/* 212:248 */       };
/* 213:249 */       return resolveInternal(var, guarded);
/* 214:    */     }
/* 215:    */     
/* 216:    */     Type resolveInternal(TypeVariable<?> var, TypeTable forDependants)
/* 217:    */     {
/* 218:261 */       Type type = (Type)this.map.get(new TypeResolver.TypeVariableKey(var));
/* 219:262 */       if (type == null)
/* 220:    */       {
/* 221:263 */         Type[] bounds = var.getBounds();
/* 222:264 */         if (bounds.length == 0) {
/* 223:265 */           return var;
/* 224:    */         }
/* 225:267 */         Type[] resolvedBounds = new TypeResolver(forDependants, null).resolveTypes(bounds);
/* 226:296 */         if ((Types.NativeTypeVariableEquals.NATIVE_TYPE_VARIABLE_ONLY) && (Arrays.equals(bounds, resolvedBounds))) {
/* 227:298 */           return var;
/* 228:    */         }
/* 229:300 */         return Types.newArtificialTypeVariable(var.getGenericDeclaration(), var.getName(), resolvedBounds);
/* 230:    */       }
/* 231:304 */       return new TypeResolver(forDependants, null).resolveType(type);
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   private static final class TypeMappingIntrospector
/* 236:    */     extends TypeVisitor
/* 237:    */   {
/* 238:310 */     private static final TypeResolver.WildcardCapturer wildcardCapturer = new TypeResolver.WildcardCapturer(null);
/* 239:312 */     private final Map<TypeResolver.TypeVariableKey, Type> mappings = Maps.newHashMap();
/* 240:    */     
/* 241:    */     static ImmutableMap<TypeResolver.TypeVariableKey, Type> getTypeMappings(Type contextType)
/* 242:    */     {
/* 243:320 */       TypeMappingIntrospector introspector = new TypeMappingIntrospector();
/* 244:321 */       introspector.visit(new Type[] { wildcardCapturer.capture(contextType) });
/* 245:322 */       return ImmutableMap.copyOf(introspector.mappings);
/* 246:    */     }
/* 247:    */     
/* 248:    */     void visitClass(Class<?> clazz)
/* 249:    */     {
/* 250:326 */       visit(new Type[] { clazz.getGenericSuperclass() });
/* 251:327 */       visit(clazz.getGenericInterfaces());
/* 252:    */     }
/* 253:    */     
/* 254:    */     void visitParameterizedType(ParameterizedType parameterizedType)
/* 255:    */     {
/* 256:331 */       Class<?> rawClass = (Class)parameterizedType.getRawType();
/* 257:332 */       TypeVariable<?>[] vars = rawClass.getTypeParameters();
/* 258:333 */       Type[] typeArgs = parameterizedType.getActualTypeArguments();
/* 259:334 */       Preconditions.checkState(vars.length == typeArgs.length);
/* 260:335 */       for (int i = 0; i < vars.length; i++) {
/* 261:336 */         map(new TypeResolver.TypeVariableKey(vars[i]), typeArgs[i]);
/* 262:    */       }
/* 263:338 */       visit(new Type[] { rawClass });
/* 264:339 */       visit(new Type[] { parameterizedType.getOwnerType() });
/* 265:    */     }
/* 266:    */     
/* 267:    */     void visitTypeVariable(TypeVariable<?> t)
/* 268:    */     {
/* 269:343 */       visit(t.getBounds());
/* 270:    */     }
/* 271:    */     
/* 272:    */     void visitWildcardType(WildcardType t)
/* 273:    */     {
/* 274:347 */       visit(t.getUpperBounds());
/* 275:    */     }
/* 276:    */     
/* 277:    */     private void map(TypeResolver.TypeVariableKey var, Type arg)
/* 278:    */     {
/* 279:351 */       if (this.mappings.containsKey(var)) {
/* 280:357 */         return;
/* 281:    */       }
/* 282:360 */       for (Type t = arg; t != null; t = (Type)this.mappings.get(TypeResolver.TypeVariableKey.forLookup(t))) {
/* 283:361 */         if (var.equalsType(t))
/* 284:    */         {
/* 285:366 */           for (Type x = arg; x != null; x = (Type)this.mappings.remove(TypeResolver.TypeVariableKey.forLookup(x))) {}
/* 286:367 */           return;
/* 287:    */         }
/* 288:    */       }
/* 289:370 */       this.mappings.put(var, arg);
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   private static final class WildcardCapturer
/* 294:    */   {
/* 295:383 */     private final AtomicInteger id = new AtomicInteger();
/* 296:    */     
/* 297:    */     Type capture(Type type)
/* 298:    */     {
/* 299:386 */       Preconditions.checkNotNull(type);
/* 300:387 */       if ((type instanceof Class)) {
/* 301:388 */         return type;
/* 302:    */       }
/* 303:390 */       if ((type instanceof TypeVariable)) {
/* 304:391 */         return type;
/* 305:    */       }
/* 306:393 */       if ((type instanceof GenericArrayType))
/* 307:    */       {
/* 308:394 */         GenericArrayType arrayType = (GenericArrayType)type;
/* 309:395 */         return Types.newArrayType(capture(arrayType.getGenericComponentType()));
/* 310:    */       }
/* 311:397 */       if ((type instanceof ParameterizedType))
/* 312:    */       {
/* 313:398 */         ParameterizedType parameterizedType = (ParameterizedType)type;
/* 314:399 */         return Types.newParameterizedTypeWithOwner(captureNullable(parameterizedType.getOwnerType()), (Class)parameterizedType.getRawType(), capture(parameterizedType.getActualTypeArguments()));
/* 315:    */       }
/* 316:404 */       if ((type instanceof WildcardType))
/* 317:    */       {
/* 318:405 */         WildcardType wildcardType = (WildcardType)type;
/* 319:406 */         Type[] lowerBounds = wildcardType.getLowerBounds();
/* 320:407 */         if (lowerBounds.length == 0)
/* 321:    */         {
/* 322:408 */           Type[] upperBounds = wildcardType.getUpperBounds();
/* 323:409 */           String name = "capture#" + this.id.incrementAndGet() + "-of ? extends " + Joiner.on('&').join(upperBounds);
/* 324:    */           
/* 325:411 */           return Types.newArtificialTypeVariable(WildcardCapturer.class, name, wildcardType.getUpperBounds());
/* 326:    */         }
/* 327:415 */         return type;
/* 328:    */       }
/* 329:418 */       throw new AssertionError("must have been one of the known types");
/* 330:    */     }
/* 331:    */     
/* 332:    */     private Type captureNullable(@Nullable Type type)
/* 333:    */     {
/* 334:422 */       if (type == null) {
/* 335:423 */         return null;
/* 336:    */       }
/* 337:425 */       return capture(type);
/* 338:    */     }
/* 339:    */     
/* 340:    */     private Type[] capture(Type[] types)
/* 341:    */     {
/* 342:429 */       Type[] result = new Type[types.length];
/* 343:430 */       for (int i = 0; i < types.length; i++) {
/* 344:431 */         result[i] = capture(types[i]);
/* 345:    */       }
/* 346:433 */       return result;
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */   static final class TypeVariableKey
/* 351:    */   {
/* 352:    */     private final TypeVariable<?> var;
/* 353:    */     
/* 354:    */     TypeVariableKey(TypeVariable<?> var)
/* 355:    */     {
/* 356:455 */       this.var = ((TypeVariable)Preconditions.checkNotNull(var));
/* 357:    */     }
/* 358:    */     
/* 359:    */     public int hashCode()
/* 360:    */     {
/* 361:459 */       return Objects.hashCode(new Object[] { this.var.getGenericDeclaration(), this.var.getName() });
/* 362:    */     }
/* 363:    */     
/* 364:    */     public boolean equals(Object obj)
/* 365:    */     {
/* 366:463 */       if ((obj instanceof TypeVariableKey))
/* 367:    */       {
/* 368:464 */         TypeVariableKey that = (TypeVariableKey)obj;
/* 369:465 */         return equalsTypeVariable(that.var);
/* 370:    */       }
/* 371:467 */       return false;
/* 372:    */     }
/* 373:    */     
/* 374:    */     public String toString()
/* 375:    */     {
/* 376:472 */       return this.var.toString();
/* 377:    */     }
/* 378:    */     
/* 379:    */     static Object forLookup(Type t)
/* 380:    */     {
/* 381:477 */       if ((t instanceof TypeVariable)) {
/* 382:478 */         return new TypeVariableKey((TypeVariable)t);
/* 383:    */       }
/* 384:480 */       return null;
/* 385:    */     }
/* 386:    */     
/* 387:    */     boolean equalsType(Type type)
/* 388:    */     {
/* 389:489 */       if ((type instanceof TypeVariable)) {
/* 390:490 */         return equalsTypeVariable((TypeVariable)type);
/* 391:    */       }
/* 392:492 */       return false;
/* 393:    */     }
/* 394:    */     
/* 395:    */     private boolean equalsTypeVariable(TypeVariable<?> that)
/* 396:    */     {
/* 397:497 */       return (this.var.getGenericDeclaration().equals(that.getGenericDeclaration())) && (this.var.getName().equals(that.getName()));
/* 398:    */     }
/* 399:    */   }
/* 400:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.TypeResolver
 * JD-Core Version:    0.7.0.1
 */
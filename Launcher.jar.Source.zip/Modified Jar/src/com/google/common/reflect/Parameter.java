/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.collect.ImmutableList;
/*   6:    */ import java.lang.annotation.Annotation;
/*   7:    */ import java.lang.reflect.AnnotatedElement;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public final class Parameter
/*  12:    */   implements AnnotatedElement
/*  13:    */ {
/*  14:    */   private final Invokable<?, ?> declaration;
/*  15:    */   private final int position;
/*  16:    */   private final TypeToken<?> type;
/*  17:    */   private final ImmutableList<Annotation> annotations;
/*  18:    */   
/*  19:    */   Parameter(Invokable<?, ?> declaration, int position, TypeToken<?> type, Annotation[] annotations)
/*  20:    */   {
/*  21: 48 */     this.declaration = declaration;
/*  22: 49 */     this.position = position;
/*  23: 50 */     this.type = type;
/*  24: 51 */     this.annotations = ImmutableList.copyOf(annotations);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public TypeToken<?> getType()
/*  28:    */   {
/*  29: 56 */     return this.type;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Invokable<?, ?> getDeclaringInvokable()
/*  33:    */   {
/*  34: 61 */     return this.declaration;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType)
/*  38:    */   {
/*  39: 65 */     return getAnnotation(annotationType) != null;
/*  40:    */   }
/*  41:    */   
/*  42:    */   @Nullable
/*  43:    */   public <A extends Annotation> A getAnnotation(Class<A> annotationType)
/*  44:    */   {
/*  45: 71 */     Preconditions.checkNotNull(annotationType);
/*  46: 72 */     for (Annotation annotation : this.annotations) {
/*  47: 73 */       if (annotationType.isInstance(annotation)) {
/*  48: 74 */         return (Annotation)annotationType.cast(annotation);
/*  49:    */       }
/*  50:    */     }
/*  51: 77 */     return null;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Annotation[] getAnnotations()
/*  55:    */   {
/*  56: 81 */     return getDeclaredAnnotations();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Annotation[] getDeclaredAnnotations()
/*  60:    */   {
/*  61: 85 */     return (Annotation[])this.annotations.toArray(new Annotation[this.annotations.size()]);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean equals(@Nullable Object obj)
/*  65:    */   {
/*  66: 89 */     if ((obj instanceof Parameter))
/*  67:    */     {
/*  68: 90 */       Parameter that = (Parameter)obj;
/*  69: 91 */       return (this.position == that.position) && (this.declaration.equals(that.declaration));
/*  70:    */     }
/*  71: 93 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public int hashCode()
/*  75:    */   {
/*  76: 97 */     return this.position;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String toString()
/*  80:    */   {
/*  81:101 */     return this.type + " arg" + this.position;
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.reflect.Parameter
 * JD-Core Version:    0.7.0.1
 */
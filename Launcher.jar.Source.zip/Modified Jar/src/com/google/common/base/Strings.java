/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ public final class Strings
/*   9:    */ {
/*  10:    */   public static String nullToEmpty(@Nullable String string)
/*  11:    */   {
/*  12: 47 */     return string == null ? "" : string;
/*  13:    */   }
/*  14:    */   
/*  15:    */   @Nullable
/*  16:    */   public static String emptyToNull(@Nullable String string)
/*  17:    */   {
/*  18: 58 */     return isNullOrEmpty(string) ? null : string;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static boolean isNullOrEmpty(@Nullable String string)
/*  22:    */   {
/*  23: 75 */     return (string == null) || (string.length() == 0);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static String padStart(String string, int minLength, char padChar)
/*  27:    */   {
/*  28: 98 */     Preconditions.checkNotNull(string);
/*  29: 99 */     if (string.length() >= minLength) {
/*  30:100 */       return string;
/*  31:    */     }
/*  32:102 */     StringBuilder sb = new StringBuilder(minLength);
/*  33:103 */     for (int i = string.length(); i < minLength; i++) {
/*  34:104 */       sb.append(padChar);
/*  35:    */     }
/*  36:106 */     sb.append(string);
/*  37:107 */     return sb.toString();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static String padEnd(String string, int minLength, char padChar)
/*  41:    */   {
/*  42:130 */     Preconditions.checkNotNull(string);
/*  43:131 */     if (string.length() >= minLength) {
/*  44:132 */       return string;
/*  45:    */     }
/*  46:134 */     StringBuilder sb = new StringBuilder(minLength);
/*  47:135 */     sb.append(string);
/*  48:136 */     for (int i = string.length(); i < minLength; i++) {
/*  49:137 */       sb.append(padChar);
/*  50:    */     }
/*  51:139 */     return sb.toString();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static String repeat(String string, int count)
/*  55:    */   {
/*  56:154 */     Preconditions.checkNotNull(string);
/*  57:156 */     if (count <= 1)
/*  58:    */     {
/*  59:157 */       Preconditions.checkArgument(count >= 0, "invalid count: %s", new Object[] { Integer.valueOf(count) });
/*  60:158 */       return count == 0 ? "" : string;
/*  61:    */     }
/*  62:162 */     int len = string.length();
/*  63:163 */     long longSize = len * count;
/*  64:164 */     int size = (int)longSize;
/*  65:165 */     if (size != longSize) {
/*  66:166 */       throw new ArrayIndexOutOfBoundsException("Required array size too large: " + longSize);
/*  67:    */     }
/*  68:170 */     char[] array = new char[size];
/*  69:171 */     string.getChars(0, len, array, 0);
/*  70:173 */     for (int n = len; n < size - n; n <<= 1) {
/*  71:174 */       System.arraycopy(array, 0, array, n, n);
/*  72:    */     }
/*  73:176 */     System.arraycopy(array, 0, array, n, size - n);
/*  74:177 */     return new String(array);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static String commonPrefix(CharSequence a, CharSequence b)
/*  78:    */   {
/*  79:189 */     Preconditions.checkNotNull(a);
/*  80:190 */     Preconditions.checkNotNull(b);
/*  81:    */     
/*  82:192 */     int maxPrefixLength = Math.min(a.length(), b.length());
/*  83:193 */     int p = 0;
/*  84:194 */     while ((p < maxPrefixLength) && (a.charAt(p) == b.charAt(p))) {
/*  85:195 */       p++;
/*  86:    */     }
/*  87:197 */     if ((validSurrogatePairAt(a, p - 1)) || (validSurrogatePairAt(b, p - 1))) {
/*  88:198 */       p--;
/*  89:    */     }
/*  90:200 */     return a.subSequence(0, p).toString();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static String commonSuffix(CharSequence a, CharSequence b)
/*  94:    */   {
/*  95:212 */     Preconditions.checkNotNull(a);
/*  96:213 */     Preconditions.checkNotNull(b);
/*  97:    */     
/*  98:215 */     int maxSuffixLength = Math.min(a.length(), b.length());
/*  99:216 */     int s = 0;
/* 100:218 */     while ((s < maxSuffixLength) && (a.charAt(a.length() - s - 1) == b.charAt(b.length() - s - 1))) {
/* 101:219 */       s++;
/* 102:    */     }
/* 103:221 */     if ((validSurrogatePairAt(a, a.length() - s - 1)) || (validSurrogatePairAt(b, b.length() - s - 1))) {
/* 104:223 */       s--;
/* 105:    */     }
/* 106:225 */     return a.subSequence(a.length() - s, a.length()).toString();
/* 107:    */   }
/* 108:    */   
/* 109:    */   @VisibleForTesting
/* 110:    */   static boolean validSurrogatePairAt(CharSequence string, int index)
/* 111:    */   {
/* 112:234 */     return (index >= 0) && (index <= string.length() - 2) && (Character.isHighSurrogate(string.charAt(index))) && (Character.isLowSurrogate(string.charAt(index + 1)));
/* 113:    */   }
/* 114:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Strings
 * JD-Core Version:    0.7.0.1
 */
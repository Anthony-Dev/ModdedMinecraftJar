/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class Equivalence<T>
/*  10:    */ {
/*  11:    */   public final boolean equivalent(@Nullable T a, @Nullable T b)
/*  12:    */   {
/*  13: 65 */     if (a == b) {
/*  14: 66 */       return true;
/*  15:    */     }
/*  16: 68 */     if ((a == null) || (b == null)) {
/*  17: 69 */       return false;
/*  18:    */     }
/*  19: 71 */     return doEquivalent(a, b);
/*  20:    */   }
/*  21:    */   
/*  22:    */   protected abstract boolean doEquivalent(T paramT1, T paramT2);
/*  23:    */   
/*  24:    */   public final int hash(@Nullable T t)
/*  25:    */   {
/*  26:101 */     if (t == null) {
/*  27:102 */       return 0;
/*  28:    */     }
/*  29:104 */     return doHash(t);
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected abstract int doHash(T paramT);
/*  33:    */   
/*  34:    */   public final <F> Equivalence<F> onResultOf(Function<F, ? extends T> function)
/*  35:    */   {
/*  36:140 */     return new FunctionalEquivalence(function, this);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public final <S extends T> Wrapper<S> wrap(@Nullable S reference)
/*  40:    */   {
/*  41:151 */     return new Wrapper(this, reference, null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static final class Wrapper<T>
/*  45:    */     implements Serializable
/*  46:    */   {
/*  47:    */     private final Equivalence<? super T> equivalence;
/*  48:    */     @Nullable
/*  49:    */     private final T reference;
/*  50:    */     private static final long serialVersionUID = 0L;
/*  51:    */     
/*  52:    */     private Wrapper(Equivalence<? super T> equivalence, @Nullable T reference)
/*  53:    */     {
/*  54:177 */       this.equivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/*  55:178 */       this.reference = reference;
/*  56:    */     }
/*  57:    */     
/*  58:    */     @Nullable
/*  59:    */     public T get()
/*  60:    */     {
/*  61:183 */       return this.reference;
/*  62:    */     }
/*  63:    */     
/*  64:    */     public boolean equals(@Nullable Object obj)
/*  65:    */     {
/*  66:192 */       if (obj == this) {
/*  67:193 */         return true;
/*  68:    */       }
/*  69:195 */       if ((obj instanceof Wrapper))
/*  70:    */       {
/*  71:196 */         Wrapper<?> that = (Wrapper)obj;
/*  72:198 */         if (this.equivalence.equals(that.equivalence))
/*  73:    */         {
/*  74:204 */           Equivalence<Object> equivalence = this.equivalence;
/*  75:205 */           return equivalence.equivalent(this.reference, that.reference);
/*  76:    */         }
/*  77:    */       }
/*  78:208 */       return false;
/*  79:    */     }
/*  80:    */     
/*  81:    */     public int hashCode()
/*  82:    */     {
/*  83:215 */       return this.equivalence.hash(this.reference);
/*  84:    */     }
/*  85:    */     
/*  86:    */     public String toString()
/*  87:    */     {
/*  88:223 */       return this.equivalence + ".wrap(" + this.reference + ")";
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   @GwtCompatible(serializable=true)
/*  93:    */   public final <S extends T> Equivalence<Iterable<S>> pairwise()
/*  94:    */   {
/*  95:244 */     return new PairwiseEquivalence(this);
/*  96:    */   }
/*  97:    */   
/*  98:    */   @Beta
/*  99:    */   public final Predicate<T> equivalentTo(@Nullable T target)
/* 100:    */   {
/* 101:255 */     return new EquivalentToPredicate(this, target);
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static final class EquivalentToPredicate<T>
/* 105:    */     implements Predicate<T>, Serializable
/* 106:    */   {
/* 107:    */     private final Equivalence<T> equivalence;
/* 108:    */     @Nullable
/* 109:    */     private final T target;
/* 110:    */     private static final long serialVersionUID = 0L;
/* 111:    */     
/* 112:    */     EquivalentToPredicate(Equivalence<T> equivalence, @Nullable T target)
/* 113:    */     {
/* 114:264 */       this.equivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 115:265 */       this.target = target;
/* 116:    */     }
/* 117:    */     
/* 118:    */     public boolean apply(@Nullable T input)
/* 119:    */     {
/* 120:269 */       return this.equivalence.equivalent(input, this.target);
/* 121:    */     }
/* 122:    */     
/* 123:    */     public boolean equals(@Nullable Object obj)
/* 124:    */     {
/* 125:273 */       if (this == obj) {
/* 126:274 */         return true;
/* 127:    */       }
/* 128:276 */       if ((obj instanceof EquivalentToPredicate))
/* 129:    */       {
/* 130:277 */         EquivalentToPredicate<?> that = (EquivalentToPredicate)obj;
/* 131:278 */         return (this.equivalence.equals(that.equivalence)) && (Objects.equal(this.target, that.target));
/* 132:    */       }
/* 133:281 */       return false;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public int hashCode()
/* 137:    */     {
/* 138:285 */       return Objects.hashCode(new Object[] { this.equivalence, this.target });
/* 139:    */     }
/* 140:    */     
/* 141:    */     public String toString()
/* 142:    */     {
/* 143:289 */       return this.equivalence + ".equivalentTo(" + this.target + ")";
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static Equivalence<Object> equals()
/* 148:    */   {
/* 149:306 */     return Equals.INSTANCE;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static Equivalence<Object> identity()
/* 153:    */   {
/* 154:318 */     return Identity.INSTANCE;
/* 155:    */   }
/* 156:    */   
/* 157:    */   static final class Equals
/* 158:    */     extends Equivalence<Object>
/* 159:    */     implements Serializable
/* 160:    */   {
/* 161:324 */     static final Equals INSTANCE = new Equals();
/* 162:    */     private static final long serialVersionUID = 1L;
/* 163:    */     
/* 164:    */     protected boolean doEquivalent(Object a, Object b)
/* 165:    */     {
/* 166:327 */       return a.equals(b);
/* 167:    */     }
/* 168:    */     
/* 169:    */     public int doHash(Object o)
/* 170:    */     {
/* 171:330 */       return o.hashCode();
/* 172:    */     }
/* 173:    */     
/* 174:    */     private Object readResolve()
/* 175:    */     {
/* 176:334 */       return INSTANCE;
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   static final class Identity
/* 181:    */     extends Equivalence<Object>
/* 182:    */     implements Serializable
/* 183:    */   {
/* 184:342 */     static final Identity INSTANCE = new Identity();
/* 185:    */     private static final long serialVersionUID = 1L;
/* 186:    */     
/* 187:    */     protected boolean doEquivalent(Object a, Object b)
/* 188:    */     {
/* 189:345 */       return false;
/* 190:    */     }
/* 191:    */     
/* 192:    */     protected int doHash(Object o)
/* 193:    */     {
/* 194:349 */       return System.identityHashCode(o);
/* 195:    */     }
/* 196:    */     
/* 197:    */     private Object readResolve()
/* 198:    */     {
/* 199:353 */       return INSTANCE;
/* 200:    */     }
/* 201:    */   }
/* 202:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Equivalence
 * JD-Core Version:    0.7.0.1
 */
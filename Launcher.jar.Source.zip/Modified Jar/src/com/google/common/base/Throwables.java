/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.io.PrintWriter;
/*   5:    */ import java.io.StringWriter;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.List;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ public final class Throwables
/*  12:    */ {
/*  13:    */   public static <X extends Throwable> void propagateIfInstanceOf(@Nullable Throwable throwable, Class<X> declaredType)
/*  14:    */     throws Throwable
/*  15:    */   {
/*  16: 63 */     if ((throwable != null) && (declaredType.isInstance(throwable))) {
/*  17: 64 */       throw ((Throwable)declaredType.cast(throwable));
/*  18:    */     }
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static void propagateIfPossible(@Nullable Throwable throwable)
/*  22:    */   {
/*  23: 83 */     propagateIfInstanceOf(throwable, Error.class);
/*  24: 84 */     propagateIfInstanceOf(throwable, RuntimeException.class);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <X extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X> declaredType)
/*  28:    */     throws Throwable
/*  29:    */   {
/*  30:108 */     propagateIfInstanceOf(throwable, declaredType);
/*  31:109 */     propagateIfPossible(throwable);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <X1 extends Throwable, X2 extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X1> declaredType1, Class<X2> declaredType2)
/*  35:    */     throws Throwable, Throwable
/*  36:    */   {
/*  37:129 */     Preconditions.checkNotNull(declaredType2);
/*  38:130 */     propagateIfInstanceOf(throwable, declaredType1);
/*  39:131 */     propagateIfPossible(throwable, declaredType2);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static RuntimeException propagate(Throwable throwable)
/*  43:    */   {
/*  44:159 */     propagateIfPossible((Throwable)Preconditions.checkNotNull(throwable));
/*  45:160 */     throw new RuntimeException(throwable);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static Throwable getRootCause(Throwable throwable)
/*  49:    */   {
/*  50:    */     Throwable cause;
/*  51:174 */     while ((cause = throwable.getCause()) != null) {
/*  52:175 */       throwable = cause;
/*  53:    */     }
/*  54:177 */     return throwable;
/*  55:    */   }
/*  56:    */   
/*  57:    */   @Beta
/*  58:    */   public static List<Throwable> getCausalChain(Throwable throwable)
/*  59:    */   {
/*  60:199 */     Preconditions.checkNotNull(throwable);
/*  61:200 */     List<Throwable> causes = new ArrayList(4);
/*  62:201 */     while (throwable != null)
/*  63:    */     {
/*  64:202 */       causes.add(throwable);
/*  65:203 */       throwable = throwable.getCause();
/*  66:    */     }
/*  67:205 */     return Collections.unmodifiableList(causes);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static String getStackTraceAsString(Throwable throwable)
/*  71:    */   {
/*  72:216 */     StringWriter stringWriter = new StringWriter();
/*  73:217 */     throwable.printStackTrace(new PrintWriter(stringWriter));
/*  74:218 */     return stringWriter.toString();
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Throwables
 * JD-Core Version:    0.7.0.1
 */
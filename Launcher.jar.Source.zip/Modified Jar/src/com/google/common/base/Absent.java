/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Collections;
/*  5:   */ import java.util.Set;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ final class Absent<T>
/* 10:   */   extends Optional<T>
/* 11:   */ {
/* 12:33 */   static final Absent<Object> INSTANCE = new Absent();
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   static <T> Optional<T> withType()
/* 16:   */   {
/* 17:37 */     return INSTANCE;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean isPresent()
/* 21:   */   {
/* 22:43 */     return false;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public T get()
/* 26:   */   {
/* 27:47 */     throw new IllegalStateException("Optional.get() cannot be called on an absent value");
/* 28:   */   }
/* 29:   */   
/* 30:   */   public T or(T defaultValue)
/* 31:   */   {
/* 32:51 */     return Preconditions.checkNotNull(defaultValue, "use Optional.orNull() instead of Optional.or(null)");
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Optional<T> or(Optional<? extends T> secondChoice)
/* 36:   */   {
/* 37:56 */     return (Optional)Preconditions.checkNotNull(secondChoice);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public T or(Supplier<? extends T> supplier)
/* 41:   */   {
/* 42:60 */     return Preconditions.checkNotNull(supplier.get(), "use Optional.orNull() instead of a Supplier that returns null");
/* 43:   */   }
/* 44:   */   
/* 45:   */   @Nullable
/* 46:   */   public T orNull()
/* 47:   */   {
/* 48:65 */     return null;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public Set<T> asSet()
/* 52:   */   {
/* 53:69 */     return Collections.emptySet();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public <V> Optional<V> transform(Function<? super T, V> function)
/* 57:   */   {
/* 58:73 */     Preconditions.checkNotNull(function);
/* 59:74 */     return Optional.absent();
/* 60:   */   }
/* 61:   */   
/* 62:   */   public boolean equals(@Nullable Object object)
/* 63:   */   {
/* 64:78 */     return object == this;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int hashCode()
/* 68:   */   {
/* 69:82 */     return 1502476572;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public String toString()
/* 73:   */   {
/* 74:86 */     return "Optional.absent()";
/* 75:   */   }
/* 76:   */   
/* 77:   */   private Object readResolve()
/* 78:   */   {
/* 79:90 */     return INSTANCE;
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Absent
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ 
/*  6:   */ @Beta
/*  7:   */ @GwtCompatible
/*  8:   */ public abstract class Ticker
/*  9:   */ {
/* 10:   */   public abstract long read();
/* 11:   */   
/* 12:   */   public static Ticker systemTicker()
/* 13:   */   {
/* 14:54 */     return SYSTEM_TICKER;
/* 15:   */   }
/* 16:   */   
/* 17:57 */   private static final Ticker SYSTEM_TICKER = new Ticker()
/* 18:   */   {
/* 19:   */     public long read()
/* 20:   */     {
/* 21:60 */       return Platform.systemNanoTime();
/* 22:   */     }
/* 23:   */   };
/* 24:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Ticker
 * JD-Core Version:    0.7.0.1
 */
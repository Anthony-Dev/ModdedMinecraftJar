/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.regex.Matcher;
/*  12:    */ import java.util.regex.Pattern;
/*  13:    */ import javax.annotation.Nullable;
/*  14:    */ 
/*  15:    */ @GwtCompatible(emulated=true)
/*  16:    */ public final class Predicates
/*  17:    */ {
/*  18:    */   @GwtCompatible(serializable=true)
/*  19:    */   public static <T> Predicate<T> alwaysTrue()
/*  20:    */   {
/*  21: 59 */     return ObjectPredicate.ALWAYS_TRUE.withNarrowedType();
/*  22:    */   }
/*  23:    */   
/*  24:    */   @GwtCompatible(serializable=true)
/*  25:    */   public static <T> Predicate<T> alwaysFalse()
/*  26:    */   {
/*  27: 67 */     return ObjectPredicate.ALWAYS_FALSE.withNarrowedType();
/*  28:    */   }
/*  29:    */   
/*  30:    */   @GwtCompatible(serializable=true)
/*  31:    */   public static <T> Predicate<T> isNull()
/*  32:    */   {
/*  33: 76 */     return ObjectPredicate.IS_NULL.withNarrowedType();
/*  34:    */   }
/*  35:    */   
/*  36:    */   @GwtCompatible(serializable=true)
/*  37:    */   public static <T> Predicate<T> notNull()
/*  38:    */   {
/*  39: 85 */     return ObjectPredicate.NOT_NULL.withNarrowedType();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static <T> Predicate<T> not(Predicate<T> predicate)
/*  43:    */   {
/*  44: 93 */     return new NotPredicate(predicate);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> components)
/*  48:    */   {
/*  49:107 */     return new AndPredicate(defensiveCopy(components), null);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <T> Predicate<T> and(Predicate<? super T>... components)
/*  53:    */   {
/*  54:120 */     return new AndPredicate(defensiveCopy(components), null);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static <T> Predicate<T> and(Predicate<? super T> first, Predicate<? super T> second)
/*  58:    */   {
/*  59:131 */     return new AndPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> components)
/*  63:    */   {
/*  64:146 */     return new OrPredicate(defensiveCopy(components), null);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <T> Predicate<T> or(Predicate<? super T>... components)
/*  68:    */   {
/*  69:159 */     return new OrPredicate(defensiveCopy(components), null);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static <T> Predicate<T> or(Predicate<? super T> first, Predicate<? super T> second)
/*  73:    */   {
/*  74:170 */     return new OrPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static <T> Predicate<T> equalTo(@Nullable T target)
/*  78:    */   {
/*  79:179 */     return target == null ? isNull() : new IsEqualToPredicate(target, null);
/*  80:    */   }
/*  81:    */   
/*  82:    */   @GwtIncompatible("Class.isInstance")
/*  83:    */   public static Predicate<Object> instanceOf(Class<?> clazz)
/*  84:    */   {
/*  85:201 */     return new InstanceOfPredicate(clazz, null);
/*  86:    */   }
/*  87:    */   
/*  88:    */   @GwtIncompatible("Class.isAssignableFrom")
/*  89:    */   @Beta
/*  90:    */   public static Predicate<Class<?>> assignableFrom(Class<?> clazz)
/*  91:    */   {
/*  92:214 */     return new AssignableFromPredicate(clazz, null);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static <T> Predicate<T> in(Collection<? extends T> target)
/*  96:    */   {
/*  97:231 */     return new InPredicate(target, null);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static <A, B> Predicate<A> compose(Predicate<B> predicate, Function<A, ? extends B> function)
/* 101:    */   {
/* 102:242 */     return new CompositionPredicate(predicate, function, null);
/* 103:    */   }
/* 104:    */   
/* 105:    */   @GwtIncompatible("java.util.regex.Pattern")
/* 106:    */   public static Predicate<CharSequence> containsPattern(String pattern)
/* 107:    */   {
/* 108:256 */     return new ContainsPatternFromStringPredicate(pattern);
/* 109:    */   }
/* 110:    */   
/* 111:    */   @GwtIncompatible("java.util.regex.Pattern")
/* 112:    */   public static Predicate<CharSequence> contains(Pattern pattern)
/* 113:    */   {
/* 114:269 */     return new ContainsPatternPredicate(pattern);
/* 115:    */   }
/* 116:    */   
/* 117:    */   static abstract enum ObjectPredicate
/* 118:    */     implements Predicate<Object>
/* 119:    */   {
/* 120:277 */     ALWAYS_TRUE,  ALWAYS_FALSE,  IS_NULL,  NOT_NULL;
/* 121:    */     
/* 122:    */     private ObjectPredicate() {}
/* 123:    */     
/* 124:    */     <T> Predicate<T> withNarrowedType()
/* 125:    */     {
/* 126:315 */       return this;
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static class NotPredicate<T>
/* 131:    */     implements Predicate<T>, Serializable
/* 132:    */   {
/* 133:    */     final Predicate<T> predicate;
/* 134:    */     private static final long serialVersionUID = 0L;
/* 135:    */     
/* 136:    */     NotPredicate(Predicate<T> predicate)
/* 137:    */     {
/* 138:324 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/* 139:    */     }
/* 140:    */     
/* 141:    */     public boolean apply(@Nullable T t)
/* 142:    */     {
/* 143:328 */       return !this.predicate.apply(t);
/* 144:    */     }
/* 145:    */     
/* 146:    */     public int hashCode()
/* 147:    */     {
/* 148:331 */       return this.predicate.hashCode() ^ 0xFFFFFFFF;
/* 149:    */     }
/* 150:    */     
/* 151:    */     public boolean equals(@Nullable Object obj)
/* 152:    */     {
/* 153:334 */       if ((obj instanceof NotPredicate))
/* 154:    */       {
/* 155:335 */         NotPredicate<?> that = (NotPredicate)obj;
/* 156:336 */         return this.predicate.equals(that.predicate);
/* 157:    */       }
/* 158:338 */       return false;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public String toString()
/* 162:    */     {
/* 163:341 */       return "Predicates.not(" + this.predicate.toString() + ")";
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:346 */   private static final Joiner COMMA_JOINER = Joiner.on(',');
/* 168:    */   
/* 169:    */   private static class AndPredicate<T>
/* 170:    */     implements Predicate<T>, Serializable
/* 171:    */   {
/* 172:    */     private final List<? extends Predicate<? super T>> components;
/* 173:    */     private static final long serialVersionUID = 0L;
/* 174:    */     
/* 175:    */     private AndPredicate(List<? extends Predicate<? super T>> components)
/* 176:    */     {
/* 177:353 */       this.components = components;
/* 178:    */     }
/* 179:    */     
/* 180:    */     public boolean apply(@Nullable T t)
/* 181:    */     {
/* 182:358 */       for (int i = 0; i < this.components.size(); i++) {
/* 183:359 */         if (!((Predicate)this.components.get(i)).apply(t)) {
/* 184:360 */           return false;
/* 185:    */         }
/* 186:    */       }
/* 187:363 */       return true;
/* 188:    */     }
/* 189:    */     
/* 190:    */     public int hashCode()
/* 191:    */     {
/* 192:367 */       return this.components.hashCode() + 306654252;
/* 193:    */     }
/* 194:    */     
/* 195:    */     public boolean equals(@Nullable Object obj)
/* 196:    */     {
/* 197:370 */       if ((obj instanceof AndPredicate))
/* 198:    */       {
/* 199:371 */         AndPredicate<?> that = (AndPredicate)obj;
/* 200:372 */         return this.components.equals(that.components);
/* 201:    */       }
/* 202:374 */       return false;
/* 203:    */     }
/* 204:    */     
/* 205:    */     public String toString()
/* 206:    */     {
/* 207:377 */       return "Predicates.and(" + Predicates.COMMA_JOINER.join(this.components) + ")";
/* 208:    */     }
/* 209:    */   }
/* 210:    */   
/* 211:    */   private static class OrPredicate<T>
/* 212:    */     implements Predicate<T>, Serializable
/* 213:    */   {
/* 214:    */     private final List<? extends Predicate<? super T>> components;
/* 215:    */     private static final long serialVersionUID = 0L;
/* 216:    */     
/* 217:    */     private OrPredicate(List<? extends Predicate<? super T>> components)
/* 218:    */     {
/* 219:387 */       this.components = components;
/* 220:    */     }
/* 221:    */     
/* 222:    */     public boolean apply(@Nullable T t)
/* 223:    */     {
/* 224:392 */       for (int i = 0; i < this.components.size(); i++) {
/* 225:393 */         if (((Predicate)this.components.get(i)).apply(t)) {
/* 226:394 */           return true;
/* 227:    */         }
/* 228:    */       }
/* 229:397 */       return false;
/* 230:    */     }
/* 231:    */     
/* 232:    */     public int hashCode()
/* 233:    */     {
/* 234:401 */       return this.components.hashCode() + 87855567;
/* 235:    */     }
/* 236:    */     
/* 237:    */     public boolean equals(@Nullable Object obj)
/* 238:    */     {
/* 239:404 */       if ((obj instanceof OrPredicate))
/* 240:    */       {
/* 241:405 */         OrPredicate<?> that = (OrPredicate)obj;
/* 242:406 */         return this.components.equals(that.components);
/* 243:    */       }
/* 244:408 */       return false;
/* 245:    */     }
/* 246:    */     
/* 247:    */     public String toString()
/* 248:    */     {
/* 249:411 */       return "Predicates.or(" + Predicates.COMMA_JOINER.join(this.components) + ")";
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   private static class IsEqualToPredicate<T>
/* 254:    */     implements Predicate<T>, Serializable
/* 255:    */   {
/* 256:    */     private final T target;
/* 257:    */     private static final long serialVersionUID = 0L;
/* 258:    */     
/* 259:    */     private IsEqualToPredicate(T target)
/* 260:    */     {
/* 261:422 */       this.target = target;
/* 262:    */     }
/* 263:    */     
/* 264:    */     public boolean apply(T t)
/* 265:    */     {
/* 266:426 */       return this.target.equals(t);
/* 267:    */     }
/* 268:    */     
/* 269:    */     public int hashCode()
/* 270:    */     {
/* 271:429 */       return this.target.hashCode();
/* 272:    */     }
/* 273:    */     
/* 274:    */     public boolean equals(@Nullable Object obj)
/* 275:    */     {
/* 276:432 */       if ((obj instanceof IsEqualToPredicate))
/* 277:    */       {
/* 278:433 */         IsEqualToPredicate<?> that = (IsEqualToPredicate)obj;
/* 279:434 */         return this.target.equals(that.target);
/* 280:    */       }
/* 281:436 */       return false;
/* 282:    */     }
/* 283:    */     
/* 284:    */     public String toString()
/* 285:    */     {
/* 286:439 */       return "Predicates.equalTo(" + this.target + ")";
/* 287:    */     }
/* 288:    */   }
/* 289:    */   
/* 290:    */   @GwtIncompatible("Class.isInstance")
/* 291:    */   private static class InstanceOfPredicate
/* 292:    */     implements Predicate<Object>, Serializable
/* 293:    */   {
/* 294:    */     private final Class<?> clazz;
/* 295:    */     private static final long serialVersionUID = 0L;
/* 296:    */     
/* 297:    */     private InstanceOfPredicate(Class<?> clazz)
/* 298:    */     {
/* 299:451 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 300:    */     }
/* 301:    */     
/* 302:    */     public boolean apply(@Nullable Object o)
/* 303:    */     {
/* 304:455 */       return this.clazz.isInstance(o);
/* 305:    */     }
/* 306:    */     
/* 307:    */     public int hashCode()
/* 308:    */     {
/* 309:458 */       return this.clazz.hashCode();
/* 310:    */     }
/* 311:    */     
/* 312:    */     public boolean equals(@Nullable Object obj)
/* 313:    */     {
/* 314:461 */       if ((obj instanceof InstanceOfPredicate))
/* 315:    */       {
/* 316:462 */         InstanceOfPredicate that = (InstanceOfPredicate)obj;
/* 317:463 */         return this.clazz == that.clazz;
/* 318:    */       }
/* 319:465 */       return false;
/* 320:    */     }
/* 321:    */     
/* 322:    */     public String toString()
/* 323:    */     {
/* 324:468 */       return "Predicates.instanceOf(" + this.clazz.getName() + ")";
/* 325:    */     }
/* 326:    */   }
/* 327:    */   
/* 328:    */   @GwtIncompatible("Class.isAssignableFrom")
/* 329:    */   private static class AssignableFromPredicate
/* 330:    */     implements Predicate<Class<?>>, Serializable
/* 331:    */   {
/* 332:    */     private final Class<?> clazz;
/* 333:    */     private static final long serialVersionUID = 0L;
/* 334:    */     
/* 335:    */     private AssignableFromPredicate(Class<?> clazz)
/* 336:    */     {
/* 337:480 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 338:    */     }
/* 339:    */     
/* 340:    */     public boolean apply(Class<?> input)
/* 341:    */     {
/* 342:484 */       return this.clazz.isAssignableFrom(input);
/* 343:    */     }
/* 344:    */     
/* 345:    */     public int hashCode()
/* 346:    */     {
/* 347:487 */       return this.clazz.hashCode();
/* 348:    */     }
/* 349:    */     
/* 350:    */     public boolean equals(@Nullable Object obj)
/* 351:    */     {
/* 352:490 */       if ((obj instanceof AssignableFromPredicate))
/* 353:    */       {
/* 354:491 */         AssignableFromPredicate that = (AssignableFromPredicate)obj;
/* 355:492 */         return this.clazz == that.clazz;
/* 356:    */       }
/* 357:494 */       return false;
/* 358:    */     }
/* 359:    */     
/* 360:    */     public String toString()
/* 361:    */     {
/* 362:497 */       return "Predicates.assignableFrom(" + this.clazz.getName() + ")";
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   private static class InPredicate<T>
/* 367:    */     implements Predicate<T>, Serializable
/* 368:    */   {
/* 369:    */     private final Collection<?> target;
/* 370:    */     private static final long serialVersionUID = 0L;
/* 371:    */     
/* 372:    */     private InPredicate(Collection<?> target)
/* 373:    */     {
/* 374:507 */       this.target = ((Collection)Preconditions.checkNotNull(target));
/* 375:    */     }
/* 376:    */     
/* 377:    */     public boolean apply(@Nullable T t)
/* 378:    */     {
/* 379:    */       try
/* 380:    */       {
/* 381:513 */         return this.target.contains(t);
/* 382:    */       }
/* 383:    */       catch (NullPointerException e)
/* 384:    */       {
/* 385:515 */         return false;
/* 386:    */       }
/* 387:    */       catch (ClassCastException e) {}
/* 388:517 */       return false;
/* 389:    */     }
/* 390:    */     
/* 391:    */     public boolean equals(@Nullable Object obj)
/* 392:    */     {
/* 393:522 */       if ((obj instanceof InPredicate))
/* 394:    */       {
/* 395:523 */         InPredicate<?> that = (InPredicate)obj;
/* 396:524 */         return this.target.equals(that.target);
/* 397:    */       }
/* 398:526 */       return false;
/* 399:    */     }
/* 400:    */     
/* 401:    */     public int hashCode()
/* 402:    */     {
/* 403:530 */       return this.target.hashCode();
/* 404:    */     }
/* 405:    */     
/* 406:    */     public String toString()
/* 407:    */     {
/* 408:534 */       return "Predicates.in(" + this.target + ")";
/* 409:    */     }
/* 410:    */   }
/* 411:    */   
/* 412:    */   private static class CompositionPredicate<A, B>
/* 413:    */     implements Predicate<A>, Serializable
/* 414:    */   {
/* 415:    */     final Predicate<B> p;
/* 416:    */     final Function<A, ? extends B> f;
/* 417:    */     private static final long serialVersionUID = 0L;
/* 418:    */     
/* 419:    */     private CompositionPredicate(Predicate<B> p, Function<A, ? extends B> f)
/* 420:    */     {
/* 421:546 */       this.p = ((Predicate)Preconditions.checkNotNull(p));
/* 422:547 */       this.f = ((Function)Preconditions.checkNotNull(f));
/* 423:    */     }
/* 424:    */     
/* 425:    */     public boolean apply(@Nullable A a)
/* 426:    */     {
/* 427:552 */       return this.p.apply(this.f.apply(a));
/* 428:    */     }
/* 429:    */     
/* 430:    */     public boolean equals(@Nullable Object obj)
/* 431:    */     {
/* 432:556 */       if ((obj instanceof CompositionPredicate))
/* 433:    */       {
/* 434:557 */         CompositionPredicate<?, ?> that = (CompositionPredicate)obj;
/* 435:558 */         return (this.f.equals(that.f)) && (this.p.equals(that.p));
/* 436:    */       }
/* 437:560 */       return false;
/* 438:    */     }
/* 439:    */     
/* 440:    */     public int hashCode()
/* 441:    */     {
/* 442:564 */       return this.f.hashCode() ^ this.p.hashCode();
/* 443:    */     }
/* 444:    */     
/* 445:    */     public String toString()
/* 446:    */     {
/* 447:568 */       return this.p.toString() + "(" + this.f.toString() + ")";
/* 448:    */     }
/* 449:    */   }
/* 450:    */   
/* 451:    */   @GwtIncompatible("Only used by other GWT-incompatible code.")
/* 452:    */   private static class ContainsPatternPredicate
/* 453:    */     implements Predicate<CharSequence>, Serializable
/* 454:    */   {
/* 455:    */     final Pattern pattern;
/* 456:    */     private static final long serialVersionUID = 0L;
/* 457:    */     
/* 458:    */     ContainsPatternPredicate(Pattern pattern)
/* 459:    */     {
/* 460:581 */       this.pattern = ((Pattern)Preconditions.checkNotNull(pattern));
/* 461:    */     }
/* 462:    */     
/* 463:    */     public boolean apply(CharSequence t)
/* 464:    */     {
/* 465:586 */       return this.pattern.matcher(t).find();
/* 466:    */     }
/* 467:    */     
/* 468:    */     public int hashCode()
/* 469:    */     {
/* 470:593 */       return Objects.hashCode(new Object[] { this.pattern.pattern(), Integer.valueOf(this.pattern.flags()) });
/* 471:    */     }
/* 472:    */     
/* 473:    */     public boolean equals(@Nullable Object obj)
/* 474:    */     {
/* 475:597 */       if ((obj instanceof ContainsPatternPredicate))
/* 476:    */       {
/* 477:598 */         ContainsPatternPredicate that = (ContainsPatternPredicate)obj;
/* 478:    */         
/* 479:    */ 
/* 480:    */ 
/* 481:602 */         return (Objects.equal(this.pattern.pattern(), that.pattern.pattern())) && (Objects.equal(Integer.valueOf(this.pattern.flags()), Integer.valueOf(that.pattern.flags())));
/* 482:    */       }
/* 483:605 */       return false;
/* 484:    */     }
/* 485:    */     
/* 486:    */     public String toString()
/* 487:    */     {
/* 488:609 */       String patternString = Objects.toStringHelper(this.pattern).add("pattern", this.pattern.pattern()).add("pattern.flags", this.pattern.flags()).toString();
/* 489:    */       
/* 490:    */ 
/* 491:    */ 
/* 492:613 */       return "Predicates.contains(" + patternString + ")";
/* 493:    */     }
/* 494:    */   }
/* 495:    */   
/* 496:    */   @GwtIncompatible("Only used by other GWT-incompatible code.")
/* 497:    */   private static class ContainsPatternFromStringPredicate
/* 498:    */     extends Predicates.ContainsPatternPredicate
/* 499:    */   {
/* 500:    */     private static final long serialVersionUID = 0L;
/* 501:    */     
/* 502:    */     ContainsPatternFromStringPredicate(String string)
/* 503:    */     {
/* 504:625 */       super();
/* 505:    */     }
/* 506:    */     
/* 507:    */     public String toString()
/* 508:    */     {
/* 509:629 */       return "Predicates.containsPattern(" + this.pattern.pattern() + ")";
/* 510:    */     }
/* 511:    */   }
/* 512:    */   
/* 513:    */   private static <T> List<Predicate<? super T>> asList(Predicate<? super T> first, Predicate<? super T> second)
/* 514:    */   {
/* 515:638 */     return Arrays.asList(new Predicate[] { first, second });
/* 516:    */   }
/* 517:    */   
/* 518:    */   private static <T> List<T> defensiveCopy(T... array)
/* 519:    */   {
/* 520:642 */     return defensiveCopy(Arrays.asList(array));
/* 521:    */   }
/* 522:    */   
/* 523:    */   static <T> List<T> defensiveCopy(Iterable<T> iterable)
/* 524:    */   {
/* 525:646 */     ArrayList<T> list = new ArrayList();
/* 526:647 */     for (T element : iterable) {
/* 527:648 */       list.add(Preconditions.checkNotNull(element));
/* 528:    */     }
/* 529:650 */     return list;
/* 530:    */   }
/* 531:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Predicates
 * JD-Core Version:    0.7.0.1
 */
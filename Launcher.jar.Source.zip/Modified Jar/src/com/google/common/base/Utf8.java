/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ 
/*   6:    */ @Beta
/*   7:    */ @GwtCompatible
/*   8:    */ public final class Utf8
/*   9:    */ {
/*  10:    */   public static int encodedLength(CharSequence sequence)
/*  11:    */   {
/*  12: 50 */     int utf16Length = sequence.length();
/*  13: 51 */     int utf8Length = utf16Length;
/*  14: 52 */     int i = 0;
/*  15: 55 */     while ((i < utf16Length) && (sequence.charAt(i) < '')) {
/*  16: 56 */       i++;
/*  17:    */     }
/*  18: 60 */     for (; i < utf16Length; i++)
/*  19:    */     {
/*  20: 61 */       char c = sequence.charAt(i);
/*  21: 62 */       if (c < 'ࠀ')
/*  22:    */       {
/*  23: 63 */         utf8Length += ('' - c >>> 31);
/*  24:    */       }
/*  25:    */       else
/*  26:    */       {
/*  27: 65 */         utf8Length += encodedLengthGeneral(sequence, i);
/*  28: 66 */         break;
/*  29:    */       }
/*  30:    */     }
/*  31: 70 */     if (utf8Length < utf16Length) {
/*  32: 72 */       throw new IllegalArgumentException("UTF-8 length does not fit in int: " + (utf8Length + 4294967296L));
/*  33:    */     }
/*  34: 75 */     return utf8Length;
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static int encodedLengthGeneral(CharSequence sequence, int start)
/*  38:    */   {
/*  39: 79 */     int utf16Length = sequence.length();
/*  40: 80 */     int utf8Length = 0;
/*  41: 81 */     for (int i = start; i < utf16Length; i++)
/*  42:    */     {
/*  43: 82 */       char c = sequence.charAt(i);
/*  44: 83 */       if (c < 'ࠀ')
/*  45:    */       {
/*  46: 84 */         utf8Length += ('' - c >>> 31);
/*  47:    */       }
/*  48:    */       else
/*  49:    */       {
/*  50: 86 */         utf8Length += 2;
/*  51: 88 */         if ((55296 <= c) && (c <= 57343))
/*  52:    */         {
/*  53: 90 */           int cp = Character.codePointAt(sequence, i);
/*  54: 91 */           if (cp < 65536) {
/*  55: 92 */             throw new IllegalArgumentException("Unpaired surrogate at index " + i);
/*  56:    */           }
/*  57: 94 */           i++;
/*  58:    */         }
/*  59:    */       }
/*  60:    */     }
/*  61: 98 */     return utf8Length;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static boolean isWellFormed(byte[] bytes)
/*  65:    */   {
/*  66:112 */     return isWellFormed(bytes, 0, bytes.length);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static boolean isWellFormed(byte[] bytes, int off, int len)
/*  70:    */   {
/*  71:125 */     int end = off + len;
/*  72:126 */     Preconditions.checkPositionIndexes(off, end, bytes.length);
/*  73:128 */     for (int i = off; i < end; i++) {
/*  74:129 */       if (bytes[i] < 0) {
/*  75:130 */         return isWellFormedSlowPath(bytes, i, end);
/*  76:    */       }
/*  77:    */     }
/*  78:133 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static boolean isWellFormedSlowPath(byte[] bytes, int off, int end)
/*  82:    */   {
/*  83:137 */     int index = off;
/*  84:    */     for (;;)
/*  85:    */     {
/*  86:143 */       if (index >= end) {
/*  87:144 */         return true;
/*  88:    */       }
/*  89:    */       int byte1;
/*  90:146 */       if ((byte1 = bytes[(index++)]) < 0) {
/*  91:148 */         if (byte1 < -32)
/*  92:    */         {
/*  93:150 */           if (index == end) {
/*  94:151 */             return false;
/*  95:    */           }
/*  96:155 */           if ((byte1 < -62) || (bytes[(index++)] > -65)) {
/*  97:156 */             return false;
/*  98:    */           }
/*  99:    */         }
/* 100:158 */         else if (byte1 < -16)
/* 101:    */         {
/* 102:160 */           if (index + 1 >= end) {
/* 103:161 */             return false;
/* 104:    */           }
/* 105:163 */           int byte2 = bytes[(index++)];
/* 106:164 */           if ((byte2 > -65) || ((byte1 == -32) && (byte2 < -96)) || ((byte1 == -19) && (-96 <= byte2)) || (bytes[(index++)] > -65)) {
/* 107:171 */             return false;
/* 108:    */           }
/* 109:    */         }
/* 110:    */         else
/* 111:    */         {
/* 112:175 */           if (index + 2 >= end) {
/* 113:176 */             return false;
/* 114:    */           }
/* 115:178 */           int byte2 = bytes[(index++)];
/* 116:179 */           if ((byte2 > -65) || ((byte1 << 28) + (byte2 - -112) >> 30 != 0) || (bytes[(index++)] > -65) || (bytes[(index++)] > -65)) {
/* 117:189 */             return false;
/* 118:    */           }
/* 119:    */         }
/* 120:    */       }
/* 121:    */     }
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Utf8
 * JD-Core Version:    0.7.0.1
 */
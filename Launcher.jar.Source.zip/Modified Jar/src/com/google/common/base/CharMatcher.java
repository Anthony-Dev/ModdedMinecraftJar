/*    1:     */ package com.google.common.base;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import java.util.Arrays;
/*    7:     */ import java.util.BitSet;
/*    8:     */ import javax.annotation.CheckReturnValue;
/*    9:     */ 
/*   10:     */ @Beta
/*   11:     */ @GwtCompatible(emulated=true)
/*   12:     */ public abstract class CharMatcher
/*   13:     */   implements Predicate<Character>
/*   14:     */ {
/*   15:  67 */   public static final CharMatcher BREAKING_WHITESPACE = new CharMatcher()
/*   16:     */   {
/*   17:     */     public boolean matches(char c)
/*   18:     */     {
/*   19:  70 */       switch (c)
/*   20:     */       {
/*   21:     */       case '\t': 
/*   22:     */       case '\n': 
/*   23:     */       case '\013': 
/*   24:     */       case '\f': 
/*   25:     */       case '\r': 
/*   26:     */       case ' ': 
/*   27:     */       case '': 
/*   28:     */       case ' ': 
/*   29:     */       case ' ': 
/*   30:     */       case ' ': 
/*   31:     */       case ' ': 
/*   32:     */       case '　': 
/*   33:  83 */         return true;
/*   34:     */       case ' ': 
/*   35:  85 */         return false;
/*   36:     */       }
/*   37:  87 */       return (c >= ' ') && (c <= ' ');
/*   38:     */     }
/*   39:     */     
/*   40:     */     public String toString()
/*   41:     */     {
/*   42:  93 */       return "CharMatcher.BREAKING_WHITESPACE";
/*   43:     */     }
/*   44:     */   };
/*   45: 100 */   public static final CharMatcher ASCII = inRange('\000', '', "CharMatcher.ASCII");
/*   46:     */   private static final String ZEROES = "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０";
/*   47:     */   private static final String NINES;
/*   48:     */   
/*   49:     */   private static class RangesMatcher
/*   50:     */     extends CharMatcher
/*   51:     */   {
/*   52:     */     private final char[] rangeStarts;
/*   53:     */     private final char[] rangeEnds;
/*   54:     */     
/*   55:     */     RangesMatcher(String description, char[] rangeStarts, char[] rangeEnds)
/*   56:     */     {
/*   57: 107 */       super();
/*   58: 108 */       this.rangeStarts = rangeStarts;
/*   59: 109 */       this.rangeEnds = rangeEnds;
/*   60: 110 */       Preconditions.checkArgument(rangeStarts.length == rangeEnds.length);
/*   61: 111 */       for (int i = 0; i < rangeStarts.length; i++)
/*   62:     */       {
/*   63: 112 */         Preconditions.checkArgument(rangeStarts[i] <= rangeEnds[i]);
/*   64: 113 */         if (i + 1 < rangeStarts.length) {
/*   65: 114 */           Preconditions.checkArgument(rangeEnds[i] < rangeStarts[(i + 1)]);
/*   66:     */         }
/*   67:     */       }
/*   68:     */     }
/*   69:     */     
/*   70:     */     public boolean matches(char c)
/*   71:     */     {
/*   72: 121 */       int index = Arrays.binarySearch(this.rangeStarts, c);
/*   73: 122 */       if (index >= 0) {
/*   74: 123 */         return true;
/*   75:     */       }
/*   76: 125 */       index = (index ^ 0xFFFFFFFF) - 1;
/*   77: 126 */       return (index >= 0) && (c <= this.rangeEnds[index]);
/*   78:     */     }
/*   79:     */   }
/*   80:     */   
/*   81:     */   static
/*   82:     */   {
/*   83: 138 */     StringBuilder builder = new StringBuilder("0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length());
/*   84: 139 */     for (int i = 0; i < "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length(); i++) {
/*   85: 140 */       builder.append((char)("0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".charAt(i) + '\t'));
/*   86:     */     }
/*   87: 142 */     NINES = builder.toString();
/*   88:     */   }
/*   89:     */   
/*   90: 150 */   public static final CharMatcher DIGIT = new RangesMatcher("CharMatcher.DIGIT", "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".toCharArray(), NINES.toCharArray());
/*   91: 158 */   public static final CharMatcher JAVA_DIGIT = new CharMatcher("CharMatcher.JAVA_DIGIT")
/*   92:     */   {
/*   93:     */     public boolean matches(char c)
/*   94:     */     {
/*   95: 160 */       return Character.isDigit(c);
/*   96:     */     }
/*   97:     */   };
/*   98: 169 */   public static final CharMatcher JAVA_LETTER = new CharMatcher("CharMatcher.JAVA_LETTER")
/*   99:     */   {
/*  100:     */     public boolean matches(char c)
/*  101:     */     {
/*  102: 171 */       return Character.isLetter(c);
/*  103:     */     }
/*  104:     */   };
/*  105: 179 */   public static final CharMatcher JAVA_LETTER_OR_DIGIT = new CharMatcher("CharMatcher.JAVA_LETTER_OR_DIGIT")
/*  106:     */   {
/*  107:     */     public boolean matches(char c)
/*  108:     */     {
/*  109: 182 */       return Character.isLetterOrDigit(c);
/*  110:     */     }
/*  111:     */   };
/*  112: 190 */   public static final CharMatcher JAVA_UPPER_CASE = new CharMatcher("CharMatcher.JAVA_UPPER_CASE")
/*  113:     */   {
/*  114:     */     public boolean matches(char c)
/*  115:     */     {
/*  116: 193 */       return Character.isUpperCase(c);
/*  117:     */     }
/*  118:     */   };
/*  119: 201 */   public static final CharMatcher JAVA_LOWER_CASE = new CharMatcher("CharMatcher.JAVA_LOWER_CASE")
/*  120:     */   {
/*  121:     */     public boolean matches(char c)
/*  122:     */     {
/*  123: 204 */       return Character.isLowerCase(c);
/*  124:     */     }
/*  125:     */   };
/*  126: 212 */   public static final CharMatcher JAVA_ISO_CONTROL = inRange('\000', '\037').or(inRange('', '')).withToString("CharMatcher.JAVA_ISO_CONTROL");
/*  127: 222 */   public static final CharMatcher INVISIBLE = new RangesMatcher("CharMatcher.INVISIBLE", "".toCharArray(), "  ­؄؜۝܏ ᠎‏ ⁤⁦⁧⁨⁩⁯　﻿￹￻".toCharArray());
/*  128:     */   
/*  129:     */   private static String showCharacter(char c)
/*  130:     */   {
/*  131: 229 */     String hex = "0123456789ABCDEF";
/*  132: 230 */     char[] tmp = { '\\', 'u', '\000', '\000', '\000', '\000' };
/*  133: 231 */     for (int i = 0; i < 4; i++)
/*  134:     */     {
/*  135: 232 */       tmp[(5 - i)] = hex.charAt(c & 0xF);
/*  136: 233 */       c = (char)(c >> '\004');
/*  137:     */     }
/*  138: 235 */     return String.copyValueOf(tmp);
/*  139:     */   }
/*  140:     */   
/*  141: 247 */   public static final CharMatcher SINGLE_WIDTH = new RangesMatcher("CharMatcher.SINGLE_WIDTH", "".toCharArray(), "ӹ־ת״ۿݿ๿₯℺﷿﻿ￜ".toCharArray());
/*  142: 252 */   public static final CharMatcher ANY = new FastMatcher("CharMatcher.ANY")
/*  143:     */   {
/*  144:     */     public boolean matches(char c)
/*  145:     */     {
/*  146: 255 */       return true;
/*  147:     */     }
/*  148:     */     
/*  149:     */     public int indexIn(CharSequence sequence)
/*  150:     */     {
/*  151: 259 */       return sequence.length() == 0 ? -1 : 0;
/*  152:     */     }
/*  153:     */     
/*  154:     */     public int indexIn(CharSequence sequence, int start)
/*  155:     */     {
/*  156: 263 */       int length = sequence.length();
/*  157: 264 */       Preconditions.checkPositionIndex(start, length);
/*  158: 265 */       return start == length ? -1 : start;
/*  159:     */     }
/*  160:     */     
/*  161:     */     public int lastIndexIn(CharSequence sequence)
/*  162:     */     {
/*  163: 269 */       return sequence.length() - 1;
/*  164:     */     }
/*  165:     */     
/*  166:     */     public boolean matchesAllOf(CharSequence sequence)
/*  167:     */     {
/*  168: 273 */       Preconditions.checkNotNull(sequence);
/*  169: 274 */       return true;
/*  170:     */     }
/*  171:     */     
/*  172:     */     public boolean matchesNoneOf(CharSequence sequence)
/*  173:     */     {
/*  174: 278 */       return sequence.length() == 0;
/*  175:     */     }
/*  176:     */     
/*  177:     */     public String removeFrom(CharSequence sequence)
/*  178:     */     {
/*  179: 282 */       Preconditions.checkNotNull(sequence);
/*  180: 283 */       return "";
/*  181:     */     }
/*  182:     */     
/*  183:     */     public String replaceFrom(CharSequence sequence, char replacement)
/*  184:     */     {
/*  185: 287 */       char[] array = new char[sequence.length()];
/*  186: 288 */       Arrays.fill(array, replacement);
/*  187: 289 */       return new String(array);
/*  188:     */     }
/*  189:     */     
/*  190:     */     public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  191:     */     {
/*  192: 293 */       StringBuilder retval = new StringBuilder(sequence.length() * replacement.length());
/*  193: 294 */       for (int i = 0; i < sequence.length(); i++) {
/*  194: 295 */         retval.append(replacement);
/*  195:     */       }
/*  196: 297 */       return retval.toString();
/*  197:     */     }
/*  198:     */     
/*  199:     */     public String collapseFrom(CharSequence sequence, char replacement)
/*  200:     */     {
/*  201: 301 */       return sequence.length() == 0 ? "" : String.valueOf(replacement);
/*  202:     */     }
/*  203:     */     
/*  204:     */     public String trimFrom(CharSequence sequence)
/*  205:     */     {
/*  206: 305 */       Preconditions.checkNotNull(sequence);
/*  207: 306 */       return "";
/*  208:     */     }
/*  209:     */     
/*  210:     */     public int countIn(CharSequence sequence)
/*  211:     */     {
/*  212: 310 */       return sequence.length();
/*  213:     */     }
/*  214:     */     
/*  215:     */     public CharMatcher and(CharMatcher other)
/*  216:     */     {
/*  217: 314 */       return (CharMatcher)Preconditions.checkNotNull(other);
/*  218:     */     }
/*  219:     */     
/*  220:     */     public CharMatcher or(CharMatcher other)
/*  221:     */     {
/*  222: 318 */       Preconditions.checkNotNull(other);
/*  223: 319 */       return this;
/*  224:     */     }
/*  225:     */     
/*  226:     */     public CharMatcher negate()
/*  227:     */     {
/*  228: 323 */       return NONE;
/*  229:     */     }
/*  230:     */   };
/*  231: 328 */   public static final CharMatcher NONE = new FastMatcher("CharMatcher.NONE")
/*  232:     */   {
/*  233:     */     public boolean matches(char c)
/*  234:     */     {
/*  235: 331 */       return false;
/*  236:     */     }
/*  237:     */     
/*  238:     */     public int indexIn(CharSequence sequence)
/*  239:     */     {
/*  240: 335 */       Preconditions.checkNotNull(sequence);
/*  241: 336 */       return -1;
/*  242:     */     }
/*  243:     */     
/*  244:     */     public int indexIn(CharSequence sequence, int start)
/*  245:     */     {
/*  246: 340 */       int length = sequence.length();
/*  247: 341 */       Preconditions.checkPositionIndex(start, length);
/*  248: 342 */       return -1;
/*  249:     */     }
/*  250:     */     
/*  251:     */     public int lastIndexIn(CharSequence sequence)
/*  252:     */     {
/*  253: 346 */       Preconditions.checkNotNull(sequence);
/*  254: 347 */       return -1;
/*  255:     */     }
/*  256:     */     
/*  257:     */     public boolean matchesAllOf(CharSequence sequence)
/*  258:     */     {
/*  259: 351 */       return sequence.length() == 0;
/*  260:     */     }
/*  261:     */     
/*  262:     */     public boolean matchesNoneOf(CharSequence sequence)
/*  263:     */     {
/*  264: 355 */       Preconditions.checkNotNull(sequence);
/*  265: 356 */       return true;
/*  266:     */     }
/*  267:     */     
/*  268:     */     public String removeFrom(CharSequence sequence)
/*  269:     */     {
/*  270: 360 */       return sequence.toString();
/*  271:     */     }
/*  272:     */     
/*  273:     */     public String replaceFrom(CharSequence sequence, char replacement)
/*  274:     */     {
/*  275: 364 */       return sequence.toString();
/*  276:     */     }
/*  277:     */     
/*  278:     */     public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  279:     */     {
/*  280: 368 */       Preconditions.checkNotNull(replacement);
/*  281: 369 */       return sequence.toString();
/*  282:     */     }
/*  283:     */     
/*  284:     */     public String collapseFrom(CharSequence sequence, char replacement)
/*  285:     */     {
/*  286: 373 */       return sequence.toString();
/*  287:     */     }
/*  288:     */     
/*  289:     */     public String trimFrom(CharSequence sequence)
/*  290:     */     {
/*  291: 377 */       return sequence.toString();
/*  292:     */     }
/*  293:     */     
/*  294:     */     public String trimLeadingFrom(CharSequence sequence)
/*  295:     */     {
/*  296: 382 */       return sequence.toString();
/*  297:     */     }
/*  298:     */     
/*  299:     */     public String trimTrailingFrom(CharSequence sequence)
/*  300:     */     {
/*  301: 387 */       return sequence.toString();
/*  302:     */     }
/*  303:     */     
/*  304:     */     public int countIn(CharSequence sequence)
/*  305:     */     {
/*  306: 391 */       Preconditions.checkNotNull(sequence);
/*  307: 392 */       return 0;
/*  308:     */     }
/*  309:     */     
/*  310:     */     public CharMatcher and(CharMatcher other)
/*  311:     */     {
/*  312: 396 */       Preconditions.checkNotNull(other);
/*  313: 397 */       return this;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public CharMatcher or(CharMatcher other)
/*  317:     */     {
/*  318: 401 */       return (CharMatcher)Preconditions.checkNotNull(other);
/*  319:     */     }
/*  320:     */     
/*  321:     */     public CharMatcher negate()
/*  322:     */     {
/*  323: 405 */       return ANY;
/*  324:     */     }
/*  325:     */   };
/*  326:     */   final String description;
/*  327:     */   private static final int DISTINCT_CHARS = 65536;
/*  328:     */   static final String WHITESPACE_TABLE = " 　\r   　 \013　   　 \t     \f 　 　　 \n 　";
/*  329:     */   static final int WHITESPACE_MULTIPLIER = 1682554634;
/*  330:     */   
/*  331:     */   public static CharMatcher is(final char match)
/*  332:     */   {
/*  333: 415 */     String description = "CharMatcher.is('" + showCharacter(match) + "')";
/*  334: 416 */     new FastMatcher(description)
/*  335:     */     {
/*  336:     */       public boolean matches(char c)
/*  337:     */       {
/*  338: 418 */         return c == match;
/*  339:     */       }
/*  340:     */       
/*  341:     */       public String replaceFrom(CharSequence sequence, char replacement)
/*  342:     */       {
/*  343: 422 */         return sequence.toString().replace(match, replacement);
/*  344:     */       }
/*  345:     */       
/*  346:     */       public CharMatcher and(CharMatcher other)
/*  347:     */       {
/*  348: 426 */         return other.matches(match) ? this : NONE;
/*  349:     */       }
/*  350:     */       
/*  351:     */       public CharMatcher or(CharMatcher other)
/*  352:     */       {
/*  353: 430 */         return other.matches(match) ? other : super.or(other);
/*  354:     */       }
/*  355:     */       
/*  356:     */       public CharMatcher negate()
/*  357:     */       {
/*  358: 434 */         return isNot(match);
/*  359:     */       }
/*  360:     */       
/*  361:     */       @GwtIncompatible("java.util.BitSet")
/*  362:     */       void setBits(BitSet table)
/*  363:     */       {
/*  364: 440 */         table.set(match);
/*  365:     */       }
/*  366:     */     };
/*  367:     */   }
/*  368:     */   
/*  369:     */   public static CharMatcher isNot(final char match)
/*  370:     */   {
/*  371: 451 */     String description = "CharMatcher.isNot('" + showCharacter(match) + "')";
/*  372: 452 */     new FastMatcher(description)
/*  373:     */     {
/*  374:     */       public boolean matches(char c)
/*  375:     */       {
/*  376: 454 */         return c != match;
/*  377:     */       }
/*  378:     */       
/*  379:     */       public CharMatcher and(CharMatcher other)
/*  380:     */       {
/*  381: 458 */         return other.matches(match) ? super.and(other) : other;
/*  382:     */       }
/*  383:     */       
/*  384:     */       public CharMatcher or(CharMatcher other)
/*  385:     */       {
/*  386: 462 */         return other.matches(match) ? ANY : this;
/*  387:     */       }
/*  388:     */       
/*  389:     */       @GwtIncompatible("java.util.BitSet")
/*  390:     */       void setBits(BitSet table)
/*  391:     */       {
/*  392: 468 */         table.set(0, match);
/*  393: 469 */         table.set(match + '\001', 65536);
/*  394:     */       }
/*  395:     */       
/*  396:     */       public CharMatcher negate()
/*  397:     */       {
/*  398: 473 */         return is(match);
/*  399:     */       }
/*  400:     */     };
/*  401:     */   }
/*  402:     */   
/*  403:     */   public static CharMatcher anyOf(CharSequence sequence)
/*  404:     */   {
/*  405: 483 */     switch (sequence.length())
/*  406:     */     {
/*  407:     */     case 0: 
/*  408: 485 */       return NONE;
/*  409:     */     case 1: 
/*  410: 487 */       return is(sequence.charAt(0));
/*  411:     */     case 2: 
/*  412: 489 */       return isEither(sequence.charAt(0), sequence.charAt(1));
/*  413:     */     }
/*  414: 494 */     final char[] chars = sequence.toString().toCharArray();
/*  415: 495 */     Arrays.sort(chars);
/*  416: 496 */     StringBuilder description = new StringBuilder("CharMatcher.anyOf(\"");
/*  417: 497 */     for (char c : chars) {
/*  418: 498 */       description.append(showCharacter(c));
/*  419:     */     }
/*  420: 500 */     description.append("\")");
/*  421: 501 */     new CharMatcher(description.toString())
/*  422:     */     {
/*  423:     */       public boolean matches(char c)
/*  424:     */       {
/*  425: 503 */         return Arrays.binarySearch(chars, c) >= 0;
/*  426:     */       }
/*  427:     */       
/*  428:     */       @GwtIncompatible("java.util.BitSet")
/*  429:     */       void setBits(BitSet table)
/*  430:     */       {
/*  431: 509 */         for (char c : chars) {
/*  432: 510 */           table.set(c);
/*  433:     */         }
/*  434:     */       }
/*  435:     */     };
/*  436:     */   }
/*  437:     */   
/*  438:     */   private static CharMatcher isEither(final char match1, final char match2)
/*  439:     */   {
/*  440: 519 */     String description = "CharMatcher.anyOf(\"" + showCharacter(match1) + showCharacter(match2) + "\")";
/*  441:     */     
/*  442: 521 */     new FastMatcher(description)
/*  443:     */     {
/*  444:     */       public boolean matches(char c)
/*  445:     */       {
/*  446: 523 */         return (c == match1) || (c == match2);
/*  447:     */       }
/*  448:     */       
/*  449:     */       @GwtIncompatible("java.util.BitSet")
/*  450:     */       void setBits(BitSet table)
/*  451:     */       {
/*  452: 528 */         table.set(match1);
/*  453: 529 */         table.set(match2);
/*  454:     */       }
/*  455:     */     };
/*  456:     */   }
/*  457:     */   
/*  458:     */   public static CharMatcher noneOf(CharSequence sequence)
/*  459:     */   {
/*  460: 539 */     return anyOf(sequence).negate();
/*  461:     */   }
/*  462:     */   
/*  463:     */   public static CharMatcher inRange(char startInclusive, char endInclusive)
/*  464:     */   {
/*  465: 550 */     Preconditions.checkArgument(endInclusive >= startInclusive);
/*  466: 551 */     String description = "CharMatcher.inRange('" + showCharacter(startInclusive) + "', '" + showCharacter(endInclusive) + "')";
/*  467:     */     
/*  468:     */ 
/*  469: 554 */     return inRange(startInclusive, endInclusive, description);
/*  470:     */   }
/*  471:     */   
/*  472:     */   static CharMatcher inRange(final char startInclusive, final char endInclusive, String description)
/*  473:     */   {
/*  474: 559 */     new FastMatcher(description)
/*  475:     */     {
/*  476:     */       public boolean matches(char c)
/*  477:     */       {
/*  478: 561 */         return (startInclusive <= c) && (c <= endInclusive);
/*  479:     */       }
/*  480:     */       
/*  481:     */       @GwtIncompatible("java.util.BitSet")
/*  482:     */       void setBits(BitSet table)
/*  483:     */       {
/*  484: 566 */         table.set(startInclusive, endInclusive + '\001');
/*  485:     */       }
/*  486:     */     };
/*  487:     */   }
/*  488:     */   
/*  489:     */   public static CharMatcher forPredicate(final Predicate<? super Character> predicate)
/*  490:     */   {
/*  491: 576 */     Preconditions.checkNotNull(predicate);
/*  492: 577 */     if ((predicate instanceof CharMatcher)) {
/*  493: 578 */       return (CharMatcher)predicate;
/*  494:     */     }
/*  495: 580 */     String description = "CharMatcher.forPredicate(" + predicate + ")";
/*  496: 581 */     new CharMatcher(description)
/*  497:     */     {
/*  498:     */       public boolean matches(char c)
/*  499:     */       {
/*  500: 583 */         return predicate.apply(Character.valueOf(c));
/*  501:     */       }
/*  502:     */       
/*  503:     */       public boolean apply(Character character)
/*  504:     */       {
/*  505: 587 */         return predicate.apply(Preconditions.checkNotNull(character));
/*  506:     */       }
/*  507:     */     };
/*  508:     */   }
/*  509:     */   
/*  510:     */   CharMatcher(String description)
/*  511:     */   {
/*  512: 601 */     this.description = description;
/*  513:     */   }
/*  514:     */   
/*  515:     */   protected CharMatcher()
/*  516:     */   {
/*  517: 609 */     this.description = super.toString();
/*  518:     */   }
/*  519:     */   
/*  520:     */   public CharMatcher negate()
/*  521:     */   {
/*  522: 623 */     return new NegatedMatcher(this);
/*  523:     */   }
/*  524:     */   
/*  525:     */   private static class NegatedMatcher
/*  526:     */     extends CharMatcher
/*  527:     */   {
/*  528:     */     final CharMatcher original;
/*  529:     */     
/*  530:     */     NegatedMatcher(String toString, CharMatcher original)
/*  531:     */     {
/*  532: 630 */       super();
/*  533: 631 */       this.original = original;
/*  534:     */     }
/*  535:     */     
/*  536:     */     NegatedMatcher(CharMatcher original)
/*  537:     */     {
/*  538: 635 */       this(original + ".negate()", original);
/*  539:     */     }
/*  540:     */     
/*  541:     */     public boolean matches(char c)
/*  542:     */     {
/*  543: 639 */       return !this.original.matches(c);
/*  544:     */     }
/*  545:     */     
/*  546:     */     public boolean matchesAllOf(CharSequence sequence)
/*  547:     */     {
/*  548: 643 */       return this.original.matchesNoneOf(sequence);
/*  549:     */     }
/*  550:     */     
/*  551:     */     public boolean matchesNoneOf(CharSequence sequence)
/*  552:     */     {
/*  553: 647 */       return this.original.matchesAllOf(sequence);
/*  554:     */     }
/*  555:     */     
/*  556:     */     public int countIn(CharSequence sequence)
/*  557:     */     {
/*  558: 651 */       return sequence.length() - this.original.countIn(sequence);
/*  559:     */     }
/*  560:     */     
/*  561:     */     @GwtIncompatible("java.util.BitSet")
/*  562:     */     void setBits(BitSet table)
/*  563:     */     {
/*  564: 657 */       BitSet tmp = new BitSet();
/*  565: 658 */       this.original.setBits(tmp);
/*  566: 659 */       tmp.flip(0, 65536);
/*  567: 660 */       table.or(tmp);
/*  568:     */     }
/*  569:     */     
/*  570:     */     public CharMatcher negate()
/*  571:     */     {
/*  572: 664 */       return this.original;
/*  573:     */     }
/*  574:     */     
/*  575:     */     CharMatcher withToString(String description)
/*  576:     */     {
/*  577: 669 */       return new NegatedMatcher(description, this.original);
/*  578:     */     }
/*  579:     */   }
/*  580:     */   
/*  581:     */   public CharMatcher and(CharMatcher other)
/*  582:     */   {
/*  583: 677 */     return new And(this, (CharMatcher)Preconditions.checkNotNull(other));
/*  584:     */   }
/*  585:     */   
/*  586:     */   private static class And
/*  587:     */     extends CharMatcher
/*  588:     */   {
/*  589:     */     final CharMatcher first;
/*  590:     */     final CharMatcher second;
/*  591:     */     
/*  592:     */     And(CharMatcher a, CharMatcher b)
/*  593:     */     {
/*  594: 685 */       this(a, b, "CharMatcher.and(" + a + ", " + b + ")");
/*  595:     */     }
/*  596:     */     
/*  597:     */     And(CharMatcher a, CharMatcher b, String description)
/*  598:     */     {
/*  599: 689 */       super();
/*  600: 690 */       this.first = ((CharMatcher)Preconditions.checkNotNull(a));
/*  601: 691 */       this.second = ((CharMatcher)Preconditions.checkNotNull(b));
/*  602:     */     }
/*  603:     */     
/*  604:     */     public boolean matches(char c)
/*  605:     */     {
/*  606: 696 */       return (this.first.matches(c)) && (this.second.matches(c));
/*  607:     */     }
/*  608:     */     
/*  609:     */     @GwtIncompatible("java.util.BitSet")
/*  610:     */     void setBits(BitSet table)
/*  611:     */     {
/*  612: 702 */       BitSet tmp1 = new BitSet();
/*  613: 703 */       this.first.setBits(tmp1);
/*  614: 704 */       BitSet tmp2 = new BitSet();
/*  615: 705 */       this.second.setBits(tmp2);
/*  616: 706 */       tmp1.and(tmp2);
/*  617: 707 */       table.or(tmp1);
/*  618:     */     }
/*  619:     */     
/*  620:     */     CharMatcher withToString(String description)
/*  621:     */     {
/*  622: 712 */       return new And(this.first, this.second, description);
/*  623:     */     }
/*  624:     */   }
/*  625:     */   
/*  626:     */   public CharMatcher or(CharMatcher other)
/*  627:     */   {
/*  628: 720 */     return new Or(this, (CharMatcher)Preconditions.checkNotNull(other));
/*  629:     */   }
/*  630:     */   
/*  631:     */   private static class Or
/*  632:     */     extends CharMatcher
/*  633:     */   {
/*  634:     */     final CharMatcher first;
/*  635:     */     final CharMatcher second;
/*  636:     */     
/*  637:     */     Or(CharMatcher a, CharMatcher b, String description)
/*  638:     */     {
/*  639: 728 */       super();
/*  640: 729 */       this.first = ((CharMatcher)Preconditions.checkNotNull(a));
/*  641: 730 */       this.second = ((CharMatcher)Preconditions.checkNotNull(b));
/*  642:     */     }
/*  643:     */     
/*  644:     */     Or(CharMatcher a, CharMatcher b)
/*  645:     */     {
/*  646: 734 */       this(a, b, "CharMatcher.or(" + a + ", " + b + ")");
/*  647:     */     }
/*  648:     */     
/*  649:     */     @GwtIncompatible("java.util.BitSet")
/*  650:     */     void setBits(BitSet table)
/*  651:     */     {
/*  652: 740 */       this.first.setBits(table);
/*  653: 741 */       this.second.setBits(table);
/*  654:     */     }
/*  655:     */     
/*  656:     */     public boolean matches(char c)
/*  657:     */     {
/*  658: 746 */       return (this.first.matches(c)) || (this.second.matches(c));
/*  659:     */     }
/*  660:     */     
/*  661:     */     CharMatcher withToString(String description)
/*  662:     */     {
/*  663: 751 */       return new Or(this.first, this.second, description);
/*  664:     */     }
/*  665:     */   }
/*  666:     */   
/*  667:     */   public CharMatcher precomputed()
/*  668:     */   {
/*  669: 765 */     return Platform.precomputeCharMatcher(this);
/*  670:     */   }
/*  671:     */   
/*  672:     */   CharMatcher withToString(String description)
/*  673:     */   {
/*  674: 775 */     throw new UnsupportedOperationException();
/*  675:     */   }
/*  676:     */   
/*  677:     */   @GwtIncompatible("java.util.BitSet")
/*  678:     */   CharMatcher precomputedInternal()
/*  679:     */   {
/*  680: 792 */     BitSet table = new BitSet();
/*  681: 793 */     setBits(table);
/*  682: 794 */     int totalCharacters = table.cardinality();
/*  683: 795 */     if (totalCharacters * 2 <= 65536) {
/*  684: 796 */       return precomputedPositive(totalCharacters, table, this.description);
/*  685:     */     }
/*  686: 799 */     table.flip(0, 65536);
/*  687: 800 */     int negatedCharacters = 65536 - totalCharacters;
/*  688: 801 */     String suffix = ".negate()";
/*  689: 802 */     String negatedDescription = this.description + suffix;
/*  690:     */     
/*  691:     */ 
/*  692: 805 */     return new NegatedFastMatcher(toString(), precomputedPositive(negatedCharacters, table, negatedDescription));
/*  693:     */   }
/*  694:     */   
/*  695:     */   static abstract class FastMatcher
/*  696:     */     extends CharMatcher
/*  697:     */   {
/*  698:     */     FastMatcher() {}
/*  699:     */     
/*  700:     */     FastMatcher(String description)
/*  701:     */     {
/*  702: 819 */       super();
/*  703:     */     }
/*  704:     */     
/*  705:     */     public final CharMatcher precomputed()
/*  706:     */     {
/*  707: 824 */       return this;
/*  708:     */     }
/*  709:     */     
/*  710:     */     public CharMatcher negate()
/*  711:     */     {
/*  712: 829 */       return new CharMatcher.NegatedFastMatcher(this);
/*  713:     */     }
/*  714:     */   }
/*  715:     */   
/*  716:     */   static final class NegatedFastMatcher
/*  717:     */     extends CharMatcher.NegatedMatcher
/*  718:     */   {
/*  719:     */     NegatedFastMatcher(CharMatcher original)
/*  720:     */     {
/*  721: 835 */       super();
/*  722:     */     }
/*  723:     */     
/*  724:     */     NegatedFastMatcher(String toString, CharMatcher original)
/*  725:     */     {
/*  726: 839 */       super(original);
/*  727:     */     }
/*  728:     */     
/*  729:     */     public final CharMatcher precomputed()
/*  730:     */     {
/*  731: 844 */       return this;
/*  732:     */     }
/*  733:     */     
/*  734:     */     CharMatcher withToString(String description)
/*  735:     */     {
/*  736: 849 */       return new NegatedFastMatcher(description, this.original);
/*  737:     */     }
/*  738:     */   }
/*  739:     */   
/*  740:     */   @GwtIncompatible("java.util.BitSet")
/*  741:     */   private static CharMatcher precomputedPositive(int totalCharacters, BitSet table, String description)
/*  742:     */   {
/*  743: 861 */     switch (totalCharacters)
/*  744:     */     {
/*  745:     */     case 0: 
/*  746: 863 */       return NONE;
/*  747:     */     case 1: 
/*  748: 865 */       return is((char)table.nextSetBit(0));
/*  749:     */     case 2: 
/*  750: 867 */       char c1 = (char)table.nextSetBit(0);
/*  751: 868 */       char c2 = (char)table.nextSetBit(c1 + '\001');
/*  752: 869 */       return isEither(c1, c2);
/*  753:     */     }
/*  754: 871 */     return isSmall(totalCharacters, table.length()) ? SmallCharMatcher.from(table, description) : new BitSetMatcher(table, description, null);
/*  755:     */   }
/*  756:     */   
/*  757:     */   @GwtIncompatible("SmallCharMatcher")
/*  758:     */   private static boolean isSmall(int totalCharacters, int tableLength)
/*  759:     */   {
/*  760: 879 */     return (totalCharacters <= 1023) && (tableLength > totalCharacters * 4 * 16);
/*  761:     */   }
/*  762:     */   
/*  763:     */   @GwtIncompatible("java.util.BitSet")
/*  764:     */   private static class BitSetMatcher
/*  765:     */     extends CharMatcher.FastMatcher
/*  766:     */   {
/*  767:     */     private final BitSet table;
/*  768:     */     
/*  769:     */     private BitSetMatcher(BitSet table, String description)
/*  770:     */     {
/*  771: 889 */       super();
/*  772: 890 */       if (table.length() + 64 < table.size()) {
/*  773: 891 */         table = (BitSet)table.clone();
/*  774:     */       }
/*  775: 894 */       this.table = table;
/*  776:     */     }
/*  777:     */     
/*  778:     */     public boolean matches(char c)
/*  779:     */     {
/*  780: 898 */       return this.table.get(c);
/*  781:     */     }
/*  782:     */     
/*  783:     */     void setBits(BitSet bitSet)
/*  784:     */     {
/*  785: 903 */       bitSet.or(this.table);
/*  786:     */     }
/*  787:     */   }
/*  788:     */   
/*  789:     */   @GwtIncompatible("java.util.BitSet")
/*  790:     */   void setBits(BitSet table)
/*  791:     */   {
/*  792: 912 */     for (int c = 65535; c >= 0; c--) {
/*  793: 913 */       if (matches((char)c)) {
/*  794: 914 */         table.set(c);
/*  795:     */       }
/*  796:     */     }
/*  797:     */   }
/*  798:     */   
/*  799:     */   public boolean matchesAnyOf(CharSequence sequence)
/*  800:     */   {
/*  801: 933 */     return !matchesNoneOf(sequence);
/*  802:     */   }
/*  803:     */   
/*  804:     */   public boolean matchesAllOf(CharSequence sequence)
/*  805:     */   {
/*  806: 947 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  807: 948 */       if (!matches(sequence.charAt(i))) {
/*  808: 949 */         return false;
/*  809:     */       }
/*  810:     */     }
/*  811: 952 */     return true;
/*  812:     */   }
/*  813:     */   
/*  814:     */   public boolean matchesNoneOf(CharSequence sequence)
/*  815:     */   {
/*  816: 967 */     return indexIn(sequence) == -1;
/*  817:     */   }
/*  818:     */   
/*  819:     */   public int indexIn(CharSequence sequence)
/*  820:     */   {
/*  821: 981 */     int length = sequence.length();
/*  822: 982 */     for (int i = 0; i < length; i++) {
/*  823: 983 */       if (matches(sequence.charAt(i))) {
/*  824: 984 */         return i;
/*  825:     */       }
/*  826:     */     }
/*  827: 987 */     return -1;
/*  828:     */   }
/*  829:     */   
/*  830:     */   public int indexIn(CharSequence sequence, int start)
/*  831:     */   {
/*  832:1006 */     int length = sequence.length();
/*  833:1007 */     Preconditions.checkPositionIndex(start, length);
/*  834:1008 */     for (int i = start; i < length; i++) {
/*  835:1009 */       if (matches(sequence.charAt(i))) {
/*  836:1010 */         return i;
/*  837:     */       }
/*  838:     */     }
/*  839:1013 */     return -1;
/*  840:     */   }
/*  841:     */   
/*  842:     */   public int lastIndexIn(CharSequence sequence)
/*  843:     */   {
/*  844:1027 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  845:1028 */       if (matches(sequence.charAt(i))) {
/*  846:1029 */         return i;
/*  847:     */       }
/*  848:     */     }
/*  849:1032 */     return -1;
/*  850:     */   }
/*  851:     */   
/*  852:     */   public int countIn(CharSequence sequence)
/*  853:     */   {
/*  854:1039 */     int count = 0;
/*  855:1040 */     for (int i = 0; i < sequence.length(); i++) {
/*  856:1041 */       if (matches(sequence.charAt(i))) {
/*  857:1042 */         count++;
/*  858:     */       }
/*  859:     */     }
/*  860:1045 */     return count;
/*  861:     */   }
/*  862:     */   
/*  863:     */   @CheckReturnValue
/*  864:     */   public String removeFrom(CharSequence sequence)
/*  865:     */   {
/*  866:1058 */     String string = sequence.toString();
/*  867:1059 */     int pos = indexIn(string);
/*  868:1060 */     if (pos == -1) {
/*  869:1061 */       return string;
/*  870:     */     }
/*  871:1064 */     char[] chars = string.toCharArray();
/*  872:1065 */     int spread = 1;
/*  873:     */     for (;;)
/*  874:     */     {
/*  875:1069 */       pos++;
/*  876:     */       for (;;)
/*  877:     */       {
/*  878:1071 */         if (pos == chars.length) {
/*  879:     */           break label79;
/*  880:     */         }
/*  881:1074 */         if (matches(chars[pos])) {
/*  882:     */           break;
/*  883:     */         }
/*  884:1077 */         chars[(pos - spread)] = chars[pos];
/*  885:1078 */         pos++;
/*  886:     */       }
/*  887:1080 */       spread++;
/*  888:     */     }
/*  889:     */     label79:
/*  890:1082 */     return new String(chars, 0, pos - spread);
/*  891:     */   }
/*  892:     */   
/*  893:     */   @CheckReturnValue
/*  894:     */   public String retainFrom(CharSequence sequence)
/*  895:     */   {
/*  896:1095 */     return negate().removeFrom(sequence);
/*  897:     */   }
/*  898:     */   
/*  899:     */   @CheckReturnValue
/*  900:     */   public String replaceFrom(CharSequence sequence, char replacement)
/*  901:     */   {
/*  902:1117 */     String string = sequence.toString();
/*  903:1118 */     int pos = indexIn(string);
/*  904:1119 */     if (pos == -1) {
/*  905:1120 */       return string;
/*  906:     */     }
/*  907:1122 */     char[] chars = string.toCharArray();
/*  908:1123 */     chars[pos] = replacement;
/*  909:1124 */     for (int i = pos + 1; i < chars.length; i++) {
/*  910:1125 */       if (matches(chars[i])) {
/*  911:1126 */         chars[i] = replacement;
/*  912:     */       }
/*  913:     */     }
/*  914:1129 */     return new String(chars);
/*  915:     */   }
/*  916:     */   
/*  917:     */   @CheckReturnValue
/*  918:     */   public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  919:     */   {
/*  920:1150 */     int replacementLen = replacement.length();
/*  921:1151 */     if (replacementLen == 0) {
/*  922:1152 */       return removeFrom(sequence);
/*  923:     */     }
/*  924:1154 */     if (replacementLen == 1) {
/*  925:1155 */       return replaceFrom(sequence, replacement.charAt(0));
/*  926:     */     }
/*  927:1158 */     String string = sequence.toString();
/*  928:1159 */     int pos = indexIn(string);
/*  929:1160 */     if (pos == -1) {
/*  930:1161 */       return string;
/*  931:     */     }
/*  932:1164 */     int len = string.length();
/*  933:1165 */     StringBuilder buf = new StringBuilder(len * 3 / 2 + 16);
/*  934:     */     
/*  935:1167 */     int oldpos = 0;
/*  936:     */     do
/*  937:     */     {
/*  938:1169 */       buf.append(string, oldpos, pos);
/*  939:1170 */       buf.append(replacement);
/*  940:1171 */       oldpos = pos + 1;
/*  941:1172 */       pos = indexIn(string, oldpos);
/*  942:1173 */     } while (pos != -1);
/*  943:1175 */     buf.append(string, oldpos, len);
/*  944:1176 */     return buf.toString();
/*  945:     */   }
/*  946:     */   
/*  947:     */   @CheckReturnValue
/*  948:     */   public String trimFrom(CharSequence sequence)
/*  949:     */   {
/*  950:1195 */     int len = sequence.length();
/*  951:1199 */     for (int first = 0; first < len; first++) {
/*  952:1200 */       if (!matches(sequence.charAt(first))) {
/*  953:     */         break;
/*  954:     */       }
/*  955:     */     }
/*  956:1204 */     for (int last = len - 1; last > first; last--) {
/*  957:1205 */       if (!matches(sequence.charAt(last))) {
/*  958:     */         break;
/*  959:     */       }
/*  960:     */     }
/*  961:1210 */     return sequence.subSequence(first, last + 1).toString();
/*  962:     */   }
/*  963:     */   
/*  964:     */   @CheckReturnValue
/*  965:     */   public String trimLeadingFrom(CharSequence sequence)
/*  966:     */   {
/*  967:1223 */     int len = sequence.length();
/*  968:1224 */     for (int first = 0; first < len; first++) {
/*  969:1225 */       if (!matches(sequence.charAt(first))) {
/*  970:1226 */         return sequence.subSequence(first, len).toString();
/*  971:     */       }
/*  972:     */     }
/*  973:1229 */     return "";
/*  974:     */   }
/*  975:     */   
/*  976:     */   @CheckReturnValue
/*  977:     */   public String trimTrailingFrom(CharSequence sequence)
/*  978:     */   {
/*  979:1242 */     int len = sequence.length();
/*  980:1243 */     for (int last = len - 1; last >= 0; last--) {
/*  981:1244 */       if (!matches(sequence.charAt(last))) {
/*  982:1245 */         return sequence.subSequence(0, last + 1).toString();
/*  983:     */       }
/*  984:     */     }
/*  985:1248 */     return "";
/*  986:     */   }
/*  987:     */   
/*  988:     */   @CheckReturnValue
/*  989:     */   public String collapseFrom(CharSequence sequence, char replacement)
/*  990:     */   {
/*  991:1272 */     int len = sequence.length();
/*  992:1273 */     for (int i = 0; i < len; i++)
/*  993:     */     {
/*  994:1274 */       char c = sequence.charAt(i);
/*  995:1275 */       if (matches(c)) {
/*  996:1276 */         if ((c == replacement) && ((i == len - 1) || (!matches(sequence.charAt(i + 1)))))
/*  997:     */         {
/*  998:1279 */           i++;
/*  999:     */         }
/* 1000:     */         else
/* 1001:     */         {
/* 1002:1281 */           StringBuilder builder = new StringBuilder(len).append(sequence.subSequence(0, i)).append(replacement);
/* 1003:     */           
/* 1004:     */ 
/* 1005:1284 */           return finishCollapseFrom(sequence, i + 1, len, replacement, builder, true);
/* 1006:     */         }
/* 1007:     */       }
/* 1008:     */     }
/* 1009:1289 */     return sequence.toString();
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   @CheckReturnValue
/* 1013:     */   public String trimAndCollapseFrom(CharSequence sequence, char replacement)
/* 1014:     */   {
/* 1015:1300 */     int len = sequence.length();
/* 1016:1304 */     for (int first = 0; (first < len) && (matches(sequence.charAt(first))); first++) {}
/* 1017:1305 */     for (int last = len - 1; (last > first) && (matches(sequence.charAt(last))); last--) {}
/* 1018:1307 */     return (first == 0) && (last == len - 1) ? collapseFrom(sequence, replacement) : finishCollapseFrom(sequence, first, last + 1, replacement, new StringBuilder(last + 1 - first), false);
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   private String finishCollapseFrom(CharSequence sequence, int start, int end, char replacement, StringBuilder builder, boolean inMatchingGroup)
/* 1022:     */   {
/* 1023:1318 */     for (int i = start; i < end; i++)
/* 1024:     */     {
/* 1025:1319 */       char c = sequence.charAt(i);
/* 1026:1320 */       if (matches(c))
/* 1027:     */       {
/* 1028:1321 */         if (!inMatchingGroup)
/* 1029:     */         {
/* 1030:1322 */           builder.append(replacement);
/* 1031:1323 */           inMatchingGroup = true;
/* 1032:     */         }
/* 1033:     */       }
/* 1034:     */       else
/* 1035:     */       {
/* 1036:1326 */         builder.append(c);
/* 1037:1327 */         inMatchingGroup = false;
/* 1038:     */       }
/* 1039:     */     }
/* 1040:1330 */     return builder.toString();
/* 1041:     */   }
/* 1042:     */   
/* 1043:     */   @Deprecated
/* 1044:     */   public boolean apply(Character character)
/* 1045:     */   {
/* 1046:1340 */     return matches(character.charValue());
/* 1047:     */   }
/* 1048:     */   
/* 1049:     */   public String toString()
/* 1050:     */   {
/* 1051:1349 */     return this.description;
/* 1052:     */   }
/* 1053:     */   
/* 1054:1358 */   static final int WHITESPACE_SHIFT = Integer.numberOfLeadingZeros(" 　\r   　 \013　   　 \t     \f 　 　　 \n 　".length() - 1);
/* 1055:1371 */   public static final CharMatcher WHITESPACE = new FastMatcher("WHITESPACE")
/* 1056:     */   {
/* 1057:     */     public boolean matches(char c)
/* 1058:     */     {
/* 1059:1374 */       return " 　\r   　 \013　   　 \t     \f 　 　　 \n 　".charAt(1682554634 * c >>> WHITESPACE_SHIFT) == c;
/* 1060:     */     }
/* 1061:     */     
/* 1062:     */     @GwtIncompatible("java.util.BitSet")
/* 1063:     */     void setBits(BitSet table)
/* 1064:     */     {
/* 1065:1380 */       for (int i = 0; i < " 　\r   　 \013　   　 \t     \f 　 　　 \n 　".length(); i++) {
/* 1066:1381 */         table.set(" 　\r   　 \013　   　 \t     \f 　 　　 \n 　".charAt(i));
/* 1067:     */       }
/* 1068:     */     }
/* 1069:     */   };
/* 1070:     */   
/* 1071:     */   public abstract boolean matches(char paramChar);
/* 1072:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.CharMatcher
 * JD-Core Version:    0.7.0.1
 */
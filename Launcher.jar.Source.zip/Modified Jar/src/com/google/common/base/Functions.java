/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Map;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ public final class Functions
/*  11:    */ {
/*  12:    */   public static Function<Object, String> toStringFunction()
/*  13:    */   {
/*  14: 56 */     return ToStringFunction.INSTANCE;
/*  15:    */   }
/*  16:    */   
/*  17:    */   private static enum ToStringFunction
/*  18:    */     implements Function<Object, String>
/*  19:    */   {
/*  20: 61 */     INSTANCE;
/*  21:    */     
/*  22:    */     private ToStringFunction() {}
/*  23:    */     
/*  24:    */     public String apply(Object o)
/*  25:    */     {
/*  26: 65 */       Preconditions.checkNotNull(o);
/*  27: 66 */       return o.toString();
/*  28:    */     }
/*  29:    */     
/*  30:    */     public String toString()
/*  31:    */     {
/*  32: 70 */       return "toString";
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <E> Function<E, E> identity()
/*  37:    */   {
/*  38: 80 */     return IdentityFunction.INSTANCE;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private static enum IdentityFunction
/*  42:    */     implements Function<Object, Object>
/*  43:    */   {
/*  44: 85 */     INSTANCE;
/*  45:    */     
/*  46:    */     private IdentityFunction() {}
/*  47:    */     
/*  48:    */     @Nullable
/*  49:    */     public Object apply(@Nullable Object o)
/*  50:    */     {
/*  51: 90 */       return o;
/*  52:    */     }
/*  53:    */     
/*  54:    */     public String toString()
/*  55:    */     {
/*  56: 94 */       return "identity";
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static <K, V> Function<K, V> forMap(Map<K, V> map)
/*  61:    */   {
/*  62:108 */     return new FunctionForMapNoDefault(map);
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static class FunctionForMapNoDefault<K, V>
/*  66:    */     implements Function<K, V>, Serializable
/*  67:    */   {
/*  68:    */     final Map<K, V> map;
/*  69:    */     private static final long serialVersionUID = 0L;
/*  70:    */     
/*  71:    */     FunctionForMapNoDefault(Map<K, V> map)
/*  72:    */     {
/*  73:115 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*  74:    */     }
/*  75:    */     
/*  76:    */     public V apply(@Nullable K key)
/*  77:    */     {
/*  78:120 */       V result = this.map.get(key);
/*  79:121 */       Preconditions.checkArgument((result != null) || (this.map.containsKey(key)), "Key '%s' not present in map", new Object[] { key });
/*  80:122 */       return result;
/*  81:    */     }
/*  82:    */     
/*  83:    */     public boolean equals(@Nullable Object o)
/*  84:    */     {
/*  85:126 */       if ((o instanceof FunctionForMapNoDefault))
/*  86:    */       {
/*  87:127 */         FunctionForMapNoDefault<?, ?> that = (FunctionForMapNoDefault)o;
/*  88:128 */         return this.map.equals(that.map);
/*  89:    */       }
/*  90:130 */       return false;
/*  91:    */     }
/*  92:    */     
/*  93:    */     public int hashCode()
/*  94:    */     {
/*  95:134 */       return this.map.hashCode();
/*  96:    */     }
/*  97:    */     
/*  98:    */     public String toString()
/*  99:    */     {
/* 100:138 */       return "forMap(" + this.map + ")";
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static <K, V> Function<K, V> forMap(Map<K, ? extends V> map, @Nullable V defaultValue)
/* 105:    */   {
/* 106:155 */     return new ForMapWithDefault(map, defaultValue);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static class ForMapWithDefault<K, V>
/* 110:    */     implements Function<K, V>, Serializable
/* 111:    */   {
/* 112:    */     final Map<K, ? extends V> map;
/* 113:    */     final V defaultValue;
/* 114:    */     private static final long serialVersionUID = 0L;
/* 115:    */     
/* 116:    */     ForMapWithDefault(Map<K, ? extends V> map, @Nullable V defaultValue)
/* 117:    */     {
/* 118:163 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 119:164 */       this.defaultValue = defaultValue;
/* 120:    */     }
/* 121:    */     
/* 122:    */     public V apply(@Nullable K key)
/* 123:    */     {
/* 124:169 */       V result = this.map.get(key);
/* 125:170 */       return (result != null) || (this.map.containsKey(key)) ? result : this.defaultValue;
/* 126:    */     }
/* 127:    */     
/* 128:    */     public boolean equals(@Nullable Object o)
/* 129:    */     {
/* 130:174 */       if ((o instanceof ForMapWithDefault))
/* 131:    */       {
/* 132:175 */         ForMapWithDefault<?, ?> that = (ForMapWithDefault)o;
/* 133:176 */         return (this.map.equals(that.map)) && (Objects.equal(this.defaultValue, that.defaultValue));
/* 134:    */       }
/* 135:178 */       return false;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public int hashCode()
/* 139:    */     {
/* 140:182 */       return Objects.hashCode(new Object[] { this.map, this.defaultValue });
/* 141:    */     }
/* 142:    */     
/* 143:    */     public String toString()
/* 144:    */     {
/* 145:186 */       return "forMap(" + this.map + ", defaultValue=" + this.defaultValue + ")";
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static <A, B, C> Function<A, C> compose(Function<B, C> g, Function<A, ? extends B> f)
/* 150:    */   {
/* 151:202 */     return new FunctionComposition(g, f);
/* 152:    */   }
/* 153:    */   
/* 154:    */   private static class FunctionComposition<A, B, C>
/* 155:    */     implements Function<A, C>, Serializable
/* 156:    */   {
/* 157:    */     private final Function<B, C> g;
/* 158:    */     private final Function<A, ? extends B> f;
/* 159:    */     private static final long serialVersionUID = 0L;
/* 160:    */     
/* 161:    */     public FunctionComposition(Function<B, C> g, Function<A, ? extends B> f)
/* 162:    */     {
/* 163:210 */       this.g = ((Function)Preconditions.checkNotNull(g));
/* 164:211 */       this.f = ((Function)Preconditions.checkNotNull(f));
/* 165:    */     }
/* 166:    */     
/* 167:    */     public C apply(@Nullable A a)
/* 168:    */     {
/* 169:216 */       return this.g.apply(this.f.apply(a));
/* 170:    */     }
/* 171:    */     
/* 172:    */     public boolean equals(@Nullable Object obj)
/* 173:    */     {
/* 174:220 */       if ((obj instanceof FunctionComposition))
/* 175:    */       {
/* 176:221 */         FunctionComposition<?, ?, ?> that = (FunctionComposition)obj;
/* 177:222 */         return (this.f.equals(that.f)) && (this.g.equals(that.g));
/* 178:    */       }
/* 179:224 */       return false;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int hashCode()
/* 183:    */     {
/* 184:228 */       return this.f.hashCode() ^ this.g.hashCode();
/* 185:    */     }
/* 186:    */     
/* 187:    */     public String toString()
/* 188:    */     {
/* 189:232 */       return this.g + "(" + this.f + ")";
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static <T> Function<T, Boolean> forPredicate(Predicate<T> predicate)
/* 194:    */   {
/* 195:245 */     return new PredicateFunction(predicate, null);
/* 196:    */   }
/* 197:    */   
/* 198:    */   private static class PredicateFunction<T>
/* 199:    */     implements Function<T, Boolean>, Serializable
/* 200:    */   {
/* 201:    */     private final Predicate<T> predicate;
/* 202:    */     private static final long serialVersionUID = 0L;
/* 203:    */     
/* 204:    */     private PredicateFunction(Predicate<T> predicate)
/* 205:    */     {
/* 206:253 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/* 207:    */     }
/* 208:    */     
/* 209:    */     public Boolean apply(@Nullable T t)
/* 210:    */     {
/* 211:258 */       return Boolean.valueOf(this.predicate.apply(t));
/* 212:    */     }
/* 213:    */     
/* 214:    */     public boolean equals(@Nullable Object obj)
/* 215:    */     {
/* 216:262 */       if ((obj instanceof PredicateFunction))
/* 217:    */       {
/* 218:263 */         PredicateFunction<?> that = (PredicateFunction)obj;
/* 219:264 */         return this.predicate.equals(that.predicate);
/* 220:    */       }
/* 221:266 */       return false;
/* 222:    */     }
/* 223:    */     
/* 224:    */     public int hashCode()
/* 225:    */     {
/* 226:270 */       return this.predicate.hashCode();
/* 227:    */     }
/* 228:    */     
/* 229:    */     public String toString()
/* 230:    */     {
/* 231:274 */       return "forPredicate(" + this.predicate + ")";
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static <E> Function<Object, E> constant(@Nullable E value)
/* 236:    */   {
/* 237:287 */     return new ConstantFunction(value);
/* 238:    */   }
/* 239:    */   
/* 240:    */   private static class ConstantFunction<E>
/* 241:    */     implements Function<Object, E>, Serializable
/* 242:    */   {
/* 243:    */     private final E value;
/* 244:    */     private static final long serialVersionUID = 0L;
/* 245:    */     
/* 246:    */     public ConstantFunction(@Nullable E value)
/* 247:    */     {
/* 248:294 */       this.value = value;
/* 249:    */     }
/* 250:    */     
/* 251:    */     public E apply(@Nullable Object from)
/* 252:    */     {
/* 253:299 */       return this.value;
/* 254:    */     }
/* 255:    */     
/* 256:    */     public boolean equals(@Nullable Object obj)
/* 257:    */     {
/* 258:303 */       if ((obj instanceof ConstantFunction))
/* 259:    */       {
/* 260:304 */         ConstantFunction<?> that = (ConstantFunction)obj;
/* 261:305 */         return Objects.equal(this.value, that.value);
/* 262:    */       }
/* 263:307 */       return false;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public int hashCode()
/* 267:    */     {
/* 268:311 */       return this.value == null ? 0 : this.value.hashCode();
/* 269:    */     }
/* 270:    */     
/* 271:    */     public String toString()
/* 272:    */     {
/* 273:315 */       return "constant(" + this.value + ")";
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   @Beta
/* 278:    */   public static <T> Function<Object, T> forSupplier(Supplier<T> supplier)
/* 279:    */   {
/* 280:329 */     return new SupplierFunction(supplier, null);
/* 281:    */   }
/* 282:    */   
/* 283:    */   private static class SupplierFunction<T>
/* 284:    */     implements Function<Object, T>, Serializable
/* 285:    */   {
/* 286:    */     private final Supplier<T> supplier;
/* 287:    */     private static final long serialVersionUID = 0L;
/* 288:    */     
/* 289:    */     private SupplierFunction(Supplier<T> supplier)
/* 290:    */     {
/* 291:338 */       this.supplier = ((Supplier)Preconditions.checkNotNull(supplier));
/* 292:    */     }
/* 293:    */     
/* 294:    */     public T apply(@Nullable Object input)
/* 295:    */     {
/* 296:342 */       return this.supplier.get();
/* 297:    */     }
/* 298:    */     
/* 299:    */     public boolean equals(@Nullable Object obj)
/* 300:    */     {
/* 301:346 */       if ((obj instanceof SupplierFunction))
/* 302:    */       {
/* 303:347 */         SupplierFunction<?> that = (SupplierFunction)obj;
/* 304:348 */         return this.supplier.equals(that.supplier);
/* 305:    */       }
/* 306:350 */       return false;
/* 307:    */     }
/* 308:    */     
/* 309:    */     public int hashCode()
/* 310:    */     {
/* 311:354 */       return this.supplier.hashCode();
/* 312:    */     }
/* 313:    */     
/* 314:    */     public String toString()
/* 315:    */     {
/* 316:358 */       return "forSupplier(" + this.supplier + ")";
/* 317:    */     }
/* 318:    */   }
/* 319:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Functions
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.nio.charset.Charset;
/*  6:   */ 
/*  7:   */ @GwtCompatible(emulated=true)
/*  8:   */ public final class Charsets
/*  9:   */ {
/* 10:   */   @GwtIncompatible("Non-UTF-8 Charset")
/* 11:46 */   public static final Charset US_ASCII = Charset.forName("US-ASCII");
/* 12:   */   @GwtIncompatible("Non-UTF-8 Charset")
/* 13:53 */   public static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
/* 14:59 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/* 15:   */   @GwtIncompatible("Non-UTF-8 Charset")
/* 16:66 */   public static final Charset UTF_16BE = Charset.forName("UTF-16BE");
/* 17:   */   @GwtIncompatible("Non-UTF-8 Charset")
/* 18:73 */   public static final Charset UTF_16LE = Charset.forName("UTF-16LE");
/* 19:   */   @GwtIncompatible("Non-UTF-8 Charset")
/* 20:81 */   public static final Charset UTF_16 = Charset.forName("UTF-16");
/* 21:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Charsets
 * JD-Core Version:    0.7.0.1
 */
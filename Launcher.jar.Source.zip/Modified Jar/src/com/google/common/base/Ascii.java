/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ public final class Ascii
/*   9:    */ {
/*  10:    */   public static final byte NUL = 0;
/*  11:    */   public static final byte SOH = 1;
/*  12:    */   public static final byte STX = 2;
/*  13:    */   public static final byte ETX = 3;
/*  14:    */   public static final byte EOT = 4;
/*  15:    */   public static final byte ENQ = 5;
/*  16:    */   public static final byte ACK = 6;
/*  17:    */   public static final byte BEL = 7;
/*  18:    */   public static final byte BS = 8;
/*  19:    */   public static final byte HT = 9;
/*  20:    */   public static final byte LF = 10;
/*  21:    */   public static final byte NL = 10;
/*  22:    */   public static final byte VT = 11;
/*  23:    */   public static final byte FF = 12;
/*  24:    */   public static final byte CR = 13;
/*  25:    */   public static final byte SO = 14;
/*  26:    */   public static final byte SI = 15;
/*  27:    */   public static final byte DLE = 16;
/*  28:    */   public static final byte DC1 = 17;
/*  29:    */   public static final byte XON = 17;
/*  30:    */   public static final byte DC2 = 18;
/*  31:    */   public static final byte DC3 = 19;
/*  32:    */   public static final byte XOFF = 19;
/*  33:    */   public static final byte DC4 = 20;
/*  34:    */   public static final byte NAK = 21;
/*  35:    */   public static final byte SYN = 22;
/*  36:    */   public static final byte ETB = 23;
/*  37:    */   public static final byte CAN = 24;
/*  38:    */   public static final byte EM = 25;
/*  39:    */   public static final byte SUB = 26;
/*  40:    */   public static final byte ESC = 27;
/*  41:    */   public static final byte FS = 28;
/*  42:    */   public static final byte GS = 29;
/*  43:    */   public static final byte RS = 30;
/*  44:    */   public static final byte US = 31;
/*  45:    */   public static final byte SP = 32;
/*  46:    */   public static final byte SPACE = 32;
/*  47:    */   public static final byte DEL = 127;
/*  48:    */   public static final char MIN = '\000';
/*  49:    */   public static final char MAX = '';
/*  50:    */   
/*  51:    */   public static String toLowerCase(String string)
/*  52:    */   {
/*  53:438 */     int length = string.length();
/*  54:439 */     for (int i = 0; i < length; i++) {
/*  55:440 */       if (isUpperCase(string.charAt(i)))
/*  56:    */       {
/*  57:441 */         char[] chars = string.toCharArray();
/*  58:442 */         for (; i < length; i++)
/*  59:    */         {
/*  60:443 */           char c = chars[i];
/*  61:444 */           if (isUpperCase(c)) {
/*  62:445 */             chars[i] = ((char)(c ^ 0x20));
/*  63:    */           }
/*  64:    */         }
/*  65:448 */         return String.valueOf(chars);
/*  66:    */       }
/*  67:    */     }
/*  68:451 */     return string;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static String toLowerCase(CharSequence chars)
/*  72:    */   {
/*  73:462 */     if ((chars instanceof String)) {
/*  74:463 */       return toLowerCase((String)chars);
/*  75:    */     }
/*  76:465 */     int length = chars.length();
/*  77:466 */     StringBuilder builder = new StringBuilder(length);
/*  78:467 */     for (int i = 0; i < length; i++) {
/*  79:468 */       builder.append(toLowerCase(chars.charAt(i)));
/*  80:    */     }
/*  81:470 */     return builder.toString();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static char toLowerCase(char c)
/*  85:    */   {
/*  86:478 */     return isUpperCase(c) ? (char)(c ^ 0x20) : c;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static String toUpperCase(String string)
/*  90:    */   {
/*  91:487 */     int length = string.length();
/*  92:488 */     for (int i = 0; i < length; i++) {
/*  93:489 */       if (isLowerCase(string.charAt(i)))
/*  94:    */       {
/*  95:490 */         char[] chars = string.toCharArray();
/*  96:491 */         for (; i < length; i++)
/*  97:    */         {
/*  98:492 */           char c = chars[i];
/*  99:493 */           if (isLowerCase(c)) {
/* 100:494 */             chars[i] = ((char)(c & 0x5F));
/* 101:    */           }
/* 102:    */         }
/* 103:497 */         return String.valueOf(chars);
/* 104:    */       }
/* 105:    */     }
/* 106:500 */     return string;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static String toUpperCase(CharSequence chars)
/* 110:    */   {
/* 111:511 */     if ((chars instanceof String)) {
/* 112:512 */       return toUpperCase((String)chars);
/* 113:    */     }
/* 114:514 */     int length = chars.length();
/* 115:515 */     StringBuilder builder = new StringBuilder(length);
/* 116:516 */     for (int i = 0; i < length; i++) {
/* 117:517 */       builder.append(toUpperCase(chars.charAt(i)));
/* 118:    */     }
/* 119:519 */     return builder.toString();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static char toUpperCase(char c)
/* 123:    */   {
/* 124:527 */     return isLowerCase(c) ? (char)(c & 0x5F) : c;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static boolean isLowerCase(char c)
/* 128:    */   {
/* 129:538 */     return (c >= 'a') && (c <= 'z');
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static boolean isUpperCase(char c)
/* 133:    */   {
/* 134:547 */     return (c >= 'A') && (c <= 'Z');
/* 135:    */   }
/* 136:    */   
/* 137:    */   @CheckReturnValue
/* 138:    */   @Beta
/* 139:    */   public static String truncate(CharSequence seq, int maxLength, String truncationIndicator)
/* 140:    */   {
/* 141:585 */     Preconditions.checkNotNull(seq);
/* 142:    */     
/* 143:    */ 
/* 144:588 */     int truncationLength = maxLength - truncationIndicator.length();
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:592 */     Preconditions.checkArgument(truncationLength >= 0, "maxLength (%s) must be >= length of the truncation indicator (%s)", new Object[] { Integer.valueOf(maxLength), Integer.valueOf(truncationIndicator.length()) });
/* 149:596 */     if (seq.length() <= maxLength)
/* 150:    */     {
/* 151:597 */       String string = seq.toString();
/* 152:598 */       if (string.length() <= maxLength) {
/* 153:599 */         return string;
/* 154:    */       }
/* 155:602 */       seq = string;
/* 156:    */     }
/* 157:605 */     return truncationIndicator;
/* 158:    */   }
/* 159:    */   
/* 160:    */   @Beta
/* 161:    */   public static boolean equalsIgnoreCase(CharSequence s1, CharSequence s2)
/* 162:    */   {
/* 163:634 */     int length = s1.length();
/* 164:635 */     if (s1 == s2) {
/* 165:636 */       return true;
/* 166:    */     }
/* 167:638 */     if (length != s2.length()) {
/* 168:639 */       return false;
/* 169:    */     }
/* 170:641 */     for (int i = 0; i < length; i++)
/* 171:    */     {
/* 172:642 */       char c1 = s1.charAt(i);
/* 173:643 */       char c2 = s2.charAt(i);
/* 174:644 */       if (c1 != c2)
/* 175:    */       {
/* 176:647 */         int alphaIndex = getAlphaIndex(c1);
/* 177:650 */         if ((alphaIndex >= 26) || (alphaIndex != getAlphaIndex(c2))) {
/* 178:653 */           return false;
/* 179:    */         }
/* 180:    */       }
/* 181:    */     }
/* 182:655 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:    */   private static int getAlphaIndex(char c)
/* 186:    */   {
/* 187:665 */     return (char)((c | 0x20) - 'a');
/* 188:    */   }
/* 189:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Ascii
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.lang.ref.WeakReference;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ @GwtCompatible(emulated=true)
/*  8:   */ final class Platform
/*  9:   */ {
/* 10:   */   static long systemNanoTime()
/* 11:   */   {
/* 12:34 */     return System.nanoTime();
/* 13:   */   }
/* 14:   */   
/* 15:   */   static CharMatcher precomputeCharMatcher(CharMatcher matcher)
/* 16:   */   {
/* 17:38 */     return matcher.precomputedInternal();
/* 18:   */   }
/* 19:   */   
/* 20:   */   static <T extends Enum<T>> Optional<T> getEnumIfPresent(Class<T> enumClass, String value)
/* 21:   */   {
/* 22:42 */     WeakReference<? extends Enum<?>> ref = (WeakReference)Enums.getEnumConstants(enumClass).get(value);
/* 23:43 */     return ref == null ? Optional.absent() : Optional.of(enumClass.cast(ref.get()));
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Platform
 * JD-Core Version:    0.7.0.1
 */
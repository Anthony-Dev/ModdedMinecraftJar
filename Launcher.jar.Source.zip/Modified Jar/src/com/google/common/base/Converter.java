/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public abstract class Converter<A, B>
/*  12:    */   implements Function<A, B>
/*  13:    */ {
/*  14:    */   private final boolean handleNullAutomatically;
/*  15:    */   private transient Converter<B, A> reverse;
/*  16:    */   
/*  17:    */   protected Converter()
/*  18:    */   {
/*  19:103 */     this(true);
/*  20:    */   }
/*  21:    */   
/*  22:    */   Converter(boolean handleNullAutomatically)
/*  23:    */   {
/*  24:110 */     this.handleNullAutomatically = handleNullAutomatically;
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected abstract B doForward(A paramA);
/*  28:    */   
/*  29:    */   protected abstract A doBackward(B paramB);
/*  30:    */   
/*  31:    */   @Nullable
/*  32:    */   public final B convert(@Nullable A a)
/*  33:    */   {
/*  34:147 */     return correctedDoForward(a);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @Nullable
/*  38:    */   B correctedDoForward(@Nullable A a)
/*  39:    */   {
/*  40:152 */     if (this.handleNullAutomatically) {
/*  41:154 */       return a == null ? null : Preconditions.checkNotNull(doForward(a));
/*  42:    */     }
/*  43:156 */     return doForward(a);
/*  44:    */   }
/*  45:    */   
/*  46:    */   @Nullable
/*  47:    */   A correctedDoBackward(@Nullable B b)
/*  48:    */   {
/*  49:162 */     if (this.handleNullAutomatically) {
/*  50:164 */       return b == null ? null : Preconditions.checkNotNull(doBackward(b));
/*  51:    */     }
/*  52:166 */     return doBackward(b);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Iterable<B> convertAll(final Iterable<? extends A> fromIterable)
/*  56:    */   {
/*  57:179 */     Preconditions.checkNotNull(fromIterable, "fromIterable");
/*  58:180 */     new Iterable()
/*  59:    */     {
/*  60:    */       public Iterator<B> iterator()
/*  61:    */       {
/*  62:182 */         new Iterator()
/*  63:    */         {
/*  64:183 */           private final Iterator<? extends A> fromIterator = Converter.1.this.val$fromIterable.iterator();
/*  65:    */           
/*  66:    */           public boolean hasNext()
/*  67:    */           {
/*  68:187 */             return this.fromIterator.hasNext();
/*  69:    */           }
/*  70:    */           
/*  71:    */           public B next()
/*  72:    */           {
/*  73:192 */             return Converter.this.convert(this.fromIterator.next());
/*  74:    */           }
/*  75:    */           
/*  76:    */           public void remove()
/*  77:    */           {
/*  78:197 */             this.fromIterator.remove();
/*  79:    */           }
/*  80:    */         };
/*  81:    */       }
/*  82:    */     };
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Converter<B, A> reverse()
/*  86:    */   {
/*  87:212 */     Converter<B, A> result = this.reverse;
/*  88:213 */     return result == null ? (this.reverse = new ReverseConverter(this)) : result;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static final class ReverseConverter<A, B>
/*  92:    */     extends Converter<B, A>
/*  93:    */     implements Serializable
/*  94:    */   {
/*  95:    */     final Converter<A, B> original;
/*  96:    */     private static final long serialVersionUID = 0L;
/*  97:    */     
/*  98:    */     ReverseConverter(Converter<A, B> original)
/*  99:    */     {
/* 100:221 */       this.original = original;
/* 101:    */     }
/* 102:    */     
/* 103:    */     protected A doForward(B b)
/* 104:    */     {
/* 105:233 */       throw new AssertionError();
/* 106:    */     }
/* 107:    */     
/* 108:    */     protected B doBackward(A a)
/* 109:    */     {
/* 110:238 */       throw new AssertionError();
/* 111:    */     }
/* 112:    */     
/* 113:    */     @Nullable
/* 114:    */     A correctedDoForward(@Nullable B b)
/* 115:    */     {
/* 116:244 */       return this.original.correctedDoBackward(b);
/* 117:    */     }
/* 118:    */     
/* 119:    */     @Nullable
/* 120:    */     B correctedDoBackward(@Nullable A a)
/* 121:    */     {
/* 122:250 */       return this.original.correctedDoForward(a);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public Converter<A, B> reverse()
/* 126:    */     {
/* 127:255 */       return this.original;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equals(@Nullable Object object)
/* 131:    */     {
/* 132:260 */       if ((object instanceof ReverseConverter))
/* 133:    */       {
/* 134:261 */         ReverseConverter<?, ?> that = (ReverseConverter)object;
/* 135:262 */         return this.original.equals(that.original);
/* 136:    */       }
/* 137:264 */       return false;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public int hashCode()
/* 141:    */     {
/* 142:269 */       return this.original.hashCode() ^ 0xFFFFFFFF;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public String toString()
/* 146:    */     {
/* 147:274 */       return this.original + ".reverse()";
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public <C> Converter<A, C> andThen(Converter<B, C> secondConverter)
/* 152:    */   {
/* 153:288 */     return new ConverterComposition(this, (Converter)Preconditions.checkNotNull(secondConverter));
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static final class ConverterComposition<A, B, C>
/* 157:    */     extends Converter<A, C>
/* 158:    */     implements Serializable
/* 159:    */   {
/* 160:    */     final Converter<A, B> first;
/* 161:    */     final Converter<B, C> second;
/* 162:    */     private static final long serialVersionUID = 0L;
/* 163:    */     
/* 164:    */     ConverterComposition(Converter<A, B> first, Converter<B, C> second)
/* 165:    */     {
/* 166:297 */       this.first = first;
/* 167:298 */       this.second = second;
/* 168:    */     }
/* 169:    */     
/* 170:    */     protected C doForward(A a)
/* 171:    */     {
/* 172:310 */       throw new AssertionError();
/* 173:    */     }
/* 174:    */     
/* 175:    */     protected A doBackward(C c)
/* 176:    */     {
/* 177:315 */       throw new AssertionError();
/* 178:    */     }
/* 179:    */     
/* 180:    */     @Nullable
/* 181:    */     C correctedDoForward(@Nullable A a)
/* 182:    */     {
/* 183:321 */       return this.second.correctedDoForward(this.first.correctedDoForward(a));
/* 184:    */     }
/* 185:    */     
/* 186:    */     @Nullable
/* 187:    */     A correctedDoBackward(@Nullable C c)
/* 188:    */     {
/* 189:327 */       return this.first.correctedDoBackward(this.second.correctedDoBackward(c));
/* 190:    */     }
/* 191:    */     
/* 192:    */     public boolean equals(@Nullable Object object)
/* 193:    */     {
/* 194:332 */       if ((object instanceof ConverterComposition))
/* 195:    */       {
/* 196:333 */         ConverterComposition<?, ?, ?> that = (ConverterComposition)object;
/* 197:334 */         return (this.first.equals(that.first)) && (this.second.equals(that.second));
/* 198:    */       }
/* 199:337 */       return false;
/* 200:    */     }
/* 201:    */     
/* 202:    */     public int hashCode()
/* 203:    */     {
/* 204:342 */       return 31 * this.first.hashCode() + this.second.hashCode();
/* 205:    */     }
/* 206:    */     
/* 207:    */     public String toString()
/* 208:    */     {
/* 209:347 */       return this.first + ".andThen(" + this.second + ")";
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   @Deprecated
/* 214:    */   @Nullable
/* 215:    */   public final B apply(@Nullable A a)
/* 216:    */   {
/* 217:360 */     return convert(a);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean equals(@Nullable Object object)
/* 221:    */   {
/* 222:376 */     return super.equals(object);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static <A, B> Converter<A, B> from(Function<? super A, ? extends B> forwardFunction, Function<? super B, ? extends A> backwardFunction)
/* 226:    */   {
/* 227:398 */     return new FunctionBasedConverter(forwardFunction, backwardFunction, null);
/* 228:    */   }
/* 229:    */   
/* 230:    */   private static final class FunctionBasedConverter<A, B>
/* 231:    */     extends Converter<A, B>
/* 232:    */     implements Serializable
/* 233:    */   {
/* 234:    */     private final Function<? super A, ? extends B> forwardFunction;
/* 235:    */     private final Function<? super B, ? extends A> backwardFunction;
/* 236:    */     
/* 237:    */     private FunctionBasedConverter(Function<? super A, ? extends B> forwardFunction, Function<? super B, ? extends A> backwardFunction)
/* 238:    */     {
/* 239:409 */       this.forwardFunction = ((Function)Preconditions.checkNotNull(forwardFunction));
/* 240:410 */       this.backwardFunction = ((Function)Preconditions.checkNotNull(backwardFunction));
/* 241:    */     }
/* 242:    */     
/* 243:    */     protected B doForward(A a)
/* 244:    */     {
/* 245:415 */       return this.forwardFunction.apply(a);
/* 246:    */     }
/* 247:    */     
/* 248:    */     protected A doBackward(B b)
/* 249:    */     {
/* 250:420 */       return this.backwardFunction.apply(b);
/* 251:    */     }
/* 252:    */     
/* 253:    */     public boolean equals(@Nullable Object object)
/* 254:    */     {
/* 255:425 */       if ((object instanceof FunctionBasedConverter))
/* 256:    */       {
/* 257:426 */         FunctionBasedConverter<?, ?> that = (FunctionBasedConverter)object;
/* 258:427 */         return (this.forwardFunction.equals(that.forwardFunction)) && (this.backwardFunction.equals(that.backwardFunction));
/* 259:    */       }
/* 260:430 */       return false;
/* 261:    */     }
/* 262:    */     
/* 263:    */     public int hashCode()
/* 264:    */     {
/* 265:435 */       return this.forwardFunction.hashCode() * 31 + this.backwardFunction.hashCode();
/* 266:    */     }
/* 267:    */     
/* 268:    */     public String toString()
/* 269:    */     {
/* 270:440 */       return "Converter.from(" + this.forwardFunction + ", " + this.backwardFunction + ")";
/* 271:    */     }
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static <T> Converter<T, T> identity()
/* 275:    */   {
/* 276:449 */     return IdentityConverter.INSTANCE;
/* 277:    */   }
/* 278:    */   
/* 279:    */   private static final class IdentityConverter<T>
/* 280:    */     extends Converter<T, T>
/* 281:    */     implements Serializable
/* 282:    */   {
/* 283:457 */     static final IdentityConverter INSTANCE = new IdentityConverter();
/* 284:    */     private static final long serialVersionUID = 0L;
/* 285:    */     
/* 286:    */     protected T doForward(T t)
/* 287:    */     {
/* 288:461 */       return t;
/* 289:    */     }
/* 290:    */     
/* 291:    */     protected T doBackward(T t)
/* 292:    */     {
/* 293:466 */       return t;
/* 294:    */     }
/* 295:    */     
/* 296:    */     public IdentityConverter<T> reverse()
/* 297:    */     {
/* 298:471 */       return this;
/* 299:    */     }
/* 300:    */     
/* 301:    */     public <S> Converter<T, S> andThen(Converter<T, S> otherConverter)
/* 302:    */     {
/* 303:476 */       return (Converter)Preconditions.checkNotNull(otherConverter, "otherConverter");
/* 304:    */     }
/* 305:    */     
/* 306:    */     public String toString()
/* 307:    */     {
/* 308:486 */       return "Converter.identity()";
/* 309:    */     }
/* 310:    */     
/* 311:    */     private Object readResolve()
/* 312:    */     {
/* 313:490 */       return INSTANCE;
/* 314:    */     }
/* 315:    */   }
/* 316:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.base.Converter
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nullable;
/*  4:   */ 
/*  5:   */ public final class SettableFuture<V>
/*  6:   */   extends AbstractFuture<V>
/*  7:   */ {
/*  8:   */   public static <V> SettableFuture<V> create()
/*  9:   */   {
/* 10:34 */     return new SettableFuture();
/* 11:   */   }
/* 12:   */   
/* 13:   */   public boolean set(@Nullable V value)
/* 14:   */   {
/* 15:53 */     return super.set(value);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean setException(Throwable throwable)
/* 19:   */   {
/* 20:68 */     return super.setException(throwable);
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.SettableFuture
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.ArrayDeque;
/*   5:    */ import java.util.Queue;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.Logger;
/*   9:    */ import javax.annotation.concurrent.GuardedBy;
/*  10:    */ 
/*  11:    */ final class SerializingExecutor
/*  12:    */   implements Executor
/*  13:    */ {
/*  14: 47 */   private static final Logger log = Logger.getLogger(SerializingExecutor.class.getName());
/*  15:    */   private final Executor executor;
/*  16:    */   @GuardedBy("internalLock")
/*  17: 54 */   private final Queue<Runnable> waitQueue = new ArrayDeque();
/*  18:    */   @GuardedBy("internalLock")
/*  19: 65 */   private boolean isThreadScheduled = false;
/*  20: 69 */   private final TaskRunner taskRunner = new TaskRunner(null);
/*  21:    */   
/*  22:    */   public SerializingExecutor(Executor executor)
/*  23:    */   {
/*  24: 77 */     Preconditions.checkNotNull(executor, "'executor' must not be null.");
/*  25: 78 */     this.executor = executor;
/*  26:    */   }
/*  27:    */   
/*  28: 81 */   private final Object internalLock = new Object()
/*  29:    */   {
/*  30:    */     public String toString()
/*  31:    */     {
/*  32: 83 */       return "SerializingExecutor lock: " + super.toString();
/*  33:    */     }
/*  34:    */   };
/*  35:    */   
/*  36:    */   public void execute(Runnable r)
/*  37:    */   {
/*  38: 93 */     Preconditions.checkNotNull(r, "'r' must not be null.");
/*  39: 94 */     boolean scheduleTaskRunner = false;
/*  40: 95 */     synchronized (this.internalLock)
/*  41:    */     {
/*  42: 96 */       this.waitQueue.add(r);
/*  43: 98 */       if (!this.isThreadScheduled)
/*  44:    */       {
/*  45: 99 */         this.isThreadScheduled = true;
/*  46:100 */         scheduleTaskRunner = true;
/*  47:    */       }
/*  48:    */     }
/*  49:103 */     if (scheduleTaskRunner)
/*  50:    */     {
/*  51:104 */       boolean threw = true;
/*  52:    */       try
/*  53:    */       {
/*  54:106 */         this.executor.execute(this.taskRunner);
/*  55:107 */         threw = false;
/*  56:    */       }
/*  57:    */       finally
/*  58:    */       {
/*  59:109 */         if (threw) {
/*  60:110 */           synchronized (this.internalLock)
/*  61:    */           {
/*  62:115 */             this.isThreadScheduled = false;
/*  63:    */           }
/*  64:    */         }
/*  65:    */       }
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   private class TaskRunner
/*  70:    */     implements Runnable
/*  71:    */   {
/*  72:    */     private TaskRunner() {}
/*  73:    */     
/*  74:    */     public void run()
/*  75:    */     {
/*  76:132 */       boolean stillRunning = true;
/*  77:    */       try
/*  78:    */       {
/*  79:    */         for (;;)
/*  80:    */         {
/*  81:135 */           Preconditions.checkState(SerializingExecutor.this.isThreadScheduled);
/*  82:    */           Runnable nextToRun;
/*  83:137 */           synchronized (SerializingExecutor.this.internalLock)
/*  84:    */           {
/*  85:138 */             nextToRun = (Runnable)SerializingExecutor.this.waitQueue.poll();
/*  86:139 */             if (nextToRun == null)
/*  87:    */             {
/*  88:140 */               SerializingExecutor.this.isThreadScheduled = false;
/*  89:141 */               stillRunning = false;
/*  90:142 */               break;
/*  91:    */             }
/*  92:    */           }
/*  93:    */           try
/*  94:    */           {
/*  95:148 */             nextToRun.run();
/*  96:    */           }
/*  97:    */           catch (RuntimeException e)
/*  98:    */           {
/*  99:151 */             SerializingExecutor.log.log(Level.SEVERE, "Exception while executing runnable " + nextToRun, e);
/* 100:    */           }
/* 101:    */         }
/* 102:    */       }
/* 103:    */       finally
/* 104:    */       {
/* 105:156 */         if (stillRunning) {
/* 106:160 */           synchronized (SerializingExecutor.this.internalLock)
/* 107:    */           {
/* 108:161 */             SerializingExecutor.this.isThreadScheduled = false;
/* 109:    */           }
/* 110:    */         }
/* 111:    */       }
/* 112:    */     }
/* 113:    */   }
/* 114:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.SerializingExecutor
 * JD-Core Version:    0.7.0.1
 */
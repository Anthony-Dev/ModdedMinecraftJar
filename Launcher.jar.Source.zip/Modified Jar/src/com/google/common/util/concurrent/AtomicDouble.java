/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.ObjectInputStream;
/*   5:    */ import java.io.ObjectOutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*   8:    */ 
/*   9:    */ public class AtomicDouble
/*  10:    */   extends Number
/*  11:    */   implements Serializable
/*  12:    */ {
/*  13:    */   private static final long serialVersionUID = 0L;
/*  14:    */   private volatile transient long value;
/*  15: 60 */   private static final AtomicLongFieldUpdater<AtomicDouble> updater = AtomicLongFieldUpdater.newUpdater(AtomicDouble.class, "value");
/*  16:    */   
/*  17:    */   public AtomicDouble(double initialValue)
/*  18:    */   {
/*  19: 69 */     this.value = Double.doubleToRawLongBits(initialValue);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public AtomicDouble() {}
/*  23:    */   
/*  24:    */   public final double get()
/*  25:    */   {
/*  26: 85 */     return Double.longBitsToDouble(this.value);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public final void set(double newValue)
/*  30:    */   {
/*  31: 94 */     long next = Double.doubleToRawLongBits(newValue);
/*  32: 95 */     this.value = next;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public final void lazySet(double newValue)
/*  36:    */   {
/*  37:104 */     set(newValue);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public final double getAndSet(double newValue)
/*  41:    */   {
/*  42:117 */     long next = Double.doubleToRawLongBits(newValue);
/*  43:118 */     return Double.longBitsToDouble(updater.getAndSet(this, next));
/*  44:    */   }
/*  45:    */   
/*  46:    */   public final boolean compareAndSet(double expect, double update)
/*  47:    */   {
/*  48:132 */     return updater.compareAndSet(this, Double.doubleToRawLongBits(expect), Double.doubleToRawLongBits(update));
/*  49:    */   }
/*  50:    */   
/*  51:    */   public final boolean weakCompareAndSet(double expect, double update)
/*  52:    */   {
/*  53:153 */     return updater.weakCompareAndSet(this, Double.doubleToRawLongBits(expect), Double.doubleToRawLongBits(update));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public final double getAndAdd(double delta)
/*  57:    */   {
/*  58:    */     for (;;)
/*  59:    */     {
/*  60:166 */       long current = this.value;
/*  61:167 */       double currentVal = Double.longBitsToDouble(current);
/*  62:168 */       double nextVal = currentVal + delta;
/*  63:169 */       long next = Double.doubleToRawLongBits(nextVal);
/*  64:170 */       if (updater.compareAndSet(this, current, next)) {
/*  65:171 */         return currentVal;
/*  66:    */       }
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public final double addAndGet(double delta)
/*  71:    */   {
/*  72:    */     for (;;)
/*  73:    */     {
/*  74:184 */       long current = this.value;
/*  75:185 */       double currentVal = Double.longBitsToDouble(current);
/*  76:186 */       double nextVal = currentVal + delta;
/*  77:187 */       long next = Double.doubleToRawLongBits(nextVal);
/*  78:188 */       if (updater.compareAndSet(this, current, next)) {
/*  79:189 */         return nextVal;
/*  80:    */       }
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String toString()
/*  85:    */   {
/*  86:199 */     return Double.toString(get());
/*  87:    */   }
/*  88:    */   
/*  89:    */   public int intValue()
/*  90:    */   {
/*  91:207 */     return (int)get();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public long longValue()
/*  95:    */   {
/*  96:215 */     return get();
/*  97:    */   }
/*  98:    */   
/*  99:    */   public float floatValue()
/* 100:    */   {
/* 101:223 */     return (float)get();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public double doubleValue()
/* 105:    */   {
/* 106:230 */     return get();
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void writeObject(ObjectOutputStream s)
/* 110:    */     throws IOException
/* 111:    */   {
/* 112:240 */     s.defaultWriteObject();
/* 113:    */     
/* 114:242 */     s.writeDouble(get());
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void readObject(ObjectInputStream s)
/* 118:    */     throws IOException, ClassNotFoundException
/* 119:    */   {
/* 120:250 */     s.defaultReadObject();
/* 121:    */     
/* 122:252 */     set(s.readDouble());
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AtomicDouble
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ 
/*  6:   */ @Beta
/*  7:   */ @GwtCompatible
/*  8:   */ public final class Runnables
/*  9:   */ {
/* 10:31 */   private static final Runnable EMPTY_RUNNABLE = new Runnable()
/* 11:   */   {
/* 12:   */     public void run() {}
/* 13:   */   };
/* 14:   */   
/* 15:   */   public static Runnable doNothing()
/* 16:   */   {
/* 17:41 */     return EMPTY_RUNNABLE;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Runnables
 * JD-Core Version:    0.7.0.1
 */
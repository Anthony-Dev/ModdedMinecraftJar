/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.concurrent.CancellationException;
/*   5:    */ import java.util.concurrent.ExecutionException;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import java.util.concurrent.TimeoutException;
/*   9:    */ import java.util.concurrent.locks.AbstractQueuedSynchronizer;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ public abstract class AbstractFuture<V>
/*  13:    */   implements ListenableFuture<V>
/*  14:    */ {
/*  15: 68 */   private final Sync<V> sync = new Sync();
/*  16: 71 */   private final ExecutionList executionList = new ExecutionList();
/*  17:    */   
/*  18:    */   public V get(long timeout, TimeUnit unit)
/*  19:    */     throws InterruptedException, TimeoutException, ExecutionException
/*  20:    */   {
/*  21: 96 */     return this.sync.get(unit.toNanos(timeout));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public V get()
/*  25:    */     throws InterruptedException, ExecutionException
/*  26:    */   {
/*  27:116 */     return this.sync.get();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean isDone()
/*  31:    */   {
/*  32:121 */     return this.sync.isDone();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public boolean isCancelled()
/*  36:    */   {
/*  37:126 */     return this.sync.isCancelled();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean cancel(boolean mayInterruptIfRunning)
/*  41:    */   {
/*  42:131 */     if (!this.sync.cancel(mayInterruptIfRunning)) {
/*  43:132 */       return false;
/*  44:    */     }
/*  45:134 */     this.executionList.execute();
/*  46:135 */     if (mayInterruptIfRunning) {
/*  47:136 */       interruptTask();
/*  48:    */     }
/*  49:138 */     return true;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected void interruptTask() {}
/*  53:    */   
/*  54:    */   protected final boolean wasInterrupted()
/*  55:    */   {
/*  56:160 */     return this.sync.wasInterrupted();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void addListener(Runnable listener, Executor exec)
/*  60:    */   {
/*  61:170 */     this.executionList.add(listener, exec);
/*  62:    */   }
/*  63:    */   
/*  64:    */   protected boolean set(@Nullable V value)
/*  65:    */   {
/*  66:183 */     boolean result = this.sync.set(value);
/*  67:184 */     if (result) {
/*  68:185 */       this.executionList.execute();
/*  69:    */     }
/*  70:187 */     return result;
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected boolean setException(Throwable throwable)
/*  74:    */   {
/*  75:200 */     boolean result = this.sync.setException((Throwable)Preconditions.checkNotNull(throwable));
/*  76:201 */     if (result) {
/*  77:202 */       this.executionList.execute();
/*  78:    */     }
/*  79:204 */     return result;
/*  80:    */   }
/*  81:    */   
/*  82:    */   static final class Sync<V>
/*  83:    */     extends AbstractQueuedSynchronizer
/*  84:    */   {
/*  85:    */     private static final long serialVersionUID = 0L;
/*  86:    */     static final int RUNNING = 0;
/*  87:    */     static final int COMPLETING = 1;
/*  88:    */     static final int COMPLETED = 2;
/*  89:    */     static final int CANCELLED = 4;
/*  90:    */     static final int INTERRUPTED = 8;
/*  91:    */     private V value;
/*  92:    */     private Throwable exception;
/*  93:    */     
/*  94:    */     protected int tryAcquireShared(int ignored)
/*  95:    */     {
/*  96:243 */       if (isDone()) {
/*  97:244 */         return 1;
/*  98:    */       }
/*  99:246 */       return -1;
/* 100:    */     }
/* 101:    */     
/* 102:    */     protected boolean tryReleaseShared(int finalState)
/* 103:    */     {
/* 104:255 */       setState(finalState);
/* 105:256 */       return true;
/* 106:    */     }
/* 107:    */     
/* 108:    */     V get(long nanos)
/* 109:    */       throws TimeoutException, CancellationException, ExecutionException, InterruptedException
/* 110:    */     {
/* 111:268 */       if (!tryAcquireSharedNanos(-1, nanos)) {
/* 112:269 */         throw new TimeoutException("Timeout waiting for task.");
/* 113:    */       }
/* 114:272 */       return getValue();
/* 115:    */     }
/* 116:    */     
/* 117:    */     V get()
/* 118:    */       throws CancellationException, ExecutionException, InterruptedException
/* 119:    */     {
/* 120:285 */       acquireSharedInterruptibly(-1);
/* 121:286 */       return getValue();
/* 122:    */     }
/* 123:    */     
/* 124:    */     private V getValue()
/* 125:    */       throws CancellationException, ExecutionException
/* 126:    */     {
/* 127:295 */       int state = getState();
/* 128:296 */       switch (state)
/* 129:    */       {
/* 130:    */       case 2: 
/* 131:298 */         if (this.exception != null) {
/* 132:299 */           throw new ExecutionException(this.exception);
/* 133:    */         }
/* 134:301 */         return this.value;
/* 135:    */       case 4: 
/* 136:    */       case 8: 
/* 137:306 */         throw AbstractFuture.cancellationExceptionWithCause("Task was cancelled.", this.exception);
/* 138:    */       }
/* 139:310 */       throw new IllegalStateException("Error, synchronizer in invalid state: " + state);
/* 140:    */     }
/* 141:    */     
/* 142:    */     boolean isDone()
/* 143:    */     {
/* 144:320 */       return (getState() & 0xE) != 0;
/* 145:    */     }
/* 146:    */     
/* 147:    */     boolean isCancelled()
/* 148:    */     {
/* 149:327 */       return (getState() & 0xC) != 0;
/* 150:    */     }
/* 151:    */     
/* 152:    */     boolean wasInterrupted()
/* 153:    */     {
/* 154:334 */       return getState() == 8;
/* 155:    */     }
/* 156:    */     
/* 157:    */     boolean set(@Nullable V v)
/* 158:    */     {
/* 159:341 */       return complete(v, null, 2);
/* 160:    */     }
/* 161:    */     
/* 162:    */     boolean setException(Throwable t)
/* 163:    */     {
/* 164:348 */       return complete(null, t, 2);
/* 165:    */     }
/* 166:    */     
/* 167:    */     boolean cancel(boolean interrupt)
/* 168:    */     {
/* 169:355 */       return complete(null, null, interrupt ? 8 : 4);
/* 170:    */     }
/* 171:    */     
/* 172:    */     private boolean complete(@Nullable V v, @Nullable Throwable t, int finalState)
/* 173:    */     {
/* 174:372 */       boolean doCompletion = compareAndSetState(0, 1);
/* 175:373 */       if (doCompletion)
/* 176:    */       {
/* 177:376 */         this.value = v;
/* 178:    */         
/* 179:378 */         this.exception = ((finalState & 0xC) != 0 ? new CancellationException("Future.cancel() was called.") : t);
/* 180:    */         
/* 181:380 */         releaseShared(finalState);
/* 182:    */       }
/* 183:381 */       else if (getState() == 1)
/* 184:    */       {
/* 185:384 */         acquireShared(-1);
/* 186:    */       }
/* 187:386 */       return doCompletion;
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   static final CancellationException cancellationExceptionWithCause(@Nullable String message, @Nullable Throwable cause)
/* 192:    */   {
/* 193:392 */     CancellationException exception = new CancellationException(message);
/* 194:393 */     exception.initCause(cause);
/* 195:394 */     return exception;
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractFuture
 * JD-Core Version:    0.7.0.1
 */
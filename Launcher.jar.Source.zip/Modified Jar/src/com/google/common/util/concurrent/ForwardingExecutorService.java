/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ForwardingObject;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.concurrent.Callable;
/*   7:    */ import java.util.concurrent.ExecutionException;
/*   8:    */ import java.util.concurrent.ExecutorService;
/*   9:    */ import java.util.concurrent.Future;
/*  10:    */ import java.util.concurrent.TimeUnit;
/*  11:    */ import java.util.concurrent.TimeoutException;
/*  12:    */ 
/*  13:    */ public abstract class ForwardingExecutorService
/*  14:    */   extends ForwardingObject
/*  15:    */   implements ExecutorService
/*  16:    */ {
/*  17:    */   protected abstract ExecutorService delegate();
/*  18:    */   
/*  19:    */   public boolean awaitTermination(long timeout, TimeUnit unit)
/*  20:    */     throws InterruptedException
/*  21:    */   {
/*  22: 50 */     return delegate().awaitTermination(timeout, unit);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks)
/*  26:    */     throws InterruptedException
/*  27:    */   {
/*  28: 56 */     return delegate().invokeAll(tasks);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
/*  32:    */     throws InterruptedException
/*  33:    */   {
/*  34: 63 */     return delegate().invokeAll(tasks, timeout, unit);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks)
/*  38:    */     throws InterruptedException, ExecutionException
/*  39:    */   {
/*  40: 69 */     return delegate().invokeAny(tasks);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
/*  44:    */     throws InterruptedException, ExecutionException, TimeoutException
/*  45:    */   {
/*  46: 76 */     return delegate().invokeAny(tasks, timeout, unit);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isShutdown()
/*  50:    */   {
/*  51: 81 */     return delegate().isShutdown();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isTerminated()
/*  55:    */   {
/*  56: 86 */     return delegate().isTerminated();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void shutdown()
/*  60:    */   {
/*  61: 91 */     delegate().shutdown();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public List<Runnable> shutdownNow()
/*  65:    */   {
/*  66: 96 */     return delegate().shutdownNow();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void execute(Runnable command)
/*  70:    */   {
/*  71:101 */     delegate().execute(command);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public <T> Future<T> submit(Callable<T> task)
/*  75:    */   {
/*  76:105 */     return delegate().submit(task);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Future<?> submit(Runnable task)
/*  80:    */   {
/*  81:110 */     return delegate().submit(task);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public <T> Future<T> submit(Runnable task, T result)
/*  85:    */   {
/*  86:115 */     return delegate().submit(task, result);
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingExecutorService
 * JD-Core Version:    0.7.0.1
 */
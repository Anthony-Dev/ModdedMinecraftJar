/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Maps;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.concurrent.ConcurrentHashMap;
/*  11:    */ import java.util.concurrent.atomic.AtomicLong;
/*  12:    */ 
/*  13:    */ @GwtCompatible
/*  14:    */ public final class AtomicLongMap<K>
/*  15:    */ {
/*  16:    */   private final ConcurrentHashMap<K, AtomicLong> map;
/*  17:    */   private transient Map<K, Long> asMap;
/*  18:    */   
/*  19:    */   private AtomicLongMap(ConcurrentHashMap<K, AtomicLong> map)
/*  20:    */   {
/*  21: 58 */     this.map = ((ConcurrentHashMap)Preconditions.checkNotNull(map));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static <K> AtomicLongMap<K> create()
/*  25:    */   {
/*  26: 65 */     return new AtomicLongMap(new ConcurrentHashMap());
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <K> AtomicLongMap<K> create(Map<? extends K, ? extends Long> m)
/*  30:    */   {
/*  31: 72 */     AtomicLongMap<K> result = create();
/*  32: 73 */     result.putAll(m);
/*  33: 74 */     return result;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public long get(K key)
/*  37:    */   {
/*  38: 82 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  39: 83 */     return atomic == null ? 0L : atomic.get();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public long incrementAndGet(K key)
/*  43:    */   {
/*  44: 90 */     return addAndGet(key, 1L);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public long decrementAndGet(K key)
/*  48:    */   {
/*  49: 97 */     return addAndGet(key, -1L);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public long addAndGet(K key, long delta)
/*  53:    */   {
/*  54:106 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  55:107 */     if (atomic == null)
/*  56:    */     {
/*  57:108 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(delta));
/*  58:109 */       if (atomic == null) {
/*  59:110 */         return delta;
/*  60:    */       }
/*  61:    */     }
/*  62:    */     for (;;)
/*  63:    */     {
/*  64:116 */       long oldValue = atomic.get();
/*  65:117 */       if (oldValue == 0L)
/*  66:    */       {
/*  67:119 */         if (!this.map.replace(key, atomic, new AtomicLong(delta))) {
/*  68:    */           break;
/*  69:    */         }
/*  70:120 */         return delta;
/*  71:    */       }
/*  72:126 */       long newValue = oldValue + delta;
/*  73:127 */       if (atomic.compareAndSet(oldValue, newValue)) {
/*  74:128 */         return newValue;
/*  75:    */       }
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public long getAndIncrement(K key)
/*  80:    */   {
/*  81:139 */     return getAndAdd(key, 1L);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public long getAndDecrement(K key)
/*  85:    */   {
/*  86:146 */     return getAndAdd(key, -1L);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public long getAndAdd(K key, long delta)
/*  90:    */   {
/*  91:155 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  92:156 */     if (atomic == null)
/*  93:    */     {
/*  94:157 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(delta));
/*  95:158 */       if (atomic == null) {
/*  96:159 */         return 0L;
/*  97:    */       }
/*  98:    */     }
/*  99:    */     for (;;)
/* 100:    */     {
/* 101:165 */       long oldValue = atomic.get();
/* 102:166 */       if (oldValue == 0L)
/* 103:    */       {
/* 104:168 */         if (!this.map.replace(key, atomic, new AtomicLong(delta))) {
/* 105:    */           break;
/* 106:    */         }
/* 107:169 */         return 0L;
/* 108:    */       }
/* 109:175 */       long newValue = oldValue + delta;
/* 110:176 */       if (atomic.compareAndSet(oldValue, newValue)) {
/* 111:177 */         return oldValue;
/* 112:    */       }
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   public long put(K key, long newValue)
/* 117:    */   {
/* 118:190 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 119:191 */     if (atomic == null)
/* 120:    */     {
/* 121:192 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(newValue));
/* 122:193 */       if (atomic == null) {
/* 123:194 */         return 0L;
/* 124:    */       }
/* 125:    */     }
/* 126:    */     for (;;)
/* 127:    */     {
/* 128:200 */       long oldValue = atomic.get();
/* 129:201 */       if (oldValue == 0L)
/* 130:    */       {
/* 131:203 */         if (!this.map.replace(key, atomic, new AtomicLong(newValue))) {
/* 132:    */           break;
/* 133:    */         }
/* 134:204 */         return 0L;
/* 135:    */       }
/* 136:210 */       if (atomic.compareAndSet(oldValue, newValue)) {
/* 137:211 */         return oldValue;
/* 138:    */       }
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void putAll(Map<? extends K, ? extends Long> m)
/* 143:    */   {
/* 144:225 */     for (Map.Entry<? extends K, ? extends Long> entry : m.entrySet()) {
/* 145:226 */       put(entry.getKey(), ((Long)entry.getValue()).longValue());
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   public long remove(K key)
/* 150:    */   {
/* 151:235 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 152:236 */     if (atomic == null) {
/* 153:237 */       return 0L;
/* 154:    */     }
/* 155:    */     for (;;)
/* 156:    */     {
/* 157:241 */       long oldValue = atomic.get();
/* 158:242 */       if ((oldValue == 0L) || (atomic.compareAndSet(oldValue, 0L)))
/* 159:    */       {
/* 160:244 */         this.map.remove(key, atomic);
/* 161:    */         
/* 162:246 */         return oldValue;
/* 163:    */       }
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void removeAllZeros()
/* 168:    */   {
/* 169:258 */     for (K key : this.map.keySet())
/* 170:    */     {
/* 171:259 */       AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 172:260 */       if ((atomic != null) && (atomic.get() == 0L)) {
/* 173:261 */         this.map.remove(key, atomic);
/* 174:    */       }
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public long sum()
/* 179:    */   {
/* 180:272 */     long sum = 0L;
/* 181:273 */     for (AtomicLong value : this.map.values()) {
/* 182:274 */       sum += value.get();
/* 183:    */     }
/* 184:276 */     return sum;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public Map<K, Long> asMap()
/* 188:    */   {
/* 189:285 */     Map<K, Long> result = this.asMap;
/* 190:286 */     return result == null ? (this.asMap = createAsMap()) : result;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private Map<K, Long> createAsMap()
/* 194:    */   {
/* 195:290 */     Collections.unmodifiableMap(Maps.transformValues(this.map, new Function()
/* 196:    */     {
/* 197:    */       public Long apply(AtomicLong atomic)
/* 198:    */       {
/* 199:294 */         return Long.valueOf(atomic.get());
/* 200:    */       }
/* 201:    */     }));
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean containsKey(Object key)
/* 205:    */   {
/* 206:303 */     return this.map.containsKey(key);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public int size()
/* 210:    */   {
/* 211:311 */     return this.map.size();
/* 212:    */   }
/* 213:    */   
/* 214:    */   public boolean isEmpty()
/* 215:    */   {
/* 216:318 */     return this.map.isEmpty();
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void clear()
/* 220:    */   {
/* 221:328 */     this.map.clear();
/* 222:    */   }
/* 223:    */   
/* 224:    */   public String toString()
/* 225:    */   {
/* 226:333 */     return this.map.toString();
/* 227:    */   }
/* 228:    */   
/* 229:    */   long putIfAbsent(K key, long newValue)
/* 230:    */   {
/* 231:    */     AtomicLong atomic;
/* 232:    */     long oldValue;
/* 233:    */     do
/* 234:    */     {
/* 235:366 */       atomic = (AtomicLong)this.map.get(key);
/* 236:367 */       if (atomic == null)
/* 237:    */       {
/* 238:368 */         atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(newValue));
/* 239:369 */         if (atomic == null) {
/* 240:370 */           return 0L;
/* 241:    */         }
/* 242:    */       }
/* 243:375 */       oldValue = atomic.get();
/* 244:376 */       if (oldValue != 0L) {
/* 245:    */         break;
/* 246:    */       }
/* 247:378 */     } while (!this.map.replace(key, atomic, new AtomicLong(newValue)));
/* 248:379 */     return 0L;
/* 249:    */     
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:385 */     return oldValue;
/* 255:    */   }
/* 256:    */   
/* 257:    */   boolean replace(K key, long expectedOldValue, long newValue)
/* 258:    */   {
/* 259:398 */     if (expectedOldValue == 0L) {
/* 260:399 */       return putIfAbsent(key, newValue) == 0L;
/* 261:    */     }
/* 262:401 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 263:402 */     return atomic == null ? false : atomic.compareAndSet(expectedOldValue, newValue);
/* 264:    */   }
/* 265:    */   
/* 266:    */   boolean remove(K key, long value)
/* 267:    */   {
/* 268:411 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 269:412 */     if (atomic == null) {
/* 270:413 */       return false;
/* 271:    */     }
/* 272:416 */     long oldValue = atomic.get();
/* 273:417 */     if (oldValue != value) {
/* 274:418 */       return false;
/* 275:    */     }
/* 276:421 */     if ((oldValue == 0L) || (atomic.compareAndSet(oldValue, 0L)))
/* 277:    */     {
/* 278:423 */       this.map.remove(key, atomic);
/* 279:    */       
/* 280:425 */       return true;
/* 281:    */     }
/* 282:429 */     return false;
/* 283:    */   }
/* 284:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.AtomicLongMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.base.Throwables;
/*   5:    */ import com.google.common.collect.ImmutableList;
/*   6:    */ import com.google.common.collect.ImmutableList.Builder;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.concurrent.Callable;
/*  10:    */ import java.util.concurrent.ExecutionException;
/*  11:    */ import java.util.concurrent.ExecutorService;
/*  12:    */ import java.util.concurrent.Executors;
/*  13:    */ import java.util.concurrent.Future;
/*  14:    */ import java.util.concurrent.TimeUnit;
/*  15:    */ import java.util.concurrent.TimeoutException;
/*  16:    */ 
/*  17:    */ abstract class WrappingExecutorService
/*  18:    */   implements ExecutorService
/*  19:    */ {
/*  20:    */   private final ExecutorService delegate;
/*  21:    */   
/*  22:    */   protected WrappingExecutorService(ExecutorService delegate)
/*  23:    */   {
/*  24: 50 */     this.delegate = ((ExecutorService)Preconditions.checkNotNull(delegate));
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected abstract <T> Callable<T> wrapTask(Callable<T> paramCallable);
/*  28:    */   
/*  29:    */   protected Runnable wrapTask(Runnable command)
/*  30:    */   {
/*  31: 65 */     final Callable<Object> wrapped = wrapTask(Executors.callable(command, null));
/*  32:    */     
/*  33: 67 */     new Runnable()
/*  34:    */     {
/*  35:    */       public void run()
/*  36:    */       {
/*  37:    */         try
/*  38:    */         {
/*  39: 70 */           wrapped.call();
/*  40:    */         }
/*  41:    */         catch (Exception e)
/*  42:    */         {
/*  43: 72 */           Throwables.propagate(e);
/*  44:    */         }
/*  45:    */       }
/*  46:    */     };
/*  47:    */   }
/*  48:    */   
/*  49:    */   private final <T> ImmutableList<Callable<T>> wrapTasks(Collection<? extends Callable<T>> tasks)
/*  50:    */   {
/*  51: 85 */     ImmutableList.Builder<Callable<T>> builder = ImmutableList.builder();
/*  52: 86 */     for (Callable<T> task : tasks) {
/*  53: 87 */       builder.add(wrapTask(task));
/*  54:    */     }
/*  55: 89 */     return builder.build();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public final void execute(Runnable command)
/*  59:    */   {
/*  60: 95 */     this.delegate.execute(wrapTask(command));
/*  61:    */   }
/*  62:    */   
/*  63:    */   public final <T> Future<T> submit(Callable<T> task)
/*  64:    */   {
/*  65:100 */     return this.delegate.submit(wrapTask((Callable)Preconditions.checkNotNull(task)));
/*  66:    */   }
/*  67:    */   
/*  68:    */   public final Future<?> submit(Runnable task)
/*  69:    */   {
/*  70:105 */     return this.delegate.submit(wrapTask(task));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public final <T> Future<T> submit(Runnable task, T result)
/*  74:    */   {
/*  75:110 */     return this.delegate.submit(wrapTask(task), result);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public final <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks)
/*  79:    */     throws InterruptedException
/*  80:    */   {
/*  81:116 */     return this.delegate.invokeAll(wrapTasks(tasks));
/*  82:    */   }
/*  83:    */   
/*  84:    */   public final <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
/*  85:    */     throws InterruptedException
/*  86:    */   {
/*  87:123 */     return this.delegate.invokeAll(wrapTasks(tasks), timeout, unit);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public final <T> T invokeAny(Collection<? extends Callable<T>> tasks)
/*  91:    */     throws InterruptedException, ExecutionException
/*  92:    */   {
/*  93:129 */     return this.delegate.invokeAny(wrapTasks(tasks));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public final <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
/*  97:    */     throws InterruptedException, ExecutionException, TimeoutException
/*  98:    */   {
/*  99:136 */     return this.delegate.invokeAny(wrapTasks(tasks), timeout, unit);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public final void shutdown()
/* 103:    */   {
/* 104:143 */     this.delegate.shutdown();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public final List<Runnable> shutdownNow()
/* 108:    */   {
/* 109:148 */     return this.delegate.shutdownNow();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public final boolean isShutdown()
/* 113:    */   {
/* 114:153 */     return this.delegate.isShutdown();
/* 115:    */   }
/* 116:    */   
/* 117:    */   public final boolean isTerminated()
/* 118:    */   {
/* 119:158 */     return this.delegate.isTerminated();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public final boolean awaitTermination(long timeout, TimeUnit unit)
/* 123:    */     throws InterruptedException
/* 124:    */   {
/* 125:164 */     return this.delegate.awaitTermination(timeout, unit);
/* 126:    */   }
/* 127:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.WrappingExecutorService
 * JD-Core Version:    0.7.0.1
 */
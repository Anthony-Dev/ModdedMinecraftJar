/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.VisibleForTesting;
/*    5:     */ import com.google.common.base.Objects;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import com.google.common.collect.ImmutableSet;
/*    8:     */ import com.google.common.collect.Lists;
/*    9:     */ import com.google.common.collect.MapMaker;
/*   10:     */ import com.google.common.collect.Maps;
/*   11:     */ import com.google.common.collect.Sets;
/*   12:     */ import java.util.ArrayList;
/*   13:     */ import java.util.Arrays;
/*   14:     */ import java.util.Collections;
/*   15:     */ import java.util.EnumMap;
/*   16:     */ import java.util.List;
/*   17:     */ import java.util.Map;
/*   18:     */ import java.util.Map.Entry;
/*   19:     */ import java.util.Set;
/*   20:     */ import java.util.concurrent.ConcurrentMap;
/*   21:     */ import java.util.concurrent.TimeUnit;
/*   22:     */ import java.util.concurrent.locks.ReentrantLock;
/*   23:     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*   24:     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*   25:     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*   26:     */ import java.util.logging.Level;
/*   27:     */ import java.util.logging.Logger;
/*   28:     */ import javax.annotation.Nullable;
/*   29:     */ import javax.annotation.concurrent.ThreadSafe;
/*   30:     */ 
/*   31:     */ @Beta
/*   32:     */ @ThreadSafe
/*   33:     */ public class CycleDetectingLockFactory
/*   34:     */ {
/*   35:     */   @Beta
/*   36:     */   public static abstract enum Policies
/*   37:     */     implements CycleDetectingLockFactory.Policy
/*   38:     */   {
/*   39: 205 */     THROW,  WARN,  DISABLED;
/*   40:     */     
/*   41:     */     private Policies() {}
/*   42:     */   }
/*   43:     */   
/*   44:     */   public static CycleDetectingLockFactory newInstance(Policy policy)
/*   45:     */   {
/*   46: 246 */     return new CycleDetectingLockFactory(policy);
/*   47:     */   }
/*   48:     */   
/*   49:     */   public ReentrantLock newReentrantLock(String lockName)
/*   50:     */   {
/*   51: 253 */     return newReentrantLock(lockName, false);
/*   52:     */   }
/*   53:     */   
/*   54:     */   public ReentrantLock newReentrantLock(String lockName, boolean fair)
/*   55:     */   {
/*   56: 262 */     return this.policy == Policies.DISABLED ? new ReentrantLock(fair) : new CycleDetectingReentrantLock(new LockGraphNode(lockName), fair, null);
/*   57:     */   }
/*   58:     */   
/*   59:     */   public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName)
/*   60:     */   {
/*   61: 271 */     return newReentrantReadWriteLock(lockName, false);
/*   62:     */   }
/*   63:     */   
/*   64:     */   public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName, boolean fair)
/*   65:     */   {
/*   66: 281 */     return this.policy == Policies.DISABLED ? new ReentrantReadWriteLock(fair) : new CycleDetectingReentrantReadWriteLock(new LockGraphNode(lockName), fair, null);
/*   67:     */   }
/*   68:     */   
/*   69: 288 */   private static final ConcurrentMap<Class<? extends Enum>, Map<? extends Enum, LockGraphNode>> lockGraphNodesPerType = new MapMaker().weakKeys().makeMap();
/*   70:     */   
/*   71:     */   public static <E extends Enum<E>> WithExplicitOrdering<E> newInstanceWithExplicitOrdering(Class<E> enumClass, Policy policy)
/*   72:     */   {
/*   73: 298 */     Preconditions.checkNotNull(enumClass);
/*   74: 299 */     Preconditions.checkNotNull(policy);
/*   75:     */     
/*   76: 301 */     Map<E, LockGraphNode> lockGraphNodes = getOrCreateNodes(enumClass);
/*   77:     */     
/*   78: 303 */     return new WithExplicitOrdering(policy, lockGraphNodes);
/*   79:     */   }
/*   80:     */   
/*   81:     */   private static Map<? extends Enum, LockGraphNode> getOrCreateNodes(Class<? extends Enum> clazz)
/*   82:     */   {
/*   83: 308 */     Map<? extends Enum, LockGraphNode> existing = (Map)lockGraphNodesPerType.get(clazz);
/*   84: 310 */     if (existing != null) {
/*   85: 311 */       return existing;
/*   86:     */     }
/*   87: 313 */     Map<? extends Enum, LockGraphNode> created = createNodes(clazz);
/*   88: 314 */     existing = (Map)lockGraphNodesPerType.putIfAbsent(clazz, created);
/*   89: 315 */     return (Map)Objects.firstNonNull(existing, created);
/*   90:     */   }
/*   91:     */   
/*   92:     */   @VisibleForTesting
/*   93:     */   static <E extends Enum<E>> Map<E, LockGraphNode> createNodes(Class<E> clazz)
/*   94:     */   {
/*   95: 326 */     EnumMap<E, LockGraphNode> map = Maps.newEnumMap(clazz);
/*   96: 327 */     E[] keys = (Enum[])clazz.getEnumConstants();
/*   97: 328 */     int numKeys = keys.length;
/*   98: 329 */     ArrayList<LockGraphNode> nodes = Lists.newArrayListWithCapacity(numKeys);
/*   99: 332 */     for (E key : keys)
/*  100:     */     {
/*  101: 333 */       LockGraphNode node = new LockGraphNode(getLockName(key));
/*  102: 334 */       nodes.add(node);
/*  103: 335 */       map.put(key, node);
/*  104:     */     }
/*  105: 338 */     for (int i = 1; i < numKeys; i++) {
/*  106: 339 */       ((LockGraphNode)nodes.get(i)).checkAcquiredLocks(Policies.THROW, nodes.subList(0, i));
/*  107:     */     }
/*  108: 342 */     for (int i = 0; i < numKeys - 1; i++) {
/*  109: 343 */       ((LockGraphNode)nodes.get(i)).checkAcquiredLocks(Policies.DISABLED, nodes.subList(i + 1, numKeys));
/*  110:     */     }
/*  111: 346 */     return Collections.unmodifiableMap(map);
/*  112:     */   }
/*  113:     */   
/*  114:     */   private static String getLockName(Enum<?> rank)
/*  115:     */   {
/*  116: 355 */     return rank.getDeclaringClass().getSimpleName() + "." + rank.name();
/*  117:     */   }
/*  118:     */   
/*  119:     */   @Beta
/*  120:     */   public static final class WithExplicitOrdering<E extends Enum<E>>
/*  121:     */     extends CycleDetectingLockFactory
/*  122:     */   {
/*  123:     */     private final Map<E, CycleDetectingLockFactory.LockGraphNode> lockGraphNodes;
/*  124:     */     
/*  125:     */     @VisibleForTesting
/*  126:     */     WithExplicitOrdering(CycleDetectingLockFactory.Policy policy, Map<E, CycleDetectingLockFactory.LockGraphNode> lockGraphNodes)
/*  127:     */     {
/*  128: 428 */       super(null);
/*  129: 429 */       this.lockGraphNodes = lockGraphNodes;
/*  130:     */     }
/*  131:     */     
/*  132:     */     public ReentrantLock newReentrantLock(E rank)
/*  133:     */     {
/*  134: 436 */       return newReentrantLock(rank, false);
/*  135:     */     }
/*  136:     */     
/*  137:     */     public ReentrantLock newReentrantLock(E rank, boolean fair)
/*  138:     */     {
/*  139: 449 */       return this.policy == CycleDetectingLockFactory.Policies.DISABLED ? new ReentrantLock(fair) : new CycleDetectingLockFactory.CycleDetectingReentrantLock(this, (CycleDetectingLockFactory.LockGraphNode)this.lockGraphNodes.get(rank), fair, null);
/*  140:     */     }
/*  141:     */     
/*  142:     */     public ReentrantReadWriteLock newReentrantReadWriteLock(E rank)
/*  143:     */     {
/*  144: 457 */       return newReentrantReadWriteLock(rank, false);
/*  145:     */     }
/*  146:     */     
/*  147:     */     public ReentrantReadWriteLock newReentrantReadWriteLock(E rank, boolean fair)
/*  148:     */     {
/*  149: 471 */       return this.policy == CycleDetectingLockFactory.Policies.DISABLED ? new ReentrantReadWriteLock(fair) : new CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock(this, (CycleDetectingLockFactory.LockGraphNode)this.lockGraphNodes.get(rank), fair, null);
/*  150:     */     }
/*  151:     */   }
/*  152:     */   
/*  153: 479 */   private static final Logger logger = Logger.getLogger(CycleDetectingLockFactory.class.getName());
/*  154:     */   final Policy policy;
/*  155:     */   
/*  156:     */   private CycleDetectingLockFactory(Policy policy)
/*  157:     */   {
/*  158: 485 */     this.policy = ((Policy)Preconditions.checkNotNull(policy));
/*  159:     */   }
/*  160:     */   
/*  161: 496 */   private static final ThreadLocal<ArrayList<LockGraphNode>> acquiredLocks = new ThreadLocal()
/*  162:     */   {
/*  163:     */     protected ArrayList<CycleDetectingLockFactory.LockGraphNode> initialValue()
/*  164:     */     {
/*  165: 499 */       return Lists.newArrayListWithCapacity(3);
/*  166:     */     }
/*  167:     */   };
/*  168:     */   
/*  169:     */   private static class ExampleStackTrace
/*  170:     */     extends IllegalStateException
/*  171:     */   {
/*  172: 519 */     static final StackTraceElement[] EMPTY_STACK_TRACE = new StackTraceElement[0];
/*  173: 522 */     static Set<String> EXCLUDED_CLASS_NAMES = ImmutableSet.of(CycleDetectingLockFactory.class.getName(), ExampleStackTrace.class.getName(), CycleDetectingLockFactory.LockGraphNode.class.getName());
/*  174:     */     
/*  175:     */     ExampleStackTrace(CycleDetectingLockFactory.LockGraphNode node1, CycleDetectingLockFactory.LockGraphNode node2)
/*  176:     */     {
/*  177: 528 */       super();
/*  178: 529 */       StackTraceElement[] origStackTrace = getStackTrace();
/*  179: 530 */       int i = 0;
/*  180: 530 */       for (int n = origStackTrace.length; i < n; i++)
/*  181:     */       {
/*  182: 531 */         if (CycleDetectingLockFactory.WithExplicitOrdering.class.getName().equals(origStackTrace[i].getClassName()))
/*  183:     */         {
/*  184: 534 */           setStackTrace(EMPTY_STACK_TRACE);
/*  185: 535 */           break;
/*  186:     */         }
/*  187: 537 */         if (!EXCLUDED_CLASS_NAMES.contains(origStackTrace[i].getClassName()))
/*  188:     */         {
/*  189: 538 */           setStackTrace((StackTraceElement[])Arrays.copyOfRange(origStackTrace, i, n));
/*  190: 539 */           break;
/*  191:     */         }
/*  192:     */       }
/*  193:     */     }
/*  194:     */   }
/*  195:     */   
/*  196:     */   @Beta
/*  197:     */   public static final class PotentialDeadlockException
/*  198:     */     extends CycleDetectingLockFactory.ExampleStackTrace
/*  199:     */   {
/*  200:     */     private final CycleDetectingLockFactory.ExampleStackTrace conflictingStackTrace;
/*  201:     */     
/*  202:     */     private PotentialDeadlockException(CycleDetectingLockFactory.LockGraphNode node1, CycleDetectingLockFactory.LockGraphNode node2, CycleDetectingLockFactory.ExampleStackTrace conflictingStackTrace)
/*  203:     */     {
/*  204: 577 */       super(node2);
/*  205: 578 */       this.conflictingStackTrace = conflictingStackTrace;
/*  206: 579 */       initCause(conflictingStackTrace);
/*  207:     */     }
/*  208:     */     
/*  209:     */     public CycleDetectingLockFactory.ExampleStackTrace getConflictingStackTrace()
/*  210:     */     {
/*  211: 583 */       return this.conflictingStackTrace;
/*  212:     */     }
/*  213:     */     
/*  214:     */     public String getMessage()
/*  215:     */     {
/*  216: 592 */       StringBuilder message = new StringBuilder(super.getMessage());
/*  217: 593 */       for (Throwable t = this.conflictingStackTrace; t != null; t = t.getCause()) {
/*  218: 594 */         message.append(", ").append(t.getMessage());
/*  219:     */       }
/*  220: 596 */       return message.toString();
/*  221:     */     }
/*  222:     */   }
/*  223:     */   
/*  224:     */   private static class LockGraphNode
/*  225:     */   {
/*  226: 625 */     final Map<LockGraphNode, CycleDetectingLockFactory.ExampleStackTrace> allowedPriorLocks = new MapMaker().weakKeys().makeMap();
/*  227: 632 */     final Map<LockGraphNode, CycleDetectingLockFactory.PotentialDeadlockException> disallowedPriorLocks = new MapMaker().weakKeys().makeMap();
/*  228:     */     final String lockName;
/*  229:     */     
/*  230:     */     LockGraphNode(String lockName)
/*  231:     */     {
/*  232: 638 */       this.lockName = ((String)Preconditions.checkNotNull(lockName));
/*  233:     */     }
/*  234:     */     
/*  235:     */     String getLockName()
/*  236:     */     {
/*  237: 642 */       return this.lockName;
/*  238:     */     }
/*  239:     */     
/*  240:     */     void checkAcquiredLocks(CycleDetectingLockFactory.Policy policy, List<LockGraphNode> acquiredLocks)
/*  241:     */     {
/*  242: 647 */       int i = 0;
/*  243: 647 */       for (int size = acquiredLocks.size(); i < size; i++) {
/*  244: 648 */         checkAcquiredLock(policy, (LockGraphNode)acquiredLocks.get(i));
/*  245:     */       }
/*  246:     */     }
/*  247:     */     
/*  248:     */     void checkAcquiredLock(CycleDetectingLockFactory.Policy policy, LockGraphNode acquiredLock)
/*  249:     */     {
/*  250: 668 */       Preconditions.checkState(this != acquiredLock, "Attempted to acquire multiple locks with the same rank " + acquiredLock.getLockName());
/*  251: 673 */       if (this.allowedPriorLocks.containsKey(acquiredLock)) {
/*  252: 677 */         return;
/*  253:     */       }
/*  254: 679 */       CycleDetectingLockFactory.PotentialDeadlockException previousDeadlockException = (CycleDetectingLockFactory.PotentialDeadlockException)this.disallowedPriorLocks.get(acquiredLock);
/*  255: 681 */       if (previousDeadlockException != null)
/*  256:     */       {
/*  257: 685 */         CycleDetectingLockFactory.PotentialDeadlockException exception = new CycleDetectingLockFactory.PotentialDeadlockException(acquiredLock, this, previousDeadlockException.getConflictingStackTrace(), null);
/*  258:     */         
/*  259:     */ 
/*  260: 688 */         policy.handlePotentialDeadlock(exception);
/*  261: 689 */         return;
/*  262:     */       }
/*  263: 693 */       Set<LockGraphNode> seen = Sets.newIdentityHashSet();
/*  264: 694 */       CycleDetectingLockFactory.ExampleStackTrace path = acquiredLock.findPathTo(this, seen);
/*  265: 696 */       if (path == null)
/*  266:     */       {
/*  267: 705 */         this.allowedPriorLocks.put(acquiredLock, new CycleDetectingLockFactory.ExampleStackTrace(acquiredLock, this));
/*  268:     */       }
/*  269:     */       else
/*  270:     */       {
/*  271: 710 */         CycleDetectingLockFactory.PotentialDeadlockException exception = new CycleDetectingLockFactory.PotentialDeadlockException(acquiredLock, this, path, null);
/*  272:     */         
/*  273: 712 */         this.disallowedPriorLocks.put(acquiredLock, exception);
/*  274: 713 */         policy.handlePotentialDeadlock(exception);
/*  275:     */       }
/*  276:     */     }
/*  277:     */     
/*  278:     */     @Nullable
/*  279:     */     private CycleDetectingLockFactory.ExampleStackTrace findPathTo(LockGraphNode node, Set<LockGraphNode> seen)
/*  280:     */     {
/*  281: 729 */       if (!seen.add(this)) {
/*  282: 730 */         return null;
/*  283:     */       }
/*  284: 732 */       CycleDetectingLockFactory.ExampleStackTrace found = (CycleDetectingLockFactory.ExampleStackTrace)this.allowedPriorLocks.get(node);
/*  285: 733 */       if (found != null) {
/*  286: 734 */         return found;
/*  287:     */       }
/*  288: 738 */       for (Map.Entry<LockGraphNode, CycleDetectingLockFactory.ExampleStackTrace> entry : this.allowedPriorLocks.entrySet())
/*  289:     */       {
/*  290: 739 */         LockGraphNode preAcquiredLock = (LockGraphNode)entry.getKey();
/*  291: 740 */         found = preAcquiredLock.findPathTo(node, seen);
/*  292: 741 */         if (found != null)
/*  293:     */         {
/*  294: 745 */           CycleDetectingLockFactory.ExampleStackTrace path = new CycleDetectingLockFactory.ExampleStackTrace(preAcquiredLock, this);
/*  295:     */           
/*  296: 747 */           path.setStackTrace(((CycleDetectingLockFactory.ExampleStackTrace)entry.getValue()).getStackTrace());
/*  297: 748 */           path.initCause(found);
/*  298: 749 */           return path;
/*  299:     */         }
/*  300:     */       }
/*  301: 752 */       return null;
/*  302:     */     }
/*  303:     */   }
/*  304:     */   
/*  305:     */   private void aboutToAcquire(CycleDetectingLock lock)
/*  306:     */   {
/*  307: 761 */     if (!lock.isAcquiredByCurrentThread())
/*  308:     */     {
/*  309: 762 */       ArrayList<LockGraphNode> acquiredLockList = (ArrayList)acquiredLocks.get();
/*  310: 763 */       LockGraphNode node = lock.getLockGraphNode();
/*  311: 764 */       node.checkAcquiredLocks(this.policy, acquiredLockList);
/*  312: 765 */       acquiredLockList.add(node);
/*  313:     */     }
/*  314:     */   }
/*  315:     */   
/*  316:     */   private void lockStateChanged(CycleDetectingLock lock)
/*  317:     */   {
/*  318: 776 */     if (!lock.isAcquiredByCurrentThread())
/*  319:     */     {
/*  320: 777 */       ArrayList<LockGraphNode> acquiredLockList = (ArrayList)acquiredLocks.get();
/*  321: 778 */       LockGraphNode node = lock.getLockGraphNode();
/*  322: 781 */       for (int i = acquiredLockList.size() - 1; i >= 0; i--) {
/*  323: 782 */         if (acquiredLockList.get(i) == node)
/*  324:     */         {
/*  325: 783 */           acquiredLockList.remove(i);
/*  326: 784 */           break;
/*  327:     */         }
/*  328:     */       }
/*  329:     */     }
/*  330:     */   }
/*  331:     */   
/*  332:     */   final class CycleDetectingReentrantLock
/*  333:     */     extends ReentrantLock
/*  334:     */     implements CycleDetectingLockFactory.CycleDetectingLock
/*  335:     */   {
/*  336:     */     private final CycleDetectingLockFactory.LockGraphNode lockGraphNode;
/*  337:     */     
/*  338:     */     private CycleDetectingReentrantLock(CycleDetectingLockFactory.LockGraphNode lockGraphNode, boolean fair)
/*  339:     */     {
/*  340: 797 */       super();
/*  341: 798 */       this.lockGraphNode = ((CycleDetectingLockFactory.LockGraphNode)Preconditions.checkNotNull(lockGraphNode));
/*  342:     */     }
/*  343:     */     
/*  344:     */     public CycleDetectingLockFactory.LockGraphNode getLockGraphNode()
/*  345:     */     {
/*  346: 805 */       return this.lockGraphNode;
/*  347:     */     }
/*  348:     */     
/*  349:     */     public boolean isAcquiredByCurrentThread()
/*  350:     */     {
/*  351: 810 */       return isHeldByCurrentThread();
/*  352:     */     }
/*  353:     */     
/*  354:     */     public void lock()
/*  355:     */     {
/*  356: 817 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  357:     */       try
/*  358:     */       {
/*  359: 819 */         super.lock();
/*  360:     */       }
/*  361:     */       finally
/*  362:     */       {
/*  363: 821 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  364:     */       }
/*  365:     */     }
/*  366:     */     
/*  367:     */     public void lockInterruptibly()
/*  368:     */       throws InterruptedException
/*  369:     */     {
/*  370: 827 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  371:     */       try
/*  372:     */       {
/*  373: 829 */         super.lockInterruptibly();
/*  374:     */       }
/*  375:     */       finally
/*  376:     */       {
/*  377: 831 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  378:     */       }
/*  379:     */     }
/*  380:     */     
/*  381:     */     public boolean tryLock()
/*  382:     */     {
/*  383: 837 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  384:     */       try
/*  385:     */       {
/*  386: 839 */         return super.tryLock();
/*  387:     */       }
/*  388:     */       finally
/*  389:     */       {
/*  390: 841 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  391:     */       }
/*  392:     */     }
/*  393:     */     
/*  394:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  395:     */       throws InterruptedException
/*  396:     */     {
/*  397: 848 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  398:     */       try
/*  399:     */       {
/*  400: 850 */         return super.tryLock(timeout, unit);
/*  401:     */       }
/*  402:     */       finally
/*  403:     */       {
/*  404: 852 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  405:     */       }
/*  406:     */     }
/*  407:     */     
/*  408:     */     public void unlock()
/*  409:     */     {
/*  410:     */       try
/*  411:     */       {
/*  412: 859 */         super.unlock();
/*  413:     */       }
/*  414:     */       finally
/*  415:     */       {
/*  416: 861 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  417:     */       }
/*  418:     */     }
/*  419:     */   }
/*  420:     */   
/*  421:     */   final class CycleDetectingReentrantReadWriteLock
/*  422:     */     extends ReentrantReadWriteLock
/*  423:     */     implements CycleDetectingLockFactory.CycleDetectingLock
/*  424:     */   {
/*  425:     */     private final CycleDetectingLockFactory.CycleDetectingReentrantReadLock readLock;
/*  426:     */     private final CycleDetectingLockFactory.CycleDetectingReentrantWriteLock writeLock;
/*  427:     */     private final CycleDetectingLockFactory.LockGraphNode lockGraphNode;
/*  428:     */     
/*  429:     */     private CycleDetectingReentrantReadWriteLock(CycleDetectingLockFactory.LockGraphNode lockGraphNode, boolean fair)
/*  430:     */     {
/*  431: 880 */       super();
/*  432: 881 */       this.readLock = new CycleDetectingLockFactory.CycleDetectingReentrantReadLock(CycleDetectingLockFactory.this, this);
/*  433: 882 */       this.writeLock = new CycleDetectingLockFactory.CycleDetectingReentrantWriteLock(CycleDetectingLockFactory.this, this);
/*  434: 883 */       this.lockGraphNode = ((CycleDetectingLockFactory.LockGraphNode)Preconditions.checkNotNull(lockGraphNode));
/*  435:     */     }
/*  436:     */     
/*  437:     */     public ReentrantReadWriteLock.ReadLock readLock()
/*  438:     */     {
/*  439: 890 */       return this.readLock;
/*  440:     */     }
/*  441:     */     
/*  442:     */     public ReentrantReadWriteLock.WriteLock writeLock()
/*  443:     */     {
/*  444: 895 */       return this.writeLock;
/*  445:     */     }
/*  446:     */     
/*  447:     */     public CycleDetectingLockFactory.LockGraphNode getLockGraphNode()
/*  448:     */     {
/*  449: 902 */       return this.lockGraphNode;
/*  450:     */     }
/*  451:     */     
/*  452:     */     public boolean isAcquiredByCurrentThread()
/*  453:     */     {
/*  454: 907 */       return (isWriteLockedByCurrentThread()) || (getReadHoldCount() > 0);
/*  455:     */     }
/*  456:     */   }
/*  457:     */   
/*  458:     */   private class CycleDetectingReentrantReadLock
/*  459:     */     extends ReentrantReadWriteLock.ReadLock
/*  460:     */   {
/*  461:     */     final CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock;
/*  462:     */     
/*  463:     */     CycleDetectingReentrantReadLock(CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock)
/*  464:     */     {
/*  465: 918 */       super();
/*  466: 919 */       this.readWriteLock = readWriteLock;
/*  467:     */     }
/*  468:     */     
/*  469:     */     public void lock()
/*  470:     */     {
/*  471: 924 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  472:     */       try
/*  473:     */       {
/*  474: 926 */         super.lock();
/*  475:     */       }
/*  476:     */       finally
/*  477:     */       {
/*  478: 928 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  479:     */       }
/*  480:     */     }
/*  481:     */     
/*  482:     */     public void lockInterruptibly()
/*  483:     */       throws InterruptedException
/*  484:     */     {
/*  485: 934 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  486:     */       try
/*  487:     */       {
/*  488: 936 */         super.lockInterruptibly();
/*  489:     */       }
/*  490:     */       finally
/*  491:     */       {
/*  492: 938 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  493:     */       }
/*  494:     */     }
/*  495:     */     
/*  496:     */     public boolean tryLock()
/*  497:     */     {
/*  498: 944 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  499:     */       try
/*  500:     */       {
/*  501: 946 */         return super.tryLock();
/*  502:     */       }
/*  503:     */       finally
/*  504:     */       {
/*  505: 948 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  506:     */       }
/*  507:     */     }
/*  508:     */     
/*  509:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  510:     */       throws InterruptedException
/*  511:     */     {
/*  512: 955 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  513:     */       try
/*  514:     */       {
/*  515: 957 */         return super.tryLock(timeout, unit);
/*  516:     */       }
/*  517:     */       finally
/*  518:     */       {
/*  519: 959 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  520:     */       }
/*  521:     */     }
/*  522:     */     
/*  523:     */     public void unlock()
/*  524:     */     {
/*  525:     */       try
/*  526:     */       {
/*  527: 966 */         super.unlock();
/*  528:     */       }
/*  529:     */       finally
/*  530:     */       {
/*  531: 968 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  532:     */       }
/*  533:     */     }
/*  534:     */   }
/*  535:     */   
/*  536:     */   private class CycleDetectingReentrantWriteLock
/*  537:     */     extends ReentrantReadWriteLock.WriteLock
/*  538:     */   {
/*  539:     */     final CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock;
/*  540:     */     
/*  541:     */     CycleDetectingReentrantWriteLock(CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock)
/*  542:     */     {
/*  543: 980 */       super();
/*  544: 981 */       this.readWriteLock = readWriteLock;
/*  545:     */     }
/*  546:     */     
/*  547:     */     public void lock()
/*  548:     */     {
/*  549: 986 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  550:     */       try
/*  551:     */       {
/*  552: 988 */         super.lock();
/*  553:     */       }
/*  554:     */       finally
/*  555:     */       {
/*  556: 990 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  557:     */       }
/*  558:     */     }
/*  559:     */     
/*  560:     */     public void lockInterruptibly()
/*  561:     */       throws InterruptedException
/*  562:     */     {
/*  563: 996 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  564:     */       try
/*  565:     */       {
/*  566: 998 */         super.lockInterruptibly();
/*  567:     */       }
/*  568:     */       finally
/*  569:     */       {
/*  570:1000 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  571:     */       }
/*  572:     */     }
/*  573:     */     
/*  574:     */     public boolean tryLock()
/*  575:     */     {
/*  576:1006 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  577:     */       try
/*  578:     */       {
/*  579:1008 */         return super.tryLock();
/*  580:     */       }
/*  581:     */       finally
/*  582:     */       {
/*  583:1010 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  584:     */       }
/*  585:     */     }
/*  586:     */     
/*  587:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  588:     */       throws InterruptedException
/*  589:     */     {
/*  590:1017 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  591:     */       try
/*  592:     */       {
/*  593:1019 */         return super.tryLock(timeout, unit);
/*  594:     */       }
/*  595:     */       finally
/*  596:     */       {
/*  597:1021 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  598:     */       }
/*  599:     */     }
/*  600:     */     
/*  601:     */     public void unlock()
/*  602:     */     {
/*  603:     */       try
/*  604:     */       {
/*  605:1028 */         super.unlock();
/*  606:     */       }
/*  607:     */       finally
/*  608:     */       {
/*  609:1030 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  610:     */       }
/*  611:     */     }
/*  612:     */   }
/*  613:     */   
/*  614:     */   private static abstract interface CycleDetectingLock
/*  615:     */   {
/*  616:     */     public abstract CycleDetectingLockFactory.LockGraphNode getLockGraphNode();
/*  617:     */     
/*  618:     */     public abstract boolean isAcquiredByCurrentThread();
/*  619:     */   }
/*  620:     */   
/*  621:     */   @Beta
/*  622:     */   @ThreadSafe
/*  623:     */   public static abstract interface Policy
/*  624:     */   {
/*  625:     */     public abstract void handlePotentialDeadlock(CycleDetectingLockFactory.PotentialDeadlockException paramPotentialDeadlockException);
/*  626:     */   }
/*  627:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.CycleDetectingLockFactory
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import java.util.concurrent.Callable;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ public final class Callables
/*   9:    */ {
/*  10:    */   public static <T> Callable<T> returning(@Nullable T value)
/*  11:    */   {
/*  12: 41 */     new Callable()
/*  13:    */     {
/*  14:    */       public T call()
/*  15:    */       {
/*  16: 43 */         return this.val$value;
/*  17:    */       }
/*  18:    */     };
/*  19:    */   }
/*  20:    */   
/*  21:    */   static <T> Callable<T> threadRenaming(final Callable<T> callable, Supplier<String> nameSupplier)
/*  22:    */   {
/*  23: 59 */     Preconditions.checkNotNull(nameSupplier);
/*  24: 60 */     Preconditions.checkNotNull(callable);
/*  25: 61 */     new Callable()
/*  26:    */     {
/*  27:    */       public T call()
/*  28:    */         throws Exception
/*  29:    */       {
/*  30: 63 */         Thread currentThread = Thread.currentThread();
/*  31: 64 */         String oldName = currentThread.getName();
/*  32: 65 */         boolean restoreName = Callables.trySetName((String)this.val$nameSupplier.get(), currentThread);
/*  33:    */         try
/*  34:    */         {
/*  35: 67 */           return callable.call();
/*  36:    */         }
/*  37:    */         finally
/*  38:    */         {
/*  39: 69 */           if (restoreName) {
/*  40: 70 */             Callables.trySetName(oldName, currentThread);
/*  41:    */           }
/*  42:    */         }
/*  43:    */       }
/*  44:    */     };
/*  45:    */   }
/*  46:    */   
/*  47:    */   static Runnable threadRenaming(final Runnable task, Supplier<String> nameSupplier)
/*  48:    */   {
/*  49: 87 */     Preconditions.checkNotNull(nameSupplier);
/*  50: 88 */     Preconditions.checkNotNull(task);
/*  51: 89 */     new Runnable()
/*  52:    */     {
/*  53:    */       public void run()
/*  54:    */       {
/*  55: 91 */         Thread currentThread = Thread.currentThread();
/*  56: 92 */         String oldName = currentThread.getName();
/*  57: 93 */         boolean restoreName = Callables.trySetName((String)this.val$nameSupplier.get(), currentThread);
/*  58:    */         try
/*  59:    */         {
/*  60: 95 */           task.run();
/*  61:    */         }
/*  62:    */         finally
/*  63:    */         {
/*  64: 97 */           if (restoreName) {
/*  65: 98 */             Callables.trySetName(oldName, currentThread);
/*  66:    */           }
/*  67:    */         }
/*  68:    */       }
/*  69:    */     };
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static boolean trySetName(String threadName, Thread currentThread)
/*  73:    */   {
/*  74:    */     try
/*  75:    */     {
/*  76:111 */       currentThread.setName(threadName);
/*  77:112 */       return true;
/*  78:    */     }
/*  79:    */     catch (SecurityException e) {}
/*  80:114 */     return false;
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.Callables
 * JD-Core Version:    0.7.0.1
 */
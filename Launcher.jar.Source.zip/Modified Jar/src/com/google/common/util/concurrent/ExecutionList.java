/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.concurrent.Executor;
/*   6:    */ import java.util.logging.Level;
/*   7:    */ import java.util.logging.Logger;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ import javax.annotation.concurrent.GuardedBy;
/*  10:    */ 
/*  11:    */ public final class ExecutionList
/*  12:    */ {
/*  13:    */   @VisibleForTesting
/*  14: 49 */   static final Logger log = Logger.getLogger(ExecutionList.class.getName());
/*  15:    */   @GuardedBy("this")
/*  16:    */   private RunnableExecutorPair runnables;
/*  17:    */   @GuardedBy("this")
/*  18:    */   private boolean executed;
/*  19:    */   
/*  20:    */   public void add(Runnable runnable, Executor executor)
/*  21:    */   {
/*  22: 85 */     Preconditions.checkNotNull(runnable, "Runnable was null.");
/*  23: 86 */     Preconditions.checkNotNull(executor, "Executor was null.");
/*  24: 91 */     synchronized (this)
/*  25:    */     {
/*  26: 92 */       if (!this.executed)
/*  27:    */       {
/*  28: 93 */         this.runnables = new RunnableExecutorPair(runnable, executor, this.runnables);
/*  29: 94 */         return;
/*  30:    */       }
/*  31:    */     }
/*  32:101 */     executeListener(runnable, executor);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void execute()
/*  36:    */   {
/*  37:    */     RunnableExecutorPair list;
/*  38:120 */     synchronized (this)
/*  39:    */     {
/*  40:121 */       if (this.executed) {
/*  41:122 */         return;
/*  42:    */       }
/*  43:124 */       this.executed = true;
/*  44:125 */       list = this.runnables;
/*  45:126 */       this.runnables = null;
/*  46:    */     }
/*  47:137 */     RunnableExecutorPair reversedList = null;
/*  48:138 */     while (list != null)
/*  49:    */     {
/*  50:139 */       RunnableExecutorPair tmp = list;
/*  51:140 */       list = list.next;
/*  52:141 */       tmp.next = reversedList;
/*  53:142 */       reversedList = tmp;
/*  54:    */     }
/*  55:144 */     while (reversedList != null)
/*  56:    */     {
/*  57:145 */       executeListener(reversedList.runnable, reversedList.executor);
/*  58:146 */       reversedList = reversedList.next;
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   private static void executeListener(Runnable runnable, Executor executor)
/*  63:    */   {
/*  64:    */     try
/*  65:    */     {
/*  66:156 */       executor.execute(runnable);
/*  67:    */     }
/*  68:    */     catch (RuntimeException e)
/*  69:    */     {
/*  70:161 */       log.log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, e);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static final class RunnableExecutorPair
/*  75:    */   {
/*  76:    */     final Runnable runnable;
/*  77:    */     final Executor executor;
/*  78:    */     @Nullable
/*  79:    */     RunnableExecutorPair next;
/*  80:    */     
/*  81:    */     RunnableExecutorPair(Runnable runnable, Executor executor, RunnableExecutorPair next)
/*  82:    */     {
/*  83:172 */       this.runnable = runnable;
/*  84:173 */       this.executor = executor;
/*  85:174 */       this.next = next;
/*  86:    */     }
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.util.concurrent.ExecutionList
 * JD-Core Version:    0.7.0.1
 */
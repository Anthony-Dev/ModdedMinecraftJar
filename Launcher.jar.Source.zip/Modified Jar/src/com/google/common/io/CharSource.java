/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Ascii;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Splitter;
/*   7:    */ import com.google.common.collect.AbstractIterator;
/*   8:    */ import com.google.common.collect.ImmutableList;
/*   9:    */ import com.google.common.collect.Lists;
/*  10:    */ import java.io.BufferedReader;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.io.Reader;
/*  13:    */ import java.io.Writer;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.regex.Pattern;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ public abstract class CharSource
/*  20:    */   implements InputSupplier<Reader>
/*  21:    */ {
/*  22:    */   public abstract Reader openStream()
/*  23:    */     throws IOException;
/*  24:    */   
/*  25:    */   @Deprecated
/*  26:    */   public final Reader getInput()
/*  27:    */     throws IOException
/*  28:    */   {
/*  29: 94 */     return openStream();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public BufferedReader openBufferedStream()
/*  33:    */     throws IOException
/*  34:    */   {
/*  35:106 */     Reader reader = openStream();
/*  36:107 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public long copyTo(Appendable appendable)
/*  40:    */     throws IOException
/*  41:    */   {
/*  42:120 */     Preconditions.checkNotNull(appendable);
/*  43:    */     
/*  44:122 */     Closer closer = Closer.create();
/*  45:    */     try
/*  46:    */     {
/*  47:124 */       Reader reader = (Reader)closer.register(openStream());
/*  48:125 */       return CharStreams.copy(reader, appendable);
/*  49:    */     }
/*  50:    */     catch (Throwable e)
/*  51:    */     {
/*  52:127 */       throw closer.rethrow(e);
/*  53:    */     }
/*  54:    */     finally
/*  55:    */     {
/*  56:129 */       closer.close();
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public long copyTo(CharSink sink)
/*  61:    */     throws IOException
/*  62:    */   {
/*  63:140 */     Preconditions.checkNotNull(sink);
/*  64:    */     
/*  65:142 */     Closer closer = Closer.create();
/*  66:    */     try
/*  67:    */     {
/*  68:144 */       Reader reader = (Reader)closer.register(openStream());
/*  69:145 */       Writer writer = (Writer)closer.register(sink.openStream());
/*  70:146 */       return CharStreams.copy(reader, writer);
/*  71:    */     }
/*  72:    */     catch (Throwable e)
/*  73:    */     {
/*  74:148 */       throw closer.rethrow(e);
/*  75:    */     }
/*  76:    */     finally
/*  77:    */     {
/*  78:150 */       closer.close();
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public String read()
/*  83:    */     throws IOException
/*  84:    */   {
/*  85:160 */     Closer closer = Closer.create();
/*  86:    */     try
/*  87:    */     {
/*  88:162 */       Reader reader = (Reader)closer.register(openStream());
/*  89:163 */       return CharStreams.toString(reader);
/*  90:    */     }
/*  91:    */     catch (Throwable e)
/*  92:    */     {
/*  93:165 */       throw closer.rethrow(e);
/*  94:    */     }
/*  95:    */     finally
/*  96:    */     {
/*  97:167 */       closer.close();
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   @Nullable
/* 102:    */   public String readFirstLine()
/* 103:    */     throws IOException
/* 104:    */   {
/* 105:181 */     Closer closer = Closer.create();
/* 106:    */     try
/* 107:    */     {
/* 108:183 */       BufferedReader reader = (BufferedReader)closer.register(openBufferedStream());
/* 109:184 */       return reader.readLine();
/* 110:    */     }
/* 111:    */     catch (Throwable e)
/* 112:    */     {
/* 113:186 */       throw closer.rethrow(e);
/* 114:    */     }
/* 115:    */     finally
/* 116:    */     {
/* 117:188 */       closer.close();
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public ImmutableList<String> readLines()
/* 122:    */     throws IOException
/* 123:    */   {
/* 124:203 */     Closer closer = Closer.create();
/* 125:    */     try
/* 126:    */     {
/* 127:205 */       BufferedReader reader = (BufferedReader)closer.register(openBufferedStream());
/* 128:206 */       List<String> result = Lists.newArrayList();
/* 129:    */       String line;
/* 130:208 */       while ((line = reader.readLine()) != null) {
/* 131:209 */         result.add(line);
/* 132:    */       }
/* 133:211 */       return ImmutableList.copyOf(result);
/* 134:    */     }
/* 135:    */     catch (Throwable e)
/* 136:    */     {
/* 137:213 */       throw closer.rethrow(e);
/* 138:    */     }
/* 139:    */     finally
/* 140:    */     {
/* 141:215 */       closer.close();
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   @Beta
/* 146:    */   public <T> T readLines(LineProcessor<T> processor)
/* 147:    */     throws IOException
/* 148:    */   {
/* 149:235 */     Preconditions.checkNotNull(processor);
/* 150:    */     
/* 151:237 */     Closer closer = Closer.create();
/* 152:    */     try
/* 153:    */     {
/* 154:239 */       Reader reader = (Reader)closer.register(openStream());
/* 155:240 */       return CharStreams.readLines(reader, processor);
/* 156:    */     }
/* 157:    */     catch (Throwable e)
/* 158:    */     {
/* 159:242 */       throw closer.rethrow(e);
/* 160:    */     }
/* 161:    */     finally
/* 162:    */     {
/* 163:244 */       closer.close();
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean isEmpty()
/* 168:    */     throws IOException
/* 169:    */   {
/* 170:256 */     Closer closer = Closer.create();
/* 171:    */     try
/* 172:    */     {
/* 173:258 */       Reader reader = (Reader)closer.register(openStream());
/* 174:259 */       return reader.read() == -1;
/* 175:    */     }
/* 176:    */     catch (Throwable e)
/* 177:    */     {
/* 178:261 */       throw closer.rethrow(e);
/* 179:    */     }
/* 180:    */     finally
/* 181:    */     {
/* 182:263 */       closer.close();
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static CharSource concat(Iterable<? extends CharSource> sources)
/* 187:    */   {
/* 188:279 */     return new ConcatenatedCharSource(sources);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static CharSource concat(Iterator<? extends CharSource> sources)
/* 192:    */   {
/* 193:301 */     return concat(ImmutableList.copyOf(sources));
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static CharSource concat(CharSource... sources)
/* 197:    */   {
/* 198:317 */     return concat(ImmutableList.copyOf(sources));
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static CharSource wrap(CharSequence charSequence)
/* 202:    */   {
/* 203:328 */     return new CharSequenceCharSource(charSequence);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static CharSource empty()
/* 207:    */   {
/* 208:337 */     return EmptyCharSource.INSTANCE;
/* 209:    */   }
/* 210:    */   
/* 211:    */   private static class CharSequenceCharSource
/* 212:    */     extends CharSource
/* 213:    */   {
/* 214:342 */     private static final Splitter LINE_SPLITTER = Splitter.on(Pattern.compile("\r\n|\n|\r"));
/* 215:    */     private final CharSequence seq;
/* 216:    */     
/* 217:    */     protected CharSequenceCharSource(CharSequence seq)
/* 218:    */     {
/* 219:348 */       this.seq = ((CharSequence)Preconditions.checkNotNull(seq));
/* 220:    */     }
/* 221:    */     
/* 222:    */     public Reader openStream()
/* 223:    */     {
/* 224:353 */       return new CharSequenceReader(this.seq);
/* 225:    */     }
/* 226:    */     
/* 227:    */     public String read()
/* 228:    */     {
/* 229:358 */       return this.seq.toString();
/* 230:    */     }
/* 231:    */     
/* 232:    */     public boolean isEmpty()
/* 233:    */     {
/* 234:363 */       return this.seq.length() == 0;
/* 235:    */     }
/* 236:    */     
/* 237:    */     private Iterable<String> lines()
/* 238:    */     {
/* 239:372 */       new Iterable()
/* 240:    */       {
/* 241:    */         public Iterator<String> iterator()
/* 242:    */         {
/* 243:375 */           new AbstractIterator()
/* 244:    */           {
/* 245:376 */             Iterator<String> lines = CharSource.CharSequenceCharSource.LINE_SPLITTER.split(CharSource.CharSequenceCharSource.this.seq).iterator();
/* 246:    */             
/* 247:    */             protected String computeNext()
/* 248:    */             {
/* 249:380 */               if (this.lines.hasNext())
/* 250:    */               {
/* 251:381 */                 String next = (String)this.lines.next();
/* 252:383 */                 if ((this.lines.hasNext()) || (!next.isEmpty())) {
/* 253:384 */                   return next;
/* 254:    */                 }
/* 255:    */               }
/* 256:387 */               return (String)endOfData();
/* 257:    */             }
/* 258:    */           };
/* 259:    */         }
/* 260:    */       };
/* 261:    */     }
/* 262:    */     
/* 263:    */     public String readFirstLine()
/* 264:    */     {
/* 265:396 */       Iterator<String> lines = lines().iterator();
/* 266:397 */       return lines.hasNext() ? (String)lines.next() : null;
/* 267:    */     }
/* 268:    */     
/* 269:    */     public ImmutableList<String> readLines()
/* 270:    */     {
/* 271:402 */       return ImmutableList.copyOf(lines());
/* 272:    */     }
/* 273:    */     
/* 274:    */     public <T> T readLines(LineProcessor<T> processor)
/* 275:    */       throws IOException
/* 276:    */     {
/* 277:407 */       for (String line : lines()) {
/* 278:408 */         if (!processor.processLine(line)) {
/* 279:    */           break;
/* 280:    */         }
/* 281:    */       }
/* 282:412 */       return processor.getResult();
/* 283:    */     }
/* 284:    */     
/* 285:    */     public String toString()
/* 286:    */     {
/* 287:417 */       return "CharSource.wrap(" + Ascii.truncate(this.seq, 30, "...") + ")";
/* 288:    */     }
/* 289:    */   }
/* 290:    */   
/* 291:    */   private static final class EmptyCharSource
/* 292:    */     extends CharSource.CharSequenceCharSource
/* 293:    */   {
/* 294:423 */     private static final EmptyCharSource INSTANCE = new EmptyCharSource();
/* 295:    */     
/* 296:    */     private EmptyCharSource()
/* 297:    */     {
/* 298:426 */       super();
/* 299:    */     }
/* 300:    */     
/* 301:    */     public String toString()
/* 302:    */     {
/* 303:431 */       return "CharSource.empty()";
/* 304:    */     }
/* 305:    */   }
/* 306:    */   
/* 307:    */   private static final class ConcatenatedCharSource
/* 308:    */     extends CharSource
/* 309:    */   {
/* 310:    */     private final Iterable<? extends CharSource> sources;
/* 311:    */     
/* 312:    */     ConcatenatedCharSource(Iterable<? extends CharSource> sources)
/* 313:    */     {
/* 314:440 */       this.sources = ((Iterable)Preconditions.checkNotNull(sources));
/* 315:    */     }
/* 316:    */     
/* 317:    */     public Reader openStream()
/* 318:    */       throws IOException
/* 319:    */     {
/* 320:445 */       return new MultiReader(this.sources.iterator());
/* 321:    */     }
/* 322:    */     
/* 323:    */     public boolean isEmpty()
/* 324:    */       throws IOException
/* 325:    */     {
/* 326:450 */       for (CharSource source : this.sources) {
/* 327:451 */         if (!source.isEmpty()) {
/* 328:452 */           return false;
/* 329:    */         }
/* 330:    */       }
/* 331:455 */       return true;
/* 332:    */     }
/* 333:    */     
/* 334:    */     public String toString()
/* 335:    */     {
/* 336:460 */       return "CharSource.concat(" + this.sources + ")";
/* 337:    */     }
/* 338:    */   }
/* 339:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.CharSource
 * JD-Core Version:    0.7.0.1
 */
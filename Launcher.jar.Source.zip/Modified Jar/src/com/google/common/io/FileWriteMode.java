package com.google.common.io;

public enum FileWriteMode
{
  APPEND;
  
  private FileWriteMode() {}
}


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.FileWriteMode
 * JD-Core Version:    0.7.0.1
 */
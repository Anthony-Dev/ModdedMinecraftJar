/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Throwables;
/*   7:    */ import java.io.Closeable;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.lang.reflect.Method;
/*  10:    */ import java.util.ArrayDeque;
/*  11:    */ import java.util.Deque;
/*  12:    */ import java.util.logging.Level;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @Beta
/*  17:    */ public final class Closer
/*  18:    */   implements Closeable
/*  19:    */ {
/*  20: 96 */   private static final Suppressor SUPPRESSOR = SuppressingSuppressor.isAvailable() ? SuppressingSuppressor.INSTANCE : LoggingSuppressor.INSTANCE;
/*  21:    */   @VisibleForTesting
/*  22:    */   final Suppressor suppressor;
/*  23:    */   
/*  24:    */   public static Closer create()
/*  25:    */   {
/*  26:104 */     return new Closer(SUPPRESSOR);
/*  27:    */   }
/*  28:    */   
/*  29:110 */   private final Deque<Closeable> stack = new ArrayDeque(4);
/*  30:    */   private Throwable thrown;
/*  31:    */   
/*  32:    */   @VisibleForTesting
/*  33:    */   Closer(Suppressor suppressor)
/*  34:    */   {
/*  35:114 */     this.suppressor = ((Suppressor)Preconditions.checkNotNull(suppressor));
/*  36:    */   }
/*  37:    */   
/*  38:    */   public <C extends Closeable> C register(@Nullable C closeable)
/*  39:    */   {
/*  40:125 */     if (closeable != null) {
/*  41:126 */       this.stack.addFirst(closeable);
/*  42:    */     }
/*  43:129 */     return closeable;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public RuntimeException rethrow(Throwable e)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49:146 */     Preconditions.checkNotNull(e);
/*  50:147 */     this.thrown = e;
/*  51:148 */     Throwables.propagateIfPossible(e, IOException.class);
/*  52:149 */     throw new RuntimeException(e);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public <X extends Exception> RuntimeException rethrow(Throwable e, Class<X> declaredType)
/*  56:    */     throws IOException, Exception
/*  57:    */   {
/*  58:168 */     Preconditions.checkNotNull(e);
/*  59:169 */     this.thrown = e;
/*  60:170 */     Throwables.propagateIfPossible(e, IOException.class);
/*  61:171 */     Throwables.propagateIfPossible(e, declaredType);
/*  62:172 */     throw new RuntimeException(e);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public <X1 extends Exception, X2 extends Exception> RuntimeException rethrow(Throwable e, Class<X1> declaredType1, Class<X2> declaredType2)
/*  66:    */     throws IOException, Exception, Exception
/*  67:    */   {
/*  68:192 */     Preconditions.checkNotNull(e);
/*  69:193 */     this.thrown = e;
/*  70:194 */     Throwables.propagateIfPossible(e, IOException.class);
/*  71:195 */     Throwables.propagateIfPossible(e, declaredType1, declaredType2);
/*  72:196 */     throw new RuntimeException(e);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void close()
/*  76:    */     throws IOException
/*  77:    */   {
/*  78:208 */     Throwable throwable = this.thrown;
/*  79:211 */     while (!this.stack.isEmpty())
/*  80:    */     {
/*  81:212 */       Closeable closeable = (Closeable)this.stack.removeFirst();
/*  82:    */       try
/*  83:    */       {
/*  84:214 */         closeable.close();
/*  85:    */       }
/*  86:    */       catch (Throwable e)
/*  87:    */       {
/*  88:216 */         if (throwable == null) {
/*  89:217 */           throwable = e;
/*  90:    */         } else {
/*  91:219 */           this.suppressor.suppress(closeable, throwable, e);
/*  92:    */         }
/*  93:    */       }
/*  94:    */     }
/*  95:224 */     if ((this.thrown == null) && (throwable != null))
/*  96:    */     {
/*  97:225 */       Throwables.propagateIfPossible(throwable, IOException.class);
/*  98:226 */       throw new AssertionError(throwable);
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   @VisibleForTesting
/* 103:    */   static final class LoggingSuppressor
/* 104:    */     implements Closer.Suppressor
/* 105:    */   {
/* 106:247 */     static final LoggingSuppressor INSTANCE = new LoggingSuppressor();
/* 107:    */     
/* 108:    */     public void suppress(Closeable closeable, Throwable thrown, Throwable suppressed)
/* 109:    */     {
/* 110:252 */       Closeables.logger.log(Level.WARNING, "Suppressing exception thrown when closing " + closeable, suppressed);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   @VisibleForTesting
/* 115:    */   static final class SuppressingSuppressor
/* 116:    */     implements Closer.Suppressor
/* 117:    */   {
/* 118:263 */     static final SuppressingSuppressor INSTANCE = new SuppressingSuppressor();
/* 119:    */     
/* 120:    */     static boolean isAvailable()
/* 121:    */     {
/* 122:266 */       return addSuppressed != null;
/* 123:    */     }
/* 124:    */     
/* 125:269 */     static final Method addSuppressed = getAddSuppressed();
/* 126:    */     
/* 127:    */     private static Method getAddSuppressed()
/* 128:    */     {
/* 129:    */       try
/* 130:    */       {
/* 131:273 */         return Throwable.class.getMethod("addSuppressed", new Class[] { Throwable.class });
/* 132:    */       }
/* 133:    */       catch (Throwable e) {}
/* 134:275 */       return null;
/* 135:    */     }
/* 136:    */     
/* 137:    */     public void suppress(Closeable closeable, Throwable thrown, Throwable suppressed)
/* 138:    */     {
/* 139:282 */       if (thrown == suppressed) {
/* 140:283 */         return;
/* 141:    */       }
/* 142:    */       try
/* 143:    */       {
/* 144:286 */         addSuppressed.invoke(thrown, new Object[] { suppressed });
/* 145:    */       }
/* 146:    */       catch (Throwable e)
/* 147:    */       {
/* 148:289 */         Closer.LoggingSuppressor.INSTANCE.suppress(closeable, thrown, suppressed);
/* 149:    */       }
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   @VisibleForTesting
/* 154:    */   static abstract interface Suppressor
/* 155:    */   {
/* 156:    */     public abstract void suppress(Closeable paramCloseable, Throwable paramThrowable1, Throwable paramThrowable2);
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.Closer
 * JD-Core Version:    0.7.0.1
 */
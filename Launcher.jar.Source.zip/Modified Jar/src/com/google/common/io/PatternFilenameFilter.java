/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.File;
/*  6:   */ import java.io.FilenameFilter;
/*  7:   */ import java.util.regex.Matcher;
/*  8:   */ import java.util.regex.Pattern;
/*  9:   */ import javax.annotation.Nullable;
/* 10:   */ 
/* 11:   */ @Beta
/* 12:   */ public final class PatternFilenameFilter
/* 13:   */   implements FilenameFilter
/* 14:   */ {
/* 15:   */   private final Pattern pattern;
/* 16:   */   
/* 17:   */   public PatternFilenameFilter(String patternStr)
/* 18:   */   {
/* 19:48 */     this(Pattern.compile(patternStr));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public PatternFilenameFilter(Pattern pattern)
/* 23:   */   {
/* 24:56 */     this.pattern = ((Pattern)Preconditions.checkNotNull(pattern));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean accept(@Nullable File dir, String fileName)
/* 28:   */   {
/* 29:60 */     return this.pattern.matcher(fileName).matches();
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.PatternFilenameFilter
 * JD-Core Version:    0.7.0.1
 */
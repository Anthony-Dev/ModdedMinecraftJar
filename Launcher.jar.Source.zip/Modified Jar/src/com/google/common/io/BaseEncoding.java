/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Ascii;
/*   7:    */ import com.google.common.base.CharMatcher;
/*   8:    */ import com.google.common.base.Preconditions;
/*   9:    */ import com.google.common.math.IntMath;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.InputStream;
/*  12:    */ import java.io.OutputStream;
/*  13:    */ import java.io.Reader;
/*  14:    */ import java.io.Writer;
/*  15:    */ import java.math.RoundingMode;
/*  16:    */ import java.util.Arrays;
/*  17:    */ import javax.annotation.CheckReturnValue;
/*  18:    */ import javax.annotation.Nullable;
/*  19:    */ 
/*  20:    */ @Beta
/*  21:    */ @GwtCompatible(emulated=true)
/*  22:    */ public abstract class BaseEncoding
/*  23:    */ {
/*  24:    */   public static final class DecodingException
/*  25:    */     extends IOException
/*  26:    */   {
/*  27:    */     DecodingException(String message)
/*  28:    */     {
/*  29:146 */       super();
/*  30:    */     }
/*  31:    */     
/*  32:    */     DecodingException(Throwable cause)
/*  33:    */     {
/*  34:150 */       super();
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String encode(byte[] bytes)
/*  39:    */   {
/*  40:158 */     return encode((byte[])Preconditions.checkNotNull(bytes), 0, bytes.length);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public final String encode(byte[] bytes, int off, int len)
/*  44:    */   {
/*  45:166 */     Preconditions.checkNotNull(bytes);
/*  46:167 */     Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  47:168 */     GwtWorkarounds.CharOutput result = GwtWorkarounds.stringBuilderOutput(maxEncodedSize(len));
/*  48:169 */     GwtWorkarounds.ByteOutput byteOutput = encodingStream(result);
/*  49:    */     try
/*  50:    */     {
/*  51:171 */       for (int i = 0; i < len; i++) {
/*  52:172 */         byteOutput.write(bytes[(off + i)]);
/*  53:    */       }
/*  54:174 */       byteOutput.close();
/*  55:    */     }
/*  56:    */     catch (IOException impossible)
/*  57:    */     {
/*  58:176 */       throw new AssertionError("impossible");
/*  59:    */     }
/*  60:178 */     return result.toString();
/*  61:    */   }
/*  62:    */   
/*  63:    */   @GwtIncompatible("Writer,OutputStream")
/*  64:    */   public final OutputStream encodingStream(Writer writer)
/*  65:    */   {
/*  66:188 */     return GwtWorkarounds.asOutputStream(encodingStream(GwtWorkarounds.asCharOutput(writer)));
/*  67:    */   }
/*  68:    */   
/*  69:    */   @GwtIncompatible("ByteSink,CharSink")
/*  70:    */   public final ByteSink encodingSink(final CharSink encodedSink)
/*  71:    */   {
/*  72:196 */     Preconditions.checkNotNull(encodedSink);
/*  73:197 */     new ByteSink()
/*  74:    */     {
/*  75:    */       public OutputStream openStream()
/*  76:    */         throws IOException
/*  77:    */       {
/*  78:200 */         return BaseEncoding.this.encodingStream(encodedSink.openStream());
/*  79:    */       }
/*  80:    */     };
/*  81:    */   }
/*  82:    */   
/*  83:    */   private static byte[] extract(byte[] result, int length)
/*  84:    */   {
/*  85:208 */     if (length == result.length) {
/*  86:209 */       return result;
/*  87:    */     }
/*  88:211 */     byte[] trunc = new byte[length];
/*  89:212 */     System.arraycopy(result, 0, trunc, 0, length);
/*  90:213 */     return trunc;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public final byte[] decode(CharSequence chars)
/*  94:    */   {
/*  95:    */     try
/*  96:    */     {
/*  97:226 */       return decodeChecked(chars);
/*  98:    */     }
/*  99:    */     catch (DecodingException badInput)
/* 100:    */     {
/* 101:228 */       throw new IllegalArgumentException(badInput);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   final byte[] decodeChecked(CharSequence chars)
/* 106:    */     throws BaseEncoding.DecodingException
/* 107:    */   {
/* 108:240 */     chars = padding().trimTrailingFrom(chars);
/* 109:241 */     GwtWorkarounds.ByteInput decodedInput = decodingStream(GwtWorkarounds.asCharInput(chars));
/* 110:242 */     byte[] tmp = new byte[maxDecodedSize(chars.length())];
/* 111:243 */     int index = 0;
/* 112:    */     try
/* 113:    */     {
/* 114:245 */       for (int i = decodedInput.read(); i != -1; i = decodedInput.read()) {
/* 115:246 */         tmp[(index++)] = ((byte)i);
/* 116:    */       }
/* 117:    */     }
/* 118:    */     catch (DecodingException badInput)
/* 119:    */     {
/* 120:249 */       throw badInput;
/* 121:    */     }
/* 122:    */     catch (IOException impossible)
/* 123:    */     {
/* 124:251 */       throw new AssertionError(impossible);
/* 125:    */     }
/* 126:253 */     return extract(tmp, index);
/* 127:    */   }
/* 128:    */   
/* 129:    */   @GwtIncompatible("Reader,InputStream")
/* 130:    */   public final InputStream decodingStream(Reader reader)
/* 131:    */   {
/* 132:263 */     return GwtWorkarounds.asInputStream(decodingStream(GwtWorkarounds.asCharInput(reader)));
/* 133:    */   }
/* 134:    */   
/* 135:    */   @GwtIncompatible("ByteSource,CharSource")
/* 136:    */   public final ByteSource decodingSource(final CharSource encodedSource)
/* 137:    */   {
/* 138:272 */     Preconditions.checkNotNull(encodedSource);
/* 139:273 */     new ByteSource()
/* 140:    */     {
/* 141:    */       public InputStream openStream()
/* 142:    */         throws IOException
/* 143:    */       {
/* 144:276 */         return BaseEncoding.this.decodingStream(encodedSource.openStream());
/* 145:    */       }
/* 146:    */     };
/* 147:    */   }
/* 148:    */   
/* 149:345 */   private static final BaseEncoding BASE64 = new StandardBaseEncoding("base64()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Character.valueOf('='));
/* 150:    */   
/* 151:    */   abstract int maxEncodedSize(int paramInt);
/* 152:    */   
/* 153:    */   abstract GwtWorkarounds.ByteOutput encodingStream(GwtWorkarounds.CharOutput paramCharOutput);
/* 154:    */   
/* 155:    */   abstract int maxDecodedSize(int paramInt);
/* 156:    */   
/* 157:    */   abstract GwtWorkarounds.ByteInput decodingStream(GwtWorkarounds.CharInput paramCharInput);
/* 158:    */   
/* 159:    */   abstract CharMatcher padding();
/* 160:    */   
/* 161:    */   @CheckReturnValue
/* 162:    */   public abstract BaseEncoding omitPadding();
/* 163:    */   
/* 164:    */   @CheckReturnValue
/* 165:    */   public abstract BaseEncoding withPadChar(char paramChar);
/* 166:    */   
/* 167:    */   @CheckReturnValue
/* 168:    */   public abstract BaseEncoding withSeparator(String paramString, int paramInt);
/* 169:    */   
/* 170:    */   @CheckReturnValue
/* 171:    */   public abstract BaseEncoding upperCase();
/* 172:    */   
/* 173:    */   @CheckReturnValue
/* 174:    */   public abstract BaseEncoding lowerCase();
/* 175:    */   
/* 176:    */   public static BaseEncoding base64()
/* 177:    */   {
/* 178:362 */     return BASE64;
/* 179:    */   }
/* 180:    */   
/* 181:365 */   private static final BaseEncoding BASE64_URL = new StandardBaseEncoding("base64Url()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", Character.valueOf('='));
/* 182:    */   
/* 183:    */   public static BaseEncoding base64Url()
/* 184:    */   {
/* 185:383 */     return BASE64_URL;
/* 186:    */   }
/* 187:    */   
/* 188:386 */   private static final BaseEncoding BASE32 = new StandardBaseEncoding("base32()", "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", Character.valueOf('='));
/* 189:    */   
/* 190:    */   public static BaseEncoding base32()
/* 191:    */   {
/* 192:403 */     return BASE32;
/* 193:    */   }
/* 194:    */   
/* 195:406 */   private static final BaseEncoding BASE32_HEX = new StandardBaseEncoding("base32Hex()", "0123456789ABCDEFGHIJKLMNOPQRSTUV", Character.valueOf('='));
/* 196:    */   
/* 197:    */   public static BaseEncoding base32Hex()
/* 198:    */   {
/* 199:422 */     return BASE32_HEX;
/* 200:    */   }
/* 201:    */   
/* 202:425 */   private static final BaseEncoding BASE16 = new StandardBaseEncoding("base16()", "0123456789ABCDEF", null);
/* 203:    */   
/* 204:    */   public static BaseEncoding base16()
/* 205:    */   {
/* 206:443 */     return BASE16;
/* 207:    */   }
/* 208:    */   
/* 209:    */   private static final class Alphabet
/* 210:    */     extends CharMatcher
/* 211:    */   {
/* 212:    */     private final String name;
/* 213:    */     private final char[] chars;
/* 214:    */     final int mask;
/* 215:    */     final int bitsPerChar;
/* 216:    */     final int charsPerChunk;
/* 217:    */     final int bytesPerChunk;
/* 218:    */     private final byte[] decodabet;
/* 219:    */     private final boolean[] validPadding;
/* 220:    */     
/* 221:    */     Alphabet(String name, char[] chars)
/* 222:    */     {
/* 223:458 */       this.name = ((String)Preconditions.checkNotNull(name));
/* 224:459 */       this.chars = ((char[])Preconditions.checkNotNull(chars));
/* 225:    */       try
/* 226:    */       {
/* 227:461 */         this.bitsPerChar = IntMath.log2(chars.length, RoundingMode.UNNECESSARY);
/* 228:    */       }
/* 229:    */       catch (ArithmeticException e)
/* 230:    */       {
/* 231:463 */         throw new IllegalArgumentException("Illegal alphabet length " + chars.length, e);
/* 232:    */       }
/* 233:470 */       int gcd = Math.min(8, Integer.lowestOneBit(this.bitsPerChar));
/* 234:471 */       this.charsPerChunk = (8 / gcd);
/* 235:472 */       this.bytesPerChunk = (this.bitsPerChar / gcd);
/* 236:    */       
/* 237:474 */       this.mask = (chars.length - 1);
/* 238:    */       
/* 239:476 */       byte[] decodabet = new byte[''];
/* 240:477 */       Arrays.fill(decodabet, (byte)-1);
/* 241:478 */       for (int i = 0; i < chars.length; i++)
/* 242:    */       {
/* 243:479 */         char c = chars[i];
/* 244:480 */         Preconditions.checkArgument(CharMatcher.ASCII.matches(c), "Non-ASCII character: %s", new Object[] { Character.valueOf(c) });
/* 245:481 */         Preconditions.checkArgument(decodabet[c] == -1, "Duplicate character: %s", new Object[] { Character.valueOf(c) });
/* 246:482 */         decodabet[c] = ((byte)i);
/* 247:    */       }
/* 248:484 */       this.decodabet = decodabet;
/* 249:    */       
/* 250:486 */       boolean[] validPadding = new boolean[this.charsPerChunk];
/* 251:487 */       for (int i = 0; i < this.bytesPerChunk; i++) {
/* 252:488 */         validPadding[IntMath.divide(i * 8, this.bitsPerChar, RoundingMode.CEILING)] = true;
/* 253:    */       }
/* 254:490 */       this.validPadding = validPadding;
/* 255:    */     }
/* 256:    */     
/* 257:    */     char encode(int bits)
/* 258:    */     {
/* 259:494 */       return this.chars[bits];
/* 260:    */     }
/* 261:    */     
/* 262:    */     boolean isValidPaddingStartPosition(int index)
/* 263:    */     {
/* 264:498 */       return this.validPadding[(index % this.charsPerChunk)];
/* 265:    */     }
/* 266:    */     
/* 267:    */     int decode(char ch)
/* 268:    */       throws IOException
/* 269:    */     {
/* 270:502 */       if ((ch > '') || (this.decodabet[ch] == -1)) {
/* 271:503 */         throw new BaseEncoding.DecodingException("Unrecognized character: " + ch);
/* 272:    */       }
/* 273:505 */       return this.decodabet[ch];
/* 274:    */     }
/* 275:    */     
/* 276:    */     private boolean hasLowerCase()
/* 277:    */     {
/* 278:509 */       for (char c : this.chars) {
/* 279:510 */         if (Ascii.isLowerCase(c)) {
/* 280:511 */           return true;
/* 281:    */         }
/* 282:    */       }
/* 283:514 */       return false;
/* 284:    */     }
/* 285:    */     
/* 286:    */     private boolean hasUpperCase()
/* 287:    */     {
/* 288:518 */       for (char c : this.chars) {
/* 289:519 */         if (Ascii.isUpperCase(c)) {
/* 290:520 */           return true;
/* 291:    */         }
/* 292:    */       }
/* 293:523 */       return false;
/* 294:    */     }
/* 295:    */     
/* 296:    */     Alphabet upperCase()
/* 297:    */     {
/* 298:527 */       if (!hasLowerCase()) {
/* 299:528 */         return this;
/* 300:    */       }
/* 301:530 */       Preconditions.checkState(!hasUpperCase(), "Cannot call upperCase() on a mixed-case alphabet");
/* 302:531 */       char[] upperCased = new char[this.chars.length];
/* 303:532 */       for (int i = 0; i < this.chars.length; i++) {
/* 304:533 */         upperCased[i] = Ascii.toUpperCase(this.chars[i]);
/* 305:    */       }
/* 306:535 */       return new Alphabet(this.name + ".upperCase()", upperCased);
/* 307:    */     }
/* 308:    */     
/* 309:    */     Alphabet lowerCase()
/* 310:    */     {
/* 311:540 */       if (!hasUpperCase()) {
/* 312:541 */         return this;
/* 313:    */       }
/* 314:543 */       Preconditions.checkState(!hasLowerCase(), "Cannot call lowerCase() on a mixed-case alphabet");
/* 315:544 */       char[] lowerCased = new char[this.chars.length];
/* 316:545 */       for (int i = 0; i < this.chars.length; i++) {
/* 317:546 */         lowerCased[i] = Ascii.toLowerCase(this.chars[i]);
/* 318:    */       }
/* 319:548 */       return new Alphabet(this.name + ".lowerCase()", lowerCased);
/* 320:    */     }
/* 321:    */     
/* 322:    */     public boolean matches(char c)
/* 323:    */     {
/* 324:554 */       return (CharMatcher.ASCII.matches(c)) && (this.decodabet[c] != -1);
/* 325:    */     }
/* 326:    */     
/* 327:    */     public String toString()
/* 328:    */     {
/* 329:559 */       return this.name;
/* 330:    */     }
/* 331:    */   }
/* 332:    */   
/* 333:    */   static final class StandardBaseEncoding
/* 334:    */     extends BaseEncoding
/* 335:    */   {
/* 336:    */     private final BaseEncoding.Alphabet alphabet;
/* 337:    */     @Nullable
/* 338:    */     private final Character paddingChar;
/* 339:    */     private transient BaseEncoding upperCase;
/* 340:    */     private transient BaseEncoding lowerCase;
/* 341:    */     
/* 342:    */     StandardBaseEncoding(String name, String alphabetChars, @Nullable Character paddingChar)
/* 343:    */     {
/* 344:571 */       this(new BaseEncoding.Alphabet(name, alphabetChars.toCharArray()), paddingChar);
/* 345:    */     }
/* 346:    */     
/* 347:    */     StandardBaseEncoding(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/* 348:    */     {
/* 349:575 */       this.alphabet = ((BaseEncoding.Alphabet)Preconditions.checkNotNull(alphabet));
/* 350:576 */       Preconditions.checkArgument((paddingChar == null) || (!alphabet.matches(paddingChar.charValue())), "Padding character %s was already in alphabet", new Object[] { paddingChar });
/* 351:    */       
/* 352:578 */       this.paddingChar = paddingChar;
/* 353:    */     }
/* 354:    */     
/* 355:    */     CharMatcher padding()
/* 356:    */     {
/* 357:583 */       return this.paddingChar == null ? CharMatcher.NONE : CharMatcher.is(this.paddingChar.charValue());
/* 358:    */     }
/* 359:    */     
/* 360:    */     int maxEncodedSize(int bytes)
/* 361:    */     {
/* 362:588 */       return this.alphabet.charsPerChunk * IntMath.divide(bytes, this.alphabet.bytesPerChunk, RoundingMode.CEILING);
/* 363:    */     }
/* 364:    */     
/* 365:    */     GwtWorkarounds.ByteOutput encodingStream(final GwtWorkarounds.CharOutput out)
/* 366:    */     {
/* 367:593 */       Preconditions.checkNotNull(out);
/* 368:594 */       new GwtWorkarounds.ByteOutput()
/* 369:    */       {
/* 370:595 */         int bitBuffer = 0;
/* 371:596 */         int bitBufferLength = 0;
/* 372:597 */         int writtenChars = 0;
/* 373:    */         
/* 374:    */         public void write(byte b)
/* 375:    */           throws IOException
/* 376:    */         {
/* 377:601 */           this.bitBuffer <<= 8;
/* 378:602 */           this.bitBuffer |= b & 0xFF;
/* 379:603 */           this.bitBufferLength += 8;
/* 380:604 */           while (this.bitBufferLength >= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar)
/* 381:    */           {
/* 382:605 */             int charIndex = this.bitBuffer >> this.bitBufferLength - BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar & BaseEncoding.StandardBaseEncoding.this.alphabet.mask;
/* 383:    */             
/* 384:607 */             out.write(BaseEncoding.StandardBaseEncoding.this.alphabet.encode(charIndex));
/* 385:608 */             this.writtenChars += 1;
/* 386:609 */             this.bitBufferLength -= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/* 387:    */           }
/* 388:    */         }
/* 389:    */         
/* 390:    */         public void flush()
/* 391:    */           throws IOException
/* 392:    */         {
/* 393:615 */           out.flush();
/* 394:    */         }
/* 395:    */         
/* 396:    */         public void close()
/* 397:    */           throws IOException
/* 398:    */         {
/* 399:620 */           if (this.bitBufferLength > 0)
/* 400:    */           {
/* 401:621 */             int charIndex = this.bitBuffer << BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar - this.bitBufferLength & BaseEncoding.StandardBaseEncoding.this.alphabet.mask;
/* 402:    */             
/* 403:623 */             out.write(BaseEncoding.StandardBaseEncoding.this.alphabet.encode(charIndex));
/* 404:624 */             this.writtenChars += 1;
/* 405:625 */             if (BaseEncoding.StandardBaseEncoding.this.paddingChar != null) {
/* 406:626 */               while (this.writtenChars % BaseEncoding.StandardBaseEncoding.this.alphabet.charsPerChunk != 0)
/* 407:    */               {
/* 408:627 */                 out.write(BaseEncoding.StandardBaseEncoding.this.paddingChar.charValue());
/* 409:628 */                 this.writtenChars += 1;
/* 410:    */               }
/* 411:    */             }
/* 412:    */           }
/* 413:632 */           out.close();
/* 414:    */         }
/* 415:    */       };
/* 416:    */     }
/* 417:    */     
/* 418:    */     int maxDecodedSize(int chars)
/* 419:    */     {
/* 420:639 */       return (int)((this.alphabet.bitsPerChar * chars + 7L) / 8L);
/* 421:    */     }
/* 422:    */     
/* 423:    */     GwtWorkarounds.ByteInput decodingStream(final GwtWorkarounds.CharInput reader)
/* 424:    */     {
/* 425:644 */       Preconditions.checkNotNull(reader);
/* 426:645 */       new GwtWorkarounds.ByteInput()
/* 427:    */       {
/* 428:646 */         int bitBuffer = 0;
/* 429:647 */         int bitBufferLength = 0;
/* 430:648 */         int readChars = 0;
/* 431:649 */         boolean hitPadding = false;
/* 432:650 */         final CharMatcher paddingMatcher = BaseEncoding.StandardBaseEncoding.this.padding();
/* 433:    */         
/* 434:    */         public int read()
/* 435:    */           throws IOException
/* 436:    */         {
/* 437:    */           for (;;)
/* 438:    */           {
/* 439:655 */             int readChar = reader.read();
/* 440:656 */             if (readChar == -1)
/* 441:    */             {
/* 442:657 */               if ((!this.hitPadding) && (!BaseEncoding.StandardBaseEncoding.this.alphabet.isValidPaddingStartPosition(this.readChars))) {
/* 443:658 */                 throw new BaseEncoding.DecodingException("Invalid input length " + this.readChars);
/* 444:    */               }
/* 445:660 */               return -1;
/* 446:    */             }
/* 447:662 */             this.readChars += 1;
/* 448:663 */             char ch = (char)readChar;
/* 449:664 */             if (this.paddingMatcher.matches(ch))
/* 450:    */             {
/* 451:665 */               if ((!this.hitPadding) && ((this.readChars == 1) || (!BaseEncoding.StandardBaseEncoding.this.alphabet.isValidPaddingStartPosition(this.readChars - 1)))) {
/* 452:667 */                 throw new BaseEncoding.DecodingException("Padding cannot start at index " + this.readChars);
/* 453:    */               }
/* 454:669 */               this.hitPadding = true;
/* 455:    */             }
/* 456:    */             else
/* 457:    */             {
/* 458:670 */               if (this.hitPadding) {
/* 459:671 */                 throw new BaseEncoding.DecodingException("Expected padding character but found '" + ch + "' at index " + this.readChars);
/* 460:    */               }
/* 461:674 */               this.bitBuffer <<= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/* 462:675 */               this.bitBuffer |= BaseEncoding.StandardBaseEncoding.this.alphabet.decode(ch);
/* 463:676 */               this.bitBufferLength += BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/* 464:678 */               if (this.bitBufferLength >= 8)
/* 465:    */               {
/* 466:679 */                 this.bitBufferLength -= 8;
/* 467:680 */                 return this.bitBuffer >> this.bitBufferLength & 0xFF;
/* 468:    */               }
/* 469:    */             }
/* 470:    */           }
/* 471:    */         }
/* 472:    */         
/* 473:    */         public void close()
/* 474:    */           throws IOException
/* 475:    */         {
/* 476:688 */           reader.close();
/* 477:    */         }
/* 478:    */       };
/* 479:    */     }
/* 480:    */     
/* 481:    */     public BaseEncoding omitPadding()
/* 482:    */     {
/* 483:695 */       return this.paddingChar == null ? this : new StandardBaseEncoding(this.alphabet, null);
/* 484:    */     }
/* 485:    */     
/* 486:    */     public BaseEncoding withPadChar(char padChar)
/* 487:    */     {
/* 488:700 */       if ((8 % this.alphabet.bitsPerChar == 0) || ((this.paddingChar != null) && (this.paddingChar.charValue() == padChar))) {
/* 489:702 */         return this;
/* 490:    */       }
/* 491:704 */       return new StandardBaseEncoding(this.alphabet, Character.valueOf(padChar));
/* 492:    */     }
/* 493:    */     
/* 494:    */     public BaseEncoding withSeparator(String separator, int afterEveryChars)
/* 495:    */     {
/* 496:710 */       Preconditions.checkNotNull(separator);
/* 497:711 */       Preconditions.checkArgument(padding().or(this.alphabet).matchesNoneOf(separator), "Separator cannot contain alphabet or padding characters");
/* 498:    */       
/* 499:713 */       return new BaseEncoding.SeparatedBaseEncoding(this, separator, afterEveryChars);
/* 500:    */     }
/* 501:    */     
/* 502:    */     public BaseEncoding upperCase()
/* 503:    */     {
/* 504:721 */       BaseEncoding result = this.upperCase;
/* 505:722 */       if (result == null)
/* 506:    */       {
/* 507:723 */         BaseEncoding.Alphabet upper = this.alphabet.upperCase();
/* 508:724 */         result = this.upperCase = upper == this.alphabet ? this : new StandardBaseEncoding(upper, this.paddingChar);
/* 509:    */       }
/* 510:727 */       return result;
/* 511:    */     }
/* 512:    */     
/* 513:    */     public BaseEncoding lowerCase()
/* 514:    */     {
/* 515:732 */       BaseEncoding result = this.lowerCase;
/* 516:733 */       if (result == null)
/* 517:    */       {
/* 518:734 */         BaseEncoding.Alphabet lower = this.alphabet.lowerCase();
/* 519:735 */         result = this.lowerCase = lower == this.alphabet ? this : new StandardBaseEncoding(lower, this.paddingChar);
/* 520:    */       }
/* 521:738 */       return result;
/* 522:    */     }
/* 523:    */     
/* 524:    */     public String toString()
/* 525:    */     {
/* 526:743 */       StringBuilder builder = new StringBuilder("BaseEncoding.");
/* 527:744 */       builder.append(this.alphabet.toString());
/* 528:745 */       if (8 % this.alphabet.bitsPerChar != 0) {
/* 529:746 */         if (this.paddingChar == null) {
/* 530:747 */           builder.append(".omitPadding()");
/* 531:    */         } else {
/* 532:749 */           builder.append(".withPadChar(").append(this.paddingChar).append(')');
/* 533:    */         }
/* 534:    */       }
/* 535:752 */       return builder.toString();
/* 536:    */     }
/* 537:    */   }
/* 538:    */   
/* 539:    */   static GwtWorkarounds.CharInput ignoringInput(GwtWorkarounds.CharInput delegate, final CharMatcher toIgnore)
/* 540:    */   {
/* 541:757 */     Preconditions.checkNotNull(delegate);
/* 542:758 */     Preconditions.checkNotNull(toIgnore);
/* 543:759 */     new GwtWorkarounds.CharInput()
/* 544:    */     {
/* 545:    */       public int read()
/* 546:    */         throws IOException
/* 547:    */       {
/* 548:    */         int readChar;
/* 549:    */         do
/* 550:    */         {
/* 551:764 */           readChar = this.val$delegate.read();
/* 552:765 */         } while ((readChar != -1) && (toIgnore.matches((char)readChar)));
/* 553:766 */         return readChar;
/* 554:    */       }
/* 555:    */       
/* 556:    */       public void close()
/* 557:    */         throws IOException
/* 558:    */       {
/* 559:771 */         this.val$delegate.close();
/* 560:    */       }
/* 561:    */     };
/* 562:    */   }
/* 563:    */   
/* 564:    */   static GwtWorkarounds.CharOutput separatingOutput(final GwtWorkarounds.CharOutput delegate, final String separator, int afterEveryChars)
/* 565:    */   {
/* 566:778 */     Preconditions.checkNotNull(delegate);
/* 567:779 */     Preconditions.checkNotNull(separator);
/* 568:780 */     Preconditions.checkArgument(afterEveryChars > 0);
/* 569:781 */     new GwtWorkarounds.CharOutput()
/* 570:    */     {
/* 571:782 */       int charsUntilSeparator = this.val$afterEveryChars;
/* 572:    */       
/* 573:    */       public void write(char c)
/* 574:    */         throws IOException
/* 575:    */       {
/* 576:786 */         if (this.charsUntilSeparator == 0)
/* 577:    */         {
/* 578:787 */           for (int i = 0; i < separator.length(); i++) {
/* 579:788 */             delegate.write(separator.charAt(i));
/* 580:    */           }
/* 581:790 */           this.charsUntilSeparator = this.val$afterEveryChars;
/* 582:    */         }
/* 583:792 */         delegate.write(c);
/* 584:793 */         this.charsUntilSeparator -= 1;
/* 585:    */       }
/* 586:    */       
/* 587:    */       public void flush()
/* 588:    */         throws IOException
/* 589:    */       {
/* 590:798 */         delegate.flush();
/* 591:    */       }
/* 592:    */       
/* 593:    */       public void close()
/* 594:    */         throws IOException
/* 595:    */       {
/* 596:803 */         delegate.close();
/* 597:    */       }
/* 598:    */     };
/* 599:    */   }
/* 600:    */   
/* 601:    */   static final class SeparatedBaseEncoding
/* 602:    */     extends BaseEncoding
/* 603:    */   {
/* 604:    */     private final BaseEncoding delegate;
/* 605:    */     private final String separator;
/* 606:    */     private final int afterEveryChars;
/* 607:    */     private final CharMatcher separatorChars;
/* 608:    */     
/* 609:    */     SeparatedBaseEncoding(BaseEncoding delegate, String separator, int afterEveryChars)
/* 610:    */     {
/* 611:815 */       this.delegate = ((BaseEncoding)Preconditions.checkNotNull(delegate));
/* 612:816 */       this.separator = ((String)Preconditions.checkNotNull(separator));
/* 613:817 */       this.afterEveryChars = afterEveryChars;
/* 614:818 */       Preconditions.checkArgument(afterEveryChars > 0, "Cannot add a separator after every %s chars", new Object[] { Integer.valueOf(afterEveryChars) });
/* 615:    */       
/* 616:820 */       this.separatorChars = CharMatcher.anyOf(separator).precomputed();
/* 617:    */     }
/* 618:    */     
/* 619:    */     CharMatcher padding()
/* 620:    */     {
/* 621:825 */       return this.delegate.padding();
/* 622:    */     }
/* 623:    */     
/* 624:    */     int maxEncodedSize(int bytes)
/* 625:    */     {
/* 626:830 */       int unseparatedSize = this.delegate.maxEncodedSize(bytes);
/* 627:831 */       return unseparatedSize + this.separator.length() * IntMath.divide(Math.max(0, unseparatedSize - 1), this.afterEveryChars, RoundingMode.FLOOR);
/* 628:    */     }
/* 629:    */     
/* 630:    */     GwtWorkarounds.ByteOutput encodingStream(GwtWorkarounds.CharOutput output)
/* 631:    */     {
/* 632:837 */       return this.delegate.encodingStream(separatingOutput(output, this.separator, this.afterEveryChars));
/* 633:    */     }
/* 634:    */     
/* 635:    */     int maxDecodedSize(int chars)
/* 636:    */     {
/* 637:842 */       return this.delegate.maxDecodedSize(chars);
/* 638:    */     }
/* 639:    */     
/* 640:    */     GwtWorkarounds.ByteInput decodingStream(GwtWorkarounds.CharInput input)
/* 641:    */     {
/* 642:847 */       return this.delegate.decodingStream(ignoringInput(input, this.separatorChars));
/* 643:    */     }
/* 644:    */     
/* 645:    */     public BaseEncoding omitPadding()
/* 646:    */     {
/* 647:852 */       return this.delegate.omitPadding().withSeparator(this.separator, this.afterEveryChars);
/* 648:    */     }
/* 649:    */     
/* 650:    */     public BaseEncoding withPadChar(char padChar)
/* 651:    */     {
/* 652:857 */       return this.delegate.withPadChar(padChar).withSeparator(this.separator, this.afterEveryChars);
/* 653:    */     }
/* 654:    */     
/* 655:    */     public BaseEncoding withSeparator(String separator, int afterEveryChars)
/* 656:    */     {
/* 657:862 */       throw new UnsupportedOperationException("Already have a separator");
/* 658:    */     }
/* 659:    */     
/* 660:    */     public BaseEncoding upperCase()
/* 661:    */     {
/* 662:867 */       return this.delegate.upperCase().withSeparator(this.separator, this.afterEveryChars);
/* 663:    */     }
/* 664:    */     
/* 665:    */     public BaseEncoding lowerCase()
/* 666:    */     {
/* 667:872 */       return this.delegate.lowerCase().withSeparator(this.separator, this.afterEveryChars);
/* 668:    */     }
/* 669:    */     
/* 670:    */     public String toString()
/* 671:    */     {
/* 672:877 */       return this.delegate.toString() + ".withSeparator(\"" + this.separator + "\", " + this.afterEveryChars + ")";
/* 673:    */     }
/* 674:    */   }
/* 675:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.io.BaseEncoding
 * JD-Core Version:    0.7.0.1
 */
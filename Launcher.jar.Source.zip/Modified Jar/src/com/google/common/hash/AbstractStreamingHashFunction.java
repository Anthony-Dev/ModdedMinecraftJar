/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.ByteOrder;
/*   6:    */ import java.nio.charset.Charset;
/*   7:    */ 
/*   8:    */ abstract class AbstractStreamingHashFunction
/*   9:    */   implements HashFunction
/*  10:    */ {
/*  11:    */   public <T> HashCode hashObject(T instance, Funnel<? super T> funnel)
/*  12:    */   {
/*  13: 37 */     return newHasher().putObject(instance, funnel).hash();
/*  14:    */   }
/*  15:    */   
/*  16:    */   public HashCode hashUnencodedChars(CharSequence input)
/*  17:    */   {
/*  18: 41 */     return newHasher().putUnencodedChars(input).hash();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public HashCode hashString(CharSequence input, Charset charset)
/*  22:    */   {
/*  23: 45 */     return newHasher().putString(input, charset).hash();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public HashCode hashInt(int input)
/*  27:    */   {
/*  28: 49 */     return newHasher().putInt(input).hash();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public HashCode hashLong(long input)
/*  32:    */   {
/*  33: 53 */     return newHasher().putLong(input).hash();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public HashCode hashBytes(byte[] input)
/*  37:    */   {
/*  38: 57 */     return newHasher().putBytes(input).hash();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public HashCode hashBytes(byte[] input, int off, int len)
/*  42:    */   {
/*  43: 61 */     return newHasher().putBytes(input, off, len).hash();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Hasher newHasher(int expectedInputSize)
/*  47:    */   {
/*  48: 65 */     Preconditions.checkArgument(expectedInputSize >= 0);
/*  49: 66 */     return newHasher();
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected static abstract class AbstractStreamingHasher
/*  53:    */     extends AbstractHasher
/*  54:    */   {
/*  55:    */     private final ByteBuffer buffer;
/*  56:    */     private final int bufferSize;
/*  57:    */     private final int chunkSize;
/*  58:    */     
/*  59:    */     protected AbstractStreamingHasher(int chunkSize)
/*  60:    */     {
/*  61: 95 */       this(chunkSize, chunkSize);
/*  62:    */     }
/*  63:    */     
/*  64:    */     protected AbstractStreamingHasher(int chunkSize, int bufferSize)
/*  65:    */     {
/*  66:109 */       Preconditions.checkArgument(bufferSize % chunkSize == 0);
/*  67:    */       
/*  68:    */ 
/*  69:112 */       this.buffer = ByteBuffer.allocate(bufferSize + 7).order(ByteOrder.LITTLE_ENDIAN);
/*  70:    */       
/*  71:    */ 
/*  72:115 */       this.bufferSize = bufferSize;
/*  73:116 */       this.chunkSize = chunkSize;
/*  74:    */     }
/*  75:    */     
/*  76:    */     protected abstract void process(ByteBuffer paramByteBuffer);
/*  77:    */     
/*  78:    */     protected void processRemaining(ByteBuffer bb)
/*  79:    */     {
/*  80:133 */       bb.position(bb.limit());
/*  81:134 */       bb.limit(this.chunkSize + 7);
/*  82:135 */       while (bb.position() < this.chunkSize) {
/*  83:136 */         bb.putLong(0L);
/*  84:    */       }
/*  85:138 */       bb.limit(this.chunkSize);
/*  86:139 */       bb.flip();
/*  87:140 */       process(bb);
/*  88:    */     }
/*  89:    */     
/*  90:    */     public final Hasher putBytes(byte[] bytes)
/*  91:    */     {
/*  92:145 */       return putBytes(bytes, 0, bytes.length);
/*  93:    */     }
/*  94:    */     
/*  95:    */     public final Hasher putBytes(byte[] bytes, int off, int len)
/*  96:    */     {
/*  97:150 */       return putBytes(ByteBuffer.wrap(bytes, off, len).order(ByteOrder.LITTLE_ENDIAN));
/*  98:    */     }
/*  99:    */     
/* 100:    */     private Hasher putBytes(ByteBuffer readBuffer)
/* 101:    */     {
/* 102:155 */       if (readBuffer.remaining() <= this.buffer.remaining())
/* 103:    */       {
/* 104:156 */         this.buffer.put(readBuffer);
/* 105:157 */         munchIfFull();
/* 106:158 */         return this;
/* 107:    */       }
/* 108:162 */       int bytesToCopy = this.bufferSize - this.buffer.position();
/* 109:163 */       for (int i = 0; i < bytesToCopy; i++) {
/* 110:164 */         this.buffer.put(readBuffer.get());
/* 111:    */       }
/* 112:166 */       munch();
/* 113:169 */       while (readBuffer.remaining() >= this.chunkSize) {
/* 114:170 */         process(readBuffer);
/* 115:    */       }
/* 116:174 */       this.buffer.put(readBuffer);
/* 117:175 */       return this;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public final Hasher putUnencodedChars(CharSequence charSequence)
/* 121:    */     {
/* 122:180 */       for (int i = 0; i < charSequence.length(); i++) {
/* 123:181 */         putChar(charSequence.charAt(i));
/* 124:    */       }
/* 125:183 */       return this;
/* 126:    */     }
/* 127:    */     
/* 128:    */     public final Hasher putByte(byte b)
/* 129:    */     {
/* 130:188 */       this.buffer.put(b);
/* 131:189 */       munchIfFull();
/* 132:190 */       return this;
/* 133:    */     }
/* 134:    */     
/* 135:    */     public final Hasher putShort(short s)
/* 136:    */     {
/* 137:195 */       this.buffer.putShort(s);
/* 138:196 */       munchIfFull();
/* 139:197 */       return this;
/* 140:    */     }
/* 141:    */     
/* 142:    */     public final Hasher putChar(char c)
/* 143:    */     {
/* 144:202 */       this.buffer.putChar(c);
/* 145:203 */       munchIfFull();
/* 146:204 */       return this;
/* 147:    */     }
/* 148:    */     
/* 149:    */     public final Hasher putInt(int i)
/* 150:    */     {
/* 151:209 */       this.buffer.putInt(i);
/* 152:210 */       munchIfFull();
/* 153:211 */       return this;
/* 154:    */     }
/* 155:    */     
/* 156:    */     public final Hasher putLong(long l)
/* 157:    */     {
/* 158:216 */       this.buffer.putLong(l);
/* 159:217 */       munchIfFull();
/* 160:218 */       return this;
/* 161:    */     }
/* 162:    */     
/* 163:    */     public final <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/* 164:    */     {
/* 165:223 */       funnel.funnel(instance, this);
/* 166:224 */       return this;
/* 167:    */     }
/* 168:    */     
/* 169:    */     public final HashCode hash()
/* 170:    */     {
/* 171:229 */       munch();
/* 172:230 */       this.buffer.flip();
/* 173:231 */       if (this.buffer.remaining() > 0) {
/* 174:232 */         processRemaining(this.buffer);
/* 175:    */       }
/* 176:234 */       return makeHash();
/* 177:    */     }
/* 178:    */     
/* 179:    */     abstract HashCode makeHash();
/* 180:    */     
/* 181:    */     private void munchIfFull()
/* 182:    */     {
/* 183:241 */       if (this.buffer.remaining() < 8) {
/* 184:243 */         munch();
/* 185:    */       }
/* 186:    */     }
/* 187:    */     
/* 188:    */     private void munch()
/* 189:    */     {
/* 190:248 */       this.buffer.flip();
/* 191:249 */       while (this.buffer.remaining() >= this.chunkSize) {
/* 192:252 */         process(this.buffer);
/* 193:    */       }
/* 194:254 */       this.buffer.compact();
/* 195:    */     }
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.AbstractStreamingHashFunction
 * JD-Core Version:    0.7.0.1
 */
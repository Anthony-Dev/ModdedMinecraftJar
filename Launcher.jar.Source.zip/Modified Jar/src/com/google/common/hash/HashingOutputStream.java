/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.FilterOutputStream;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.io.OutputStream;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public final class HashingOutputStream
/* 11:   */   extends FilterOutputStream
/* 12:   */ {
/* 13:   */   private final Hasher hasher;
/* 14:   */   
/* 15:   */   public HashingOutputStream(HashFunction hashFunction, OutputStream out)
/* 16:   */   {
/* 17:46 */     super((OutputStream)Preconditions.checkNotNull(out));
/* 18:47 */     this.hasher = ((Hasher)Preconditions.checkNotNull(hashFunction.newHasher()));
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void write(int b)
/* 22:   */     throws IOException
/* 23:   */   {
/* 24:51 */     this.hasher.putByte((byte)b);
/* 25:52 */     this.out.write(b);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void write(byte[] bytes, int off, int len)
/* 29:   */     throws IOException
/* 30:   */   {
/* 31:56 */     this.hasher.putBytes(bytes, off, len);
/* 32:57 */     this.out.write(bytes, off, len);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public HashCode hash()
/* 36:   */   {
/* 37:65 */     return this.hasher.hash();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void close()
/* 41:   */     throws IOException
/* 42:   */   {
/* 43:72 */     this.out.close();
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.HashingOutputStream
 * JD-Core Version:    0.7.0.1
 */
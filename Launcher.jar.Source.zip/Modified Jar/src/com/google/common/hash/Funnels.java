/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.nio.charset.Charset;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public final class Funnels
/*  12:    */ {
/*  13:    */   public static Funnel<byte[]> byteArrayFunnel()
/*  14:    */   {
/*  15: 40 */     return ByteArrayFunnel.INSTANCE;
/*  16:    */   }
/*  17:    */   
/*  18:    */   private static enum ByteArrayFunnel
/*  19:    */     implements Funnel<byte[]>
/*  20:    */   {
/*  21: 44 */     INSTANCE;
/*  22:    */     
/*  23:    */     private ByteArrayFunnel() {}
/*  24:    */     
/*  25:    */     public void funnel(byte[] from, PrimitiveSink into)
/*  26:    */     {
/*  27: 47 */       into.putBytes(from);
/*  28:    */     }
/*  29:    */     
/*  30:    */     public String toString()
/*  31:    */     {
/*  32: 51 */       return "Funnels.byteArrayFunnel()";
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static Funnel<CharSequence> unencodedCharsFunnel()
/*  37:    */   {
/*  38: 63 */     return UnencodedCharsFunnel.INSTANCE;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private static enum UnencodedCharsFunnel
/*  42:    */     implements Funnel<CharSequence>
/*  43:    */   {
/*  44: 67 */     INSTANCE;
/*  45:    */     
/*  46:    */     private UnencodedCharsFunnel() {}
/*  47:    */     
/*  48:    */     public void funnel(CharSequence from, PrimitiveSink into)
/*  49:    */     {
/*  50: 70 */       into.putUnencodedChars(from);
/*  51:    */     }
/*  52:    */     
/*  53:    */     public String toString()
/*  54:    */     {
/*  55: 74 */       return "Funnels.unencodedCharsFunnel()";
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static Funnel<CharSequence> stringFunnel(Charset charset)
/*  60:    */   {
/*  61: 85 */     return new StringCharsetFunnel(charset);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static class StringCharsetFunnel
/*  65:    */     implements Funnel<CharSequence>, Serializable
/*  66:    */   {
/*  67:    */     private final Charset charset;
/*  68:    */     
/*  69:    */     StringCharsetFunnel(Charset charset)
/*  70:    */     {
/*  71: 92 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/*  72:    */     }
/*  73:    */     
/*  74:    */     public void funnel(CharSequence from, PrimitiveSink into)
/*  75:    */     {
/*  76: 96 */       into.putString(from, this.charset);
/*  77:    */     }
/*  78:    */     
/*  79:    */     public String toString()
/*  80:    */     {
/*  81:100 */       return "Funnels.stringFunnel(" + this.charset.name() + ")";
/*  82:    */     }
/*  83:    */     
/*  84:    */     public boolean equals(@Nullable Object o)
/*  85:    */     {
/*  86:104 */       if ((o instanceof StringCharsetFunnel))
/*  87:    */       {
/*  88:105 */         StringCharsetFunnel funnel = (StringCharsetFunnel)o;
/*  89:106 */         return this.charset.equals(funnel.charset);
/*  90:    */       }
/*  91:108 */       return false;
/*  92:    */     }
/*  93:    */     
/*  94:    */     public int hashCode()
/*  95:    */     {
/*  96:112 */       return StringCharsetFunnel.class.hashCode() ^ this.charset.hashCode();
/*  97:    */     }
/*  98:    */     
/*  99:    */     Object writeReplace()
/* 100:    */     {
/* 101:116 */       return new SerializedForm(this.charset);
/* 102:    */     }
/* 103:    */     
/* 104:    */     private static class SerializedForm
/* 105:    */       implements Serializable
/* 106:    */     {
/* 107:    */       private final String charsetCanonicalName;
/* 108:    */       private static final long serialVersionUID = 0L;
/* 109:    */       
/* 110:    */       SerializedForm(Charset charset)
/* 111:    */       {
/* 112:123 */         this.charsetCanonicalName = charset.name();
/* 113:    */       }
/* 114:    */       
/* 115:    */       private Object readResolve()
/* 116:    */       {
/* 117:127 */         return Funnels.stringFunnel(Charset.forName(this.charsetCanonicalName));
/* 118:    */       }
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static Funnel<Integer> integerFunnel()
/* 123:    */   {
/* 124:140 */     return IntegerFunnel.INSTANCE;
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static enum IntegerFunnel
/* 128:    */     implements Funnel<Integer>
/* 129:    */   {
/* 130:144 */     INSTANCE;
/* 131:    */     
/* 132:    */     private IntegerFunnel() {}
/* 133:    */     
/* 134:    */     public void funnel(Integer from, PrimitiveSink into)
/* 135:    */     {
/* 136:147 */       into.putInt(from.intValue());
/* 137:    */     }
/* 138:    */     
/* 139:    */     public String toString()
/* 140:    */     {
/* 141:151 */       return "Funnels.integerFunnel()";
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static <E> Funnel<Iterable<? extends E>> sequentialFunnel(Funnel<E> elementFunnel)
/* 146:    */   {
/* 147:162 */     return new SequentialFunnel(elementFunnel);
/* 148:    */   }
/* 149:    */   
/* 150:    */   private static class SequentialFunnel<E>
/* 151:    */     implements Funnel<Iterable<? extends E>>, Serializable
/* 152:    */   {
/* 153:    */     private final Funnel<E> elementFunnel;
/* 154:    */     
/* 155:    */     SequentialFunnel(Funnel<E> elementFunnel)
/* 156:    */     {
/* 157:169 */       this.elementFunnel = ((Funnel)Preconditions.checkNotNull(elementFunnel));
/* 158:    */     }
/* 159:    */     
/* 160:    */     public void funnel(Iterable<? extends E> from, PrimitiveSink into)
/* 161:    */     {
/* 162:173 */       for (E e : from) {
/* 163:174 */         this.elementFunnel.funnel(e, into);
/* 164:    */       }
/* 165:    */     }
/* 166:    */     
/* 167:    */     public String toString()
/* 168:    */     {
/* 169:179 */       return "Funnels.sequentialFunnel(" + this.elementFunnel + ")";
/* 170:    */     }
/* 171:    */     
/* 172:    */     public boolean equals(@Nullable Object o)
/* 173:    */     {
/* 174:183 */       if ((o instanceof SequentialFunnel))
/* 175:    */       {
/* 176:184 */         SequentialFunnel<?> funnel = (SequentialFunnel)o;
/* 177:185 */         return this.elementFunnel.equals(funnel.elementFunnel);
/* 178:    */       }
/* 179:187 */       return false;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int hashCode()
/* 183:    */     {
/* 184:191 */       return SequentialFunnel.class.hashCode() ^ this.elementFunnel.hashCode();
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   public static Funnel<Long> longFunnel()
/* 189:    */   {
/* 190:201 */     return LongFunnel.INSTANCE;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private static enum LongFunnel
/* 194:    */     implements Funnel<Long>
/* 195:    */   {
/* 196:205 */     INSTANCE;
/* 197:    */     
/* 198:    */     private LongFunnel() {}
/* 199:    */     
/* 200:    */     public void funnel(Long from, PrimitiveSink into)
/* 201:    */     {
/* 202:208 */       into.putLong(from.longValue());
/* 203:    */     }
/* 204:    */     
/* 205:    */     public String toString()
/* 206:    */     {
/* 207:212 */       return "Funnels.longFunnel()";
/* 208:    */     }
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static OutputStream asOutputStream(PrimitiveSink sink)
/* 212:    */   {
/* 213:227 */     return new SinkAsStream(sink);
/* 214:    */   }
/* 215:    */   
/* 216:    */   private static class SinkAsStream
/* 217:    */     extends OutputStream
/* 218:    */   {
/* 219:    */     final PrimitiveSink sink;
/* 220:    */     
/* 221:    */     SinkAsStream(PrimitiveSink sink)
/* 222:    */     {
/* 223:233 */       this.sink = ((PrimitiveSink)Preconditions.checkNotNull(sink));
/* 224:    */     }
/* 225:    */     
/* 226:    */     public void write(int b)
/* 227:    */     {
/* 228:237 */       this.sink.putByte((byte)b);
/* 229:    */     }
/* 230:    */     
/* 231:    */     public void write(byte[] bytes)
/* 232:    */     {
/* 233:241 */       this.sink.putBytes(bytes);
/* 234:    */     }
/* 235:    */     
/* 236:    */     public void write(byte[] bytes, int off, int len)
/* 237:    */     {
/* 238:245 */       this.sink.putBytes(bytes, off, len);
/* 239:    */     }
/* 240:    */     
/* 241:    */     public String toString()
/* 242:    */     {
/* 243:249 */       return "Funnels.asOutputStream(" + this.sink + ")";
/* 244:    */     }
/* 245:    */   }
/* 246:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.Funnels
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.ByteArrayOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.nio.charset.Charset;
/*   7:    */ 
/*   8:    */ abstract class AbstractNonStreamingHashFunction
/*   9:    */   implements HashFunction
/*  10:    */ {
/*  11:    */   public Hasher newHasher()
/*  12:    */   {
/*  13: 35 */     return new BufferingHasher(32);
/*  14:    */   }
/*  15:    */   
/*  16:    */   public Hasher newHasher(int expectedInputSize)
/*  17:    */   {
/*  18: 40 */     Preconditions.checkArgument(expectedInputSize >= 0);
/*  19: 41 */     return new BufferingHasher(expectedInputSize);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public <T> HashCode hashObject(T instance, Funnel<? super T> funnel)
/*  23:    */   {
/*  24: 45 */     return newHasher().putObject(instance, funnel).hash();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public HashCode hashUnencodedChars(CharSequence input)
/*  28:    */   {
/*  29: 49 */     int len = input.length();
/*  30: 50 */     Hasher hasher = newHasher(len * 2);
/*  31: 51 */     for (int i = 0; i < len; i++) {
/*  32: 52 */       hasher.putChar(input.charAt(i));
/*  33:    */     }
/*  34: 54 */     return hasher.hash();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public HashCode hashString(CharSequence input, Charset charset)
/*  38:    */   {
/*  39: 58 */     return hashBytes(input.toString().getBytes(charset));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public HashCode hashInt(int input)
/*  43:    */   {
/*  44: 62 */     return newHasher(4).putInt(input).hash();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public HashCode hashLong(long input)
/*  48:    */   {
/*  49: 66 */     return newHasher(8).putLong(input).hash();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public HashCode hashBytes(byte[] input)
/*  53:    */   {
/*  54: 70 */     return hashBytes(input, 0, input.length);
/*  55:    */   }
/*  56:    */   
/*  57:    */   private final class BufferingHasher
/*  58:    */     extends AbstractHasher
/*  59:    */   {
/*  60:    */     final AbstractNonStreamingHashFunction.ExposedByteArrayOutputStream stream;
/*  61:    */     static final int BOTTOM_BYTE = 255;
/*  62:    */     
/*  63:    */     BufferingHasher(int expectedInputSize)
/*  64:    */     {
/*  65: 81 */       this.stream = new AbstractNonStreamingHashFunction.ExposedByteArrayOutputStream(expectedInputSize);
/*  66:    */     }
/*  67:    */     
/*  68:    */     public Hasher putByte(byte b)
/*  69:    */     {
/*  70: 86 */       this.stream.write(b);
/*  71: 87 */       return this;
/*  72:    */     }
/*  73:    */     
/*  74:    */     public Hasher putBytes(byte[] bytes)
/*  75:    */     {
/*  76:    */       try
/*  77:    */       {
/*  78: 93 */         this.stream.write(bytes);
/*  79:    */       }
/*  80:    */       catch (IOException e)
/*  81:    */       {
/*  82: 95 */         throw new RuntimeException(e);
/*  83:    */       }
/*  84: 97 */       return this;
/*  85:    */     }
/*  86:    */     
/*  87:    */     public Hasher putBytes(byte[] bytes, int off, int len)
/*  88:    */     {
/*  89:102 */       this.stream.write(bytes, off, len);
/*  90:103 */       return this;
/*  91:    */     }
/*  92:    */     
/*  93:    */     public Hasher putShort(short s)
/*  94:    */     {
/*  95:108 */       this.stream.write(s & 0xFF);
/*  96:109 */       this.stream.write(s >>> 8 & 0xFF);
/*  97:110 */       return this;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public Hasher putInt(int i)
/* 101:    */     {
/* 102:115 */       this.stream.write(i & 0xFF);
/* 103:116 */       this.stream.write(i >>> 8 & 0xFF);
/* 104:117 */       this.stream.write(i >>> 16 & 0xFF);
/* 105:118 */       this.stream.write(i >>> 24 & 0xFF);
/* 106:119 */       return this;
/* 107:    */     }
/* 108:    */     
/* 109:    */     public Hasher putLong(long l)
/* 110:    */     {
/* 111:124 */       for (int i = 0; i < 64; i += 8) {
/* 112:125 */         this.stream.write((byte)(int)(l >>> i & 0xFF));
/* 113:    */       }
/* 114:127 */       return this;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public Hasher putChar(char c)
/* 118:    */     {
/* 119:132 */       this.stream.write(c & 0xFF);
/* 120:133 */       this.stream.write(c >>> '\b' & 0xFF);
/* 121:134 */       return this;
/* 122:    */     }
/* 123:    */     
/* 124:    */     public <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/* 125:    */     {
/* 126:139 */       funnel.funnel(instance, this);
/* 127:140 */       return this;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public HashCode hash()
/* 131:    */     {
/* 132:145 */       return AbstractNonStreamingHashFunction.this.hashBytes(this.stream.byteArray(), 0, this.stream.length());
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   private static final class ExposedByteArrayOutputStream
/* 137:    */     extends ByteArrayOutputStream
/* 138:    */   {
/* 139:    */     ExposedByteArrayOutputStream(int expectedInputSize)
/* 140:    */     {
/* 141:152 */       super();
/* 142:    */     }
/* 143:    */     
/* 144:    */     byte[] byteArray()
/* 145:    */     {
/* 146:155 */       return this.buf;
/* 147:    */     }
/* 148:    */     
/* 149:    */     int length()
/* 150:    */     {
/* 151:158 */       return this.count;
/* 152:    */     }
/* 153:    */   }
/* 154:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.hash.AbstractNonStreamingHashFunction
 * JD-Core Version:    0.7.0.1
 */
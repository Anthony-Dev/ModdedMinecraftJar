/*  1:   */ package com.google.common.escape;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible(emulated=true)
/*  6:   */ final class Platform
/*  7:   */ {
/*  8:   */   static char[] charBufferFromThreadLocal()
/*  9:   */   {
/* 10:32 */     return (char[])DEST_TL.get();
/* 11:   */   }
/* 12:   */   
/* 13:40 */   private static final ThreadLocal<char[]> DEST_TL = new ThreadLocal()
/* 14:   */   {
/* 15:   */     protected char[] initialValue()
/* 16:   */     {
/* 17:43 */       return new char[1024];
/* 18:   */     }
/* 19:   */   };
/* 20:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.escape.Platform
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class UnicodeEscaper
/*  10:    */   extends Escaper
/*  11:    */ {
/*  12:    */   private static final int DEST_PAD = 32;
/*  13:    */   
/*  14:    */   protected abstract char[] escape(int paramInt);
/*  15:    */   
/*  16:    */   protected int nextEscapeIndex(CharSequence csq, int start, int end)
/*  17:    */   {
/*  18:117 */     int index = start;
/*  19:118 */     while (index < end)
/*  20:    */     {
/*  21:119 */       int cp = codePointAt(csq, index, end);
/*  22:120 */       if ((cp < 0) || (escape(cp) != null)) {
/*  23:    */         break;
/*  24:    */       }
/*  25:123 */       index += (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*  26:    */     }
/*  27:125 */     return index;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String escape(String string)
/*  31:    */   {
/*  32:153 */     Preconditions.checkNotNull(string);
/*  33:154 */     int end = string.length();
/*  34:155 */     int index = nextEscapeIndex(string, 0, end);
/*  35:156 */     return index == end ? string : escapeSlow(string, index);
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected final String escapeSlow(String s, int index)
/*  39:    */   {
/*  40:177 */     int end = s.length();
/*  41:    */     
/*  42:    */ 
/*  43:180 */     char[] dest = Platform.charBufferFromThreadLocal();
/*  44:181 */     int destIndex = 0;
/*  45:182 */     int unescapedChunkStart = 0;
/*  46:184 */     while (index < end)
/*  47:    */     {
/*  48:185 */       int cp = codePointAt(s, index, end);
/*  49:186 */       if (cp < 0) {
/*  50:187 */         throw new IllegalArgumentException("Trailing high surrogate at end of input");
/*  51:    */       }
/*  52:193 */       char[] escaped = escape(cp);
/*  53:194 */       int nextIndex = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*  54:195 */       if (escaped != null)
/*  55:    */       {
/*  56:196 */         int charsSkipped = index - unescapedChunkStart;
/*  57:    */         
/*  58:    */ 
/*  59:    */ 
/*  60:200 */         int sizeNeeded = destIndex + charsSkipped + escaped.length;
/*  61:201 */         if (dest.length < sizeNeeded)
/*  62:    */         {
/*  63:202 */           int destLength = sizeNeeded + (end - index) + 32;
/*  64:203 */           dest = growBuffer(dest, destIndex, destLength);
/*  65:    */         }
/*  66:206 */         if (charsSkipped > 0)
/*  67:    */         {
/*  68:207 */           s.getChars(unescapedChunkStart, index, dest, destIndex);
/*  69:208 */           destIndex += charsSkipped;
/*  70:    */         }
/*  71:210 */         if (escaped.length > 0)
/*  72:    */         {
/*  73:211 */           System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
/*  74:212 */           destIndex += escaped.length;
/*  75:    */         }
/*  76:215 */         unescapedChunkStart = nextIndex;
/*  77:    */       }
/*  78:217 */       index = nextEscapeIndex(s, nextIndex, end);
/*  79:    */     }
/*  80:222 */     int charsSkipped = end - unescapedChunkStart;
/*  81:223 */     if (charsSkipped > 0)
/*  82:    */     {
/*  83:224 */       int endIndex = destIndex + charsSkipped;
/*  84:225 */       if (dest.length < endIndex) {
/*  85:226 */         dest = growBuffer(dest, destIndex, endIndex);
/*  86:    */       }
/*  87:228 */       s.getChars(unescapedChunkStart, end, dest, destIndex);
/*  88:229 */       destIndex = endIndex;
/*  89:    */     }
/*  90:231 */     return new String(dest, 0, destIndex);
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected static int codePointAt(CharSequence seq, int index, int end)
/*  94:    */   {
/*  95:267 */     Preconditions.checkNotNull(seq);
/*  96:268 */     if (index < end)
/*  97:    */     {
/*  98:269 */       char c1 = seq.charAt(index++);
/*  99:270 */       if ((c1 < 55296) || (c1 > 57343)) {
/* 100:273 */         return c1;
/* 101:    */       }
/* 102:274 */       if (c1 <= 56319)
/* 103:    */       {
/* 104:276 */         if (index == end) {
/* 105:277 */           return -c1;
/* 106:    */         }
/* 107:280 */         char c2 = seq.charAt(index);
/* 108:281 */         if (Character.isLowSurrogate(c2)) {
/* 109:282 */           return Character.toCodePoint(c1, c2);
/* 110:    */         }
/* 111:284 */         throw new IllegalArgumentException("Expected low surrogate but got char '" + c2 + "' with value " + c2 + " at index " + index + " in '" + seq + "'");
/* 112:    */       }
/* 113:289 */       throw new IllegalArgumentException("Unexpected low surrogate character '" + c1 + "' with value " + c1 + " at index " + (index - 1) + " in '" + seq + "'");
/* 114:    */     }
/* 115:295 */     throw new IndexOutOfBoundsException("Index exceeds specified range");
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static char[] growBuffer(char[] dest, int index, int size)
/* 119:    */   {
/* 120:304 */     char[] copy = new char[size];
/* 121:305 */     if (index > 0) {
/* 122:306 */       System.arraycopy(dest, 0, copy, 0, index);
/* 123:    */     }
/* 124:308 */     return copy;
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.escape.UnicodeEscaper
 * JD-Core Version:    0.7.0.1
 */
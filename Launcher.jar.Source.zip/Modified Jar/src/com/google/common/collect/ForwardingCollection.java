/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ public abstract class ForwardingCollection<E>
/*  11:    */   extends ForwardingObject
/*  12:    */   implements Collection<E>
/*  13:    */ {
/*  14:    */   protected abstract Collection<E> delegate();
/*  15:    */   
/*  16:    */   public Iterator<E> iterator()
/*  17:    */   {
/*  18: 59 */     return delegate().iterator();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public int size()
/*  22:    */   {
/*  23: 64 */     return delegate().size();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public boolean removeAll(Collection<?> collection)
/*  27:    */   {
/*  28: 69 */     return delegate().removeAll(collection);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public boolean isEmpty()
/*  32:    */   {
/*  33: 74 */     return delegate().isEmpty();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean contains(Object object)
/*  37:    */   {
/*  38: 79 */     return delegate().contains(object);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean add(E element)
/*  42:    */   {
/*  43: 84 */     return delegate().add(element);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean remove(Object object)
/*  47:    */   {
/*  48: 89 */     return delegate().remove(object);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean containsAll(Collection<?> collection)
/*  52:    */   {
/*  53: 94 */     return delegate().containsAll(collection);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean addAll(Collection<? extends E> collection)
/*  57:    */   {
/*  58: 99 */     return delegate().addAll(collection);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean retainAll(Collection<?> collection)
/*  62:    */   {
/*  63:104 */     return delegate().retainAll(collection);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void clear()
/*  67:    */   {
/*  68:109 */     delegate().clear();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Object[] toArray()
/*  72:    */   {
/*  73:114 */     return delegate().toArray();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public <T> T[] toArray(T[] array)
/*  77:    */   {
/*  78:119 */     return delegate().toArray(array);
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected boolean standardContains(@Nullable Object object)
/*  82:    */   {
/*  83:130 */     return Iterators.contains(iterator(), object);
/*  84:    */   }
/*  85:    */   
/*  86:    */   protected boolean standardContainsAll(Collection<?> collection)
/*  87:    */   {
/*  88:141 */     return Collections2.containsAllImpl(this, collection);
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected boolean standardAddAll(Collection<? extends E> collection)
/*  92:    */   {
/*  93:152 */     return Iterators.addAll(this, collection.iterator());
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected boolean standardRemove(@Nullable Object object)
/*  97:    */   {
/*  98:164 */     Iterator<E> iterator = iterator();
/*  99:165 */     while (iterator.hasNext()) {
/* 100:166 */       if (Objects.equal(iterator.next(), object))
/* 101:    */       {
/* 102:167 */         iterator.remove();
/* 103:168 */         return true;
/* 104:    */       }
/* 105:    */     }
/* 106:171 */     return false;
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected boolean standardRemoveAll(Collection<?> collection)
/* 110:    */   {
/* 111:183 */     return Iterators.removeAll(iterator(), collection);
/* 112:    */   }
/* 113:    */   
/* 114:    */   protected boolean standardRetainAll(Collection<?> collection)
/* 115:    */   {
/* 116:195 */     return Iterators.retainAll(iterator(), collection);
/* 117:    */   }
/* 118:    */   
/* 119:    */   protected void standardClear()
/* 120:    */   {
/* 121:207 */     Iterators.clear(iterator());
/* 122:    */   }
/* 123:    */   
/* 124:    */   protected boolean standardIsEmpty()
/* 125:    */   {
/* 126:219 */     return !iterator().hasNext();
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected String standardToString()
/* 130:    */   {
/* 131:230 */     return Collections2.toStringImpl(this);
/* 132:    */   }
/* 133:    */   
/* 134:    */   protected Object[] standardToArray()
/* 135:    */   {
/* 136:241 */     Object[] newArray = new Object[size()];
/* 137:242 */     return toArray(newArray);
/* 138:    */   }
/* 139:    */   
/* 140:    */   protected <T> T[] standardToArray(T[] array)
/* 141:    */   {
/* 142:253 */     return ObjectArrays.toArrayImpl(this, array);
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingCollection
 * JD-Core Version:    0.7.0.1
 */
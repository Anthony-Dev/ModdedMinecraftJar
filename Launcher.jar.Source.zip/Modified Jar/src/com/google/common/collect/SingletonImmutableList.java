/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.List;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ final class SingletonImmutableList<E>
/*  10:    */   extends ImmutableList<E>
/*  11:    */ {
/*  12:    */   final transient E element;
/*  13:    */   
/*  14:    */   SingletonImmutableList(E element)
/*  15:    */   {
/*  16: 40 */     this.element = Preconditions.checkNotNull(element);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public E get(int index)
/*  20:    */   {
/*  21: 45 */     Preconditions.checkElementIndex(index, 1);
/*  22: 46 */     return this.element;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public int indexOf(@Nullable Object object)
/*  26:    */   {
/*  27: 50 */     return this.element.equals(object) ? 0 : -1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public UnmodifiableIterator<E> iterator()
/*  31:    */   {
/*  32: 54 */     return Iterators.singletonIterator(this.element);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public int lastIndexOf(@Nullable Object object)
/*  36:    */   {
/*  37: 58 */     return indexOf(object);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int size()
/*  41:    */   {
/*  42: 63 */     return 1;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public ImmutableList<E> subList(int fromIndex, int toIndex)
/*  46:    */   {
/*  47: 67 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, 1);
/*  48: 68 */     return fromIndex == toIndex ? ImmutableList.of() : this;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public ImmutableList<E> reverse()
/*  52:    */   {
/*  53: 72 */     return this;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean contains(@Nullable Object object)
/*  57:    */   {
/*  58: 76 */     return this.element.equals(object);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean equals(@Nullable Object object)
/*  62:    */   {
/*  63: 80 */     if (object == this) {
/*  64: 81 */       return true;
/*  65:    */     }
/*  66: 83 */     if ((object instanceof List))
/*  67:    */     {
/*  68: 84 */       List<?> that = (List)object;
/*  69: 85 */       return (that.size() == 1) && (this.element.equals(that.get(0)));
/*  70:    */     }
/*  71: 87 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public int hashCode()
/*  75:    */   {
/*  76: 93 */     return 31 + this.element.hashCode();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String toString()
/*  80:    */   {
/*  81: 97 */     String elementToString = this.element.toString();
/*  82: 98 */     return elementToString.length() + 2 + '[' + elementToString + ']';
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean isEmpty()
/*  86:    */   {
/*  87:106 */     return false;
/*  88:    */   }
/*  89:    */   
/*  90:    */   boolean isPartialView()
/*  91:    */   {
/*  92:110 */     return false;
/*  93:    */   }
/*  94:    */   
/*  95:    */   int copyIntoArray(Object[] dst, int offset)
/*  96:    */   {
/*  97:115 */     dst[offset] = this.element;
/*  98:116 */     return offset + 1;
/*  99:    */   }
/* 100:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableList
 * JD-Core Version:    0.7.0.1
 */
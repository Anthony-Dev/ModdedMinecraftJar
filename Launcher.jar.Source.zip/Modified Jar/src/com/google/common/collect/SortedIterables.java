/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.Comparator;
/*  6:   */ import java.util.SortedSet;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ final class SortedIterables
/* 10:   */ {
/* 11:   */   public static boolean hasSameComparator(Comparator<?> comparator, Iterable<?> elements)
/* 12:   */   {
/* 13:38 */     Preconditions.checkNotNull(comparator);
/* 14:39 */     Preconditions.checkNotNull(elements);
/* 15:   */     Comparator<?> comparator2;
/* 16:41 */     if ((elements instanceof SortedSet))
/* 17:   */     {
/* 18:42 */       comparator2 = comparator((SortedSet)elements);
/* 19:   */     }
/* 20:   */     else
/* 21:   */     {
/* 22:   */       Comparator<?> comparator2;
/* 23:43 */       if ((elements instanceof SortedIterable)) {
/* 24:44 */         comparator2 = ((SortedIterable)elements).comparator();
/* 25:   */       } else {
/* 26:46 */         return false;
/* 27:   */       }
/* 28:   */     }
/* 29:   */     Comparator<?> comparator2;
/* 30:48 */     return comparator.equals(comparator2);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static <E> Comparator<? super E> comparator(SortedSet<E> sortedSet)
/* 34:   */   {
/* 35:54 */     Comparator<? super E> result = sortedSet.comparator();
/* 36:55 */     if (result == null) {
/* 37:56 */       result = Ordering.natural();
/* 38:   */     }
/* 39:58 */     return result;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SortedIterables
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.InvalidObjectException;
/*   6:    */ import java.io.ObjectInputStream;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.RandomAccess;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableList<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements List<E>, RandomAccess
/*  18:    */ {
/*  19: 66 */   private static final ImmutableList<Object> EMPTY = new RegularImmutableList(ObjectArrays.EMPTY_ARRAY);
/*  20:    */   
/*  21:    */   public static <E> ImmutableList<E> of()
/*  22:    */   {
/*  23: 77 */     return EMPTY;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static <E> ImmutableList<E> of(E element)
/*  27:    */   {
/*  28: 89 */     return new SingletonImmutableList(element);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <E> ImmutableList<E> of(E e1, E e2)
/*  32:    */   {
/*  33: 98 */     return construct(new Object[] { e1, e2 });
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3)
/*  37:    */   {
/*  38:107 */     return construct(new Object[] { e1, e2, e3 });
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4)
/*  42:    */   {
/*  43:116 */     return construct(new Object[] { e1, e2, e3, e4 });
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5)
/*  47:    */   {
/*  48:125 */     return construct(new Object[] { e1, e2, e3, e4, e5 });
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6)
/*  52:    */   {
/*  53:134 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6 });
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7)
/*  57:    */   {
/*  58:144 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7 });
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8)
/*  62:    */   {
/*  63:154 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8 });
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9)
/*  67:    */   {
/*  68:164 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9 });
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10)
/*  72:    */   {
/*  73:174 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10 });
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11)
/*  77:    */   {
/*  78:184 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11 });
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11, E e12, E... others)
/*  82:    */   {
/*  83:199 */     Object[] array = new Object[12 + others.length];
/*  84:200 */     array[0] = e1;
/*  85:201 */     array[1] = e2;
/*  86:202 */     array[2] = e3;
/*  87:203 */     array[3] = e4;
/*  88:204 */     array[4] = e5;
/*  89:205 */     array[5] = e6;
/*  90:206 */     array[6] = e7;
/*  91:207 */     array[7] = e8;
/*  92:208 */     array[8] = e9;
/*  93:209 */     array[9] = e10;
/*  94:210 */     array[10] = e11;
/*  95:211 */     array[11] = e12;
/*  96:212 */     System.arraycopy(others, 0, array, 12, others.length);
/*  97:213 */     return construct(array);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static <E> ImmutableList<E> copyOf(Iterable<? extends E> elements)
/* 101:    */   {
/* 102:225 */     Preconditions.checkNotNull(elements);
/* 103:226 */     return (elements instanceof Collection) ? copyOf(Collections2.cast(elements)) : copyOf(elements.iterator());
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static <E> ImmutableList<E> copyOf(Collection<? extends E> elements)
/* 107:    */   {
/* 108:251 */     if ((elements instanceof ImmutableCollection))
/* 109:    */     {
/* 110:253 */       ImmutableList<E> list = ((ImmutableCollection)elements).asList();
/* 111:254 */       return list.isPartialView() ? asImmutableList(list.toArray()) : list;
/* 112:    */     }
/* 113:258 */     return construct(elements.toArray());
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static <E> ImmutableList<E> copyOf(Iterator<? extends E> elements)
/* 117:    */   {
/* 118:268 */     if (!elements.hasNext()) {
/* 119:269 */       return of();
/* 120:    */     }
/* 121:271 */     E first = elements.next();
/* 122:272 */     if (!elements.hasNext()) {
/* 123:273 */       return of(first);
/* 124:    */     }
/* 125:275 */     return new Builder().add(first).addAll(elements).build();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static <E> ImmutableList<E> copyOf(E[] elements)
/* 129:    */   {
/* 130:289 */     switch (elements.length)
/* 131:    */     {
/* 132:    */     case 0: 
/* 133:291 */       return of();
/* 134:    */     case 1: 
/* 135:293 */       return new SingletonImmutableList(elements[0]);
/* 136:    */     }
/* 137:295 */     return new RegularImmutableList(ObjectArrays.checkElementsNotNull((Object[])elements.clone()));
/* 138:    */   }
/* 139:    */   
/* 140:    */   private static <E> ImmutableList<E> construct(Object... elements)
/* 141:    */   {
/* 142:303 */     return asImmutableList(ObjectArrays.checkElementsNotNull(elements));
/* 143:    */   }
/* 144:    */   
/* 145:    */   static <E> ImmutableList<E> asImmutableList(Object[] elements)
/* 146:    */   {
/* 147:312 */     return asImmutableList(elements, elements.length);
/* 148:    */   }
/* 149:    */   
/* 150:    */   static <E> ImmutableList<E> asImmutableList(Object[] elements, int length)
/* 151:    */   {
/* 152:320 */     switch (length)
/* 153:    */     {
/* 154:    */     case 0: 
/* 155:322 */       return of();
/* 156:    */     case 1: 
/* 157:325 */       ImmutableList<E> list = new SingletonImmutableList(elements[0]);
/* 158:326 */       return list;
/* 159:    */     }
/* 160:328 */     if (length < elements.length) {
/* 161:329 */       elements = ObjectArrays.arraysCopyOf(elements, length);
/* 162:    */     }
/* 163:331 */     return new RegularImmutableList(elements);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public UnmodifiableIterator<E> iterator()
/* 167:    */   {
/* 168:340 */     return listIterator();
/* 169:    */   }
/* 170:    */   
/* 171:    */   public UnmodifiableListIterator<E> listIterator()
/* 172:    */   {
/* 173:344 */     return listIterator(0);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public UnmodifiableListIterator<E> listIterator(int index)
/* 177:    */   {
/* 178:348 */     new AbstractIndexedListIterator(size(), index)
/* 179:    */     {
/* 180:    */       protected E get(int index)
/* 181:    */       {
/* 182:351 */         return ImmutableList.this.get(index);
/* 183:    */       }
/* 184:    */     };
/* 185:    */   }
/* 186:    */   
/* 187:    */   public int indexOf(@Nullable Object object)
/* 188:    */   {
/* 189:358 */     return object == null ? -1 : Lists.indexOfImpl(this, object);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public int lastIndexOf(@Nullable Object object)
/* 193:    */   {
/* 194:363 */     return object == null ? -1 : Lists.lastIndexOfImpl(this, object);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public boolean contains(@Nullable Object object)
/* 198:    */   {
/* 199:368 */     return indexOf(object) >= 0;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 203:    */   {
/* 204:381 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/* 205:382 */     int length = toIndex - fromIndex;
/* 206:383 */     switch (length)
/* 207:    */     {
/* 208:    */     case 0: 
/* 209:385 */       return of();
/* 210:    */     case 1: 
/* 211:387 */       return of(get(fromIndex));
/* 212:    */     }
/* 213:389 */     return subListUnchecked(fromIndex, toIndex);
/* 214:    */   }
/* 215:    */   
/* 216:    */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/* 217:    */   {
/* 218:399 */     return new SubList(fromIndex, toIndex - fromIndex);
/* 219:    */   }
/* 220:    */   
/* 221:    */   class SubList
/* 222:    */     extends ImmutableList<E>
/* 223:    */   {
/* 224:    */     final transient int offset;
/* 225:    */     final transient int length;
/* 226:    */     
/* 227:    */     SubList(int offset, int length)
/* 228:    */     {
/* 229:407 */       this.offset = offset;
/* 230:408 */       this.length = length;
/* 231:    */     }
/* 232:    */     
/* 233:    */     public int size()
/* 234:    */     {
/* 235:413 */       return this.length;
/* 236:    */     }
/* 237:    */     
/* 238:    */     public E get(int index)
/* 239:    */     {
/* 240:418 */       Preconditions.checkElementIndex(index, this.length);
/* 241:419 */       return ImmutableList.this.get(index + this.offset);
/* 242:    */     }
/* 243:    */     
/* 244:    */     public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 245:    */     {
/* 246:424 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, this.length);
/* 247:425 */       return ImmutableList.this.subList(fromIndex + this.offset, toIndex + this.offset);
/* 248:    */     }
/* 249:    */     
/* 250:    */     boolean isPartialView()
/* 251:    */     {
/* 252:430 */       return true;
/* 253:    */     }
/* 254:    */   }
/* 255:    */   
/* 256:    */   @Deprecated
/* 257:    */   public final boolean addAll(int index, Collection<? extends E> newElements)
/* 258:    */   {
/* 259:443 */     throw new UnsupportedOperationException();
/* 260:    */   }
/* 261:    */   
/* 262:    */   @Deprecated
/* 263:    */   public final E set(int index, E element)
/* 264:    */   {
/* 265:455 */     throw new UnsupportedOperationException();
/* 266:    */   }
/* 267:    */   
/* 268:    */   @Deprecated
/* 269:    */   public final void add(int index, E element)
/* 270:    */   {
/* 271:467 */     throw new UnsupportedOperationException();
/* 272:    */   }
/* 273:    */   
/* 274:    */   @Deprecated
/* 275:    */   public final E remove(int index)
/* 276:    */   {
/* 277:479 */     throw new UnsupportedOperationException();
/* 278:    */   }
/* 279:    */   
/* 280:    */   public final ImmutableList<E> asList()
/* 281:    */   {
/* 282:488 */     return this;
/* 283:    */   }
/* 284:    */   
/* 285:    */   int copyIntoArray(Object[] dst, int offset)
/* 286:    */   {
/* 287:494 */     int size = size();
/* 288:495 */     for (int i = 0; i < size; i++) {
/* 289:496 */       dst[(offset + i)] = get(i);
/* 290:    */     }
/* 291:498 */     return offset + size;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public ImmutableList<E> reverse()
/* 295:    */   {
/* 296:510 */     return new ReverseImmutableList(this);
/* 297:    */   }
/* 298:    */   
/* 299:    */   private static class ReverseImmutableList<E>
/* 300:    */     extends ImmutableList<E>
/* 301:    */   {
/* 302:    */     private final transient ImmutableList<E> forwardList;
/* 303:    */     
/* 304:    */     ReverseImmutableList(ImmutableList<E> backingList)
/* 305:    */     {
/* 306:517 */       this.forwardList = backingList;
/* 307:    */     }
/* 308:    */     
/* 309:    */     private int reverseIndex(int index)
/* 310:    */     {
/* 311:521 */       return size() - 1 - index;
/* 312:    */     }
/* 313:    */     
/* 314:    */     private int reversePosition(int index)
/* 315:    */     {
/* 316:525 */       return size() - index;
/* 317:    */     }
/* 318:    */     
/* 319:    */     public ImmutableList<E> reverse()
/* 320:    */     {
/* 321:529 */       return this.forwardList;
/* 322:    */     }
/* 323:    */     
/* 324:    */     public boolean contains(@Nullable Object object)
/* 325:    */     {
/* 326:533 */       return this.forwardList.contains(object);
/* 327:    */     }
/* 328:    */     
/* 329:    */     public int indexOf(@Nullable Object object)
/* 330:    */     {
/* 331:537 */       int index = this.forwardList.lastIndexOf(object);
/* 332:538 */       return index >= 0 ? reverseIndex(index) : -1;
/* 333:    */     }
/* 334:    */     
/* 335:    */     public int lastIndexOf(@Nullable Object object)
/* 336:    */     {
/* 337:542 */       int index = this.forwardList.indexOf(object);
/* 338:543 */       return index >= 0 ? reverseIndex(index) : -1;
/* 339:    */     }
/* 340:    */     
/* 341:    */     public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 342:    */     {
/* 343:547 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/* 344:548 */       return this.forwardList.subList(reversePosition(toIndex), reversePosition(fromIndex)).reverse();
/* 345:    */     }
/* 346:    */     
/* 347:    */     public E get(int index)
/* 348:    */     {
/* 349:553 */       Preconditions.checkElementIndex(index, size());
/* 350:554 */       return this.forwardList.get(reverseIndex(index));
/* 351:    */     }
/* 352:    */     
/* 353:    */     public int size()
/* 354:    */     {
/* 355:558 */       return this.forwardList.size();
/* 356:    */     }
/* 357:    */     
/* 358:    */     boolean isPartialView()
/* 359:    */     {
/* 360:562 */       return this.forwardList.isPartialView();
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   public boolean equals(@Nullable Object obj)
/* 365:    */   {
/* 366:567 */     return Lists.equalsImpl(this, obj);
/* 367:    */   }
/* 368:    */   
/* 369:    */   public int hashCode()
/* 370:    */   {
/* 371:571 */     int hashCode = 1;
/* 372:572 */     int n = size();
/* 373:573 */     for (int i = 0; i < n; i++)
/* 374:    */     {
/* 375:574 */       hashCode = 31 * hashCode + get(i).hashCode();
/* 376:    */       
/* 377:576 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/* 378:    */     }
/* 379:579 */     return hashCode;
/* 380:    */   }
/* 381:    */   
/* 382:    */   static class SerializedForm
/* 383:    */     implements Serializable
/* 384:    */   {
/* 385:    */     final Object[] elements;
/* 386:    */     private static final long serialVersionUID = 0L;
/* 387:    */     
/* 388:    */     SerializedForm(Object[] elements)
/* 389:    */     {
/* 390:589 */       this.elements = elements;
/* 391:    */     }
/* 392:    */     
/* 393:    */     Object readResolve()
/* 394:    */     {
/* 395:592 */       return ImmutableList.copyOf(this.elements);
/* 396:    */     }
/* 397:    */   }
/* 398:    */   
/* 399:    */   private void readObject(ObjectInputStream stream)
/* 400:    */     throws InvalidObjectException
/* 401:    */   {
/* 402:599 */     throw new InvalidObjectException("Use SerializedForm");
/* 403:    */   }
/* 404:    */   
/* 405:    */   Object writeReplace()
/* 406:    */   {
/* 407:603 */     return new SerializedForm(toArray());
/* 408:    */   }
/* 409:    */   
/* 410:    */   public static <E> Builder<E> builder()
/* 411:    */   {
/* 412:611 */     return new Builder();
/* 413:    */   }
/* 414:    */   
/* 415:    */   public static final class Builder<E>
/* 416:    */     extends ImmutableCollection.ArrayBasedBuilder<E>
/* 417:    */   {
/* 418:    */     public Builder()
/* 419:    */     {
/* 420:636 */       this(4);
/* 421:    */     }
/* 422:    */     
/* 423:    */     Builder(int capacity)
/* 424:    */     {
/* 425:641 */       super();
/* 426:    */     }
/* 427:    */     
/* 428:    */     public Builder<E> add(E element)
/* 429:    */     {
/* 430:652 */       super.add(element);
/* 431:653 */       return this;
/* 432:    */     }
/* 433:    */     
/* 434:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 435:    */     {
/* 436:665 */       super.addAll(elements);
/* 437:666 */       return this;
/* 438:    */     }
/* 439:    */     
/* 440:    */     public Builder<E> add(E... elements)
/* 441:    */     {
/* 442:678 */       super.add(elements);
/* 443:679 */       return this;
/* 444:    */     }
/* 445:    */     
/* 446:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 447:    */     {
/* 448:691 */       super.addAll(elements);
/* 449:692 */       return this;
/* 450:    */     }
/* 451:    */     
/* 452:    */     public ImmutableList<E> build()
/* 453:    */     {
/* 454:700 */       return ImmutableList.asImmutableList(this.contents, this.size);
/* 455:    */     }
/* 456:    */   }
/* 457:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableList
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Set;
/*  13:    */ import javax.annotation.Nullable;
/*  14:    */ 
/*  15:    */ @GwtCompatible
/*  16:    */ class FilteredKeyMultimap<K, V>
/*  17:    */   extends AbstractMultimap<K, V>
/*  18:    */   implements FilteredMultimap<K, V>
/*  19:    */ {
/*  20:    */   final Multimap<K, V> unfiltered;
/*  21:    */   final Predicate<? super K> keyPredicate;
/*  22:    */   
/*  23:    */   FilteredKeyMultimap(Multimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/*  24:    */   {
/*  25: 44 */     this.unfiltered = ((Multimap)Preconditions.checkNotNull(unfiltered));
/*  26: 45 */     this.keyPredicate = ((Predicate)Preconditions.checkNotNull(keyPredicate));
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Multimap<K, V> unfiltered()
/*  30:    */   {
/*  31: 50 */     return this.unfiltered;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Predicate<? super Map.Entry<K, V>> entryPredicate()
/*  35:    */   {
/*  36: 55 */     return Maps.keyPredicateOnEntries(this.keyPredicate);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public int size()
/*  40:    */   {
/*  41: 60 */     int size = 0;
/*  42: 61 */     for (Collection<V> collection : asMap().values()) {
/*  43: 62 */       size += collection.size();
/*  44:    */     }
/*  45: 64 */     return size;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean containsKey(@Nullable Object key)
/*  49:    */   {
/*  50: 69 */     if (this.unfiltered.containsKey(key))
/*  51:    */     {
/*  52: 71 */       K k = key;
/*  53: 72 */       return this.keyPredicate.apply(k);
/*  54:    */     }
/*  55: 74 */     return false;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Collection<V> removeAll(Object key)
/*  59:    */   {
/*  60: 79 */     return containsKey(key) ? this.unfiltered.removeAll(key) : unmodifiableEmptyCollection();
/*  61:    */   }
/*  62:    */   
/*  63:    */   Collection<V> unmodifiableEmptyCollection()
/*  64:    */   {
/*  65: 83 */     if ((this.unfiltered instanceof SetMultimap)) {
/*  66: 84 */       return ImmutableSet.of();
/*  67:    */     }
/*  68: 86 */     return ImmutableList.of();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void clear()
/*  72:    */   {
/*  73: 92 */     keySet().clear();
/*  74:    */   }
/*  75:    */   
/*  76:    */   Set<K> createKeySet()
/*  77:    */   {
/*  78: 97 */     return Sets.filter(this.unfiltered.keySet(), this.keyPredicate);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Collection<V> get(K key)
/*  82:    */   {
/*  83:102 */     if (this.keyPredicate.apply(key)) {
/*  84:103 */       return this.unfiltered.get(key);
/*  85:    */     }
/*  86:104 */     if ((this.unfiltered instanceof SetMultimap)) {
/*  87:105 */       return new AddRejectingSet(key);
/*  88:    */     }
/*  89:107 */     return new AddRejectingList(key);
/*  90:    */   }
/*  91:    */   
/*  92:    */   static class AddRejectingSet<K, V>
/*  93:    */     extends ForwardingSet<V>
/*  94:    */   {
/*  95:    */     final K key;
/*  96:    */     
/*  97:    */     AddRejectingSet(K key)
/*  98:    */     {
/*  99:115 */       this.key = key;
/* 100:    */     }
/* 101:    */     
/* 102:    */     public boolean add(V element)
/* 103:    */     {
/* 104:120 */       throw new IllegalArgumentException("Key does not satisfy predicate: " + this.key);
/* 105:    */     }
/* 106:    */     
/* 107:    */     public boolean addAll(Collection<? extends V> collection)
/* 108:    */     {
/* 109:125 */       Preconditions.checkNotNull(collection);
/* 110:126 */       throw new IllegalArgumentException("Key does not satisfy predicate: " + this.key);
/* 111:    */     }
/* 112:    */     
/* 113:    */     protected Set<V> delegate()
/* 114:    */     {
/* 115:131 */       return Collections.emptySet();
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   static class AddRejectingList<K, V>
/* 120:    */     extends ForwardingList<V>
/* 121:    */   {
/* 122:    */     final K key;
/* 123:    */     
/* 124:    */     AddRejectingList(K key)
/* 125:    */     {
/* 126:139 */       this.key = key;
/* 127:    */     }
/* 128:    */     
/* 129:    */     public boolean add(V v)
/* 130:    */     {
/* 131:144 */       add(0, v);
/* 132:145 */       return true;
/* 133:    */     }
/* 134:    */     
/* 135:    */     public boolean addAll(Collection<? extends V> collection)
/* 136:    */     {
/* 137:150 */       addAll(0, collection);
/* 138:151 */       return true;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public void add(int index, V element)
/* 142:    */     {
/* 143:156 */       Preconditions.checkPositionIndex(index, 0);
/* 144:157 */       throw new IllegalArgumentException("Key does not satisfy predicate: " + this.key);
/* 145:    */     }
/* 146:    */     
/* 147:    */     public boolean addAll(int index, Collection<? extends V> elements)
/* 148:    */     {
/* 149:162 */       Preconditions.checkNotNull(elements);
/* 150:163 */       Preconditions.checkPositionIndex(index, 0);
/* 151:164 */       throw new IllegalArgumentException("Key does not satisfy predicate: " + this.key);
/* 152:    */     }
/* 153:    */     
/* 154:    */     protected List<V> delegate()
/* 155:    */     {
/* 156:169 */       return Collections.emptyList();
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   Iterator<Map.Entry<K, V>> entryIterator()
/* 161:    */   {
/* 162:175 */     throw new AssertionError("should never be called");
/* 163:    */   }
/* 164:    */   
/* 165:    */   Collection<Map.Entry<K, V>> createEntries()
/* 166:    */   {
/* 167:180 */     return new Entries();
/* 168:    */   }
/* 169:    */   
/* 170:    */   class Entries
/* 171:    */     extends ForwardingCollection<Map.Entry<K, V>>
/* 172:    */   {
/* 173:    */     Entries() {}
/* 174:    */     
/* 175:    */     protected Collection<Map.Entry<K, V>> delegate()
/* 176:    */     {
/* 177:186 */       return Collections2.filter(FilteredKeyMultimap.this.unfiltered.entries(), FilteredKeyMultimap.this.entryPredicate());
/* 178:    */     }
/* 179:    */     
/* 180:    */     public boolean remove(@Nullable Object o)
/* 181:    */     {
/* 182:192 */       if ((o instanceof Map.Entry))
/* 183:    */       {
/* 184:193 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 185:194 */         if ((FilteredKeyMultimap.this.unfiltered.containsKey(entry.getKey())) && (FilteredKeyMultimap.this.keyPredicate.apply(entry.getKey()))) {
/* 186:197 */           return FilteredKeyMultimap.this.unfiltered.remove(entry.getKey(), entry.getValue());
/* 187:    */         }
/* 188:    */       }
/* 189:200 */       return false;
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   Collection<V> createValues()
/* 194:    */   {
/* 195:206 */     return new FilteredMultimapValues(this);
/* 196:    */   }
/* 197:    */   
/* 198:    */   Map<K, Collection<V>> createAsMap()
/* 199:    */   {
/* 200:211 */     return Maps.filterKeys(this.unfiltered.asMap(), this.keyPredicate);
/* 201:    */   }
/* 202:    */   
/* 203:    */   Multiset<K> createKeys()
/* 204:    */   {
/* 205:216 */     return Multisets.filter(this.unfiltered.keys(), this.keyPredicate);
/* 206:    */   }
/* 207:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.FilteredKeyMultimap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import com.google.common.base.Predicates;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @GwtCompatible
/*  18:    */ class FilteredEntryMultimap<K, V>
/*  19:    */   extends AbstractMultimap<K, V>
/*  20:    */   implements FilteredMultimap<K, V>
/*  21:    */ {
/*  22:    */   final Multimap<K, V> unfiltered;
/*  23:    */   final Predicate<? super Map.Entry<K, V>> predicate;
/*  24:    */   
/*  25:    */   FilteredEntryMultimap(Multimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/*  26:    */   {
/*  27: 51 */     this.unfiltered = ((Multimap)Preconditions.checkNotNull(unfiltered));
/*  28: 52 */     this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Multimap<K, V> unfiltered()
/*  32:    */   {
/*  33: 57 */     return this.unfiltered;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Predicate<? super Map.Entry<K, V>> entryPredicate()
/*  37:    */   {
/*  38: 62 */     return this.predicate;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int size()
/*  42:    */   {
/*  43: 67 */     return entries().size();
/*  44:    */   }
/*  45:    */   
/*  46:    */   private boolean satisfies(K key, V value)
/*  47:    */   {
/*  48: 71 */     return this.predicate.apply(Maps.immutableEntry(key, value));
/*  49:    */   }
/*  50:    */   
/*  51:    */   final class ValuePredicate
/*  52:    */     implements Predicate<V>
/*  53:    */   {
/*  54:    */     private final K key;
/*  55:    */     
/*  56:    */     ValuePredicate()
/*  57:    */     {
/*  58: 79 */       this.key = key;
/*  59:    */     }
/*  60:    */     
/*  61:    */     public boolean apply(@Nullable V value)
/*  62:    */     {
/*  63: 84 */       return FilteredEntryMultimap.this.satisfies(this.key, value);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   static <E> Collection<E> filterCollection(Collection<E> collection, Predicate<? super E> predicate)
/*  68:    */   {
/*  69: 90 */     if ((collection instanceof Set)) {
/*  70: 91 */       return Sets.filter((Set)collection, predicate);
/*  71:    */     }
/*  72: 93 */     return Collections2.filter(collection, predicate);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean containsKey(@Nullable Object key)
/*  76:    */   {
/*  77: 99 */     return asMap().get(key) != null;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Collection<V> removeAll(@Nullable Object key)
/*  81:    */   {
/*  82:104 */     return (Collection)Objects.firstNonNull(asMap().remove(key), unmodifiableEmptyCollection());
/*  83:    */   }
/*  84:    */   
/*  85:    */   Collection<V> unmodifiableEmptyCollection()
/*  86:    */   {
/*  87:109 */     return (this.unfiltered instanceof SetMultimap) ? Collections.emptySet() : Collections.emptyList();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void clear()
/*  91:    */   {
/*  92:116 */     entries().clear();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Collection<V> get(K key)
/*  96:    */   {
/*  97:121 */     return filterCollection(this.unfiltered.get(key), new ValuePredicate(key));
/*  98:    */   }
/*  99:    */   
/* 100:    */   Collection<Map.Entry<K, V>> createEntries()
/* 101:    */   {
/* 102:126 */     return filterCollection(this.unfiltered.entries(), this.predicate);
/* 103:    */   }
/* 104:    */   
/* 105:    */   Collection<V> createValues()
/* 106:    */   {
/* 107:131 */     return new FilteredMultimapValues(this);
/* 108:    */   }
/* 109:    */   
/* 110:    */   Iterator<Map.Entry<K, V>> entryIterator()
/* 111:    */   {
/* 112:136 */     throw new AssertionError("should never be called");
/* 113:    */   }
/* 114:    */   
/* 115:    */   Map<K, Collection<V>> createAsMap()
/* 116:    */   {
/* 117:141 */     return new AsMap();
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Set<K> keySet()
/* 121:    */   {
/* 122:146 */     return asMap().keySet();
/* 123:    */   }
/* 124:    */   
/* 125:    */   boolean removeEntriesIf(Predicate<? super Map.Entry<K, Collection<V>>> predicate)
/* 126:    */   {
/* 127:150 */     Iterator<Map.Entry<K, Collection<V>>> entryIterator = this.unfiltered.asMap().entrySet().iterator();
/* 128:151 */     boolean changed = false;
/* 129:152 */     while (entryIterator.hasNext())
/* 130:    */     {
/* 131:153 */       Map.Entry<K, Collection<V>> entry = (Map.Entry)entryIterator.next();
/* 132:154 */       K key = entry.getKey();
/* 133:155 */       Collection<V> collection = filterCollection((Collection)entry.getValue(), new ValuePredicate(key));
/* 134:156 */       if ((!collection.isEmpty()) && (predicate.apply(Maps.immutableEntry(key, collection))))
/* 135:    */       {
/* 136:157 */         if (collection.size() == ((Collection)entry.getValue()).size()) {
/* 137:158 */           entryIterator.remove();
/* 138:    */         } else {
/* 139:160 */           collection.clear();
/* 140:    */         }
/* 141:162 */         changed = true;
/* 142:    */       }
/* 143:    */     }
/* 144:165 */     return changed;
/* 145:    */   }
/* 146:    */   
/* 147:    */   class AsMap
/* 148:    */     extends Maps.ImprovedAbstractMap<K, Collection<V>>
/* 149:    */   {
/* 150:    */     AsMap() {}
/* 151:    */     
/* 152:    */     public boolean containsKey(@Nullable Object key)
/* 153:    */     {
/* 154:171 */       return get(key) != null;
/* 155:    */     }
/* 156:    */     
/* 157:    */     public void clear()
/* 158:    */     {
/* 159:176 */       FilteredEntryMultimap.this.clear();
/* 160:    */     }
/* 161:    */     
/* 162:    */     public Collection<V> get(@Nullable Object key)
/* 163:    */     {
/* 164:181 */       Collection<V> result = (Collection)FilteredEntryMultimap.this.unfiltered.asMap().get(key);
/* 165:182 */       if (result == null) {
/* 166:183 */         return null;
/* 167:    */       }
/* 168:186 */       K k = key;
/* 169:187 */       result = FilteredEntryMultimap.filterCollection(result, new FilteredEntryMultimap.ValuePredicate(FilteredEntryMultimap.this, k));
/* 170:188 */       return result.isEmpty() ? null : result;
/* 171:    */     }
/* 172:    */     
/* 173:    */     public Collection<V> remove(@Nullable Object key)
/* 174:    */     {
/* 175:193 */       Collection<V> collection = (Collection)FilteredEntryMultimap.this.unfiltered.asMap().get(key);
/* 176:194 */       if (collection == null) {
/* 177:195 */         return null;
/* 178:    */       }
/* 179:198 */       K k = key;
/* 180:199 */       List<V> result = Lists.newArrayList();
/* 181:200 */       Iterator<V> itr = collection.iterator();
/* 182:201 */       while (itr.hasNext())
/* 183:    */       {
/* 184:202 */         V v = itr.next();
/* 185:203 */         if (FilteredEntryMultimap.this.satisfies(k, v))
/* 186:    */         {
/* 187:204 */           itr.remove();
/* 188:205 */           result.add(v);
/* 189:    */         }
/* 190:    */       }
/* 191:208 */       if (result.isEmpty()) {
/* 192:209 */         return null;
/* 193:    */       }
/* 194:210 */       if ((FilteredEntryMultimap.this.unfiltered instanceof SetMultimap)) {
/* 195:211 */         return Collections.unmodifiableSet(Sets.newLinkedHashSet(result));
/* 196:    */       }
/* 197:213 */       return Collections.unmodifiableList(result);
/* 198:    */     }
/* 199:    */     
/* 200:    */     Set<K> createKeySet()
/* 201:    */     {
/* 202:219 */       new Maps.KeySet(this)
/* 203:    */       {
/* 204:    */         public boolean removeAll(Collection<?> c)
/* 205:    */         {
/* 206:222 */           return FilteredEntryMultimap.this.removeEntriesIf(Maps.keyPredicateOnEntries(Predicates.in(c)));
/* 207:    */         }
/* 208:    */         
/* 209:    */         public boolean retainAll(Collection<?> c)
/* 210:    */         {
/* 211:227 */           return FilteredEntryMultimap.this.removeEntriesIf(Maps.keyPredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 212:    */         }
/* 213:    */         
/* 214:    */         public boolean remove(@Nullable Object o)
/* 215:    */         {
/* 216:232 */           return FilteredEntryMultimap.AsMap.this.remove(o) != null;
/* 217:    */         }
/* 218:    */       };
/* 219:    */     }
/* 220:    */     
/* 221:    */     Set<Map.Entry<K, Collection<V>>> createEntrySet()
/* 222:    */     {
/* 223:239 */       new Maps.EntrySet()
/* 224:    */       {
/* 225:    */         Map<K, Collection<V>> map()
/* 226:    */         {
/* 227:242 */           return FilteredEntryMultimap.AsMap.this;
/* 228:    */         }
/* 229:    */         
/* 230:    */         public Iterator<Map.Entry<K, Collection<V>>> iterator()
/* 231:    */         {
/* 232:247 */           new AbstractIterator()
/* 233:    */           {
/* 234:248 */             final Iterator<Map.Entry<K, Collection<V>>> backingIterator = FilteredEntryMultimap.this.unfiltered.asMap().entrySet().iterator();
/* 235:    */             
/* 236:    */             protected Map.Entry<K, Collection<V>> computeNext()
/* 237:    */             {
/* 238:253 */               while (this.backingIterator.hasNext())
/* 239:    */               {
/* 240:254 */                 Map.Entry<K, Collection<V>> entry = (Map.Entry)this.backingIterator.next();
/* 241:255 */                 K key = entry.getKey();
/* 242:256 */                 Collection<V> collection = FilteredEntryMultimap.filterCollection((Collection)entry.getValue(), new FilteredEntryMultimap.ValuePredicate(FilteredEntryMultimap.this, key));
/* 243:258 */                 if (!collection.isEmpty()) {
/* 244:259 */                   return Maps.immutableEntry(key, collection);
/* 245:    */                 }
/* 246:    */               }
/* 247:262 */               return (Map.Entry)endOfData();
/* 248:    */             }
/* 249:    */           };
/* 250:    */         }
/* 251:    */         
/* 252:    */         public boolean removeAll(Collection<?> c)
/* 253:    */         {
/* 254:269 */           return FilteredEntryMultimap.this.removeEntriesIf(Predicates.in(c));
/* 255:    */         }
/* 256:    */         
/* 257:    */         public boolean retainAll(Collection<?> c)
/* 258:    */         {
/* 259:274 */           return FilteredEntryMultimap.this.removeEntriesIf(Predicates.not(Predicates.in(c)));
/* 260:    */         }
/* 261:    */         
/* 262:    */         public int size()
/* 263:    */         {
/* 264:279 */           return Iterators.size(iterator());
/* 265:    */         }
/* 266:    */       };
/* 267:    */     }
/* 268:    */     
/* 269:    */     Collection<Collection<V>> createValues()
/* 270:    */     {
/* 271:286 */       new Maps.Values(this)
/* 272:    */       {
/* 273:    */         public boolean remove(@Nullable Object o)
/* 274:    */         {
/* 275:289 */           if ((o instanceof Collection))
/* 276:    */           {
/* 277:290 */             Collection<?> c = (Collection)o;
/* 278:291 */             Iterator<Map.Entry<K, Collection<V>>> entryIterator = FilteredEntryMultimap.this.unfiltered.asMap().entrySet().iterator();
/* 279:293 */             while (entryIterator.hasNext())
/* 280:    */             {
/* 281:294 */               Map.Entry<K, Collection<V>> entry = (Map.Entry)entryIterator.next();
/* 282:295 */               K key = entry.getKey();
/* 283:296 */               Collection<V> collection = FilteredEntryMultimap.filterCollection((Collection)entry.getValue(), new FilteredEntryMultimap.ValuePredicate(FilteredEntryMultimap.this, key));
/* 284:298 */               if ((!collection.isEmpty()) && (c.equals(collection)))
/* 285:    */               {
/* 286:299 */                 if (collection.size() == ((Collection)entry.getValue()).size()) {
/* 287:300 */                   entryIterator.remove();
/* 288:    */                 } else {
/* 289:302 */                   collection.clear();
/* 290:    */                 }
/* 291:304 */                 return true;
/* 292:    */               }
/* 293:    */             }
/* 294:    */           }
/* 295:308 */           return false;
/* 296:    */         }
/* 297:    */         
/* 298:    */         public boolean removeAll(Collection<?> c)
/* 299:    */         {
/* 300:313 */           return FilteredEntryMultimap.this.removeEntriesIf(Maps.valuePredicateOnEntries(Predicates.in(c)));
/* 301:    */         }
/* 302:    */         
/* 303:    */         public boolean retainAll(Collection<?> c)
/* 304:    */         {
/* 305:318 */           return FilteredEntryMultimap.this.removeEntriesIf(Maps.valuePredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 306:    */         }
/* 307:    */       };
/* 308:    */     }
/* 309:    */   }
/* 310:    */   
/* 311:    */   Multiset<K> createKeys()
/* 312:    */   {
/* 313:326 */     return new Keys();
/* 314:    */   }
/* 315:    */   
/* 316:    */   class Keys
/* 317:    */     extends Multimaps.Keys<K, V>
/* 318:    */   {
/* 319:    */     Keys()
/* 320:    */     {
/* 321:331 */       super();
/* 322:    */     }
/* 323:    */     
/* 324:    */     public int remove(@Nullable Object key, int occurrences)
/* 325:    */     {
/* 326:336 */       CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 327:337 */       if (occurrences == 0) {
/* 328:338 */         return count(key);
/* 329:    */       }
/* 330:340 */       Collection<V> collection = (Collection)FilteredEntryMultimap.this.unfiltered.asMap().get(key);
/* 331:341 */       if (collection == null) {
/* 332:342 */         return 0;
/* 333:    */       }
/* 334:345 */       K k = key;
/* 335:346 */       int oldCount = 0;
/* 336:347 */       Iterator<V> itr = collection.iterator();
/* 337:348 */       while (itr.hasNext())
/* 338:    */       {
/* 339:349 */         V v = itr.next();
/* 340:350 */         if (FilteredEntryMultimap.this.satisfies(k, v))
/* 341:    */         {
/* 342:351 */           oldCount++;
/* 343:352 */           if (oldCount <= occurrences) {
/* 344:353 */             itr.remove();
/* 345:    */           }
/* 346:    */         }
/* 347:    */       }
/* 348:357 */       return oldCount;
/* 349:    */     }
/* 350:    */     
/* 351:    */     public Set<Multiset.Entry<K>> entrySet()
/* 352:    */     {
/* 353:362 */       new Multisets.EntrySet()
/* 354:    */       {
/* 355:    */         Multiset<K> multiset()
/* 356:    */         {
/* 357:366 */           return FilteredEntryMultimap.Keys.this;
/* 358:    */         }
/* 359:    */         
/* 360:    */         public Iterator<Multiset.Entry<K>> iterator()
/* 361:    */         {
/* 362:371 */           return FilteredEntryMultimap.Keys.this.entryIterator();
/* 363:    */         }
/* 364:    */         
/* 365:    */         public int size()
/* 366:    */         {
/* 367:376 */           return FilteredEntryMultimap.this.keySet().size();
/* 368:    */         }
/* 369:    */         
/* 370:    */         private boolean removeEntriesIf(final Predicate<? super Multiset.Entry<K>> predicate)
/* 371:    */         {
/* 372:380 */           FilteredEntryMultimap.this.removeEntriesIf(new Predicate()
/* 373:    */           {
/* 374:    */             public boolean apply(Map.Entry<K, Collection<V>> entry)
/* 375:    */             {
/* 376:384 */               return predicate.apply(Multisets.immutableEntry(entry.getKey(), ((Collection)entry.getValue()).size()));
/* 377:    */             }
/* 378:    */           });
/* 379:    */         }
/* 380:    */         
/* 381:    */         public boolean removeAll(Collection<?> c)
/* 382:    */         {
/* 383:392 */           return removeEntriesIf(Predicates.in(c));
/* 384:    */         }
/* 385:    */         
/* 386:    */         public boolean retainAll(Collection<?> c)
/* 387:    */         {
/* 388:397 */           return removeEntriesIf(Predicates.not(Predicates.in(c)));
/* 389:    */         }
/* 390:    */       };
/* 391:    */     }
/* 392:    */   }
/* 393:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.FilteredEntryMultimap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Optional;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.ArrayDeque;
/*   8:    */ import java.util.BitSet;
/*   9:    */ import java.util.Deque;
/*  10:    */ import java.util.Iterator;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ @GwtCompatible(emulated=true)
/*  14:    */ public abstract class BinaryTreeTraverser<T>
/*  15:    */   extends TreeTraverser<T>
/*  16:    */ {
/*  17:    */   public abstract Optional<T> leftChild(T paramT);
/*  18:    */   
/*  19:    */   public abstract Optional<T> rightChild(T paramT);
/*  20:    */   
/*  21:    */   public final Iterable<T> children(final T root)
/*  22:    */   {
/*  23: 59 */     Preconditions.checkNotNull(root);
/*  24: 60 */     new FluentIterable()
/*  25:    */     {
/*  26:    */       public Iterator<T> iterator()
/*  27:    */       {
/*  28: 63 */         new AbstractIterator()
/*  29:    */         {
/*  30:    */           boolean doneLeft;
/*  31:    */           boolean doneRight;
/*  32:    */           
/*  33:    */           protected T computeNext()
/*  34:    */           {
/*  35: 69 */             if (!this.doneLeft)
/*  36:    */             {
/*  37: 70 */               this.doneLeft = true;
/*  38: 71 */               Optional<T> left = BinaryTreeTraverser.this.leftChild(BinaryTreeTraverser.1.this.val$root);
/*  39: 72 */               if (left.isPresent()) {
/*  40: 73 */                 return left.get();
/*  41:    */               }
/*  42:    */             }
/*  43: 76 */             if (!this.doneRight)
/*  44:    */             {
/*  45: 77 */               this.doneRight = true;
/*  46: 78 */               Optional<T> right = BinaryTreeTraverser.this.rightChild(BinaryTreeTraverser.1.this.val$root);
/*  47: 79 */               if (right.isPresent()) {
/*  48: 80 */                 return right.get();
/*  49:    */               }
/*  50:    */             }
/*  51: 83 */             return endOfData();
/*  52:    */           }
/*  53:    */         };
/*  54:    */       }
/*  55:    */     };
/*  56:    */   }
/*  57:    */   
/*  58:    */   UnmodifiableIterator<T> preOrderIterator(T root)
/*  59:    */   {
/*  60: 92 */     return new PreOrderIterator(root);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private final class PreOrderIterator
/*  64:    */     extends UnmodifiableIterator<T>
/*  65:    */     implements PeekingIterator<T>
/*  66:    */   {
/*  67:    */     private final Deque<T> stack;
/*  68:    */     
/*  69:    */     PreOrderIterator()
/*  70:    */     {
/*  71:103 */       this.stack = new ArrayDeque();
/*  72:104 */       this.stack.addLast(root);
/*  73:    */     }
/*  74:    */     
/*  75:    */     public boolean hasNext()
/*  76:    */     {
/*  77:109 */       return !this.stack.isEmpty();
/*  78:    */     }
/*  79:    */     
/*  80:    */     public T next()
/*  81:    */     {
/*  82:114 */       T result = this.stack.removeLast();
/*  83:115 */       BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.rightChild(result));
/*  84:116 */       BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.leftChild(result));
/*  85:117 */       return result;
/*  86:    */     }
/*  87:    */     
/*  88:    */     public T peek()
/*  89:    */     {
/*  90:122 */       return this.stack.getLast();
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   UnmodifiableIterator<T> postOrderIterator(T root)
/*  95:    */   {
/*  96:128 */     return new PostOrderIterator(root);
/*  97:    */   }
/*  98:    */   
/*  99:    */   private final class PostOrderIterator
/* 100:    */     extends UnmodifiableIterator<T>
/* 101:    */   {
/* 102:    */     private final Deque<T> stack;
/* 103:    */     private final BitSet hasExpanded;
/* 104:    */     
/* 105:    */     PostOrderIterator()
/* 106:    */     {
/* 107:139 */       this.stack = new ArrayDeque();
/* 108:140 */       this.stack.addLast(root);
/* 109:141 */       this.hasExpanded = new BitSet();
/* 110:    */     }
/* 111:    */     
/* 112:    */     public boolean hasNext()
/* 113:    */     {
/* 114:146 */       return !this.stack.isEmpty();
/* 115:    */     }
/* 116:    */     
/* 117:    */     public T next()
/* 118:    */     {
/* 119:    */       for (;;)
/* 120:    */       {
/* 121:152 */         T node = this.stack.getLast();
/* 122:153 */         boolean expandedNode = this.hasExpanded.get(this.stack.size() - 1);
/* 123:154 */         if (expandedNode)
/* 124:    */         {
/* 125:155 */           this.stack.removeLast();
/* 126:156 */           this.hasExpanded.clear(this.stack.size());
/* 127:157 */           return node;
/* 128:    */         }
/* 129:159 */         this.hasExpanded.set(this.stack.size() - 1);
/* 130:160 */         BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.rightChild(node));
/* 131:161 */         BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.leftChild(node));
/* 132:    */       }
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public final FluentIterable<T> inOrderTraversal(final T root)
/* 137:    */   {
/* 138:170 */     Preconditions.checkNotNull(root);
/* 139:171 */     new FluentIterable()
/* 140:    */     {
/* 141:    */       public UnmodifiableIterator<T> iterator()
/* 142:    */       {
/* 143:174 */         return new BinaryTreeTraverser.InOrderIterator(BinaryTreeTraverser.this, root);
/* 144:    */       }
/* 145:    */     };
/* 146:    */   }
/* 147:    */   
/* 148:    */   private final class InOrderIterator
/* 149:    */     extends AbstractIterator<T>
/* 150:    */   {
/* 151:    */     private final Deque<T> stack;
/* 152:    */     private final BitSet hasExpandedLeft;
/* 153:    */     
/* 154:    */     InOrderIterator()
/* 155:    */     {
/* 156:184 */       this.stack = new ArrayDeque();
/* 157:185 */       this.hasExpandedLeft = new BitSet();
/* 158:186 */       this.stack.addLast(root);
/* 159:    */     }
/* 160:    */     
/* 161:    */     protected T computeNext()
/* 162:    */     {
/* 163:191 */       while (!this.stack.isEmpty())
/* 164:    */       {
/* 165:192 */         T node = this.stack.getLast();
/* 166:193 */         if (this.hasExpandedLeft.get(this.stack.size() - 1))
/* 167:    */         {
/* 168:194 */           this.stack.removeLast();
/* 169:195 */           this.hasExpandedLeft.clear(this.stack.size());
/* 170:196 */           BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.rightChild(node));
/* 171:197 */           return node;
/* 172:    */         }
/* 173:199 */         this.hasExpandedLeft.set(this.stack.size() - 1);
/* 174:200 */         BinaryTreeTraverser.pushIfPresent(this.stack, BinaryTreeTraverser.this.leftChild(node));
/* 175:    */       }
/* 176:203 */       return endOfData();
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static <T> void pushIfPresent(Deque<T> stack, Optional<T> node)
/* 181:    */   {
/* 182:208 */     if (node.isPresent()) {
/* 183:209 */       stack.addLast(node.get());
/* 184:    */     }
/* 185:    */   }
/* 186:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.BinaryTreeTraverser
 * JD-Core Version:    0.7.0.1
 */
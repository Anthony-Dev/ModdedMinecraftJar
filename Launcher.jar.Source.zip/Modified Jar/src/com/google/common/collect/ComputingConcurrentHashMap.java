/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Equivalence;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.lang.ref.ReferenceQueue;
/*  10:    */ import java.util.Queue;
/*  11:    */ import java.util.concurrent.ConcurrentMap;
/*  12:    */ import java.util.concurrent.ExecutionException;
/*  13:    */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ import javax.annotation.concurrent.GuardedBy;
/*  16:    */ 
/*  17:    */ class ComputingConcurrentHashMap<K, V>
/*  18:    */   extends MapMakerInternalMap<K, V>
/*  19:    */ {
/*  20:    */   final Function<? super K, ? extends V> computingFunction;
/*  21:    */   private static final long serialVersionUID = 4L;
/*  22:    */   
/*  23:    */   ComputingConcurrentHashMap(MapMaker builder, Function<? super K, ? extends V> computingFunction)
/*  24:    */   {
/*  25: 51 */     super(builder);
/*  26: 52 */     this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/*  27:    */   }
/*  28:    */   
/*  29:    */   MapMakerInternalMap.Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize)
/*  30:    */   {
/*  31: 57 */     return new ComputingSegment(this, initialCapacity, maxSegmentSize);
/*  32:    */   }
/*  33:    */   
/*  34:    */   ComputingSegment<K, V> segmentFor(int hash)
/*  35:    */   {
/*  36: 62 */     return (ComputingSegment)super.segmentFor(hash);
/*  37:    */   }
/*  38:    */   
/*  39:    */   V getOrCompute(K key)
/*  40:    */     throws ExecutionException
/*  41:    */   {
/*  42: 66 */     int hash = hash(Preconditions.checkNotNull(key));
/*  43: 67 */     return segmentFor(hash).getOrCompute(key, hash, this.computingFunction);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static final class ComputingSegment<K, V>
/*  47:    */     extends MapMakerInternalMap.Segment<K, V>
/*  48:    */   {
/*  49:    */     ComputingSegment(MapMakerInternalMap<K, V> map, int initialCapacity, int maxSegmentSize)
/*  50:    */     {
/*  51: 73 */       super(initialCapacity, maxSegmentSize);
/*  52:    */     }
/*  53:    */     
/*  54:    */     V getOrCompute(K key, int hash, Function<? super K, ? extends V> computingFunction)
/*  55:    */       throws ExecutionException
/*  56:    */     {
/*  57:    */       try
/*  58:    */       {
/*  59:    */         MapMakerInternalMap.ReferenceEntry<K, V> e;
/*  60:    */         Object computingValueReference;
/*  61:    */         V value;
/*  62:    */         do
/*  63:    */         {
/*  64: 81 */           e = getEntry(key, hash);
/*  65: 82 */           if (e != null)
/*  66:    */           {
/*  67: 83 */             V value = getLiveValue(e);
/*  68: 84 */             if (value != null)
/*  69:    */             {
/*  70: 85 */               recordRead(e);
/*  71: 86 */               return value;
/*  72:    */             }
/*  73:    */           }
/*  74: 92 */           if ((e == null) || (!e.getValueReference().isComputingReference()))
/*  75:    */           {
/*  76: 93 */             boolean createNewEntry = true;
/*  77: 94 */             computingValueReference = null;
/*  78: 95 */             lock();
/*  79:    */             int newCount;
/*  80:    */             try
/*  81:    */             {
/*  82: 97 */               preWriteCleanup();
/*  83:    */               
/*  84: 99 */               newCount = this.count - 1;
/*  85:100 */               AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/*  86:101 */               int index = hash & table.length() - 1;
/*  87:102 */               MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/*  88:104 */               for (e = first; e != null; e = e.getNext())
/*  89:    */               {
/*  90:105 */                 K entryKey = e.getKey();
/*  91:106 */                 if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/*  92:    */                 {
/*  93:108 */                   MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/*  94:109 */                   if (valueReference.isComputingReference())
/*  95:    */                   {
/*  96:110 */                     createNewEntry = false; break;
/*  97:    */                   }
/*  98:112 */                   V value = e.getValueReference().get();
/*  99:113 */                   if (value == null)
/* 100:    */                   {
/* 101:114 */                     enqueueNotification(entryKey, hash, value, MapMaker.RemovalCause.COLLECTED);
/* 102:    */                   }
/* 103:115 */                   else if ((this.map.expires()) && (this.map.isExpired(e)))
/* 104:    */                   {
/* 105:118 */                     enqueueNotification(entryKey, hash, value, MapMaker.RemovalCause.EXPIRED);
/* 106:    */                   }
/* 107:    */                   else
/* 108:    */                   {
/* 109:120 */                     recordLockedRead(e);
/* 110:121 */                     return value;
/* 111:    */                   }
/* 112:125 */                   this.evictionQueue.remove(e);
/* 113:126 */                   this.expirationQueue.remove(e);
/* 114:127 */                   this.count = newCount;
/* 115:    */                   
/* 116:129 */                   break;
/* 117:    */                 }
/* 118:    */               }
/* 119:133 */               if (createNewEntry)
/* 120:    */               {
/* 121:134 */                 computingValueReference = new ComputingConcurrentHashMap.ComputingValueReference(computingFunction);
/* 122:136 */                 if (e == null)
/* 123:    */                 {
/* 124:137 */                   e = newEntry(key, hash, first);
/* 125:138 */                   e.setValueReference((MapMakerInternalMap.ValueReference)computingValueReference);
/* 126:139 */                   table.set(index, e);
/* 127:    */                 }
/* 128:    */                 else
/* 129:    */                 {
/* 130:141 */                   e.setValueReference((MapMakerInternalMap.ValueReference)computingValueReference);
/* 131:    */                 }
/* 132:    */               }
/* 133:    */             }
/* 134:    */             finally
/* 135:    */             {
/* 136:145 */               unlock();
/* 137:    */             }
/* 138:149 */             if (createNewEntry) {
/* 139:151 */               return compute(key, hash, e, (ComputingConcurrentHashMap.ComputingValueReference)computingValueReference);
/* 140:    */             }
/* 141:    */           }
/* 142:156 */           Preconditions.checkState(!Thread.holdsLock(e), "Recursive computation");
/* 143:    */           
/* 144:158 */           value = e.getValueReference().waitForValue();
/* 145:159 */         } while (value == null);
/* 146:160 */         recordRead(e);
/* 147:161 */         return value;
/* 148:    */       }
/* 149:    */       finally
/* 150:    */       {
/* 151:167 */         postReadCleanup();
/* 152:    */       }
/* 153:    */     }
/* 154:    */     
/* 155:    */     V compute(K key, int hash, MapMakerInternalMap.ReferenceEntry<K, V> e, ComputingConcurrentHashMap.ComputingValueReference<K, V> computingValueReference)
/* 156:    */       throws ExecutionException
/* 157:    */     {
/* 158:174 */       V value = null;
/* 159:175 */       long start = System.nanoTime();
/* 160:176 */       long end = 0L;
/* 161:    */       try
/* 162:    */       {
/* 163:181 */         synchronized (e)
/* 164:    */         {
/* 165:182 */           value = computingValueReference.compute(key, hash);
/* 166:183 */           end = System.nanoTime();
/* 167:    */         }
/* 168:    */         V oldValue;
/* 169:185 */         if (value != null)
/* 170:    */         {
/* 171:187 */           oldValue = put(key, hash, value, true);
/* 172:188 */           if (oldValue != null) {
/* 173:190 */             enqueueNotification(key, hash, value, MapMaker.RemovalCause.REPLACED);
/* 174:    */           }
/* 175:    */         }
/* 176:193 */         return value;
/* 177:    */       }
/* 178:    */       finally
/* 179:    */       {
/* 180:195 */         if (end == 0L) {
/* 181:196 */           end = System.nanoTime();
/* 182:    */         }
/* 183:198 */         if (value == null) {
/* 184:199 */           clearValue(key, hash, computingValueReference);
/* 185:    */         }
/* 186:    */       }
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static final class ComputationExceptionReference<K, V>
/* 191:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 192:    */   {
/* 193:    */     final Throwable t;
/* 194:    */     
/* 195:    */     ComputationExceptionReference(Throwable t)
/* 196:    */     {
/* 197:212 */       this.t = t;
/* 198:    */     }
/* 199:    */     
/* 200:    */     public V get()
/* 201:    */     {
/* 202:217 */       return null;
/* 203:    */     }
/* 204:    */     
/* 205:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 206:    */     {
/* 207:222 */       return null;
/* 208:    */     }
/* 209:    */     
/* 210:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 211:    */     {
/* 212:228 */       return this;
/* 213:    */     }
/* 214:    */     
/* 215:    */     public boolean isComputingReference()
/* 216:    */     {
/* 217:233 */       return false;
/* 218:    */     }
/* 219:    */     
/* 220:    */     public V waitForValue()
/* 221:    */       throws ExecutionException
/* 222:    */     {
/* 223:238 */       throw new ExecutionException(this.t);
/* 224:    */     }
/* 225:    */     
/* 226:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 227:    */   }
/* 228:    */   
/* 229:    */   private static final class ComputedReference<K, V>
/* 230:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 231:    */   {
/* 232:    */     final V value;
/* 233:    */     
/* 234:    */     ComputedReference(@Nullable V value)
/* 235:    */     {
/* 236:252 */       this.value = value;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public V get()
/* 240:    */     {
/* 241:257 */       return this.value;
/* 242:    */     }
/* 243:    */     
/* 244:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 245:    */     {
/* 246:262 */       return null;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 250:    */     {
/* 251:268 */       return this;
/* 252:    */     }
/* 253:    */     
/* 254:    */     public boolean isComputingReference()
/* 255:    */     {
/* 256:273 */       return false;
/* 257:    */     }
/* 258:    */     
/* 259:    */     public V waitForValue()
/* 260:    */     {
/* 261:278 */       return get();
/* 262:    */     }
/* 263:    */     
/* 264:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 265:    */   }
/* 266:    */   
/* 267:    */   private static final class ComputingValueReference<K, V>
/* 268:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 269:    */   {
/* 270:    */     final Function<? super K, ? extends V> computingFunction;
/* 271:    */     @GuardedBy("ComputingValueReference.this")
/* 272:288 */     volatile MapMakerInternalMap.ValueReference<K, V> computedReference = MapMakerInternalMap.unset();
/* 273:    */     
/* 274:    */     public ComputingValueReference(Function<? super K, ? extends V> computingFunction)
/* 275:    */     {
/* 276:292 */       this.computingFunction = computingFunction;
/* 277:    */     }
/* 278:    */     
/* 279:    */     public V get()
/* 280:    */     {
/* 281:299 */       return null;
/* 282:    */     }
/* 283:    */     
/* 284:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 285:    */     {
/* 286:304 */       return null;
/* 287:    */     }
/* 288:    */     
/* 289:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, @Nullable V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 290:    */     {
/* 291:310 */       return this;
/* 292:    */     }
/* 293:    */     
/* 294:    */     public boolean isComputingReference()
/* 295:    */     {
/* 296:315 */       return true;
/* 297:    */     }
/* 298:    */     
/* 299:    */     public V waitForValue()
/* 300:    */       throws ExecutionException
/* 301:    */     {
/* 302:323 */       if (this.computedReference == MapMakerInternalMap.UNSET)
/* 303:    */       {
/* 304:324 */         boolean interrupted = false;
/* 305:    */         try
/* 306:    */         {
/* 307:326 */           synchronized (this)
/* 308:    */           {
/* 309:327 */             while (this.computedReference == MapMakerInternalMap.UNSET) {
/* 310:    */               try
/* 311:    */               {
/* 312:329 */                 wait();
/* 313:    */               }
/* 314:    */               catch (InterruptedException ie)
/* 315:    */               {
/* 316:331 */                 interrupted = true;
/* 317:    */               }
/* 318:    */             }
/* 319:    */           }
/* 320:    */         }
/* 321:    */         finally
/* 322:    */         {
/* 323:336 */           if (interrupted) {
/* 324:337 */             Thread.currentThread().interrupt();
/* 325:    */           }
/* 326:    */         }
/* 327:    */       }
/* 328:341 */       return this.computedReference.waitForValue();
/* 329:    */     }
/* 330:    */     
/* 331:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 332:    */     {
/* 333:348 */       setValueReference(newValue);
/* 334:    */     }
/* 335:    */     
/* 336:    */     V compute(K key, int hash)
/* 337:    */       throws ExecutionException
/* 338:    */     {
/* 339:    */       V value;
/* 340:    */       try
/* 341:    */       {
/* 342:356 */         value = this.computingFunction.apply(key);
/* 343:    */       }
/* 344:    */       catch (Throwable t)
/* 345:    */       {
/* 346:358 */         setValueReference(new ComputingConcurrentHashMap.ComputationExceptionReference(t));
/* 347:359 */         throw new ExecutionException(t);
/* 348:    */       }
/* 349:362 */       setValueReference(new ComputingConcurrentHashMap.ComputedReference(value));
/* 350:363 */       return value;
/* 351:    */     }
/* 352:    */     
/* 353:    */     void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 354:    */     {
/* 355:367 */       synchronized (this)
/* 356:    */       {
/* 357:368 */         if (this.computedReference == MapMakerInternalMap.UNSET)
/* 358:    */         {
/* 359:369 */           this.computedReference = valueReference;
/* 360:370 */           notifyAll();
/* 361:    */         }
/* 362:    */       }
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   Object writeReplace()
/* 367:    */   {
/* 368:382 */     return new ComputingSerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize, this.concurrencyLevel, this.removalListener, this, this.computingFunction);
/* 369:    */   }
/* 370:    */   
/* 371:    */   static final class ComputingSerializationProxy<K, V>
/* 372:    */     extends MapMakerInternalMap.AbstractSerializationProxy<K, V>
/* 373:    */   {
/* 374:    */     final Function<? super K, ? extends V> computingFunction;
/* 375:    */     private static final long serialVersionUID = 4L;
/* 376:    */     
/* 377:    */     ComputingSerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate, Function<? super K, ? extends V> computingFunction)
/* 378:    */     {
/* 379:396 */       super(valueStrength, keyEquivalence, valueEquivalence, expireAfterWriteNanos, expireAfterAccessNanos, maximumSize, concurrencyLevel, removalListener, delegate);
/* 380:    */       
/* 381:398 */       this.computingFunction = computingFunction;
/* 382:    */     }
/* 383:    */     
/* 384:    */     private void writeObject(ObjectOutputStream out)
/* 385:    */       throws IOException
/* 386:    */     {
/* 387:402 */       out.defaultWriteObject();
/* 388:403 */       writeMapTo(out);
/* 389:    */     }
/* 390:    */     
/* 391:    */     private void readObject(ObjectInputStream in)
/* 392:    */       throws IOException, ClassNotFoundException
/* 393:    */     {
/* 394:408 */       in.defaultReadObject();
/* 395:409 */       MapMaker mapMaker = readMapMaker(in);
/* 396:410 */       this.delegate = mapMaker.makeComputingMap(this.computingFunction);
/* 397:411 */       readEntries(in);
/* 398:    */     }
/* 399:    */     
/* 400:    */     Object readResolve()
/* 401:    */     {
/* 402:415 */       return this.delegate;
/* 403:    */     }
/* 404:    */   }
/* 405:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ComputingConcurrentHashMap
 * JD-Core Version:    0.7.0.1
 */
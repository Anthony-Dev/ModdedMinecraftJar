/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Function;
/*   7:    */ import com.google.common.base.Optional;
/*   8:    */ import com.google.common.base.Preconditions;
/*   9:    */ import com.google.common.base.Predicate;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.SortedSet;
/*  15:    */ import javax.annotation.CheckReturnValue;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ public abstract class FluentIterable<E>
/*  20:    */   implements Iterable<E>
/*  21:    */ {
/*  22:    */   private final Iterable<E> iterable;
/*  23:    */   
/*  24:    */   protected FluentIterable()
/*  25:    */   {
/*  26: 78 */     this.iterable = this;
/*  27:    */   }
/*  28:    */   
/*  29:    */   FluentIterable(Iterable<E> iterable)
/*  30:    */   {
/*  31: 82 */     this.iterable = ((Iterable)Preconditions.checkNotNull(iterable));
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E> FluentIterable<E> from(final Iterable<E> iterable)
/*  35:    */   {
/*  36: 90 */     (iterable instanceof FluentIterable) ? (FluentIterable)iterable : new FluentIterable(iterable)
/*  37:    */     {
/*  38:    */       public Iterator<E> iterator()
/*  39:    */       {
/*  40: 94 */         return iterable.iterator();
/*  41:    */       }
/*  42:    */     };
/*  43:    */   }
/*  44:    */   
/*  45:    */   @Deprecated
/*  46:    */   public static <E> FluentIterable<E> from(FluentIterable<E> iterable)
/*  47:    */   {
/*  48:109 */     return (FluentIterable)Preconditions.checkNotNull(iterable);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String toString()
/*  52:    */   {
/*  53:118 */     return Iterables.toString(this.iterable);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public final int size()
/*  57:    */   {
/*  58:125 */     return Iterables.size(this.iterable);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public final boolean contains(@Nullable Object element)
/*  62:    */   {
/*  63:133 */     return Iterables.contains(this.iterable, element);
/*  64:    */   }
/*  65:    */   
/*  66:    */   @CheckReturnValue
/*  67:    */   public final FluentIterable<E> cycle()
/*  68:    */   {
/*  69:151 */     return from(Iterables.cycle(this.iterable));
/*  70:    */   }
/*  71:    */   
/*  72:    */   @CheckReturnValue
/*  73:    */   public final FluentIterable<E> filter(Predicate<? super E> predicate)
/*  74:    */   {
/*  75:160 */     return from(Iterables.filter(this.iterable, predicate));
/*  76:    */   }
/*  77:    */   
/*  78:    */   @CheckReturnValue
/*  79:    */   @GwtIncompatible("Class.isInstance")
/*  80:    */   public final <T> FluentIterable<T> filter(Class<T> type)
/*  81:    */   {
/*  82:171 */     return from(Iterables.filter(this.iterable, type));
/*  83:    */   }
/*  84:    */   
/*  85:    */   public final boolean anyMatch(Predicate<? super E> predicate)
/*  86:    */   {
/*  87:178 */     return Iterables.any(this.iterable, predicate);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public final boolean allMatch(Predicate<? super E> predicate)
/*  91:    */   {
/*  92:186 */     return Iterables.all(this.iterable, predicate);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public final Optional<E> firstMatch(Predicate<? super E> predicate)
/*  96:    */   {
/*  97:197 */     return Iterables.tryFind(this.iterable, predicate);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public final <T> FluentIterable<T> transform(Function<? super E, T> function)
/* 101:    */   {
/* 102:209 */     return from(Iterables.transform(this.iterable, function));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public <T> FluentIterable<T> transformAndConcat(Function<? super E, ? extends Iterable<? extends T>> function)
/* 106:    */   {
/* 107:225 */     return from(Iterables.concat(transform(function)));
/* 108:    */   }
/* 109:    */   
/* 110:    */   public final Optional<E> first()
/* 111:    */   {
/* 112:236 */     Iterator<E> iterator = this.iterable.iterator();
/* 113:237 */     return iterator.hasNext() ? Optional.of(iterator.next()) : Optional.absent();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public final Optional<E> last()
/* 117:    */   {
/* 118:253 */     if ((this.iterable instanceof List))
/* 119:    */     {
/* 120:254 */       List<E> list = (List)this.iterable;
/* 121:255 */       if (list.isEmpty()) {
/* 122:256 */         return Optional.absent();
/* 123:    */       }
/* 124:258 */       return Optional.of(list.get(list.size() - 1));
/* 125:    */     }
/* 126:260 */     Iterator<E> iterator = this.iterable.iterator();
/* 127:261 */     if (!iterator.hasNext()) {
/* 128:262 */       return Optional.absent();
/* 129:    */     }
/* 130:270 */     if ((this.iterable instanceof SortedSet))
/* 131:    */     {
/* 132:271 */       SortedSet<E> sortedSet = (SortedSet)this.iterable;
/* 133:272 */       return Optional.of(sortedSet.last());
/* 134:    */     }
/* 135:    */     for (;;)
/* 136:    */     {
/* 137:276 */       E current = iterator.next();
/* 138:277 */       if (!iterator.hasNext()) {
/* 139:278 */         return Optional.of(current);
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   @CheckReturnValue
/* 145:    */   public final FluentIterable<E> skip(int numberToSkip)
/* 146:    */   {
/* 147:302 */     return from(Iterables.skip(this.iterable, numberToSkip));
/* 148:    */   }
/* 149:    */   
/* 150:    */   @CheckReturnValue
/* 151:    */   public final FluentIterable<E> limit(int size)
/* 152:    */   {
/* 153:317 */     return from(Iterables.limit(this.iterable, size));
/* 154:    */   }
/* 155:    */   
/* 156:    */   public final boolean isEmpty()
/* 157:    */   {
/* 158:324 */     return !this.iterable.iterator().hasNext();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public final ImmutableList<E> toList()
/* 162:    */   {
/* 163:334 */     return ImmutableList.copyOf(this.iterable);
/* 164:    */   }
/* 165:    */   
/* 166:    */   @Beta
/* 167:    */   public final ImmutableList<E> toSortedList(Comparator<? super E> comparator)
/* 168:    */   {
/* 169:348 */     return Ordering.from(comparator).immutableSortedCopy(this.iterable);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public final ImmutableSet<E> toSet()
/* 173:    */   {
/* 174:358 */     return ImmutableSet.copyOf(this.iterable);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public final ImmutableSortedSet<E> toSortedSet(Comparator<? super E> comparator)
/* 178:    */   {
/* 179:372 */     return ImmutableSortedSet.copyOf(comparator, this.iterable);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public final <V> ImmutableMap<E, V> toMap(Function<? super E, V> valueFunction)
/* 183:    */   {
/* 184:386 */     return Maps.toMap(this.iterable, valueFunction);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public final <K> ImmutableListMultimap<K, E> index(Function<? super E, K> keyFunction)
/* 188:    */   {
/* 189:408 */     return Multimaps.index(this.iterable, keyFunction);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public final <K> ImmutableMap<K, E> uniqueIndex(Function<? super E, K> keyFunction)
/* 193:    */   {
/* 194:424 */     return Maps.uniqueIndex(this.iterable, keyFunction);
/* 195:    */   }
/* 196:    */   
/* 197:    */   @GwtIncompatible("Array.newArray(Class, int)")
/* 198:    */   public final E[] toArray(Class<E> type)
/* 199:    */   {
/* 200:436 */     return Iterables.toArray(this.iterable, type);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public final <C extends Collection<? super E>> C copyInto(C collection)
/* 204:    */   {
/* 205:448 */     Preconditions.checkNotNull(collection);
/* 206:449 */     if ((this.iterable instanceof Collection)) {
/* 207:450 */       collection.addAll(Collections2.cast(this.iterable));
/* 208:    */     } else {
/* 209:452 */       for (E item : this.iterable) {
/* 210:453 */         collection.add(item);
/* 211:    */       }
/* 212:    */     }
/* 213:456 */     return collection;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public final E get(int position)
/* 217:    */   {
/* 218:468 */     return Iterables.get(this.iterable, position);
/* 219:    */   }
/* 220:    */   
/* 221:    */   private static class FromIterableFunction<E>
/* 222:    */     implements Function<Iterable<E>, FluentIterable<E>>
/* 223:    */   {
/* 224:    */     public FluentIterable<E> apply(Iterable<E> fromObject)
/* 225:    */     {
/* 226:478 */       return FluentIterable.from(fromObject);
/* 227:    */     }
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.FluentIterable
 * JD-Core Version:    0.7.0.1
 */
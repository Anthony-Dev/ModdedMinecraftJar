/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Arrays;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.NavigableMap;
/*  10:    */ import java.util.Set;
/*  11:    */ import java.util.SortedMap;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableSortedMap<K, V>
/*  16:    */   extends ImmutableSortedMapFauxverideShim<K, V>
/*  17:    */   implements NavigableMap<K, V>
/*  18:    */ {
/*  19: 65 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  20: 67 */   private static final ImmutableSortedMap<Comparable, Object> NATURAL_EMPTY_MAP = new EmptyImmutableSortedMap(NATURAL_ORDER);
/*  21:    */   private transient ImmutableSortedMap<K, V> descendingMap;
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   static <K, V> ImmutableSortedMap<K, V> emptyMap(Comparator<? super K> comparator)
/*  25:    */   {
/*  26: 71 */     if (Ordering.natural().equals(comparator)) {
/*  27: 72 */       return of();
/*  28:    */     }
/*  29: 74 */     return new EmptyImmutableSortedMap(comparator);
/*  30:    */   }
/*  31:    */   
/*  32:    */   static <K, V> ImmutableSortedMap<K, V> fromSortedEntries(Comparator<? super K> comparator, int size, Map.Entry<K, V>[] entries)
/*  33:    */   {
/*  34: 82 */     if (size == 0) {
/*  35: 83 */       return emptyMap(comparator);
/*  36:    */     }
/*  37: 86 */     ImmutableList.Builder<K> keyBuilder = ImmutableList.builder();
/*  38: 87 */     ImmutableList.Builder<V> valueBuilder = ImmutableList.builder();
/*  39: 88 */     for (int i = 0; i < size; i++)
/*  40:    */     {
/*  41: 89 */       Map.Entry<K, V> entry = entries[i];
/*  42: 90 */       keyBuilder.add(entry.getKey());
/*  43: 91 */       valueBuilder.add(entry.getValue());
/*  44:    */     }
/*  45: 94 */     return new RegularImmutableSortedMap(new RegularImmutableSortedSet(keyBuilder.build(), comparator), valueBuilder.build());
/*  46:    */   }
/*  47:    */   
/*  48:    */   static <K, V> ImmutableSortedMap<K, V> from(ImmutableSortedSet<K> keySet, ImmutableList<V> valueList)
/*  49:    */   {
/*  50:101 */     if (keySet.isEmpty()) {
/*  51:102 */       return emptyMap(keySet.comparator());
/*  52:    */     }
/*  53:104 */     return new RegularImmutableSortedMap((RegularImmutableSortedSet)keySet, valueList);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <K, V> ImmutableSortedMap<K, V> of()
/*  57:    */   {
/*  58:117 */     return NATURAL_EMPTY_MAP;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1)
/*  62:    */   {
/*  63:125 */     return from(ImmutableSortedSet.of(k1), ImmutableList.of(v1));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2)
/*  67:    */   {
/*  68:138 */     return fromEntries(Ordering.natural(), false, 2, new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  72:    */   {
/*  73:151 */     return fromEntries(Ordering.natural(), false, 3, new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  77:    */   {
/*  78:165 */     return fromEntries(Ordering.natural(), false, 4, new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  82:    */   {
/*  83:179 */     return fromEntries(Ordering.natural(), false, 5, new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/*  87:    */   {
/*  88:205 */     Ordering<K> naturalOrder = Ordering.natural();
/*  89:206 */     return copyOfInternal(map, naturalOrder);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/*  93:    */   {
/*  94:223 */     return copyOfInternal(map, (Comparator)Preconditions.checkNotNull(comparator));
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static <K, V> ImmutableSortedMap<K, V> copyOfSorted(SortedMap<K, ? extends V> map)
/*  98:    */   {
/*  99:239 */     Comparator<? super K> comparator = map.comparator();
/* 100:240 */     if (comparator == null) {
/* 101:243 */       comparator = NATURAL_ORDER;
/* 102:    */     }
/* 103:245 */     return copyOfInternal(map, comparator);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static <K, V> ImmutableSortedMap<K, V> copyOfInternal(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/* 107:    */   {
/* 108:250 */     boolean sameComparator = false;
/* 109:251 */     if ((map instanceof SortedMap))
/* 110:    */     {
/* 111:252 */       SortedMap<?, ?> sortedMap = (SortedMap)map;
/* 112:253 */       Comparator<?> comparator2 = sortedMap.comparator();
/* 113:254 */       sameComparator = comparator2 == null ? false : comparator == NATURAL_ORDER ? true : comparator.equals(comparator2);
/* 114:    */     }
/* 115:259 */     if ((sameComparator) && ((map instanceof ImmutableSortedMap)))
/* 116:    */     {
/* 117:263 */       ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap)map;
/* 118:264 */       if (!kvMap.isPartialView()) {
/* 119:265 */         return kvMap;
/* 120:    */       }
/* 121:    */     }
/* 122:273 */     Map.Entry<K, V>[] entries = (Map.Entry[])map.entrySet().toArray(new Map.Entry[0]);
/* 123:    */     
/* 124:275 */     return fromEntries(comparator, sameComparator, entries.length, entries);
/* 125:    */   }
/* 126:    */   
/* 127:    */   static <K, V> ImmutableSortedMap<K, V> fromEntries(Comparator<? super K> comparator, boolean sameComparator, int size, Map.Entry<K, V>... entries)
/* 128:    */   {
/* 129:280 */     for (int i = 0; i < size; i++)
/* 130:    */     {
/* 131:281 */       Map.Entry<K, V> entry = entries[i];
/* 132:282 */       entries[i] = entryOf(entry.getKey(), entry.getValue());
/* 133:    */     }
/* 134:284 */     if (!sameComparator)
/* 135:    */     {
/* 136:285 */       sortEntries(comparator, size, entries);
/* 137:286 */       validateEntries(size, entries, comparator);
/* 138:    */     }
/* 139:289 */     return fromSortedEntries(comparator, size, entries);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private static <K, V> void sortEntries(Comparator<? super K> comparator, int size, Map.Entry<K, V>[] entries)
/* 143:    */   {
/* 144:294 */     Arrays.sort(entries, 0, size, Ordering.from(comparator).onKeys());
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static <K, V> void validateEntries(int size, Map.Entry<K, V>[] entries, Comparator<? super K> comparator)
/* 148:    */   {
/* 149:299 */     for (int i = 1; i < size; i++) {
/* 150:300 */       checkNoConflict(comparator.compare(entries[(i - 1)].getKey(), entries[i].getKey()) != 0, "key", entries[(i - 1)], entries[i]);
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static <K extends Comparable<?>, V> Builder<K, V> naturalOrder()
/* 155:    */   {
/* 156:311 */     return new Builder(Ordering.natural());
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static <K, V> Builder<K, V> orderedBy(Comparator<K> comparator)
/* 160:    */   {
/* 161:323 */     return new Builder(comparator);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static <K extends Comparable<?>, V> Builder<K, V> reverseOrder()
/* 165:    */   {
/* 166:331 */     return new Builder(Ordering.natural().reverse());
/* 167:    */   }
/* 168:    */   
/* 169:    */   ImmutableSortedMap() {}
/* 170:    */   
/* 171:    */   public static class Builder<K, V>
/* 172:    */     extends ImmutableMap.Builder<K, V>
/* 173:    */   {
/* 174:    */     private final Comparator<? super K> comparator;
/* 175:    */     
/* 176:    */     public Builder(Comparator<? super K> comparator)
/* 177:    */     {
/* 178:363 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 179:    */     }
/* 180:    */     
/* 181:    */     public Builder<K, V> put(K key, V value)
/* 182:    */     {
/* 183:372 */       super.put(key, value);
/* 184:373 */       return this;
/* 185:    */     }
/* 186:    */     
/* 187:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/* 188:    */     {
/* 189:385 */       super.put(entry);
/* 190:386 */       return this;
/* 191:    */     }
/* 192:    */     
/* 193:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/* 194:    */     {
/* 195:397 */       super.putAll(map);
/* 196:398 */       return this;
/* 197:    */     }
/* 198:    */     
/* 199:    */     public ImmutableSortedMap<K, V> build()
/* 200:    */     {
/* 201:408 */       return ImmutableSortedMap.fromEntries(this.comparator, false, this.size, this.entries);
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   ImmutableSortedMap(ImmutableSortedMap<K, V> descendingMap)
/* 206:    */   {
/* 207:416 */     this.descendingMap = descendingMap;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public int size()
/* 211:    */   {
/* 212:421 */     return values().size();
/* 213:    */   }
/* 214:    */   
/* 215:    */   public boolean containsValue(@Nullable Object value)
/* 216:    */   {
/* 217:425 */     return values().contains(value);
/* 218:    */   }
/* 219:    */   
/* 220:    */   boolean isPartialView()
/* 221:    */   {
/* 222:429 */     return (keySet().isPartialView()) || (values().isPartialView());
/* 223:    */   }
/* 224:    */   
/* 225:    */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/* 226:    */   {
/* 227:437 */     return super.entrySet();
/* 228:    */   }
/* 229:    */   
/* 230:    */   public abstract ImmutableSortedSet<K> keySet();
/* 231:    */   
/* 232:    */   public abstract ImmutableCollection<V> values();
/* 233:    */   
/* 234:    */   public Comparator<? super K> comparator()
/* 235:    */   {
/* 236:459 */     return keySet().comparator();
/* 237:    */   }
/* 238:    */   
/* 239:    */   public K firstKey()
/* 240:    */   {
/* 241:464 */     return keySet().first();
/* 242:    */   }
/* 243:    */   
/* 244:    */   public K lastKey()
/* 245:    */   {
/* 246:469 */     return keySet().last();
/* 247:    */   }
/* 248:    */   
/* 249:    */   public ImmutableSortedMap<K, V> headMap(K toKey)
/* 250:    */   {
/* 251:484 */     return headMap(toKey, false);
/* 252:    */   }
/* 253:    */   
/* 254:    */   public abstract ImmutableSortedMap<K, V> headMap(K paramK, boolean paramBoolean);
/* 255:    */   
/* 256:    */   public ImmutableSortedMap<K, V> subMap(K fromKey, K toKey)
/* 257:    */   {
/* 258:517 */     return subMap(fromKey, true, toKey, false);
/* 259:    */   }
/* 260:    */   
/* 261:    */   public ImmutableSortedMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 262:    */   {
/* 263:538 */     Preconditions.checkNotNull(fromKey);
/* 264:539 */     Preconditions.checkNotNull(toKey);
/* 265:540 */     Preconditions.checkArgument(comparator().compare(fromKey, toKey) <= 0, "expected fromKey <= toKey but %s > %s", new Object[] { fromKey, toKey });
/* 266:    */     
/* 267:542 */     return headMap(toKey, toInclusive).tailMap(fromKey, fromInclusive);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public ImmutableSortedMap<K, V> tailMap(K fromKey)
/* 271:    */   {
/* 272:557 */     return tailMap(fromKey, true);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public abstract ImmutableSortedMap<K, V> tailMap(K paramK, boolean paramBoolean);
/* 276:    */   
/* 277:    */   public Map.Entry<K, V> lowerEntry(K key)
/* 278:    */   {
/* 279:578 */     return headMap(key, false).lastEntry();
/* 280:    */   }
/* 281:    */   
/* 282:    */   public K lowerKey(K key)
/* 283:    */   {
/* 284:583 */     return Maps.keyOrNull(lowerEntry(key));
/* 285:    */   }
/* 286:    */   
/* 287:    */   public Map.Entry<K, V> floorEntry(K key)
/* 288:    */   {
/* 289:588 */     return headMap(key, true).lastEntry();
/* 290:    */   }
/* 291:    */   
/* 292:    */   public K floorKey(K key)
/* 293:    */   {
/* 294:593 */     return Maps.keyOrNull(floorEntry(key));
/* 295:    */   }
/* 296:    */   
/* 297:    */   public Map.Entry<K, V> ceilingEntry(K key)
/* 298:    */   {
/* 299:598 */     return tailMap(key, true).firstEntry();
/* 300:    */   }
/* 301:    */   
/* 302:    */   public K ceilingKey(K key)
/* 303:    */   {
/* 304:603 */     return Maps.keyOrNull(ceilingEntry(key));
/* 305:    */   }
/* 306:    */   
/* 307:    */   public Map.Entry<K, V> higherEntry(K key)
/* 308:    */   {
/* 309:608 */     return tailMap(key, false).firstEntry();
/* 310:    */   }
/* 311:    */   
/* 312:    */   public K higherKey(K key)
/* 313:    */   {
/* 314:613 */     return Maps.keyOrNull(higherEntry(key));
/* 315:    */   }
/* 316:    */   
/* 317:    */   public Map.Entry<K, V> firstEntry()
/* 318:    */   {
/* 319:618 */     return isEmpty() ? null : (Map.Entry)entrySet().asList().get(0);
/* 320:    */   }
/* 321:    */   
/* 322:    */   public Map.Entry<K, V> lastEntry()
/* 323:    */   {
/* 324:623 */     return isEmpty() ? null : (Map.Entry)entrySet().asList().get(size() - 1);
/* 325:    */   }
/* 326:    */   
/* 327:    */   @Deprecated
/* 328:    */   public final Map.Entry<K, V> pollFirstEntry()
/* 329:    */   {
/* 330:635 */     throw new UnsupportedOperationException();
/* 331:    */   }
/* 332:    */   
/* 333:    */   @Deprecated
/* 334:    */   public final Map.Entry<K, V> pollLastEntry()
/* 335:    */   {
/* 336:647 */     throw new UnsupportedOperationException();
/* 337:    */   }
/* 338:    */   
/* 339:    */   public ImmutableSortedMap<K, V> descendingMap()
/* 340:    */   {
/* 341:654 */     ImmutableSortedMap<K, V> result = this.descendingMap;
/* 342:655 */     if (result == null) {
/* 343:656 */       result = this.descendingMap = createDescendingMap();
/* 344:    */     }
/* 345:658 */     return result;
/* 346:    */   }
/* 347:    */   
/* 348:    */   abstract ImmutableSortedMap<K, V> createDescendingMap();
/* 349:    */   
/* 350:    */   public ImmutableSortedSet<K> navigableKeySet()
/* 351:    */   {
/* 352:665 */     return keySet();
/* 353:    */   }
/* 354:    */   
/* 355:    */   public ImmutableSortedSet<K> descendingKeySet()
/* 356:    */   {
/* 357:670 */     return keySet().descendingSet();
/* 358:    */   }
/* 359:    */   
/* 360:    */   private static class SerializedForm
/* 361:    */     extends ImmutableMap.SerializedForm
/* 362:    */   {
/* 363:    */     private final Comparator<Object> comparator;
/* 364:    */     private static final long serialVersionUID = 0L;
/* 365:    */     
/* 366:    */     SerializedForm(ImmutableSortedMap<?, ?> sortedMap)
/* 367:    */     {
/* 368:683 */       super();
/* 369:684 */       this.comparator = sortedMap.comparator();
/* 370:    */     }
/* 371:    */     
/* 372:    */     Object readResolve()
/* 373:    */     {
/* 374:687 */       ImmutableSortedMap.Builder<Object, Object> builder = new ImmutableSortedMap.Builder(this.comparator);
/* 375:688 */       return createMap(builder);
/* 376:    */     }
/* 377:    */   }
/* 378:    */   
/* 379:    */   Object writeReplace()
/* 380:    */   {
/* 381:694 */     return new SerializedForm(this);
/* 382:    */   }
/* 383:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedMap
 * JD-Core Version:    0.7.0.1
 */
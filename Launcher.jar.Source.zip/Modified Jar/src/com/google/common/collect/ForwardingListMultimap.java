/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.List;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ public abstract class ForwardingListMultimap<K, V>
/*  9:   */   extends ForwardingMultimap<K, V>
/* 10:   */   implements ListMultimap<K, V>
/* 11:   */ {
/* 12:   */   protected abstract ListMultimap<K, V> delegate();
/* 13:   */   
/* 14:   */   public List<V> get(@Nullable K key)
/* 15:   */   {
/* 16:44 */     return delegate().get(key);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public List<V> removeAll(@Nullable Object key)
/* 20:   */   {
/* 21:48 */     return delegate().removeAll(key);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public List<V> replaceValues(K key, Iterable<? extends V> values)
/* 25:   */   {
/* 26:52 */     return delegate().replaceValues(key, values);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingListMultimap
 * JD-Core Version:    0.7.0.1
 */
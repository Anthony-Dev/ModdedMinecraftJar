/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Map.Entry;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ @GwtCompatible(serializable=true, emulated=true)
/*   8:    */ final class RegularImmutableMap<K, V>
/*   9:    */   extends ImmutableMap<K, V>
/*  10:    */ {
/*  11:    */   private final transient ImmutableMapEntry<K, V>[] entries;
/*  12:    */   private final transient ImmutableMapEntry<K, V>[] table;
/*  13:    */   private final transient int mask;
/*  14:    */   private static final double MAX_LOAD_FACTOR = 1.2D;
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   RegularImmutableMap(ImmutableMapEntry.TerminalEntry<?, ?>... theEntries)
/*  18:    */   {
/*  19: 44 */     this(theEntries.length, theEntries);
/*  20:    */   }
/*  21:    */   
/*  22:    */   RegularImmutableMap(int size, ImmutableMapEntry.TerminalEntry<?, ?>[] theEntries)
/*  23:    */   {
/*  24: 54 */     this.entries = createEntryArray(size);
/*  25: 55 */     int tableSize = Hashing.closedTableSize(size, 1.2D);
/*  26: 56 */     this.table = createEntryArray(tableSize);
/*  27: 57 */     this.mask = (tableSize - 1);
/*  28: 58 */     for (int entryIndex = 0; entryIndex < size; entryIndex++)
/*  29:    */     {
/*  30: 60 */       ImmutableMapEntry.TerminalEntry<K, V> entry = theEntries[entryIndex];
/*  31: 61 */       K key = entry.getKey();
/*  32: 62 */       int tableIndex = Hashing.smear(key.hashCode()) & this.mask;
/*  33: 63 */       ImmutableMapEntry<K, V> existing = this.table[tableIndex];
/*  34:    */       
/*  35: 65 */       ImmutableMapEntry<K, V> newEntry = existing == null ? entry : new NonTerminalMapEntry(entry, existing);
/*  36:    */       
/*  37:    */ 
/*  38: 68 */       this.table[tableIndex] = newEntry;
/*  39: 69 */       this.entries[entryIndex] = newEntry;
/*  40: 70 */       checkNoConflictInBucket(key, newEntry, existing);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   RegularImmutableMap(Map.Entry<?, ?>[] theEntries)
/*  45:    */   {
/*  46: 78 */     int size = theEntries.length;
/*  47: 79 */     this.entries = createEntryArray(size);
/*  48: 80 */     int tableSize = Hashing.closedTableSize(size, 1.2D);
/*  49: 81 */     this.table = createEntryArray(tableSize);
/*  50: 82 */     this.mask = (tableSize - 1);
/*  51: 83 */     for (int entryIndex = 0; entryIndex < size; entryIndex++)
/*  52:    */     {
/*  53: 85 */       Map.Entry<K, V> entry = theEntries[entryIndex];
/*  54: 86 */       K key = entry.getKey();
/*  55: 87 */       V value = entry.getValue();
/*  56: 88 */       CollectPreconditions.checkEntryNotNull(key, value);
/*  57: 89 */       int tableIndex = Hashing.smear(key.hashCode()) & this.mask;
/*  58: 90 */       ImmutableMapEntry<K, V> existing = this.table[tableIndex];
/*  59:    */       
/*  60: 92 */       ImmutableMapEntry<K, V> newEntry = existing == null ? new ImmutableMapEntry.TerminalEntry(key, value) : new NonTerminalMapEntry(key, value, existing);
/*  61:    */       
/*  62:    */ 
/*  63: 95 */       this.table[tableIndex] = newEntry;
/*  64: 96 */       this.entries[entryIndex] = newEntry;
/*  65: 97 */       checkNoConflictInBucket(key, newEntry, existing);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   private void checkNoConflictInBucket(K key, ImmutableMapEntry<K, V> entry, ImmutableMapEntry<K, V> bucketHead)
/*  70:    */   {
/*  71:103 */     for (; bucketHead != null; bucketHead = bucketHead.getNextInKeyBucket()) {
/*  72:104 */       checkNoConflict(!key.equals(bucketHead.getKey()), "key", entry, bucketHead);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   private static final class NonTerminalMapEntry<K, V>
/*  77:    */     extends ImmutableMapEntry<K, V>
/*  78:    */   {
/*  79:    */     private final ImmutableMapEntry<K, V> nextInKeyBucket;
/*  80:    */     
/*  81:    */     NonTerminalMapEntry(K key, V value, ImmutableMapEntry<K, V> nextInKeyBucket)
/*  82:    */     {
/*  83:112 */       super(value);
/*  84:113 */       this.nextInKeyBucket = nextInKeyBucket;
/*  85:    */     }
/*  86:    */     
/*  87:    */     NonTerminalMapEntry(ImmutableMapEntry<K, V> contents, ImmutableMapEntry<K, V> nextInKeyBucket)
/*  88:    */     {
/*  89:117 */       super();
/*  90:118 */       this.nextInKeyBucket = nextInKeyBucket;
/*  91:    */     }
/*  92:    */     
/*  93:    */     ImmutableMapEntry<K, V> getNextInKeyBucket()
/*  94:    */     {
/*  95:123 */       return this.nextInKeyBucket;
/*  96:    */     }
/*  97:    */     
/*  98:    */     @Nullable
/*  99:    */     ImmutableMapEntry<K, V> getNextInValueBucket()
/* 100:    */     {
/* 101:129 */       return null;
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   private ImmutableMapEntry<K, V>[] createEntryArray(int size)
/* 106:    */   {
/* 107:148 */     return new ImmutableMapEntry[size];
/* 108:    */   }
/* 109:    */   
/* 110:    */   public V get(@Nullable Object key)
/* 111:    */   {
/* 112:152 */     if (key == null) {
/* 113:153 */       return null;
/* 114:    */     }
/* 115:155 */     int index = Hashing.smear(key.hashCode()) & this.mask;
/* 116:156 */     for (ImmutableMapEntry<K, V> entry = this.table[index]; entry != null; entry = entry.getNextInKeyBucket())
/* 117:    */     {
/* 118:159 */       K candidateKey = entry.getKey();
/* 119:167 */       if (key.equals(candidateKey)) {
/* 120:168 */         return entry.getValue();
/* 121:    */       }
/* 122:    */     }
/* 123:171 */     return null;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public int size()
/* 127:    */   {
/* 128:176 */     return this.entries.length;
/* 129:    */   }
/* 130:    */   
/* 131:    */   boolean isPartialView()
/* 132:    */   {
/* 133:180 */     return false;
/* 134:    */   }
/* 135:    */   
/* 136:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 137:    */   {
/* 138:185 */     return new EntrySet(null);
/* 139:    */   }
/* 140:    */   
/* 141:    */   private class EntrySet
/* 142:    */     extends ImmutableMapEntrySet<K, V>
/* 143:    */   {
/* 144:    */     private EntrySet() {}
/* 145:    */     
/* 146:    */     ImmutableMap<K, V> map()
/* 147:    */     {
/* 148:191 */       return RegularImmutableMap.this;
/* 149:    */     }
/* 150:    */     
/* 151:    */     public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 152:    */     {
/* 153:196 */       return asList().iterator();
/* 154:    */     }
/* 155:    */     
/* 156:    */     ImmutableList<Map.Entry<K, V>> createAsList()
/* 157:    */     {
/* 158:201 */       return new RegularImmutableAsList(this, RegularImmutableMap.this.entries);
/* 159:    */     }
/* 160:    */   }
/* 161:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableMap
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtIncompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtIncompatible("unnecessary")
/*  7:   */ abstract class ImmutableMapEntry<K, V>
/*  8:   */   extends ImmutableEntry<K, V>
/*  9:   */ {
/* 10:   */   ImmutableMapEntry(K key, V value)
/* 11:   */   {
/* 12:36 */     super(key, value);
/* 13:37 */     CollectPreconditions.checkEntryNotNull(key, value);
/* 14:   */   }
/* 15:   */   
/* 16:   */   ImmutableMapEntry(ImmutableMapEntry<K, V> contents)
/* 17:   */   {
/* 18:41 */     super(contents.getKey(), contents.getValue());
/* 19:   */   }
/* 20:   */   
/* 21:   */   @Nullable
/* 22:   */   abstract ImmutableMapEntry<K, V> getNextInKeyBucket();
/* 23:   */   
/* 24:   */   @Nullable
/* 25:   */   abstract ImmutableMapEntry<K, V> getNextInValueBucket();
/* 26:   */   
/* 27:   */   static final class TerminalEntry<K, V>
/* 28:   */     extends ImmutableMapEntry<K, V>
/* 29:   */   {
/* 30:   */     TerminalEntry(ImmutableMapEntry<K, V> contents)
/* 31:   */     {
/* 32:53 */       super();
/* 33:   */     }
/* 34:   */     
/* 35:   */     TerminalEntry(K key, V value)
/* 36:   */     {
/* 37:57 */       super(value);
/* 38:   */     }
/* 39:   */     
/* 40:   */     @Nullable
/* 41:   */     ImmutableMapEntry<K, V> getNextInKeyBucket()
/* 42:   */     {
/* 43:63 */       return null;
/* 44:   */     }
/* 45:   */     
/* 46:   */     @Nullable
/* 47:   */     ImmutableMapEntry<K, V> getNextInValueBucket()
/* 48:   */     {
/* 49:69 */       return null;
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapEntry
 * JD-Core Version:    0.7.0.1
 */
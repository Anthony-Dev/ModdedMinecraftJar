/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.NavigableMap;
/*   7:    */ import java.util.NavigableSet;
/*   8:    */ import java.util.NoSuchElementException;
/*   9:    */ import java.util.Set;
/*  10:    */ import java.util.SortedMap;
/*  11:    */ 
/*  12:    */ public abstract class ForwardingNavigableMap<K, V>
/*  13:    */   extends ForwardingSortedMap<K, V>
/*  14:    */   implements NavigableMap<K, V>
/*  15:    */ {
/*  16:    */   protected abstract NavigableMap<K, V> delegate();
/*  17:    */   
/*  18:    */   public Map.Entry<K, V> lowerEntry(K key)
/*  19:    */   {
/*  20: 63 */     return delegate().lowerEntry(key);
/*  21:    */   }
/*  22:    */   
/*  23:    */   protected Map.Entry<K, V> standardLowerEntry(K key)
/*  24:    */   {
/*  25: 72 */     return headMap(key, false).lastEntry();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public K lowerKey(K key)
/*  29:    */   {
/*  30: 77 */     return delegate().lowerKey(key);
/*  31:    */   }
/*  32:    */   
/*  33:    */   protected K standardLowerKey(K key)
/*  34:    */   {
/*  35: 86 */     return Maps.keyOrNull(lowerEntry(key));
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Map.Entry<K, V> floorEntry(K key)
/*  39:    */   {
/*  40: 91 */     return delegate().floorEntry(key);
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected Map.Entry<K, V> standardFloorEntry(K key)
/*  44:    */   {
/*  45:100 */     return headMap(key, true).lastEntry();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public K floorKey(K key)
/*  49:    */   {
/*  50:105 */     return delegate().floorKey(key);
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected K standardFloorKey(K key)
/*  54:    */   {
/*  55:114 */     return Maps.keyOrNull(floorEntry(key));
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Map.Entry<K, V> ceilingEntry(K key)
/*  59:    */   {
/*  60:119 */     return delegate().ceilingEntry(key);
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected Map.Entry<K, V> standardCeilingEntry(K key)
/*  64:    */   {
/*  65:128 */     return tailMap(key, true).firstEntry();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public K ceilingKey(K key)
/*  69:    */   {
/*  70:133 */     return delegate().ceilingKey(key);
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected K standardCeilingKey(K key)
/*  74:    */   {
/*  75:142 */     return Maps.keyOrNull(ceilingEntry(key));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Map.Entry<K, V> higherEntry(K key)
/*  79:    */   {
/*  80:147 */     return delegate().higherEntry(key);
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected Map.Entry<K, V> standardHigherEntry(K key)
/*  84:    */   {
/*  85:156 */     return tailMap(key, false).firstEntry();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public K higherKey(K key)
/*  89:    */   {
/*  90:161 */     return delegate().higherKey(key);
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected K standardHigherKey(K key)
/*  94:    */   {
/*  95:170 */     return Maps.keyOrNull(higherEntry(key));
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Map.Entry<K, V> firstEntry()
/*  99:    */   {
/* 100:175 */     return delegate().firstEntry();
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected Map.Entry<K, V> standardFirstEntry()
/* 104:    */   {
/* 105:184 */     return (Map.Entry)Iterables.getFirst(entrySet(), null);
/* 106:    */   }
/* 107:    */   
/* 108:    */   protected K standardFirstKey()
/* 109:    */   {
/* 110:193 */     Map.Entry<K, V> entry = firstEntry();
/* 111:194 */     if (entry == null) {
/* 112:195 */       throw new NoSuchElementException();
/* 113:    */     }
/* 114:197 */     return entry.getKey();
/* 115:    */   }
/* 116:    */   
/* 117:    */   public Map.Entry<K, V> lastEntry()
/* 118:    */   {
/* 119:203 */     return delegate().lastEntry();
/* 120:    */   }
/* 121:    */   
/* 122:    */   protected Map.Entry<K, V> standardLastEntry()
/* 123:    */   {
/* 124:212 */     return (Map.Entry)Iterables.getFirst(descendingMap().entrySet(), null);
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected K standardLastKey()
/* 128:    */   {
/* 129:220 */     Map.Entry<K, V> entry = lastEntry();
/* 130:221 */     if (entry == null) {
/* 131:222 */       throw new NoSuchElementException();
/* 132:    */     }
/* 133:224 */     return entry.getKey();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Map.Entry<K, V> pollFirstEntry()
/* 137:    */   {
/* 138:230 */     return delegate().pollFirstEntry();
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected Map.Entry<K, V> standardPollFirstEntry()
/* 142:    */   {
/* 143:239 */     return (Map.Entry)Iterators.pollNext(entrySet().iterator());
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Map.Entry<K, V> pollLastEntry()
/* 147:    */   {
/* 148:244 */     return delegate().pollLastEntry();
/* 149:    */   }
/* 150:    */   
/* 151:    */   protected Map.Entry<K, V> standardPollLastEntry()
/* 152:    */   {
/* 153:253 */     return (Map.Entry)Iterators.pollNext(descendingMap().entrySet().iterator());
/* 154:    */   }
/* 155:    */   
/* 156:    */   public NavigableMap<K, V> descendingMap()
/* 157:    */   {
/* 158:258 */     return delegate().descendingMap();
/* 159:    */   }
/* 160:    */   
/* 161:    */   @Beta
/* 162:    */   protected class StandardDescendingMap
/* 163:    */     extends Maps.DescendingMap<K, V>
/* 164:    */   {
/* 165:    */     public StandardDescendingMap() {}
/* 166:    */     
/* 167:    */     NavigableMap<K, V> forward()
/* 168:    */     {
/* 169:280 */       return ForwardingNavigableMap.this;
/* 170:    */     }
/* 171:    */     
/* 172:    */     protected Iterator<Map.Entry<K, V>> entryIterator()
/* 173:    */     {
/* 174:285 */       new Iterator()
/* 175:    */       {
/* 176:286 */         private Map.Entry<K, V> toRemove = null;
/* 177:287 */         private Map.Entry<K, V> nextOrNull = ForwardingNavigableMap.StandardDescendingMap.this.forward().lastEntry();
/* 178:    */         
/* 179:    */         public boolean hasNext()
/* 180:    */         {
/* 181:291 */           return this.nextOrNull != null;
/* 182:    */         }
/* 183:    */         
/* 184:    */         public Map.Entry<K, V> next()
/* 185:    */         {
/* 186:296 */           if (!hasNext()) {
/* 187:297 */             throw new NoSuchElementException();
/* 188:    */           }
/* 189:    */           try
/* 190:    */           {
/* 191:300 */             return this.nextOrNull;
/* 192:    */           }
/* 193:    */           finally
/* 194:    */           {
/* 195:302 */             this.toRemove = this.nextOrNull;
/* 196:303 */             this.nextOrNull = ForwardingNavigableMap.StandardDescendingMap.this.forward().lowerEntry(this.nextOrNull.getKey());
/* 197:    */           }
/* 198:    */         }
/* 199:    */         
/* 200:    */         public void remove()
/* 201:    */         {
/* 202:309 */           CollectPreconditions.checkRemove(this.toRemove != null);
/* 203:310 */           ForwardingNavigableMap.StandardDescendingMap.this.forward().remove(this.toRemove.getKey());
/* 204:311 */           this.toRemove = null;
/* 205:    */         }
/* 206:    */       };
/* 207:    */     }
/* 208:    */   }
/* 209:    */   
/* 210:    */   public NavigableSet<K> navigableKeySet()
/* 211:    */   {
/* 212:319 */     return delegate().navigableKeySet();
/* 213:    */   }
/* 214:    */   
/* 215:    */   @Beta
/* 216:    */   protected class StandardNavigableKeySet
/* 217:    */     extends Maps.NavigableKeySet<K, V>
/* 218:    */   {
/* 219:    */     public StandardNavigableKeySet()
/* 220:    */     {
/* 221:334 */       super();
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   public NavigableSet<K> descendingKeySet()
/* 226:    */   {
/* 227:340 */     return delegate().descendingKeySet();
/* 228:    */   }
/* 229:    */   
/* 230:    */   @Beta
/* 231:    */   protected NavigableSet<K> standardDescendingKeySet()
/* 232:    */   {
/* 233:352 */     return descendingMap().navigableKeySet();
/* 234:    */   }
/* 235:    */   
/* 236:    */   protected SortedMap<K, V> standardSubMap(K fromKey, K toKey)
/* 237:    */   {
/* 238:363 */     return subMap(fromKey, true, toKey, false);
/* 239:    */   }
/* 240:    */   
/* 241:    */   public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 242:    */   {
/* 243:368 */     return delegate().subMap(fromKey, fromInclusive, toKey, toInclusive);
/* 244:    */   }
/* 245:    */   
/* 246:    */   public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 247:    */   {
/* 248:373 */     return delegate().headMap(toKey, inclusive);
/* 249:    */   }
/* 250:    */   
/* 251:    */   public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 252:    */   {
/* 253:378 */     return delegate().tailMap(fromKey, inclusive);
/* 254:    */   }
/* 255:    */   
/* 256:    */   protected SortedMap<K, V> standardHeadMap(K toKey)
/* 257:    */   {
/* 258:387 */     return headMap(toKey, false);
/* 259:    */   }
/* 260:    */   
/* 261:    */   protected SortedMap<K, V> standardTailMap(K fromKey)
/* 262:    */   {
/* 263:396 */     return tailMap(fromKey, true);
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingNavigableMap
 * JD-Core Version:    0.7.0.1
 */
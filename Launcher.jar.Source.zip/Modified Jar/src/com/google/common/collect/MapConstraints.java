/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.LinkedHashMap;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedSet;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @Beta
/*  19:    */ @GwtCompatible
/*  20:    */ public final class MapConstraints
/*  21:    */ {
/*  22:    */   public static MapConstraint<Object, Object> notNull()
/*  23:    */   {
/*  24: 54 */     return NotNullMapConstraint.INSTANCE;
/*  25:    */   }
/*  26:    */   
/*  27:    */   private static enum NotNullMapConstraint
/*  28:    */     implements MapConstraint<Object, Object>
/*  29:    */   {
/*  30: 59 */     INSTANCE;
/*  31:    */     
/*  32:    */     private NotNullMapConstraint() {}
/*  33:    */     
/*  34:    */     public void checkKeyValue(Object key, Object value)
/*  35:    */     {
/*  36: 63 */       Preconditions.checkNotNull(key);
/*  37: 64 */       Preconditions.checkNotNull(value);
/*  38:    */     }
/*  39:    */     
/*  40:    */     public String toString()
/*  41:    */     {
/*  42: 68 */       return "Not null";
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <K, V> Map<K, V> constrainedMap(Map<K, V> map, MapConstraint<? super K, ? super V> constraint)
/*  47:    */   {
/*  48: 86 */     return new ConstrainedMap(map, constraint);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <K, V> Multimap<K, V> constrainedMultimap(Multimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  52:    */   {
/*  53:107 */     return new ConstrainedMultimap(multimap, constraint);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <K, V> ListMultimap<K, V> constrainedListMultimap(ListMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  57:    */   {
/*  58:129 */     return new ConstrainedListMultimap(multimap, constraint);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <K, V> SetMultimap<K, V> constrainedSetMultimap(SetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  62:    */   {
/*  63:150 */     return new ConstrainedSetMultimap(multimap, constraint);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <K, V> SortedSetMultimap<K, V> constrainedSortedSetMultimap(SortedSetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  67:    */   {
/*  68:171 */     return new ConstrainedSortedSetMultimap(multimap, constraint);
/*  69:    */   }
/*  70:    */   
/*  71:    */   private static <K, V> Map.Entry<K, V> constrainedEntry(Map.Entry<K, V> entry, final MapConstraint<? super K, ? super V> constraint)
/*  72:    */   {
/*  73:186 */     Preconditions.checkNotNull(entry);
/*  74:187 */     Preconditions.checkNotNull(constraint);
/*  75:188 */     new ForwardingMapEntry()
/*  76:    */     {
/*  77:    */       protected Map.Entry<K, V> delegate()
/*  78:    */       {
/*  79:190 */         return this.val$entry;
/*  80:    */       }
/*  81:    */       
/*  82:    */       public V setValue(V value)
/*  83:    */       {
/*  84:193 */         constraint.checkKeyValue(getKey(), value);
/*  85:194 */         return this.val$entry.setValue(value);
/*  86:    */       }
/*  87:    */     };
/*  88:    */   }
/*  89:    */   
/*  90:    */   private static <K, V> Map.Entry<K, Collection<V>> constrainedAsMapEntry(Map.Entry<K, Collection<V>> entry, final MapConstraint<? super K, ? super V> constraint)
/*  91:    */   {
/*  92:212 */     Preconditions.checkNotNull(entry);
/*  93:213 */     Preconditions.checkNotNull(constraint);
/*  94:214 */     new ForwardingMapEntry()
/*  95:    */     {
/*  96:    */       protected Map.Entry<K, Collection<V>> delegate()
/*  97:    */       {
/*  98:216 */         return this.val$entry;
/*  99:    */       }
/* 100:    */       
/* 101:    */       public Collection<V> getValue()
/* 102:    */       {
/* 103:219 */         Constraints.constrainedTypePreservingCollection((Collection)this.val$entry.getValue(), new Constraint()
/* 104:    */         {
/* 105:    */           public V checkElement(V value)
/* 106:    */           {
/* 107:223 */             MapConstraints.2.this.val$constraint.checkKeyValue(MapConstraints.2.this.getKey(), value);
/* 108:224 */             return value;
/* 109:    */           }
/* 110:    */         });
/* 111:    */       }
/* 112:    */     };
/* 113:    */   }
/* 114:    */   
/* 115:    */   private static <K, V> Set<Map.Entry<K, Collection<V>>> constrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/* 116:    */   {
/* 117:246 */     return new ConstrainedAsMapEntries(entries, constraint);
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static <K, V> Collection<Map.Entry<K, V>> constrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 121:    */   {
/* 122:264 */     if ((entries instanceof Set)) {
/* 123:265 */       return constrainedEntrySet((Set)entries, constraint);
/* 124:    */     }
/* 125:267 */     return new ConstrainedEntries(entries, constraint);
/* 126:    */   }
/* 127:    */   
/* 128:    */   private static <K, V> Set<Map.Entry<K, V>> constrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 129:    */   {
/* 130:287 */     return new ConstrainedEntrySet(entries, constraint);
/* 131:    */   }
/* 132:    */   
/* 133:    */   static class ConstrainedMap<K, V>
/* 134:    */     extends ForwardingMap<K, V>
/* 135:    */   {
/* 136:    */     private final Map<K, V> delegate;
/* 137:    */     final MapConstraint<? super K, ? super V> constraint;
/* 138:    */     private transient Set<Map.Entry<K, V>> entrySet;
/* 139:    */     
/* 140:    */     ConstrainedMap(Map<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 141:    */     {
/* 142:298 */       this.delegate = ((Map)Preconditions.checkNotNull(delegate));
/* 143:299 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 144:    */     }
/* 145:    */     
/* 146:    */     protected Map<K, V> delegate()
/* 147:    */     {
/* 148:302 */       return this.delegate;
/* 149:    */     }
/* 150:    */     
/* 151:    */     public Set<Map.Entry<K, V>> entrySet()
/* 152:    */     {
/* 153:305 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 154:306 */       if (result == null) {
/* 155:307 */         this.entrySet = (result = MapConstraints.constrainedEntrySet(this.delegate.entrySet(), this.constraint));
/* 156:    */       }
/* 157:310 */       return result;
/* 158:    */     }
/* 159:    */     
/* 160:    */     public V put(K key, V value)
/* 161:    */     {
/* 162:313 */       this.constraint.checkKeyValue(key, value);
/* 163:314 */       return this.delegate.put(key, value);
/* 164:    */     }
/* 165:    */     
/* 166:    */     public void putAll(Map<? extends K, ? extends V> map)
/* 167:    */     {
/* 168:317 */       this.delegate.putAll(MapConstraints.checkMap(map, this.constraint));
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static <K, V> BiMap<K, V> constrainedBiMap(BiMap<K, V> map, MapConstraint<? super K, ? super V> constraint)
/* 173:    */   {
/* 174:334 */     return new ConstrainedBiMap(map, null, constraint);
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static class ConstrainedBiMap<K, V>
/* 178:    */     extends MapConstraints.ConstrainedMap<K, V>
/* 179:    */     implements BiMap<K, V>
/* 180:    */   {
/* 181:    */     volatile BiMap<V, K> inverse;
/* 182:    */     
/* 183:    */     ConstrainedBiMap(BiMap<K, V> delegate, @Nullable BiMap<V, K> inverse, MapConstraint<? super K, ? super V> constraint)
/* 184:    */     {
/* 185:356 */       super(constraint);
/* 186:357 */       this.inverse = inverse;
/* 187:    */     }
/* 188:    */     
/* 189:    */     protected BiMap<K, V> delegate()
/* 190:    */     {
/* 191:361 */       return (BiMap)super.delegate();
/* 192:    */     }
/* 193:    */     
/* 194:    */     public V forcePut(K key, V value)
/* 195:    */     {
/* 196:366 */       this.constraint.checkKeyValue(key, value);
/* 197:367 */       return delegate().forcePut(key, value);
/* 198:    */     }
/* 199:    */     
/* 200:    */     public BiMap<V, K> inverse()
/* 201:    */     {
/* 202:372 */       if (this.inverse == null) {
/* 203:373 */         this.inverse = new ConstrainedBiMap(delegate().inverse(), this, new MapConstraints.InverseConstraint(this.constraint));
/* 204:    */       }
/* 205:376 */       return this.inverse;
/* 206:    */     }
/* 207:    */     
/* 208:    */     public Set<V> values()
/* 209:    */     {
/* 210:380 */       return delegate().values();
/* 211:    */     }
/* 212:    */   }
/* 213:    */   
/* 214:    */   private static class InverseConstraint<K, V>
/* 215:    */     implements MapConstraint<K, V>
/* 216:    */   {
/* 217:    */     final MapConstraint<? super V, ? super K> constraint;
/* 218:    */     
/* 219:    */     public InverseConstraint(MapConstraint<? super V, ? super K> constraint)
/* 220:    */     {
/* 221:389 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 222:    */     }
/* 223:    */     
/* 224:    */     public void checkKeyValue(K key, V value)
/* 225:    */     {
/* 226:393 */       this.constraint.checkKeyValue(value, key);
/* 227:    */     }
/* 228:    */   }
/* 229:    */   
/* 230:    */   private static class ConstrainedMultimap<K, V>
/* 231:    */     extends ForwardingMultimap<K, V>
/* 232:    */     implements Serializable
/* 233:    */   {
/* 234:    */     final MapConstraint<? super K, ? super V> constraint;
/* 235:    */     final Multimap<K, V> delegate;
/* 236:    */     transient Collection<Map.Entry<K, V>> entries;
/* 237:    */     transient Map<K, Collection<V>> asMap;
/* 238:    */     
/* 239:    */     public ConstrainedMultimap(Multimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 240:    */     {
/* 241:407 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/* 242:408 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 243:    */     }
/* 244:    */     
/* 245:    */     protected Multimap<K, V> delegate()
/* 246:    */     {
/* 247:412 */       return this.delegate;
/* 248:    */     }
/* 249:    */     
/* 250:    */     public Map<K, Collection<V>> asMap()
/* 251:    */     {
/* 252:416 */       Map<K, Collection<V>> result = this.asMap;
/* 253:417 */       if (result == null)
/* 254:    */       {
/* 255:418 */         final Map<K, Collection<V>> asMapDelegate = this.delegate.asMap();
/* 256:    */         
/* 257:420 */         this.asMap = (result = new ForwardingMap()
/* 258:    */         {
/* 259:    */           Set<Map.Entry<K, Collection<V>>> entrySet;
/* 260:    */           Collection<Collection<V>> values;
/* 261:    */           
/* 262:    */           protected Map<K, Collection<V>> delegate()
/* 263:    */           {
/* 264:425 */             return asMapDelegate;
/* 265:    */           }
/* 266:    */           
/* 267:    */           public Set<Map.Entry<K, Collection<V>>> entrySet()
/* 268:    */           {
/* 269:429 */             Set<Map.Entry<K, Collection<V>>> result = this.entrySet;
/* 270:430 */             if (result == null) {
/* 271:431 */               this.entrySet = (result = MapConstraints.constrainedAsMapEntries(asMapDelegate.entrySet(), MapConstraints.ConstrainedMultimap.this.constraint));
/* 272:    */             }
/* 273:434 */             return result;
/* 274:    */           }
/* 275:    */           
/* 276:    */           public Collection<V> get(Object key)
/* 277:    */           {
/* 278:    */             try
/* 279:    */             {
/* 280:440 */               Collection<V> collection = MapConstraints.ConstrainedMultimap.this.get(key);
/* 281:441 */               return collection.isEmpty() ? null : collection;
/* 282:    */             }
/* 283:    */             catch (ClassCastException e) {}
/* 284:443 */             return null;
/* 285:    */           }
/* 286:    */           
/* 287:    */           public Collection<Collection<V>> values()
/* 288:    */           {
/* 289:448 */             Collection<Collection<V>> result = this.values;
/* 290:449 */             if (result == null) {
/* 291:450 */               this.values = (result = new MapConstraints.ConstrainedAsMapValues(delegate().values(), entrySet()));
/* 292:    */             }
/* 293:453 */             return result;
/* 294:    */           }
/* 295:    */           
/* 296:    */           public boolean containsValue(Object o)
/* 297:    */           {
/* 298:457 */             return values().contains(o);
/* 299:    */           }
/* 300:    */         });
/* 301:    */       }
/* 302:461 */       return result;
/* 303:    */     }
/* 304:    */     
/* 305:    */     public Collection<Map.Entry<K, V>> entries()
/* 306:    */     {
/* 307:465 */       Collection<Map.Entry<K, V>> result = this.entries;
/* 308:466 */       if (result == null) {
/* 309:467 */         this.entries = (result = MapConstraints.constrainedEntries(this.delegate.entries(), this.constraint));
/* 310:    */       }
/* 311:469 */       return result;
/* 312:    */     }
/* 313:    */     
/* 314:    */     public Collection<V> get(final K key)
/* 315:    */     {
/* 316:473 */       Constraints.constrainedTypePreservingCollection(this.delegate.get(key), new Constraint()
/* 317:    */       {
/* 318:    */         public V checkElement(V value)
/* 319:    */         {
/* 320:477 */           MapConstraints.ConstrainedMultimap.this.constraint.checkKeyValue(key, value);
/* 321:478 */           return value;
/* 322:    */         }
/* 323:    */       });
/* 324:    */     }
/* 325:    */     
/* 326:    */     public boolean put(K key, V value)
/* 327:    */     {
/* 328:484 */       this.constraint.checkKeyValue(key, value);
/* 329:485 */       return this.delegate.put(key, value);
/* 330:    */     }
/* 331:    */     
/* 332:    */     public boolean putAll(K key, Iterable<? extends V> values)
/* 333:    */     {
/* 334:489 */       return this.delegate.putAll(key, MapConstraints.checkValues(key, values, this.constraint));
/* 335:    */     }
/* 336:    */     
/* 337:    */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/* 338:    */     {
/* 339:494 */       boolean changed = false;
/* 340:495 */       for (Map.Entry<? extends K, ? extends V> entry : multimap.entries()) {
/* 341:496 */         changed |= put(entry.getKey(), entry.getValue());
/* 342:    */       }
/* 343:498 */       return changed;
/* 344:    */     }
/* 345:    */     
/* 346:    */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/* 347:    */     {
/* 348:503 */       return this.delegate.replaceValues(key, MapConstraints.checkValues(key, values, this.constraint));
/* 349:    */     }
/* 350:    */   }
/* 351:    */   
/* 352:    */   private static class ConstrainedAsMapValues<K, V>
/* 353:    */     extends ForwardingCollection<Collection<V>>
/* 354:    */   {
/* 355:    */     final Collection<Collection<V>> delegate;
/* 356:    */     final Set<Map.Entry<K, Collection<V>>> entrySet;
/* 357:    */     
/* 358:    */     ConstrainedAsMapValues(Collection<Collection<V>> delegate, Set<Map.Entry<K, Collection<V>>> entrySet)
/* 359:    */     {
/* 360:519 */       this.delegate = delegate;
/* 361:520 */       this.entrySet = entrySet;
/* 362:    */     }
/* 363:    */     
/* 364:    */     protected Collection<Collection<V>> delegate()
/* 365:    */     {
/* 366:523 */       return this.delegate;
/* 367:    */     }
/* 368:    */     
/* 369:    */     public Iterator<Collection<V>> iterator()
/* 370:    */     {
/* 371:527 */       final Iterator<Map.Entry<K, Collection<V>>> iterator = this.entrySet.iterator();
/* 372:528 */       new Iterator()
/* 373:    */       {
/* 374:    */         public boolean hasNext()
/* 375:    */         {
/* 376:531 */           return iterator.hasNext();
/* 377:    */         }
/* 378:    */         
/* 379:    */         public Collection<V> next()
/* 380:    */         {
/* 381:535 */           return (Collection)((Map.Entry)iterator.next()).getValue();
/* 382:    */         }
/* 383:    */         
/* 384:    */         public void remove()
/* 385:    */         {
/* 386:539 */           iterator.remove();
/* 387:    */         }
/* 388:    */       };
/* 389:    */     }
/* 390:    */     
/* 391:    */     public Object[] toArray()
/* 392:    */     {
/* 393:545 */       return standardToArray();
/* 394:    */     }
/* 395:    */     
/* 396:    */     public <T> T[] toArray(T[] array)
/* 397:    */     {
/* 398:548 */       return standardToArray(array);
/* 399:    */     }
/* 400:    */     
/* 401:    */     public boolean contains(Object o)
/* 402:    */     {
/* 403:551 */       return standardContains(o);
/* 404:    */     }
/* 405:    */     
/* 406:    */     public boolean containsAll(Collection<?> c)
/* 407:    */     {
/* 408:554 */       return standardContainsAll(c);
/* 409:    */     }
/* 410:    */     
/* 411:    */     public boolean remove(Object o)
/* 412:    */     {
/* 413:557 */       return standardRemove(o);
/* 414:    */     }
/* 415:    */     
/* 416:    */     public boolean removeAll(Collection<?> c)
/* 417:    */     {
/* 418:560 */       return standardRemoveAll(c);
/* 419:    */     }
/* 420:    */     
/* 421:    */     public boolean retainAll(Collection<?> c)
/* 422:    */     {
/* 423:563 */       return standardRetainAll(c);
/* 424:    */     }
/* 425:    */   }
/* 426:    */   
/* 427:    */   private static class ConstrainedEntries<K, V>
/* 428:    */     extends ForwardingCollection<Map.Entry<K, V>>
/* 429:    */   {
/* 430:    */     final MapConstraint<? super K, ? super V> constraint;
/* 431:    */     final Collection<Map.Entry<K, V>> entries;
/* 432:    */     
/* 433:    */     ConstrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 434:    */     {
/* 435:575 */       this.entries = entries;
/* 436:576 */       this.constraint = constraint;
/* 437:    */     }
/* 438:    */     
/* 439:    */     protected Collection<Map.Entry<K, V>> delegate()
/* 440:    */     {
/* 441:579 */       return this.entries;
/* 442:    */     }
/* 443:    */     
/* 444:    */     public Iterator<Map.Entry<K, V>> iterator()
/* 445:    */     {
/* 446:583 */       final Iterator<Map.Entry<K, V>> iterator = this.entries.iterator();
/* 447:584 */       new ForwardingIterator()
/* 448:    */       {
/* 449:    */         public Map.Entry<K, V> next()
/* 450:    */         {
/* 451:586 */           return MapConstraints.constrainedEntry((Map.Entry)iterator.next(), MapConstraints.ConstrainedEntries.this.constraint);
/* 452:    */         }
/* 453:    */         
/* 454:    */         protected Iterator<Map.Entry<K, V>> delegate()
/* 455:    */         {
/* 456:589 */           return iterator;
/* 457:    */         }
/* 458:    */       };
/* 459:    */     }
/* 460:    */     
/* 461:    */     public Object[] toArray()
/* 462:    */     {
/* 463:597 */       return standardToArray();
/* 464:    */     }
/* 465:    */     
/* 466:    */     public <T> T[] toArray(T[] array)
/* 467:    */     {
/* 468:600 */       return standardToArray(array);
/* 469:    */     }
/* 470:    */     
/* 471:    */     public boolean contains(Object o)
/* 472:    */     {
/* 473:603 */       return Maps.containsEntryImpl(delegate(), o);
/* 474:    */     }
/* 475:    */     
/* 476:    */     public boolean containsAll(Collection<?> c)
/* 477:    */     {
/* 478:606 */       return standardContainsAll(c);
/* 479:    */     }
/* 480:    */     
/* 481:    */     public boolean remove(Object o)
/* 482:    */     {
/* 483:609 */       return Maps.removeEntryImpl(delegate(), o);
/* 484:    */     }
/* 485:    */     
/* 486:    */     public boolean removeAll(Collection<?> c)
/* 487:    */     {
/* 488:612 */       return standardRemoveAll(c);
/* 489:    */     }
/* 490:    */     
/* 491:    */     public boolean retainAll(Collection<?> c)
/* 492:    */     {
/* 493:615 */       return standardRetainAll(c);
/* 494:    */     }
/* 495:    */   }
/* 496:    */   
/* 497:    */   static class ConstrainedEntrySet<K, V>
/* 498:    */     extends MapConstraints.ConstrainedEntries<K, V>
/* 499:    */     implements Set<Map.Entry<K, V>>
/* 500:    */   {
/* 501:    */     ConstrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 502:    */     {
/* 503:624 */       super(constraint);
/* 504:    */     }
/* 505:    */     
/* 506:    */     public boolean equals(@Nullable Object object)
/* 507:    */     {
/* 508:630 */       return Sets.equalsImpl(this, object);
/* 509:    */     }
/* 510:    */     
/* 511:    */     public int hashCode()
/* 512:    */     {
/* 513:634 */       return Sets.hashCodeImpl(this);
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   static class ConstrainedAsMapEntries<K, V>
/* 518:    */     extends ForwardingSet<Map.Entry<K, Collection<V>>>
/* 519:    */   {
/* 520:    */     private final MapConstraint<? super K, ? super V> constraint;
/* 521:    */     private final Set<Map.Entry<K, Collection<V>>> entries;
/* 522:    */     
/* 523:    */     ConstrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/* 524:    */     {
/* 525:646 */       this.entries = entries;
/* 526:647 */       this.constraint = constraint;
/* 527:    */     }
/* 528:    */     
/* 529:    */     protected Set<Map.Entry<K, Collection<V>>> delegate()
/* 530:    */     {
/* 531:651 */       return this.entries;
/* 532:    */     }
/* 533:    */     
/* 534:    */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/* 535:    */     {
/* 536:655 */       final Iterator<Map.Entry<K, Collection<V>>> iterator = this.entries.iterator();
/* 537:656 */       new ForwardingIterator()
/* 538:    */       {
/* 539:    */         public Map.Entry<K, Collection<V>> next()
/* 540:    */         {
/* 541:658 */           return MapConstraints.constrainedAsMapEntry((Map.Entry)iterator.next(), MapConstraints.ConstrainedAsMapEntries.this.constraint);
/* 542:    */         }
/* 543:    */         
/* 544:    */         protected Iterator<Map.Entry<K, Collection<V>>> delegate()
/* 545:    */         {
/* 546:661 */           return iterator;
/* 547:    */         }
/* 548:    */       };
/* 549:    */     }
/* 550:    */     
/* 551:    */     public Object[] toArray()
/* 552:    */     {
/* 553:669 */       return standardToArray();
/* 554:    */     }
/* 555:    */     
/* 556:    */     public <T> T[] toArray(T[] array)
/* 557:    */     {
/* 558:673 */       return standardToArray(array);
/* 559:    */     }
/* 560:    */     
/* 561:    */     public boolean contains(Object o)
/* 562:    */     {
/* 563:677 */       return Maps.containsEntryImpl(delegate(), o);
/* 564:    */     }
/* 565:    */     
/* 566:    */     public boolean containsAll(Collection<?> c)
/* 567:    */     {
/* 568:681 */       return standardContainsAll(c);
/* 569:    */     }
/* 570:    */     
/* 571:    */     public boolean equals(@Nullable Object object)
/* 572:    */     {
/* 573:685 */       return standardEquals(object);
/* 574:    */     }
/* 575:    */     
/* 576:    */     public int hashCode()
/* 577:    */     {
/* 578:689 */       return standardHashCode();
/* 579:    */     }
/* 580:    */     
/* 581:    */     public boolean remove(Object o)
/* 582:    */     {
/* 583:693 */       return Maps.removeEntryImpl(delegate(), o);
/* 584:    */     }
/* 585:    */     
/* 586:    */     public boolean removeAll(Collection<?> c)
/* 587:    */     {
/* 588:697 */       return standardRemoveAll(c);
/* 589:    */     }
/* 590:    */     
/* 591:    */     public boolean retainAll(Collection<?> c)
/* 592:    */     {
/* 593:701 */       return standardRetainAll(c);
/* 594:    */     }
/* 595:    */   }
/* 596:    */   
/* 597:    */   private static class ConstrainedListMultimap<K, V>
/* 598:    */     extends MapConstraints.ConstrainedMultimap<K, V>
/* 599:    */     implements ListMultimap<K, V>
/* 600:    */   {
/* 601:    */     ConstrainedListMultimap(ListMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 602:    */     {
/* 603:709 */       super(constraint);
/* 604:    */     }
/* 605:    */     
/* 606:    */     public List<V> get(K key)
/* 607:    */     {
/* 608:712 */       return (List)super.get(key);
/* 609:    */     }
/* 610:    */     
/* 611:    */     public List<V> removeAll(Object key)
/* 612:    */     {
/* 613:715 */       return (List)super.removeAll(key);
/* 614:    */     }
/* 615:    */     
/* 616:    */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/* 617:    */     {
/* 618:719 */       return (List)super.replaceValues(key, values);
/* 619:    */     }
/* 620:    */   }
/* 621:    */   
/* 622:    */   private static class ConstrainedSetMultimap<K, V>
/* 623:    */     extends MapConstraints.ConstrainedMultimap<K, V>
/* 624:    */     implements SetMultimap<K, V>
/* 625:    */   {
/* 626:    */     ConstrainedSetMultimap(SetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 627:    */     {
/* 628:727 */       super(constraint);
/* 629:    */     }
/* 630:    */     
/* 631:    */     public Set<V> get(K key)
/* 632:    */     {
/* 633:730 */       return (Set)super.get(key);
/* 634:    */     }
/* 635:    */     
/* 636:    */     public Set<Map.Entry<K, V>> entries()
/* 637:    */     {
/* 638:733 */       return (Set)super.entries();
/* 639:    */     }
/* 640:    */     
/* 641:    */     public Set<V> removeAll(Object key)
/* 642:    */     {
/* 643:736 */       return (Set)super.removeAll(key);
/* 644:    */     }
/* 645:    */     
/* 646:    */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/* 647:    */     {
/* 648:740 */       return (Set)super.replaceValues(key, values);
/* 649:    */     }
/* 650:    */   }
/* 651:    */   
/* 652:    */   private static class ConstrainedSortedSetMultimap<K, V>
/* 653:    */     extends MapConstraints.ConstrainedSetMultimap<K, V>
/* 654:    */     implements SortedSetMultimap<K, V>
/* 655:    */   {
/* 656:    */     ConstrainedSortedSetMultimap(SortedSetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 657:    */     {
/* 658:748 */       super(constraint);
/* 659:    */     }
/* 660:    */     
/* 661:    */     public SortedSet<V> get(K key)
/* 662:    */     {
/* 663:751 */       return (SortedSet)super.get(key);
/* 664:    */     }
/* 665:    */     
/* 666:    */     public SortedSet<V> removeAll(Object key)
/* 667:    */     {
/* 668:754 */       return (SortedSet)super.removeAll(key);
/* 669:    */     }
/* 670:    */     
/* 671:    */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/* 672:    */     {
/* 673:758 */       return (SortedSet)super.replaceValues(key, values);
/* 674:    */     }
/* 675:    */     
/* 676:    */     public Comparator<? super V> valueComparator()
/* 677:    */     {
/* 678:762 */       return ((SortedSetMultimap)delegate()).valueComparator();
/* 679:    */     }
/* 680:    */   }
/* 681:    */   
/* 682:    */   private static <K, V> Collection<V> checkValues(K key, Iterable<? extends V> values, MapConstraint<? super K, ? super V> constraint)
/* 683:    */   {
/* 684:769 */     Collection<V> copy = Lists.newArrayList(values);
/* 685:770 */     for (V value : copy) {
/* 686:771 */       constraint.checkKeyValue(key, value);
/* 687:    */     }
/* 688:773 */     return copy;
/* 689:    */   }
/* 690:    */   
/* 691:    */   private static <K, V> Map<K, V> checkMap(Map<? extends K, ? extends V> map, MapConstraint<? super K, ? super V> constraint)
/* 692:    */   {
/* 693:778 */     Map<K, V> copy = new LinkedHashMap(map);
/* 694:779 */     for (Map.Entry<K, V> entry : copy.entrySet()) {
/* 695:780 */       constraint.checkKeyValue(entry.getKey(), entry.getValue());
/* 696:    */     }
/* 697:782 */     return copy;
/* 698:    */   }
/* 699:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MapConstraints
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Map.Entry;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(emulated=true)
/* 10:   */ abstract class ImmutableMapEntrySet<K, V>
/* 11:   */   extends ImmutableSet<Map.Entry<K, V>>
/* 12:   */ {
/* 13:   */   abstract ImmutableMap<K, V> map();
/* 14:   */   
/* 15:   */   public int size()
/* 16:   */   {
/* 17:41 */     return map().size();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean contains(@Nullable Object object)
/* 21:   */   {
/* 22:46 */     if ((object instanceof Map.Entry))
/* 23:   */     {
/* 24:47 */       Map.Entry<?, ?> entry = (Map.Entry)object;
/* 25:48 */       V value = map().get(entry.getKey());
/* 26:49 */       return (value != null) && (value.equals(entry.getValue()));
/* 27:   */     }
/* 28:51 */     return false;
/* 29:   */   }
/* 30:   */   
/* 31:   */   boolean isPartialView()
/* 32:   */   {
/* 33:56 */     return map().isPartialView();
/* 34:   */   }
/* 35:   */   
/* 36:   */   @GwtIncompatible("serialization")
/* 37:   */   Object writeReplace()
/* 38:   */   {
/* 39:62 */     return new EntrySetSerializedForm(map());
/* 40:   */   }
/* 41:   */   
/* 42:   */   @GwtIncompatible("serialization")
/* 43:   */   private static class EntrySetSerializedForm<K, V>
/* 44:   */     implements Serializable
/* 45:   */   {
/* 46:   */     final ImmutableMap<K, V> map;
/* 47:   */     private static final long serialVersionUID = 0L;
/* 48:   */     
/* 49:   */     EntrySetSerializedForm(ImmutableMap<K, V> map)
/* 50:   */     {
/* 51:69 */       this.map = map;
/* 52:   */     }
/* 53:   */     
/* 54:   */     Object readResolve()
/* 55:   */     {
/* 56:72 */       return this.map.entrySet();
/* 57:   */     }
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapEntrySet
 * JD-Core Version:    0.7.0.1
 */
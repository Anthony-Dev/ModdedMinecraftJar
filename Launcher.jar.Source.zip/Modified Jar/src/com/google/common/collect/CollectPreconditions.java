/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ final class CollectPreconditions
/*  8:   */ {
/*  9:   */   static void checkEntryNotNull(Object key, Object value)
/* 10:   */   {
/* 11:30 */     if (key == null) {
/* 12:31 */       throw new NullPointerException("null key in entry: null=" + value);
/* 13:   */     }
/* 14:32 */     if (value == null) {
/* 15:33 */       throw new NullPointerException("null value in entry: " + key + "=null");
/* 16:   */     }
/* 17:   */   }
/* 18:   */   
/* 19:   */   static int checkNonnegative(int value, String name)
/* 20:   */   {
/* 21:38 */     if (value < 0) {
/* 22:39 */       throw new IllegalArgumentException(name + " cannot be negative but was: " + value);
/* 23:   */     }
/* 24:41 */     return value;
/* 25:   */   }
/* 26:   */   
/* 27:   */   static void checkRemove(boolean canRemove)
/* 28:   */   {
/* 29:49 */     Preconditions.checkState(canRemove, "no calls to next() since the last call to remove()");
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.CollectPreconditions
 * JD-Core Version:    0.7.0.1
 */
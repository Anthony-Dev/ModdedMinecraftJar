/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ public abstract class ForwardingMultiset<E>
/*  13:    */   extends ForwardingCollection<E>
/*  14:    */   implements Multiset<E>
/*  15:    */ {
/*  16:    */   protected abstract Multiset<E> delegate();
/*  17:    */   
/*  18:    */   public int count(Object element)
/*  19:    */   {
/*  20: 62 */     return delegate().count(element);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public int add(E element, int occurrences)
/*  24:    */   {
/*  25: 67 */     return delegate().add(element, occurrences);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public int remove(Object element, int occurrences)
/*  29:    */   {
/*  30: 72 */     return delegate().remove(element, occurrences);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public Set<E> elementSet()
/*  34:    */   {
/*  35: 77 */     return delegate().elementSet();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Set<Multiset.Entry<E>> entrySet()
/*  39:    */   {
/*  40: 82 */     return delegate().entrySet();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean equals(@Nullable Object object)
/*  44:    */   {
/*  45: 86 */     return (object == this) || (delegate().equals(object));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public int hashCode()
/*  49:    */   {
/*  50: 90 */     return delegate().hashCode();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int setCount(E element, int count)
/*  54:    */   {
/*  55: 95 */     return delegate().setCount(element, count);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean setCount(E element, int oldCount, int newCount)
/*  59:    */   {
/*  60:100 */     return delegate().setCount(element, oldCount, newCount);
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected boolean standardContains(@Nullable Object object)
/*  64:    */   {
/*  65:111 */     return count(object) > 0;
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected void standardClear()
/*  69:    */   {
/*  70:122 */     Iterators.clear(entrySet().iterator());
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Beta
/*  74:    */   protected int standardCount(@Nullable Object object)
/*  75:    */   {
/*  76:133 */     for (Multiset.Entry<?> entry : entrySet()) {
/*  77:134 */       if (Objects.equal(entry.getElement(), object)) {
/*  78:135 */         return entry.getCount();
/*  79:    */       }
/*  80:    */     }
/*  81:138 */     return 0;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected boolean standardAdd(E element)
/*  85:    */   {
/*  86:149 */     add(element, 1);
/*  87:150 */     return true;
/*  88:    */   }
/*  89:    */   
/*  90:    */   @Beta
/*  91:    */   protected boolean standardAddAll(Collection<? extends E> elementsToAdd)
/*  92:    */   {
/*  93:163 */     return Multisets.addAllImpl(this, elementsToAdd);
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected boolean standardRemove(Object element)
/*  97:    */   {
/*  98:175 */     return remove(element, 1) > 0;
/*  99:    */   }
/* 100:    */   
/* 101:    */   protected boolean standardRemoveAll(Collection<?> elementsToRemove)
/* 102:    */   {
/* 103:188 */     return Multisets.removeAllImpl(this, elementsToRemove);
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected boolean standardRetainAll(Collection<?> elementsToRetain)
/* 107:    */   {
/* 108:201 */     return Multisets.retainAllImpl(this, elementsToRetain);
/* 109:    */   }
/* 110:    */   
/* 111:    */   protected int standardSetCount(E element, int count)
/* 112:    */   {
/* 113:214 */     return Multisets.setCountImpl(this, element, count);
/* 114:    */   }
/* 115:    */   
/* 116:    */   protected boolean standardSetCount(E element, int oldCount, int newCount)
/* 117:    */   {
/* 118:226 */     return Multisets.setCountImpl(this, element, oldCount, newCount);
/* 119:    */   }
/* 120:    */   
/* 121:    */   @Beta
/* 122:    */   protected class StandardElementSet
/* 123:    */     extends Multisets.ElementSet<E>
/* 124:    */   {
/* 125:    */     public StandardElementSet() {}
/* 126:    */     
/* 127:    */     Multiset<E> multiset()
/* 128:    */     {
/* 129:249 */       return ForwardingMultiset.this;
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   protected Iterator<E> standardIterator()
/* 134:    */   {
/* 135:261 */     return Multisets.iteratorImpl(this);
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected int standardSize()
/* 139:    */   {
/* 140:272 */     return Multisets.sizeImpl(this);
/* 141:    */   }
/* 142:    */   
/* 143:    */   protected boolean standardEquals(@Nullable Object object)
/* 144:    */   {
/* 145:284 */     return Multisets.equalsImpl(this, object);
/* 146:    */   }
/* 147:    */   
/* 148:    */   protected int standardHashCode()
/* 149:    */   {
/* 150:295 */     return entrySet().hashCode();
/* 151:    */   }
/* 152:    */   
/* 153:    */   protected String standardToString()
/* 154:    */   {
/* 155:306 */     return entrySet().toString();
/* 156:    */   }
/* 157:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingMultiset
 * JD-Core Version:    0.7.0.1
 */
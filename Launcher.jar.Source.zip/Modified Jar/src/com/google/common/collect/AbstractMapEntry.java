/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Objects;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ abstract class AbstractMapEntry<K, V>
/* 10:   */   implements Map.Entry<K, V>
/* 11:   */ {
/* 12:   */   public abstract K getKey();
/* 13:   */   
/* 14:   */   public abstract V getValue();
/* 15:   */   
/* 16:   */   public V setValue(V value)
/* 17:   */   {
/* 18:43 */     throw new UnsupportedOperationException();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean equals(@Nullable Object object)
/* 22:   */   {
/* 23:47 */     if ((object instanceof Map.Entry))
/* 24:   */     {
/* 25:48 */       Map.Entry<?, ?> that = (Map.Entry)object;
/* 26:49 */       return (Objects.equal(getKey(), that.getKey())) && (Objects.equal(getValue(), that.getValue()));
/* 27:   */     }
/* 28:52 */     return false;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int hashCode()
/* 32:   */   {
/* 33:56 */     K k = getKey();
/* 34:57 */     V v = getValue();
/* 35:58 */     return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String toString()
/* 39:   */   {
/* 40:65 */     return getKey() + "=" + getValue();
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractMapEntry
 * JD-Core Version:    0.7.0.1
 */
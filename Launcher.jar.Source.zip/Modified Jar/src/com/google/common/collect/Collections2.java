/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Joiner;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicate;
/*   9:    */ import com.google.common.base.Predicates;
/*  10:    */ import com.google.common.math.IntMath;
/*  11:    */ import com.google.common.math.LongMath;
/*  12:    */ import java.util.AbstractCollection;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Arrays;
/*  15:    */ import java.util.Collection;
/*  16:    */ import java.util.Collections;
/*  17:    */ import java.util.Comparator;
/*  18:    */ import java.util.Iterator;
/*  19:    */ import java.util.List;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ @GwtCompatible
/*  23:    */ public final class Collections2
/*  24:    */ {
/*  25:    */   public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate)
/*  26:    */   {
/*  27: 91 */     if ((unfiltered instanceof FilteredCollection)) {
/*  28: 94 */       return ((FilteredCollection)unfiltered).createCombined(predicate);
/*  29:    */     }
/*  30: 97 */     return new FilteredCollection((Collection)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  31:    */   }
/*  32:    */   
/*  33:    */   static boolean safeContains(Collection<?> collection, @Nullable Object object)
/*  34:    */   {
/*  35:108 */     Preconditions.checkNotNull(collection);
/*  36:    */     try
/*  37:    */     {
/*  38:110 */       return collection.contains(object);
/*  39:    */     }
/*  40:    */     catch (ClassCastException e)
/*  41:    */     {
/*  42:112 */       return false;
/*  43:    */     }
/*  44:    */     catch (NullPointerException e) {}
/*  45:114 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   static boolean safeRemove(Collection<?> collection, @Nullable Object object)
/*  49:    */   {
/*  50:124 */     Preconditions.checkNotNull(collection);
/*  51:    */     try
/*  52:    */     {
/*  53:126 */       return collection.remove(object);
/*  54:    */     }
/*  55:    */     catch (ClassCastException e)
/*  56:    */     {
/*  57:128 */       return false;
/*  58:    */     }
/*  59:    */     catch (NullPointerException e) {}
/*  60:130 */     return false;
/*  61:    */   }
/*  62:    */   
/*  63:    */   static class FilteredCollection<E>
/*  64:    */     extends AbstractCollection<E>
/*  65:    */   {
/*  66:    */     final Collection<E> unfiltered;
/*  67:    */     final Predicate<? super E> predicate;
/*  68:    */     
/*  69:    */     FilteredCollection(Collection<E> unfiltered, Predicate<? super E> predicate)
/*  70:    */     {
/*  71:140 */       this.unfiltered = unfiltered;
/*  72:141 */       this.predicate = predicate;
/*  73:    */     }
/*  74:    */     
/*  75:    */     FilteredCollection<E> createCombined(Predicate<? super E> newPredicate)
/*  76:    */     {
/*  77:145 */       return new FilteredCollection(this.unfiltered, Predicates.and(this.predicate, newPredicate));
/*  78:    */     }
/*  79:    */     
/*  80:    */     public boolean add(E element)
/*  81:    */     {
/*  82:152 */       Preconditions.checkArgument(this.predicate.apply(element));
/*  83:153 */       return this.unfiltered.add(element);
/*  84:    */     }
/*  85:    */     
/*  86:    */     public boolean addAll(Collection<? extends E> collection)
/*  87:    */     {
/*  88:158 */       for (E element : collection) {
/*  89:159 */         Preconditions.checkArgument(this.predicate.apply(element));
/*  90:    */       }
/*  91:161 */       return this.unfiltered.addAll(collection);
/*  92:    */     }
/*  93:    */     
/*  94:    */     public void clear()
/*  95:    */     {
/*  96:166 */       Iterables.removeIf(this.unfiltered, this.predicate);
/*  97:    */     }
/*  98:    */     
/*  99:    */     public boolean contains(@Nullable Object element)
/* 100:    */     {
/* 101:171 */       if (Collections2.safeContains(this.unfiltered, element))
/* 102:    */       {
/* 103:173 */         E e = element;
/* 104:174 */         return this.predicate.apply(e);
/* 105:    */       }
/* 106:176 */       return false;
/* 107:    */     }
/* 108:    */     
/* 109:    */     public boolean containsAll(Collection<?> collection)
/* 110:    */     {
/* 111:181 */       return Collections2.containsAllImpl(this, collection);
/* 112:    */     }
/* 113:    */     
/* 114:    */     public boolean isEmpty()
/* 115:    */     {
/* 116:186 */       return !Iterables.any(this.unfiltered, this.predicate);
/* 117:    */     }
/* 118:    */     
/* 119:    */     public Iterator<E> iterator()
/* 120:    */     {
/* 121:191 */       return Iterators.filter(this.unfiltered.iterator(), this.predicate);
/* 122:    */     }
/* 123:    */     
/* 124:    */     public boolean remove(Object element)
/* 125:    */     {
/* 126:196 */       return (contains(element)) && (this.unfiltered.remove(element));
/* 127:    */     }
/* 128:    */     
/* 129:    */     public boolean removeAll(Collection<?> collection)
/* 130:    */     {
/* 131:201 */       return Iterables.removeIf(this.unfiltered, Predicates.and(this.predicate, Predicates.in(collection)));
/* 132:    */     }
/* 133:    */     
/* 134:    */     public boolean retainAll(Collection<?> collection)
/* 135:    */     {
/* 136:206 */       return Iterables.removeIf(this.unfiltered, Predicates.and(this.predicate, Predicates.not(Predicates.in(collection))));
/* 137:    */     }
/* 138:    */     
/* 139:    */     public int size()
/* 140:    */     {
/* 141:211 */       return Iterators.size(iterator());
/* 142:    */     }
/* 143:    */     
/* 144:    */     public Object[] toArray()
/* 145:    */     {
/* 146:217 */       return Lists.newArrayList(iterator()).toArray();
/* 147:    */     }
/* 148:    */     
/* 149:    */     public <T> T[] toArray(T[] array)
/* 150:    */     {
/* 151:222 */       return Lists.newArrayList(iterator()).toArray(array);
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function)
/* 156:    */   {
/* 157:247 */     return new TransformedCollection(fromCollection, function);
/* 158:    */   }
/* 159:    */   
/* 160:    */   static class TransformedCollection<F, T>
/* 161:    */     extends AbstractCollection<T>
/* 162:    */   {
/* 163:    */     final Collection<F> fromCollection;
/* 164:    */     final Function<? super F, ? extends T> function;
/* 165:    */     
/* 166:    */     TransformedCollection(Collection<F> fromCollection, Function<? super F, ? extends T> function)
/* 167:    */     {
/* 168:256 */       this.fromCollection = ((Collection)Preconditions.checkNotNull(fromCollection));
/* 169:257 */       this.function = ((Function)Preconditions.checkNotNull(function));
/* 170:    */     }
/* 171:    */     
/* 172:    */     public void clear()
/* 173:    */     {
/* 174:261 */       this.fromCollection.clear();
/* 175:    */     }
/* 176:    */     
/* 177:    */     public boolean isEmpty()
/* 178:    */     {
/* 179:265 */       return this.fromCollection.isEmpty();
/* 180:    */     }
/* 181:    */     
/* 182:    */     public Iterator<T> iterator()
/* 183:    */     {
/* 184:269 */       return Iterators.transform(this.fromCollection.iterator(), this.function);
/* 185:    */     }
/* 186:    */     
/* 187:    */     public int size()
/* 188:    */     {
/* 189:273 */       return this.fromCollection.size();
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   static boolean containsAllImpl(Collection<?> self, Collection<?> c)
/* 194:    */   {
/* 195:290 */     return Iterables.all(c, Predicates.in(self));
/* 196:    */   }
/* 197:    */   
/* 198:    */   static String toStringImpl(Collection<?> collection)
/* 199:    */   {
/* 200:297 */     StringBuilder sb = newStringBuilderForCollection(collection.size()).append('[');
/* 201:    */     
/* 202:299 */     STANDARD_JOINER.appendTo(sb, Iterables.transform(collection, new Function()
/* 203:    */     {
/* 204:    */       public Object apply(Object input)
/* 205:    */       {
/* 206:302 */         return input == this.val$collection ? "(this Collection)" : input;
/* 207:    */       }
/* 208:304 */     }));
/* 209:305 */     return ']';
/* 210:    */   }
/* 211:    */   
/* 212:    */   static StringBuilder newStringBuilderForCollection(int size)
/* 213:    */   {
/* 214:312 */     CollectPreconditions.checkNonnegative(size, "size");
/* 215:313 */     return new StringBuilder((int)Math.min(size * 8L, 1073741824L));
/* 216:    */   }
/* 217:    */   
/* 218:    */   static <T> Collection<T> cast(Iterable<T> iterable)
/* 219:    */   {
/* 220:320 */     return (Collection)iterable;
/* 221:    */   }
/* 222:    */   
/* 223:323 */   static final Joiner STANDARD_JOINER = Joiner.on(", ").useForNull("null");
/* 224:    */   
/* 225:    */   @Beta
/* 226:    */   public static <E extends Comparable<? super E>> Collection<List<E>> orderedPermutations(Iterable<E> elements)
/* 227:    */   {
/* 228:354 */     return orderedPermutations(elements, Ordering.natural());
/* 229:    */   }
/* 230:    */   
/* 231:    */   @Beta
/* 232:    */   public static <E> Collection<List<E>> orderedPermutations(Iterable<E> elements, Comparator<? super E> comparator)
/* 233:    */   {
/* 234:406 */     return new OrderedPermutationCollection(elements, comparator);
/* 235:    */   }
/* 236:    */   
/* 237:    */   private static final class OrderedPermutationCollection<E>
/* 238:    */     extends AbstractCollection<List<E>>
/* 239:    */   {
/* 240:    */     final ImmutableList<E> inputList;
/* 241:    */     final Comparator<? super E> comparator;
/* 242:    */     final int size;
/* 243:    */     
/* 244:    */     OrderedPermutationCollection(Iterable<E> input, Comparator<? super E> comparator)
/* 245:    */     {
/* 246:417 */       this.inputList = Ordering.from(comparator).immutableSortedCopy(input);
/* 247:418 */       this.comparator = comparator;
/* 248:419 */       this.size = calculateSize(this.inputList, comparator);
/* 249:    */     }
/* 250:    */     
/* 251:    */     private static <E> int calculateSize(List<E> sortedInputList, Comparator<? super E> comparator)
/* 252:    */     {
/* 253:433 */       long permutations = 1L;
/* 254:434 */       int n = 1;
/* 255:435 */       int r = 1;
/* 256:436 */       while (n < sortedInputList.size())
/* 257:    */       {
/* 258:437 */         int comparison = comparator.compare(sortedInputList.get(n - 1), sortedInputList.get(n));
/* 259:439 */         if (comparison < 0)
/* 260:    */         {
/* 261:441 */           permutations *= LongMath.binomial(n, r);
/* 262:442 */           r = 0;
/* 263:443 */           if (!Collections2.isPositiveInt(permutations)) {
/* 264:444 */             return 2147483647;
/* 265:    */           }
/* 266:    */         }
/* 267:447 */         n++;
/* 268:448 */         r++;
/* 269:    */       }
/* 270:450 */       permutations *= LongMath.binomial(n, r);
/* 271:451 */       if (!Collections2.isPositiveInt(permutations)) {
/* 272:452 */         return 2147483647;
/* 273:    */       }
/* 274:454 */       return (int)permutations;
/* 275:    */     }
/* 276:    */     
/* 277:    */     public int size()
/* 278:    */     {
/* 279:458 */       return this.size;
/* 280:    */     }
/* 281:    */     
/* 282:    */     public boolean isEmpty()
/* 283:    */     {
/* 284:462 */       return false;
/* 285:    */     }
/* 286:    */     
/* 287:    */     public Iterator<List<E>> iterator()
/* 288:    */     {
/* 289:466 */       return new Collections2.OrderedPermutationIterator(this.inputList, this.comparator);
/* 290:    */     }
/* 291:    */     
/* 292:    */     public boolean contains(@Nullable Object obj)
/* 293:    */     {
/* 294:470 */       if ((obj instanceof List))
/* 295:    */       {
/* 296:471 */         List<?> list = (List)obj;
/* 297:472 */         return Collections2.isPermutation(this.inputList, list);
/* 298:    */       }
/* 299:474 */       return false;
/* 300:    */     }
/* 301:    */     
/* 302:    */     public String toString()
/* 303:    */     {
/* 304:478 */       return "orderedPermutationCollection(" + this.inputList + ")";
/* 305:    */     }
/* 306:    */   }
/* 307:    */   
/* 308:    */   private static final class OrderedPermutationIterator<E>
/* 309:    */     extends AbstractIterator<List<E>>
/* 310:    */   {
/* 311:    */     List<E> nextPermutation;
/* 312:    */     final Comparator<? super E> comparator;
/* 313:    */     
/* 314:    */     OrderedPermutationIterator(List<E> list, Comparator<? super E> comparator)
/* 315:    */     {
/* 316:490 */       this.nextPermutation = Lists.newArrayList(list);
/* 317:491 */       this.comparator = comparator;
/* 318:    */     }
/* 319:    */     
/* 320:    */     protected List<E> computeNext()
/* 321:    */     {
/* 322:495 */       if (this.nextPermutation == null) {
/* 323:496 */         return (List)endOfData();
/* 324:    */       }
/* 325:498 */       ImmutableList<E> next = ImmutableList.copyOf(this.nextPermutation);
/* 326:499 */       calculateNextPermutation();
/* 327:500 */       return next;
/* 328:    */     }
/* 329:    */     
/* 330:    */     void calculateNextPermutation()
/* 331:    */     {
/* 332:504 */       int j = findNextJ();
/* 333:505 */       if (j == -1)
/* 334:    */       {
/* 335:506 */         this.nextPermutation = null;
/* 336:507 */         return;
/* 337:    */       }
/* 338:510 */       int l = findNextL(j);
/* 339:511 */       Collections.swap(this.nextPermutation, j, l);
/* 340:512 */       int n = this.nextPermutation.size();
/* 341:513 */       Collections.reverse(this.nextPermutation.subList(j + 1, n));
/* 342:    */     }
/* 343:    */     
/* 344:    */     int findNextJ()
/* 345:    */     {
/* 346:517 */       for (int k = this.nextPermutation.size() - 2; k >= 0; k--) {
/* 347:518 */         if (this.comparator.compare(this.nextPermutation.get(k), this.nextPermutation.get(k + 1)) < 0) {
/* 348:520 */           return k;
/* 349:    */         }
/* 350:    */       }
/* 351:523 */       return -1;
/* 352:    */     }
/* 353:    */     
/* 354:    */     int findNextL(int j)
/* 355:    */     {
/* 356:527 */       E ak = this.nextPermutation.get(j);
/* 357:528 */       for (int l = this.nextPermutation.size() - 1; l > j; l--) {
/* 358:529 */         if (this.comparator.compare(ak, this.nextPermutation.get(l)) < 0) {
/* 359:530 */           return l;
/* 360:    */         }
/* 361:    */       }
/* 362:533 */       throw new AssertionError("this statement should be unreachable");
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   @Beta
/* 367:    */   public static <E> Collection<List<E>> permutations(Collection<E> elements)
/* 368:    */   {
/* 369:559 */     return new PermutationCollection(ImmutableList.copyOf(elements));
/* 370:    */   }
/* 371:    */   
/* 372:    */   private static final class PermutationCollection<E>
/* 373:    */     extends AbstractCollection<List<E>>
/* 374:    */   {
/* 375:    */     final ImmutableList<E> inputList;
/* 376:    */     
/* 377:    */     PermutationCollection(ImmutableList<E> input)
/* 378:    */     {
/* 379:567 */       this.inputList = input;
/* 380:    */     }
/* 381:    */     
/* 382:    */     public int size()
/* 383:    */     {
/* 384:571 */       return IntMath.factorial(this.inputList.size());
/* 385:    */     }
/* 386:    */     
/* 387:    */     public boolean isEmpty()
/* 388:    */     {
/* 389:575 */       return false;
/* 390:    */     }
/* 391:    */     
/* 392:    */     public Iterator<List<E>> iterator()
/* 393:    */     {
/* 394:579 */       return new Collections2.PermutationIterator(this.inputList);
/* 395:    */     }
/* 396:    */     
/* 397:    */     public boolean contains(@Nullable Object obj)
/* 398:    */     {
/* 399:583 */       if ((obj instanceof List))
/* 400:    */       {
/* 401:584 */         List<?> list = (List)obj;
/* 402:585 */         return Collections2.isPermutation(this.inputList, list);
/* 403:    */       }
/* 404:587 */       return false;
/* 405:    */     }
/* 406:    */     
/* 407:    */     public String toString()
/* 408:    */     {
/* 409:591 */       return "permutations(" + this.inputList + ")";
/* 410:    */     }
/* 411:    */   }
/* 412:    */   
/* 413:    */   private static class PermutationIterator<E>
/* 414:    */     extends AbstractIterator<List<E>>
/* 415:    */   {
/* 416:    */     final List<E> list;
/* 417:    */     final int[] c;
/* 418:    */     final int[] o;
/* 419:    */     int j;
/* 420:    */     
/* 421:    */     PermutationIterator(List<E> list)
/* 422:    */     {
/* 423:603 */       this.list = new ArrayList(list);
/* 424:604 */       int n = list.size();
/* 425:605 */       this.c = new int[n];
/* 426:606 */       this.o = new int[n];
/* 427:607 */       Arrays.fill(this.c, 0);
/* 428:608 */       Arrays.fill(this.o, 1);
/* 429:609 */       this.j = 2147483647;
/* 430:    */     }
/* 431:    */     
/* 432:    */     protected List<E> computeNext()
/* 433:    */     {
/* 434:613 */       if (this.j <= 0) {
/* 435:614 */         return (List)endOfData();
/* 436:    */       }
/* 437:616 */       ImmutableList<E> next = ImmutableList.copyOf(this.list);
/* 438:617 */       calculateNextPermutation();
/* 439:618 */       return next;
/* 440:    */     }
/* 441:    */     
/* 442:    */     void calculateNextPermutation()
/* 443:    */     {
/* 444:622 */       this.j = (this.list.size() - 1);
/* 445:623 */       int s = 0;
/* 446:627 */       if (this.j == -1) {
/* 447:    */         return;
/* 448:    */       }
/* 449:    */       int q;
/* 450:    */       for (;;)
/* 451:    */       {
/* 452:632 */         q = this.c[this.j] + this.o[this.j];
/* 453:633 */         if (q < 0)
/* 454:    */         {
/* 455:634 */           switchDirection();
/* 456:    */         }
/* 457:    */         else
/* 458:    */         {
/* 459:637 */           if (q != this.j + 1) {
/* 460:    */             break;
/* 461:    */           }
/* 462:638 */           if (this.j == 0) {
/* 463:    */             return;
/* 464:    */           }
/* 465:641 */           s++;
/* 466:642 */           switchDirection();
/* 467:    */         }
/* 468:    */       }
/* 469:646 */       Collections.swap(this.list, this.j - this.c[this.j] + s, this.j - q + s);
/* 470:647 */       this.c[this.j] = q;
/* 471:    */     }
/* 472:    */     
/* 473:    */     void switchDirection()
/* 474:    */     {
/* 475:653 */       this.o[this.j] = (-this.o[this.j]);
/* 476:654 */       this.j -= 1;
/* 477:    */     }
/* 478:    */   }
/* 479:    */   
/* 480:    */   private static boolean isPermutation(List<?> first, List<?> second)
/* 481:    */   {
/* 482:663 */     if (first.size() != second.size()) {
/* 483:664 */       return false;
/* 484:    */     }
/* 485:666 */     Multiset<?> firstMultiset = HashMultiset.create(first);
/* 486:667 */     Multiset<?> secondMultiset = HashMultiset.create(second);
/* 487:668 */     return firstMultiset.equals(secondMultiset);
/* 488:    */   }
/* 489:    */   
/* 490:    */   private static boolean isPositiveInt(long n)
/* 491:    */   {
/* 492:672 */     return (n >= 0L) && (n <= 2147483647L);
/* 493:    */   }
/* 494:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Collections2
 * JD-Core Version:    0.7.0.1
 */
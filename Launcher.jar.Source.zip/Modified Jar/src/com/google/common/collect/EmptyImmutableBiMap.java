/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(emulated=true)
/*  8:   */ final class EmptyImmutableBiMap
/*  9:   */   extends ImmutableBiMap<Object, Object>
/* 10:   */ {
/* 11:31 */   static final EmptyImmutableBiMap INSTANCE = new EmptyImmutableBiMap();
/* 12:   */   
/* 13:   */   public ImmutableBiMap<Object, Object> inverse()
/* 14:   */   {
/* 15:36 */     return this;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int size()
/* 19:   */   {
/* 20:41 */     return 0;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean isEmpty()
/* 24:   */   {
/* 25:46 */     return true;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Object get(@Nullable Object key)
/* 29:   */   {
/* 30:51 */     return null;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ImmutableSet<Map.Entry<Object, Object>> entrySet()
/* 34:   */   {
/* 35:56 */     return ImmutableSet.of();
/* 36:   */   }
/* 37:   */   
/* 38:   */   ImmutableSet<Map.Entry<Object, Object>> createEntrySet()
/* 39:   */   {
/* 40:61 */     throw new AssertionError("should never be called");
/* 41:   */   }
/* 42:   */   
/* 43:   */   public ImmutableSetMultimap<Object, Object> asMultimap()
/* 44:   */   {
/* 45:66 */     return ImmutableSetMultimap.of();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public ImmutableSet<Object> keySet()
/* 49:   */   {
/* 50:71 */     return ImmutableSet.of();
/* 51:   */   }
/* 52:   */   
/* 53:   */   boolean isPartialView()
/* 54:   */   {
/* 55:76 */     return false;
/* 56:   */   }
/* 57:   */   
/* 58:   */   Object readResolve()
/* 59:   */   {
/* 60:80 */     return INSTANCE;
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */
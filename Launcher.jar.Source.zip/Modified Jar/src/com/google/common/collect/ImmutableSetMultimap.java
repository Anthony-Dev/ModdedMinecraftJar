/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.InvalidObjectException;
/*   9:    */ import java.io.ObjectInputStream;
/*  10:    */ import java.io.ObjectOutputStream;
/*  11:    */ import java.util.Arrays;
/*  12:    */ import java.util.Collection;
/*  13:    */ import java.util.Collections;
/*  14:    */ import java.util.Comparator;
/*  15:    */ import java.util.LinkedHashMap;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Map;
/*  18:    */ import java.util.Map.Entry;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @GwtCompatible(serializable=true, emulated=true)
/*  22:    */ public class ImmutableSetMultimap<K, V>
/*  23:    */   extends ImmutableMultimap<K, V>
/*  24:    */   implements SetMultimap<K, V>
/*  25:    */ {
/*  26:    */   private final transient ImmutableSet<V> emptySet;
/*  27:    */   private transient ImmutableSetMultimap<V, K> inverse;
/*  28:    */   private transient ImmutableSet<Map.Entry<K, V>> entries;
/*  29:    */   @GwtIncompatible("not needed in emulated source.")
/*  30:    */   private static final long serialVersionUID = 0L;
/*  31:    */   
/*  32:    */   public static <K, V> ImmutableSetMultimap<K, V> of()
/*  33:    */   {
/*  34: 73 */     return EmptyImmutableSetMultimap.INSTANCE;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1)
/*  38:    */   {
/*  39: 80 */     Builder<K, V> builder = builder();
/*  40: 81 */     builder.put(k1, v1);
/*  41: 82 */     return builder.build();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*  45:    */   {
/*  46: 91 */     Builder<K, V> builder = builder();
/*  47: 92 */     builder.put(k1, v1);
/*  48: 93 */     builder.put(k2, v2);
/*  49: 94 */     return builder.build();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  53:    */   {
/*  54:104 */     Builder<K, V> builder = builder();
/*  55:105 */     builder.put(k1, v1);
/*  56:106 */     builder.put(k2, v2);
/*  57:107 */     builder.put(k3, v3);
/*  58:108 */     return builder.build();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  62:    */   {
/*  63:118 */     Builder<K, V> builder = builder();
/*  64:119 */     builder.put(k1, v1);
/*  65:120 */     builder.put(k2, v2);
/*  66:121 */     builder.put(k3, v3);
/*  67:122 */     builder.put(k4, v4);
/*  68:123 */     return builder.build();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  72:    */   {
/*  73:133 */     Builder<K, V> builder = builder();
/*  74:134 */     builder.put(k1, v1);
/*  75:135 */     builder.put(k2, v2);
/*  76:136 */     builder.put(k3, v3);
/*  77:137 */     builder.put(k4, v4);
/*  78:138 */     builder.put(k5, v5);
/*  79:139 */     return builder.build();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static <K, V> Builder<K, V> builder()
/*  83:    */   {
/*  84:148 */     return new Builder();
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static class BuilderMultimap<K, V>
/*  88:    */     extends AbstractMapBasedMultimap<K, V>
/*  89:    */   {
/*  90:    */     private static final long serialVersionUID = 0L;
/*  91:    */     
/*  92:    */     BuilderMultimap()
/*  93:    */     {
/*  94:157 */       super();
/*  95:    */     }
/*  96:    */     
/*  97:    */     Collection<V> createCollection()
/*  98:    */     {
/*  99:160 */       return Sets.newLinkedHashSet();
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static final class Builder<K, V>
/* 104:    */     extends ImmutableMultimap.Builder<K, V>
/* 105:    */   {
/* 106:    */     public Builder()
/* 107:    */     {
/* 108:190 */       this.builderMultimap = new ImmutableSetMultimap.BuilderMultimap();
/* 109:    */     }
/* 110:    */     
/* 111:    */     public Builder<K, V> put(K key, V value)
/* 112:    */     {
/* 113:198 */       this.builderMultimap.put(Preconditions.checkNotNull(key), Preconditions.checkNotNull(value));
/* 114:199 */       return this;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/* 118:    */     {
/* 119:208 */       this.builderMultimap.put(Preconditions.checkNotNull(entry.getKey()), Preconditions.checkNotNull(entry.getValue()));
/* 120:    */       
/* 121:210 */       return this;
/* 122:    */     }
/* 123:    */     
/* 124:    */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/* 125:    */     {
/* 126:214 */       Collection<V> collection = this.builderMultimap.get(Preconditions.checkNotNull(key));
/* 127:215 */       for (V value : values) {
/* 128:216 */         collection.add(Preconditions.checkNotNull(value));
/* 129:    */       }
/* 130:218 */       return this;
/* 131:    */     }
/* 132:    */     
/* 133:    */     public Builder<K, V> putAll(K key, V... values)
/* 134:    */     {
/* 135:222 */       return putAll(key, Arrays.asList(values));
/* 136:    */     }
/* 137:    */     
/* 138:    */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/* 139:    */     {
/* 140:228 */       for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet()) {
/* 141:229 */         putAll(entry.getKey(), (Iterable)entry.getValue());
/* 142:    */       }
/* 143:231 */       return this;
/* 144:    */     }
/* 145:    */     
/* 146:    */     public Builder<K, V> orderKeysBy(Comparator<? super K> keyComparator)
/* 147:    */     {
/* 148:241 */       this.keyComparator = ((Comparator)Preconditions.checkNotNull(keyComparator));
/* 149:242 */       return this;
/* 150:    */     }
/* 151:    */     
/* 152:    */     public Builder<K, V> orderValuesBy(Comparator<? super V> valueComparator)
/* 153:    */     {
/* 154:259 */       super.orderValuesBy(valueComparator);
/* 155:260 */       return this;
/* 156:    */     }
/* 157:    */     
/* 158:    */     public ImmutableSetMultimap<K, V> build()
/* 159:    */     {
/* 160:267 */       if (this.keyComparator != null)
/* 161:    */       {
/* 162:268 */         Multimap<K, V> sortedCopy = new ImmutableSetMultimap.BuilderMultimap();
/* 163:269 */         List<Map.Entry<K, Collection<V>>> entries = Lists.newArrayList(this.builderMultimap.asMap().entrySet());
/* 164:    */         
/* 165:271 */         Collections.sort(entries, Ordering.from(this.keyComparator).onKeys());
/* 166:274 */         for (Map.Entry<K, Collection<V>> entry : entries) {
/* 167:275 */           sortedCopy.putAll(entry.getKey(), (Iterable)entry.getValue());
/* 168:    */         }
/* 169:277 */         this.builderMultimap = sortedCopy;
/* 170:    */       }
/* 171:279 */       return ImmutableSetMultimap.copyOf(this.builderMultimap, this.valueComparator);
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/* 176:    */   {
/* 177:299 */     return copyOf(multimap, null);
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap, Comparator<? super V> valueComparator)
/* 181:    */   {
/* 182:305 */     Preconditions.checkNotNull(multimap);
/* 183:306 */     if ((multimap.isEmpty()) && (valueComparator == null)) {
/* 184:307 */       return of();
/* 185:    */     }
/* 186:310 */     if ((multimap instanceof ImmutableSetMultimap))
/* 187:    */     {
/* 188:312 */       ImmutableSetMultimap<K, V> kvMultimap = (ImmutableSetMultimap)multimap;
/* 189:314 */       if (!kvMultimap.isPartialView()) {
/* 190:315 */         return kvMultimap;
/* 191:    */       }
/* 192:    */     }
/* 193:319 */     ImmutableMap.Builder<K, ImmutableSet<V>> builder = ImmutableMap.builder();
/* 194:320 */     int size = 0;
/* 195:323 */     for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet())
/* 196:    */     {
/* 197:324 */       K key = entry.getKey();
/* 198:325 */       Collection<? extends V> values = (Collection)entry.getValue();
/* 199:326 */       ImmutableSet<V> set = valueSet(valueComparator, values);
/* 200:327 */       if (!set.isEmpty())
/* 201:    */       {
/* 202:328 */         builder.put(key, set);
/* 203:329 */         size += set.size();
/* 204:    */       }
/* 205:    */     }
/* 206:333 */     return new ImmutableSetMultimap(builder.build(), size, valueComparator);
/* 207:    */   }
/* 208:    */   
/* 209:    */   ImmutableSetMultimap(ImmutableMap<K, ImmutableSet<V>> map, int size, @Nullable Comparator<? super V> valueComparator)
/* 210:    */   {
/* 211:345 */     super(map, size);
/* 212:346 */     this.emptySet = emptySet(valueComparator);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public ImmutableSet<V> get(@Nullable K key)
/* 216:    */   {
/* 217:359 */     ImmutableSet<V> set = (ImmutableSet)this.map.get(key);
/* 218:360 */     return (ImmutableSet)Objects.firstNonNull(set, this.emptySet);
/* 219:    */   }
/* 220:    */   
/* 221:    */   public ImmutableSetMultimap<V, K> inverse()
/* 222:    */   {
/* 223:376 */     ImmutableSetMultimap<V, K> result = this.inverse;
/* 224:377 */     return result == null ? (this.inverse = invert()) : result;
/* 225:    */   }
/* 226:    */   
/* 227:    */   private ImmutableSetMultimap<V, K> invert()
/* 228:    */   {
/* 229:381 */     Builder<V, K> builder = builder();
/* 230:382 */     for (Map.Entry<K, V> entry : entries()) {
/* 231:383 */       builder.put(entry.getValue(), entry.getKey());
/* 232:    */     }
/* 233:385 */     ImmutableSetMultimap<V, K> invertedMultimap = builder.build();
/* 234:386 */     invertedMultimap.inverse = this;
/* 235:387 */     return invertedMultimap;
/* 236:    */   }
/* 237:    */   
/* 238:    */   @Deprecated
/* 239:    */   public ImmutableSet<V> removeAll(Object key)
/* 240:    */   {
/* 241:397 */     throw new UnsupportedOperationException();
/* 242:    */   }
/* 243:    */   
/* 244:    */   @Deprecated
/* 245:    */   public ImmutableSet<V> replaceValues(K key, Iterable<? extends V> values)
/* 246:    */   {
/* 247:408 */     throw new UnsupportedOperationException();
/* 248:    */   }
/* 249:    */   
/* 250:    */   public ImmutableSet<Map.Entry<K, V>> entries()
/* 251:    */   {
/* 252:419 */     ImmutableSet<Map.Entry<K, V>> result = this.entries;
/* 253:420 */     return result == null ? (this.entries = new EntrySet(this)) : result;
/* 254:    */   }
/* 255:    */   
/* 256:    */   private static final class EntrySet<K, V>
/* 257:    */     extends ImmutableSet<Map.Entry<K, V>>
/* 258:    */   {
/* 259:    */     private final transient ImmutableSetMultimap<K, V> multimap;
/* 260:    */     
/* 261:    */     EntrySet(ImmutableSetMultimap<K, V> multimap)
/* 262:    */     {
/* 263:429 */       this.multimap = multimap;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public boolean contains(@Nullable Object object)
/* 267:    */     {
/* 268:434 */       if ((object instanceof Map.Entry))
/* 269:    */       {
/* 270:435 */         Map.Entry<?, ?> entry = (Map.Entry)object;
/* 271:436 */         return this.multimap.containsEntry(entry.getKey(), entry.getValue());
/* 272:    */       }
/* 273:438 */       return false;
/* 274:    */     }
/* 275:    */     
/* 276:    */     public int size()
/* 277:    */     {
/* 278:443 */       return this.multimap.size();
/* 279:    */     }
/* 280:    */     
/* 281:    */     public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 282:    */     {
/* 283:448 */       return this.multimap.entryIterator();
/* 284:    */     }
/* 285:    */     
/* 286:    */     boolean isPartialView()
/* 287:    */     {
/* 288:453 */       return false;
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */   private static <V> ImmutableSet<V> valueSet(@Nullable Comparator<? super V> valueComparator, Collection<? extends V> values)
/* 293:    */   {
/* 294:460 */     return valueComparator == null ? ImmutableSet.copyOf(values) : ImmutableSortedSet.copyOf(valueComparator, values);
/* 295:    */   }
/* 296:    */   
/* 297:    */   private static <V> ImmutableSet<V> emptySet(@Nullable Comparator<? super V> valueComparator)
/* 298:    */   {
/* 299:467 */     return valueComparator == null ? ImmutableSet.of() : ImmutableSortedSet.emptySet(valueComparator);
/* 300:    */   }
/* 301:    */   
/* 302:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 303:    */   private void writeObject(ObjectOutputStream stream)
/* 304:    */     throws IOException
/* 305:    */   {
/* 306:478 */     stream.defaultWriteObject();
/* 307:479 */     stream.writeObject(valueComparator());
/* 308:480 */     Serialization.writeMultimap(this, stream);
/* 309:    */   }
/* 310:    */   
/* 311:    */   @Nullable
/* 312:    */   Comparator<? super V> valueComparator()
/* 313:    */   {
/* 314:484 */     return (this.emptySet instanceof ImmutableSortedSet) ? ((ImmutableSortedSet)this.emptySet).comparator() : null;
/* 315:    */   }
/* 316:    */   
/* 317:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 318:    */   private void readObject(ObjectInputStream stream)
/* 319:    */     throws IOException, ClassNotFoundException
/* 320:    */   {
/* 321:494 */     stream.defaultReadObject();
/* 322:495 */     Comparator<Object> valueComparator = (Comparator)stream.readObject();
/* 323:    */     
/* 324:497 */     int keyCount = stream.readInt();
/* 325:498 */     if (keyCount < 0) {
/* 326:499 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/* 327:    */     }
/* 328:501 */     ImmutableMap.Builder<Object, ImmutableSet<Object>> builder = ImmutableMap.builder();
/* 329:    */     
/* 330:503 */     int tmpSize = 0;
/* 331:505 */     for (int i = 0; i < keyCount; i++)
/* 332:    */     {
/* 333:506 */       Object key = stream.readObject();
/* 334:507 */       int valueCount = stream.readInt();
/* 335:508 */       if (valueCount <= 0) {
/* 336:509 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/* 337:    */       }
/* 338:512 */       Object[] array = new Object[valueCount];
/* 339:513 */       for (int j = 0; j < valueCount; j++) {
/* 340:514 */         array[j] = stream.readObject();
/* 341:    */       }
/* 342:516 */       ImmutableSet<Object> valueSet = valueSet(valueComparator, Arrays.asList(array));
/* 343:517 */       if (valueSet.size() != array.length) {
/* 344:518 */         throw new InvalidObjectException("Duplicate key-value pairs exist for key " + key);
/* 345:    */       }
/* 346:521 */       builder.put(key, valueSet);
/* 347:522 */       tmpSize += valueCount;
/* 348:    */     }
/* 349:    */     ImmutableMap<Object, ImmutableSet<Object>> tmpMap;
/* 350:    */     try
/* 351:    */     {
/* 352:527 */       tmpMap = builder.build();
/* 353:    */     }
/* 354:    */     catch (IllegalArgumentException e)
/* 355:    */     {
/* 356:529 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/* 357:    */     }
/* 358:533 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 359:534 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/* 360:535 */     ImmutableMultimap.FieldSettersHolder.EMPTY_SET_FIELD_SETTER.set(this, emptySet(valueComparator));
/* 361:    */   }
/* 362:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSetMultimap
 * JD-Core Version:    0.7.0.1
 */
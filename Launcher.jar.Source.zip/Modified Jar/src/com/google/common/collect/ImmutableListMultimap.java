/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InvalidObjectException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Map.Entry;
/*  13:    */ import javax.annotation.Nullable;
/*  14:    */ 
/*  15:    */ @GwtCompatible(serializable=true, emulated=true)
/*  16:    */ public class ImmutableListMultimap<K, V>
/*  17:    */   extends ImmutableMultimap<K, V>
/*  18:    */   implements ListMultimap<K, V>
/*  19:    */ {
/*  20:    */   private transient ImmutableListMultimap<V, K> inverse;
/*  21:    */   @GwtIncompatible("Not needed in emulated source")
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   public static <K, V> ImmutableListMultimap<K, V> of()
/*  25:    */   {
/*  26: 64 */     return EmptyImmutableListMultimap.INSTANCE;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1)
/*  30:    */   {
/*  31: 71 */     Builder<K, V> builder = builder();
/*  32:    */     
/*  33: 73 */     builder.put(k1, v1);
/*  34: 74 */     return builder.build();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*  38:    */   {
/*  39: 81 */     Builder<K, V> builder = builder();
/*  40:    */     
/*  41: 83 */     builder.put(k1, v1);
/*  42: 84 */     builder.put(k2, v2);
/*  43: 85 */     return builder.build();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  47:    */   {
/*  48: 93 */     Builder<K, V> builder = builder();
/*  49:    */     
/*  50: 95 */     builder.put(k1, v1);
/*  51: 96 */     builder.put(k2, v2);
/*  52: 97 */     builder.put(k3, v3);
/*  53: 98 */     return builder.build();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  57:    */   {
/*  58:106 */     Builder<K, V> builder = builder();
/*  59:    */     
/*  60:108 */     builder.put(k1, v1);
/*  61:109 */     builder.put(k2, v2);
/*  62:110 */     builder.put(k3, v3);
/*  63:111 */     builder.put(k4, v4);
/*  64:112 */     return builder.build();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  68:    */   {
/*  69:120 */     Builder<K, V> builder = builder();
/*  70:    */     
/*  71:122 */     builder.put(k1, v1);
/*  72:123 */     builder.put(k2, v2);
/*  73:124 */     builder.put(k3, v3);
/*  74:125 */     builder.put(k4, v4);
/*  75:126 */     builder.put(k5, v5);
/*  76:127 */     return builder.build();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static <K, V> Builder<K, V> builder()
/*  80:    */   {
/*  81:137 */     return new Builder();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static final class Builder<K, V>
/*  85:    */     extends ImmutableMultimap.Builder<K, V>
/*  86:    */   {
/*  87:    */     public Builder<K, V> put(K key, V value)
/*  88:    */     {
/*  89:167 */       super.put(key, value);
/*  90:168 */       return this;
/*  91:    */     }
/*  92:    */     
/*  93:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/*  94:    */     {
/*  95:178 */       super.put(entry);
/*  96:179 */       return this;
/*  97:    */     }
/*  98:    */     
/*  99:    */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/* 100:    */     {
/* 101:183 */       super.putAll(key, values);
/* 102:184 */       return this;
/* 103:    */     }
/* 104:    */     
/* 105:    */     public Builder<K, V> putAll(K key, V... values)
/* 106:    */     {
/* 107:188 */       super.putAll(key, values);
/* 108:189 */       return this;
/* 109:    */     }
/* 110:    */     
/* 111:    */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/* 112:    */     {
/* 113:194 */       super.putAll(multimap);
/* 114:195 */       return this;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public Builder<K, V> orderKeysBy(Comparator<? super K> keyComparator)
/* 118:    */     {
/* 119:205 */       super.orderKeysBy(keyComparator);
/* 120:206 */       return this;
/* 121:    */     }
/* 122:    */     
/* 123:    */     public Builder<K, V> orderValuesBy(Comparator<? super V> valueComparator)
/* 124:    */     {
/* 125:216 */       super.orderValuesBy(valueComparator);
/* 126:217 */       return this;
/* 127:    */     }
/* 128:    */     
/* 129:    */     public ImmutableListMultimap<K, V> build()
/* 130:    */     {
/* 131:224 */       return (ImmutableListMultimap)super.build();
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static <K, V> ImmutableListMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/* 136:    */   {
/* 137:242 */     if (multimap.isEmpty()) {
/* 138:243 */       return of();
/* 139:    */     }
/* 140:247 */     if ((multimap instanceof ImmutableListMultimap))
/* 141:    */     {
/* 142:249 */       ImmutableListMultimap<K, V> kvMultimap = (ImmutableListMultimap)multimap;
/* 143:251 */       if (!kvMultimap.isPartialView()) {
/* 144:252 */         return kvMultimap;
/* 145:    */       }
/* 146:    */     }
/* 147:256 */     ImmutableMap.Builder<K, ImmutableList<V>> builder = ImmutableMap.builder();
/* 148:257 */     int size = 0;
/* 149:260 */     for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet())
/* 150:    */     {
/* 151:261 */       ImmutableList<V> list = ImmutableList.copyOf((Collection)entry.getValue());
/* 152:262 */       if (!list.isEmpty())
/* 153:    */       {
/* 154:263 */         builder.put(entry.getKey(), list);
/* 155:264 */         size += list.size();
/* 156:    */       }
/* 157:    */     }
/* 158:268 */     return new ImmutableListMultimap(builder.build(), size);
/* 159:    */   }
/* 160:    */   
/* 161:    */   ImmutableListMultimap(ImmutableMap<K, ImmutableList<V>> map, int size)
/* 162:    */   {
/* 163:272 */     super(map, size);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public ImmutableList<V> get(@Nullable K key)
/* 167:    */   {
/* 168:285 */     ImmutableList<V> list = (ImmutableList)this.map.get(key);
/* 169:286 */     return list == null ? ImmutableList.of() : list;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public ImmutableListMultimap<V, K> inverse()
/* 173:    */   {
/* 174:303 */     ImmutableListMultimap<V, K> result = this.inverse;
/* 175:304 */     return result == null ? (this.inverse = invert()) : result;
/* 176:    */   }
/* 177:    */   
/* 178:    */   private ImmutableListMultimap<V, K> invert()
/* 179:    */   {
/* 180:308 */     Builder<V, K> builder = builder();
/* 181:309 */     for (Map.Entry<K, V> entry : entries()) {
/* 182:310 */       builder.put(entry.getValue(), entry.getKey());
/* 183:    */     }
/* 184:312 */     ImmutableListMultimap<V, K> invertedMultimap = builder.build();
/* 185:313 */     invertedMultimap.inverse = this;
/* 186:314 */     return invertedMultimap;
/* 187:    */   }
/* 188:    */   
/* 189:    */   @Deprecated
/* 190:    */   public ImmutableList<V> removeAll(Object key)
/* 191:    */   {
/* 192:324 */     throw new UnsupportedOperationException();
/* 193:    */   }
/* 194:    */   
/* 195:    */   @Deprecated
/* 196:    */   public ImmutableList<V> replaceValues(K key, Iterable<? extends V> values)
/* 197:    */   {
/* 198:335 */     throw new UnsupportedOperationException();
/* 199:    */   }
/* 200:    */   
/* 201:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 202:    */   private void writeObject(ObjectOutputStream stream)
/* 203:    */     throws IOException
/* 204:    */   {
/* 205:344 */     stream.defaultWriteObject();
/* 206:345 */     Serialization.writeMultimap(this, stream);
/* 207:    */   }
/* 208:    */   
/* 209:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 210:    */   private void readObject(ObjectInputStream stream)
/* 211:    */     throws IOException, ClassNotFoundException
/* 212:    */   {
/* 213:351 */     stream.defaultReadObject();
/* 214:352 */     int keyCount = stream.readInt();
/* 215:353 */     if (keyCount < 0) {
/* 216:354 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/* 217:    */     }
/* 218:356 */     ImmutableMap.Builder<Object, ImmutableList<Object>> builder = ImmutableMap.builder();
/* 219:    */     
/* 220:358 */     int tmpSize = 0;
/* 221:360 */     for (int i = 0; i < keyCount; i++)
/* 222:    */     {
/* 223:361 */       Object key = stream.readObject();
/* 224:362 */       int valueCount = stream.readInt();
/* 225:363 */       if (valueCount <= 0) {
/* 226:364 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/* 227:    */       }
/* 228:367 */       Object[] array = new Object[valueCount];
/* 229:368 */       for (int j = 0; j < valueCount; j++) {
/* 230:369 */         array[j] = stream.readObject();
/* 231:    */       }
/* 232:371 */       builder.put(key, ImmutableList.copyOf(array));
/* 233:372 */       tmpSize += valueCount;
/* 234:    */     }
/* 235:    */     ImmutableMap<Object, ImmutableList<Object>> tmpMap;
/* 236:    */     try
/* 237:    */     {
/* 238:377 */       tmpMap = builder.build();
/* 239:    */     }
/* 240:    */     catch (IllegalArgumentException e)
/* 241:    */     {
/* 242:379 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/* 243:    */     }
/* 244:383 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 245:384 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/* 246:    */   }
/* 247:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableListMultimap
 * JD-Core Version:    0.7.0.1
 */
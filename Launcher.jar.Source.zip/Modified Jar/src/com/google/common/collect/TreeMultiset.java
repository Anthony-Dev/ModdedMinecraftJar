/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.primitives.Ints;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.ObjectInputStream;
/*  10:    */ import java.io.ObjectOutputStream;
/*  11:    */ import java.io.Serializable;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.ConcurrentModificationException;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.NavigableSet;
/*  16:    */ import java.util.NoSuchElementException;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class TreeMultiset<E>
/*  21:    */   extends AbstractSortedMultiset<E>
/*  22:    */   implements Serializable
/*  23:    */ {
/*  24:    */   private final transient Reference<AvlNode<E>> rootReference;
/*  25:    */   private final transient GeneralRange<E> range;
/*  26:    */   private final transient AvlNode<E> header;
/*  27:    */   @GwtIncompatible("not needed in emulated source")
/*  28:    */   private static final long serialVersionUID = 1L;
/*  29:    */   
/*  30:    */   public static <E extends Comparable> TreeMultiset<E> create()
/*  31:    */   {
/*  32: 74 */     return new TreeMultiset(Ordering.natural());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <E> TreeMultiset<E> create(@Nullable Comparator<? super E> comparator)
/*  36:    */   {
/*  37: 91 */     return comparator == null ? new TreeMultiset(Ordering.natural()) : new TreeMultiset(comparator);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E extends Comparable> TreeMultiset<E> create(Iterable<? extends E> elements)
/*  41:    */   {
/*  42:106 */     TreeMultiset<E> multiset = create();
/*  43:107 */     Iterables.addAll(multiset, elements);
/*  44:108 */     return multiset;
/*  45:    */   }
/*  46:    */   
/*  47:    */   TreeMultiset(Reference<AvlNode<E>> rootReference, GeneralRange<E> range, AvlNode<E> endLink)
/*  48:    */   {
/*  49:116 */     super(range.comparator());
/*  50:117 */     this.rootReference = rootReference;
/*  51:118 */     this.range = range;
/*  52:119 */     this.header = endLink;
/*  53:    */   }
/*  54:    */   
/*  55:    */   TreeMultiset(Comparator<? super E> comparator)
/*  56:    */   {
/*  57:123 */     super(comparator);
/*  58:124 */     this.range = GeneralRange.all(comparator);
/*  59:125 */     this.header = new AvlNode(null, 1);
/*  60:126 */     successor(this.header, this.header);
/*  61:127 */     this.rootReference = new Reference(null);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static abstract enum Aggregate
/*  65:    */   {
/*  66:134 */     SIZE,  DISTINCT;
/*  67:    */     
/*  68:    */     private Aggregate() {}
/*  69:    */     
/*  70:    */     abstract int nodeAggregate(TreeMultiset.AvlNode<?> paramAvlNode);
/*  71:    */     
/*  72:    */     abstract long treeAggregate(@Nullable TreeMultiset.AvlNode<?> paramAvlNode);
/*  73:    */   }
/*  74:    */   
/*  75:    */   private long aggregateForEntries(Aggregate aggr)
/*  76:    */   {
/*  77:162 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/*  78:163 */     long total = aggr.treeAggregate(root);
/*  79:164 */     if (this.range.hasLowerBound()) {
/*  80:165 */       total -= aggregateBelowRange(aggr, root);
/*  81:    */     }
/*  82:167 */     if (this.range.hasUpperBound()) {
/*  83:168 */       total -= aggregateAboveRange(aggr, root);
/*  84:    */     }
/*  85:170 */     return total;
/*  86:    */   }
/*  87:    */   
/*  88:    */   private long aggregateBelowRange(Aggregate aggr, @Nullable AvlNode<E> node)
/*  89:    */   {
/*  90:174 */     if (node == null) {
/*  91:175 */       return 0L;
/*  92:    */     }
/*  93:177 */     int cmp = comparator().compare(this.range.getLowerEndpoint(), node.elem);
/*  94:178 */     if (cmp < 0) {
/*  95:179 */       return aggregateBelowRange(aggr, node.left);
/*  96:    */     }
/*  97:180 */     if (cmp == 0)
/*  98:    */     {
/*  99:181 */       switch (4.$SwitchMap$com$google$common$collect$BoundType[this.range.getLowerBoundType().ordinal()])
/* 100:    */       {
/* 101:    */       case 1: 
/* 102:183 */         return aggr.nodeAggregate(node) + aggr.treeAggregate(node.left);
/* 103:    */       case 2: 
/* 104:185 */         return aggr.treeAggregate(node.left);
/* 105:    */       }
/* 106:187 */       throw new AssertionError();
/* 107:    */     }
/* 108:190 */     return aggr.treeAggregate(node.left) + aggr.nodeAggregate(node) + aggregateBelowRange(aggr, node.right);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private long aggregateAboveRange(Aggregate aggr, @Nullable AvlNode<E> node)
/* 112:    */   {
/* 113:196 */     if (node == null) {
/* 114:197 */       return 0L;
/* 115:    */     }
/* 116:199 */     int cmp = comparator().compare(this.range.getUpperEndpoint(), node.elem);
/* 117:200 */     if (cmp > 0) {
/* 118:201 */       return aggregateAboveRange(aggr, node.right);
/* 119:    */     }
/* 120:202 */     if (cmp == 0)
/* 121:    */     {
/* 122:203 */       switch (4.$SwitchMap$com$google$common$collect$BoundType[this.range.getUpperBoundType().ordinal()])
/* 123:    */       {
/* 124:    */       case 1: 
/* 125:205 */         return aggr.nodeAggregate(node) + aggr.treeAggregate(node.right);
/* 126:    */       case 2: 
/* 127:207 */         return aggr.treeAggregate(node.right);
/* 128:    */       }
/* 129:209 */       throw new AssertionError();
/* 130:    */     }
/* 131:212 */     return aggr.treeAggregate(node.right) + aggr.nodeAggregate(node) + aggregateAboveRange(aggr, node.left);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public int size()
/* 135:    */   {
/* 136:219 */     return Ints.saturatedCast(aggregateForEntries(Aggregate.SIZE));
/* 137:    */   }
/* 138:    */   
/* 139:    */   int distinctElements()
/* 140:    */   {
/* 141:224 */     return Ints.saturatedCast(aggregateForEntries(Aggregate.DISTINCT));
/* 142:    */   }
/* 143:    */   
/* 144:    */   public int count(@Nullable Object element)
/* 145:    */   {
/* 146:    */     try
/* 147:    */     {
/* 148:231 */       E e = element;
/* 149:232 */       AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 150:233 */       if ((!this.range.contains(e)) || (root == null)) {
/* 151:234 */         return 0;
/* 152:    */       }
/* 153:236 */       return root.count(comparator(), e);
/* 154:    */     }
/* 155:    */     catch (ClassCastException e)
/* 156:    */     {
/* 157:238 */       return 0;
/* 158:    */     }
/* 159:    */     catch (NullPointerException e) {}
/* 160:240 */     return 0;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public int add(@Nullable E element, int occurrences)
/* 164:    */   {
/* 165:246 */     CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 166:247 */     if (occurrences == 0) {
/* 167:248 */       return count(element);
/* 168:    */     }
/* 169:250 */     Preconditions.checkArgument(this.range.contains(element));
/* 170:251 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 171:252 */     if (root == null)
/* 172:    */     {
/* 173:253 */       comparator().compare(element, element);
/* 174:254 */       AvlNode<E> newRoot = new AvlNode(element, occurrences);
/* 175:255 */       successor(this.header, newRoot, this.header);
/* 176:256 */       this.rootReference.checkAndSet(root, newRoot);
/* 177:257 */       return 0;
/* 178:    */     }
/* 179:259 */     int[] result = new int[1];
/* 180:260 */     AvlNode<E> newRoot = root.add(comparator(), element, occurrences, result);
/* 181:261 */     this.rootReference.checkAndSet(root, newRoot);
/* 182:262 */     return result[0];
/* 183:    */   }
/* 184:    */   
/* 185:    */   public int remove(@Nullable Object element, int occurrences)
/* 186:    */   {
/* 187:267 */     CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 188:268 */     if (occurrences == 0) {
/* 189:269 */       return count(element);
/* 190:    */     }
/* 191:271 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 192:272 */     int[] result = new int[1];
/* 193:    */     AvlNode<E> newRoot;
/* 194:    */     try
/* 195:    */     {
/* 196:276 */       E e = element;
/* 197:277 */       if ((!this.range.contains(e)) || (root == null)) {
/* 198:278 */         return 0;
/* 199:    */       }
/* 200:280 */       newRoot = root.remove(comparator(), e, occurrences, result);
/* 201:    */     }
/* 202:    */     catch (ClassCastException e)
/* 203:    */     {
/* 204:282 */       return 0;
/* 205:    */     }
/* 206:    */     catch (NullPointerException e)
/* 207:    */     {
/* 208:284 */       return 0;
/* 209:    */     }
/* 210:286 */     this.rootReference.checkAndSet(root, newRoot);
/* 211:287 */     return result[0];
/* 212:    */   }
/* 213:    */   
/* 214:    */   public int setCount(@Nullable E element, int count)
/* 215:    */   {
/* 216:292 */     CollectPreconditions.checkNonnegative(count, "count");
/* 217:293 */     if (!this.range.contains(element))
/* 218:    */     {
/* 219:294 */       Preconditions.checkArgument(count == 0);
/* 220:295 */       return 0;
/* 221:    */     }
/* 222:298 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 223:299 */     if (root == null)
/* 224:    */     {
/* 225:300 */       if (count > 0) {
/* 226:301 */         add(element, count);
/* 227:    */       }
/* 228:303 */       return 0;
/* 229:    */     }
/* 230:305 */     int[] result = new int[1];
/* 231:306 */     AvlNode<E> newRoot = root.setCount(comparator(), element, count, result);
/* 232:307 */     this.rootReference.checkAndSet(root, newRoot);
/* 233:308 */     return result[0];
/* 234:    */   }
/* 235:    */   
/* 236:    */   public boolean setCount(@Nullable E element, int oldCount, int newCount)
/* 237:    */   {
/* 238:313 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/* 239:314 */     CollectPreconditions.checkNonnegative(oldCount, "oldCount");
/* 240:315 */     Preconditions.checkArgument(this.range.contains(element));
/* 241:    */     
/* 242:317 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 243:318 */     if (root == null)
/* 244:    */     {
/* 245:319 */       if (oldCount == 0)
/* 246:    */       {
/* 247:320 */         if (newCount > 0) {
/* 248:321 */           add(element, newCount);
/* 249:    */         }
/* 250:323 */         return true;
/* 251:    */       }
/* 252:325 */       return false;
/* 253:    */     }
/* 254:328 */     int[] result = new int[1];
/* 255:329 */     AvlNode<E> newRoot = root.setCount(comparator(), element, oldCount, newCount, result);
/* 256:330 */     this.rootReference.checkAndSet(root, newRoot);
/* 257:331 */     return result[0] == oldCount;
/* 258:    */   }
/* 259:    */   
/* 260:    */   private Multiset.Entry<E> wrapEntry(final AvlNode<E> baseEntry)
/* 261:    */   {
/* 262:335 */     new Multisets.AbstractEntry()
/* 263:    */     {
/* 264:    */       public E getElement()
/* 265:    */       {
/* 266:338 */         return baseEntry.getElement();
/* 267:    */       }
/* 268:    */       
/* 269:    */       public int getCount()
/* 270:    */       {
/* 271:343 */         int result = baseEntry.getCount();
/* 272:344 */         if (result == 0) {
/* 273:345 */           return TreeMultiset.this.count(getElement());
/* 274:    */         }
/* 275:347 */         return result;
/* 276:    */       }
/* 277:    */     };
/* 278:    */   }
/* 279:    */   
/* 280:    */   @Nullable
/* 281:    */   private AvlNode<E> firstNode()
/* 282:    */   {
/* 283:357 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 284:358 */     if (root == null) {
/* 285:359 */       return null;
/* 286:    */     }
/* 287:    */     AvlNode<E> node;
/* 288:362 */     if (this.range.hasLowerBound())
/* 289:    */     {
/* 290:363 */       E endpoint = this.range.getLowerEndpoint();
/* 291:364 */       AvlNode<E> node = ((AvlNode)this.rootReference.get()).ceiling(comparator(), endpoint);
/* 292:365 */       if (node == null) {
/* 293:366 */         return null;
/* 294:    */       }
/* 295:368 */       if ((this.range.getLowerBoundType() == BoundType.OPEN) && (comparator().compare(endpoint, node.getElement()) == 0)) {
/* 296:370 */         node = node.succ;
/* 297:    */       }
/* 298:    */     }
/* 299:    */     else
/* 300:    */     {
/* 301:373 */       node = this.header.succ;
/* 302:    */     }
/* 303:375 */     return (node == this.header) || (!this.range.contains(node.getElement())) ? null : node;
/* 304:    */   }
/* 305:    */   
/* 306:    */   @Nullable
/* 307:    */   private AvlNode<E> lastNode()
/* 308:    */   {
/* 309:379 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 310:380 */     if (root == null) {
/* 311:381 */       return null;
/* 312:    */     }
/* 313:    */     AvlNode<E> node;
/* 314:384 */     if (this.range.hasUpperBound())
/* 315:    */     {
/* 316:385 */       E endpoint = this.range.getUpperEndpoint();
/* 317:386 */       AvlNode<E> node = ((AvlNode)this.rootReference.get()).floor(comparator(), endpoint);
/* 318:387 */       if (node == null) {
/* 319:388 */         return null;
/* 320:    */       }
/* 321:390 */       if ((this.range.getUpperBoundType() == BoundType.OPEN) && (comparator().compare(endpoint, node.getElement()) == 0)) {
/* 322:392 */         node = node.pred;
/* 323:    */       }
/* 324:    */     }
/* 325:    */     else
/* 326:    */     {
/* 327:395 */       node = this.header.pred;
/* 328:    */     }
/* 329:397 */     return (node == this.header) || (!this.range.contains(node.getElement())) ? null : node;
/* 330:    */   }
/* 331:    */   
/* 332:    */   Iterator<Multiset.Entry<E>> entryIterator()
/* 333:    */   {
/* 334:402 */     new Iterator()
/* 335:    */     {
/* 336:403 */       TreeMultiset.AvlNode<E> current = TreeMultiset.this.firstNode();
/* 337:    */       Multiset.Entry<E> prevEntry;
/* 338:    */       
/* 339:    */       public boolean hasNext()
/* 340:    */       {
/* 341:408 */         if (this.current == null) {
/* 342:409 */           return false;
/* 343:    */         }
/* 344:410 */         if (TreeMultiset.this.range.tooHigh(this.current.getElement()))
/* 345:    */         {
/* 346:411 */           this.current = null;
/* 347:412 */           return false;
/* 348:    */         }
/* 349:414 */         return true;
/* 350:    */       }
/* 351:    */       
/* 352:    */       public Multiset.Entry<E> next()
/* 353:    */       {
/* 354:420 */         if (!hasNext()) {
/* 355:421 */           throw new NoSuchElementException();
/* 356:    */         }
/* 357:423 */         Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
/* 358:424 */         this.prevEntry = result;
/* 359:425 */         if (TreeMultiset.AvlNode.access$900(this.current) == TreeMultiset.this.header) {
/* 360:426 */           this.current = null;
/* 361:    */         } else {
/* 362:428 */           this.current = TreeMultiset.AvlNode.access$900(this.current);
/* 363:    */         }
/* 364:430 */         return result;
/* 365:    */       }
/* 366:    */       
/* 367:    */       public void remove()
/* 368:    */       {
/* 369:435 */         CollectPreconditions.checkRemove(this.prevEntry != null);
/* 370:436 */         TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
/* 371:437 */         this.prevEntry = null;
/* 372:    */       }
/* 373:    */     };
/* 374:    */   }
/* 375:    */   
/* 376:    */   Iterator<Multiset.Entry<E>> descendingEntryIterator()
/* 377:    */   {
/* 378:444 */     new Iterator()
/* 379:    */     {
/* 380:445 */       TreeMultiset.AvlNode<E> current = TreeMultiset.this.lastNode();
/* 381:446 */       Multiset.Entry<E> prevEntry = null;
/* 382:    */       
/* 383:    */       public boolean hasNext()
/* 384:    */       {
/* 385:450 */         if (this.current == null) {
/* 386:451 */           return false;
/* 387:    */         }
/* 388:452 */         if (TreeMultiset.this.range.tooLow(this.current.getElement()))
/* 389:    */         {
/* 390:453 */           this.current = null;
/* 391:454 */           return false;
/* 392:    */         }
/* 393:456 */         return true;
/* 394:    */       }
/* 395:    */       
/* 396:    */       public Multiset.Entry<E> next()
/* 397:    */       {
/* 398:462 */         if (!hasNext()) {
/* 399:463 */           throw new NoSuchElementException();
/* 400:    */         }
/* 401:465 */         Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
/* 402:466 */         this.prevEntry = result;
/* 403:467 */         if (TreeMultiset.AvlNode.access$1100(this.current) == TreeMultiset.this.header) {
/* 404:468 */           this.current = null;
/* 405:    */         } else {
/* 406:470 */           this.current = TreeMultiset.AvlNode.access$1100(this.current);
/* 407:    */         }
/* 408:472 */         return result;
/* 409:    */       }
/* 410:    */       
/* 411:    */       public void remove()
/* 412:    */       {
/* 413:477 */         CollectPreconditions.checkRemove(this.prevEntry != null);
/* 414:478 */         TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
/* 415:479 */         this.prevEntry = null;
/* 416:    */       }
/* 417:    */     };
/* 418:    */   }
/* 419:    */   
/* 420:    */   public SortedMultiset<E> headMultiset(@Nullable E upperBound, BoundType boundType)
/* 421:    */   {
/* 422:486 */     return new TreeMultiset(this.rootReference, this.range.intersect(GeneralRange.upTo(comparator(), upperBound, boundType)), this.header);
/* 423:    */   }
/* 424:    */   
/* 425:    */   public SortedMultiset<E> tailMultiset(@Nullable E lowerBound, BoundType boundType)
/* 426:    */   {
/* 427:494 */     return new TreeMultiset(this.rootReference, this.range.intersect(GeneralRange.downTo(comparator(), lowerBound, boundType)), this.header);
/* 428:    */   }
/* 429:    */   
/* 430:    */   static int distinctElements(@Nullable AvlNode<?> node)
/* 431:    */   {
/* 432:501 */     return node == null ? 0 : node.distinctElements;
/* 433:    */   }
/* 434:    */   
/* 435:    */   private static final class Reference<T>
/* 436:    */   {
/* 437:    */     @Nullable
/* 438:    */     private T value;
/* 439:    */     
/* 440:    */     @Nullable
/* 441:    */     public T get()
/* 442:    */     {
/* 443:508 */       return this.value;
/* 444:    */     }
/* 445:    */     
/* 446:    */     public void checkAndSet(@Nullable T expected, T newValue)
/* 447:    */     {
/* 448:512 */       if (this.value != expected) {
/* 449:513 */         throw new ConcurrentModificationException();
/* 450:    */       }
/* 451:515 */       this.value = newValue;
/* 452:    */     }
/* 453:    */   }
/* 454:    */   
/* 455:    */   private static final class AvlNode<E>
/* 456:    */     extends Multisets.AbstractEntry<E>
/* 457:    */   {
/* 458:    */     @Nullable
/* 459:    */     private final E elem;
/* 460:    */     private int elemCount;
/* 461:    */     private int distinctElements;
/* 462:    */     private long totalCount;
/* 463:    */     private int height;
/* 464:    */     private AvlNode<E> left;
/* 465:    */     private AvlNode<E> right;
/* 466:    */     private AvlNode<E> pred;
/* 467:    */     private AvlNode<E> succ;
/* 468:    */     
/* 469:    */     AvlNode(@Nullable E elem, int elemCount)
/* 470:    */     {
/* 471:534 */       Preconditions.checkArgument(elemCount > 0);
/* 472:535 */       this.elem = elem;
/* 473:536 */       this.elemCount = elemCount;
/* 474:537 */       this.totalCount = elemCount;
/* 475:538 */       this.distinctElements = 1;
/* 476:539 */       this.height = 1;
/* 477:540 */       this.left = null;
/* 478:541 */       this.right = null;
/* 479:    */     }
/* 480:    */     
/* 481:    */     public int count(Comparator<? super E> comparator, E e)
/* 482:    */     {
/* 483:545 */       int cmp = comparator.compare(e, this.elem);
/* 484:546 */       if (cmp < 0) {
/* 485:547 */         return this.left == null ? 0 : this.left.count(comparator, e);
/* 486:    */       }
/* 487:548 */       if (cmp > 0) {
/* 488:549 */         return this.right == null ? 0 : this.right.count(comparator, e);
/* 489:    */       }
/* 490:551 */       return this.elemCount;
/* 491:    */     }
/* 492:    */     
/* 493:    */     private AvlNode<E> addRightChild(E e, int count)
/* 494:    */     {
/* 495:556 */       this.right = new AvlNode(e, count);
/* 496:557 */       TreeMultiset.successor(this, this.right, this.succ);
/* 497:558 */       this.height = Math.max(2, this.height);
/* 498:559 */       this.distinctElements += 1;
/* 499:560 */       this.totalCount += count;
/* 500:561 */       return this;
/* 501:    */     }
/* 502:    */     
/* 503:    */     private AvlNode<E> addLeftChild(E e, int count)
/* 504:    */     {
/* 505:565 */       this.left = new AvlNode(e, count);
/* 506:566 */       TreeMultiset.successor(this.pred, this.left, this);
/* 507:567 */       this.height = Math.max(2, this.height);
/* 508:568 */       this.distinctElements += 1;
/* 509:569 */       this.totalCount += count;
/* 510:570 */       return this;
/* 511:    */     }
/* 512:    */     
/* 513:    */     AvlNode<E> add(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 514:    */     {
/* 515:578 */       int cmp = comparator.compare(e, this.elem);
/* 516:579 */       if (cmp < 0)
/* 517:    */       {
/* 518:580 */         AvlNode<E> initLeft = this.left;
/* 519:581 */         if (initLeft == null)
/* 520:    */         {
/* 521:582 */           result[0] = 0;
/* 522:583 */           return addLeftChild(e, count);
/* 523:    */         }
/* 524:585 */         int initHeight = initLeft.height;
/* 525:    */         
/* 526:587 */         this.left = initLeft.add(comparator, e, count, result);
/* 527:588 */         if (result[0] == 0) {
/* 528:589 */           this.distinctElements += 1;
/* 529:    */         }
/* 530:591 */         this.totalCount += count;
/* 531:592 */         return this.left.height == initHeight ? this : rebalance();
/* 532:    */       }
/* 533:593 */       if (cmp > 0)
/* 534:    */       {
/* 535:594 */         AvlNode<E> initRight = this.right;
/* 536:595 */         if (initRight == null)
/* 537:    */         {
/* 538:596 */           result[0] = 0;
/* 539:597 */           return addRightChild(e, count);
/* 540:    */         }
/* 541:599 */         int initHeight = initRight.height;
/* 542:    */         
/* 543:601 */         this.right = initRight.add(comparator, e, count, result);
/* 544:602 */         if (result[0] == 0) {
/* 545:603 */           this.distinctElements += 1;
/* 546:    */         }
/* 547:605 */         this.totalCount += count;
/* 548:606 */         return this.right.height == initHeight ? this : rebalance();
/* 549:    */       }
/* 550:610 */       result[0] = this.elemCount;
/* 551:611 */       long resultCount = this.elemCount + count;
/* 552:612 */       Preconditions.checkArgument(resultCount <= 2147483647L);
/* 553:613 */       this.elemCount += count;
/* 554:614 */       this.totalCount += count;
/* 555:615 */       return this;
/* 556:    */     }
/* 557:    */     
/* 558:    */     AvlNode<E> remove(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 559:    */     {
/* 560:619 */       int cmp = comparator.compare(e, this.elem);
/* 561:620 */       if (cmp < 0)
/* 562:    */       {
/* 563:621 */         AvlNode<E> initLeft = this.left;
/* 564:622 */         if (initLeft == null)
/* 565:    */         {
/* 566:623 */           result[0] = 0;
/* 567:624 */           return this;
/* 568:    */         }
/* 569:627 */         this.left = initLeft.remove(comparator, e, count, result);
/* 570:629 */         if (result[0] > 0) {
/* 571:630 */           if (count >= result[0])
/* 572:    */           {
/* 573:631 */             this.distinctElements -= 1;
/* 574:632 */             this.totalCount -= result[0];
/* 575:    */           }
/* 576:    */           else
/* 577:    */           {
/* 578:634 */             this.totalCount -= count;
/* 579:    */           }
/* 580:    */         }
/* 581:637 */         return result[0] == 0 ? this : rebalance();
/* 582:    */       }
/* 583:638 */       if (cmp > 0)
/* 584:    */       {
/* 585:639 */         AvlNode<E> initRight = this.right;
/* 586:640 */         if (initRight == null)
/* 587:    */         {
/* 588:641 */           result[0] = 0;
/* 589:642 */           return this;
/* 590:    */         }
/* 591:645 */         this.right = initRight.remove(comparator, e, count, result);
/* 592:647 */         if (result[0] > 0) {
/* 593:648 */           if (count >= result[0])
/* 594:    */           {
/* 595:649 */             this.distinctElements -= 1;
/* 596:650 */             this.totalCount -= result[0];
/* 597:    */           }
/* 598:    */           else
/* 599:    */           {
/* 600:652 */             this.totalCount -= count;
/* 601:    */           }
/* 602:    */         }
/* 603:655 */         return rebalance();
/* 604:    */       }
/* 605:659 */       result[0] = this.elemCount;
/* 606:660 */       if (count >= this.elemCount) {
/* 607:661 */         return deleteMe();
/* 608:    */       }
/* 609:663 */       this.elemCount -= count;
/* 610:664 */       this.totalCount -= count;
/* 611:665 */       return this;
/* 612:    */     }
/* 613:    */     
/* 614:    */     AvlNode<E> setCount(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 615:    */     {
/* 616:670 */       int cmp = comparator.compare(e, this.elem);
/* 617:671 */       if (cmp < 0)
/* 618:    */       {
/* 619:672 */         AvlNode<E> initLeft = this.left;
/* 620:673 */         if (initLeft == null)
/* 621:    */         {
/* 622:674 */           result[0] = 0;
/* 623:675 */           return count > 0 ? addLeftChild(e, count) : this;
/* 624:    */         }
/* 625:678 */         this.left = initLeft.setCount(comparator, e, count, result);
/* 626:680 */         if ((count == 0) && (result[0] != 0)) {
/* 627:681 */           this.distinctElements -= 1;
/* 628:682 */         } else if ((count > 0) && (result[0] == 0)) {
/* 629:683 */           this.distinctElements += 1;
/* 630:    */         }
/* 631:686 */         this.totalCount += count - result[0];
/* 632:687 */         return rebalance();
/* 633:    */       }
/* 634:688 */       if (cmp > 0)
/* 635:    */       {
/* 636:689 */         AvlNode<E> initRight = this.right;
/* 637:690 */         if (initRight == null)
/* 638:    */         {
/* 639:691 */           result[0] = 0;
/* 640:692 */           return count > 0 ? addRightChild(e, count) : this;
/* 641:    */         }
/* 642:695 */         this.right = initRight.setCount(comparator, e, count, result);
/* 643:697 */         if ((count == 0) && (result[0] != 0)) {
/* 644:698 */           this.distinctElements -= 1;
/* 645:699 */         } else if ((count > 0) && (result[0] == 0)) {
/* 646:700 */           this.distinctElements += 1;
/* 647:    */         }
/* 648:703 */         this.totalCount += count - result[0];
/* 649:704 */         return rebalance();
/* 650:    */       }
/* 651:708 */       result[0] = this.elemCount;
/* 652:709 */       if (count == 0) {
/* 653:710 */         return deleteMe();
/* 654:    */       }
/* 655:712 */       this.totalCount += count - this.elemCount;
/* 656:713 */       this.elemCount = count;
/* 657:714 */       return this;
/* 658:    */     }
/* 659:    */     
/* 660:    */     AvlNode<E> setCount(Comparator<? super E> comparator, @Nullable E e, int expectedCount, int newCount, int[] result)
/* 661:    */     {
/* 662:723 */       int cmp = comparator.compare(e, this.elem);
/* 663:724 */       if (cmp < 0)
/* 664:    */       {
/* 665:725 */         AvlNode<E> initLeft = this.left;
/* 666:726 */         if (initLeft == null)
/* 667:    */         {
/* 668:727 */           result[0] = 0;
/* 669:728 */           if ((expectedCount == 0) && (newCount > 0)) {
/* 670:729 */             return addLeftChild(e, newCount);
/* 671:    */           }
/* 672:731 */           return this;
/* 673:    */         }
/* 674:734 */         this.left = initLeft.setCount(comparator, e, expectedCount, newCount, result);
/* 675:736 */         if (result[0] == expectedCount)
/* 676:    */         {
/* 677:737 */           if ((newCount == 0) && (result[0] != 0)) {
/* 678:738 */             this.distinctElements -= 1;
/* 679:739 */           } else if ((newCount > 0) && (result[0] == 0)) {
/* 680:740 */             this.distinctElements += 1;
/* 681:    */           }
/* 682:742 */           this.totalCount += newCount - result[0];
/* 683:    */         }
/* 684:744 */         return rebalance();
/* 685:    */       }
/* 686:745 */       if (cmp > 0)
/* 687:    */       {
/* 688:746 */         AvlNode<E> initRight = this.right;
/* 689:747 */         if (initRight == null)
/* 690:    */         {
/* 691:748 */           result[0] = 0;
/* 692:749 */           if ((expectedCount == 0) && (newCount > 0)) {
/* 693:750 */             return addRightChild(e, newCount);
/* 694:    */           }
/* 695:752 */           return this;
/* 696:    */         }
/* 697:755 */         this.right = initRight.setCount(comparator, e, expectedCount, newCount, result);
/* 698:757 */         if (result[0] == expectedCount)
/* 699:    */         {
/* 700:758 */           if ((newCount == 0) && (result[0] != 0)) {
/* 701:759 */             this.distinctElements -= 1;
/* 702:760 */           } else if ((newCount > 0) && (result[0] == 0)) {
/* 703:761 */             this.distinctElements += 1;
/* 704:    */           }
/* 705:763 */           this.totalCount += newCount - result[0];
/* 706:    */         }
/* 707:765 */         return rebalance();
/* 708:    */       }
/* 709:769 */       result[0] = this.elemCount;
/* 710:770 */       if (expectedCount == this.elemCount)
/* 711:    */       {
/* 712:771 */         if (newCount == 0) {
/* 713:772 */           return deleteMe();
/* 714:    */         }
/* 715:774 */         this.totalCount += newCount - this.elemCount;
/* 716:775 */         this.elemCount = newCount;
/* 717:    */       }
/* 718:777 */       return this;
/* 719:    */     }
/* 720:    */     
/* 721:    */     private AvlNode<E> deleteMe()
/* 722:    */     {
/* 723:781 */       int oldElemCount = this.elemCount;
/* 724:782 */       this.elemCount = 0;
/* 725:783 */       TreeMultiset.successor(this.pred, this.succ);
/* 726:784 */       if (this.left == null) {
/* 727:785 */         return this.right;
/* 728:    */       }
/* 729:786 */       if (this.right == null) {
/* 730:787 */         return this.left;
/* 731:    */       }
/* 732:788 */       if (this.left.height >= this.right.height)
/* 733:    */       {
/* 734:789 */         AvlNode<E> newTop = this.pred;
/* 735:    */         
/* 736:791 */         newTop.left = this.left.removeMax(newTop);
/* 737:792 */         newTop.right = this.right;
/* 738:793 */         this.distinctElements -= 1;
/* 739:794 */         this.totalCount -= oldElemCount;
/* 740:795 */         return newTop.rebalance();
/* 741:    */       }
/* 742:797 */       AvlNode<E> newTop = this.succ;
/* 743:798 */       newTop.right = this.right.removeMin(newTop);
/* 744:799 */       newTop.left = this.left;
/* 745:800 */       this.distinctElements -= 1;
/* 746:801 */       this.totalCount -= oldElemCount;
/* 747:802 */       return newTop.rebalance();
/* 748:    */     }
/* 749:    */     
/* 750:    */     private AvlNode<E> removeMin(AvlNode<E> node)
/* 751:    */     {
/* 752:808 */       if (this.left == null) {
/* 753:809 */         return this.right;
/* 754:    */       }
/* 755:811 */       this.left = this.left.removeMin(node);
/* 756:812 */       this.distinctElements -= 1;
/* 757:813 */       this.totalCount -= node.elemCount;
/* 758:814 */       return rebalance();
/* 759:    */     }
/* 760:    */     
/* 761:    */     private AvlNode<E> removeMax(AvlNode<E> node)
/* 762:    */     {
/* 763:820 */       if (this.right == null) {
/* 764:821 */         return this.left;
/* 765:    */       }
/* 766:823 */       this.right = this.right.removeMax(node);
/* 767:824 */       this.distinctElements -= 1;
/* 768:825 */       this.totalCount -= node.elemCount;
/* 769:826 */       return rebalance();
/* 770:    */     }
/* 771:    */     
/* 772:    */     private void recomputeMultiset()
/* 773:    */     {
/* 774:831 */       this.distinctElements = (1 + TreeMultiset.distinctElements(this.left) + TreeMultiset.distinctElements(this.right));
/* 775:    */       
/* 776:833 */       this.totalCount = (this.elemCount + totalCount(this.left) + totalCount(this.right));
/* 777:    */     }
/* 778:    */     
/* 779:    */     private void recomputeHeight()
/* 780:    */     {
/* 781:837 */       this.height = (1 + Math.max(height(this.left), height(this.right)));
/* 782:    */     }
/* 783:    */     
/* 784:    */     private void recompute()
/* 785:    */     {
/* 786:841 */       recomputeMultiset();
/* 787:842 */       recomputeHeight();
/* 788:    */     }
/* 789:    */     
/* 790:    */     private AvlNode<E> rebalance()
/* 791:    */     {
/* 792:846 */       switch (balanceFactor())
/* 793:    */       {
/* 794:    */       case -2: 
/* 795:848 */         if (this.right.balanceFactor() > 0) {
/* 796:849 */           this.right = this.right.rotateRight();
/* 797:    */         }
/* 798:851 */         return rotateLeft();
/* 799:    */       case 2: 
/* 800:853 */         if (this.left.balanceFactor() < 0) {
/* 801:854 */           this.left = this.left.rotateLeft();
/* 802:    */         }
/* 803:856 */         return rotateRight();
/* 804:    */       }
/* 805:858 */       recomputeHeight();
/* 806:859 */       return this;
/* 807:    */     }
/* 808:    */     
/* 809:    */     private int balanceFactor()
/* 810:    */     {
/* 811:864 */       return height(this.left) - height(this.right);
/* 812:    */     }
/* 813:    */     
/* 814:    */     private AvlNode<E> rotateLeft()
/* 815:    */     {
/* 816:868 */       Preconditions.checkState(this.right != null);
/* 817:869 */       AvlNode<E> newTop = this.right;
/* 818:870 */       this.right = newTop.left;
/* 819:871 */       newTop.left = this;
/* 820:872 */       newTop.totalCount = this.totalCount;
/* 821:873 */       newTop.distinctElements = this.distinctElements;
/* 822:874 */       recompute();
/* 823:875 */       newTop.recomputeHeight();
/* 824:876 */       return newTop;
/* 825:    */     }
/* 826:    */     
/* 827:    */     private AvlNode<E> rotateRight()
/* 828:    */     {
/* 829:880 */       Preconditions.checkState(this.left != null);
/* 830:881 */       AvlNode<E> newTop = this.left;
/* 831:882 */       this.left = newTop.right;
/* 832:883 */       newTop.right = this;
/* 833:884 */       newTop.totalCount = this.totalCount;
/* 834:885 */       newTop.distinctElements = this.distinctElements;
/* 835:886 */       recompute();
/* 836:887 */       newTop.recomputeHeight();
/* 837:888 */       return newTop;
/* 838:    */     }
/* 839:    */     
/* 840:    */     private static long totalCount(@Nullable AvlNode<?> node)
/* 841:    */     {
/* 842:892 */       return node == null ? 0L : node.totalCount;
/* 843:    */     }
/* 844:    */     
/* 845:    */     private static int height(@Nullable AvlNode<?> node)
/* 846:    */     {
/* 847:896 */       return node == null ? 0 : node.height;
/* 848:    */     }
/* 849:    */     
/* 850:    */     @Nullable
/* 851:    */     private AvlNode<E> ceiling(Comparator<? super E> comparator, E e)
/* 852:    */     {
/* 853:900 */       int cmp = comparator.compare(e, this.elem);
/* 854:901 */       if (cmp < 0) {
/* 855:902 */         return this.left == null ? this : (AvlNode)Objects.firstNonNull(this.left.ceiling(comparator, e), this);
/* 856:    */       }
/* 857:903 */       if (cmp == 0) {
/* 858:904 */         return this;
/* 859:    */       }
/* 860:906 */       return this.right == null ? null : this.right.ceiling(comparator, e);
/* 861:    */     }
/* 862:    */     
/* 863:    */     @Nullable
/* 864:    */     private AvlNode<E> floor(Comparator<? super E> comparator, E e)
/* 865:    */     {
/* 866:911 */       int cmp = comparator.compare(e, this.elem);
/* 867:912 */       if (cmp > 0) {
/* 868:913 */         return this.right == null ? this : (AvlNode)Objects.firstNonNull(this.right.floor(comparator, e), this);
/* 869:    */       }
/* 870:914 */       if (cmp == 0) {
/* 871:915 */         return this;
/* 872:    */       }
/* 873:917 */       return this.left == null ? null : this.left.floor(comparator, e);
/* 874:    */     }
/* 875:    */     
/* 876:    */     public E getElement()
/* 877:    */     {
/* 878:923 */       return this.elem;
/* 879:    */     }
/* 880:    */     
/* 881:    */     public int getCount()
/* 882:    */     {
/* 883:928 */       return this.elemCount;
/* 884:    */     }
/* 885:    */     
/* 886:    */     public String toString()
/* 887:    */     {
/* 888:933 */       return Multisets.immutableEntry(getElement(), getCount()).toString();
/* 889:    */     }
/* 890:    */   }
/* 891:    */   
/* 892:    */   private static <T> void successor(AvlNode<T> a, AvlNode<T> b)
/* 893:    */   {
/* 894:938 */     a.succ = b;
/* 895:939 */     b.pred = a;
/* 896:    */   }
/* 897:    */   
/* 898:    */   private static <T> void successor(AvlNode<T> a, AvlNode<T> b, AvlNode<T> c)
/* 899:    */   {
/* 900:943 */     successor(a, b);
/* 901:944 */     successor(b, c);
/* 902:    */   }
/* 903:    */   
/* 904:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 905:    */   private void writeObject(ObjectOutputStream stream)
/* 906:    */     throws IOException
/* 907:    */   {
/* 908:959 */     stream.defaultWriteObject();
/* 909:960 */     stream.writeObject(elementSet().comparator());
/* 910:961 */     Serialization.writeMultiset(this, stream);
/* 911:    */   }
/* 912:    */   
/* 913:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 914:    */   private void readObject(ObjectInputStream stream)
/* 915:    */     throws IOException, ClassNotFoundException
/* 916:    */   {
/* 917:966 */     stream.defaultReadObject();
/* 918:    */     
/* 919:    */ 
/* 920:969 */     Comparator<? super E> comparator = (Comparator)stream.readObject();
/* 921:970 */     Serialization.getFieldSetter(AbstractSortedMultiset.class, "comparator").set(this, comparator);
/* 922:971 */     Serialization.getFieldSetter(TreeMultiset.class, "range").set(this, GeneralRange.all(comparator));
/* 923:    */     
/* 924:    */ 
/* 925:974 */     Serialization.getFieldSetter(TreeMultiset.class, "rootReference").set(this, new Reference(null));
/* 926:    */     
/* 927:    */ 
/* 928:977 */     AvlNode<E> header = new AvlNode(null, 1);
/* 929:978 */     Serialization.getFieldSetter(TreeMultiset.class, "header").set(this, header);
/* 930:979 */     successor(header, header);
/* 931:980 */     Serialization.populateMultiset(this, stream);
/* 932:    */   }
/* 933:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.TreeMultiset
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.util.AbstractMap;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.NavigableMap;
/*   8:    */ import java.util.NavigableSet;
/*   9:    */ import java.util.NoSuchElementException;
/*  10:    */ import java.util.Set;
/*  11:    */ import java.util.SortedMap;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ abstract class AbstractNavigableMap<K, V>
/*  15:    */   extends AbstractMap<K, V>
/*  16:    */   implements NavigableMap<K, V>
/*  17:    */ {
/*  18:    */   @Nullable
/*  19:    */   public abstract V get(@Nullable Object paramObject);
/*  20:    */   
/*  21:    */   @Nullable
/*  22:    */   public Map.Entry<K, V> firstEntry()
/*  23:    */   {
/*  24: 44 */     return (Map.Entry)Iterators.getNext(entryIterator(), null);
/*  25:    */   }
/*  26:    */   
/*  27:    */   @Nullable
/*  28:    */   public Map.Entry<K, V> lastEntry()
/*  29:    */   {
/*  30: 50 */     return (Map.Entry)Iterators.getNext(descendingEntryIterator(), null);
/*  31:    */   }
/*  32:    */   
/*  33:    */   @Nullable
/*  34:    */   public Map.Entry<K, V> pollFirstEntry()
/*  35:    */   {
/*  36: 56 */     return (Map.Entry)Iterators.pollNext(entryIterator());
/*  37:    */   }
/*  38:    */   
/*  39:    */   @Nullable
/*  40:    */   public Map.Entry<K, V> pollLastEntry()
/*  41:    */   {
/*  42: 62 */     return (Map.Entry)Iterators.pollNext(descendingEntryIterator());
/*  43:    */   }
/*  44:    */   
/*  45:    */   public K firstKey()
/*  46:    */   {
/*  47: 67 */     Map.Entry<K, V> entry = firstEntry();
/*  48: 68 */     if (entry == null) {
/*  49: 69 */       throw new NoSuchElementException();
/*  50:    */     }
/*  51: 71 */     return entry.getKey();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public K lastKey()
/*  55:    */   {
/*  56: 77 */     Map.Entry<K, V> entry = lastEntry();
/*  57: 78 */     if (entry == null) {
/*  58: 79 */       throw new NoSuchElementException();
/*  59:    */     }
/*  60: 81 */     return entry.getKey();
/*  61:    */   }
/*  62:    */   
/*  63:    */   @Nullable
/*  64:    */   public Map.Entry<K, V> lowerEntry(K key)
/*  65:    */   {
/*  66: 88 */     return headMap(key, false).lastEntry();
/*  67:    */   }
/*  68:    */   
/*  69:    */   @Nullable
/*  70:    */   public Map.Entry<K, V> floorEntry(K key)
/*  71:    */   {
/*  72: 94 */     return headMap(key, true).lastEntry();
/*  73:    */   }
/*  74:    */   
/*  75:    */   @Nullable
/*  76:    */   public Map.Entry<K, V> ceilingEntry(K key)
/*  77:    */   {
/*  78:100 */     return tailMap(key, true).firstEntry();
/*  79:    */   }
/*  80:    */   
/*  81:    */   @Nullable
/*  82:    */   public Map.Entry<K, V> higherEntry(K key)
/*  83:    */   {
/*  84:106 */     return tailMap(key, false).firstEntry();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public K lowerKey(K key)
/*  88:    */   {
/*  89:111 */     return Maps.keyOrNull(lowerEntry(key));
/*  90:    */   }
/*  91:    */   
/*  92:    */   public K floorKey(K key)
/*  93:    */   {
/*  94:116 */     return Maps.keyOrNull(floorEntry(key));
/*  95:    */   }
/*  96:    */   
/*  97:    */   public K ceilingKey(K key)
/*  98:    */   {
/*  99:121 */     return Maps.keyOrNull(ceilingEntry(key));
/* 100:    */   }
/* 101:    */   
/* 102:    */   public K higherKey(K key)
/* 103:    */   {
/* 104:126 */     return Maps.keyOrNull(higherEntry(key));
/* 105:    */   }
/* 106:    */   
/* 107:    */   abstract Iterator<Map.Entry<K, V>> entryIterator();
/* 108:    */   
/* 109:    */   abstract Iterator<Map.Entry<K, V>> descendingEntryIterator();
/* 110:    */   
/* 111:    */   public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 112:    */   {
/* 113:135 */     return subMap(fromKey, true, toKey, false);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public SortedMap<K, V> headMap(K toKey)
/* 117:    */   {
/* 118:140 */     return headMap(toKey, false);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public SortedMap<K, V> tailMap(K fromKey)
/* 122:    */   {
/* 123:145 */     return tailMap(fromKey, true);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public NavigableSet<K> navigableKeySet()
/* 127:    */   {
/* 128:150 */     return new Maps.NavigableKeySet(this);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Set<K> keySet()
/* 132:    */   {
/* 133:155 */     return navigableKeySet();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public abstract int size();
/* 137:    */   
/* 138:    */   public Set<Map.Entry<K, V>> entrySet()
/* 139:    */   {
/* 140:163 */     new Maps.EntrySet()
/* 141:    */     {
/* 142:    */       Map<K, V> map()
/* 143:    */       {
/* 144:166 */         return AbstractNavigableMap.this;
/* 145:    */       }
/* 146:    */       
/* 147:    */       public Iterator<Map.Entry<K, V>> iterator()
/* 148:    */       {
/* 149:171 */         return AbstractNavigableMap.this.entryIterator();
/* 150:    */       }
/* 151:    */     };
/* 152:    */   }
/* 153:    */   
/* 154:    */   public NavigableSet<K> descendingKeySet()
/* 155:    */   {
/* 156:178 */     return descendingMap().navigableKeySet();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public NavigableMap<K, V> descendingMap()
/* 160:    */   {
/* 161:183 */     return new DescendingMap(null);
/* 162:    */   }
/* 163:    */   
/* 164:    */   private final class DescendingMap
/* 165:    */     extends Maps.DescendingMap<K, V>
/* 166:    */   {
/* 167:    */     private DescendingMap() {}
/* 168:    */     
/* 169:    */     NavigableMap<K, V> forward()
/* 170:    */     {
/* 171:189 */       return AbstractNavigableMap.this;
/* 172:    */     }
/* 173:    */     
/* 174:    */     Iterator<Map.Entry<K, V>> entryIterator()
/* 175:    */     {
/* 176:194 */       return AbstractNavigableMap.this.descendingEntryIterator();
/* 177:    */     }
/* 178:    */   }
/* 179:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractNavigableMap
 * JD-Core Version:    0.7.0.1
 */
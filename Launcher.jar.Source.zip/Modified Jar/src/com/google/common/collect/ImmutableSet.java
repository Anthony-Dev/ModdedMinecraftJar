/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.EnumSet;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableSet<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements Set<E>
/*  18:    */ {
/*  19:    */   static final int MAX_TABLE_SIZE = 1073741824;
/*  20:    */   private static final double DESIRED_LOAD_FACTOR = 0.7D;
/*  21:    */   private static final int CUTOFF = 751619276;
/*  22:    */   
/*  23:    */   public static <E> ImmutableSet<E> of()
/*  24:    */   {
/*  25: 84 */     return EmptyImmutableSet.INSTANCE;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <E> ImmutableSet<E> of(E element)
/*  29:    */   {
/*  30: 94 */     return new SingletonImmutableSet(element);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <E> ImmutableSet<E> of(E e1, E e2)
/*  34:    */   {
/*  35:105 */     return construct(2, new Object[] { e1, e2 });
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3)
/*  39:    */   {
/*  40:116 */     return construct(3, new Object[] { e1, e2, e3 });
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4)
/*  44:    */   {
/*  45:127 */     return construct(4, new Object[] { e1, e2, e3, e4 });
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*  49:    */   {
/*  50:138 */     return construct(5, new Object[] { e1, e2, e3, e4, e5 });
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others)
/*  54:    */   {
/*  55:151 */     int paramCount = 6;
/*  56:152 */     Object[] elements = new Object[6 + others.length];
/*  57:153 */     elements[0] = e1;
/*  58:154 */     elements[1] = e2;
/*  59:155 */     elements[2] = e3;
/*  60:156 */     elements[3] = e4;
/*  61:157 */     elements[4] = e5;
/*  62:158 */     elements[5] = e6;
/*  63:159 */     System.arraycopy(others, 0, elements, 6, others.length);
/*  64:160 */     return construct(elements.length, elements);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static <E> ImmutableSet<E> construct(int n, Object... elements)
/*  68:    */   {
/*  69:179 */     switch (n)
/*  70:    */     {
/*  71:    */     case 0: 
/*  72:181 */       return of();
/*  73:    */     case 1: 
/*  74:184 */       E elem = elements[0];
/*  75:185 */       return of(elem);
/*  76:    */     }
/*  77:189 */     int tableSize = chooseTableSize(n);
/*  78:190 */     Object[] table = new Object[tableSize];
/*  79:191 */     int mask = tableSize - 1;
/*  80:192 */     int hashCode = 0;
/*  81:193 */     int uniques = 0;
/*  82:194 */     for (int i = 0; i < n; i++)
/*  83:    */     {
/*  84:195 */       Object element = ObjectArrays.checkElementNotNull(elements[i], i);
/*  85:196 */       int hash = element.hashCode();
/*  86:197 */       for (int j = Hashing.smear(hash);; j++)
/*  87:    */       {
/*  88:198 */         int index = j & mask;
/*  89:199 */         Object value = table[index];
/*  90:200 */         if (value == null)
/*  91:    */         {
/*  92:202 */           elements[(uniques++)] = element;
/*  93:203 */           table[index] = element;
/*  94:204 */           hashCode += hash;
/*  95:    */         }
/*  96:    */         else
/*  97:    */         {
/*  98:206 */           if (value.equals(element)) {
/*  99:    */             break;
/* 100:    */           }
/* 101:    */         }
/* 102:    */       }
/* 103:    */     }
/* 104:211 */     Arrays.fill(elements, uniques, n, null);
/* 105:212 */     if (uniques == 1)
/* 106:    */     {
/* 107:215 */       E element = elements[0];
/* 108:216 */       return new SingletonImmutableSet(element, hashCode);
/* 109:    */     }
/* 110:217 */     if (tableSize != chooseTableSize(uniques)) {
/* 111:220 */       return construct(uniques, elements);
/* 112:    */     }
/* 113:222 */     Object[] uniqueElements = uniques < elements.length ? ObjectArrays.arraysCopyOf(elements, uniques) : elements;
/* 114:    */     
/* 115:    */ 
/* 116:225 */     return new RegularImmutableSet(uniqueElements, hashCode, table, mask);
/* 117:    */   }
/* 118:    */   
/* 119:    */   @VisibleForTesting
/* 120:    */   static int chooseTableSize(int setSize)
/* 121:    */   {
/* 122:249 */     if (setSize < 751619276)
/* 123:    */     {
/* 124:251 */       int tableSize = Integer.highestOneBit(setSize - 1) << 1;
/* 125:252 */       while (tableSize * 0.7D < setSize) {
/* 126:253 */         tableSize <<= 1;
/* 127:    */       }
/* 128:255 */       return tableSize;
/* 129:    */     }
/* 130:259 */     Preconditions.checkArgument(setSize < 1073741824, "collection too large");
/* 131:260 */     return 1073741824;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static <E> ImmutableSet<E> copyOf(E[] elements)
/* 135:    */   {
/* 136:272 */     switch (elements.length)
/* 137:    */     {
/* 138:    */     case 0: 
/* 139:274 */       return of();
/* 140:    */     case 1: 
/* 141:276 */       return of(elements[0]);
/* 142:    */     }
/* 143:278 */     return construct(elements.length, (Object[])elements.clone());
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static <E> ImmutableSet<E> copyOf(Iterable<? extends E> elements)
/* 147:    */   {
/* 148:300 */     return (elements instanceof Collection) ? copyOf(Collections2.cast(elements)) : copyOf(elements.iterator());
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static <E> ImmutableSet<E> copyOf(Iterator<? extends E> elements)
/* 152:    */   {
/* 153:314 */     if (!elements.hasNext()) {
/* 154:315 */       return of();
/* 155:    */     }
/* 156:317 */     E first = elements.next();
/* 157:318 */     if (!elements.hasNext()) {
/* 158:319 */       return of(first);
/* 159:    */     }
/* 160:321 */     return new Builder().add(first).addAll(elements).build();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static <E> ImmutableSet<E> copyOf(Collection<? extends E> elements)
/* 164:    */   {
/* 165:364 */     if (((elements instanceof ImmutableSet)) && (!(elements instanceof ImmutableSortedSet)))
/* 166:    */     {
/* 167:367 */       ImmutableSet<E> set = (ImmutableSet)elements;
/* 168:368 */       if (!set.isPartialView()) {
/* 169:369 */         return set;
/* 170:    */       }
/* 171:    */     }
/* 172:371 */     else if ((elements instanceof EnumSet))
/* 173:    */     {
/* 174:372 */       return copyOfEnumSet((EnumSet)elements);
/* 175:    */     }
/* 176:374 */     Object[] array = elements.toArray();
/* 177:375 */     return construct(array.length, array);
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static <E extends Enum<E>> ImmutableSet<E> copyOfEnumSet(EnumSet<E> enumSet)
/* 181:    */   {
/* 182:380 */     return ImmutableEnumSet.asImmutable(EnumSet.copyOf(enumSet));
/* 183:    */   }
/* 184:    */   
/* 185:    */   boolean isHashCodeFast()
/* 186:    */   {
/* 187:387 */     return false;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public boolean equals(@Nullable Object object)
/* 191:    */   {
/* 192:391 */     if (object == this) {
/* 193:392 */       return true;
/* 194:    */     }
/* 195:393 */     if (((object instanceof ImmutableSet)) && (isHashCodeFast()) && (((ImmutableSet)object).isHashCodeFast()) && (hashCode() != object.hashCode())) {
/* 196:397 */       return false;
/* 197:    */     }
/* 198:399 */     return Sets.equalsImpl(this, object);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public int hashCode()
/* 202:    */   {
/* 203:403 */     return Sets.hashCodeImpl(this);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public abstract UnmodifiableIterator<E> iterator();
/* 207:    */   
/* 208:    */   private static class SerializedForm
/* 209:    */     implements Serializable
/* 210:    */   {
/* 211:    */     final Object[] elements;
/* 212:    */     private static final long serialVersionUID = 0L;
/* 213:    */     
/* 214:    */     SerializedForm(Object[] elements)
/* 215:    */     {
/* 216:420 */       this.elements = elements;
/* 217:    */     }
/* 218:    */     
/* 219:    */     Object readResolve()
/* 220:    */     {
/* 221:423 */       return ImmutableSet.copyOf(this.elements);
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   Object writeReplace()
/* 226:    */   {
/* 227:429 */     return new SerializedForm(toArray());
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static <E> Builder<E> builder()
/* 231:    */   {
/* 232:437 */     return new Builder();
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static class Builder<E>
/* 236:    */     extends ImmutableCollection.ArrayBasedBuilder<E>
/* 237:    */   {
/* 238:    */     public Builder()
/* 239:    */     {
/* 240:463 */       this(4);
/* 241:    */     }
/* 242:    */     
/* 243:    */     Builder(int capacity)
/* 244:    */     {
/* 245:467 */       super();
/* 246:    */     }
/* 247:    */     
/* 248:    */     public Builder<E> add(E element)
/* 249:    */     {
/* 250:480 */       super.add(element);
/* 251:481 */       return this;
/* 252:    */     }
/* 253:    */     
/* 254:    */     public Builder<E> add(E... elements)
/* 255:    */     {
/* 256:494 */       super.add(elements);
/* 257:495 */       return this;
/* 258:    */     }
/* 259:    */     
/* 260:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 261:    */     {
/* 262:508 */       super.addAll(elements);
/* 263:509 */       return this;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 267:    */     {
/* 268:522 */       super.addAll(elements);
/* 269:523 */       return this;
/* 270:    */     }
/* 271:    */     
/* 272:    */     public ImmutableSet<E> build()
/* 273:    */     {
/* 274:531 */       ImmutableSet<E> result = ImmutableSet.construct(this.size, this.contents);
/* 275:    */       
/* 276:    */ 
/* 277:534 */       this.size = result.size();
/* 278:535 */       return result;
/* 279:    */     }
/* 280:    */   }
/* 281:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSet
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ final class EmptyImmutableSortedMultiset<E>
/*   9:    */   extends ImmutableSortedMultiset<E>
/*  10:    */ {
/*  11:    */   private final ImmutableSortedSet<E> elementSet;
/*  12:    */   
/*  13:    */   EmptyImmutableSortedMultiset(Comparator<? super E> comparator)
/*  14:    */   {
/*  15: 34 */     this.elementSet = ImmutableSortedSet.emptySet(comparator);
/*  16:    */   }
/*  17:    */   
/*  18:    */   public Multiset.Entry<E> firstEntry()
/*  19:    */   {
/*  20: 39 */     return null;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public Multiset.Entry<E> lastEntry()
/*  24:    */   {
/*  25: 44 */     return null;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public int count(@Nullable Object element)
/*  29:    */   {
/*  30: 49 */     return 0;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean containsAll(Collection<?> targets)
/*  34:    */   {
/*  35: 54 */     return targets.isEmpty();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int size()
/*  39:    */   {
/*  40: 59 */     return 0;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public ImmutableSortedSet<E> elementSet()
/*  44:    */   {
/*  45: 64 */     return this.elementSet;
/*  46:    */   }
/*  47:    */   
/*  48:    */   Multiset.Entry<E> getEntry(int index)
/*  49:    */   {
/*  50: 69 */     throw new AssertionError("should never be called");
/*  51:    */   }
/*  52:    */   
/*  53:    */   public ImmutableSortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/*  54:    */   {
/*  55: 74 */     Preconditions.checkNotNull(upperBound);
/*  56: 75 */     Preconditions.checkNotNull(boundType);
/*  57: 76 */     return this;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public ImmutableSortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/*  61:    */   {
/*  62: 81 */     Preconditions.checkNotNull(lowerBound);
/*  63: 82 */     Preconditions.checkNotNull(boundType);
/*  64: 83 */     return this;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public UnmodifiableIterator<E> iterator()
/*  68:    */   {
/*  69: 88 */     return Iterators.emptyIterator();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean equals(@Nullable Object object)
/*  73:    */   {
/*  74: 93 */     if ((object instanceof Multiset))
/*  75:    */     {
/*  76: 94 */       Multiset<?> other = (Multiset)object;
/*  77: 95 */       return other.isEmpty();
/*  78:    */     }
/*  79: 97 */     return false;
/*  80:    */   }
/*  81:    */   
/*  82:    */   boolean isPartialView()
/*  83:    */   {
/*  84:102 */     return false;
/*  85:    */   }
/*  86:    */   
/*  87:    */   int copyIntoArray(Object[] dst, int offset)
/*  88:    */   {
/*  89:107 */     return offset;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public ImmutableList<E> asList()
/*  93:    */   {
/*  94:112 */     return ImmutableList.of();
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */
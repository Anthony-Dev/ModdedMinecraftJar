/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.Set;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible(serializable=true, emulated=true)
/*  10:    */ final class SingletonImmutableSet<E>
/*  11:    */   extends ImmutableSet<E>
/*  12:    */ {
/*  13:    */   final transient E element;
/*  14:    */   private transient int cachedHashCode;
/*  15:    */   
/*  16:    */   SingletonImmutableSet(E element)
/*  17:    */   {
/*  18: 47 */     this.element = Preconditions.checkNotNull(element);
/*  19:    */   }
/*  20:    */   
/*  21:    */   SingletonImmutableSet(E element, int hashCode)
/*  22:    */   {
/*  23: 52 */     this.element = element;
/*  24: 53 */     this.cachedHashCode = hashCode;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public int size()
/*  28:    */   {
/*  29: 58 */     return 1;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public boolean isEmpty()
/*  33:    */   {
/*  34: 62 */     return false;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean contains(Object target)
/*  38:    */   {
/*  39: 66 */     return this.element.equals(target);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public UnmodifiableIterator<E> iterator()
/*  43:    */   {
/*  44: 70 */     return Iterators.singletonIterator(this.element);
/*  45:    */   }
/*  46:    */   
/*  47:    */   boolean isPartialView()
/*  48:    */   {
/*  49: 74 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   int copyIntoArray(Object[] dst, int offset)
/*  53:    */   {
/*  54: 79 */     dst[offset] = this.element;
/*  55: 80 */     return offset + 1;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean equals(@Nullable Object object)
/*  59:    */   {
/*  60: 84 */     if (object == this) {
/*  61: 85 */       return true;
/*  62:    */     }
/*  63: 87 */     if ((object instanceof Set))
/*  64:    */     {
/*  65: 88 */       Set<?> that = (Set)object;
/*  66: 89 */       return (that.size() == 1) && (this.element.equals(that.iterator().next()));
/*  67:    */     }
/*  68: 91 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public final int hashCode()
/*  72:    */   {
/*  73: 96 */     int code = this.cachedHashCode;
/*  74: 97 */     if (code == 0) {
/*  75: 98 */       this.cachedHashCode = (code = this.element.hashCode());
/*  76:    */     }
/*  77:100 */     return code;
/*  78:    */   }
/*  79:    */   
/*  80:    */   boolean isHashCodeFast()
/*  81:    */   {
/*  82:104 */     return this.cachedHashCode != 0;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String toString()
/*  86:    */   {
/*  87:108 */     String elementToString = this.element.toString();
/*  88:109 */     return elementToString.length() + 2 + '[' + elementToString + ']';
/*  89:    */   }
/*  90:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableSet
 * JD-Core Version:    0.7.0.1
 */
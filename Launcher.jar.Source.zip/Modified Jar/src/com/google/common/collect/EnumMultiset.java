/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.EnumMap;
/*  10:    */ import java.util.Iterator;
/*  11:    */ 
/*  12:    */ @GwtCompatible(emulated=true)
/*  13:    */ public final class EnumMultiset<E extends Enum<E>>
/*  14:    */   extends AbstractMapBasedMultiset<E>
/*  15:    */ {
/*  16:    */   private transient Class<E> type;
/*  17:    */   @GwtIncompatible("Not needed in emulated source")
/*  18:    */   private static final long serialVersionUID = 0L;
/*  19:    */   
/*  20:    */   public static <E extends Enum<E>> EnumMultiset<E> create(Class<E> type)
/*  21:    */   {
/*  22: 42 */     return new EnumMultiset(type);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <E extends Enum<E>> EnumMultiset<E> create(Iterable<E> elements)
/*  26:    */   {
/*  27: 55 */     Iterator<E> iterator = elements.iterator();
/*  28: 56 */     Preconditions.checkArgument(iterator.hasNext(), "EnumMultiset constructor passed empty Iterable");
/*  29: 57 */     EnumMultiset<E> multiset = new EnumMultiset(((Enum)iterator.next()).getDeclaringClass());
/*  30: 58 */     Iterables.addAll(multiset, elements);
/*  31: 59 */     return multiset;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E extends Enum<E>> EnumMultiset<E> create(Iterable<E> elements, Class<E> type)
/*  35:    */   {
/*  36: 70 */     EnumMultiset<E> result = create(type);
/*  37: 71 */     Iterables.addAll(result, elements);
/*  38: 72 */     return result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private EnumMultiset(Class<E> type)
/*  42:    */   {
/*  43: 79 */     super(WellBehavedMap.wrap(new EnumMap(type)));
/*  44: 80 */     this.type = type;
/*  45:    */   }
/*  46:    */   
/*  47:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  48:    */   private void writeObject(ObjectOutputStream stream)
/*  49:    */     throws IOException
/*  50:    */   {
/*  51: 85 */     stream.defaultWriteObject();
/*  52: 86 */     stream.writeObject(this.type);
/*  53: 87 */     Serialization.writeMultiset(this, stream);
/*  54:    */   }
/*  55:    */   
/*  56:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  57:    */   private void readObject(ObjectInputStream stream)
/*  58:    */     throws IOException, ClassNotFoundException
/*  59:    */   {
/*  60: 97 */     stream.defaultReadObject();
/*  61:    */     
/*  62: 99 */     Class<E> localType = (Class)stream.readObject();
/*  63:100 */     this.type = localType;
/*  64:101 */     setBackingMap(WellBehavedMap.wrap(new EnumMap(this.type)));
/*  65:102 */     Serialization.populateMultiset(this, stream);
/*  66:    */   }
/*  67:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EnumMultiset
 * JD-Core Version:    0.7.0.1
 */
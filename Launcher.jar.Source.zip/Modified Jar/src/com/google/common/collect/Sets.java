/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Predicate;
/*    7:     */ import com.google.common.base.Predicates;
/*    8:     */ import java.io.Serializable;
/*    9:     */ import java.util.AbstractSet;
/*   10:     */ import java.util.Arrays;
/*   11:     */ import java.util.Collection;
/*   12:     */ import java.util.Collections;
/*   13:     */ import java.util.Comparator;
/*   14:     */ import java.util.EnumSet;
/*   15:     */ import java.util.HashSet;
/*   16:     */ import java.util.Iterator;
/*   17:     */ import java.util.LinkedHashSet;
/*   18:     */ import java.util.List;
/*   19:     */ import java.util.Map;
/*   20:     */ import java.util.NavigableSet;
/*   21:     */ import java.util.NoSuchElementException;
/*   22:     */ import java.util.Set;
/*   23:     */ import java.util.SortedSet;
/*   24:     */ import java.util.TreeSet;
/*   25:     */ import java.util.concurrent.ConcurrentHashMap;
/*   26:     */ import java.util.concurrent.CopyOnWriteArraySet;
/*   27:     */ import javax.annotation.Nullable;
/*   28:     */ 
/*   29:     */ @GwtCompatible(emulated=true)
/*   30:     */ public final class Sets
/*   31:     */ {
/*   32:     */   static abstract class ImprovedAbstractSet<E>
/*   33:     */     extends AbstractSet<E>
/*   34:     */   {
/*   35:     */     public boolean removeAll(Collection<?> c)
/*   36:     */     {
/*   37:  74 */       return Sets.removeAllImpl(this, c);
/*   38:     */     }
/*   39:     */     
/*   40:     */     public boolean retainAll(Collection<?> c)
/*   41:     */     {
/*   42:  79 */       return super.retainAll((Collection)Preconditions.checkNotNull(c));
/*   43:     */     }
/*   44:     */   }
/*   45:     */   
/*   46:     */   @GwtCompatible(serializable=true)
/*   47:     */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(E anElement, E... otherElements)
/*   48:     */   {
/*   49:  98 */     return ImmutableEnumSet.asImmutable(EnumSet.of(anElement, otherElements));
/*   50:     */   }
/*   51:     */   
/*   52:     */   @GwtCompatible(serializable=true)
/*   53:     */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(Iterable<E> elements)
/*   54:     */   {
/*   55: 116 */     if ((elements instanceof ImmutableEnumSet)) {
/*   56: 117 */       return (ImmutableEnumSet)elements;
/*   57:     */     }
/*   58: 118 */     if ((elements instanceof Collection))
/*   59:     */     {
/*   60: 119 */       Collection<E> collection = (Collection)elements;
/*   61: 120 */       if (collection.isEmpty()) {
/*   62: 121 */         return ImmutableSet.of();
/*   63:     */       }
/*   64: 123 */       return ImmutableEnumSet.asImmutable(EnumSet.copyOf(collection));
/*   65:     */     }
/*   66: 126 */     Iterator<E> itr = elements.iterator();
/*   67: 127 */     if (itr.hasNext())
/*   68:     */     {
/*   69: 128 */       EnumSet<E> enumSet = EnumSet.of((Enum)itr.next());
/*   70: 129 */       Iterators.addAll(enumSet, itr);
/*   71: 130 */       return ImmutableEnumSet.asImmutable(enumSet);
/*   72:     */     }
/*   73: 132 */     return ImmutableSet.of();
/*   74:     */   }
/*   75:     */   
/*   76:     */   public static <E extends Enum<E>> EnumSet<E> newEnumSet(Iterable<E> iterable, Class<E> elementType)
/*   77:     */   {
/*   78: 145 */     EnumSet<E> set = EnumSet.noneOf(elementType);
/*   79: 146 */     Iterables.addAll(set, iterable);
/*   80: 147 */     return set;
/*   81:     */   }
/*   82:     */   
/*   83:     */   public static <E> HashSet<E> newHashSet()
/*   84:     */   {
/*   85: 164 */     return new HashSet();
/*   86:     */   }
/*   87:     */   
/*   88:     */   public static <E> HashSet<E> newHashSet(E... elements)
/*   89:     */   {
/*   90: 182 */     HashSet<E> set = newHashSetWithExpectedSize(elements.length);
/*   91: 183 */     Collections.addAll(set, elements);
/*   92: 184 */     return set;
/*   93:     */   }
/*   94:     */   
/*   95:     */   public static <E> HashSet<E> newHashSetWithExpectedSize(int expectedSize)
/*   96:     */   {
/*   97: 201 */     return new HashSet(Maps.capacity(expectedSize));
/*   98:     */   }
/*   99:     */   
/*  100:     */   public static <E> HashSet<E> newHashSet(Iterable<? extends E> elements)
/*  101:     */   {
/*  102: 218 */     return (elements instanceof Collection) ? new HashSet(Collections2.cast(elements)) : newHashSet(elements.iterator());
/*  103:     */   }
/*  104:     */   
/*  105:     */   public static <E> HashSet<E> newHashSet(Iterator<? extends E> elements)
/*  106:     */   {
/*  107: 237 */     HashSet<E> set = newHashSet();
/*  108: 238 */     Iterators.addAll(set, elements);
/*  109: 239 */     return set;
/*  110:     */   }
/*  111:     */   
/*  112:     */   public static <E> Set<E> newConcurrentHashSet()
/*  113:     */   {
/*  114: 254 */     return newSetFromMap(new ConcurrentHashMap());
/*  115:     */   }
/*  116:     */   
/*  117:     */   public static <E> Set<E> newConcurrentHashSet(Iterable<? extends E> elements)
/*  118:     */   {
/*  119: 273 */     Set<E> set = newConcurrentHashSet();
/*  120: 274 */     Iterables.addAll(set, elements);
/*  121: 275 */     return set;
/*  122:     */   }
/*  123:     */   
/*  124:     */   public static <E> LinkedHashSet<E> newLinkedHashSet()
/*  125:     */   {
/*  126: 289 */     return new LinkedHashSet();
/*  127:     */   }
/*  128:     */   
/*  129:     */   public static <E> LinkedHashSet<E> newLinkedHashSetWithExpectedSize(int expectedSize)
/*  130:     */   {
/*  131: 308 */     return new LinkedHashSet(Maps.capacity(expectedSize));
/*  132:     */   }
/*  133:     */   
/*  134:     */   public static <E> LinkedHashSet<E> newLinkedHashSet(Iterable<? extends E> elements)
/*  135:     */   {
/*  136: 324 */     if ((elements instanceof Collection)) {
/*  137: 325 */       return new LinkedHashSet(Collections2.cast(elements));
/*  138:     */     }
/*  139: 327 */     LinkedHashSet<E> set = newLinkedHashSet();
/*  140: 328 */     Iterables.addAll(set, elements);
/*  141: 329 */     return set;
/*  142:     */   }
/*  143:     */   
/*  144:     */   public static <E extends Comparable> TreeSet<E> newTreeSet()
/*  145:     */   {
/*  146: 344 */     return new TreeSet();
/*  147:     */   }
/*  148:     */   
/*  149:     */   public static <E extends Comparable> TreeSet<E> newTreeSet(Iterable<? extends E> elements)
/*  150:     */   {
/*  151: 364 */     TreeSet<E> set = newTreeSet();
/*  152: 365 */     Iterables.addAll(set, elements);
/*  153: 366 */     return set;
/*  154:     */   }
/*  155:     */   
/*  156:     */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator)
/*  157:     */   {
/*  158: 381 */     return new TreeSet((Comparator)Preconditions.checkNotNull(comparator));
/*  159:     */   }
/*  160:     */   
/*  161:     */   public static <E> Set<E> newIdentityHashSet()
/*  162:     */   {
/*  163: 395 */     return newSetFromMap(Maps.newIdentityHashMap());
/*  164:     */   }
/*  165:     */   
/*  166:     */   @GwtIncompatible("CopyOnWriteArraySet")
/*  167:     */   public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet()
/*  168:     */   {
/*  169: 409 */     return new CopyOnWriteArraySet();
/*  170:     */   }
/*  171:     */   
/*  172:     */   @GwtIncompatible("CopyOnWriteArraySet")
/*  173:     */   public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet(Iterable<? extends E> elements)
/*  174:     */   {
/*  175: 424 */     Collection<? extends E> elementsCollection = (elements instanceof Collection) ? Collections2.cast(elements) : Lists.newArrayList(elements);
/*  176:     */     
/*  177:     */ 
/*  178: 427 */     return new CopyOnWriteArraySet(elementsCollection);
/*  179:     */   }
/*  180:     */   
/*  181:     */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection)
/*  182:     */   {
/*  183: 447 */     if ((collection instanceof EnumSet)) {
/*  184: 448 */       return EnumSet.complementOf((EnumSet)collection);
/*  185:     */     }
/*  186: 450 */     Preconditions.checkArgument(!collection.isEmpty(), "collection is empty; use the other version of this method");
/*  187:     */     
/*  188: 452 */     Class<E> type = ((Enum)collection.iterator().next()).getDeclaringClass();
/*  189: 453 */     return makeComplementByHand(collection, type);
/*  190:     */   }
/*  191:     */   
/*  192:     */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection, Class<E> type)
/*  193:     */   {
/*  194: 470 */     Preconditions.checkNotNull(collection);
/*  195: 471 */     return (collection instanceof EnumSet) ? EnumSet.complementOf((EnumSet)collection) : makeComplementByHand(collection, type);
/*  196:     */   }
/*  197:     */   
/*  198:     */   private static <E extends Enum<E>> EnumSet<E> makeComplementByHand(Collection<E> collection, Class<E> type)
/*  199:     */   {
/*  200: 478 */     EnumSet<E> result = EnumSet.allOf(type);
/*  201: 479 */     result.removeAll(collection);
/*  202: 480 */     return result;
/*  203:     */   }
/*  204:     */   
/*  205:     */   public static <E> Set<E> newSetFromMap(Map<E, Boolean> map)
/*  206:     */   {
/*  207: 515 */     return Platform.newSetFromMap(map);
/*  208:     */   }
/*  209:     */   
/*  210:     */   public static abstract class SetView<E>
/*  211:     */     extends AbstractSet<E>
/*  212:     */   {
/*  213:     */     public ImmutableSet<E> immutableCopy()
/*  214:     */     {
/*  215: 541 */       return ImmutableSet.copyOf(this);
/*  216:     */     }
/*  217:     */     
/*  218:     */     public <S extends Set<E>> S copyInto(S set)
/*  219:     */     {
/*  220: 554 */       set.addAll(this);
/*  221: 555 */       return set;
/*  222:     */     }
/*  223:     */   }
/*  224:     */   
/*  225:     */   public static <E> SetView<E> union(Set<? extends E> set1, final Set<? extends E> set2)
/*  226:     */   {
/*  227: 581 */     Preconditions.checkNotNull(set1, "set1");
/*  228: 582 */     Preconditions.checkNotNull(set2, "set2");
/*  229:     */     
/*  230: 584 */     final Set<? extends E> set2minus1 = difference(set2, set1);
/*  231:     */     
/*  232: 586 */     new SetView(set1)
/*  233:     */     {
/*  234:     */       public int size()
/*  235:     */       {
/*  236: 588 */         return this.val$set1.size() + set2minus1.size();
/*  237:     */       }
/*  238:     */       
/*  239:     */       public boolean isEmpty()
/*  240:     */       {
/*  241: 591 */         return (this.val$set1.isEmpty()) && (set2.isEmpty());
/*  242:     */       }
/*  243:     */       
/*  244:     */       public Iterator<E> iterator()
/*  245:     */       {
/*  246: 594 */         return Iterators.unmodifiableIterator(Iterators.concat(this.val$set1.iterator(), set2minus1.iterator()));
/*  247:     */       }
/*  248:     */       
/*  249:     */       public boolean contains(Object object)
/*  250:     */       {
/*  251: 598 */         return (this.val$set1.contains(object)) || (set2.contains(object));
/*  252:     */       }
/*  253:     */       
/*  254:     */       public <S extends Set<E>> S copyInto(S set)
/*  255:     */       {
/*  256: 601 */         set.addAll(this.val$set1);
/*  257: 602 */         set.addAll(set2);
/*  258: 603 */         return set;
/*  259:     */       }
/*  260:     */       
/*  261:     */       public ImmutableSet<E> immutableCopy()
/*  262:     */       {
/*  263: 606 */         return new ImmutableSet.Builder().addAll(this.val$set1).addAll(set2).build();
/*  264:     */       }
/*  265:     */     };
/*  266:     */   }
/*  267:     */   
/*  268:     */   public static <E> SetView<E> intersection(Set<E> set1, final Set<?> set2)
/*  269:     */   {
/*  270: 640 */     Preconditions.checkNotNull(set1, "set1");
/*  271: 641 */     Preconditions.checkNotNull(set2, "set2");
/*  272:     */     
/*  273: 643 */     final Predicate<Object> inSet2 = Predicates.in(set2);
/*  274: 644 */     new SetView(set1)
/*  275:     */     {
/*  276:     */       public Iterator<E> iterator()
/*  277:     */       {
/*  278: 646 */         return Iterators.filter(this.val$set1.iterator(), inSet2);
/*  279:     */       }
/*  280:     */       
/*  281:     */       public int size()
/*  282:     */       {
/*  283: 649 */         return Iterators.size(iterator());
/*  284:     */       }
/*  285:     */       
/*  286:     */       public boolean isEmpty()
/*  287:     */       {
/*  288: 652 */         return !iterator().hasNext();
/*  289:     */       }
/*  290:     */       
/*  291:     */       public boolean contains(Object object)
/*  292:     */       {
/*  293: 655 */         return (this.val$set1.contains(object)) && (set2.contains(object));
/*  294:     */       }
/*  295:     */       
/*  296:     */       public boolean containsAll(Collection<?> collection)
/*  297:     */       {
/*  298: 658 */         return (this.val$set1.containsAll(collection)) && (set2.containsAll(collection));
/*  299:     */       }
/*  300:     */     };
/*  301:     */   }
/*  302:     */   
/*  303:     */   public static <E> SetView<E> difference(Set<E> set1, final Set<?> set2)
/*  304:     */   {
/*  305: 677 */     Preconditions.checkNotNull(set1, "set1");
/*  306: 678 */     Preconditions.checkNotNull(set2, "set2");
/*  307:     */     
/*  308: 680 */     final Predicate<Object> notInSet2 = Predicates.not(Predicates.in(set2));
/*  309: 681 */     new SetView(set1)
/*  310:     */     {
/*  311:     */       public Iterator<E> iterator()
/*  312:     */       {
/*  313: 683 */         return Iterators.filter(this.val$set1.iterator(), notInSet2);
/*  314:     */       }
/*  315:     */       
/*  316:     */       public int size()
/*  317:     */       {
/*  318: 686 */         return Iterators.size(iterator());
/*  319:     */       }
/*  320:     */       
/*  321:     */       public boolean isEmpty()
/*  322:     */       {
/*  323: 689 */         return set2.containsAll(this.val$set1);
/*  324:     */       }
/*  325:     */       
/*  326:     */       public boolean contains(Object element)
/*  327:     */       {
/*  328: 692 */         return (this.val$set1.contains(element)) && (!set2.contains(element));
/*  329:     */       }
/*  330:     */     };
/*  331:     */   }
/*  332:     */   
/*  333:     */   public static <E> SetView<E> symmetricDifference(Set<? extends E> set1, Set<? extends E> set2)
/*  334:     */   {
/*  335: 711 */     Preconditions.checkNotNull(set1, "set1");
/*  336: 712 */     Preconditions.checkNotNull(set2, "set2");
/*  337:     */     
/*  338:     */ 
/*  339: 715 */     return difference(union(set1, set2), intersection(set1, set2));
/*  340:     */   }
/*  341:     */   
/*  342:     */   public static <E> Set<E> filter(Set<E> unfiltered, Predicate<? super E> predicate)
/*  343:     */   {
/*  344: 747 */     if ((unfiltered instanceof SortedSet)) {
/*  345: 748 */       return filter((SortedSet)unfiltered, predicate);
/*  346:     */     }
/*  347: 750 */     if ((unfiltered instanceof FilteredSet))
/*  348:     */     {
/*  349: 753 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  350: 754 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  351:     */       
/*  352: 756 */       return new FilteredSet((Set)filtered.unfiltered, combinedPredicate);
/*  353:     */     }
/*  354: 760 */     return new FilteredSet((Set)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  355:     */   }
/*  356:     */   
/*  357:     */   private static class FilteredSet<E>
/*  358:     */     extends Collections2.FilteredCollection<E>
/*  359:     */     implements Set<E>
/*  360:     */   {
/*  361:     */     FilteredSet(Set<E> unfiltered, Predicate<? super E> predicate)
/*  362:     */     {
/*  363: 767 */       super(predicate);
/*  364:     */     }
/*  365:     */     
/*  366:     */     public boolean equals(@Nullable Object object)
/*  367:     */     {
/*  368: 771 */       return Sets.equalsImpl(this, object);
/*  369:     */     }
/*  370:     */     
/*  371:     */     public int hashCode()
/*  372:     */     {
/*  373: 775 */       return Sets.hashCodeImpl(this);
/*  374:     */     }
/*  375:     */   }
/*  376:     */   
/*  377:     */   public static <E> SortedSet<E> filter(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  378:     */   {
/*  379: 810 */     return Platform.setsFilterSortedSet(unfiltered, predicate);
/*  380:     */   }
/*  381:     */   
/*  382:     */   static <E> SortedSet<E> filterSortedIgnoreNavigable(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  383:     */   {
/*  384: 815 */     if ((unfiltered instanceof FilteredSet))
/*  385:     */     {
/*  386: 818 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  387: 819 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  388:     */       
/*  389: 821 */       return new FilteredSortedSet((SortedSet)filtered.unfiltered, combinedPredicate);
/*  390:     */     }
/*  391: 825 */     return new FilteredSortedSet((SortedSet)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  392:     */   }
/*  393:     */   
/*  394:     */   private static class FilteredSortedSet<E>
/*  395:     */     extends Sets.FilteredSet<E>
/*  396:     */     implements SortedSet<E>
/*  397:     */   {
/*  398:     */     FilteredSortedSet(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  399:     */     {
/*  400: 833 */       super(predicate);
/*  401:     */     }
/*  402:     */     
/*  403:     */     public Comparator<? super E> comparator()
/*  404:     */     {
/*  405: 838 */       return ((SortedSet)this.unfiltered).comparator();
/*  406:     */     }
/*  407:     */     
/*  408:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  409:     */     {
/*  410: 843 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).subSet(fromElement, toElement), this.predicate);
/*  411:     */     }
/*  412:     */     
/*  413:     */     public SortedSet<E> headSet(E toElement)
/*  414:     */     {
/*  415: 849 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).headSet(toElement), this.predicate);
/*  416:     */     }
/*  417:     */     
/*  418:     */     public SortedSet<E> tailSet(E fromElement)
/*  419:     */     {
/*  420: 854 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).tailSet(fromElement), this.predicate);
/*  421:     */     }
/*  422:     */     
/*  423:     */     public E first()
/*  424:     */     {
/*  425: 859 */       return iterator().next();
/*  426:     */     }
/*  427:     */     
/*  428:     */     public E last()
/*  429:     */     {
/*  430: 864 */       SortedSet<E> sortedUnfiltered = (SortedSet)this.unfiltered;
/*  431:     */       for (;;)
/*  432:     */       {
/*  433: 866 */         E element = sortedUnfiltered.last();
/*  434: 867 */         if (this.predicate.apply(element)) {
/*  435: 868 */           return element;
/*  436:     */         }
/*  437: 870 */         sortedUnfiltered = sortedUnfiltered.headSet(element);
/*  438:     */       }
/*  439:     */     }
/*  440:     */   }
/*  441:     */   
/*  442:     */   @GwtIncompatible("NavigableSet")
/*  443:     */   public static <E> NavigableSet<E> filter(NavigableSet<E> unfiltered, Predicate<? super E> predicate)
/*  444:     */   {
/*  445: 908 */     if ((unfiltered instanceof FilteredSet))
/*  446:     */     {
/*  447: 911 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  448: 912 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  449:     */       
/*  450: 914 */       return new FilteredNavigableSet((NavigableSet)filtered.unfiltered, combinedPredicate);
/*  451:     */     }
/*  452: 918 */     return new FilteredNavigableSet((NavigableSet)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  453:     */   }
/*  454:     */   
/*  455:     */   @GwtIncompatible("NavigableSet")
/*  456:     */   private static class FilteredNavigableSet<E>
/*  457:     */     extends Sets.FilteredSortedSet<E>
/*  458:     */     implements NavigableSet<E>
/*  459:     */   {
/*  460:     */     FilteredNavigableSet(NavigableSet<E> unfiltered, Predicate<? super E> predicate)
/*  461:     */     {
/*  462: 926 */       super(predicate);
/*  463:     */     }
/*  464:     */     
/*  465:     */     NavigableSet<E> unfiltered()
/*  466:     */     {
/*  467: 930 */       return (NavigableSet)this.unfiltered;
/*  468:     */     }
/*  469:     */     
/*  470:     */     @Nullable
/*  471:     */     public E lower(E e)
/*  472:     */     {
/*  473: 936 */       return Iterators.getNext(headSet(e, false).descendingIterator(), null);
/*  474:     */     }
/*  475:     */     
/*  476:     */     @Nullable
/*  477:     */     public E floor(E e)
/*  478:     */     {
/*  479: 942 */       return Iterators.getNext(headSet(e, true).descendingIterator(), null);
/*  480:     */     }
/*  481:     */     
/*  482:     */     public E ceiling(E e)
/*  483:     */     {
/*  484: 947 */       return Iterables.getFirst(tailSet(e, true), null);
/*  485:     */     }
/*  486:     */     
/*  487:     */     public E higher(E e)
/*  488:     */     {
/*  489: 952 */       return Iterables.getFirst(tailSet(e, false), null);
/*  490:     */     }
/*  491:     */     
/*  492:     */     public E pollFirst()
/*  493:     */     {
/*  494: 957 */       return Iterables.removeFirstMatching(unfiltered(), this.predicate);
/*  495:     */     }
/*  496:     */     
/*  497:     */     public E pollLast()
/*  498:     */     {
/*  499: 962 */       return Iterables.removeFirstMatching(unfiltered().descendingSet(), this.predicate);
/*  500:     */     }
/*  501:     */     
/*  502:     */     public NavigableSet<E> descendingSet()
/*  503:     */     {
/*  504: 967 */       return Sets.filter(unfiltered().descendingSet(), this.predicate);
/*  505:     */     }
/*  506:     */     
/*  507:     */     public Iterator<E> descendingIterator()
/*  508:     */     {
/*  509: 972 */       return Iterators.filter(unfiltered().descendingIterator(), this.predicate);
/*  510:     */     }
/*  511:     */     
/*  512:     */     public E last()
/*  513:     */     {
/*  514: 977 */       return descendingIterator().next();
/*  515:     */     }
/*  516:     */     
/*  517:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  518:     */     {
/*  519: 983 */       return Sets.filter(unfiltered().subSet(fromElement, fromInclusive, toElement, toInclusive), this.predicate);
/*  520:     */     }
/*  521:     */     
/*  522:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  523:     */     {
/*  524: 989 */       return Sets.filter(unfiltered().headSet(toElement, inclusive), this.predicate);
/*  525:     */     }
/*  526:     */     
/*  527:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  528:     */     {
/*  529: 994 */       return Sets.filter(unfiltered().tailSet(fromElement, inclusive), this.predicate);
/*  530:     */     }
/*  531:     */   }
/*  532:     */   
/*  533:     */   public static <B> Set<List<B>> cartesianProduct(List<? extends Set<? extends B>> sets)
/*  534:     */   {
/*  535:1055 */     return CartesianSet.create(sets);
/*  536:     */   }
/*  537:     */   
/*  538:     */   public static <B> Set<List<B>> cartesianProduct(Set<? extends B>... sets)
/*  539:     */   {
/*  540:1115 */     return cartesianProduct(Arrays.asList(sets));
/*  541:     */   }
/*  542:     */   
/*  543:     */   private static final class CartesianSet<E>
/*  544:     */     extends ForwardingCollection<List<E>>
/*  545:     */     implements Set<List<E>>
/*  546:     */   {
/*  547:     */     private final transient ImmutableList<ImmutableSet<E>> axes;
/*  548:     */     private final transient CartesianList<E> delegate;
/*  549:     */     
/*  550:     */     static <E> Set<List<E>> create(List<? extends Set<? extends E>> sets)
/*  551:     */     {
/*  552:1124 */       ImmutableList.Builder<ImmutableSet<E>> axesBuilder = new ImmutableList.Builder(sets.size());
/*  553:1126 */       for (Set<? extends E> set : sets)
/*  554:     */       {
/*  555:1127 */         ImmutableSet<E> copy = ImmutableSet.copyOf(set);
/*  556:1128 */         if (copy.isEmpty()) {
/*  557:1129 */           return ImmutableSet.of();
/*  558:     */         }
/*  559:1131 */         axesBuilder.add(copy);
/*  560:     */       }
/*  561:1133 */       ImmutableList<ImmutableSet<E>> axes = axesBuilder.build();
/*  562:1134 */       ImmutableList<List<E>> listAxes = new ImmutableList()
/*  563:     */       {
/*  564:     */         public int size()
/*  565:     */         {
/*  566:1138 */           return this.val$axes.size();
/*  567:     */         }
/*  568:     */         
/*  569:     */         public List<E> get(int index)
/*  570:     */         {
/*  571:1143 */           return ((ImmutableSet)this.val$axes.get(index)).asList();
/*  572:     */         }
/*  573:     */         
/*  574:     */         boolean isPartialView()
/*  575:     */         {
/*  576:1148 */           return true;
/*  577:     */         }
/*  578:1150 */       };
/*  579:1151 */       return new CartesianSet(axes, new CartesianList(listAxes));
/*  580:     */     }
/*  581:     */     
/*  582:     */     private CartesianSet(ImmutableList<ImmutableSet<E>> axes, CartesianList<E> delegate)
/*  583:     */     {
/*  584:1156 */       this.axes = axes;
/*  585:1157 */       this.delegate = delegate;
/*  586:     */     }
/*  587:     */     
/*  588:     */     protected Collection<List<E>> delegate()
/*  589:     */     {
/*  590:1162 */       return this.delegate;
/*  591:     */     }
/*  592:     */     
/*  593:     */     public boolean equals(@Nullable Object object)
/*  594:     */     {
/*  595:1168 */       if ((object instanceof CartesianSet))
/*  596:     */       {
/*  597:1169 */         CartesianSet<?> that = (CartesianSet)object;
/*  598:1170 */         return this.axes.equals(that.axes);
/*  599:     */       }
/*  600:1172 */       return super.equals(object);
/*  601:     */     }
/*  602:     */     
/*  603:     */     public int hashCode()
/*  604:     */     {
/*  605:1181 */       int adjust = size() - 1;
/*  606:1182 */       for (int i = 0; i < this.axes.size(); i++)
/*  607:     */       {
/*  608:1183 */         adjust *= 31;
/*  609:1184 */         adjust = adjust ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  610:     */       }
/*  611:1187 */       int hash = 1;
/*  612:1188 */       for (Set<E> axis : this.axes)
/*  613:     */       {
/*  614:1189 */         hash = 31 * hash + size() / axis.size() * axis.hashCode();
/*  615:     */         
/*  616:1191 */         hash = hash ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  617:     */       }
/*  618:1193 */       hash += adjust;
/*  619:1194 */       return hash ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  620:     */     }
/*  621:     */   }
/*  622:     */   
/*  623:     */   @GwtCompatible(serializable=false)
/*  624:     */   public static <E> Set<Set<E>> powerSet(Set<E> set)
/*  625:     */   {
/*  626:1229 */     return new PowerSet(set);
/*  627:     */   }
/*  628:     */   
/*  629:     */   private static final class SubSet<E>
/*  630:     */     extends AbstractSet<E>
/*  631:     */   {
/*  632:     */     private final ImmutableMap<E, Integer> inputSet;
/*  633:     */     private final int mask;
/*  634:     */     
/*  635:     */     SubSet(ImmutableMap<E, Integer> inputSet, int mask)
/*  636:     */     {
/*  637:1237 */       this.inputSet = inputSet;
/*  638:1238 */       this.mask = mask;
/*  639:     */     }
/*  640:     */     
/*  641:     */     public Iterator<E> iterator()
/*  642:     */     {
/*  643:1243 */       new UnmodifiableIterator()
/*  644:     */       {
/*  645:1244 */         final ImmutableList<E> elements = Sets.SubSet.this.inputSet.keySet().asList();
/*  646:1245 */         int remainingSetBits = Sets.SubSet.this.mask;
/*  647:     */         
/*  648:     */         public boolean hasNext()
/*  649:     */         {
/*  650:1249 */           return this.remainingSetBits != 0;
/*  651:     */         }
/*  652:     */         
/*  653:     */         public E next()
/*  654:     */         {
/*  655:1254 */           int index = Integer.numberOfTrailingZeros(this.remainingSetBits);
/*  656:1255 */           if (index == 32) {
/*  657:1256 */             throw new NoSuchElementException();
/*  658:     */           }
/*  659:1258 */           this.remainingSetBits &= (1 << index ^ 0xFFFFFFFF);
/*  660:1259 */           return this.elements.get(index);
/*  661:     */         }
/*  662:     */       };
/*  663:     */     }
/*  664:     */     
/*  665:     */     public int size()
/*  666:     */     {
/*  667:1266 */       return Integer.bitCount(this.mask);
/*  668:     */     }
/*  669:     */     
/*  670:     */     public boolean contains(@Nullable Object o)
/*  671:     */     {
/*  672:1271 */       Integer index = (Integer)this.inputSet.get(o);
/*  673:1272 */       return (index != null) && ((this.mask & 1 << index.intValue()) != 0);
/*  674:     */     }
/*  675:     */   }
/*  676:     */   
/*  677:     */   private static final class PowerSet<E>
/*  678:     */     extends AbstractSet<Set<E>>
/*  679:     */   {
/*  680:     */     final ImmutableMap<E, Integer> inputSet;
/*  681:     */     
/*  682:     */     PowerSet(Set<E> input)
/*  683:     */     {
/*  684:1280 */       ImmutableMap.Builder<E, Integer> builder = ImmutableMap.builder();
/*  685:1281 */       int i = 0;
/*  686:1282 */       for (E e : (Set)Preconditions.checkNotNull(input)) {
/*  687:1283 */         builder.put(e, Integer.valueOf(i++));
/*  688:     */       }
/*  689:1285 */       this.inputSet = builder.build();
/*  690:1286 */       Preconditions.checkArgument(this.inputSet.size() <= 30, "Too many elements to create power set: %s > 30", new Object[] { Integer.valueOf(this.inputSet.size()) });
/*  691:     */     }
/*  692:     */     
/*  693:     */     public int size()
/*  694:     */     {
/*  695:1291 */       return 1 << this.inputSet.size();
/*  696:     */     }
/*  697:     */     
/*  698:     */     public boolean isEmpty()
/*  699:     */     {
/*  700:1295 */       return false;
/*  701:     */     }
/*  702:     */     
/*  703:     */     public Iterator<Set<E>> iterator()
/*  704:     */     {
/*  705:1299 */       new AbstractIndexedListIterator(size())
/*  706:     */       {
/*  707:     */         protected Set<E> get(int setBits)
/*  708:     */         {
/*  709:1301 */           return new Sets.SubSet(Sets.PowerSet.this.inputSet, setBits);
/*  710:     */         }
/*  711:     */       };
/*  712:     */     }
/*  713:     */     
/*  714:     */     public boolean contains(@Nullable Object obj)
/*  715:     */     {
/*  716:1307 */       if ((obj instanceof Set))
/*  717:     */       {
/*  718:1308 */         Set<?> set = (Set)obj;
/*  719:1309 */         return this.inputSet.keySet().containsAll(set);
/*  720:     */       }
/*  721:1311 */       return false;
/*  722:     */     }
/*  723:     */     
/*  724:     */     public boolean equals(@Nullable Object obj)
/*  725:     */     {
/*  726:1315 */       if ((obj instanceof PowerSet))
/*  727:     */       {
/*  728:1316 */         PowerSet<?> that = (PowerSet)obj;
/*  729:1317 */         return this.inputSet.equals(that.inputSet);
/*  730:     */       }
/*  731:1319 */       return super.equals(obj);
/*  732:     */     }
/*  733:     */     
/*  734:     */     public int hashCode()
/*  735:     */     {
/*  736:1328 */       return this.inputSet.keySet().hashCode() << this.inputSet.size() - 1;
/*  737:     */     }
/*  738:     */     
/*  739:     */     public String toString()
/*  740:     */     {
/*  741:1332 */       return "powerSet(" + this.inputSet + ")";
/*  742:     */     }
/*  743:     */   }
/*  744:     */   
/*  745:     */   static int hashCodeImpl(Set<?> s)
/*  746:     */   {
/*  747:1340 */     int hashCode = 0;
/*  748:1341 */     for (Object o : s)
/*  749:     */     {
/*  750:1342 */       hashCode += (o != null ? o.hashCode() : 0);
/*  751:     */       
/*  752:1344 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  753:     */     }
/*  754:1347 */     return hashCode;
/*  755:     */   }
/*  756:     */   
/*  757:     */   static boolean equalsImpl(Set<?> s, @Nullable Object object)
/*  758:     */   {
/*  759:1354 */     if (s == object) {
/*  760:1355 */       return true;
/*  761:     */     }
/*  762:1357 */     if ((object instanceof Set))
/*  763:     */     {
/*  764:1358 */       Set<?> o = (Set)object;
/*  765:     */       try
/*  766:     */       {
/*  767:1361 */         return (s.size() == o.size()) && (s.containsAll(o));
/*  768:     */       }
/*  769:     */       catch (NullPointerException ignored)
/*  770:     */       {
/*  771:1363 */         return false;
/*  772:     */       }
/*  773:     */       catch (ClassCastException ignored)
/*  774:     */       {
/*  775:1365 */         return false;
/*  776:     */       }
/*  777:     */     }
/*  778:1368 */     return false;
/*  779:     */   }
/*  780:     */   
/*  781:     */   @GwtIncompatible("NavigableSet")
/*  782:     */   public static <E> NavigableSet<E> unmodifiableNavigableSet(NavigableSet<E> set)
/*  783:     */   {
/*  784:1390 */     if (((set instanceof ImmutableSortedSet)) || ((set instanceof UnmodifiableNavigableSet))) {
/*  785:1392 */       return set;
/*  786:     */     }
/*  787:1394 */     return new UnmodifiableNavigableSet(set);
/*  788:     */   }
/*  789:     */   
/*  790:     */   @GwtIncompatible("NavigableSet")
/*  791:     */   static final class UnmodifiableNavigableSet<E>
/*  792:     */     extends ForwardingSortedSet<E>
/*  793:     */     implements NavigableSet<E>, Serializable
/*  794:     */   {
/*  795:     */     private final NavigableSet<E> delegate;
/*  796:     */     private transient UnmodifiableNavigableSet<E> descendingSet;
/*  797:     */     private static final long serialVersionUID = 0L;
/*  798:     */     
/*  799:     */     UnmodifiableNavigableSet(NavigableSet<E> delegate)
/*  800:     */     {
/*  801:1403 */       this.delegate = ((NavigableSet)Preconditions.checkNotNull(delegate));
/*  802:     */     }
/*  803:     */     
/*  804:     */     protected SortedSet<E> delegate()
/*  805:     */     {
/*  806:1408 */       return Collections.unmodifiableSortedSet(this.delegate);
/*  807:     */     }
/*  808:     */     
/*  809:     */     public E lower(E e)
/*  810:     */     {
/*  811:1413 */       return this.delegate.lower(e);
/*  812:     */     }
/*  813:     */     
/*  814:     */     public E floor(E e)
/*  815:     */     {
/*  816:1418 */       return this.delegate.floor(e);
/*  817:     */     }
/*  818:     */     
/*  819:     */     public E ceiling(E e)
/*  820:     */     {
/*  821:1423 */       return this.delegate.ceiling(e);
/*  822:     */     }
/*  823:     */     
/*  824:     */     public E higher(E e)
/*  825:     */     {
/*  826:1428 */       return this.delegate.higher(e);
/*  827:     */     }
/*  828:     */     
/*  829:     */     public E pollFirst()
/*  830:     */     {
/*  831:1433 */       throw new UnsupportedOperationException();
/*  832:     */     }
/*  833:     */     
/*  834:     */     public E pollLast()
/*  835:     */     {
/*  836:1438 */       throw new UnsupportedOperationException();
/*  837:     */     }
/*  838:     */     
/*  839:     */     public NavigableSet<E> descendingSet()
/*  840:     */     {
/*  841:1445 */       UnmodifiableNavigableSet<E> result = this.descendingSet;
/*  842:1446 */       if (result == null)
/*  843:     */       {
/*  844:1447 */         result = this.descendingSet = new UnmodifiableNavigableSet(this.delegate.descendingSet());
/*  845:     */         
/*  846:1449 */         result.descendingSet = this;
/*  847:     */       }
/*  848:1451 */       return result;
/*  849:     */     }
/*  850:     */     
/*  851:     */     public Iterator<E> descendingIterator()
/*  852:     */     {
/*  853:1456 */       return Iterators.unmodifiableIterator(this.delegate.descendingIterator());
/*  854:     */     }
/*  855:     */     
/*  856:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  857:     */     {
/*  858:1465 */       return Sets.unmodifiableNavigableSet(this.delegate.subSet(fromElement, fromInclusive, toElement, toInclusive));
/*  859:     */     }
/*  860:     */     
/*  861:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  862:     */     {
/*  863:1474 */       return Sets.unmodifiableNavigableSet(this.delegate.headSet(toElement, inclusive));
/*  864:     */     }
/*  865:     */     
/*  866:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  867:     */     {
/*  868:1479 */       return Sets.unmodifiableNavigableSet(this.delegate.tailSet(fromElement, inclusive));
/*  869:     */     }
/*  870:     */   }
/*  871:     */   
/*  872:     */   @GwtIncompatible("NavigableSet")
/*  873:     */   public static <E> NavigableSet<E> synchronizedNavigableSet(NavigableSet<E> navigableSet)
/*  874:     */   {
/*  875:1532 */     return Synchronized.navigableSet(navigableSet);
/*  876:     */   }
/*  877:     */   
/*  878:     */   static boolean removeAllImpl(Set<?> set, Iterator<?> iterator)
/*  879:     */   {
/*  880:1539 */     boolean changed = false;
/*  881:1540 */     while (iterator.hasNext()) {
/*  882:1541 */       changed |= set.remove(iterator.next());
/*  883:     */     }
/*  884:1543 */     return changed;
/*  885:     */   }
/*  886:     */   
/*  887:     */   static boolean removeAllImpl(Set<?> set, Collection<?> collection)
/*  888:     */   {
/*  889:1547 */     Preconditions.checkNotNull(collection);
/*  890:1548 */     if ((collection instanceof Multiset)) {
/*  891:1549 */       collection = ((Multiset)collection).elementSet();
/*  892:     */     }
/*  893:1558 */     if (((collection instanceof Set)) && (collection.size() > set.size())) {
/*  894:1559 */       return Iterators.removeAll(set.iterator(), collection);
/*  895:     */     }
/*  896:1561 */     return removeAllImpl(set, collection.iterator());
/*  897:     */   }
/*  898:     */   
/*  899:     */   @GwtIncompatible("NavigableSet")
/*  900:     */   static class DescendingSet<E>
/*  901:     */     extends ForwardingNavigableSet<E>
/*  902:     */   {
/*  903:     */     private final NavigableSet<E> forward;
/*  904:     */     
/*  905:     */     DescendingSet(NavigableSet<E> forward)
/*  906:     */     {
/*  907:1570 */       this.forward = forward;
/*  908:     */     }
/*  909:     */     
/*  910:     */     protected NavigableSet<E> delegate()
/*  911:     */     {
/*  912:1575 */       return this.forward;
/*  913:     */     }
/*  914:     */     
/*  915:     */     public E lower(E e)
/*  916:     */     {
/*  917:1580 */       return this.forward.higher(e);
/*  918:     */     }
/*  919:     */     
/*  920:     */     public E floor(E e)
/*  921:     */     {
/*  922:1585 */       return this.forward.ceiling(e);
/*  923:     */     }
/*  924:     */     
/*  925:     */     public E ceiling(E e)
/*  926:     */     {
/*  927:1590 */       return this.forward.floor(e);
/*  928:     */     }
/*  929:     */     
/*  930:     */     public E higher(E e)
/*  931:     */     {
/*  932:1595 */       return this.forward.lower(e);
/*  933:     */     }
/*  934:     */     
/*  935:     */     public E pollFirst()
/*  936:     */     {
/*  937:1600 */       return this.forward.pollLast();
/*  938:     */     }
/*  939:     */     
/*  940:     */     public E pollLast()
/*  941:     */     {
/*  942:1605 */       return this.forward.pollFirst();
/*  943:     */     }
/*  944:     */     
/*  945:     */     public NavigableSet<E> descendingSet()
/*  946:     */     {
/*  947:1610 */       return this.forward;
/*  948:     */     }
/*  949:     */     
/*  950:     */     public Iterator<E> descendingIterator()
/*  951:     */     {
/*  952:1615 */       return this.forward.iterator();
/*  953:     */     }
/*  954:     */     
/*  955:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  956:     */     {
/*  957:1624 */       return this.forward.subSet(toElement, toInclusive, fromElement, fromInclusive).descendingSet();
/*  958:     */     }
/*  959:     */     
/*  960:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  961:     */     {
/*  962:1629 */       return this.forward.tailSet(toElement, inclusive).descendingSet();
/*  963:     */     }
/*  964:     */     
/*  965:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  966:     */     {
/*  967:1634 */       return this.forward.headSet(fromElement, inclusive).descendingSet();
/*  968:     */     }
/*  969:     */     
/*  970:     */     public Comparator<? super E> comparator()
/*  971:     */     {
/*  972:1640 */       Comparator<? super E> forwardComparator = this.forward.comparator();
/*  973:1641 */       if (forwardComparator == null) {
/*  974:1642 */         return Ordering.natural().reverse();
/*  975:     */       }
/*  976:1644 */       return reverse(forwardComparator);
/*  977:     */     }
/*  978:     */     
/*  979:     */     private static <T> Ordering<T> reverse(Comparator<T> forward)
/*  980:     */     {
/*  981:1650 */       return Ordering.from(forward).reverse();
/*  982:     */     }
/*  983:     */     
/*  984:     */     public E first()
/*  985:     */     {
/*  986:1655 */       return this.forward.last();
/*  987:     */     }
/*  988:     */     
/*  989:     */     public SortedSet<E> headSet(E toElement)
/*  990:     */     {
/*  991:1660 */       return standardHeadSet(toElement);
/*  992:     */     }
/*  993:     */     
/*  994:     */     public E last()
/*  995:     */     {
/*  996:1665 */       return this.forward.first();
/*  997:     */     }
/*  998:     */     
/*  999:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/* 1000:     */     {
/* 1001:1670 */       return standardSubSet(fromElement, toElement);
/* 1002:     */     }
/* 1003:     */     
/* 1004:     */     public SortedSet<E> tailSet(E fromElement)
/* 1005:     */     {
/* 1006:1675 */       return standardTailSet(fromElement);
/* 1007:     */     }
/* 1008:     */     
/* 1009:     */     public Iterator<E> iterator()
/* 1010:     */     {
/* 1011:1680 */       return this.forward.descendingIterator();
/* 1012:     */     }
/* 1013:     */     
/* 1014:     */     public Object[] toArray()
/* 1015:     */     {
/* 1016:1685 */       return standardToArray();
/* 1017:     */     }
/* 1018:     */     
/* 1019:     */     public <T> T[] toArray(T[] array)
/* 1020:     */     {
/* 1021:1690 */       return standardToArray(array);
/* 1022:     */     }
/* 1023:     */     
/* 1024:     */     public String toString()
/* 1025:     */     {
/* 1026:1695 */       return standardToString();
/* 1027:     */     }
/* 1028:     */   }
/* 1029:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Sets
 * JD-Core Version:    0.7.0.1
 */
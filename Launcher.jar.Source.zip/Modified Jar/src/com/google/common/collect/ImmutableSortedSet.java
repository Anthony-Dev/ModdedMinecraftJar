/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.InvalidObjectException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.NavigableSet;
/*  14:    */ import java.util.SortedSet;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @GwtCompatible(serializable=true, emulated=true)
/*  18:    */ public abstract class ImmutableSortedSet<E>
/*  19:    */   extends ImmutableSortedSetFauxverideShim<E>
/*  20:    */   implements NavigableSet<E>, SortedIterable<E>
/*  21:    */ {
/*  22: 97 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  23:100 */   private static final ImmutableSortedSet<Comparable> NATURAL_EMPTY_SET = new EmptyImmutableSortedSet(NATURAL_ORDER);
/*  24:    */   final transient Comparator<? super E> comparator;
/*  25:    */   @GwtIncompatible("NavigableSet")
/*  26:    */   transient ImmutableSortedSet<E> descendingSet;
/*  27:    */   
/*  28:    */   private static <E> ImmutableSortedSet<E> emptySet()
/*  29:    */   {
/*  30:105 */     return NATURAL_EMPTY_SET;
/*  31:    */   }
/*  32:    */   
/*  33:    */   static <E> ImmutableSortedSet<E> emptySet(Comparator<? super E> comparator)
/*  34:    */   {
/*  35:110 */     if (NATURAL_ORDER.equals(comparator)) {
/*  36:111 */       return emptySet();
/*  37:    */     }
/*  38:113 */     return new EmptyImmutableSortedSet(comparator);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <E> ImmutableSortedSet<E> of()
/*  42:    */   {
/*  43:121 */     return emptySet();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E element)
/*  47:    */   {
/*  48:129 */     return new RegularImmutableSortedSet(ImmutableList.of(element), Ordering.natural());
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2)
/*  52:    */   {
/*  53:143 */     return construct(Ordering.natural(), 2, new Comparable[] { e1, e2 });
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3)
/*  57:    */   {
/*  58:156 */     return construct(Ordering.natural(), 3, new Comparable[] { e1, e2, e3 });
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4)
/*  62:    */   {
/*  63:169 */     return construct(Ordering.natural(), 4, new Comparable[] { e1, e2, e3, e4 });
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*  67:    */   {
/*  68:182 */     return construct(Ordering.natural(), 5, new Comparable[] { e1, e2, e3, e4, e5 });
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... remaining)
/*  72:    */   {
/*  73:196 */     Comparable[] contents = new Comparable[6 + remaining.length];
/*  74:197 */     contents[0] = e1;
/*  75:198 */     contents[1] = e2;
/*  76:199 */     contents[2] = e3;
/*  77:200 */     contents[3] = e4;
/*  78:201 */     contents[4] = e5;
/*  79:202 */     contents[5] = e6;
/*  80:203 */     System.arraycopy(remaining, 0, contents, 6, remaining.length);
/*  81:204 */     return construct(Ordering.natural(), contents.length, (Comparable[])contents);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> copyOf(E[] elements)
/*  85:    */   {
/*  86:219 */     return construct(Ordering.natural(), elements.length, (Object[])elements.clone());
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static <E> ImmutableSortedSet<E> copyOf(Iterable<? extends E> elements)
/*  90:    */   {
/*  91:253 */     Ordering<E> naturalOrder = Ordering.natural();
/*  92:254 */     return copyOf(naturalOrder, elements);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static <E> ImmutableSortedSet<E> copyOf(Collection<? extends E> elements)
/*  96:    */   {
/*  97:291 */     Ordering<E> naturalOrder = Ordering.natural();
/*  98:292 */     return copyOf(naturalOrder, elements);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static <E> ImmutableSortedSet<E> copyOf(Iterator<? extends E> elements)
/* 102:    */   {
/* 103:311 */     Ordering<E> naturalOrder = Ordering.natural();
/* 104:312 */     return copyOf(naturalOrder, elements);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterator<? extends E> elements)
/* 108:    */   {
/* 109:326 */     return new Builder(comparator).addAll(elements).build();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterable<? extends E> elements)
/* 113:    */   {
/* 114:344 */     Preconditions.checkNotNull(comparator);
/* 115:345 */     boolean hasSameComparator = SortedIterables.hasSameComparator(comparator, elements);
/* 116:348 */     if ((hasSameComparator) && ((elements instanceof ImmutableSortedSet)))
/* 117:    */     {
/* 118:350 */       ImmutableSortedSet<E> original = (ImmutableSortedSet)elements;
/* 119:351 */       if (!original.isPartialView()) {
/* 120:352 */         return original;
/* 121:    */       }
/* 122:    */     }
/* 123:356 */     E[] array = (Object[])Iterables.toArray(elements);
/* 124:357 */     return construct(comparator, array.length, array);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Collection<? extends E> elements)
/* 128:    */   {
/* 129:380 */     return copyOf(comparator, elements);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static <E> ImmutableSortedSet<E> copyOfSorted(SortedSet<E> sortedSet)
/* 133:    */   {
/* 134:401 */     Comparator<? super E> comparator = SortedIterables.comparator(sortedSet);
/* 135:402 */     ImmutableList<E> list = ImmutableList.copyOf(sortedSet);
/* 136:403 */     if (list.isEmpty()) {
/* 137:404 */       return emptySet(comparator);
/* 138:    */     }
/* 139:406 */     return new RegularImmutableSortedSet(list, comparator);
/* 140:    */   }
/* 141:    */   
/* 142:    */   static <E> ImmutableSortedSet<E> construct(Comparator<? super E> comparator, int n, E... contents)
/* 143:    */   {
/* 144:424 */     if (n == 0) {
/* 145:425 */       return emptySet(comparator);
/* 146:    */     }
/* 147:427 */     ObjectArrays.checkElementsNotNull(contents, n);
/* 148:428 */     Arrays.sort(contents, 0, n, comparator);
/* 149:429 */     int uniques = 1;
/* 150:430 */     for (int i = 1; i < n; i++)
/* 151:    */     {
/* 152:431 */       E cur = contents[i];
/* 153:432 */       E prev = contents[(uniques - 1)];
/* 154:433 */       if (comparator.compare(cur, prev) != 0) {
/* 155:434 */         contents[(uniques++)] = cur;
/* 156:    */       }
/* 157:    */     }
/* 158:437 */     Arrays.fill(contents, uniques, n, null);
/* 159:438 */     return new RegularImmutableSortedSet(ImmutableList.asImmutableList(contents, uniques), comparator);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static <E> Builder<E> orderedBy(Comparator<E> comparator)
/* 163:    */   {
/* 164:451 */     return new Builder(comparator);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static <E extends Comparable<?>> Builder<E> reverseOrder()
/* 168:    */   {
/* 169:459 */     return new Builder(Ordering.natural().reverse());
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static <E extends Comparable<?>> Builder<E> naturalOrder()
/* 173:    */   {
/* 174:470 */     return new Builder(Ordering.natural());
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static final class Builder<E>
/* 178:    */     extends ImmutableSet.Builder<E>
/* 179:    */   {
/* 180:    */     private final Comparator<? super E> comparator;
/* 181:    */     
/* 182:    */     public Builder(Comparator<? super E> comparator)
/* 183:    */     {
/* 184:498 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 185:    */     }
/* 186:    */     
/* 187:    */     public Builder<E> add(E element)
/* 188:    */     {
/* 189:512 */       super.add(element);
/* 190:513 */       return this;
/* 191:    */     }
/* 192:    */     
/* 193:    */     public Builder<E> add(E... elements)
/* 194:    */     {
/* 195:525 */       super.add(elements);
/* 196:526 */       return this;
/* 197:    */     }
/* 198:    */     
/* 199:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 200:    */     {
/* 201:538 */       super.addAll(elements);
/* 202:539 */       return this;
/* 203:    */     }
/* 204:    */     
/* 205:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 206:    */     {
/* 207:551 */       super.addAll(elements);
/* 208:552 */       return this;
/* 209:    */     }
/* 210:    */     
/* 211:    */     public ImmutableSortedSet<E> build()
/* 212:    */     {
/* 213:561 */       E[] contentsArray = (Object[])this.contents;
/* 214:562 */       ImmutableSortedSet<E> result = ImmutableSortedSet.construct(this.comparator, this.size, contentsArray);
/* 215:563 */       this.size = result.size();
/* 216:564 */       return result;
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   int unsafeCompare(Object a, Object b)
/* 221:    */   {
/* 222:569 */     return unsafeCompare(this.comparator, a, b);
/* 223:    */   }
/* 224:    */   
/* 225:    */   static int unsafeCompare(Comparator<?> comparator, Object a, Object b)
/* 226:    */   {
/* 227:578 */     Comparator<Object> unsafeComparator = comparator;
/* 228:579 */     return unsafeComparator.compare(a, b);
/* 229:    */   }
/* 230:    */   
/* 231:    */   ImmutableSortedSet(Comparator<? super E> comparator)
/* 232:    */   {
/* 233:585 */     this.comparator = comparator;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public Comparator<? super E> comparator()
/* 237:    */   {
/* 238:597 */     return this.comparator;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public abstract UnmodifiableIterator<E> iterator();
/* 242:    */   
/* 243:    */   public ImmutableSortedSet<E> headSet(E toElement)
/* 244:    */   {
/* 245:616 */     return headSet(toElement, false);
/* 246:    */   }
/* 247:    */   
/* 248:    */   @GwtIncompatible("NavigableSet")
/* 249:    */   public ImmutableSortedSet<E> headSet(E toElement, boolean inclusive)
/* 250:    */   {
/* 251:625 */     return headSetImpl(Preconditions.checkNotNull(toElement), inclusive);
/* 252:    */   }
/* 253:    */   
/* 254:    */   public ImmutableSortedSet<E> subSet(E fromElement, E toElement)
/* 255:    */   {
/* 256:643 */     return subSet(fromElement, true, toElement, false);
/* 257:    */   }
/* 258:    */   
/* 259:    */   @GwtIncompatible("NavigableSet")
/* 260:    */   public ImmutableSortedSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 261:    */   {
/* 262:653 */     Preconditions.checkNotNull(fromElement);
/* 263:654 */     Preconditions.checkNotNull(toElement);
/* 264:655 */     Preconditions.checkArgument(this.comparator.compare(fromElement, toElement) <= 0);
/* 265:656 */     return subSetImpl(fromElement, fromInclusive, toElement, toInclusive);
/* 266:    */   }
/* 267:    */   
/* 268:    */   public ImmutableSortedSet<E> tailSet(E fromElement)
/* 269:    */   {
/* 270:672 */     return tailSet(fromElement, true);
/* 271:    */   }
/* 272:    */   
/* 273:    */   @GwtIncompatible("NavigableSet")
/* 274:    */   public ImmutableSortedSet<E> tailSet(E fromElement, boolean inclusive)
/* 275:    */   {
/* 276:681 */     return tailSetImpl(Preconditions.checkNotNull(fromElement), inclusive);
/* 277:    */   }
/* 278:    */   
/* 279:    */   abstract ImmutableSortedSet<E> headSetImpl(E paramE, boolean paramBoolean);
/* 280:    */   
/* 281:    */   abstract ImmutableSortedSet<E> subSetImpl(E paramE1, boolean paramBoolean1, E paramE2, boolean paramBoolean2);
/* 282:    */   
/* 283:    */   abstract ImmutableSortedSet<E> tailSetImpl(E paramE, boolean paramBoolean);
/* 284:    */   
/* 285:    */   @GwtIncompatible("NavigableSet")
/* 286:    */   public E lower(E e)
/* 287:    */   {
/* 288:701 */     return Iterators.getNext(headSet(e, false).descendingIterator(), null);
/* 289:    */   }
/* 290:    */   
/* 291:    */   @GwtIncompatible("NavigableSet")
/* 292:    */   public E floor(E e)
/* 293:    */   {
/* 294:710 */     return Iterators.getNext(headSet(e, true).descendingIterator(), null);
/* 295:    */   }
/* 296:    */   
/* 297:    */   @GwtIncompatible("NavigableSet")
/* 298:    */   public E ceiling(E e)
/* 299:    */   {
/* 300:719 */     return Iterables.getFirst(tailSet(e, true), null);
/* 301:    */   }
/* 302:    */   
/* 303:    */   @GwtIncompatible("NavigableSet")
/* 304:    */   public E higher(E e)
/* 305:    */   {
/* 306:728 */     return Iterables.getFirst(tailSet(e, false), null);
/* 307:    */   }
/* 308:    */   
/* 309:    */   public E first()
/* 310:    */   {
/* 311:733 */     return iterator().next();
/* 312:    */   }
/* 313:    */   
/* 314:    */   public E last()
/* 315:    */   {
/* 316:738 */     return descendingIterator().next();
/* 317:    */   }
/* 318:    */   
/* 319:    */   @Deprecated
/* 320:    */   @GwtIncompatible("NavigableSet")
/* 321:    */   public final E pollFirst()
/* 322:    */   {
/* 323:752 */     throw new UnsupportedOperationException();
/* 324:    */   }
/* 325:    */   
/* 326:    */   @Deprecated
/* 327:    */   @GwtIncompatible("NavigableSet")
/* 328:    */   public final E pollLast()
/* 329:    */   {
/* 330:766 */     throw new UnsupportedOperationException();
/* 331:    */   }
/* 332:    */   
/* 333:    */   @GwtIncompatible("NavigableSet")
/* 334:    */   public ImmutableSortedSet<E> descendingSet()
/* 335:    */   {
/* 336:779 */     ImmutableSortedSet<E> result = this.descendingSet;
/* 337:780 */     if (result == null)
/* 338:    */     {
/* 339:781 */       result = this.descendingSet = createDescendingSet();
/* 340:782 */       result.descendingSet = this;
/* 341:    */     }
/* 342:784 */     return result;
/* 343:    */   }
/* 344:    */   
/* 345:    */   @GwtIncompatible("NavigableSet")
/* 346:    */   ImmutableSortedSet<E> createDescendingSet()
/* 347:    */   {
/* 348:789 */     return new DescendingImmutableSortedSet(this);
/* 349:    */   }
/* 350:    */   
/* 351:    */   @GwtIncompatible("NavigableSet")
/* 352:    */   public abstract UnmodifiableIterator<E> descendingIterator();
/* 353:    */   
/* 354:    */   abstract int indexOf(@Nullable Object paramObject);
/* 355:    */   
/* 356:    */   private static class SerializedForm<E>
/* 357:    */     implements Serializable
/* 358:    */   {
/* 359:    */     final Comparator<? super E> comparator;
/* 360:    */     final Object[] elements;
/* 361:    */     private static final long serialVersionUID = 0L;
/* 362:    */     
/* 363:    */     public SerializedForm(Comparator<? super E> comparator, Object[] elements)
/* 364:    */     {
/* 365:815 */       this.comparator = comparator;
/* 366:816 */       this.elements = elements;
/* 367:    */     }
/* 368:    */     
/* 369:    */     Object readResolve()
/* 370:    */     {
/* 371:821 */       return new ImmutableSortedSet.Builder(this.comparator).add((Object[])this.elements).build();
/* 372:    */     }
/* 373:    */   }
/* 374:    */   
/* 375:    */   private void readObject(ObjectInputStream stream)
/* 376:    */     throws InvalidObjectException
/* 377:    */   {
/* 378:829 */     throw new InvalidObjectException("Use SerializedForm");
/* 379:    */   }
/* 380:    */   
/* 381:    */   Object writeReplace()
/* 382:    */   {
/* 383:833 */     return new SerializedForm(this.comparator, toArray());
/* 384:    */   }
/* 385:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */
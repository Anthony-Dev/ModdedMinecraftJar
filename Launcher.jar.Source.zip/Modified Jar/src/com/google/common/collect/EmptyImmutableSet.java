/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Collection;
/*  5:   */ import java.util.Set;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true, emulated=true)
/*  9:   */ final class EmptyImmutableSet
/* 10:   */   extends ImmutableSet<Object>
/* 11:   */ {
/* 12:33 */   static final EmptyImmutableSet INSTANCE = new EmptyImmutableSet();
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   public int size()
/* 16:   */   {
/* 17:39 */     return 0;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean isEmpty()
/* 21:   */   {
/* 22:43 */     return true;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean contains(@Nullable Object target)
/* 26:   */   {
/* 27:47 */     return false;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean containsAll(Collection<?> targets)
/* 31:   */   {
/* 32:51 */     return targets.isEmpty();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public UnmodifiableIterator<Object> iterator()
/* 36:   */   {
/* 37:55 */     return Iterators.emptyIterator();
/* 38:   */   }
/* 39:   */   
/* 40:   */   boolean isPartialView()
/* 41:   */   {
/* 42:59 */     return false;
/* 43:   */   }
/* 44:   */   
/* 45:   */   int copyIntoArray(Object[] dst, int offset)
/* 46:   */   {
/* 47:64 */     return offset;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public ImmutableList<Object> asList()
/* 51:   */   {
/* 52:69 */     return ImmutableList.of();
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean equals(@Nullable Object object)
/* 56:   */   {
/* 57:73 */     if ((object instanceof Set))
/* 58:   */     {
/* 59:74 */       Set<?> that = (Set)object;
/* 60:75 */       return that.isEmpty();
/* 61:   */     }
/* 62:77 */     return false;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public final int hashCode()
/* 66:   */   {
/* 67:81 */     return 0;
/* 68:   */   }
/* 69:   */   
/* 70:   */   boolean isHashCodeFast()
/* 71:   */   {
/* 72:85 */     return true;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String toString()
/* 76:   */   {
/* 77:89 */     return "[]";
/* 78:   */   }
/* 79:   */   
/* 80:   */   Object readResolve()
/* 81:   */   {
/* 82:93 */     return INSTANCE;
/* 83:   */   }
/* 84:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableSet
 * JD-Core Version:    0.7.0.1
 */
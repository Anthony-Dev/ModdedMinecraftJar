/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.Collection;
/*  6:   */ import java.util.Set;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible
/* 10:   */ public abstract class ForwardingSet<E>
/* 11:   */   extends ForwardingCollection<E>
/* 12:   */   implements Set<E>
/* 13:   */ {
/* 14:   */   protected abstract Set<E> delegate();
/* 15:   */   
/* 16:   */   public boolean equals(@Nullable Object object)
/* 17:   */   {
/* 18:59 */     return (object == this) || (delegate().equals(object));
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int hashCode()
/* 22:   */   {
/* 23:63 */     return delegate().hashCode();
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected boolean standardRemoveAll(Collection<?> collection)
/* 27:   */   {
/* 28:76 */     return Sets.removeAllImpl(this, (Collection)Preconditions.checkNotNull(collection));
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected boolean standardEquals(@Nullable Object object)
/* 32:   */   {
/* 33:87 */     return Sets.equalsImpl(this, object);
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected int standardHashCode()
/* 37:   */   {
/* 38:98 */     return Sets.hashCodeImpl(this);
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingSet
 * JD-Core Version:    0.7.0.1
 */
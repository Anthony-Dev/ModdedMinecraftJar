/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ abstract class AbstractSetMultimap<K, V>
/*  12:    */   extends AbstractMapBasedMultimap<K, V>
/*  13:    */   implements SetMultimap<K, V>
/*  14:    */ {
/*  15:    */   private static final long serialVersionUID = 7431625294878419160L;
/*  16:    */   
/*  17:    */   protected AbstractSetMultimap(Map<K, Collection<V>> map)
/*  18:    */   {
/*  19: 44 */     super(map);
/*  20:    */   }
/*  21:    */   
/*  22:    */   abstract Set<V> createCollection();
/*  23:    */   
/*  24:    */   Set<V> createUnmodifiableEmptyCollection()
/*  25:    */   {
/*  26: 50 */     return ImmutableSet.of();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Set<V> get(@Nullable K key)
/*  30:    */   {
/*  31: 63 */     return (Set)super.get(key);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Set<Map.Entry<K, V>> entries()
/*  35:    */   {
/*  36: 74 */     return (Set)super.entries();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Set<V> removeAll(@Nullable Object key)
/*  40:    */   {
/*  41: 85 */     return (Set)super.removeAll(key);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Set<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*  45:    */   {
/*  46: 99 */     return (Set)super.replaceValues(key, values);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Map<K, Collection<V>> asMap()
/*  50:    */   {
/*  51:109 */     return super.asMap();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean put(@Nullable K key, @Nullable V value)
/*  55:    */   {
/*  56:121 */     return super.put(key, value);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean equals(@Nullable Object object)
/*  60:    */   {
/*  61:132 */     return super.equals(object);
/*  62:    */   }
/*  63:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractSetMultimap
 * JD-Core Version:    0.7.0.1
 */
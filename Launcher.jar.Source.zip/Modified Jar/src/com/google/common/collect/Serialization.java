/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.ObjectInputStream;
/*   5:    */ import java.io.ObjectOutputStream;
/*   6:    */ import java.lang.reflect.Field;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ 
/*  12:    */ final class Serialization
/*  13:    */ {
/*  14:    */   static int readCount(ObjectInputStream stream)
/*  15:    */     throws IOException
/*  16:    */   {
/*  17: 50 */     return stream.readInt();
/*  18:    */   }
/*  19:    */   
/*  20:    */   static <K, V> void writeMap(Map<K, V> map, ObjectOutputStream stream)
/*  21:    */     throws IOException
/*  22:    */   {
/*  23: 63 */     stream.writeInt(map.size());
/*  24: 64 */     for (Map.Entry<K, V> entry : map.entrySet())
/*  25:    */     {
/*  26: 65 */       stream.writeObject(entry.getKey());
/*  27: 66 */       stream.writeObject(entry.getValue());
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   static <K, V> void populateMap(Map<K, V> map, ObjectInputStream stream)
/*  32:    */     throws IOException, ClassNotFoundException
/*  33:    */   {
/*  34: 76 */     int size = stream.readInt();
/*  35: 77 */     populateMap(map, stream, size);
/*  36:    */   }
/*  37:    */   
/*  38:    */   static <K, V> void populateMap(Map<K, V> map, ObjectInputStream stream, int size)
/*  39:    */     throws IOException, ClassNotFoundException
/*  40:    */   {
/*  41: 87 */     for (int i = 0; i < size; i++)
/*  42:    */     {
/*  43: 89 */       K key = stream.readObject();
/*  44:    */       
/*  45: 91 */       V value = stream.readObject();
/*  46: 92 */       map.put(key, value);
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <E> void writeMultiset(Multiset<E> multiset, ObjectOutputStream stream)
/*  51:    */     throws IOException
/*  52:    */   {
/*  53:106 */     int entryCount = multiset.entrySet().size();
/*  54:107 */     stream.writeInt(entryCount);
/*  55:108 */     for (Multiset.Entry<E> entry : multiset.entrySet())
/*  56:    */     {
/*  57:109 */       stream.writeObject(entry.getElement());
/*  58:110 */       stream.writeInt(entry.getCount());
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   static <E> void populateMultiset(Multiset<E> multiset, ObjectInputStream stream)
/*  63:    */     throws IOException, ClassNotFoundException
/*  64:    */   {
/*  65:121 */     int distinctElements = stream.readInt();
/*  66:122 */     populateMultiset(multiset, stream, distinctElements);
/*  67:    */   }
/*  68:    */   
/*  69:    */   static <E> void populateMultiset(Multiset<E> multiset, ObjectInputStream stream, int distinctElements)
/*  70:    */     throws IOException, ClassNotFoundException
/*  71:    */   {
/*  72:133 */     for (int i = 0; i < distinctElements; i++)
/*  73:    */     {
/*  74:135 */       E element = stream.readObject();
/*  75:136 */       int count = stream.readInt();
/*  76:137 */       multiset.add(element, count);
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   static <K, V> void writeMultimap(Multimap<K, V> multimap, ObjectOutputStream stream)
/*  81:    */     throws IOException
/*  82:    */   {
/*  83:153 */     stream.writeInt(multimap.asMap().size());
/*  84:154 */     for (Map.Entry<K, Collection<V>> entry : multimap.asMap().entrySet())
/*  85:    */     {
/*  86:155 */       stream.writeObject(entry.getKey());
/*  87:156 */       stream.writeInt(((Collection)entry.getValue()).size());
/*  88:157 */       for (V value : (Collection)entry.getValue()) {
/*  89:158 */         stream.writeObject(value);
/*  90:    */       }
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   static <K, V> void populateMultimap(Multimap<K, V> multimap, ObjectInputStream stream)
/*  95:    */     throws IOException, ClassNotFoundException
/*  96:    */   {
/*  97:170 */     int distinctKeys = stream.readInt();
/*  98:171 */     populateMultimap(multimap, stream, distinctKeys);
/*  99:    */   }
/* 100:    */   
/* 101:    */   static <K, V> void populateMultimap(Multimap<K, V> multimap, ObjectInputStream stream, int distinctKeys)
/* 102:    */     throws IOException, ClassNotFoundException
/* 103:    */   {
/* 104:182 */     for (int i = 0; i < distinctKeys; i++)
/* 105:    */     {
/* 106:184 */       K key = stream.readObject();
/* 107:185 */       Collection<V> values = multimap.get(key);
/* 108:186 */       int valueCount = stream.readInt();
/* 109:187 */       for (int j = 0; j < valueCount; j++)
/* 110:    */       {
/* 111:189 */         V value = stream.readObject();
/* 112:190 */         values.add(value);
/* 113:    */       }
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   static <T> FieldSetter<T> getFieldSetter(Class<T> clazz, String fieldName)
/* 118:    */   {
/* 119:    */     try
/* 120:    */     {
/* 121:199 */       Field field = clazz.getDeclaredField(fieldName);
/* 122:200 */       return new FieldSetter(field, null);
/* 123:    */     }
/* 124:    */     catch (NoSuchFieldException e)
/* 125:    */     {
/* 126:202 */       throw new AssertionError(e);
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   static final class FieldSetter<T>
/* 131:    */   {
/* 132:    */     private final Field field;
/* 133:    */     
/* 134:    */     private FieldSetter(Field field)
/* 135:    */     {
/* 136:211 */       this.field = field;
/* 137:212 */       field.setAccessible(true);
/* 138:    */     }
/* 139:    */     
/* 140:    */     void set(T instance, Object value)
/* 141:    */     {
/* 142:    */       try
/* 143:    */       {
/* 144:217 */         this.field.set(instance, value);
/* 145:    */       }
/* 146:    */       catch (IllegalAccessException impossible)
/* 147:    */       {
/* 148:219 */         throw new AssertionError(impossible);
/* 149:    */       }
/* 150:    */     }
/* 151:    */     
/* 152:    */     void set(T instance, int value)
/* 153:    */     {
/* 154:    */       try
/* 155:    */       {
/* 156:225 */         this.field.set(instance, Integer.valueOf(value));
/* 157:    */       }
/* 158:    */       catch (IllegalAccessException impossible)
/* 159:    */       {
/* 160:227 */         throw new AssertionError(impossible);
/* 161:    */       }
/* 162:    */     }
/* 163:    */   }
/* 164:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Serialization
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ abstract class AbstractListMultimap<K, V>
/*  11:    */   extends AbstractMapBasedMultimap<K, V>
/*  12:    */   implements ListMultimap<K, V>
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 6588350623831699109L;
/*  15:    */   
/*  16:    */   protected AbstractListMultimap(Map<K, Collection<V>> map)
/*  17:    */   {
/*  18: 46 */     super(map);
/*  19:    */   }
/*  20:    */   
/*  21:    */   abstract List<V> createCollection();
/*  22:    */   
/*  23:    */   List<V> createUnmodifiableEmptyCollection()
/*  24:    */   {
/*  25: 53 */     return ImmutableList.of();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public List<V> get(@Nullable K key)
/*  29:    */   {
/*  30: 66 */     return (List)super.get(key);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public List<V> removeAll(@Nullable Object key)
/*  34:    */   {
/*  35: 77 */     return (List)super.removeAll(key);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public List<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*  39:    */   {
/*  40: 89 */     return (List)super.replaceValues(key, values);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean put(@Nullable K key, @Nullable V value)
/*  44:    */   {
/*  45:100 */     return super.put(key, value);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Map<K, Collection<V>> asMap()
/*  49:    */   {
/*  50:110 */     return super.asMap();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean equals(@Nullable Object object)
/*  54:    */   {
/*  55:121 */     return super.equals(object);
/*  56:    */   }
/*  57:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractListMultimap
 * JD-Core Version:    0.7.0.1
 */
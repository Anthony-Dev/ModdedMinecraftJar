/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.concurrent.ConcurrentMap;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class ForwardingConcurrentMap<K, V>
/*  8:   */   extends ForwardingMap<K, V>
/*  9:   */   implements ConcurrentMap<K, V>
/* 10:   */ {
/* 11:   */   protected abstract ConcurrentMap<K, V> delegate();
/* 12:   */   
/* 13:   */   public V putIfAbsent(K key, V value)
/* 14:   */   {
/* 15:43 */     return delegate().putIfAbsent(key, value);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean remove(Object key, Object value)
/* 19:   */   {
/* 20:48 */     return delegate().remove(key, value);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public V replace(K key, V value)
/* 24:   */   {
/* 25:53 */     return delegate().replace(key, value);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean replace(K key, V oldValue, V newValue)
/* 29:   */   {
/* 30:58 */     return delegate().replace(key, oldValue, newValue);
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingConcurrentMap
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Supplier;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.EnumMap;
/*  12:    */ import java.util.EnumSet;
/*  13:    */ import java.util.HashMap;
/*  14:    */ import java.util.HashSet;
/*  15:    */ import java.util.LinkedHashMap;
/*  16:    */ import java.util.LinkedHashSet;
/*  17:    */ import java.util.LinkedList;
/*  18:    */ import java.util.List;
/*  19:    */ import java.util.Map;
/*  20:    */ import java.util.Set;
/*  21:    */ import java.util.SortedSet;
/*  22:    */ import java.util.TreeMap;
/*  23:    */ import java.util.TreeSet;
/*  24:    */ 
/*  25:    */ @Beta
/*  26:    */ @GwtCompatible
/*  27:    */ public abstract class MultimapBuilder<K0, V0>
/*  28:    */ {
/*  29:    */   private static final int DEFAULT_EXPECTED_KEYS = 8;
/*  30:    */   
/*  31:    */   public static MultimapBuilderWithKeys<Object> hashKeys()
/*  32:    */   {
/*  33: 85 */     return hashKeys(8);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static MultimapBuilderWithKeys<Object> hashKeys(int expectedKeys)
/*  37:    */   {
/*  38: 95 */     CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
/*  39: 96 */     new MultimapBuilderWithKeys()
/*  40:    */     {
/*  41:    */       <K, V> Map<K, Collection<V>> createMap()
/*  42:    */       {
/*  43: 99 */         return new HashMap(this.val$expectedKeys);
/*  44:    */       }
/*  45:    */     };
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static MultimapBuilderWithKeys<Object> linkedHashKeys()
/*  49:    */   {
/*  50:113 */     return linkedHashKeys(8);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static MultimapBuilderWithKeys<Object> linkedHashKeys(int expectedKeys)
/*  54:    */   {
/*  55:126 */     CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
/*  56:127 */     new MultimapBuilderWithKeys()
/*  57:    */     {
/*  58:    */       <K, V> Map<K, Collection<V>> createMap()
/*  59:    */       {
/*  60:130 */         return new LinkedHashMap(this.val$expectedKeys);
/*  61:    */       }
/*  62:    */     };
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static MultimapBuilderWithKeys<Comparable> treeKeys()
/*  66:    */   {
/*  67:147 */     return treeKeys(Ordering.natural());
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static <K0> MultimapBuilderWithKeys<K0> treeKeys(Comparator<K0> comparator)
/*  71:    */   {
/*  72:164 */     Preconditions.checkNotNull(comparator);
/*  73:165 */     new MultimapBuilderWithKeys()
/*  74:    */     {
/*  75:    */       <K extends K0, V> Map<K, Collection<V>> createMap()
/*  76:    */       {
/*  77:168 */         return new TreeMap(this.val$comparator);
/*  78:    */       }
/*  79:    */     };
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static <K0 extends Enum<K0>> MultimapBuilderWithKeys<K0> enumKeys(Class<K0> keyClass)
/*  83:    */   {
/*  84:178 */     Preconditions.checkNotNull(keyClass);
/*  85:179 */     new MultimapBuilderWithKeys()
/*  86:    */     {
/*  87:    */       <K extends K0, V> Map<K, Collection<V>> createMap()
/*  88:    */       {
/*  89:185 */         return new EnumMap(this.val$keyClass);
/*  90:    */       }
/*  91:    */     };
/*  92:    */   }
/*  93:    */   
/*  94:    */   public abstract <K extends K0, V extends V0> Multimap<K, V> build();
/*  95:    */   
/*  96:    */   private static final class ArrayListSupplier<V>
/*  97:    */     implements Supplier<List<V>>, Serializable
/*  98:    */   {
/*  99:    */     private final int expectedValuesPerKey;
/* 100:    */     
/* 101:    */     ArrayListSupplier(int expectedValuesPerKey)
/* 102:    */     {
/* 103:194 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 104:    */     }
/* 105:    */     
/* 106:    */     public List<V> get()
/* 107:    */     {
/* 108:199 */       return new ArrayList(this.expectedValuesPerKey);
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static enum LinkedListSupplier
/* 113:    */     implements Supplier<List<Object>>
/* 114:    */   {
/* 115:204 */     INSTANCE;
/* 116:    */     
/* 117:    */     private LinkedListSupplier() {}
/* 118:    */     
/* 119:    */     public static <V> Supplier<List<V>> instance()
/* 120:    */     {
/* 121:209 */       Supplier<List<V>> result = INSTANCE;
/* 122:210 */       return result;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public List<Object> get()
/* 126:    */     {
/* 127:215 */       return new LinkedList();
/* 128:    */     }
/* 129:    */   }
/* 130:    */   
/* 131:    */   private static final class HashSetSupplier<V>
/* 132:    */     implements Supplier<Set<V>>, Serializable
/* 133:    */   {
/* 134:    */     private final int expectedValuesPerKey;
/* 135:    */     
/* 136:    */     HashSetSupplier(int expectedValuesPerKey)
/* 137:    */     {
/* 138:223 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 139:    */     }
/* 140:    */     
/* 141:    */     public Set<V> get()
/* 142:    */     {
/* 143:228 */       return new HashSet(this.expectedValuesPerKey);
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static final class LinkedHashSetSupplier<V>
/* 148:    */     implements Supplier<Set<V>>, Serializable
/* 149:    */   {
/* 150:    */     private final int expectedValuesPerKey;
/* 151:    */     
/* 152:    */     LinkedHashSetSupplier(int expectedValuesPerKey)
/* 153:    */     {
/* 154:236 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 155:    */     }
/* 156:    */     
/* 157:    */     public Set<V> get()
/* 158:    */     {
/* 159:241 */       return new LinkedHashSet(this.expectedValuesPerKey);
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   private static final class TreeSetSupplier<V>
/* 164:    */     implements Supplier<SortedSet<V>>, Serializable
/* 165:    */   {
/* 166:    */     private final Comparator<? super V> comparator;
/* 167:    */     
/* 168:    */     TreeSetSupplier(Comparator<? super V> comparator)
/* 169:    */     {
/* 170:249 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 171:    */     }
/* 172:    */     
/* 173:    */     public SortedSet<V> get()
/* 174:    */     {
/* 175:254 */       return new TreeSet(this.comparator);
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static final class EnumSetSupplier<V extends Enum<V>>
/* 180:    */     implements Supplier<Set<V>>, Serializable
/* 181:    */   {
/* 182:    */     private final Class<V> clazz;
/* 183:    */     
/* 184:    */     EnumSetSupplier(Class<V> clazz)
/* 185:    */     {
/* 186:263 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 187:    */     }
/* 188:    */     
/* 189:    */     public Set<V> get()
/* 190:    */     {
/* 191:268 */       return EnumSet.noneOf(this.clazz);
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static abstract class MultimapBuilderWithKeys<K0>
/* 196:    */   {
/* 197:    */     private static final int DEFAULT_EXPECTED_VALUES_PER_KEY = 2;
/* 198:    */     
/* 199:    */     abstract <K extends K0, V> Map<K, Collection<V>> createMap();
/* 200:    */     
/* 201:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> arrayListValues()
/* 202:    */     {
/* 203:290 */       return arrayListValues(2);
/* 204:    */     }
/* 205:    */     
/* 206:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> arrayListValues(final int expectedValuesPerKey)
/* 207:    */     {
/* 208:300 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 209:301 */       new MultimapBuilder.ListMultimapBuilder()
/* 210:    */       {
/* 211:    */         public <K extends K0, V> ListMultimap<K, V> build()
/* 212:    */         {
/* 213:304 */           return Multimaps.newListMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.ArrayListSupplier(expectedValuesPerKey));
/* 214:    */         }
/* 215:    */       };
/* 216:    */     }
/* 217:    */     
/* 218:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> linkedListValues()
/* 219:    */     {
/* 220:315 */       new MultimapBuilder.ListMultimapBuilder()
/* 221:    */       {
/* 222:    */         public <K extends K0, V> ListMultimap<K, V> build()
/* 223:    */         {
/* 224:318 */           return Multimaps.newListMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), MultimapBuilder.LinkedListSupplier.instance());
/* 225:    */         }
/* 226:    */       };
/* 227:    */     }
/* 228:    */     
/* 229:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> hashSetValues()
/* 230:    */     {
/* 231:329 */       return hashSetValues(2);
/* 232:    */     }
/* 233:    */     
/* 234:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> hashSetValues(final int expectedValuesPerKey)
/* 235:    */     {
/* 236:339 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 237:340 */       new MultimapBuilder.SetMultimapBuilder()
/* 238:    */       {
/* 239:    */         public <K extends K0, V> SetMultimap<K, V> build()
/* 240:    */         {
/* 241:343 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.HashSetSupplier(expectedValuesPerKey));
/* 242:    */         }
/* 243:    */       };
/* 244:    */     }
/* 245:    */     
/* 246:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> linkedHashSetValues()
/* 247:    */     {
/* 248:354 */       return linkedHashSetValues(2);
/* 249:    */     }
/* 250:    */     
/* 251:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> linkedHashSetValues(final int expectedValuesPerKey)
/* 252:    */     {
/* 253:364 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 254:365 */       new MultimapBuilder.SetMultimapBuilder()
/* 255:    */       {
/* 256:    */         public <K extends K0, V> SetMultimap<K, V> build()
/* 257:    */         {
/* 258:368 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.LinkedHashSetSupplier(expectedValuesPerKey));
/* 259:    */         }
/* 260:    */       };
/* 261:    */     }
/* 262:    */     
/* 263:    */     public MultimapBuilder.SortedSetMultimapBuilder<K0, Comparable> treeSetValues()
/* 264:    */     {
/* 265:380 */       return treeSetValues(Ordering.natural());
/* 266:    */     }
/* 267:    */     
/* 268:    */     public <V0> MultimapBuilder.SortedSetMultimapBuilder<K0, V0> treeSetValues(final Comparator<V0> comparator)
/* 269:    */     {
/* 270:390 */       Preconditions.checkNotNull(comparator, "comparator");
/* 271:391 */       new MultimapBuilder.SortedSetMultimapBuilder()
/* 272:    */       {
/* 273:    */         public <K extends K0, V extends V0> SortedSetMultimap<K, V> build()
/* 274:    */         {
/* 275:394 */           return Multimaps.newSortedSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.TreeSetSupplier(comparator));
/* 276:    */         }
/* 277:    */       };
/* 278:    */     }
/* 279:    */     
/* 280:    */     public <V0 extends Enum<V0>> MultimapBuilder.SetMultimapBuilder<K0, V0> enumSetValues(final Class<V0> valueClass)
/* 281:    */     {
/* 282:406 */       Preconditions.checkNotNull(valueClass, "valueClass");
/* 283:407 */       new MultimapBuilder.SetMultimapBuilder()
/* 284:    */       {
/* 285:    */         public <K extends K0, V extends V0> SetMultimap<K, V> build()
/* 286:    */         {
/* 287:413 */           Supplier<Set<V>> factory = new MultimapBuilder.EnumSetSupplier(valueClass);
/* 288:414 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), factory);
/* 289:    */         }
/* 290:    */       };
/* 291:    */     }
/* 292:    */   }
/* 293:    */   
/* 294:    */   public <K extends K0, V extends V0> Multimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 295:    */   {
/* 296:433 */     Multimap<K, V> result = build();
/* 297:434 */     result.putAll(multimap);
/* 298:435 */     return result;
/* 299:    */   }
/* 300:    */   
/* 301:    */   public static abstract class ListMultimapBuilder<K0, V0>
/* 302:    */     extends MultimapBuilder<K0, V0>
/* 303:    */   {
/* 304:    */     ListMultimapBuilder()
/* 305:    */     {
/* 306:442 */       super();
/* 307:    */     }
/* 308:    */     
/* 309:    */     public abstract <K extends K0, V extends V0> ListMultimap<K, V> build();
/* 310:    */     
/* 311:    */     public <K extends K0, V extends V0> ListMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 312:    */     {
/* 313:450 */       return (ListMultimap)super.build(multimap);
/* 314:    */     }
/* 315:    */   }
/* 316:    */   
/* 317:    */   public static abstract class SetMultimapBuilder<K0, V0>
/* 318:    */     extends MultimapBuilder<K0, V0>
/* 319:    */   {
/* 320:    */     SetMultimapBuilder()
/* 321:    */     {
/* 322:458 */       super();
/* 323:    */     }
/* 324:    */     
/* 325:    */     public abstract <K extends K0, V extends V0> SetMultimap<K, V> build();
/* 326:    */     
/* 327:    */     public <K extends K0, V extends V0> SetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 328:    */     {
/* 329:466 */       return (SetMultimap)super.build(multimap);
/* 330:    */     }
/* 331:    */   }
/* 332:    */   
/* 333:    */   public static abstract class SortedSetMultimapBuilder<K0, V0>
/* 334:    */     extends MultimapBuilder.SetMultimapBuilder<K0, V0>
/* 335:    */   {
/* 336:    */     public abstract <K extends K0, V extends V0> SortedSetMultimap<K, V> build();
/* 337:    */     
/* 338:    */     public <K extends K0, V extends V0> SortedSetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 339:    */     {
/* 340:482 */       return (SortedSetMultimap)super.build(multimap);
/* 341:    */     }
/* 342:    */   }
/* 343:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MultimapBuilder
 * JD-Core Version:    0.7.0.1
 */
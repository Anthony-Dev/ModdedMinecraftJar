/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ public abstract class ImmutableTable<R, C, V>
/*  14:    */   extends AbstractTable<R, C, V>
/*  15:    */ {
/*  16: 49 */   private static final ImmutableTable<Object, Object, Object> EMPTY = new SparseImmutableTable(ImmutableList.of(), ImmutableSet.of(), ImmutableSet.of());
/*  17:    */   
/*  18:    */   public static <R, C, V> ImmutableTable<R, C, V> of()
/*  19:    */   {
/*  20: 57 */     return EMPTY;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <R, C, V> ImmutableTable<R, C, V> of(R rowKey, C columnKey, V value)
/*  24:    */   {
/*  25: 63 */     return new SingletonImmutableTable(rowKey, columnKey, value);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <R, C, V> ImmutableTable<R, C, V> copyOf(Table<? extends R, ? extends C, ? extends V> table)
/*  29:    */   {
/*  30: 82 */     if ((table instanceof ImmutableTable))
/*  31:    */     {
/*  32: 84 */       ImmutableTable<R, C, V> parameterizedTable = (ImmutableTable)table;
/*  33:    */       
/*  34: 86 */       return parameterizedTable;
/*  35:    */     }
/*  36: 88 */     int size = table.size();
/*  37: 89 */     switch (size)
/*  38:    */     {
/*  39:    */     case 0: 
/*  40: 91 */       return of();
/*  41:    */     case 1: 
/*  42: 93 */       Table.Cell<? extends R, ? extends C, ? extends V> onlyCell = (Table.Cell)Iterables.getOnlyElement(table.cellSet());
/*  43:    */       
/*  44: 95 */       return of(onlyCell.getRowKey(), onlyCell.getColumnKey(), onlyCell.getValue());
/*  45:    */     }
/*  46: 98 */     ImmutableSet.Builder<Table.Cell<R, C, V>> cellSetBuilder = ImmutableSet.builder();
/*  47:101 */     for (Table.Cell<? extends R, ? extends C, ? extends V> cell : table.cellSet()) {
/*  48:106 */       cellSetBuilder.add(cellOf(cell.getRowKey(), cell.getColumnKey(), cell.getValue()));
/*  49:    */     }
/*  50:109 */     return RegularImmutableTable.forCells(cellSetBuilder.build());
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <R, C, V> Builder<R, C, V> builder()
/*  54:    */   {
/*  55:119 */     return new Builder();
/*  56:    */   }
/*  57:    */   
/*  58:    */   static <R, C, V> Table.Cell<R, C, V> cellOf(R rowKey, C columnKey, V value)
/*  59:    */   {
/*  60:127 */     return Tables.immutableCell(Preconditions.checkNotNull(rowKey), Preconditions.checkNotNull(columnKey), Preconditions.checkNotNull(value));
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static final class Builder<R, C, V>
/*  64:    */   {
/*  65:158 */     private final List<Table.Cell<R, C, V>> cells = Lists.newArrayList();
/*  66:    */     private Comparator<? super R> rowComparator;
/*  67:    */     private Comparator<? super C> columnComparator;
/*  68:    */     
/*  69:    */     public Builder<R, C, V> orderRowsBy(Comparator<? super R> rowComparator)
/*  70:    */     {
/*  71:172 */       this.rowComparator = ((Comparator)Preconditions.checkNotNull(rowComparator));
/*  72:173 */       return this;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public Builder<R, C, V> orderColumnsBy(Comparator<? super C> columnComparator)
/*  76:    */     {
/*  77:181 */       this.columnComparator = ((Comparator)Preconditions.checkNotNull(columnComparator));
/*  78:182 */       return this;
/*  79:    */     }
/*  80:    */     
/*  81:    */     public Builder<R, C, V> put(R rowKey, C columnKey, V value)
/*  82:    */     {
/*  83:191 */       this.cells.add(ImmutableTable.cellOf(rowKey, columnKey, value));
/*  84:192 */       return this;
/*  85:    */     }
/*  86:    */     
/*  87:    */     public Builder<R, C, V> put(Table.Cell<? extends R, ? extends C, ? extends V> cell)
/*  88:    */     {
/*  89:202 */       if ((cell instanceof Tables.ImmutableCell))
/*  90:    */       {
/*  91:203 */         Preconditions.checkNotNull(cell.getRowKey());
/*  92:204 */         Preconditions.checkNotNull(cell.getColumnKey());
/*  93:205 */         Preconditions.checkNotNull(cell.getValue());
/*  94:    */         
/*  95:207 */         Table.Cell<R, C, V> immutableCell = cell;
/*  96:208 */         this.cells.add(immutableCell);
/*  97:    */       }
/*  98:    */       else
/*  99:    */       {
/* 100:210 */         put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/* 101:    */       }
/* 102:212 */       return this;
/* 103:    */     }
/* 104:    */     
/* 105:    */     public Builder<R, C, V> putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 106:    */     {
/* 107:224 */       for (Table.Cell<? extends R, ? extends C, ? extends V> cell : table.cellSet()) {
/* 108:225 */         put(cell);
/* 109:    */       }
/* 110:227 */       return this;
/* 111:    */     }
/* 112:    */     
/* 113:    */     public ImmutableTable<R, C, V> build()
/* 114:    */     {
/* 115:236 */       int size = this.cells.size();
/* 116:237 */       switch (size)
/* 117:    */       {
/* 118:    */       case 0: 
/* 119:239 */         return ImmutableTable.of();
/* 120:    */       case 1: 
/* 121:241 */         return new SingletonImmutableTable((Table.Cell)Iterables.getOnlyElement(this.cells));
/* 122:    */       }
/* 123:244 */       return RegularImmutableTable.forCells(this.cells, this.rowComparator, this.columnComparator);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public ImmutableSet<Table.Cell<R, C, V>> cellSet()
/* 128:    */   {
/* 129:253 */     return (ImmutableSet)super.cellSet();
/* 130:    */   }
/* 131:    */   
/* 132:    */   abstract ImmutableSet<Table.Cell<R, C, V>> createCellSet();
/* 133:    */   
/* 134:    */   final UnmodifiableIterator<Table.Cell<R, C, V>> cellIterator()
/* 135:    */   {
/* 136:261 */     throw new AssertionError("should never be called");
/* 137:    */   }
/* 138:    */   
/* 139:    */   public ImmutableCollection<V> values()
/* 140:    */   {
/* 141:266 */     return (ImmutableCollection)super.values();
/* 142:    */   }
/* 143:    */   
/* 144:    */   abstract ImmutableCollection<V> createValues();
/* 145:    */   
/* 146:    */   final Iterator<V> valuesIterator()
/* 147:    */   {
/* 148:274 */     throw new AssertionError("should never be called");
/* 149:    */   }
/* 150:    */   
/* 151:    */   public ImmutableMap<R, V> column(C columnKey)
/* 152:    */   {
/* 153:283 */     Preconditions.checkNotNull(columnKey);
/* 154:284 */     return (ImmutableMap)Objects.firstNonNull((ImmutableMap)columnMap().get(columnKey), ImmutableMap.of());
/* 155:    */   }
/* 156:    */   
/* 157:    */   public ImmutableSet<C> columnKeySet()
/* 158:    */   {
/* 159:290 */     return columnMap().keySet();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public abstract ImmutableMap<C, Map<R, V>> columnMap();
/* 163:    */   
/* 164:    */   public ImmutableMap<C, V> row(R rowKey)
/* 165:    */   {
/* 166:307 */     Preconditions.checkNotNull(rowKey);
/* 167:308 */     return (ImmutableMap)Objects.firstNonNull((ImmutableMap)rowMap().get(rowKey), ImmutableMap.of());
/* 168:    */   }
/* 169:    */   
/* 170:    */   public ImmutableSet<R> rowKeySet()
/* 171:    */   {
/* 172:314 */     return rowMap().keySet();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public abstract ImmutableMap<R, Map<C, V>> rowMap();
/* 176:    */   
/* 177:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/* 178:    */   {
/* 179:327 */     return get(rowKey, columnKey) != null;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public boolean containsValue(@Nullable Object value)
/* 183:    */   {
/* 184:332 */     return values().contains(value);
/* 185:    */   }
/* 186:    */   
/* 187:    */   @Deprecated
/* 188:    */   public final void clear()
/* 189:    */   {
/* 190:342 */     throw new UnsupportedOperationException();
/* 191:    */   }
/* 192:    */   
/* 193:    */   @Deprecated
/* 194:    */   public final V put(R rowKey, C columnKey, V value)
/* 195:    */   {
/* 196:352 */     throw new UnsupportedOperationException();
/* 197:    */   }
/* 198:    */   
/* 199:    */   @Deprecated
/* 200:    */   public final void putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 201:    */   {
/* 202:363 */     throw new UnsupportedOperationException();
/* 203:    */   }
/* 204:    */   
/* 205:    */   @Deprecated
/* 206:    */   public final V remove(Object rowKey, Object columnKey)
/* 207:    */   {
/* 208:373 */     throw new UnsupportedOperationException();
/* 209:    */   }
/* 210:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableTable
 * JD-Core Version:    0.7.0.1
 */
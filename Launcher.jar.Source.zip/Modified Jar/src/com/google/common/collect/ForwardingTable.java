/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class ForwardingTable<R, C, V>
/*  10:    */   extends ForwardingObject
/*  11:    */   implements Table<R, C, V>
/*  12:    */ {
/*  13:    */   protected abstract Table<R, C, V> delegate();
/*  14:    */   
/*  15:    */   public Set<Table.Cell<R, C, V>> cellSet()
/*  16:    */   {
/*  17: 44 */     return delegate().cellSet();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void clear()
/*  21:    */   {
/*  22: 49 */     delegate().clear();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Map<R, V> column(C columnKey)
/*  26:    */   {
/*  27: 54 */     return delegate().column(columnKey);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Set<C> columnKeySet()
/*  31:    */   {
/*  32: 59 */     return delegate().columnKeySet();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Map<C, Map<R, V>> columnMap()
/*  36:    */   {
/*  37: 64 */     return delegate().columnMap();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean contains(Object rowKey, Object columnKey)
/*  41:    */   {
/*  42: 69 */     return delegate().contains(rowKey, columnKey);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean containsColumn(Object columnKey)
/*  46:    */   {
/*  47: 74 */     return delegate().containsColumn(columnKey);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean containsRow(Object rowKey)
/*  51:    */   {
/*  52: 79 */     return delegate().containsRow(rowKey);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean containsValue(Object value)
/*  56:    */   {
/*  57: 84 */     return delegate().containsValue(value);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public V get(Object rowKey, Object columnKey)
/*  61:    */   {
/*  62: 89 */     return delegate().get(rowKey, columnKey);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isEmpty()
/*  66:    */   {
/*  67: 94 */     return delegate().isEmpty();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public V put(R rowKey, C columnKey, V value)
/*  71:    */   {
/*  72: 99 */     return delegate().put(rowKey, columnKey, value);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/*  76:    */   {
/*  77:104 */     delegate().putAll(table);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public V remove(Object rowKey, Object columnKey)
/*  81:    */   {
/*  82:109 */     return delegate().remove(rowKey, columnKey);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Map<C, V> row(R rowKey)
/*  86:    */   {
/*  87:114 */     return delegate().row(rowKey);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Set<R> rowKeySet()
/*  91:    */   {
/*  92:119 */     return delegate().rowKeySet();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Map<R, Map<C, V>> rowMap()
/*  96:    */   {
/*  97:124 */     return delegate().rowMap();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int size()
/* 101:    */   {
/* 102:129 */     return delegate().size();
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Collection<V> values()
/* 106:    */   {
/* 107:134 */     return delegate().values();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean equals(Object obj)
/* 111:    */   {
/* 112:138 */     return (obj == this) || (delegate().equals(obj));
/* 113:    */   }
/* 114:    */   
/* 115:    */   public int hashCode()
/* 116:    */   {
/* 117:142 */     return delegate().hashCode();
/* 118:    */   }
/* 119:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ForwardingTable
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.math.IntMath;
/*   7:    */ import com.google.common.primitives.Ints;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.ObjectInputStream;
/*  10:    */ import java.io.ObjectOutputStream;
/*  11:    */ import java.io.Serializable;
/*  12:    */ import java.util.Collection;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.Set;
/*  17:    */ import java.util.concurrent.ConcurrentHashMap;
/*  18:    */ import java.util.concurrent.ConcurrentMap;
/*  19:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ public final class ConcurrentHashMultiset<E>
/*  23:    */   extends AbstractMultiset<E>
/*  24:    */   implements Serializable
/*  25:    */ {
/*  26:    */   private final transient ConcurrentMap<E, AtomicInteger> countMap;
/*  27:    */   private transient ConcurrentHashMultiset<E>.EntrySet entrySet;
/*  28:    */   private static final long serialVersionUID = 1L;
/*  29:    */   
/*  30:    */   private static class FieldSettersHolder
/*  31:    */   {
/*  32: 75 */     static final Serialization.FieldSetter<ConcurrentHashMultiset> COUNT_MAP_FIELD_SETTER = Serialization.getFieldSetter(ConcurrentHashMultiset.class, "countMap");
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <E> ConcurrentHashMultiset<E> create()
/*  36:    */   {
/*  37: 87 */     return new ConcurrentHashMultiset(new ConcurrentHashMap());
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E> ConcurrentHashMultiset<E> create(Iterable<? extends E> elements)
/*  41:    */   {
/*  42: 99 */     ConcurrentHashMultiset<E> multiset = create();
/*  43:100 */     Iterables.addAll(multiset, elements);
/*  44:101 */     return multiset;
/*  45:    */   }
/*  46:    */   
/*  47:    */   @Beta
/*  48:    */   public static <E> ConcurrentHashMultiset<E> create(MapMaker mapMaker)
/*  49:    */   {
/*  50:127 */     return new ConcurrentHashMultiset(mapMaker.makeMap());
/*  51:    */   }
/*  52:    */   
/*  53:    */   @VisibleForTesting
/*  54:    */   ConcurrentHashMultiset(ConcurrentMap<E, AtomicInteger> countMap)
/*  55:    */   {
/*  56:141 */     Preconditions.checkArgument(countMap.isEmpty());
/*  57:142 */     this.countMap = countMap;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public int count(@Nullable Object element)
/*  61:    */   {
/*  62:154 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/*  63:155 */     return existingCounter == null ? 0 : existingCounter.get();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int size()
/*  67:    */   {
/*  68:165 */     long sum = 0L;
/*  69:166 */     for (AtomicInteger value : this.countMap.values()) {
/*  70:167 */       sum += value.get();
/*  71:    */     }
/*  72:169 */     return Ints.saturatedCast(sum);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Object[] toArray()
/*  76:    */   {
/*  77:178 */     return snapshot().toArray();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public <T> T[] toArray(T[] array)
/*  81:    */   {
/*  82:182 */     return snapshot().toArray(array);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private List<E> snapshot()
/*  86:    */   {
/*  87:190 */     List<E> list = Lists.newArrayListWithExpectedSize(size());
/*  88:191 */     for (Multiset.Entry<E> entry : entrySet())
/*  89:    */     {
/*  90:192 */       E element = entry.getElement();
/*  91:193 */       for (int i = entry.getCount(); i > 0; i--) {
/*  92:194 */         list.add(element);
/*  93:    */       }
/*  94:    */     }
/*  95:197 */     return list;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public int add(E element, int occurrences)
/*  99:    */   {
/* 100:212 */     Preconditions.checkNotNull(element);
/* 101:213 */     if (occurrences == 0) {
/* 102:214 */       return count(element);
/* 103:    */     }
/* 104:216 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/* 105:    */     for (;;)
/* 106:    */     {
/* 107:219 */       AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 108:220 */       if (existingCounter == null)
/* 109:    */       {
/* 110:221 */         existingCounter = (AtomicInteger)this.countMap.putIfAbsent(element, new AtomicInteger(occurrences));
/* 111:222 */         if (existingCounter == null) {
/* 112:223 */           return 0;
/* 113:    */         }
/* 114:    */       }
/* 115:    */       for (;;)
/* 116:    */       {
/* 117:229 */         int oldValue = existingCounter.get();
/* 118:230 */         if (oldValue != 0)
/* 119:    */         {
/* 120:    */           try
/* 121:    */           {
/* 122:232 */             int newValue = IntMath.checkedAdd(oldValue, occurrences);
/* 123:233 */             if (existingCounter.compareAndSet(oldValue, newValue)) {
/* 124:235 */               return oldValue;
/* 125:    */             }
/* 126:    */           }
/* 127:    */           catch (ArithmeticException overflow)
/* 128:    */           {
/* 129:238 */             throw new IllegalArgumentException("Overflow adding " + occurrences + " occurrences to a count of " + oldValue);
/* 130:    */           }
/* 131:    */         }
/* 132:    */         else
/* 133:    */         {
/* 134:245 */           AtomicInteger newCounter = new AtomicInteger(occurrences);
/* 135:246 */           if ((this.countMap.putIfAbsent(element, newCounter) != null) && (!this.countMap.replace(element, existingCounter, newCounter))) {
/* 136:    */             break;
/* 137:    */           }
/* 138:248 */           return 0;
/* 139:    */         }
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   public int remove(@Nullable Object element, int occurrences)
/* 145:    */   {
/* 146:277 */     if (occurrences == 0) {
/* 147:278 */       return count(element);
/* 148:    */     }
/* 149:280 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/* 150:    */     
/* 151:282 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 152:283 */     if (existingCounter == null) {
/* 153:284 */       return 0;
/* 154:    */     }
/* 155:    */     for (;;)
/* 156:    */     {
/* 157:287 */       int oldValue = existingCounter.get();
/* 158:288 */       if (oldValue != 0)
/* 159:    */       {
/* 160:289 */         int newValue = Math.max(0, oldValue - occurrences);
/* 161:290 */         if (existingCounter.compareAndSet(oldValue, newValue))
/* 162:    */         {
/* 163:291 */           if (newValue == 0) {
/* 164:294 */             this.countMap.remove(element, existingCounter);
/* 165:    */           }
/* 166:296 */           return oldValue;
/* 167:    */         }
/* 168:    */       }
/* 169:    */       else
/* 170:    */       {
/* 171:299 */         return 0;
/* 172:    */       }
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public boolean removeExactly(@Nullable Object element, int occurrences)
/* 177:    */   {
/* 178:316 */     if (occurrences == 0) {
/* 179:317 */       return true;
/* 180:    */     }
/* 181:319 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/* 182:    */     
/* 183:321 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 184:322 */     if (existingCounter == null) {
/* 185:323 */       return false;
/* 186:    */     }
/* 187:    */     for (;;)
/* 188:    */     {
/* 189:326 */       int oldValue = existingCounter.get();
/* 190:327 */       if (oldValue < occurrences) {
/* 191:328 */         return false;
/* 192:    */       }
/* 193:330 */       int newValue = oldValue - occurrences;
/* 194:331 */       if (existingCounter.compareAndSet(oldValue, newValue))
/* 195:    */       {
/* 196:332 */         if (newValue == 0) {
/* 197:335 */           this.countMap.remove(element, existingCounter);
/* 198:    */         }
/* 199:337 */         return true;
/* 200:    */       }
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public int setCount(E element, int count)
/* 205:    */   {
/* 206:350 */     Preconditions.checkNotNull(element);
/* 207:351 */     CollectPreconditions.checkNonnegative(count, "count");
/* 208:    */     for (;;)
/* 209:    */     {
/* 210:353 */       AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 211:354 */       if (existingCounter == null)
/* 212:    */       {
/* 213:355 */         if (count == 0) {
/* 214:356 */           return 0;
/* 215:    */         }
/* 216:358 */         existingCounter = (AtomicInteger)this.countMap.putIfAbsent(element, new AtomicInteger(count));
/* 217:359 */         if (existingCounter == null) {
/* 218:360 */           return 0;
/* 219:    */         }
/* 220:    */       }
/* 221:    */       for (;;)
/* 222:    */       {
/* 223:367 */         int oldValue = existingCounter.get();
/* 224:368 */         if (oldValue == 0)
/* 225:    */         {
/* 226:369 */           if (count == 0) {
/* 227:370 */             return 0;
/* 228:    */           }
/* 229:372 */           AtomicInteger newCounter = new AtomicInteger(count);
/* 230:373 */           if ((this.countMap.putIfAbsent(element, newCounter) == null) || (this.countMap.replace(element, existingCounter, newCounter))) {
/* 231:375 */             return 0;
/* 232:    */           }
/* 233:378 */           break;
/* 234:    */         }
/* 235:380 */         if (existingCounter.compareAndSet(oldValue, count))
/* 236:    */         {
/* 237:381 */           if (count == 0) {
/* 238:384 */             this.countMap.remove(element, existingCounter);
/* 239:    */           }
/* 240:386 */           return oldValue;
/* 241:    */         }
/* 242:    */       }
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   public boolean setCount(E element, int expectedOldCount, int newCount)
/* 247:    */   {
/* 248:405 */     Preconditions.checkNotNull(element);
/* 249:406 */     CollectPreconditions.checkNonnegative(expectedOldCount, "oldCount");
/* 250:407 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/* 251:    */     
/* 252:409 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 253:410 */     if (existingCounter == null)
/* 254:    */     {
/* 255:411 */       if (expectedOldCount != 0) {
/* 256:412 */         return false;
/* 257:    */       }
/* 258:413 */       if (newCount == 0) {
/* 259:414 */         return true;
/* 260:    */       }
/* 261:417 */       return this.countMap.putIfAbsent(element, new AtomicInteger(newCount)) == null;
/* 262:    */     }
/* 263:420 */     int oldValue = existingCounter.get();
/* 264:421 */     if (oldValue == expectedOldCount)
/* 265:    */     {
/* 266:422 */       if (oldValue == 0)
/* 267:    */       {
/* 268:423 */         if (newCount == 0)
/* 269:    */         {
/* 270:425 */           this.countMap.remove(element, existingCounter);
/* 271:426 */           return true;
/* 272:    */         }
/* 273:428 */         AtomicInteger newCounter = new AtomicInteger(newCount);
/* 274:429 */         return (this.countMap.putIfAbsent(element, newCounter) == null) || (this.countMap.replace(element, existingCounter, newCounter));
/* 275:    */       }
/* 276:433 */       if (existingCounter.compareAndSet(oldValue, newCount))
/* 277:    */       {
/* 278:434 */         if (newCount == 0) {
/* 279:437 */           this.countMap.remove(element, existingCounter);
/* 280:    */         }
/* 281:439 */         return true;
/* 282:    */       }
/* 283:    */     }
/* 284:443 */     return false;
/* 285:    */   }
/* 286:    */   
/* 287:    */   Set<E> createElementSet()
/* 288:    */   {
/* 289:449 */     final Set<E> delegate = this.countMap.keySet();
/* 290:450 */     new ForwardingSet()
/* 291:    */     {
/* 292:    */       protected Set<E> delegate()
/* 293:    */       {
/* 294:452 */         return delegate;
/* 295:    */       }
/* 296:    */       
/* 297:    */       public boolean contains(@Nullable Object object)
/* 298:    */       {
/* 299:457 */         return (object != null) && (Collections2.safeContains(delegate, object));
/* 300:    */       }
/* 301:    */       
/* 302:    */       public boolean containsAll(Collection<?> collection)
/* 303:    */       {
/* 304:462 */         return standardContainsAll(collection);
/* 305:    */       }
/* 306:    */       
/* 307:    */       public boolean remove(Object object)
/* 308:    */       {
/* 309:466 */         return (object != null) && (Collections2.safeRemove(delegate, object));
/* 310:    */       }
/* 311:    */       
/* 312:    */       public boolean removeAll(Collection<?> c)
/* 313:    */       {
/* 314:470 */         return standardRemoveAll(c);
/* 315:    */       }
/* 316:    */     };
/* 317:    */   }
/* 318:    */   
/* 319:    */   public Set<Multiset.Entry<E>> entrySet()
/* 320:    */   {
/* 321:478 */     ConcurrentHashMultiset<E>.EntrySet result = this.entrySet;
/* 322:479 */     if (result == null) {
/* 323:480 */       this.entrySet = (result = new EntrySet(null));
/* 324:    */     }
/* 325:482 */     return result;
/* 326:    */   }
/* 327:    */   
/* 328:    */   int distinctElements()
/* 329:    */   {
/* 330:486 */     return this.countMap.size();
/* 331:    */   }
/* 332:    */   
/* 333:    */   public boolean isEmpty()
/* 334:    */   {
/* 335:490 */     return this.countMap.isEmpty();
/* 336:    */   }
/* 337:    */   
/* 338:    */   Iterator<Multiset.Entry<E>> entryIterator()
/* 339:    */   {
/* 340:496 */     final Iterator<Multiset.Entry<E>> readOnlyIterator = new AbstractIterator()
/* 341:    */     {
/* 342:498 */       private Iterator<Map.Entry<E, AtomicInteger>> mapEntries = ConcurrentHashMultiset.this.countMap.entrySet().iterator();
/* 343:    */       
/* 344:    */       protected Multiset.Entry<E> computeNext()
/* 345:    */       {
/* 346:    */         for (;;)
/* 347:    */         {
/* 348:502 */           if (!this.mapEntries.hasNext()) {
/* 349:503 */             return (Multiset.Entry)endOfData();
/* 350:    */           }
/* 351:505 */           Map.Entry<E, AtomicInteger> mapEntry = (Map.Entry)this.mapEntries.next();
/* 352:506 */           int count = ((AtomicInteger)mapEntry.getValue()).get();
/* 353:507 */           if (count != 0) {
/* 354:508 */             return Multisets.immutableEntry(mapEntry.getKey(), count);
/* 355:    */           }
/* 356:    */         }
/* 357:    */       }
/* 358:513 */     };
/* 359:514 */     new ForwardingIterator()
/* 360:    */     {
/* 361:    */       private Multiset.Entry<E> last;
/* 362:    */       
/* 363:    */       protected Iterator<Multiset.Entry<E>> delegate()
/* 364:    */       {
/* 365:518 */         return readOnlyIterator;
/* 366:    */       }
/* 367:    */       
/* 368:    */       public Multiset.Entry<E> next()
/* 369:    */       {
/* 370:522 */         this.last = ((Multiset.Entry)super.next());
/* 371:523 */         return this.last;
/* 372:    */       }
/* 373:    */       
/* 374:    */       public void remove()
/* 375:    */       {
/* 376:527 */         CollectPreconditions.checkRemove(this.last != null);
/* 377:528 */         ConcurrentHashMultiset.this.setCount(this.last.getElement(), 0);
/* 378:529 */         this.last = null;
/* 379:    */       }
/* 380:    */     };
/* 381:    */   }
/* 382:    */   
/* 383:    */   public void clear()
/* 384:    */   {
/* 385:535 */     this.countMap.clear();
/* 386:    */   }
/* 387:    */   
/* 388:    */   private class EntrySet
/* 389:    */     extends AbstractMultiset<E>.EntrySet
/* 390:    */   {
/* 391:    */     private EntrySet()
/* 392:    */     {
/* 393:538 */       super();
/* 394:    */     }
/* 395:    */     
/* 396:    */     ConcurrentHashMultiset<E> multiset()
/* 397:    */     {
/* 398:540 */       return ConcurrentHashMultiset.this;
/* 399:    */     }
/* 400:    */     
/* 401:    */     public Object[] toArray()
/* 402:    */     {
/* 403:549 */       return snapshot().toArray();
/* 404:    */     }
/* 405:    */     
/* 406:    */     public <T> T[] toArray(T[] array)
/* 407:    */     {
/* 408:553 */       return snapshot().toArray(array);
/* 409:    */     }
/* 410:    */     
/* 411:    */     private List<Multiset.Entry<E>> snapshot()
/* 412:    */     {
/* 413:557 */       List<Multiset.Entry<E>> list = Lists.newArrayListWithExpectedSize(size());
/* 414:    */       
/* 415:559 */       Iterators.addAll(list, iterator());
/* 416:560 */       return list;
/* 417:    */     }
/* 418:    */   }
/* 419:    */   
/* 420:    */   private void writeObject(ObjectOutputStream stream)
/* 421:    */     throws IOException
/* 422:    */   {
/* 423:568 */     stream.defaultWriteObject();
/* 424:569 */     stream.writeObject(this.countMap);
/* 425:    */   }
/* 426:    */   
/* 427:    */   private void readObject(ObjectInputStream stream)
/* 428:    */     throws IOException, ClassNotFoundException
/* 429:    */   {
/* 430:573 */     stream.defaultReadObject();
/* 431:    */     
/* 432:575 */     ConcurrentMap<E, Integer> deserializedCountMap = (ConcurrentMap)stream.readObject();
/* 433:    */     
/* 434:577 */     FieldSettersHolder.COUNT_MAP_FIELD_SETTER.set(this, deserializedCountMap);
/* 435:    */   }
/* 436:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ConcurrentHashMultiset
 * JD-Core Version:    0.7.0.1
 */
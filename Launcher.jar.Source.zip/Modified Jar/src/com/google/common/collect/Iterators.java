/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Objects;
/*    8:     */ import com.google.common.base.Optional;
/*    9:     */ import com.google.common.base.Preconditions;
/*   10:     */ import com.google.common.base.Predicate;
/*   11:     */ import com.google.common.base.Predicates;
/*   12:     */ import java.util.Arrays;
/*   13:     */ import java.util.Collection;
/*   14:     */ import java.util.Collections;
/*   15:     */ import java.util.Comparator;
/*   16:     */ import java.util.Enumeration;
/*   17:     */ import java.util.Iterator;
/*   18:     */ import java.util.List;
/*   19:     */ import java.util.ListIterator;
/*   20:     */ import java.util.NoSuchElementException;
/*   21:     */ import java.util.PriorityQueue;
/*   22:     */ import java.util.Queue;
/*   23:     */ import javax.annotation.Nullable;
/*   24:     */ 
/*   25:     */ @GwtCompatible(emulated=true)
/*   26:     */ public final class Iterators
/*   27:     */ {
/*   28:  72 */   static final UnmodifiableListIterator<Object> EMPTY_LIST_ITERATOR = new UnmodifiableListIterator()
/*   29:     */   {
/*   30:     */     public boolean hasNext()
/*   31:     */     {
/*   32:  76 */       return false;
/*   33:     */     }
/*   34:     */     
/*   35:     */     public Object next()
/*   36:     */     {
/*   37:  80 */       throw new NoSuchElementException();
/*   38:     */     }
/*   39:     */     
/*   40:     */     public boolean hasPrevious()
/*   41:     */     {
/*   42:  84 */       return false;
/*   43:     */     }
/*   44:     */     
/*   45:     */     public Object previous()
/*   46:     */     {
/*   47:  88 */       throw new NoSuchElementException();
/*   48:     */     }
/*   49:     */     
/*   50:     */     public int nextIndex()
/*   51:     */     {
/*   52:  92 */       return 0;
/*   53:     */     }
/*   54:     */     
/*   55:     */     public int previousIndex()
/*   56:     */     {
/*   57:  96 */       return -1;
/*   58:     */     }
/*   59:     */   };
/*   60:     */   
/*   61:     */   public static <T> UnmodifiableIterator<T> emptyIterator()
/*   62:     */   {
/*   63: 107 */     return emptyListIterator();
/*   64:     */   }
/*   65:     */   
/*   66:     */   static <T> UnmodifiableListIterator<T> emptyListIterator()
/*   67:     */   {
/*   68: 119 */     return EMPTY_LIST_ITERATOR;
/*   69:     */   }
/*   70:     */   
/*   71: 122 */   private static final Iterator<Object> EMPTY_MODIFIABLE_ITERATOR = new Iterator()
/*   72:     */   {
/*   73:     */     public boolean hasNext()
/*   74:     */     {
/*   75: 125 */       return false;
/*   76:     */     }
/*   77:     */     
/*   78:     */     public Object next()
/*   79:     */     {
/*   80: 129 */       throw new NoSuchElementException();
/*   81:     */     }
/*   82:     */     
/*   83:     */     public void remove()
/*   84:     */     {
/*   85: 133 */       CollectPreconditions.checkRemove(false);
/*   86:     */     }
/*   87:     */   };
/*   88:     */   
/*   89:     */   static <T> Iterator<T> emptyModifiableIterator()
/*   90:     */   {
/*   91: 146 */     return EMPTY_MODIFIABLE_ITERATOR;
/*   92:     */   }
/*   93:     */   
/*   94:     */   public static <T> UnmodifiableIterator<T> unmodifiableIterator(Iterator<T> iterator)
/*   95:     */   {
/*   96: 152 */     Preconditions.checkNotNull(iterator);
/*   97: 153 */     if ((iterator instanceof UnmodifiableIterator)) {
/*   98: 154 */       return (UnmodifiableIterator)iterator;
/*   99:     */     }
/*  100: 156 */     new UnmodifiableIterator()
/*  101:     */     {
/*  102:     */       public boolean hasNext()
/*  103:     */       {
/*  104: 159 */         return this.val$iterator.hasNext();
/*  105:     */       }
/*  106:     */       
/*  107:     */       public T next()
/*  108:     */       {
/*  109: 163 */         return this.val$iterator.next();
/*  110:     */       }
/*  111:     */     };
/*  112:     */   }
/*  113:     */   
/*  114:     */   @Deprecated
/*  115:     */   public static <T> UnmodifiableIterator<T> unmodifiableIterator(UnmodifiableIterator<T> iterator)
/*  116:     */   {
/*  117: 176 */     return (UnmodifiableIterator)Preconditions.checkNotNull(iterator);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static int size(Iterator<?> iterator)
/*  121:     */   {
/*  122: 185 */     int count = 0;
/*  123: 186 */     while (iterator.hasNext())
/*  124:     */     {
/*  125: 187 */       iterator.next();
/*  126: 188 */       count++;
/*  127:     */     }
/*  128: 190 */     return count;
/*  129:     */   }
/*  130:     */   
/*  131:     */   public static boolean contains(Iterator<?> iterator, @Nullable Object element)
/*  132:     */   {
/*  133: 197 */     return any(iterator, Predicates.equalTo(element));
/*  134:     */   }
/*  135:     */   
/*  136:     */   public static boolean removeAll(Iterator<?> removeFrom, Collection<?> elementsToRemove)
/*  137:     */   {
/*  138: 211 */     return removeIf(removeFrom, Predicates.in(elementsToRemove));
/*  139:     */   }
/*  140:     */   
/*  141:     */   public static <T> boolean removeIf(Iterator<T> removeFrom, Predicate<? super T> predicate)
/*  142:     */   {
/*  143: 227 */     Preconditions.checkNotNull(predicate);
/*  144: 228 */     boolean modified = false;
/*  145: 229 */     while (removeFrom.hasNext()) {
/*  146: 230 */       if (predicate.apply(removeFrom.next()))
/*  147:     */       {
/*  148: 231 */         removeFrom.remove();
/*  149: 232 */         modified = true;
/*  150:     */       }
/*  151:     */     }
/*  152: 235 */     return modified;
/*  153:     */   }
/*  154:     */   
/*  155:     */   public static boolean retainAll(Iterator<?> removeFrom, Collection<?> elementsToRetain)
/*  156:     */   {
/*  157: 249 */     return removeIf(removeFrom, Predicates.not(Predicates.in(elementsToRetain)));
/*  158:     */   }
/*  159:     */   
/*  160:     */   public static boolean elementsEqual(Iterator<?> iterator1, Iterator<?> iterator2)
/*  161:     */   {
/*  162: 264 */     while (iterator1.hasNext())
/*  163:     */     {
/*  164: 265 */       if (!iterator2.hasNext()) {
/*  165: 266 */         return false;
/*  166:     */       }
/*  167: 268 */       Object o1 = iterator1.next();
/*  168: 269 */       Object o2 = iterator2.next();
/*  169: 270 */       if (!Objects.equal(o1, o2)) {
/*  170: 271 */         return false;
/*  171:     */       }
/*  172:     */     }
/*  173: 274 */     return !iterator2.hasNext();
/*  174:     */   }
/*  175:     */   
/*  176:     */   public static String toString(Iterator<?> iterator)
/*  177:     */   {
/*  178: 283 */     return ']';
/*  179:     */   }
/*  180:     */   
/*  181:     */   public static <T> T getOnlyElement(Iterator<T> iterator)
/*  182:     */   {
/*  183: 297 */     T first = iterator.next();
/*  184: 298 */     if (!iterator.hasNext()) {
/*  185: 299 */       return first;
/*  186:     */     }
/*  187: 302 */     StringBuilder sb = new StringBuilder();
/*  188: 303 */     sb.append("expected one element but was: <" + first);
/*  189: 304 */     for (int i = 0; (i < 4) && (iterator.hasNext()); i++) {
/*  190: 305 */       sb.append(", " + iterator.next());
/*  191:     */     }
/*  192: 307 */     if (iterator.hasNext()) {
/*  193: 308 */       sb.append(", ...");
/*  194:     */     }
/*  195: 310 */     sb.append('>');
/*  196:     */     
/*  197: 312 */     throw new IllegalArgumentException(sb.toString());
/*  198:     */   }
/*  199:     */   
/*  200:     */   @Nullable
/*  201:     */   public static <T> T getOnlyElement(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  202:     */   {
/*  203: 324 */     return iterator.hasNext() ? getOnlyElement(iterator) : defaultValue;
/*  204:     */   }
/*  205:     */   
/*  206:     */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  207:     */   public static <T> T[] toArray(Iterator<? extends T> iterator, Class<T> type)
/*  208:     */   {
/*  209: 339 */     List<T> list = Lists.newArrayList(iterator);
/*  210: 340 */     return Iterables.toArray(list, type);
/*  211:     */   }
/*  212:     */   
/*  213:     */   public static <T> boolean addAll(Collection<T> addTo, Iterator<? extends T> iterator)
/*  214:     */   {
/*  215: 353 */     Preconditions.checkNotNull(addTo);
/*  216: 354 */     Preconditions.checkNotNull(iterator);
/*  217: 355 */     boolean wasModified = false;
/*  218: 356 */     while (iterator.hasNext()) {
/*  219: 357 */       wasModified |= addTo.add(iterator.next());
/*  220:     */     }
/*  221: 359 */     return wasModified;
/*  222:     */   }
/*  223:     */   
/*  224:     */   public static int frequency(Iterator<?> iterator, @Nullable Object element)
/*  225:     */   {
/*  226: 370 */     return size(filter(iterator, Predicates.equalTo(element)));
/*  227:     */   }
/*  228:     */   
/*  229:     */   public static <T> Iterator<T> cycle(Iterable<T> iterable)
/*  230:     */   {
/*  231: 388 */     Preconditions.checkNotNull(iterable);
/*  232: 389 */     new Iterator()
/*  233:     */     {
/*  234: 390 */       Iterator<T> iterator = Iterators.emptyIterator();
/*  235:     */       Iterator<T> removeFrom;
/*  236:     */       
/*  237:     */       public boolean hasNext()
/*  238:     */       {
/*  239: 395 */         if (!this.iterator.hasNext()) {
/*  240: 396 */           this.iterator = this.val$iterable.iterator();
/*  241:     */         }
/*  242: 398 */         return this.iterator.hasNext();
/*  243:     */       }
/*  244:     */       
/*  245:     */       public T next()
/*  246:     */       {
/*  247: 402 */         if (!hasNext()) {
/*  248: 403 */           throw new NoSuchElementException();
/*  249:     */         }
/*  250: 405 */         this.removeFrom = this.iterator;
/*  251: 406 */         return this.iterator.next();
/*  252:     */       }
/*  253:     */       
/*  254:     */       public void remove()
/*  255:     */       {
/*  256: 410 */         CollectPreconditions.checkRemove(this.removeFrom != null);
/*  257: 411 */         this.removeFrom.remove();
/*  258: 412 */         this.removeFrom = null;
/*  259:     */       }
/*  260:     */     };
/*  261:     */   }
/*  262:     */   
/*  263:     */   public static <T> Iterator<T> cycle(T... elements)
/*  264:     */   {
/*  265: 431 */     return cycle(Lists.newArrayList(elements));
/*  266:     */   }
/*  267:     */   
/*  268:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b)
/*  269:     */   {
/*  270: 449 */     return concat(ImmutableList.of(a, b).iterator());
/*  271:     */   }
/*  272:     */   
/*  273:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c)
/*  274:     */   {
/*  275: 468 */     return concat(ImmutableList.of(a, b, c).iterator());
/*  276:     */   }
/*  277:     */   
/*  278:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c, Iterator<? extends T> d)
/*  279:     */   {
/*  280: 488 */     return concat(ImmutableList.of(a, b, c, d).iterator());
/*  281:     */   }
/*  282:     */   
/*  283:     */   public static <T> Iterator<T> concat(Iterator<? extends T>... inputs)
/*  284:     */   {
/*  285: 507 */     return concat(ImmutableList.copyOf(inputs).iterator());
/*  286:     */   }
/*  287:     */   
/*  288:     */   public static <T> Iterator<T> concat(Iterator<? extends Iterator<? extends T>> inputs)
/*  289:     */   {
/*  290: 526 */     Preconditions.checkNotNull(inputs);
/*  291: 527 */     new Iterator()
/*  292:     */     {
/*  293: 528 */       Iterator<? extends T> current = Iterators.emptyIterator();
/*  294:     */       Iterator<? extends T> removeFrom;
/*  295:     */       
/*  296:     */       public boolean hasNext()
/*  297:     */       {
/*  298:     */         boolean currentHasNext;
/*  299: 542 */         while ((!(currentHasNext = ((Iterator)Preconditions.checkNotNull(this.current)).hasNext())) && (this.val$inputs.hasNext())) {
/*  300: 543 */           this.current = ((Iterator)this.val$inputs.next());
/*  301:     */         }
/*  302: 545 */         return currentHasNext;
/*  303:     */       }
/*  304:     */       
/*  305:     */       public T next()
/*  306:     */       {
/*  307: 549 */         if (!hasNext()) {
/*  308: 550 */           throw new NoSuchElementException();
/*  309:     */         }
/*  310: 552 */         this.removeFrom = this.current;
/*  311: 553 */         return this.current.next();
/*  312:     */       }
/*  313:     */       
/*  314:     */       public void remove()
/*  315:     */       {
/*  316: 557 */         CollectPreconditions.checkRemove(this.removeFrom != null);
/*  317: 558 */         this.removeFrom.remove();
/*  318: 559 */         this.removeFrom = null;
/*  319:     */       }
/*  320:     */     };
/*  321:     */   }
/*  322:     */   
/*  323:     */   public static <T> UnmodifiableIterator<List<T>> partition(Iterator<T> iterator, int size)
/*  324:     */   {
/*  325: 581 */     return partitionImpl(iterator, size, false);
/*  326:     */   }
/*  327:     */   
/*  328:     */   public static <T> UnmodifiableIterator<List<T>> paddedPartition(Iterator<T> iterator, int size)
/*  329:     */   {
/*  330: 602 */     return partitionImpl(iterator, size, true);
/*  331:     */   }
/*  332:     */   
/*  333:     */   private static <T> UnmodifiableIterator<List<T>> partitionImpl(Iterator<T> iterator, final int size, final boolean pad)
/*  334:     */   {
/*  335: 607 */     Preconditions.checkNotNull(iterator);
/*  336: 608 */     Preconditions.checkArgument(size > 0);
/*  337: 609 */     new UnmodifiableIterator()
/*  338:     */     {
/*  339:     */       public boolean hasNext()
/*  340:     */       {
/*  341: 612 */         return this.val$iterator.hasNext();
/*  342:     */       }
/*  343:     */       
/*  344:     */       public List<T> next()
/*  345:     */       {
/*  346: 616 */         if (!hasNext()) {
/*  347: 617 */           throw new NoSuchElementException();
/*  348:     */         }
/*  349: 619 */         Object[] array = new Object[size];
/*  350: 620 */         for (int count = 0; (count < size) && (this.val$iterator.hasNext()); count++) {
/*  351: 622 */           array[count] = this.val$iterator.next();
/*  352:     */         }
/*  353: 624 */         for (int i = count; i < size; i++) {
/*  354: 625 */           array[i] = null;
/*  355:     */         }
/*  356: 629 */         List<T> list = Collections.unmodifiableList(Arrays.asList(array));
/*  357:     */         
/*  358: 631 */         return (pad) || (count == size) ? list : list.subList(0, count);
/*  359:     */       }
/*  360:     */     };
/*  361:     */   }
/*  362:     */   
/*  363:     */   public static <T> UnmodifiableIterator<T> filter(Iterator<T> unfiltered, final Predicate<? super T> predicate)
/*  364:     */   {
/*  365: 641 */     Preconditions.checkNotNull(unfiltered);
/*  366: 642 */     Preconditions.checkNotNull(predicate);
/*  367: 643 */     new AbstractIterator()
/*  368:     */     {
/*  369:     */       protected T computeNext()
/*  370:     */       {
/*  371: 645 */         while (this.val$unfiltered.hasNext())
/*  372:     */         {
/*  373: 646 */           T element = this.val$unfiltered.next();
/*  374: 647 */           if (predicate.apply(element)) {
/*  375: 648 */             return element;
/*  376:     */           }
/*  377:     */         }
/*  378: 651 */         return endOfData();
/*  379:     */       }
/*  380:     */     };
/*  381:     */   }
/*  382:     */   
/*  383:     */   @GwtIncompatible("Class.isInstance")
/*  384:     */   public static <T> UnmodifiableIterator<T> filter(Iterator<?> unfiltered, Class<T> type)
/*  385:     */   {
/*  386: 670 */     return filter(unfiltered, Predicates.instanceOf(type));
/*  387:     */   }
/*  388:     */   
/*  389:     */   public static <T> boolean any(Iterator<T> iterator, Predicate<? super T> predicate)
/*  390:     */   {
/*  391: 679 */     return indexOf(iterator, predicate) != -1;
/*  392:     */   }
/*  393:     */   
/*  394:     */   public static <T> boolean all(Iterator<T> iterator, Predicate<? super T> predicate)
/*  395:     */   {
/*  396: 689 */     Preconditions.checkNotNull(predicate);
/*  397: 690 */     while (iterator.hasNext())
/*  398:     */     {
/*  399: 691 */       T element = iterator.next();
/*  400: 692 */       if (!predicate.apply(element)) {
/*  401: 693 */         return false;
/*  402:     */       }
/*  403:     */     }
/*  404: 696 */     return true;
/*  405:     */   }
/*  406:     */   
/*  407:     */   public static <T> T find(Iterator<T> iterator, Predicate<? super T> predicate)
/*  408:     */   {
/*  409: 712 */     return filter(iterator, predicate).next();
/*  410:     */   }
/*  411:     */   
/*  412:     */   @Nullable
/*  413:     */   public static <T> T find(Iterator<? extends T> iterator, Predicate<? super T> predicate, @Nullable T defaultValue)
/*  414:     */   {
/*  415: 728 */     return getNext(filter(iterator, predicate), defaultValue);
/*  416:     */   }
/*  417:     */   
/*  418:     */   public static <T> Optional<T> tryFind(Iterator<T> iterator, Predicate<? super T> predicate)
/*  419:     */   {
/*  420: 746 */     UnmodifiableIterator<T> filteredIterator = filter(iterator, predicate);
/*  421: 747 */     return filteredIterator.hasNext() ? Optional.of(filteredIterator.next()) : Optional.absent();
/*  422:     */   }
/*  423:     */   
/*  424:     */   public static <T> int indexOf(Iterator<T> iterator, Predicate<? super T> predicate)
/*  425:     */   {
/*  426: 770 */     Preconditions.checkNotNull(predicate, "predicate");
/*  427: 771 */     for (int i = 0; iterator.hasNext(); i++)
/*  428:     */     {
/*  429: 772 */       T current = iterator.next();
/*  430: 773 */       if (predicate.apply(current)) {
/*  431: 774 */         return i;
/*  432:     */       }
/*  433:     */     }
/*  434: 777 */     return -1;
/*  435:     */   }
/*  436:     */   
/*  437:     */   public static <F, T> Iterator<T> transform(Iterator<F> fromIterator, final Function<? super F, ? extends T> function)
/*  438:     */   {
/*  439: 790 */     Preconditions.checkNotNull(function);
/*  440: 791 */     new TransformedIterator(fromIterator)
/*  441:     */     {
/*  442:     */       T transform(F from)
/*  443:     */       {
/*  444: 794 */         return function.apply(from);
/*  445:     */       }
/*  446:     */     };
/*  447:     */   }
/*  448:     */   
/*  449:     */   public static <T> T get(Iterator<T> iterator, int position)
/*  450:     */   {
/*  451: 810 */     checkNonnegative(position);
/*  452: 811 */     int skipped = advance(iterator, position);
/*  453: 812 */     if (!iterator.hasNext()) {
/*  454: 813 */       throw new IndexOutOfBoundsException("position (" + position + ") must be less than the number of elements that remained (" + skipped + ")");
/*  455:     */     }
/*  456: 817 */     return iterator.next();
/*  457:     */   }
/*  458:     */   
/*  459:     */   static void checkNonnegative(int position)
/*  460:     */   {
/*  461: 821 */     if (position < 0) {
/*  462: 822 */       throw new IndexOutOfBoundsException("position (" + position + ") must not be negative");
/*  463:     */     }
/*  464:     */   }
/*  465:     */   
/*  466:     */   @Nullable
/*  467:     */   public static <T> T get(Iterator<? extends T> iterator, int position, @Nullable T defaultValue)
/*  468:     */   {
/*  469: 844 */     checkNonnegative(position);
/*  470: 845 */     advance(iterator, position);
/*  471: 846 */     return getNext(iterator, defaultValue);
/*  472:     */   }
/*  473:     */   
/*  474:     */   @Nullable
/*  475:     */   public static <T> T getNext(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  476:     */   {
/*  477: 860 */     return iterator.hasNext() ? iterator.next() : defaultValue;
/*  478:     */   }
/*  479:     */   
/*  480:     */   public static <T> T getLast(Iterator<T> iterator)
/*  481:     */   {
/*  482:     */     for (;;)
/*  483:     */     {
/*  484: 871 */       T current = iterator.next();
/*  485: 872 */       if (!iterator.hasNext()) {
/*  486: 873 */         return current;
/*  487:     */       }
/*  488:     */     }
/*  489:     */   }
/*  490:     */   
/*  491:     */   @Nullable
/*  492:     */   public static <T> T getLast(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  493:     */   {
/*  494: 888 */     return iterator.hasNext() ? getLast(iterator) : defaultValue;
/*  495:     */   }
/*  496:     */   
/*  497:     */   public static int advance(Iterator<?> iterator, int numberToAdvance)
/*  498:     */   {
/*  499: 899 */     Preconditions.checkNotNull(iterator);
/*  500: 900 */     Preconditions.checkArgument(numberToAdvance >= 0, "numberToAdvance must be nonnegative");
/*  501: 903 */     for (int i = 0; (i < numberToAdvance) && (iterator.hasNext()); i++) {
/*  502: 904 */       iterator.next();
/*  503:     */     }
/*  504: 906 */     return i;
/*  505:     */   }
/*  506:     */   
/*  507:     */   public static <T> Iterator<T> limit(final Iterator<T> iterator, int limitSize)
/*  508:     */   {
/*  509: 923 */     Preconditions.checkNotNull(iterator);
/*  510: 924 */     Preconditions.checkArgument(limitSize >= 0, "limit is negative");
/*  511: 925 */     new Iterator()
/*  512:     */     {
/*  513:     */       private int count;
/*  514:     */       
/*  515:     */       public boolean hasNext()
/*  516:     */       {
/*  517: 930 */         return (this.count < this.val$limitSize) && (iterator.hasNext());
/*  518:     */       }
/*  519:     */       
/*  520:     */       public T next()
/*  521:     */       {
/*  522: 935 */         if (!hasNext()) {
/*  523: 936 */           throw new NoSuchElementException();
/*  524:     */         }
/*  525: 938 */         this.count += 1;
/*  526: 939 */         return iterator.next();
/*  527:     */       }
/*  528:     */       
/*  529:     */       public void remove()
/*  530:     */       {
/*  531: 944 */         iterator.remove();
/*  532:     */       }
/*  533:     */     };
/*  534:     */   }
/*  535:     */   
/*  536:     */   public static <T> Iterator<T> consumingIterator(Iterator<T> iterator)
/*  537:     */   {
/*  538: 963 */     Preconditions.checkNotNull(iterator);
/*  539: 964 */     new UnmodifiableIterator()
/*  540:     */     {
/*  541:     */       public boolean hasNext()
/*  542:     */       {
/*  543: 967 */         return this.val$iterator.hasNext();
/*  544:     */       }
/*  545:     */       
/*  546:     */       public T next()
/*  547:     */       {
/*  548: 972 */         T next = this.val$iterator.next();
/*  549: 973 */         this.val$iterator.remove();
/*  550: 974 */         return next;
/*  551:     */       }
/*  552:     */       
/*  553:     */       public String toString()
/*  554:     */       {
/*  555: 979 */         return "Iterators.consumingIterator(...)";
/*  556:     */       }
/*  557:     */     };
/*  558:     */   }
/*  559:     */   
/*  560:     */   @Nullable
/*  561:     */   static <T> T pollNext(Iterator<T> iterator)
/*  562:     */   {
/*  563: 990 */     if (iterator.hasNext())
/*  564:     */     {
/*  565: 991 */       T result = iterator.next();
/*  566: 992 */       iterator.remove();
/*  567: 993 */       return result;
/*  568:     */     }
/*  569: 995 */     return null;
/*  570:     */   }
/*  571:     */   
/*  572:     */   static void clear(Iterator<?> iterator)
/*  573:     */   {
/*  574:1005 */     Preconditions.checkNotNull(iterator);
/*  575:1006 */     while (iterator.hasNext())
/*  576:     */     {
/*  577:1007 */       iterator.next();
/*  578:1008 */       iterator.remove();
/*  579:     */     }
/*  580:     */   }
/*  581:     */   
/*  582:     */   public static <T> UnmodifiableIterator<T> forArray(T... array)
/*  583:     */   {
/*  584:1026 */     return forArray(array, 0, array.length, 0);
/*  585:     */   }
/*  586:     */   
/*  587:     */   static <T> UnmodifiableListIterator<T> forArray(final T[] array, final int offset, int length, int index)
/*  588:     */   {
/*  589:1038 */     Preconditions.checkArgument(length >= 0);
/*  590:1039 */     int end = offset + length;
/*  591:     */     
/*  592:     */ 
/*  593:1042 */     Preconditions.checkPositionIndexes(offset, end, array.length);
/*  594:1043 */     Preconditions.checkPositionIndex(index, length);
/*  595:1044 */     if (length == 0) {
/*  596:1045 */       return emptyListIterator();
/*  597:     */     }
/*  598:1053 */     new AbstractIndexedListIterator(length, index)
/*  599:     */     {
/*  600:     */       protected T get(int index)
/*  601:     */       {
/*  602:1055 */         return array[(offset + index)];
/*  603:     */       }
/*  604:     */     };
/*  605:     */   }
/*  606:     */   
/*  607:     */   public static <T> UnmodifiableIterator<T> singletonIterator(@Nullable T value)
/*  608:     */   {
/*  609:1068 */     new UnmodifiableIterator()
/*  610:     */     {
/*  611:     */       boolean done;
/*  612:     */       
/*  613:     */       public boolean hasNext()
/*  614:     */       {
/*  615:1072 */         return !this.done;
/*  616:     */       }
/*  617:     */       
/*  618:     */       public T next()
/*  619:     */       {
/*  620:1076 */         if (this.done) {
/*  621:1077 */           throw new NoSuchElementException();
/*  622:     */         }
/*  623:1079 */         this.done = true;
/*  624:1080 */         return this.val$value;
/*  625:     */       }
/*  626:     */     };
/*  627:     */   }
/*  628:     */   
/*  629:     */   public static <T> UnmodifiableIterator<T> forEnumeration(Enumeration<T> enumeration)
/*  630:     */   {
/*  631:1095 */     Preconditions.checkNotNull(enumeration);
/*  632:1096 */     new UnmodifiableIterator()
/*  633:     */     {
/*  634:     */       public boolean hasNext()
/*  635:     */       {
/*  636:1099 */         return this.val$enumeration.hasMoreElements();
/*  637:     */       }
/*  638:     */       
/*  639:     */       public T next()
/*  640:     */       {
/*  641:1103 */         return this.val$enumeration.nextElement();
/*  642:     */       }
/*  643:     */     };
/*  644:     */   }
/*  645:     */   
/*  646:     */   public static <T> Enumeration<T> asEnumeration(Iterator<T> iterator)
/*  647:     */   {
/*  648:1116 */     Preconditions.checkNotNull(iterator);
/*  649:1117 */     new Enumeration()
/*  650:     */     {
/*  651:     */       public boolean hasMoreElements()
/*  652:     */       {
/*  653:1120 */         return this.val$iterator.hasNext();
/*  654:     */       }
/*  655:     */       
/*  656:     */       public T nextElement()
/*  657:     */       {
/*  658:1124 */         return this.val$iterator.next();
/*  659:     */       }
/*  660:     */     };
/*  661:     */   }
/*  662:     */   
/*  663:     */   private static class PeekingImpl<E>
/*  664:     */     implements PeekingIterator<E>
/*  665:     */   {
/*  666:     */     private final Iterator<? extends E> iterator;
/*  667:     */     private boolean hasPeeked;
/*  668:     */     private E peekedElement;
/*  669:     */     
/*  670:     */     public PeekingImpl(Iterator<? extends E> iterator)
/*  671:     */     {
/*  672:1139 */       this.iterator = ((Iterator)Preconditions.checkNotNull(iterator));
/*  673:     */     }
/*  674:     */     
/*  675:     */     public boolean hasNext()
/*  676:     */     {
/*  677:1144 */       return (this.hasPeeked) || (this.iterator.hasNext());
/*  678:     */     }
/*  679:     */     
/*  680:     */     public E next()
/*  681:     */     {
/*  682:1149 */       if (!this.hasPeeked) {
/*  683:1150 */         return this.iterator.next();
/*  684:     */       }
/*  685:1152 */       E result = this.peekedElement;
/*  686:1153 */       this.hasPeeked = false;
/*  687:1154 */       this.peekedElement = null;
/*  688:1155 */       return result;
/*  689:     */     }
/*  690:     */     
/*  691:     */     public void remove()
/*  692:     */     {
/*  693:1160 */       Preconditions.checkState(!this.hasPeeked, "Can't remove after you've peeked at next");
/*  694:1161 */       this.iterator.remove();
/*  695:     */     }
/*  696:     */     
/*  697:     */     public E peek()
/*  698:     */     {
/*  699:1166 */       if (!this.hasPeeked)
/*  700:     */       {
/*  701:1167 */         this.peekedElement = this.iterator.next();
/*  702:1168 */         this.hasPeeked = true;
/*  703:     */       }
/*  704:1170 */       return this.peekedElement;
/*  705:     */     }
/*  706:     */   }
/*  707:     */   
/*  708:     */   public static <T> PeekingIterator<T> peekingIterator(Iterator<? extends T> iterator)
/*  709:     */   {
/*  710:1214 */     if ((iterator instanceof PeekingImpl))
/*  711:     */     {
/*  712:1218 */       PeekingImpl<T> peeking = (PeekingImpl)iterator;
/*  713:1219 */       return peeking;
/*  714:     */     }
/*  715:1221 */     return new PeekingImpl(iterator);
/*  716:     */   }
/*  717:     */   
/*  718:     */   @Deprecated
/*  719:     */   public static <T> PeekingIterator<T> peekingIterator(PeekingIterator<T> iterator)
/*  720:     */   {
/*  721:1232 */     return (PeekingIterator)Preconditions.checkNotNull(iterator);
/*  722:     */   }
/*  723:     */   
/*  724:     */   @Beta
/*  725:     */   public static <T> UnmodifiableIterator<T> mergeSorted(Iterable<? extends Iterator<? extends T>> iterators, Comparator<? super T> comparator)
/*  726:     */   {
/*  727:1252 */     Preconditions.checkNotNull(iterators, "iterators");
/*  728:1253 */     Preconditions.checkNotNull(comparator, "comparator");
/*  729:     */     
/*  730:1255 */     return new MergingIterator(iterators, comparator);
/*  731:     */   }
/*  732:     */   
/*  733:     */   private static class MergingIterator<T>
/*  734:     */     extends UnmodifiableIterator<T>
/*  735:     */   {
/*  736:     */     final Queue<PeekingIterator<T>> queue;
/*  737:     */     
/*  738:     */     public MergingIterator(Iterable<? extends Iterator<? extends T>> iterators, final Comparator<? super T> itemComparator)
/*  739:     */     {
/*  740:1274 */       Comparator<PeekingIterator<T>> heapComparator = new Comparator()
/*  741:     */       {
/*  742:     */         public int compare(PeekingIterator<T> o1, PeekingIterator<T> o2)
/*  743:     */         {
/*  744:1278 */           return itemComparator.compare(o1.peek(), o2.peek());
/*  745:     */         }
/*  746:1281 */       };
/*  747:1282 */       this.queue = new PriorityQueue(2, heapComparator);
/*  748:1284 */       for (Iterator<? extends T> iterator : iterators) {
/*  749:1285 */         if (iterator.hasNext()) {
/*  750:1286 */           this.queue.add(Iterators.peekingIterator(iterator));
/*  751:     */         }
/*  752:     */       }
/*  753:     */     }
/*  754:     */     
/*  755:     */     public boolean hasNext()
/*  756:     */     {
/*  757:1293 */       return !this.queue.isEmpty();
/*  758:     */     }
/*  759:     */     
/*  760:     */     public T next()
/*  761:     */     {
/*  762:1298 */       PeekingIterator<T> nextIter = (PeekingIterator)this.queue.remove();
/*  763:1299 */       T next = nextIter.next();
/*  764:1300 */       if (nextIter.hasNext()) {
/*  765:1301 */         this.queue.add(nextIter);
/*  766:     */       }
/*  767:1303 */       return next;
/*  768:     */     }
/*  769:     */   }
/*  770:     */   
/*  771:     */   static <T> ListIterator<T> cast(Iterator<T> iterator)
/*  772:     */   {
/*  773:1311 */     return (ListIterator)iterator;
/*  774:     */   }
/*  775:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Iterators
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.EnumMap;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.Map;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(emulated=true)
/*  15:    */ public final class EnumHashBiMap<K extends Enum<K>, V>
/*  16:    */   extends AbstractBiMap<K, V>
/*  17:    */ {
/*  18:    */   private transient Class<K> keyType;
/*  19:    */   @GwtIncompatible("only needed in emulated source.")
/*  20:    */   private static final long serialVersionUID = 0L;
/*  21:    */   
/*  22:    */   public static <K extends Enum<K>, V> EnumHashBiMap<K, V> create(Class<K> keyType)
/*  23:    */   {
/*  24: 58 */     return new EnumHashBiMap(keyType);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <K extends Enum<K>, V> EnumHashBiMap<K, V> create(Map<K, ? extends V> map)
/*  28:    */   {
/*  29: 73 */     EnumHashBiMap<K, V> bimap = create(EnumBiMap.inferKeyType(map));
/*  30: 74 */     bimap.putAll(map);
/*  31: 75 */     return bimap;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private EnumHashBiMap(Class<K> keyType)
/*  35:    */   {
/*  36: 79 */     super(WellBehavedMap.wrap(new EnumMap(keyType)), Maps.newHashMapWithExpectedSize(((Enum[])keyType.getEnumConstants()).length));
/*  37:    */     
/*  38:    */ 
/*  39:    */ 
/*  40: 83 */     this.keyType = keyType;
/*  41:    */   }
/*  42:    */   
/*  43:    */   K checkKey(K key)
/*  44:    */   {
/*  45: 90 */     return (Enum)Preconditions.checkNotNull(key);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public V put(K key, @Nullable V value)
/*  49:    */   {
/*  50: 94 */     return super.put(key, value);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public V forcePut(K key, @Nullable V value)
/*  54:    */   {
/*  55: 98 */     return super.forcePut(key, value);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Class<K> keyType()
/*  59:    */   {
/*  60:103 */     return this.keyType;
/*  61:    */   }
/*  62:    */   
/*  63:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  64:    */   private void writeObject(ObjectOutputStream stream)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67:112 */     stream.defaultWriteObject();
/*  68:113 */     stream.writeObject(this.keyType);
/*  69:114 */     Serialization.writeMap(this, stream);
/*  70:    */   }
/*  71:    */   
/*  72:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  73:    */   private void readObject(ObjectInputStream stream)
/*  74:    */     throws IOException, ClassNotFoundException
/*  75:    */   {
/*  76:121 */     stream.defaultReadObject();
/*  77:122 */     this.keyType = ((Class)stream.readObject());
/*  78:123 */     setDelegates(WellBehavedMap.wrap(new EnumMap(this.keyType)), new HashMap(((Enum[])this.keyType.getEnumConstants()).length * 3 / 2));
/*  79:    */     
/*  80:125 */     Serialization.populateMap(this, stream);
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.EnumHashBiMap
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.VisibleForTesting;
/*  5:   */ 
/*  6:   */ @GwtCompatible(serializable=true, emulated=true)
/*  7:   */ final class RegularImmutableSet<E>
/*  8:   */   extends ImmutableSet<E>
/*  9:   */ {
/* 10:   */   private final Object[] elements;
/* 11:   */   @VisibleForTesting
/* 12:   */   final transient Object[] table;
/* 13:   */   private final transient int mask;
/* 14:   */   private final transient int hashCode;
/* 15:   */   
/* 16:   */   RegularImmutableSet(Object[] elements, int hashCode, Object[] table, int mask)
/* 17:   */   {
/* 18:39 */     this.elements = elements;
/* 19:40 */     this.table = table;
/* 20:41 */     this.mask = mask;
/* 21:42 */     this.hashCode = hashCode;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean contains(Object target)
/* 25:   */   {
/* 26:46 */     if (target == null) {
/* 27:47 */       return false;
/* 28:   */     }
/* 29:49 */     for (int i = Hashing.smear(target.hashCode());; i++)
/* 30:   */     {
/* 31:50 */       Object candidate = this.table[(i & this.mask)];
/* 32:51 */       if (candidate == null) {
/* 33:52 */         return false;
/* 34:   */       }
/* 35:54 */       if (candidate.equals(target)) {
/* 36:55 */         return true;
/* 37:   */       }
/* 38:   */     }
/* 39:   */   }
/* 40:   */   
/* 41:   */   public int size()
/* 42:   */   {
/* 43:62 */     return this.elements.length;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public UnmodifiableIterator<E> iterator()
/* 47:   */   {
/* 48:68 */     return Iterators.forArray(this.elements);
/* 49:   */   }
/* 50:   */   
/* 51:   */   int copyIntoArray(Object[] dst, int offset)
/* 52:   */   {
/* 53:73 */     System.arraycopy(this.elements, 0, dst, offset, this.elements.length);
/* 54:74 */     return offset + this.elements.length;
/* 55:   */   }
/* 56:   */   
/* 57:   */   ImmutableList<E> createAsList()
/* 58:   */   {
/* 59:79 */     return new RegularImmutableAsList(this, this.elements);
/* 60:   */   }
/* 61:   */   
/* 62:   */   boolean isPartialView()
/* 63:   */   {
/* 64:84 */     return false;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int hashCode()
/* 68:   */   {
/* 69:88 */     return this.hashCode;
/* 70:   */   }
/* 71:   */   
/* 72:   */   boolean isHashCodeFast()
/* 73:   */   {
/* 74:92 */     return true;
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSet
 * JD-Core Version:    0.7.0.1
 */
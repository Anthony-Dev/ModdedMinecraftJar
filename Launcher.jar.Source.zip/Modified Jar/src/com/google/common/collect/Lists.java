/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.annotations.VisibleForTesting;
/*    7:     */ import com.google.common.base.Function;
/*    8:     */ import com.google.common.base.Objects;
/*    9:     */ import com.google.common.base.Preconditions;
/*   10:     */ import com.google.common.math.IntMath;
/*   11:     */ import com.google.common.primitives.Ints;
/*   12:     */ import java.io.Serializable;
/*   13:     */ import java.math.RoundingMode;
/*   14:     */ import java.util.AbstractList;
/*   15:     */ import java.util.AbstractSequentialList;
/*   16:     */ import java.util.ArrayList;
/*   17:     */ import java.util.Arrays;
/*   18:     */ import java.util.Collection;
/*   19:     */ import java.util.Collections;
/*   20:     */ import java.util.Iterator;
/*   21:     */ import java.util.LinkedList;
/*   22:     */ import java.util.List;
/*   23:     */ import java.util.ListIterator;
/*   24:     */ import java.util.NoSuchElementException;
/*   25:     */ import java.util.RandomAccess;
/*   26:     */ import java.util.concurrent.CopyOnWriteArrayList;
/*   27:     */ import javax.annotation.Nullable;
/*   28:     */ 
/*   29:     */ @GwtCompatible(emulated=true)
/*   30:     */ public final class Lists
/*   31:     */ {
/*   32:     */   @GwtCompatible(serializable=true)
/*   33:     */   public static <E> ArrayList<E> newArrayList()
/*   34:     */   {
/*   35:  84 */     return new ArrayList();
/*   36:     */   }
/*   37:     */   
/*   38:     */   @GwtCompatible(serializable=true)
/*   39:     */   public static <E> ArrayList<E> newArrayList(E... elements)
/*   40:     */   {
/*   41: 100 */     Preconditions.checkNotNull(elements);
/*   42:     */     
/*   43: 102 */     int capacity = computeArrayListCapacity(elements.length);
/*   44: 103 */     ArrayList<E> list = new ArrayList(capacity);
/*   45: 104 */     Collections.addAll(list, elements);
/*   46: 105 */     return list;
/*   47:     */   }
/*   48:     */   
/*   49:     */   @VisibleForTesting
/*   50:     */   static int computeArrayListCapacity(int arraySize)
/*   51:     */   {
/*   52: 109 */     CollectPreconditions.checkNonnegative(arraySize, "arraySize");
/*   53:     */     
/*   54:     */ 
/*   55: 112 */     return Ints.saturatedCast(5L + arraySize + arraySize / 10);
/*   56:     */   }
/*   57:     */   
/*   58:     */   @GwtCompatible(serializable=true)
/*   59:     */   public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements)
/*   60:     */   {
/*   61: 127 */     Preconditions.checkNotNull(elements);
/*   62:     */     
/*   63: 129 */     return (elements instanceof Collection) ? new ArrayList(Collections2.cast(elements)) : newArrayList(elements.iterator());
/*   64:     */   }
/*   65:     */   
/*   66:     */   @GwtCompatible(serializable=true)
/*   67:     */   public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements)
/*   68:     */   {
/*   69: 146 */     ArrayList<E> list = newArrayList();
/*   70: 147 */     Iterators.addAll(list, elements);
/*   71: 148 */     return list;
/*   72:     */   }
/*   73:     */   
/*   74:     */   @GwtCompatible(serializable=true)
/*   75:     */   public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize)
/*   76:     */   {
/*   77: 174 */     CollectPreconditions.checkNonnegative(initialArraySize, "initialArraySize");
/*   78: 175 */     return new ArrayList(initialArraySize);
/*   79:     */   }
/*   80:     */   
/*   81:     */   @GwtCompatible(serializable=true)
/*   82:     */   public static <E> ArrayList<E> newArrayListWithExpectedSize(int estimatedSize)
/*   83:     */   {
/*   84: 196 */     return new ArrayList(computeArrayListCapacity(estimatedSize));
/*   85:     */   }
/*   86:     */   
/*   87:     */   @GwtCompatible(serializable=true)
/*   88:     */   public static <E> LinkedList<E> newLinkedList()
/*   89:     */   {
/*   90: 211 */     return new LinkedList();
/*   91:     */   }
/*   92:     */   
/*   93:     */   @GwtCompatible(serializable=true)
/*   94:     */   public static <E> LinkedList<E> newLinkedList(Iterable<? extends E> elements)
/*   95:     */   {
/*   96: 223 */     LinkedList<E> list = newLinkedList();
/*   97: 224 */     Iterables.addAll(list, elements);
/*   98: 225 */     return list;
/*   99:     */   }
/*  100:     */   
/*  101:     */   @GwtIncompatible("CopyOnWriteArrayList")
/*  102:     */   public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList()
/*  103:     */   {
/*  104: 239 */     return new CopyOnWriteArrayList();
/*  105:     */   }
/*  106:     */   
/*  107:     */   @GwtIncompatible("CopyOnWriteArrayList")
/*  108:     */   public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList(Iterable<? extends E> elements)
/*  109:     */   {
/*  110: 254 */     Collection<? extends E> elementsCollection = (elements instanceof Collection) ? Collections2.cast(elements) : newArrayList(elements);
/*  111:     */     
/*  112:     */ 
/*  113: 257 */     return new CopyOnWriteArrayList(elementsCollection);
/*  114:     */   }
/*  115:     */   
/*  116:     */   public static <E> List<E> asList(@Nullable E first, E[] rest)
/*  117:     */   {
/*  118: 277 */     return new OnePlusArrayList(first, rest);
/*  119:     */   }
/*  120:     */   
/*  121:     */   private static class OnePlusArrayList<E>
/*  122:     */     extends AbstractList<E>
/*  123:     */     implements Serializable, RandomAccess
/*  124:     */   {
/*  125:     */     final E first;
/*  126:     */     final E[] rest;
/*  127:     */     private static final long serialVersionUID = 0L;
/*  128:     */     
/*  129:     */     OnePlusArrayList(@Nullable E first, E[] rest)
/*  130:     */     {
/*  131: 287 */       this.first = first;
/*  132: 288 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*  133:     */     }
/*  134:     */     
/*  135:     */     public int size()
/*  136:     */     {
/*  137: 291 */       return this.rest.length + 1;
/*  138:     */     }
/*  139:     */     
/*  140:     */     public E get(int index)
/*  141:     */     {
/*  142: 295 */       Preconditions.checkElementIndex(index, size());
/*  143: 296 */       return index == 0 ? this.first : this.rest[(index - 1)];
/*  144:     */     }
/*  145:     */   }
/*  146:     */   
/*  147:     */   public static <E> List<E> asList(@Nullable E first, @Nullable E second, E[] rest)
/*  148:     */   {
/*  149: 320 */     return new TwoPlusArrayList(first, second, rest);
/*  150:     */   }
/*  151:     */   
/*  152:     */   private static class TwoPlusArrayList<E>
/*  153:     */     extends AbstractList<E>
/*  154:     */     implements Serializable, RandomAccess
/*  155:     */   {
/*  156:     */     final E first;
/*  157:     */     final E second;
/*  158:     */     final E[] rest;
/*  159:     */     private static final long serialVersionUID = 0L;
/*  160:     */     
/*  161:     */     TwoPlusArrayList(@Nullable E first, @Nullable E second, E[] rest)
/*  162:     */     {
/*  163: 331 */       this.first = first;
/*  164: 332 */       this.second = second;
/*  165: 333 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*  166:     */     }
/*  167:     */     
/*  168:     */     public int size()
/*  169:     */     {
/*  170: 336 */       return this.rest.length + 2;
/*  171:     */     }
/*  172:     */     
/*  173:     */     public E get(int index)
/*  174:     */     {
/*  175: 339 */       switch (index)
/*  176:     */       {
/*  177:     */       case 0: 
/*  178: 341 */         return this.first;
/*  179:     */       case 1: 
/*  180: 343 */         return this.second;
/*  181:     */       }
/*  182: 346 */       Preconditions.checkElementIndex(index, size());
/*  183: 347 */       return this.rest[(index - 2)];
/*  184:     */     }
/*  185:     */   }
/*  186:     */   
/*  187:     */   static <B> List<List<B>> cartesianProduct(List<? extends List<? extends B>> lists)
/*  188:     */   {
/*  189: 410 */     return CartesianList.create(lists);
/*  190:     */   }
/*  191:     */   
/*  192:     */   static <B> List<List<B>> cartesianProduct(List<? extends B>... lists)
/*  193:     */   {
/*  194: 470 */     return cartesianProduct(Arrays.asList(lists));
/*  195:     */   }
/*  196:     */   
/*  197:     */   public static <F, T> List<T> transform(List<F> fromList, Function<? super F, ? extends T> function)
/*  198:     */   {
/*  199: 508 */     return (fromList instanceof RandomAccess) ? new TransformingRandomAccessList(fromList, function) : new TransformingSequentialList(fromList, function);
/*  200:     */   }
/*  201:     */   
/*  202:     */   private static class TransformingSequentialList<F, T>
/*  203:     */     extends AbstractSequentialList<T>
/*  204:     */     implements Serializable
/*  205:     */   {
/*  206:     */     final List<F> fromList;
/*  207:     */     final Function<? super F, ? extends T> function;
/*  208:     */     private static final long serialVersionUID = 0L;
/*  209:     */     
/*  210:     */     TransformingSequentialList(List<F> fromList, Function<? super F, ? extends T> function)
/*  211:     */     {
/*  212: 525 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/*  213: 526 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  214:     */     }
/*  215:     */     
/*  216:     */     public void clear()
/*  217:     */     {
/*  218: 534 */       this.fromList.clear();
/*  219:     */     }
/*  220:     */     
/*  221:     */     public int size()
/*  222:     */     {
/*  223: 537 */       return this.fromList.size();
/*  224:     */     }
/*  225:     */     
/*  226:     */     public ListIterator<T> listIterator(int index)
/*  227:     */     {
/*  228: 540 */       new TransformedListIterator(this.fromList.listIterator(index))
/*  229:     */       {
/*  230:     */         T transform(F from)
/*  231:     */         {
/*  232: 543 */           return Lists.TransformingSequentialList.this.function.apply(from);
/*  233:     */         }
/*  234:     */       };
/*  235:     */     }
/*  236:     */   }
/*  237:     */   
/*  238:     */   private static class TransformingRandomAccessList<F, T>
/*  239:     */     extends AbstractList<T>
/*  240:     */     implements RandomAccess, Serializable
/*  241:     */   {
/*  242:     */     final List<F> fromList;
/*  243:     */     final Function<? super F, ? extends T> function;
/*  244:     */     private static final long serialVersionUID = 0L;
/*  245:     */     
/*  246:     */     TransformingRandomAccessList(List<F> fromList, Function<? super F, ? extends T> function)
/*  247:     */     {
/*  248: 566 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/*  249: 567 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  250:     */     }
/*  251:     */     
/*  252:     */     public void clear()
/*  253:     */     {
/*  254: 570 */       this.fromList.clear();
/*  255:     */     }
/*  256:     */     
/*  257:     */     public T get(int index)
/*  258:     */     {
/*  259: 573 */       return this.function.apply(this.fromList.get(index));
/*  260:     */     }
/*  261:     */     
/*  262:     */     public Iterator<T> iterator()
/*  263:     */     {
/*  264: 576 */       return listIterator();
/*  265:     */     }
/*  266:     */     
/*  267:     */     public ListIterator<T> listIterator(int index)
/*  268:     */     {
/*  269: 579 */       new TransformedListIterator(this.fromList.listIterator(index))
/*  270:     */       {
/*  271:     */         T transform(F from)
/*  272:     */         {
/*  273: 582 */           return Lists.TransformingRandomAccessList.this.function.apply(from);
/*  274:     */         }
/*  275:     */       };
/*  276:     */     }
/*  277:     */     
/*  278:     */     public boolean isEmpty()
/*  279:     */     {
/*  280: 587 */       return this.fromList.isEmpty();
/*  281:     */     }
/*  282:     */     
/*  283:     */     public T remove(int index)
/*  284:     */     {
/*  285: 590 */       return this.function.apply(this.fromList.remove(index));
/*  286:     */     }
/*  287:     */     
/*  288:     */     public int size()
/*  289:     */     {
/*  290: 593 */       return this.fromList.size();
/*  291:     */     }
/*  292:     */   }
/*  293:     */   
/*  294:     */   public static <T> List<List<T>> partition(List<T> list, int size)
/*  295:     */   {
/*  296: 617 */     Preconditions.checkNotNull(list);
/*  297: 618 */     Preconditions.checkArgument(size > 0);
/*  298: 619 */     return (list instanceof RandomAccess) ? new RandomAccessPartition(list, size) : new Partition(list, size);
/*  299:     */   }
/*  300:     */   
/*  301:     */   private static class Partition<T>
/*  302:     */     extends AbstractList<List<T>>
/*  303:     */   {
/*  304:     */     final List<T> list;
/*  305:     */     final int size;
/*  306:     */     
/*  307:     */     Partition(List<T> list, int size)
/*  308:     */     {
/*  309: 629 */       this.list = list;
/*  310: 630 */       this.size = size;
/*  311:     */     }
/*  312:     */     
/*  313:     */     public List<T> get(int index)
/*  314:     */     {
/*  315: 634 */       Preconditions.checkElementIndex(index, size());
/*  316: 635 */       int start = index * this.size;
/*  317: 636 */       int end = Math.min(start + this.size, this.list.size());
/*  318: 637 */       return this.list.subList(start, end);
/*  319:     */     }
/*  320:     */     
/*  321:     */     public int size()
/*  322:     */     {
/*  323: 641 */       return IntMath.divide(this.list.size(), this.size, RoundingMode.CEILING);
/*  324:     */     }
/*  325:     */     
/*  326:     */     public boolean isEmpty()
/*  327:     */     {
/*  328: 645 */       return this.list.isEmpty();
/*  329:     */     }
/*  330:     */   }
/*  331:     */   
/*  332:     */   private static class RandomAccessPartition<T>
/*  333:     */     extends Lists.Partition<T>
/*  334:     */     implements RandomAccess
/*  335:     */   {
/*  336:     */     RandomAccessPartition(List<T> list, int size)
/*  337:     */     {
/*  338: 652 */       super(size);
/*  339:     */     }
/*  340:     */   }
/*  341:     */   
/*  342:     */   @Beta
/*  343:     */   public static ImmutableList<Character> charactersOf(String string)
/*  344:     */   {
/*  345: 663 */     return new StringAsImmutableList((String)Preconditions.checkNotNull(string));
/*  346:     */   }
/*  347:     */   
/*  348:     */   private static final class StringAsImmutableList
/*  349:     */     extends ImmutableList<Character>
/*  350:     */   {
/*  351:     */     private final String string;
/*  352:     */     
/*  353:     */     StringAsImmutableList(String string)
/*  354:     */     {
/*  355: 673 */       this.string = string;
/*  356:     */     }
/*  357:     */     
/*  358:     */     public int indexOf(@Nullable Object object)
/*  359:     */     {
/*  360: 677 */       return (object instanceof Character) ? this.string.indexOf(((Character)object).charValue()) : -1;
/*  361:     */     }
/*  362:     */     
/*  363:     */     public int lastIndexOf(@Nullable Object object)
/*  364:     */     {
/*  365: 682 */       return (object instanceof Character) ? this.string.lastIndexOf(((Character)object).charValue()) : -1;
/*  366:     */     }
/*  367:     */     
/*  368:     */     public ImmutableList<Character> subList(int fromIndex, int toIndex)
/*  369:     */     {
/*  370: 688 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/*  371: 689 */       return Lists.charactersOf(this.string.substring(fromIndex, toIndex));
/*  372:     */     }
/*  373:     */     
/*  374:     */     boolean isPartialView()
/*  375:     */     {
/*  376: 693 */       return false;
/*  377:     */     }
/*  378:     */     
/*  379:     */     public Character get(int index)
/*  380:     */     {
/*  381: 697 */       Preconditions.checkElementIndex(index, size());
/*  382: 698 */       return Character.valueOf(this.string.charAt(index));
/*  383:     */     }
/*  384:     */     
/*  385:     */     public int size()
/*  386:     */     {
/*  387: 702 */       return this.string.length();
/*  388:     */     }
/*  389:     */   }
/*  390:     */   
/*  391:     */   @Beta
/*  392:     */   public static List<Character> charactersOf(CharSequence sequence)
/*  393:     */   {
/*  394: 718 */     return new CharSequenceAsList((CharSequence)Preconditions.checkNotNull(sequence));
/*  395:     */   }
/*  396:     */   
/*  397:     */   private static final class CharSequenceAsList
/*  398:     */     extends AbstractList<Character>
/*  399:     */   {
/*  400:     */     private final CharSequence sequence;
/*  401:     */     
/*  402:     */     CharSequenceAsList(CharSequence sequence)
/*  403:     */     {
/*  404: 726 */       this.sequence = sequence;
/*  405:     */     }
/*  406:     */     
/*  407:     */     public Character get(int index)
/*  408:     */     {
/*  409: 730 */       Preconditions.checkElementIndex(index, size());
/*  410: 731 */       return Character.valueOf(this.sequence.charAt(index));
/*  411:     */     }
/*  412:     */     
/*  413:     */     public int size()
/*  414:     */     {
/*  415: 735 */       return this.sequence.length();
/*  416:     */     }
/*  417:     */   }
/*  418:     */   
/*  419:     */   public static <T> List<T> reverse(List<T> list)
/*  420:     */   {
/*  421: 752 */     if ((list instanceof ImmutableList)) {
/*  422: 753 */       return ((ImmutableList)list).reverse();
/*  423:     */     }
/*  424: 754 */     if ((list instanceof ReverseList)) {
/*  425: 755 */       return ((ReverseList)list).getForwardList();
/*  426:     */     }
/*  427: 756 */     if ((list instanceof RandomAccess)) {
/*  428: 757 */       return new RandomAccessReverseList(list);
/*  429:     */     }
/*  430: 759 */     return new ReverseList(list);
/*  431:     */   }
/*  432:     */   
/*  433:     */   private static class ReverseList<T>
/*  434:     */     extends AbstractList<T>
/*  435:     */   {
/*  436:     */     private final List<T> forwardList;
/*  437:     */     
/*  438:     */     ReverseList(List<T> forwardList)
/*  439:     */     {
/*  440: 767 */       this.forwardList = ((List)Preconditions.checkNotNull(forwardList));
/*  441:     */     }
/*  442:     */     
/*  443:     */     List<T> getForwardList()
/*  444:     */     {
/*  445: 771 */       return this.forwardList;
/*  446:     */     }
/*  447:     */     
/*  448:     */     private int reverseIndex(int index)
/*  449:     */     {
/*  450: 775 */       int size = size();
/*  451: 776 */       Preconditions.checkElementIndex(index, size);
/*  452: 777 */       return size - 1 - index;
/*  453:     */     }
/*  454:     */     
/*  455:     */     private int reversePosition(int index)
/*  456:     */     {
/*  457: 781 */       int size = size();
/*  458: 782 */       Preconditions.checkPositionIndex(index, size);
/*  459: 783 */       return size - index;
/*  460:     */     }
/*  461:     */     
/*  462:     */     public void add(int index, @Nullable T element)
/*  463:     */     {
/*  464: 787 */       this.forwardList.add(reversePosition(index), element);
/*  465:     */     }
/*  466:     */     
/*  467:     */     public void clear()
/*  468:     */     {
/*  469: 791 */       this.forwardList.clear();
/*  470:     */     }
/*  471:     */     
/*  472:     */     public T remove(int index)
/*  473:     */     {
/*  474: 795 */       return this.forwardList.remove(reverseIndex(index));
/*  475:     */     }
/*  476:     */     
/*  477:     */     protected void removeRange(int fromIndex, int toIndex)
/*  478:     */     {
/*  479: 799 */       subList(fromIndex, toIndex).clear();
/*  480:     */     }
/*  481:     */     
/*  482:     */     public T set(int index, @Nullable T element)
/*  483:     */     {
/*  484: 803 */       return this.forwardList.set(reverseIndex(index), element);
/*  485:     */     }
/*  486:     */     
/*  487:     */     public T get(int index)
/*  488:     */     {
/*  489: 807 */       return this.forwardList.get(reverseIndex(index));
/*  490:     */     }
/*  491:     */     
/*  492:     */     public int size()
/*  493:     */     {
/*  494: 811 */       return this.forwardList.size();
/*  495:     */     }
/*  496:     */     
/*  497:     */     public List<T> subList(int fromIndex, int toIndex)
/*  498:     */     {
/*  499: 815 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/*  500: 816 */       return Lists.reverse(this.forwardList.subList(reversePosition(toIndex), reversePosition(fromIndex)));
/*  501:     */     }
/*  502:     */     
/*  503:     */     public Iterator<T> iterator()
/*  504:     */     {
/*  505: 821 */       return listIterator();
/*  506:     */     }
/*  507:     */     
/*  508:     */     public ListIterator<T> listIterator(int index)
/*  509:     */     {
/*  510: 825 */       int start = reversePosition(index);
/*  511: 826 */       final ListIterator<T> forwardIterator = this.forwardList.listIterator(start);
/*  512: 827 */       new ListIterator()
/*  513:     */       {
/*  514:     */         boolean canRemoveOrSet;
/*  515:     */         
/*  516:     */         public void add(T e)
/*  517:     */         {
/*  518: 832 */           forwardIterator.add(e);
/*  519: 833 */           forwardIterator.previous();
/*  520: 834 */           this.canRemoveOrSet = false;
/*  521:     */         }
/*  522:     */         
/*  523:     */         public boolean hasNext()
/*  524:     */         {
/*  525: 838 */           return forwardIterator.hasPrevious();
/*  526:     */         }
/*  527:     */         
/*  528:     */         public boolean hasPrevious()
/*  529:     */         {
/*  530: 842 */           return forwardIterator.hasNext();
/*  531:     */         }
/*  532:     */         
/*  533:     */         public T next()
/*  534:     */         {
/*  535: 846 */           if (!hasNext()) {
/*  536: 847 */             throw new NoSuchElementException();
/*  537:     */           }
/*  538: 849 */           this.canRemoveOrSet = true;
/*  539: 850 */           return forwardIterator.previous();
/*  540:     */         }
/*  541:     */         
/*  542:     */         public int nextIndex()
/*  543:     */         {
/*  544: 854 */           return Lists.ReverseList.this.reversePosition(forwardIterator.nextIndex());
/*  545:     */         }
/*  546:     */         
/*  547:     */         public T previous()
/*  548:     */         {
/*  549: 858 */           if (!hasPrevious()) {
/*  550: 859 */             throw new NoSuchElementException();
/*  551:     */           }
/*  552: 861 */           this.canRemoveOrSet = true;
/*  553: 862 */           return forwardIterator.next();
/*  554:     */         }
/*  555:     */         
/*  556:     */         public int previousIndex()
/*  557:     */         {
/*  558: 866 */           return nextIndex() - 1;
/*  559:     */         }
/*  560:     */         
/*  561:     */         public void remove()
/*  562:     */         {
/*  563: 870 */           CollectPreconditions.checkRemove(this.canRemoveOrSet);
/*  564: 871 */           forwardIterator.remove();
/*  565: 872 */           this.canRemoveOrSet = false;
/*  566:     */         }
/*  567:     */         
/*  568:     */         public void set(T e)
/*  569:     */         {
/*  570: 876 */           Preconditions.checkState(this.canRemoveOrSet);
/*  571: 877 */           forwardIterator.set(e);
/*  572:     */         }
/*  573:     */       };
/*  574:     */     }
/*  575:     */   }
/*  576:     */   
/*  577:     */   private static class RandomAccessReverseList<T>
/*  578:     */     extends Lists.ReverseList<T>
/*  579:     */     implements RandomAccess
/*  580:     */   {
/*  581:     */     RandomAccessReverseList(List<T> forwardList)
/*  582:     */     {
/*  583: 886 */       super();
/*  584:     */     }
/*  585:     */   }
/*  586:     */   
/*  587:     */   static int hashCodeImpl(List<?> list)
/*  588:     */   {
/*  589: 895 */     int hashCode = 1;
/*  590: 896 */     for (Object o : list)
/*  591:     */     {
/*  592: 897 */       hashCode = 31 * hashCode + (o == null ? 0 : o.hashCode());
/*  593:     */       
/*  594: 899 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  595:     */     }
/*  596: 902 */     return hashCode;
/*  597:     */   }
/*  598:     */   
/*  599:     */   static boolean equalsImpl(List<?> list, @Nullable Object object)
/*  600:     */   {
/*  601: 909 */     if (object == Preconditions.checkNotNull(list)) {
/*  602: 910 */       return true;
/*  603:     */     }
/*  604: 912 */     if (!(object instanceof List)) {
/*  605: 913 */       return false;
/*  606:     */     }
/*  607: 916 */     List<?> o = (List)object;
/*  608:     */     
/*  609: 918 */     return (list.size() == o.size()) && (Iterators.elementsEqual(list.iterator(), o.iterator()));
/*  610:     */   }
/*  611:     */   
/*  612:     */   static <E> boolean addAllImpl(List<E> list, int index, Iterable<? extends E> elements)
/*  613:     */   {
/*  614: 927 */     boolean changed = false;
/*  615: 928 */     ListIterator<E> listIterator = list.listIterator(index);
/*  616: 929 */     for (E e : elements)
/*  617:     */     {
/*  618: 930 */       listIterator.add(e);
/*  619: 931 */       changed = true;
/*  620:     */     }
/*  621: 933 */     return changed;
/*  622:     */   }
/*  623:     */   
/*  624:     */   static int indexOfImpl(List<?> list, @Nullable Object element)
/*  625:     */   {
/*  626: 940 */     ListIterator<?> listIterator = list.listIterator();
/*  627: 941 */     while (listIterator.hasNext()) {
/*  628: 942 */       if (Objects.equal(element, listIterator.next())) {
/*  629: 943 */         return listIterator.previousIndex();
/*  630:     */       }
/*  631:     */     }
/*  632: 946 */     return -1;
/*  633:     */   }
/*  634:     */   
/*  635:     */   static int lastIndexOfImpl(List<?> list, @Nullable Object element)
/*  636:     */   {
/*  637: 953 */     ListIterator<?> listIterator = list.listIterator(list.size());
/*  638: 954 */     while (listIterator.hasPrevious()) {
/*  639: 955 */       if (Objects.equal(element, listIterator.previous())) {
/*  640: 956 */         return listIterator.nextIndex();
/*  641:     */       }
/*  642:     */     }
/*  643: 959 */     return -1;
/*  644:     */   }
/*  645:     */   
/*  646:     */   static <E> ListIterator<E> listIteratorImpl(List<E> list, int index)
/*  647:     */   {
/*  648: 966 */     return new AbstractListWrapper(list).listIterator(index);
/*  649:     */   }
/*  650:     */   
/*  651:     */   static <E> List<E> subListImpl(List<E> list, int fromIndex, int toIndex)
/*  652:     */   {
/*  653:     */     List<E> wrapper;
/*  654:     */     List<E> wrapper;
/*  655: 975 */     if ((list instanceof RandomAccess)) {
/*  656: 976 */       wrapper = new RandomAccessListWrapper(list)
/*  657:     */       {
/*  658:     */         private static final long serialVersionUID = 0L;
/*  659:     */         
/*  660:     */         public ListIterator<E> listIterator(int index)
/*  661:     */         {
/*  662: 978 */           return this.backingList.listIterator(index);
/*  663:     */         }
/*  664:     */       };
/*  665:     */     } else {
/*  666: 984 */       wrapper = new AbstractListWrapper(list)
/*  667:     */       {
/*  668:     */         private static final long serialVersionUID = 0L;
/*  669:     */         
/*  670:     */         public ListIterator<E> listIterator(int index)
/*  671:     */         {
/*  672: 986 */           return this.backingList.listIterator(index);
/*  673:     */         }
/*  674:     */       };
/*  675:     */     }
/*  676: 992 */     return wrapper.subList(fromIndex, toIndex);
/*  677:     */   }
/*  678:     */   
/*  679:     */   private static class AbstractListWrapper<E>
/*  680:     */     extends AbstractList<E>
/*  681:     */   {
/*  682:     */     final List<E> backingList;
/*  683:     */     
/*  684:     */     AbstractListWrapper(List<E> backingList)
/*  685:     */     {
/*  686: 999 */       this.backingList = ((List)Preconditions.checkNotNull(backingList));
/*  687:     */     }
/*  688:     */     
/*  689:     */     public void add(int index, E element)
/*  690:     */     {
/*  691:1003 */       this.backingList.add(index, element);
/*  692:     */     }
/*  693:     */     
/*  694:     */     public boolean addAll(int index, Collection<? extends E> c)
/*  695:     */     {
/*  696:1007 */       return this.backingList.addAll(index, c);
/*  697:     */     }
/*  698:     */     
/*  699:     */     public E get(int index)
/*  700:     */     {
/*  701:1011 */       return this.backingList.get(index);
/*  702:     */     }
/*  703:     */     
/*  704:     */     public E remove(int index)
/*  705:     */     {
/*  706:1015 */       return this.backingList.remove(index);
/*  707:     */     }
/*  708:     */     
/*  709:     */     public E set(int index, E element)
/*  710:     */     {
/*  711:1019 */       return this.backingList.set(index, element);
/*  712:     */     }
/*  713:     */     
/*  714:     */     public boolean contains(Object o)
/*  715:     */     {
/*  716:1023 */       return this.backingList.contains(o);
/*  717:     */     }
/*  718:     */     
/*  719:     */     public int size()
/*  720:     */     {
/*  721:1027 */       return this.backingList.size();
/*  722:     */     }
/*  723:     */   }
/*  724:     */   
/*  725:     */   private static class RandomAccessListWrapper<E>
/*  726:     */     extends Lists.AbstractListWrapper<E>
/*  727:     */     implements RandomAccess
/*  728:     */   {
/*  729:     */     RandomAccessListWrapper(List<E> backingList)
/*  730:     */     {
/*  731:1034 */       super();
/*  732:     */     }
/*  733:     */   }
/*  734:     */   
/*  735:     */   static <T> List<T> cast(Iterable<T> iterable)
/*  736:     */   {
/*  737:1042 */     return (List)iterable;
/*  738:     */   }
/*  739:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Lists
 * JD-Core Version:    0.7.0.1
 */
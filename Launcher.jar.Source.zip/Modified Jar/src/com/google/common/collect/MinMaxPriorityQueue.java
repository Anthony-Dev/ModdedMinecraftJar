/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.math.IntMath;
/*   7:    */ import java.util.AbstractQueue;
/*   8:    */ import java.util.ArrayDeque;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.ConcurrentModificationException;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.NoSuchElementException;
/*  17:    */ import java.util.Queue;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ public final class MinMaxPriorityQueue<E>
/*  21:    */   extends AbstractQueue<E>
/*  22:    */ {
/*  23:    */   private final MinMaxPriorityQueue<E>.Heap minHeap;
/*  24:    */   private final MinMaxPriorityQueue<E>.Heap maxHeap;
/*  25:    */   @VisibleForTesting
/*  26:    */   final int maximumSize;
/*  27:    */   private Object[] queue;
/*  28:    */   private int size;
/*  29:    */   private int modCount;
/*  30:    */   private static final int EVEN_POWERS_OF_TWO = 1431655765;
/*  31:    */   private static final int ODD_POWERS_OF_TWO = -1431655766;
/*  32:    */   private static final int DEFAULT_CAPACITY = 11;
/*  33:    */   
/*  34:    */   public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create()
/*  35:    */   {
/*  36: 98 */     return new Builder(Ordering.natural(), null).create();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create(Iterable<? extends E> initialContents)
/*  40:    */   {
/*  41:107 */     return new Builder(Ordering.natural(), null).create(initialContents);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <B> Builder<B> orderedBy(Comparator<B> comparator)
/*  45:    */   {
/*  46:116 */     return new Builder(comparator, null);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static Builder<Comparable> expectedSize(int expectedSize)
/*  50:    */   {
/*  51:125 */     return new Builder(Ordering.natural(), null).expectedSize(expectedSize);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static Builder<Comparable> maximumSize(int maximumSize)
/*  55:    */   {
/*  56:137 */     return new Builder(Ordering.natural(), null).maximumSize(maximumSize);
/*  57:    */   }
/*  58:    */   
/*  59:    */   @Beta
/*  60:    */   public static final class Builder<B>
/*  61:    */   {
/*  62:    */     private static final int UNSET_EXPECTED_SIZE = -1;
/*  63:    */     private final Comparator<B> comparator;
/*  64:163 */     private int expectedSize = -1;
/*  65:164 */     private int maximumSize = 2147483647;
/*  66:    */     
/*  67:    */     private Builder(Comparator<B> comparator)
/*  68:    */     {
/*  69:167 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*  70:    */     }
/*  71:    */     
/*  72:    */     public Builder<B> expectedSize(int expectedSize)
/*  73:    */     {
/*  74:175 */       Preconditions.checkArgument(expectedSize >= 0);
/*  75:176 */       this.expectedSize = expectedSize;
/*  76:177 */       return this;
/*  77:    */     }
/*  78:    */     
/*  79:    */     public Builder<B> maximumSize(int maximumSize)
/*  80:    */     {
/*  81:187 */       Preconditions.checkArgument(maximumSize > 0);
/*  82:188 */       this.maximumSize = maximumSize;
/*  83:189 */       return this;
/*  84:    */     }
/*  85:    */     
/*  86:    */     public <T extends B> MinMaxPriorityQueue<T> create()
/*  87:    */     {
/*  88:197 */       return create(Collections.emptySet());
/*  89:    */     }
/*  90:    */     
/*  91:    */     public <T extends B> MinMaxPriorityQueue<T> create(Iterable<? extends T> initialContents)
/*  92:    */     {
/*  93:206 */       MinMaxPriorityQueue<T> queue = new MinMaxPriorityQueue(this, MinMaxPriorityQueue.initialQueueSize(this.expectedSize, this.maximumSize, initialContents), null);
/*  94:208 */       for (T element : initialContents) {
/*  95:209 */         queue.offer(element);
/*  96:    */       }
/*  97:211 */       return queue;
/*  98:    */     }
/*  99:    */     
/* 100:    */     private <T extends B> Ordering<T> ordering()
/* 101:    */     {
/* 102:216 */       return Ordering.from(this.comparator);
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   private MinMaxPriorityQueue(Builder<? super E> builder, int queueSize)
/* 107:    */   {
/* 108:228 */     Ordering<E> ordering = builder.ordering();
/* 109:229 */     this.minHeap = new Heap(ordering);
/* 110:230 */     this.maxHeap = new Heap(ordering.reverse());
/* 111:231 */     this.minHeap.otherHeap = this.maxHeap;
/* 112:232 */     this.maxHeap.otherHeap = this.minHeap;
/* 113:    */     
/* 114:234 */     this.maximumSize = builder.maximumSize;
/* 115:    */     
/* 116:236 */     this.queue = new Object[queueSize];
/* 117:    */   }
/* 118:    */   
/* 119:    */   public int size()
/* 120:    */   {
/* 121:240 */     return this.size;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean add(E element)
/* 125:    */   {
/* 126:252 */     offer(element);
/* 127:253 */     return true;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public boolean addAll(Collection<? extends E> newElements)
/* 131:    */   {
/* 132:257 */     boolean modified = false;
/* 133:258 */     for (E element : newElements)
/* 134:    */     {
/* 135:259 */       offer(element);
/* 136:260 */       modified = true;
/* 137:    */     }
/* 138:262 */     return modified;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean offer(E element)
/* 142:    */   {
/* 143:272 */     Preconditions.checkNotNull(element);
/* 144:273 */     this.modCount += 1;
/* 145:274 */     int insertIndex = this.size++;
/* 146:    */     
/* 147:276 */     growIfNeeded();
/* 148:    */     
/* 149:    */ 
/* 150:    */ 
/* 151:280 */     heapForIndex(insertIndex).bubbleUp(insertIndex, element);
/* 152:281 */     return (this.size <= this.maximumSize) || (pollLast() != element);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public E poll()
/* 156:    */   {
/* 157:285 */     return isEmpty() ? null : removeAndGet(0);
/* 158:    */   }
/* 159:    */   
/* 160:    */   E elementData(int index)
/* 161:    */   {
/* 162:290 */     return this.queue[index];
/* 163:    */   }
/* 164:    */   
/* 165:    */   public E peek()
/* 166:    */   {
/* 167:294 */     return isEmpty() ? null : elementData(0);
/* 168:    */   }
/* 169:    */   
/* 170:    */   private int getMaxElementIndex()
/* 171:    */   {
/* 172:301 */     switch (this.size)
/* 173:    */     {
/* 174:    */     case 1: 
/* 175:303 */       return 0;
/* 176:    */     case 2: 
/* 177:305 */       return 1;
/* 178:    */     }
/* 179:309 */     return this.maxHeap.compareElements(1, 2) <= 0 ? 1 : 2;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public E pollFirst()
/* 183:    */   {
/* 184:318 */     return poll();
/* 185:    */   }
/* 186:    */   
/* 187:    */   public E removeFirst()
/* 188:    */   {
/* 189:327 */     return remove();
/* 190:    */   }
/* 191:    */   
/* 192:    */   public E peekFirst()
/* 193:    */   {
/* 194:335 */     return peek();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public E pollLast()
/* 198:    */   {
/* 199:343 */     return isEmpty() ? null : removeAndGet(getMaxElementIndex());
/* 200:    */   }
/* 201:    */   
/* 202:    */   public E removeLast()
/* 203:    */   {
/* 204:352 */     if (isEmpty()) {
/* 205:353 */       throw new NoSuchElementException();
/* 206:    */     }
/* 207:355 */     return removeAndGet(getMaxElementIndex());
/* 208:    */   }
/* 209:    */   
/* 210:    */   public E peekLast()
/* 211:    */   {
/* 212:363 */     return isEmpty() ? null : elementData(getMaxElementIndex());
/* 213:    */   }
/* 214:    */   
/* 215:    */   @VisibleForTesting
/* 216:    */   MoveDesc<E> removeAt(int index)
/* 217:    */   {
/* 218:382 */     Preconditions.checkPositionIndex(index, this.size);
/* 219:383 */     this.modCount += 1;
/* 220:384 */     this.size -= 1;
/* 221:385 */     if (this.size == index)
/* 222:    */     {
/* 223:386 */       this.queue[this.size] = null;
/* 224:387 */       return null;
/* 225:    */     }
/* 226:389 */     E actualLastElement = elementData(this.size);
/* 227:390 */     int lastElementAt = heapForIndex(this.size).getCorrectLastElement(actualLastElement);
/* 228:    */     
/* 229:392 */     E toTrickle = elementData(this.size);
/* 230:393 */     this.queue[this.size] = null;
/* 231:394 */     MoveDesc<E> changes = fillHole(index, toTrickle);
/* 232:395 */     if (lastElementAt < index)
/* 233:    */     {
/* 234:397 */       if (changes == null) {
/* 235:399 */         return new MoveDesc(actualLastElement, toTrickle);
/* 236:    */       }
/* 237:403 */       return new MoveDesc(actualLastElement, changes.replaced);
/* 238:    */     }
/* 239:407 */     return changes;
/* 240:    */   }
/* 241:    */   
/* 242:    */   private MoveDesc<E> fillHole(int index, E toTrickle)
/* 243:    */   {
/* 244:411 */     MinMaxPriorityQueue<E>.Heap heap = heapForIndex(index);
/* 245:    */     
/* 246:    */ 
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:419 */     int vacated = heap.fillHoleAt(index);
/* 253:    */     
/* 254:421 */     int bubbledTo = heap.bubbleUpAlternatingLevels(vacated, toTrickle);
/* 255:422 */     if (bubbledTo == vacated) {
/* 256:426 */       return heap.tryCrossOverAndBubbleUp(index, vacated, toTrickle);
/* 257:    */     }
/* 258:428 */     return bubbledTo < index ? new MoveDesc(toTrickle, elementData(index)) : null;
/* 259:    */   }
/* 260:    */   
/* 261:    */   static class MoveDesc<E>
/* 262:    */   {
/* 263:    */     final E toTrickle;
/* 264:    */     final E replaced;
/* 265:    */     
/* 266:    */     MoveDesc(E toTrickle, E replaced)
/* 267:    */     {
/* 268:440 */       this.toTrickle = toTrickle;
/* 269:441 */       this.replaced = replaced;
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   private E removeAndGet(int index)
/* 274:    */   {
/* 275:449 */     E value = elementData(index);
/* 276:450 */     removeAt(index);
/* 277:451 */     return value;
/* 278:    */   }
/* 279:    */   
/* 280:    */   private MinMaxPriorityQueue<E>.Heap heapForIndex(int i)
/* 281:    */   {
/* 282:455 */     return isEvenLevel(i) ? this.minHeap : this.maxHeap;
/* 283:    */   }
/* 284:    */   
/* 285:    */   @VisibleForTesting
/* 286:    */   static boolean isEvenLevel(int index)
/* 287:    */   {
/* 288:462 */     int oneBased = index + 1;
/* 289:463 */     Preconditions.checkState(oneBased > 0, "negative index");
/* 290:464 */     return (oneBased & 0x55555555) > (oneBased & 0xAAAAAAAA);
/* 291:    */   }
/* 292:    */   
/* 293:    */   @VisibleForTesting
/* 294:    */   boolean isIntact()
/* 295:    */   {
/* 296:474 */     for (int i = 1; i < this.size; i++) {
/* 297:475 */       if (!heapForIndex(i).verifyIndex(i)) {
/* 298:476 */         return false;
/* 299:    */       }
/* 300:    */     }
/* 301:479 */     return true;
/* 302:    */   }
/* 303:    */   
/* 304:    */   private class Heap
/* 305:    */   {
/* 306:    */     final Ordering<E> ordering;
/* 307:    */     MinMaxPriorityQueue<E>.Heap otherHeap;
/* 308:    */     
/* 309:    */     Heap()
/* 310:    */     {
/* 311:493 */       this.ordering = ordering;
/* 312:    */     }
/* 313:    */     
/* 314:    */     int compareElements(int a, int b)
/* 315:    */     {
/* 316:497 */       return this.ordering.compare(MinMaxPriorityQueue.this.elementData(a), MinMaxPriorityQueue.this.elementData(b));
/* 317:    */     }
/* 318:    */     
/* 319:    */     MinMaxPriorityQueue.MoveDesc<E> tryCrossOverAndBubbleUp(int removeIndex, int vacated, E toTrickle)
/* 320:    */     {
/* 321:507 */       int crossOver = crossOver(vacated, toTrickle);
/* 322:508 */       if (crossOver == vacated) {
/* 323:509 */         return null;
/* 324:    */       }
/* 325:    */       E parent;
/* 326:    */       E parent;
/* 327:517 */       if (crossOver < removeIndex) {
/* 328:520 */         parent = MinMaxPriorityQueue.this.elementData(removeIndex);
/* 329:    */       } else {
/* 330:522 */         parent = MinMaxPriorityQueue.this.elementData(getParentIndex(removeIndex));
/* 331:    */       }
/* 332:525 */       if (this.otherHeap.bubbleUpAlternatingLevels(crossOver, toTrickle) < removeIndex) {
/* 333:527 */         return new MinMaxPriorityQueue.MoveDesc(toTrickle, parent);
/* 334:    */       }
/* 335:529 */       return null;
/* 336:    */     }
/* 337:    */     
/* 338:    */     void bubbleUp(int index, E x)
/* 339:    */     {
/* 340:537 */       int crossOver = crossOverUp(index, x);
/* 341:    */       MinMaxPriorityQueue<E>.Heap heap;
/* 342:    */       MinMaxPriorityQueue<E>.Heap heap;
/* 343:540 */       if (crossOver == index)
/* 344:    */       {
/* 345:541 */         heap = this;
/* 346:    */       }
/* 347:    */       else
/* 348:    */       {
/* 349:543 */         index = crossOver;
/* 350:544 */         heap = this.otherHeap;
/* 351:    */       }
/* 352:546 */       heap.bubbleUpAlternatingLevels(index, x);
/* 353:    */     }
/* 354:    */     
/* 355:    */     int bubbleUpAlternatingLevels(int index, E x)
/* 356:    */     {
/* 357:554 */       while (index > 2)
/* 358:    */       {
/* 359:555 */         int grandParentIndex = getGrandparentIndex(index);
/* 360:556 */         E e = MinMaxPriorityQueue.this.elementData(grandParentIndex);
/* 361:557 */         if (this.ordering.compare(e, x) <= 0) {
/* 362:    */           break;
/* 363:    */         }
/* 364:560 */         MinMaxPriorityQueue.this.queue[index] = e;
/* 365:561 */         index = grandParentIndex;
/* 366:    */       }
/* 367:563 */       MinMaxPriorityQueue.this.queue[index] = x;
/* 368:564 */       return index;
/* 369:    */     }
/* 370:    */     
/* 371:    */     int findMin(int index, int len)
/* 372:    */     {
/* 373:573 */       if (index >= MinMaxPriorityQueue.this.size) {
/* 374:574 */         return -1;
/* 375:    */       }
/* 376:576 */       Preconditions.checkState(index > 0);
/* 377:577 */       int limit = Math.min(index, MinMaxPriorityQueue.this.size - len) + len;
/* 378:578 */       int minIndex = index;
/* 379:579 */       for (int i = index + 1; i < limit; i++) {
/* 380:580 */         if (compareElements(i, minIndex) < 0) {
/* 381:581 */           minIndex = i;
/* 382:    */         }
/* 383:    */       }
/* 384:584 */       return minIndex;
/* 385:    */     }
/* 386:    */     
/* 387:    */     int findMinChild(int index)
/* 388:    */     {
/* 389:591 */       return findMin(getLeftChildIndex(index), 2);
/* 390:    */     }
/* 391:    */     
/* 392:    */     int findMinGrandChild(int index)
/* 393:    */     {
/* 394:598 */       int leftChildIndex = getLeftChildIndex(index);
/* 395:599 */       if (leftChildIndex < 0) {
/* 396:600 */         return -1;
/* 397:    */       }
/* 398:602 */       return findMin(getLeftChildIndex(leftChildIndex), 4);
/* 399:    */     }
/* 400:    */     
/* 401:    */     int crossOverUp(int index, E x)
/* 402:    */     {
/* 403:611 */       if (index == 0)
/* 404:    */       {
/* 405:612 */         MinMaxPriorityQueue.this.queue[0] = x;
/* 406:613 */         return 0;
/* 407:    */       }
/* 408:615 */       int parentIndex = getParentIndex(index);
/* 409:616 */       E parentElement = MinMaxPriorityQueue.this.elementData(parentIndex);
/* 410:617 */       if (parentIndex != 0)
/* 411:    */       {
/* 412:622 */         int grandparentIndex = getParentIndex(parentIndex);
/* 413:623 */         int uncleIndex = getRightChildIndex(grandparentIndex);
/* 414:624 */         if ((uncleIndex != parentIndex) && (getLeftChildIndex(uncleIndex) >= MinMaxPriorityQueue.this.size))
/* 415:    */         {
/* 416:626 */           E uncleElement = MinMaxPriorityQueue.this.elementData(uncleIndex);
/* 417:627 */           if (this.ordering.compare(uncleElement, parentElement) < 0)
/* 418:    */           {
/* 419:628 */             parentIndex = uncleIndex;
/* 420:629 */             parentElement = uncleElement;
/* 421:    */           }
/* 422:    */         }
/* 423:    */       }
/* 424:633 */       if (this.ordering.compare(parentElement, x) < 0)
/* 425:    */       {
/* 426:634 */         MinMaxPriorityQueue.this.queue[index] = parentElement;
/* 427:635 */         MinMaxPriorityQueue.this.queue[parentIndex] = x;
/* 428:636 */         return parentIndex;
/* 429:    */       }
/* 430:638 */       MinMaxPriorityQueue.this.queue[index] = x;
/* 431:639 */       return index;
/* 432:    */     }
/* 433:    */     
/* 434:    */     int getCorrectLastElement(E actualLastElement)
/* 435:    */     {
/* 436:652 */       int parentIndex = getParentIndex(MinMaxPriorityQueue.this.size);
/* 437:653 */       if (parentIndex != 0)
/* 438:    */       {
/* 439:654 */         int grandparentIndex = getParentIndex(parentIndex);
/* 440:655 */         int uncleIndex = getRightChildIndex(grandparentIndex);
/* 441:656 */         if ((uncleIndex != parentIndex) && (getLeftChildIndex(uncleIndex) >= MinMaxPriorityQueue.this.size))
/* 442:    */         {
/* 443:658 */           E uncleElement = MinMaxPriorityQueue.this.elementData(uncleIndex);
/* 444:659 */           if (this.ordering.compare(uncleElement, actualLastElement) < 0)
/* 445:    */           {
/* 446:660 */             MinMaxPriorityQueue.this.queue[uncleIndex] = actualLastElement;
/* 447:661 */             MinMaxPriorityQueue.this.queue[MinMaxPriorityQueue.this.size] = uncleElement;
/* 448:662 */             return uncleIndex;
/* 449:    */           }
/* 450:    */         }
/* 451:    */       }
/* 452:666 */       return MinMaxPriorityQueue.this.size;
/* 453:    */     }
/* 454:    */     
/* 455:    */     int crossOver(int index, E x)
/* 456:    */     {
/* 457:676 */       int minChildIndex = findMinChild(index);
/* 458:679 */       if ((minChildIndex > 0) && (this.ordering.compare(MinMaxPriorityQueue.this.elementData(minChildIndex), x) < 0))
/* 459:    */       {
/* 460:681 */         MinMaxPriorityQueue.this.queue[index] = MinMaxPriorityQueue.this.elementData(minChildIndex);
/* 461:682 */         MinMaxPriorityQueue.this.queue[minChildIndex] = x;
/* 462:683 */         return minChildIndex;
/* 463:    */       }
/* 464:685 */       return crossOverUp(index, x);
/* 465:    */     }
/* 466:    */     
/* 467:    */     int fillHoleAt(int index)
/* 468:    */     {
/* 469:    */       int minGrandchildIndex;
/* 470:698 */       while ((minGrandchildIndex = findMinGrandChild(index)) > 0)
/* 471:    */       {
/* 472:699 */         MinMaxPriorityQueue.this.queue[index] = MinMaxPriorityQueue.this.elementData(minGrandchildIndex);
/* 473:700 */         index = minGrandchildIndex;
/* 474:    */       }
/* 475:702 */       return index;
/* 476:    */     }
/* 477:    */     
/* 478:    */     private boolean verifyIndex(int i)
/* 479:    */     {
/* 480:706 */       if ((getLeftChildIndex(i) < MinMaxPriorityQueue.this.size) && (compareElements(i, getLeftChildIndex(i)) > 0)) {
/* 481:708 */         return false;
/* 482:    */       }
/* 483:710 */       if ((getRightChildIndex(i) < MinMaxPriorityQueue.this.size) && (compareElements(i, getRightChildIndex(i)) > 0)) {
/* 484:712 */         return false;
/* 485:    */       }
/* 486:714 */       if ((i > 0) && (compareElements(i, getParentIndex(i)) > 0)) {
/* 487:715 */         return false;
/* 488:    */       }
/* 489:717 */       if ((i > 2) && (compareElements(getGrandparentIndex(i), i) > 0)) {
/* 490:718 */         return false;
/* 491:    */       }
/* 492:720 */       return true;
/* 493:    */     }
/* 494:    */     
/* 495:    */     private int getLeftChildIndex(int i)
/* 496:    */     {
/* 497:726 */       return i * 2 + 1;
/* 498:    */     }
/* 499:    */     
/* 500:    */     private int getRightChildIndex(int i)
/* 501:    */     {
/* 502:730 */       return i * 2 + 2;
/* 503:    */     }
/* 504:    */     
/* 505:    */     private int getParentIndex(int i)
/* 506:    */     {
/* 507:734 */       return (i - 1) / 2;
/* 508:    */     }
/* 509:    */     
/* 510:    */     private int getGrandparentIndex(int i)
/* 511:    */     {
/* 512:738 */       return getParentIndex(getParentIndex(i));
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   private class QueueIterator
/* 517:    */     implements Iterator<E>
/* 518:    */   {
/* 519:749 */     private int cursor = -1;
/* 520:750 */     private int expectedModCount = MinMaxPriorityQueue.this.modCount;
/* 521:    */     private Queue<E> forgetMeNot;
/* 522:    */     private List<E> skipMe;
/* 523:    */     private E lastFromForgetMeNot;
/* 524:    */     private boolean canRemove;
/* 525:    */     
/* 526:    */     private QueueIterator() {}
/* 527:    */     
/* 528:    */     public boolean hasNext()
/* 529:    */     {
/* 530:757 */       checkModCount();
/* 531:758 */       return (nextNotInSkipMe(this.cursor + 1) < MinMaxPriorityQueue.this.size()) || ((this.forgetMeNot != null) && (!this.forgetMeNot.isEmpty()));
/* 532:    */     }
/* 533:    */     
/* 534:    */     public E next()
/* 535:    */     {
/* 536:763 */       checkModCount();
/* 537:764 */       int tempCursor = nextNotInSkipMe(this.cursor + 1);
/* 538:765 */       if (tempCursor < MinMaxPriorityQueue.this.size())
/* 539:    */       {
/* 540:766 */         this.cursor = tempCursor;
/* 541:767 */         this.canRemove = true;
/* 542:768 */         return MinMaxPriorityQueue.this.elementData(this.cursor);
/* 543:    */       }
/* 544:769 */       if (this.forgetMeNot != null)
/* 545:    */       {
/* 546:770 */         this.cursor = MinMaxPriorityQueue.this.size();
/* 547:771 */         this.lastFromForgetMeNot = this.forgetMeNot.poll();
/* 548:772 */         if (this.lastFromForgetMeNot != null)
/* 549:    */         {
/* 550:773 */           this.canRemove = true;
/* 551:774 */           return this.lastFromForgetMeNot;
/* 552:    */         }
/* 553:    */       }
/* 554:777 */       throw new NoSuchElementException("iterator moved past last element in queue.");
/* 555:    */     }
/* 556:    */     
/* 557:    */     public void remove()
/* 558:    */     {
/* 559:782 */       CollectPreconditions.checkRemove(this.canRemove);
/* 560:783 */       checkModCount();
/* 561:784 */       this.canRemove = false;
/* 562:785 */       this.expectedModCount += 1;
/* 563:786 */       if (this.cursor < MinMaxPriorityQueue.this.size())
/* 564:    */       {
/* 565:787 */         MinMaxPriorityQueue.MoveDesc<E> moved = MinMaxPriorityQueue.this.removeAt(this.cursor);
/* 566:788 */         if (moved != null)
/* 567:    */         {
/* 568:789 */           if (this.forgetMeNot == null)
/* 569:    */           {
/* 570:790 */             this.forgetMeNot = new ArrayDeque();
/* 571:791 */             this.skipMe = new ArrayList(3);
/* 572:    */           }
/* 573:793 */           this.forgetMeNot.add(moved.toTrickle);
/* 574:794 */           this.skipMe.add(moved.replaced);
/* 575:    */         }
/* 576:796 */         this.cursor -= 1;
/* 577:    */       }
/* 578:    */       else
/* 579:    */       {
/* 580:798 */         Preconditions.checkState(removeExact(this.lastFromForgetMeNot));
/* 581:799 */         this.lastFromForgetMeNot = null;
/* 582:    */       }
/* 583:    */     }
/* 584:    */     
/* 585:    */     private boolean containsExact(Iterable<E> elements, E target)
/* 586:    */     {
/* 587:805 */       for (E element : elements) {
/* 588:806 */         if (element == target) {
/* 589:807 */           return true;
/* 590:    */         }
/* 591:    */       }
/* 592:810 */       return false;
/* 593:    */     }
/* 594:    */     
/* 595:    */     boolean removeExact(Object target)
/* 596:    */     {
/* 597:815 */       for (int i = 0; i < MinMaxPriorityQueue.this.size; i++) {
/* 598:816 */         if (MinMaxPriorityQueue.this.queue[i] == target)
/* 599:    */         {
/* 600:817 */           MinMaxPriorityQueue.this.removeAt(i);
/* 601:818 */           return true;
/* 602:    */         }
/* 603:    */       }
/* 604:821 */       return false;
/* 605:    */     }
/* 606:    */     
/* 607:    */     void checkModCount()
/* 608:    */     {
/* 609:825 */       if (MinMaxPriorityQueue.this.modCount != this.expectedModCount) {
/* 610:826 */         throw new ConcurrentModificationException();
/* 611:    */       }
/* 612:    */     }
/* 613:    */     
/* 614:    */     private int nextNotInSkipMe(int c)
/* 615:    */     {
/* 616:835 */       if (this.skipMe != null) {
/* 617:836 */         while ((c < MinMaxPriorityQueue.this.size()) && (containsExact(this.skipMe, MinMaxPriorityQueue.this.elementData(c)))) {
/* 618:837 */           c++;
/* 619:    */         }
/* 620:    */       }
/* 621:840 */       return c;
/* 622:    */     }
/* 623:    */   }
/* 624:    */   
/* 625:    */   public Iterator<E> iterator()
/* 626:    */   {
/* 627:867 */     return new QueueIterator(null);
/* 628:    */   }
/* 629:    */   
/* 630:    */   public void clear()
/* 631:    */   {
/* 632:871 */     for (int i = 0; i < this.size; i++) {
/* 633:872 */       this.queue[i] = null;
/* 634:    */     }
/* 635:874 */     this.size = 0;
/* 636:    */   }
/* 637:    */   
/* 638:    */   public Object[] toArray()
/* 639:    */   {
/* 640:878 */     Object[] copyTo = new Object[this.size];
/* 641:879 */     System.arraycopy(this.queue, 0, copyTo, 0, this.size);
/* 642:880 */     return copyTo;
/* 643:    */   }
/* 644:    */   
/* 645:    */   public Comparator<? super E> comparator()
/* 646:    */   {
/* 647:889 */     return this.minHeap.ordering;
/* 648:    */   }
/* 649:    */   
/* 650:    */   @VisibleForTesting
/* 651:    */   int capacity()
/* 652:    */   {
/* 653:893 */     return this.queue.length;
/* 654:    */   }
/* 655:    */   
/* 656:    */   @VisibleForTesting
/* 657:    */   static int initialQueueSize(int configuredExpectedSize, int maximumSize, Iterable<?> initialContents)
/* 658:    */   {
/* 659:903 */     int result = configuredExpectedSize == -1 ? 11 : configuredExpectedSize;
/* 660:908 */     if ((initialContents instanceof Collection))
/* 661:    */     {
/* 662:909 */       int initialSize = ((Collection)initialContents).size();
/* 663:910 */       result = Math.max(result, initialSize);
/* 664:    */     }
/* 665:914 */     return capAtMaximumSize(result, maximumSize);
/* 666:    */   }
/* 667:    */   
/* 668:    */   private void growIfNeeded()
/* 669:    */   {
/* 670:918 */     if (this.size > this.queue.length)
/* 671:    */     {
/* 672:919 */       int newCapacity = calculateNewCapacity();
/* 673:920 */       Object[] newQueue = new Object[newCapacity];
/* 674:921 */       System.arraycopy(this.queue, 0, newQueue, 0, this.queue.length);
/* 675:922 */       this.queue = newQueue;
/* 676:    */     }
/* 677:    */   }
/* 678:    */   
/* 679:    */   private int calculateNewCapacity()
/* 680:    */   {
/* 681:928 */     int oldCapacity = this.queue.length;
/* 682:929 */     int newCapacity = oldCapacity < 64 ? (oldCapacity + 1) * 2 : IntMath.checkedMultiply(oldCapacity / 2, 3);
/* 683:    */     
/* 684:    */ 
/* 685:932 */     return capAtMaximumSize(newCapacity, this.maximumSize);
/* 686:    */   }
/* 687:    */   
/* 688:    */   private static int capAtMaximumSize(int queueSize, int maximumSize)
/* 689:    */   {
/* 690:937 */     return Math.min(queueSize - 1, maximumSize) + 1;
/* 691:    */   }
/* 692:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.MinMaxPriorityQueue
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.primitives.Primitives;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ public final class ImmutableClassToInstanceMap<B>
/*  11:    */   extends ForwardingMap<Class<? extends B>, B>
/*  12:    */   implements ClassToInstanceMap<B>, Serializable
/*  13:    */ {
/*  14:    */   private final ImmutableMap<Class<? extends B>, B> delegate;
/*  15:    */   
/*  16:    */   public static <B> Builder<B> builder()
/*  17:    */   {
/*  18: 44 */     return new Builder();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static final class Builder<B>
/*  22:    */   {
/*  23: 65 */     private final ImmutableMap.Builder<Class<? extends B>, B> mapBuilder = ImmutableMap.builder();
/*  24:    */     
/*  25:    */     public <T extends B> Builder<B> put(Class<T> key, T value)
/*  26:    */     {
/*  27: 73 */       this.mapBuilder.put(key, value);
/*  28: 74 */       return this;
/*  29:    */     }
/*  30:    */     
/*  31:    */     public <T extends B> Builder<B> putAll(Map<? extends Class<? extends T>, ? extends T> map)
/*  32:    */     {
/*  33: 88 */       for (Map.Entry<? extends Class<? extends T>, ? extends T> entry : map.entrySet())
/*  34:    */       {
/*  35: 89 */         Class<? extends T> type = (Class)entry.getKey();
/*  36: 90 */         T value = entry.getValue();
/*  37: 91 */         this.mapBuilder.put(type, cast(type, value));
/*  38:    */       }
/*  39: 93 */       return this;
/*  40:    */     }
/*  41:    */     
/*  42:    */     private static <B, T extends B> T cast(Class<T> type, B value)
/*  43:    */     {
/*  44: 97 */       return Primitives.wrap(type).cast(value);
/*  45:    */     }
/*  46:    */     
/*  47:    */     public ImmutableClassToInstanceMap<B> build()
/*  48:    */     {
/*  49:107 */       return new ImmutableClassToInstanceMap(this.mapBuilder.build(), null);
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <B, S extends B> ImmutableClassToInstanceMap<B> copyOf(Map<? extends Class<? extends S>, ? extends S> map)
/*  54:    */   {
/*  55:126 */     if ((map instanceof ImmutableClassToInstanceMap))
/*  56:    */     {
/*  57:129 */       ImmutableClassToInstanceMap<B> cast = (ImmutableClassToInstanceMap)map;
/*  58:130 */       return cast;
/*  59:    */     }
/*  60:132 */     return new Builder().putAll(map).build();
/*  61:    */   }
/*  62:    */   
/*  63:    */   private ImmutableClassToInstanceMap(ImmutableMap<Class<? extends B>, B> delegate)
/*  64:    */   {
/*  65:139 */     this.delegate = delegate;
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected Map<Class<? extends B>, B> delegate()
/*  69:    */   {
/*  70:143 */     return this.delegate;
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Nullable
/*  74:    */   public <T extends B> T getInstance(Class<T> type)
/*  75:    */   {
/*  76:150 */     return this.delegate.get(Preconditions.checkNotNull(type));
/*  77:    */   }
/*  78:    */   
/*  79:    */   @Deprecated
/*  80:    */   public <T extends B> T putInstance(Class<T> type, T value)
/*  81:    */   {
/*  82:162 */     throw new UnsupportedOperationException();
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ImmutableClassToInstanceMap
 * JD-Core Version:    0.7.0.1
 */
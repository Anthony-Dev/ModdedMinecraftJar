/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.lang.reflect.Array;
/*   7:    */ import java.util.Collection;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ public final class ObjectArrays
/*  12:    */ {
/*  13: 37 */   static final Object[] EMPTY_ARRAY = new Object[0];
/*  14:    */   
/*  15:    */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  16:    */   public static <T> T[] newArray(Class<T> type, int length)
/*  17:    */   {
/*  18: 50 */     return (Object[])Array.newInstance(type, length);
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static <T> T[] newArray(T[] reference, int length)
/*  22:    */   {
/*  23: 61 */     return Platform.newArray(reference, length);
/*  24:    */   }
/*  25:    */   
/*  26:    */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  27:    */   public static <T> T[] concat(T[] first, T[] second, Class<T> type)
/*  28:    */   {
/*  29: 73 */     T[] result = newArray(type, first.length + second.length);
/*  30: 74 */     System.arraycopy(first, 0, result, 0, first.length);
/*  31: 75 */     System.arraycopy(second, 0, result, first.length, second.length);
/*  32: 76 */     return result;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <T> T[] concat(@Nullable T element, T[] array)
/*  36:    */   {
/*  37: 89 */     T[] result = newArray(array, array.length + 1);
/*  38: 90 */     result[0] = element;
/*  39: 91 */     System.arraycopy(array, 0, result, 1, array.length);
/*  40: 92 */     return result;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <T> T[] concat(T[] array, @Nullable T element)
/*  44:    */   {
/*  45:105 */     T[] result = arraysCopyOf(array, array.length + 1);
/*  46:106 */     result[array.length] = element;
/*  47:107 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <T> T[] arraysCopyOf(T[] original, int newLength)
/*  51:    */   {
/*  52:112 */     T[] copy = newArray(original, newLength);
/*  53:113 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
/*  54:    */     
/*  55:115 */     return copy;
/*  56:    */   }
/*  57:    */   
/*  58:    */   static <T> T[] toArrayImpl(Collection<?> c, T[] array)
/*  59:    */   {
/*  60:143 */     int size = c.size();
/*  61:144 */     if (array.length < size) {
/*  62:145 */       array = newArray(array, size);
/*  63:    */     }
/*  64:147 */     fillArray(c, array);
/*  65:148 */     if (array.length > size) {
/*  66:149 */       array[size] = null;
/*  67:    */     }
/*  68:151 */     return array;
/*  69:    */   }
/*  70:    */   
/*  71:    */   static <T> T[] toArrayImpl(Object[] src, int offset, int len, T[] dst)
/*  72:    */   {
/*  73:166 */     Preconditions.checkPositionIndexes(offset, offset + len, src.length);
/*  74:167 */     if (dst.length < len) {
/*  75:168 */       dst = newArray(dst, len);
/*  76:169 */     } else if (dst.length > len) {
/*  77:170 */       dst[len] = null;
/*  78:    */     }
/*  79:172 */     System.arraycopy(src, offset, dst, 0, len);
/*  80:173 */     return dst;
/*  81:    */   }
/*  82:    */   
/*  83:    */   static Object[] toArrayImpl(Collection<?> c)
/*  84:    */   {
/*  85:191 */     return fillArray(c, new Object[c.size()]);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static Object[] copyAsObjectArray(Object[] elements, int offset, int length)
/*  89:    */   {
/*  90:199 */     Preconditions.checkPositionIndexes(offset, offset + length, elements.length);
/*  91:200 */     if (length == 0) {
/*  92:201 */       return EMPTY_ARRAY;
/*  93:    */     }
/*  94:203 */     Object[] result = new Object[length];
/*  95:204 */     System.arraycopy(elements, offset, result, 0, length);
/*  96:205 */     return result;
/*  97:    */   }
/*  98:    */   
/*  99:    */   private static Object[] fillArray(Iterable<?> elements, Object[] array)
/* 100:    */   {
/* 101:209 */     int i = 0;
/* 102:210 */     for (Object element : elements) {
/* 103:211 */       array[(i++)] = element;
/* 104:    */     }
/* 105:213 */     return array;
/* 106:    */   }
/* 107:    */   
/* 108:    */   static void swap(Object[] array, int i, int j)
/* 109:    */   {
/* 110:220 */     Object temp = array[i];
/* 111:221 */     array[i] = array[j];
/* 112:222 */     array[j] = temp;
/* 113:    */   }
/* 114:    */   
/* 115:    */   static Object[] checkElementsNotNull(Object... array)
/* 116:    */   {
/* 117:226 */     return checkElementsNotNull(array, array.length);
/* 118:    */   }
/* 119:    */   
/* 120:    */   static Object[] checkElementsNotNull(Object[] array, int length)
/* 121:    */   {
/* 122:230 */     for (int i = 0; i < length; i++) {
/* 123:231 */       checkElementNotNull(array[i], i);
/* 124:    */     }
/* 125:233 */     return array;
/* 126:    */   }
/* 127:    */   
/* 128:    */   static Object checkElementNotNull(Object element, int index)
/* 129:    */   {
/* 130:239 */     if (element == null) {
/* 131:240 */       throw new NullPointerException("at index " + index);
/* 132:    */     }
/* 133:242 */     return element;
/* 134:    */   }
/* 135:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ObjectArrays
 * JD-Core Version:    0.7.0.1
 */
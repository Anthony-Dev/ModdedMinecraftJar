/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.SortedSet;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ abstract class AbstractSortedSetMultimap<K, V>
/*  13:    */   extends AbstractSetMultimap<K, V>
/*  14:    */   implements SortedSetMultimap<K, V>
/*  15:    */ {
/*  16:    */   private static final long serialVersionUID = 430848587173315748L;
/*  17:    */   
/*  18:    */   protected AbstractSortedSetMultimap(Map<K, Collection<V>> map)
/*  19:    */   {
/*  20: 47 */     super(map);
/*  21:    */   }
/*  22:    */   
/*  23:    */   abstract SortedSet<V> createCollection();
/*  24:    */   
/*  25:    */   SortedSet<V> createUnmodifiableEmptyCollection()
/*  26:    */   {
/*  27: 55 */     Comparator<? super V> comparator = valueComparator();
/*  28: 56 */     if (comparator == null) {
/*  29: 57 */       return Collections.unmodifiableSortedSet(createCollection());
/*  30:    */     }
/*  31: 59 */     return ImmutableSortedSet.emptySet(valueComparator());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public SortedSet<V> get(@Nullable K key)
/*  35:    */   {
/*  36: 78 */     return (SortedSet)super.get(key);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public SortedSet<V> removeAll(@Nullable Object key)
/*  40:    */   {
/*  41: 90 */     return (SortedSet)super.removeAll(key);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public SortedSet<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*  45:    */   {
/*  46:105 */     return (SortedSet)super.replaceValues(key, values);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Map<K, Collection<V>> asMap()
/*  50:    */   {
/*  51:123 */     return super.asMap();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Collection<V> values()
/*  55:    */   {
/*  56:133 */     return super.values();
/*  57:    */   }
/*  58:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AbstractSortedSetMultimap
 * JD-Core Version:    0.7.0.1
 */
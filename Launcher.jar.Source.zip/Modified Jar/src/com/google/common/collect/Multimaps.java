/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Preconditions;
/*    8:     */ import com.google.common.base.Predicate;
/*    9:     */ import com.google.common.base.Predicates;
/*   10:     */ import com.google.common.base.Supplier;
/*   11:     */ import java.io.IOException;
/*   12:     */ import java.io.ObjectInputStream;
/*   13:     */ import java.io.ObjectOutputStream;
/*   14:     */ import java.io.Serializable;
/*   15:     */ import java.util.AbstractCollection;
/*   16:     */ import java.util.Collection;
/*   17:     */ import java.util.Collections;
/*   18:     */ import java.util.Comparator;
/*   19:     */ import java.util.HashSet;
/*   20:     */ import java.util.Iterator;
/*   21:     */ import java.util.List;
/*   22:     */ import java.util.Map;
/*   23:     */ import java.util.Map.Entry;
/*   24:     */ import java.util.NoSuchElementException;
/*   25:     */ import java.util.Set;
/*   26:     */ import java.util.SortedSet;
/*   27:     */ import javax.annotation.Nullable;
/*   28:     */ 
/*   29:     */ @GwtCompatible(emulated=true)
/*   30:     */ public final class Multimaps
/*   31:     */ {
/*   32:     */   public static <K, V> Multimap<K, V> newMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*   33:     */   {
/*   34: 113 */     return new CustomMultimap(map, factory);
/*   35:     */   }
/*   36:     */   
/*   37:     */   private static class CustomMultimap<K, V>
/*   38:     */     extends AbstractMapBasedMultimap<K, V>
/*   39:     */   {
/*   40:     */     transient Supplier<? extends Collection<V>> factory;
/*   41:     */     @GwtIncompatible("java serialization not supported")
/*   42:     */     private static final long serialVersionUID = 0L;
/*   43:     */     
/*   44:     */     CustomMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*   45:     */     {
/*   46: 121 */       super();
/*   47: 122 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*   48:     */     }
/*   49:     */     
/*   50:     */     protected Collection<V> createCollection()
/*   51:     */     {
/*   52: 126 */       return (Collection)this.factory.get();
/*   53:     */     }
/*   54:     */     
/*   55:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*   56:     */     private void writeObject(ObjectOutputStream stream)
/*   57:     */       throws IOException
/*   58:     */     {
/*   59: 135 */       stream.defaultWriteObject();
/*   60: 136 */       stream.writeObject(this.factory);
/*   61: 137 */       stream.writeObject(backingMap());
/*   62:     */     }
/*   63:     */     
/*   64:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*   65:     */     private void readObject(ObjectInputStream stream)
/*   66:     */       throws IOException, ClassNotFoundException
/*   67:     */     {
/*   68: 144 */       stream.defaultReadObject();
/*   69: 145 */       this.factory = ((Supplier)stream.readObject());
/*   70: 146 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*   71: 147 */       setMap(map);
/*   72:     */     }
/*   73:     */   }
/*   74:     */   
/*   75:     */   public static <K, V> ListMultimap<K, V> newListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*   76:     */   {
/*   77: 194 */     return new CustomListMultimap(map, factory);
/*   78:     */   }
/*   79:     */   
/*   80:     */   private static class CustomListMultimap<K, V>
/*   81:     */     extends AbstractListMultimap<K, V>
/*   82:     */   {
/*   83:     */     transient Supplier<? extends List<V>> factory;
/*   84:     */     @GwtIncompatible("java serialization not supported")
/*   85:     */     private static final long serialVersionUID = 0L;
/*   86:     */     
/*   87:     */     CustomListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*   88:     */     {
/*   89: 203 */       super();
/*   90: 204 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*   91:     */     }
/*   92:     */     
/*   93:     */     protected List<V> createCollection()
/*   94:     */     {
/*   95: 208 */       return (List)this.factory.get();
/*   96:     */     }
/*   97:     */     
/*   98:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*   99:     */     private void writeObject(ObjectOutputStream stream)
/*  100:     */       throws IOException
/*  101:     */     {
/*  102: 214 */       stream.defaultWriteObject();
/*  103: 215 */       stream.writeObject(this.factory);
/*  104: 216 */       stream.writeObject(backingMap());
/*  105:     */     }
/*  106:     */     
/*  107:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  108:     */     private void readObject(ObjectInputStream stream)
/*  109:     */       throws IOException, ClassNotFoundException
/*  110:     */     {
/*  111: 223 */       stream.defaultReadObject();
/*  112: 224 */       this.factory = ((Supplier)stream.readObject());
/*  113: 225 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  114: 226 */       setMap(map);
/*  115:     */     }
/*  116:     */   }
/*  117:     */   
/*  118:     */   public static <K, V> SetMultimap<K, V> newSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*  119:     */   {
/*  120: 272 */     return new CustomSetMultimap(map, factory);
/*  121:     */   }
/*  122:     */   
/*  123:     */   private static class CustomSetMultimap<K, V>
/*  124:     */     extends AbstractSetMultimap<K, V>
/*  125:     */   {
/*  126:     */     transient Supplier<? extends Set<V>> factory;
/*  127:     */     @GwtIncompatible("not needed in emulated source")
/*  128:     */     private static final long serialVersionUID = 0L;
/*  129:     */     
/*  130:     */     CustomSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*  131:     */     {
/*  132: 281 */       super();
/*  133: 282 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*  134:     */     }
/*  135:     */     
/*  136:     */     protected Set<V> createCollection()
/*  137:     */     {
/*  138: 286 */       return (Set)this.factory.get();
/*  139:     */     }
/*  140:     */     
/*  141:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*  142:     */     private void writeObject(ObjectOutputStream stream)
/*  143:     */       throws IOException
/*  144:     */     {
/*  145: 292 */       stream.defaultWriteObject();
/*  146: 293 */       stream.writeObject(this.factory);
/*  147: 294 */       stream.writeObject(backingMap());
/*  148:     */     }
/*  149:     */     
/*  150:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  151:     */     private void readObject(ObjectInputStream stream)
/*  152:     */       throws IOException, ClassNotFoundException
/*  153:     */     {
/*  154: 301 */       stream.defaultReadObject();
/*  155: 302 */       this.factory = ((Supplier)stream.readObject());
/*  156: 303 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  157: 304 */       setMap(map);
/*  158:     */     }
/*  159:     */   }
/*  160:     */   
/*  161:     */   public static <K, V> SortedSetMultimap<K, V> newSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*  162:     */   {
/*  163: 350 */     return new CustomSortedSetMultimap(map, factory);
/*  164:     */   }
/*  165:     */   
/*  166:     */   private static class CustomSortedSetMultimap<K, V>
/*  167:     */     extends AbstractSortedSetMultimap<K, V>
/*  168:     */   {
/*  169:     */     transient Supplier<? extends SortedSet<V>> factory;
/*  170:     */     transient Comparator<? super V> valueComparator;
/*  171:     */     @GwtIncompatible("not needed in emulated source")
/*  172:     */     private static final long serialVersionUID = 0L;
/*  173:     */     
/*  174:     */     CustomSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*  175:     */     {
/*  176: 360 */       super();
/*  177: 361 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*  178: 362 */       this.valueComparator = ((SortedSet)factory.get()).comparator();
/*  179:     */     }
/*  180:     */     
/*  181:     */     protected SortedSet<V> createCollection()
/*  182:     */     {
/*  183: 366 */       return (SortedSet)this.factory.get();
/*  184:     */     }
/*  185:     */     
/*  186:     */     public Comparator<? super V> valueComparator()
/*  187:     */     {
/*  188: 370 */       return this.valueComparator;
/*  189:     */     }
/*  190:     */     
/*  191:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*  192:     */     private void writeObject(ObjectOutputStream stream)
/*  193:     */       throws IOException
/*  194:     */     {
/*  195: 376 */       stream.defaultWriteObject();
/*  196: 377 */       stream.writeObject(this.factory);
/*  197: 378 */       stream.writeObject(backingMap());
/*  198:     */     }
/*  199:     */     
/*  200:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  201:     */     private void readObject(ObjectInputStream stream)
/*  202:     */       throws IOException, ClassNotFoundException
/*  203:     */     {
/*  204: 385 */       stream.defaultReadObject();
/*  205: 386 */       this.factory = ((Supplier)stream.readObject());
/*  206: 387 */       this.valueComparator = ((SortedSet)this.factory.get()).comparator();
/*  207: 388 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  208: 389 */       setMap(map);
/*  209:     */     }
/*  210:     */   }
/*  211:     */   
/*  212:     */   public static <K, V, M extends Multimap<K, V>> M invertFrom(Multimap<? extends V, ? extends K> source, M dest)
/*  213:     */   {
/*  214: 409 */     Preconditions.checkNotNull(dest);
/*  215: 410 */     for (Map.Entry<? extends V, ? extends K> entry : source.entries()) {
/*  216: 411 */       dest.put(entry.getValue(), entry.getKey());
/*  217:     */     }
/*  218: 413 */     return dest;
/*  219:     */   }
/*  220:     */   
/*  221:     */   public static <K, V> Multimap<K, V> synchronizedMultimap(Multimap<K, V> multimap)
/*  222:     */   {
/*  223: 451 */     return Synchronized.multimap(multimap, null);
/*  224:     */   }
/*  225:     */   
/*  226:     */   public static <K, V> Multimap<K, V> unmodifiableMultimap(Multimap<K, V> delegate)
/*  227:     */   {
/*  228: 473 */     if (((delegate instanceof UnmodifiableMultimap)) || ((delegate instanceof ImmutableMultimap))) {
/*  229: 475 */       return delegate;
/*  230:     */     }
/*  231: 477 */     return new UnmodifiableMultimap(delegate);
/*  232:     */   }
/*  233:     */   
/*  234:     */   @Deprecated
/*  235:     */   public static <K, V> Multimap<K, V> unmodifiableMultimap(ImmutableMultimap<K, V> delegate)
/*  236:     */   {
/*  237: 488 */     return (Multimap)Preconditions.checkNotNull(delegate);
/*  238:     */   }
/*  239:     */   
/*  240:     */   private static class UnmodifiableMultimap<K, V>
/*  241:     */     extends ForwardingMultimap<K, V>
/*  242:     */     implements Serializable
/*  243:     */   {
/*  244:     */     final Multimap<K, V> delegate;
/*  245:     */     transient Collection<Map.Entry<K, V>> entries;
/*  246:     */     transient Multiset<K> keys;
/*  247:     */     transient Set<K> keySet;
/*  248:     */     transient Collection<V> values;
/*  249:     */     transient Map<K, Collection<V>> map;
/*  250:     */     private static final long serialVersionUID = 0L;
/*  251:     */     
/*  252:     */     UnmodifiableMultimap(Multimap<K, V> delegate)
/*  253:     */     {
/*  254: 501 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/*  255:     */     }
/*  256:     */     
/*  257:     */     protected Multimap<K, V> delegate()
/*  258:     */     {
/*  259: 505 */       return this.delegate;
/*  260:     */     }
/*  261:     */     
/*  262:     */     public void clear()
/*  263:     */     {
/*  264: 509 */       throw new UnsupportedOperationException();
/*  265:     */     }
/*  266:     */     
/*  267:     */     public Map<K, Collection<V>> asMap()
/*  268:     */     {
/*  269: 513 */       Map<K, Collection<V>> result = this.map;
/*  270: 514 */       if (result == null) {
/*  271: 515 */         result = this.map = Collections.unmodifiableMap(Maps.transformValues(this.delegate.asMap(), new Function()
/*  272:     */         {
/*  273:     */           public Collection<V> apply(Collection<V> collection)
/*  274:     */           {
/*  275: 519 */             return Multimaps.unmodifiableValueCollection(collection);
/*  276:     */           }
/*  277:     */         }));
/*  278:     */       }
/*  279: 523 */       return result;
/*  280:     */     }
/*  281:     */     
/*  282:     */     public Collection<Map.Entry<K, V>> entries()
/*  283:     */     {
/*  284: 527 */       Collection<Map.Entry<K, V>> result = this.entries;
/*  285: 528 */       if (result == null) {
/*  286: 529 */         this.entries = (result = Multimaps.unmodifiableEntries(this.delegate.entries()));
/*  287:     */       }
/*  288: 531 */       return result;
/*  289:     */     }
/*  290:     */     
/*  291:     */     public Collection<V> get(K key)
/*  292:     */     {
/*  293: 535 */       return Multimaps.unmodifiableValueCollection(this.delegate.get(key));
/*  294:     */     }
/*  295:     */     
/*  296:     */     public Multiset<K> keys()
/*  297:     */     {
/*  298: 539 */       Multiset<K> result = this.keys;
/*  299: 540 */       if (result == null) {
/*  300: 541 */         this.keys = (result = Multisets.unmodifiableMultiset(this.delegate.keys()));
/*  301:     */       }
/*  302: 543 */       return result;
/*  303:     */     }
/*  304:     */     
/*  305:     */     public Set<K> keySet()
/*  306:     */     {
/*  307: 547 */       Set<K> result = this.keySet;
/*  308: 548 */       if (result == null) {
/*  309: 549 */         this.keySet = (result = Collections.unmodifiableSet(this.delegate.keySet()));
/*  310:     */       }
/*  311: 551 */       return result;
/*  312:     */     }
/*  313:     */     
/*  314:     */     public boolean put(K key, V value)
/*  315:     */     {
/*  316: 555 */       throw new UnsupportedOperationException();
/*  317:     */     }
/*  318:     */     
/*  319:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  320:     */     {
/*  321: 559 */       throw new UnsupportedOperationException();
/*  322:     */     }
/*  323:     */     
/*  324:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  325:     */     {
/*  326: 564 */       throw new UnsupportedOperationException();
/*  327:     */     }
/*  328:     */     
/*  329:     */     public boolean remove(Object key, Object value)
/*  330:     */     {
/*  331: 568 */       throw new UnsupportedOperationException();
/*  332:     */     }
/*  333:     */     
/*  334:     */     public Collection<V> removeAll(Object key)
/*  335:     */     {
/*  336: 572 */       throw new UnsupportedOperationException();
/*  337:     */     }
/*  338:     */     
/*  339:     */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*  340:     */     {
/*  341: 577 */       throw new UnsupportedOperationException();
/*  342:     */     }
/*  343:     */     
/*  344:     */     public Collection<V> values()
/*  345:     */     {
/*  346: 581 */       Collection<V> result = this.values;
/*  347: 582 */       if (result == null) {
/*  348: 583 */         this.values = (result = Collections.unmodifiableCollection(this.delegate.values()));
/*  349:     */       }
/*  350: 585 */       return result;
/*  351:     */     }
/*  352:     */   }
/*  353:     */   
/*  354:     */   private static class UnmodifiableListMultimap<K, V>
/*  355:     */     extends Multimaps.UnmodifiableMultimap<K, V>
/*  356:     */     implements ListMultimap<K, V>
/*  357:     */   {
/*  358:     */     private static final long serialVersionUID = 0L;
/*  359:     */     
/*  360:     */     UnmodifiableListMultimap(ListMultimap<K, V> delegate)
/*  361:     */     {
/*  362: 594 */       super();
/*  363:     */     }
/*  364:     */     
/*  365:     */     public ListMultimap<K, V> delegate()
/*  366:     */     {
/*  367: 597 */       return (ListMultimap)super.delegate();
/*  368:     */     }
/*  369:     */     
/*  370:     */     public List<V> get(K key)
/*  371:     */     {
/*  372: 600 */       return Collections.unmodifiableList(delegate().get(key));
/*  373:     */     }
/*  374:     */     
/*  375:     */     public List<V> removeAll(Object key)
/*  376:     */     {
/*  377: 603 */       throw new UnsupportedOperationException();
/*  378:     */     }
/*  379:     */     
/*  380:     */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/*  381:     */     {
/*  382: 607 */       throw new UnsupportedOperationException();
/*  383:     */     }
/*  384:     */   }
/*  385:     */   
/*  386:     */   private static class UnmodifiableSetMultimap<K, V>
/*  387:     */     extends Multimaps.UnmodifiableMultimap<K, V>
/*  388:     */     implements SetMultimap<K, V>
/*  389:     */   {
/*  390:     */     private static final long serialVersionUID = 0L;
/*  391:     */     
/*  392:     */     UnmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*  393:     */     {
/*  394: 615 */       super();
/*  395:     */     }
/*  396:     */     
/*  397:     */     public SetMultimap<K, V> delegate()
/*  398:     */     {
/*  399: 618 */       return (SetMultimap)super.delegate();
/*  400:     */     }
/*  401:     */     
/*  402:     */     public Set<V> get(K key)
/*  403:     */     {
/*  404: 625 */       return Collections.unmodifiableSet(delegate().get(key));
/*  405:     */     }
/*  406:     */     
/*  407:     */     public Set<Map.Entry<K, V>> entries()
/*  408:     */     {
/*  409: 628 */       return Maps.unmodifiableEntrySet(delegate().entries());
/*  410:     */     }
/*  411:     */     
/*  412:     */     public Set<V> removeAll(Object key)
/*  413:     */     {
/*  414: 631 */       throw new UnsupportedOperationException();
/*  415:     */     }
/*  416:     */     
/*  417:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  418:     */     {
/*  419: 635 */       throw new UnsupportedOperationException();
/*  420:     */     }
/*  421:     */   }
/*  422:     */   
/*  423:     */   private static class UnmodifiableSortedSetMultimap<K, V>
/*  424:     */     extends Multimaps.UnmodifiableSetMultimap<K, V>
/*  425:     */     implements SortedSetMultimap<K, V>
/*  426:     */   {
/*  427:     */     private static final long serialVersionUID = 0L;
/*  428:     */     
/*  429:     */     UnmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*  430:     */     {
/*  431: 643 */       super();
/*  432:     */     }
/*  433:     */     
/*  434:     */     public SortedSetMultimap<K, V> delegate()
/*  435:     */     {
/*  436: 646 */       return (SortedSetMultimap)super.delegate();
/*  437:     */     }
/*  438:     */     
/*  439:     */     public SortedSet<V> get(K key)
/*  440:     */     {
/*  441: 649 */       return Collections.unmodifiableSortedSet(delegate().get(key));
/*  442:     */     }
/*  443:     */     
/*  444:     */     public SortedSet<V> removeAll(Object key)
/*  445:     */     {
/*  446: 652 */       throw new UnsupportedOperationException();
/*  447:     */     }
/*  448:     */     
/*  449:     */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/*  450:     */     {
/*  451: 656 */       throw new UnsupportedOperationException();
/*  452:     */     }
/*  453:     */     
/*  454:     */     public Comparator<? super V> valueComparator()
/*  455:     */     {
/*  456: 660 */       return delegate().valueComparator();
/*  457:     */     }
/*  458:     */   }
/*  459:     */   
/*  460:     */   public static <K, V> SetMultimap<K, V> synchronizedSetMultimap(SetMultimap<K, V> multimap)
/*  461:     */   {
/*  462: 679 */     return Synchronized.setMultimap(multimap, null);
/*  463:     */   }
/*  464:     */   
/*  465:     */   public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*  466:     */   {
/*  467: 702 */     if (((delegate instanceof UnmodifiableSetMultimap)) || ((delegate instanceof ImmutableSetMultimap))) {
/*  468: 704 */       return delegate;
/*  469:     */     }
/*  470: 706 */     return new UnmodifiableSetMultimap(delegate);
/*  471:     */   }
/*  472:     */   
/*  473:     */   @Deprecated
/*  474:     */   public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(ImmutableSetMultimap<K, V> delegate)
/*  475:     */   {
/*  476: 717 */     return (SetMultimap)Preconditions.checkNotNull(delegate);
/*  477:     */   }
/*  478:     */   
/*  479:     */   public static <K, V> SortedSetMultimap<K, V> synchronizedSortedSetMultimap(SortedSetMultimap<K, V> multimap)
/*  480:     */   {
/*  481: 734 */     return Synchronized.sortedSetMultimap(multimap, null);
/*  482:     */   }
/*  483:     */   
/*  484:     */   public static <K, V> SortedSetMultimap<K, V> unmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*  485:     */   {
/*  486: 757 */     if ((delegate instanceof UnmodifiableSortedSetMultimap)) {
/*  487: 758 */       return delegate;
/*  488:     */     }
/*  489: 760 */     return new UnmodifiableSortedSetMultimap(delegate);
/*  490:     */   }
/*  491:     */   
/*  492:     */   public static <K, V> ListMultimap<K, V> synchronizedListMultimap(ListMultimap<K, V> multimap)
/*  493:     */   {
/*  494: 774 */     return Synchronized.listMultimap(multimap, null);
/*  495:     */   }
/*  496:     */   
/*  497:     */   public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ListMultimap<K, V> delegate)
/*  498:     */   {
/*  499: 797 */     if (((delegate instanceof UnmodifiableListMultimap)) || ((delegate instanceof ImmutableListMultimap))) {
/*  500: 799 */       return delegate;
/*  501:     */     }
/*  502: 801 */     return new UnmodifiableListMultimap(delegate);
/*  503:     */   }
/*  504:     */   
/*  505:     */   @Deprecated
/*  506:     */   public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ImmutableListMultimap<K, V> delegate)
/*  507:     */   {
/*  508: 812 */     return (ListMultimap)Preconditions.checkNotNull(delegate);
/*  509:     */   }
/*  510:     */   
/*  511:     */   private static <V> Collection<V> unmodifiableValueCollection(Collection<V> collection)
/*  512:     */   {
/*  513: 825 */     if ((collection instanceof SortedSet)) {
/*  514: 826 */       return Collections.unmodifiableSortedSet((SortedSet)collection);
/*  515:     */     }
/*  516: 827 */     if ((collection instanceof Set)) {
/*  517: 828 */       return Collections.unmodifiableSet((Set)collection);
/*  518:     */     }
/*  519: 829 */     if ((collection instanceof List)) {
/*  520: 830 */       return Collections.unmodifiableList((List)collection);
/*  521:     */     }
/*  522: 832 */     return Collections.unmodifiableCollection(collection);
/*  523:     */   }
/*  524:     */   
/*  525:     */   private static <K, V> Collection<Map.Entry<K, V>> unmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*  526:     */   {
/*  527: 846 */     if ((entries instanceof Set)) {
/*  528: 847 */       return Maps.unmodifiableEntrySet((Set)entries);
/*  529:     */     }
/*  530: 849 */     return new Maps.UnmodifiableEntries(Collections.unmodifiableCollection(entries));
/*  531:     */   }
/*  532:     */   
/*  533:     */   @Beta
/*  534:     */   public static <K, V> Map<K, List<V>> asMap(ListMultimap<K, V> multimap)
/*  535:     */   {
/*  536: 863 */     return multimap.asMap();
/*  537:     */   }
/*  538:     */   
/*  539:     */   @Beta
/*  540:     */   public static <K, V> Map<K, Set<V>> asMap(SetMultimap<K, V> multimap)
/*  541:     */   {
/*  542: 876 */     return multimap.asMap();
/*  543:     */   }
/*  544:     */   
/*  545:     */   @Beta
/*  546:     */   public static <K, V> Map<K, SortedSet<V>> asMap(SortedSetMultimap<K, V> multimap)
/*  547:     */   {
/*  548: 891 */     return multimap.asMap();
/*  549:     */   }
/*  550:     */   
/*  551:     */   @Beta
/*  552:     */   public static <K, V> Map<K, Collection<V>> asMap(Multimap<K, V> multimap)
/*  553:     */   {
/*  554: 902 */     return multimap.asMap();
/*  555:     */   }
/*  556:     */   
/*  557:     */   public static <K, V> SetMultimap<K, V> forMap(Map<K, V> map)
/*  558:     */   {
/*  559: 923 */     return new MapMultimap(map);
/*  560:     */   }
/*  561:     */   
/*  562:     */   private static class MapMultimap<K, V>
/*  563:     */     extends AbstractMultimap<K, V>
/*  564:     */     implements SetMultimap<K, V>, Serializable
/*  565:     */   {
/*  566:     */     final Map<K, V> map;
/*  567:     */     private static final long serialVersionUID = 7845222491160860175L;
/*  568:     */     
/*  569:     */     MapMultimap(Map<K, V> map)
/*  570:     */     {
/*  571: 932 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*  572:     */     }
/*  573:     */     
/*  574:     */     public int size()
/*  575:     */     {
/*  576: 937 */       return this.map.size();
/*  577:     */     }
/*  578:     */     
/*  579:     */     public boolean containsKey(Object key)
/*  580:     */     {
/*  581: 942 */       return this.map.containsKey(key);
/*  582:     */     }
/*  583:     */     
/*  584:     */     public boolean containsValue(Object value)
/*  585:     */     {
/*  586: 947 */       return this.map.containsValue(value);
/*  587:     */     }
/*  588:     */     
/*  589:     */     public boolean containsEntry(Object key, Object value)
/*  590:     */     {
/*  591: 952 */       return this.map.entrySet().contains(Maps.immutableEntry(key, value));
/*  592:     */     }
/*  593:     */     
/*  594:     */     public Set<V> get(final K key)
/*  595:     */     {
/*  596: 957 */       new Sets.ImprovedAbstractSet()
/*  597:     */       {
/*  598:     */         public Iterator<V> iterator()
/*  599:     */         {
/*  600: 959 */           new Iterator()
/*  601:     */           {
/*  602:     */             int i;
/*  603:     */             
/*  604:     */             public boolean hasNext()
/*  605:     */             {
/*  606: 964 */               return (this.i == 0) && (Multimaps.MapMultimap.this.map.containsKey(Multimaps.MapMultimap.1.this.val$key));
/*  607:     */             }
/*  608:     */             
/*  609:     */             public V next()
/*  610:     */             {
/*  611: 969 */               if (!hasNext()) {
/*  612: 970 */                 throw new NoSuchElementException();
/*  613:     */               }
/*  614: 972 */               this.i += 1;
/*  615: 973 */               return Multimaps.MapMultimap.this.map.get(Multimaps.MapMultimap.1.this.val$key);
/*  616:     */             }
/*  617:     */             
/*  618:     */             public void remove()
/*  619:     */             {
/*  620: 978 */               CollectPreconditions.checkRemove(this.i == 1);
/*  621: 979 */               this.i = -1;
/*  622: 980 */               Multimaps.MapMultimap.this.map.remove(Multimaps.MapMultimap.1.this.val$key);
/*  623:     */             }
/*  624:     */           };
/*  625:     */         }
/*  626:     */         
/*  627:     */         public int size()
/*  628:     */         {
/*  629: 986 */           return Multimaps.MapMultimap.this.map.containsKey(key) ? 1 : 0;
/*  630:     */         }
/*  631:     */       };
/*  632:     */     }
/*  633:     */     
/*  634:     */     public boolean put(K key, V value)
/*  635:     */     {
/*  636: 993 */       throw new UnsupportedOperationException();
/*  637:     */     }
/*  638:     */     
/*  639:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  640:     */     {
/*  641: 998 */       throw new UnsupportedOperationException();
/*  642:     */     }
/*  643:     */     
/*  644:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  645:     */     {
/*  646:1003 */       throw new UnsupportedOperationException();
/*  647:     */     }
/*  648:     */     
/*  649:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  650:     */     {
/*  651:1008 */       throw new UnsupportedOperationException();
/*  652:     */     }
/*  653:     */     
/*  654:     */     public boolean remove(Object key, Object value)
/*  655:     */     {
/*  656:1013 */       return this.map.entrySet().remove(Maps.immutableEntry(key, value));
/*  657:     */     }
/*  658:     */     
/*  659:     */     public Set<V> removeAll(Object key)
/*  660:     */     {
/*  661:1018 */       Set<V> values = new HashSet(2);
/*  662:1019 */       if (!this.map.containsKey(key)) {
/*  663:1020 */         return values;
/*  664:     */       }
/*  665:1022 */       values.add(this.map.remove(key));
/*  666:1023 */       return values;
/*  667:     */     }
/*  668:     */     
/*  669:     */     public void clear()
/*  670:     */     {
/*  671:1028 */       this.map.clear();
/*  672:     */     }
/*  673:     */     
/*  674:     */     public Set<K> keySet()
/*  675:     */     {
/*  676:1033 */       return this.map.keySet();
/*  677:     */     }
/*  678:     */     
/*  679:     */     public Collection<V> values()
/*  680:     */     {
/*  681:1038 */       return this.map.values();
/*  682:     */     }
/*  683:     */     
/*  684:     */     public Set<Map.Entry<K, V>> entries()
/*  685:     */     {
/*  686:1043 */       return this.map.entrySet();
/*  687:     */     }
/*  688:     */     
/*  689:     */     Iterator<Map.Entry<K, V>> entryIterator()
/*  690:     */     {
/*  691:1048 */       return this.map.entrySet().iterator();
/*  692:     */     }
/*  693:     */     
/*  694:     */     Map<K, Collection<V>> createAsMap()
/*  695:     */     {
/*  696:1053 */       return new Multimaps.AsMap(this);
/*  697:     */     }
/*  698:     */     
/*  699:     */     public int hashCode()
/*  700:     */     {
/*  701:1057 */       return this.map.hashCode();
/*  702:     */     }
/*  703:     */   }
/*  704:     */   
/*  705:     */   public static <K, V1, V2> Multimap<K, V2> transformValues(Multimap<K, V1> fromMultimap, Function<? super V1, V2> function)
/*  706:     */   {
/*  707:1109 */     Preconditions.checkNotNull(function);
/*  708:1110 */     Maps.EntryTransformer<K, V1, V2> transformer = Maps.asEntryTransformer(function);
/*  709:1111 */     return transformEntries(fromMultimap, transformer);
/*  710:     */   }
/*  711:     */   
/*  712:     */   public static <K, V1, V2> Multimap<K, V2> transformEntries(Multimap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  713:     */   {
/*  714:1172 */     return new TransformedEntriesMultimap(fromMap, transformer);
/*  715:     */   }
/*  716:     */   
/*  717:     */   private static class TransformedEntriesMultimap<K, V1, V2>
/*  718:     */     extends AbstractMultimap<K, V2>
/*  719:     */   {
/*  720:     */     final Multimap<K, V1> fromMultimap;
/*  721:     */     final Maps.EntryTransformer<? super K, ? super V1, V2> transformer;
/*  722:     */     
/*  723:     */     TransformedEntriesMultimap(Multimap<K, V1> fromMultimap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  724:     */     {
/*  725:1182 */       this.fromMultimap = ((Multimap)Preconditions.checkNotNull(fromMultimap));
/*  726:1183 */       this.transformer = ((Maps.EntryTransformer)Preconditions.checkNotNull(transformer));
/*  727:     */     }
/*  728:     */     
/*  729:     */     Collection<V2> transform(K key, Collection<V1> values)
/*  730:     */     {
/*  731:1187 */       Function<? super V1, V2> function = Maps.asValueToValueFunction(this.transformer, key);
/*  732:1189 */       if ((values instanceof List)) {
/*  733:1190 */         return Lists.transform((List)values, function);
/*  734:     */       }
/*  735:1192 */       return Collections2.transform(values, function);
/*  736:     */     }
/*  737:     */     
/*  738:     */     Map<K, Collection<V2>> createAsMap()
/*  739:     */     {
/*  740:1198 */       Maps.transformEntries(this.fromMultimap.asMap(), new Maps.EntryTransformer()
/*  741:     */       {
/*  742:     */         public Collection<V2> transformEntry(K key, Collection<V1> value)
/*  743:     */         {
/*  744:1202 */           return Multimaps.TransformedEntriesMultimap.this.transform(key, value);
/*  745:     */         }
/*  746:     */       });
/*  747:     */     }
/*  748:     */     
/*  749:     */     public void clear()
/*  750:     */     {
/*  751:1208 */       this.fromMultimap.clear();
/*  752:     */     }
/*  753:     */     
/*  754:     */     public boolean containsKey(Object key)
/*  755:     */     {
/*  756:1212 */       return this.fromMultimap.containsKey(key);
/*  757:     */     }
/*  758:     */     
/*  759:     */     Iterator<Map.Entry<K, V2>> entryIterator()
/*  760:     */     {
/*  761:1217 */       return Iterators.transform(this.fromMultimap.entries().iterator(), Maps.asEntryToEntryFunction(this.transformer));
/*  762:     */     }
/*  763:     */     
/*  764:     */     public Collection<V2> get(K key)
/*  765:     */     {
/*  766:1222 */       return transform(key, this.fromMultimap.get(key));
/*  767:     */     }
/*  768:     */     
/*  769:     */     public boolean isEmpty()
/*  770:     */     {
/*  771:1226 */       return this.fromMultimap.isEmpty();
/*  772:     */     }
/*  773:     */     
/*  774:     */     public Set<K> keySet()
/*  775:     */     {
/*  776:1230 */       return this.fromMultimap.keySet();
/*  777:     */     }
/*  778:     */     
/*  779:     */     public Multiset<K> keys()
/*  780:     */     {
/*  781:1234 */       return this.fromMultimap.keys();
/*  782:     */     }
/*  783:     */     
/*  784:     */     public boolean put(K key, V2 value)
/*  785:     */     {
/*  786:1238 */       throw new UnsupportedOperationException();
/*  787:     */     }
/*  788:     */     
/*  789:     */     public boolean putAll(K key, Iterable<? extends V2> values)
/*  790:     */     {
/*  791:1242 */       throw new UnsupportedOperationException();
/*  792:     */     }
/*  793:     */     
/*  794:     */     public boolean putAll(Multimap<? extends K, ? extends V2> multimap)
/*  795:     */     {
/*  796:1247 */       throw new UnsupportedOperationException();
/*  797:     */     }
/*  798:     */     
/*  799:     */     public boolean remove(Object key, Object value)
/*  800:     */     {
/*  801:1252 */       return get(key).remove(value);
/*  802:     */     }
/*  803:     */     
/*  804:     */     public Collection<V2> removeAll(Object key)
/*  805:     */     {
/*  806:1257 */       return transform(key, this.fromMultimap.removeAll(key));
/*  807:     */     }
/*  808:     */     
/*  809:     */     public Collection<V2> replaceValues(K key, Iterable<? extends V2> values)
/*  810:     */     {
/*  811:1262 */       throw new UnsupportedOperationException();
/*  812:     */     }
/*  813:     */     
/*  814:     */     public int size()
/*  815:     */     {
/*  816:1266 */       return this.fromMultimap.size();
/*  817:     */     }
/*  818:     */     
/*  819:     */     Collection<V2> createValues()
/*  820:     */     {
/*  821:1271 */       return Collections2.transform(this.fromMultimap.entries(), Maps.asEntryToValueFunction(this.transformer));
/*  822:     */     }
/*  823:     */   }
/*  824:     */   
/*  825:     */   public static <K, V1, V2> ListMultimap<K, V2> transformValues(ListMultimap<K, V1> fromMultimap, Function<? super V1, V2> function)
/*  826:     */   {
/*  827:1320 */     Preconditions.checkNotNull(function);
/*  828:1321 */     Maps.EntryTransformer<K, V1, V2> transformer = Maps.asEntryTransformer(function);
/*  829:1322 */     return transformEntries(fromMultimap, transformer);
/*  830:     */   }
/*  831:     */   
/*  832:     */   public static <K, V1, V2> ListMultimap<K, V2> transformEntries(ListMultimap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  833:     */   {
/*  834:1380 */     return new TransformedEntriesListMultimap(fromMap, transformer);
/*  835:     */   }
/*  836:     */   
/*  837:     */   private static final class TransformedEntriesListMultimap<K, V1, V2>
/*  838:     */     extends Multimaps.TransformedEntriesMultimap<K, V1, V2>
/*  839:     */     implements ListMultimap<K, V2>
/*  840:     */   {
/*  841:     */     TransformedEntriesListMultimap(ListMultimap<K, V1> fromMultimap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  842:     */     {
/*  843:1389 */       super(transformer);
/*  844:     */     }
/*  845:     */     
/*  846:     */     List<V2> transform(K key, Collection<V1> values)
/*  847:     */     {
/*  848:1393 */       return Lists.transform((List)values, Maps.asValueToValueFunction(this.transformer, key));
/*  849:     */     }
/*  850:     */     
/*  851:     */     public List<V2> get(K key)
/*  852:     */     {
/*  853:1397 */       return transform(key, this.fromMultimap.get(key));
/*  854:     */     }
/*  855:     */     
/*  856:     */     public List<V2> removeAll(Object key)
/*  857:     */     {
/*  858:1402 */       return transform(key, this.fromMultimap.removeAll(key));
/*  859:     */     }
/*  860:     */     
/*  861:     */     public List<V2> replaceValues(K key, Iterable<? extends V2> values)
/*  862:     */     {
/*  863:1407 */       throw new UnsupportedOperationException();
/*  864:     */     }
/*  865:     */   }
/*  866:     */   
/*  867:     */   public static <K, V> ImmutableListMultimap<K, V> index(Iterable<V> values, Function<? super V, K> keyFunction)
/*  868:     */   {
/*  869:1455 */     return index(values.iterator(), keyFunction);
/*  870:     */   }
/*  871:     */   
/*  872:     */   public static <K, V> ImmutableListMultimap<K, V> index(Iterator<V> values, Function<? super V, K> keyFunction)
/*  873:     */   {
/*  874:1503 */     Preconditions.checkNotNull(keyFunction);
/*  875:1504 */     ImmutableListMultimap.Builder<K, V> builder = ImmutableListMultimap.builder();
/*  876:1506 */     while (values.hasNext())
/*  877:     */     {
/*  878:1507 */       V value = values.next();
/*  879:1508 */       Preconditions.checkNotNull(value, values);
/*  880:1509 */       builder.put(keyFunction.apply(value), value);
/*  881:     */     }
/*  882:1511 */     return builder.build();
/*  883:     */   }
/*  884:     */   
/*  885:     */   static class Keys<K, V>
/*  886:     */     extends AbstractMultiset<K>
/*  887:     */   {
/*  888:     */     final Multimap<K, V> multimap;
/*  889:     */     
/*  890:     */     Keys(Multimap<K, V> multimap)
/*  891:     */     {
/*  892:1518 */       this.multimap = multimap;
/*  893:     */     }
/*  894:     */     
/*  895:     */     Iterator<Multiset.Entry<K>> entryIterator()
/*  896:     */     {
/*  897:1522 */       new TransformedIterator(this.multimap.asMap().entrySet().iterator())
/*  898:     */       {
/*  899:     */         Multiset.Entry<K> transform(final Map.Entry<K, Collection<V>> backingEntry)
/*  900:     */         {
/*  901:1527 */           new Multisets.AbstractEntry()
/*  902:     */           {
/*  903:     */             public K getElement()
/*  904:     */             {
/*  905:1530 */               return backingEntry.getKey();
/*  906:     */             }
/*  907:     */             
/*  908:     */             public int getCount()
/*  909:     */             {
/*  910:1535 */               return ((Collection)backingEntry.getValue()).size();
/*  911:     */             }
/*  912:     */           };
/*  913:     */         }
/*  914:     */       };
/*  915:     */     }
/*  916:     */     
/*  917:     */     int distinctElements()
/*  918:     */     {
/*  919:1543 */       return this.multimap.asMap().size();
/*  920:     */     }
/*  921:     */     
/*  922:     */     Set<Multiset.Entry<K>> createEntrySet()
/*  923:     */     {
/*  924:1547 */       return new KeysEntrySet();
/*  925:     */     }
/*  926:     */     
/*  927:     */     class KeysEntrySet
/*  928:     */       extends Multisets.EntrySet<K>
/*  929:     */     {
/*  930:     */       KeysEntrySet() {}
/*  931:     */       
/*  932:     */       Multiset<K> multiset()
/*  933:     */       {
/*  934:1552 */         return Multimaps.Keys.this;
/*  935:     */       }
/*  936:     */       
/*  937:     */       public Iterator<Multiset.Entry<K>> iterator()
/*  938:     */       {
/*  939:1556 */         return Multimaps.Keys.this.entryIterator();
/*  940:     */       }
/*  941:     */       
/*  942:     */       public int size()
/*  943:     */       {
/*  944:1560 */         return Multimaps.Keys.this.distinctElements();
/*  945:     */       }
/*  946:     */       
/*  947:     */       public boolean isEmpty()
/*  948:     */       {
/*  949:1564 */         return Multimaps.Keys.this.multimap.isEmpty();
/*  950:     */       }
/*  951:     */       
/*  952:     */       public boolean contains(@Nullable Object o)
/*  953:     */       {
/*  954:1568 */         if ((o instanceof Multiset.Entry))
/*  955:     */         {
/*  956:1569 */           Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  957:1570 */           Collection<V> collection = (Collection)Multimaps.Keys.this.multimap.asMap().get(entry.getElement());
/*  958:1571 */           return (collection != null) && (collection.size() == entry.getCount());
/*  959:     */         }
/*  960:1573 */         return false;
/*  961:     */       }
/*  962:     */       
/*  963:     */       public boolean remove(@Nullable Object o)
/*  964:     */       {
/*  965:1577 */         if ((o instanceof Multiset.Entry))
/*  966:     */         {
/*  967:1578 */           Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  968:1579 */           Collection<V> collection = (Collection)Multimaps.Keys.this.multimap.asMap().get(entry.getElement());
/*  969:1580 */           if ((collection != null) && (collection.size() == entry.getCount()))
/*  970:     */           {
/*  971:1581 */             collection.clear();
/*  972:1582 */             return true;
/*  973:     */           }
/*  974:     */         }
/*  975:1585 */         return false;
/*  976:     */       }
/*  977:     */     }
/*  978:     */     
/*  979:     */     public boolean contains(@Nullable Object element)
/*  980:     */     {
/*  981:1590 */       return this.multimap.containsKey(element);
/*  982:     */     }
/*  983:     */     
/*  984:     */     public Iterator<K> iterator()
/*  985:     */     {
/*  986:1594 */       return Maps.keyIterator(this.multimap.entries().iterator());
/*  987:     */     }
/*  988:     */     
/*  989:     */     public int count(@Nullable Object element)
/*  990:     */     {
/*  991:1598 */       Collection<V> values = (Collection)Maps.safeGet(this.multimap.asMap(), element);
/*  992:1599 */       return values == null ? 0 : values.size();
/*  993:     */     }
/*  994:     */     
/*  995:     */     public int remove(@Nullable Object element, int occurrences)
/*  996:     */     {
/*  997:1603 */       CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/*  998:1604 */       if (occurrences == 0) {
/*  999:1605 */         return count(element);
/* 1000:     */       }
/* 1001:1608 */       Collection<V> values = (Collection)Maps.safeGet(this.multimap.asMap(), element);
/* 1002:1610 */       if (values == null) {
/* 1003:1611 */         return 0;
/* 1004:     */       }
/* 1005:1614 */       int oldCount = values.size();
/* 1006:1615 */       if (occurrences >= oldCount)
/* 1007:     */       {
/* 1008:1616 */         values.clear();
/* 1009:     */       }
/* 1010:     */       else
/* 1011:     */       {
/* 1012:1618 */         Iterator<V> iterator = values.iterator();
/* 1013:1619 */         for (int i = 0; i < occurrences; i++)
/* 1014:     */         {
/* 1015:1620 */           iterator.next();
/* 1016:1621 */           iterator.remove();
/* 1017:     */         }
/* 1018:     */       }
/* 1019:1624 */       return oldCount;
/* 1020:     */     }
/* 1021:     */     
/* 1022:     */     public void clear()
/* 1023:     */     {
/* 1024:1628 */       this.multimap.clear();
/* 1025:     */     }
/* 1026:     */     
/* 1027:     */     public Set<K> elementSet()
/* 1028:     */     {
/* 1029:1632 */       return this.multimap.keySet();
/* 1030:     */     }
/* 1031:     */   }
/* 1032:     */   
/* 1033:     */   static abstract class Entries<K, V>
/* 1034:     */     extends AbstractCollection<Map.Entry<K, V>>
/* 1035:     */   {
/* 1036:     */     abstract Multimap<K, V> multimap();
/* 1037:     */     
/* 1038:     */     public int size()
/* 1039:     */     {
/* 1040:1644 */       return multimap().size();
/* 1041:     */     }
/* 1042:     */     
/* 1043:     */     public boolean contains(@Nullable Object o)
/* 1044:     */     {
/* 1045:1648 */       if ((o instanceof Map.Entry))
/* 1046:     */       {
/* 1047:1649 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1048:1650 */         return multimap().containsEntry(entry.getKey(), entry.getValue());
/* 1049:     */       }
/* 1050:1652 */       return false;
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     public boolean remove(@Nullable Object o)
/* 1054:     */     {
/* 1055:1656 */       if ((o instanceof Map.Entry))
/* 1056:     */       {
/* 1057:1657 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1058:1658 */         return multimap().remove(entry.getKey(), entry.getValue());
/* 1059:     */       }
/* 1060:1660 */       return false;
/* 1061:     */     }
/* 1062:     */     
/* 1063:     */     public void clear()
/* 1064:     */     {
/* 1065:1664 */       multimap().clear();
/* 1066:     */     }
/* 1067:     */   }
/* 1068:     */   
/* 1069:     */   static final class AsMap<K, V>
/* 1070:     */     extends Maps.ImprovedAbstractMap<K, Collection<V>>
/* 1071:     */   {
/* 1072:     */     private final Multimap<K, V> multimap;
/* 1073:     */     
/* 1074:     */     AsMap(Multimap<K, V> multimap)
/* 1075:     */     {
/* 1076:1676 */       this.multimap = ((Multimap)Preconditions.checkNotNull(multimap));
/* 1077:     */     }
/* 1078:     */     
/* 1079:     */     public int size()
/* 1080:     */     {
/* 1081:1680 */       return this.multimap.keySet().size();
/* 1082:     */     }
/* 1083:     */     
/* 1084:     */     protected Set<Map.Entry<K, Collection<V>>> createEntrySet()
/* 1085:     */     {
/* 1086:1684 */       return new EntrySet();
/* 1087:     */     }
/* 1088:     */     
/* 1089:     */     void removeValuesForKey(Object key)
/* 1090:     */     {
/* 1091:1688 */       this.multimap.keySet().remove(key);
/* 1092:     */     }
/* 1093:     */     
/* 1094:     */     class EntrySet
/* 1095:     */       extends Maps.EntrySet<K, Collection<V>>
/* 1096:     */     {
/* 1097:     */       EntrySet() {}
/* 1098:     */       
/* 1099:     */       Map<K, Collection<V>> map()
/* 1100:     */       {
/* 1101:1693 */         return Multimaps.AsMap.this;
/* 1102:     */       }
/* 1103:     */       
/* 1104:     */       public Iterator<Map.Entry<K, Collection<V>>> iterator()
/* 1105:     */       {
/* 1106:1697 */         Maps.asMapEntryIterator(Multimaps.AsMap.this.multimap.keySet(), new Function()
/* 1107:     */         {
/* 1108:     */           public Collection<V> apply(K key)
/* 1109:     */           {
/* 1110:1700 */             return Multimaps.AsMap.this.multimap.get(key);
/* 1111:     */           }
/* 1112:     */         });
/* 1113:     */       }
/* 1114:     */       
/* 1115:     */       public boolean remove(Object o)
/* 1116:     */       {
/* 1117:1706 */         if (!contains(o)) {
/* 1118:1707 */           return false;
/* 1119:     */         }
/* 1120:1709 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1121:1710 */         Multimaps.AsMap.this.removeValuesForKey(entry.getKey());
/* 1122:1711 */         return true;
/* 1123:     */       }
/* 1124:     */     }
/* 1125:     */     
/* 1126:     */     public Collection<V> get(Object key)
/* 1127:     */     {
/* 1128:1717 */       return containsKey(key) ? this.multimap.get(key) : null;
/* 1129:     */     }
/* 1130:     */     
/* 1131:     */     public Collection<V> remove(Object key)
/* 1132:     */     {
/* 1133:1721 */       return containsKey(key) ? this.multimap.removeAll(key) : null;
/* 1134:     */     }
/* 1135:     */     
/* 1136:     */     public Set<K> keySet()
/* 1137:     */     {
/* 1138:1725 */       return this.multimap.keySet();
/* 1139:     */     }
/* 1140:     */     
/* 1141:     */     public boolean isEmpty()
/* 1142:     */     {
/* 1143:1729 */       return this.multimap.isEmpty();
/* 1144:     */     }
/* 1145:     */     
/* 1146:     */     public boolean containsKey(Object key)
/* 1147:     */     {
/* 1148:1733 */       return this.multimap.containsKey(key);
/* 1149:     */     }
/* 1150:     */     
/* 1151:     */     public void clear()
/* 1152:     */     {
/* 1153:1737 */       this.multimap.clear();
/* 1154:     */     }
/* 1155:     */   }
/* 1156:     */   
/* 1157:     */   public static <K, V> Multimap<K, V> filterKeys(Multimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1158:     */   {
/* 1159:1773 */     if ((unfiltered instanceof SetMultimap)) {
/* 1160:1774 */       return filterKeys((SetMultimap)unfiltered, keyPredicate);
/* 1161:     */     }
/* 1162:1775 */     if ((unfiltered instanceof ListMultimap)) {
/* 1163:1776 */       return filterKeys((ListMultimap)unfiltered, keyPredicate);
/* 1164:     */     }
/* 1165:1777 */     if ((unfiltered instanceof FilteredKeyMultimap))
/* 1166:     */     {
/* 1167:1778 */       FilteredKeyMultimap<K, V> prev = (FilteredKeyMultimap)unfiltered;
/* 1168:1779 */       return new FilteredKeyMultimap(prev.unfiltered, Predicates.and(prev.keyPredicate, keyPredicate));
/* 1169:     */     }
/* 1170:1781 */     if ((unfiltered instanceof FilteredMultimap))
/* 1171:     */     {
/* 1172:1782 */       FilteredMultimap<K, V> prev = (FilteredMultimap)unfiltered;
/* 1173:1783 */       return filterFiltered(prev, Maps.keyPredicateOnEntries(keyPredicate));
/* 1174:     */     }
/* 1175:1785 */     return new FilteredKeyMultimap(unfiltered, keyPredicate);
/* 1176:     */   }
/* 1177:     */   
/* 1178:     */   public static <K, V> SetMultimap<K, V> filterKeys(SetMultimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1179:     */   {
/* 1180:1821 */     if ((unfiltered instanceof FilteredKeySetMultimap))
/* 1181:     */     {
/* 1182:1822 */       FilteredKeySetMultimap<K, V> prev = (FilteredKeySetMultimap)unfiltered;
/* 1183:1823 */       return new FilteredKeySetMultimap(prev.unfiltered(), Predicates.and(prev.keyPredicate, keyPredicate));
/* 1184:     */     }
/* 1185:1825 */     if ((unfiltered instanceof FilteredSetMultimap))
/* 1186:     */     {
/* 1187:1826 */       FilteredSetMultimap<K, V> prev = (FilteredSetMultimap)unfiltered;
/* 1188:1827 */       return filterFiltered(prev, Maps.keyPredicateOnEntries(keyPredicate));
/* 1189:     */     }
/* 1190:1829 */     return new FilteredKeySetMultimap(unfiltered, keyPredicate);
/* 1191:     */   }
/* 1192:     */   
/* 1193:     */   public static <K, V> ListMultimap<K, V> filterKeys(ListMultimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1194:     */   {
/* 1195:1865 */     if ((unfiltered instanceof FilteredKeyListMultimap))
/* 1196:     */     {
/* 1197:1866 */       FilteredKeyListMultimap<K, V> prev = (FilteredKeyListMultimap)unfiltered;
/* 1198:1867 */       return new FilteredKeyListMultimap(prev.unfiltered(), Predicates.and(prev.keyPredicate, keyPredicate));
/* 1199:     */     }
/* 1200:1870 */     return new FilteredKeyListMultimap(unfiltered, keyPredicate);
/* 1201:     */   }
/* 1202:     */   
/* 1203:     */   public static <K, V> Multimap<K, V> filterValues(Multimap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1204:     */   {
/* 1205:1906 */     return filterEntries(unfiltered, Maps.valuePredicateOnEntries(valuePredicate));
/* 1206:     */   }
/* 1207:     */   
/* 1208:     */   public static <K, V> SetMultimap<K, V> filterValues(SetMultimap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1209:     */   {
/* 1210:1941 */     return filterEntries(unfiltered, Maps.valuePredicateOnEntries(valuePredicate));
/* 1211:     */   }
/* 1212:     */   
/* 1213:     */   public static <K, V> Multimap<K, V> filterEntries(Multimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1214:     */   {
/* 1215:1974 */     Preconditions.checkNotNull(entryPredicate);
/* 1216:1975 */     if ((unfiltered instanceof SetMultimap)) {
/* 1217:1976 */       return filterEntries((SetMultimap)unfiltered, entryPredicate);
/* 1218:     */     }
/* 1219:1978 */     return (unfiltered instanceof FilteredMultimap) ? filterFiltered((FilteredMultimap)unfiltered, entryPredicate) : new FilteredEntryMultimap((Multimap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1220:     */   }
/* 1221:     */   
/* 1222:     */   public static <K, V> SetMultimap<K, V> filterEntries(SetMultimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1223:     */   {
/* 1224:2013 */     Preconditions.checkNotNull(entryPredicate);
/* 1225:2014 */     return (unfiltered instanceof FilteredSetMultimap) ? filterFiltered((FilteredSetMultimap)unfiltered, entryPredicate) : new FilteredEntrySetMultimap((SetMultimap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1226:     */   }
/* 1227:     */   
/* 1228:     */   private static <K, V> Multimap<K, V> filterFiltered(FilteredMultimap<K, V> multimap, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1229:     */   {
/* 1230:2028 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(multimap.entryPredicate(), entryPredicate);
/* 1231:     */     
/* 1232:2030 */     return new FilteredEntryMultimap(multimap.unfiltered(), predicate);
/* 1233:     */   }
/* 1234:     */   
/* 1235:     */   private static <K, V> SetMultimap<K, V> filterFiltered(FilteredSetMultimap<K, V> multimap, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1236:     */   {
/* 1237:2042 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(multimap.entryPredicate(), entryPredicate);
/* 1238:     */     
/* 1239:2044 */     return new FilteredEntrySetMultimap(multimap.unfiltered(), predicate);
/* 1240:     */   }
/* 1241:     */   
/* 1242:     */   static boolean equalsImpl(Multimap<?, ?> multimap, @Nullable Object object)
/* 1243:     */   {
/* 1244:2048 */     if (object == multimap) {
/* 1245:2049 */       return true;
/* 1246:     */     }
/* 1247:2051 */     if ((object instanceof Multimap))
/* 1248:     */     {
/* 1249:2052 */       Multimap<?, ?> that = (Multimap)object;
/* 1250:2053 */       return multimap.asMap().equals(that.asMap());
/* 1251:     */     }
/* 1252:2055 */     return false;
/* 1253:     */   }
/* 1254:     */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.Multimaps
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.List;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class AllEqualOrdering
/* 10:   */   extends Ordering<Object>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:33 */   static final AllEqualOrdering INSTANCE = new AllEqualOrdering();
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   public int compare(@Nullable Object left, @Nullable Object right)
/* 17:   */   {
/* 18:37 */     return 0;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public <E> List<E> sortedCopy(Iterable<E> iterable)
/* 22:   */   {
/* 23:42 */     return Lists.newArrayList(iterable);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public <E> ImmutableList<E> immutableSortedCopy(Iterable<E> iterable)
/* 27:   */   {
/* 28:47 */     return ImmutableList.copyOf(iterable);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public <S> Ordering<S> reverse()
/* 32:   */   {
/* 33:53 */     return this;
/* 34:   */   }
/* 35:   */   
/* 36:   */   private Object readResolve()
/* 37:   */   {
/* 38:57 */     return INSTANCE;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:62 */     return "Ordering.allEqual()";
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.AllEqualOrdering
 * JD-Core Version:    0.7.0.1
 */
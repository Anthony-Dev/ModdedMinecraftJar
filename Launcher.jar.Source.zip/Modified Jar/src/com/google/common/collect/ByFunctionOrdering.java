/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Function;
/*  5:   */ import com.google.common.base.Objects;
/*  6:   */ import com.google.common.base.Preconditions;
/*  7:   */ import java.io.Serializable;
/*  8:   */ import javax.annotation.Nullable;
/*  9:   */ 
/* 10:   */ @GwtCompatible(serializable=true)
/* 11:   */ final class ByFunctionOrdering<F, T>
/* 12:   */   extends Ordering<F>
/* 13:   */   implements Serializable
/* 14:   */ {
/* 15:   */   final Function<F, ? extends T> function;
/* 16:   */   final Ordering<T> ordering;
/* 17:   */   private static final long serialVersionUID = 0L;
/* 18:   */   
/* 19:   */   ByFunctionOrdering(Function<F, ? extends T> function, Ordering<T> ordering)
/* 20:   */   {
/* 21:41 */     this.function = ((Function)Preconditions.checkNotNull(function));
/* 22:42 */     this.ordering = ((Ordering)Preconditions.checkNotNull(ordering));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int compare(F left, F right)
/* 26:   */   {
/* 27:46 */     return this.ordering.compare(this.function.apply(left), this.function.apply(right));
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean equals(@Nullable Object object)
/* 31:   */   {
/* 32:50 */     if (object == this) {
/* 33:51 */       return true;
/* 34:   */     }
/* 35:53 */     if ((object instanceof ByFunctionOrdering))
/* 36:   */     {
/* 37:54 */       ByFunctionOrdering<?, ?> that = (ByFunctionOrdering)object;
/* 38:55 */       return (this.function.equals(that.function)) && (this.ordering.equals(that.ordering));
/* 39:   */     }
/* 40:58 */     return false;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public int hashCode()
/* 44:   */   {
/* 45:62 */     return Objects.hashCode(new Object[] { this.function, this.ordering });
/* 46:   */   }
/* 47:   */   
/* 48:   */   public String toString()
/* 49:   */   {
/* 50:66 */     return this.ordering + ".onResultOf(" + this.function + ")";
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ByFunctionOrdering
 * JD-Core Version:    0.7.0.1
 */
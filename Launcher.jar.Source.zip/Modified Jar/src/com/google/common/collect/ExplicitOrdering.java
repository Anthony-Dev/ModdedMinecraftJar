/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.List;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class ExplicitOrdering<T>
/* 10:   */   extends Ordering<T>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:   */   final ImmutableMap<T, Integer> rankMap;
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   ExplicitOrdering(List<T> valuesInOrder)
/* 17:   */   {
/* 18:32 */     this(buildRankMap(valuesInOrder));
/* 19:   */   }
/* 20:   */   
/* 21:   */   ExplicitOrdering(ImmutableMap<T, Integer> rankMap)
/* 22:   */   {
/* 23:36 */     this.rankMap = rankMap;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int compare(T left, T right)
/* 27:   */   {
/* 28:40 */     return rank(left) - rank(right);
/* 29:   */   }
/* 30:   */   
/* 31:   */   private int rank(T value)
/* 32:   */   {
/* 33:44 */     Integer rank = (Integer)this.rankMap.get(value);
/* 34:45 */     if (rank == null) {
/* 35:46 */       throw new Ordering.IncomparableValueException(value);
/* 36:   */     }
/* 37:48 */     return rank.intValue();
/* 38:   */   }
/* 39:   */   
/* 40:   */   private static <T> ImmutableMap<T, Integer> buildRankMap(List<T> valuesInOrder)
/* 41:   */   {
/* 42:53 */     ImmutableMap.Builder<T, Integer> builder = ImmutableMap.builder();
/* 43:54 */     int rank = 0;
/* 44:55 */     for (T value : valuesInOrder) {
/* 45:56 */       builder.put(value, Integer.valueOf(rank++));
/* 46:   */     }
/* 47:58 */     return builder.build();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public boolean equals(@Nullable Object object)
/* 51:   */   {
/* 52:62 */     if ((object instanceof ExplicitOrdering))
/* 53:   */     {
/* 54:63 */       ExplicitOrdering<?> that = (ExplicitOrdering)object;
/* 55:64 */       return this.rankMap.equals(that.rankMap);
/* 56:   */     }
/* 57:66 */     return false;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public int hashCode()
/* 61:   */   {
/* 62:70 */     return this.rankMap.hashCode();
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String toString()
/* 66:   */   {
/* 67:74 */     return "Ordering.explicit(" + this.rankMap.keySet() + ")";
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.collect.ExplicitOrdering
 * JD-Core Version:    0.7.0.1
 */
/*  1:   */ package com.google.common.primitives;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible
/*  6:   */ final class ParseRequest
/*  7:   */ {
/*  8:   */   final String rawValue;
/*  9:   */   final int radix;
/* 10:   */   
/* 11:   */   private ParseRequest(String rawValue, int radix)
/* 12:   */   {
/* 13:28 */     this.rawValue = rawValue;
/* 14:29 */     this.radix = radix;
/* 15:   */   }
/* 16:   */   
/* 17:   */   static ParseRequest fromString(String stringValue)
/* 18:   */   {
/* 19:33 */     if (stringValue.length() == 0) {
/* 20:34 */       throw new NumberFormatException("empty string");
/* 21:   */     }
/* 22:40 */     char firstChar = stringValue.charAt(0);
/* 23:   */     int radix;
/* 24:   */     String rawValue;
/* 25:   */     int radix;
/* 26:41 */     if ((stringValue.startsWith("0x")) || (stringValue.startsWith("0X")))
/* 27:   */     {
/* 28:42 */       String rawValue = stringValue.substring(2);
/* 29:43 */       radix = 16;
/* 30:   */     }
/* 31:   */     else
/* 32:   */     {
/* 33:   */       int radix;
/* 34:44 */       if (firstChar == '#')
/* 35:   */       {
/* 36:45 */         String rawValue = stringValue.substring(1);
/* 37:46 */         radix = 16;
/* 38:   */       }
/* 39:   */       else
/* 40:   */       {
/* 41:   */         int radix;
/* 42:47 */         if ((firstChar == '0') && (stringValue.length() > 1))
/* 43:   */         {
/* 44:48 */           String rawValue = stringValue.substring(1);
/* 45:49 */           radix = 8;
/* 46:   */         }
/* 47:   */         else
/* 48:   */         {
/* 49:51 */           rawValue = stringValue;
/* 50:52 */           radix = 10;
/* 51:   */         }
/* 52:   */       }
/* 53:   */     }
/* 54:55 */     return new ParseRequest(rawValue, radix);
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.ParseRequest
 * JD-Core Version:    0.7.0.1
 */
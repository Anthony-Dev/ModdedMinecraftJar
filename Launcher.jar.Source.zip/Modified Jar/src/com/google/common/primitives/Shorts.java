/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ 
/*  16:    */ @GwtCompatible(emulated=true)
/*  17:    */ public final class Shorts
/*  18:    */ {
/*  19:    */   public static final int BYTES = 2;
/*  20:    */   public static final short MAX_POWER_OF_TWO = 16384;
/*  21:    */   
/*  22:    */   public static int hashCode(short value)
/*  23:    */   {
/*  24: 74 */     return value;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static short checkedCast(long value)
/*  28:    */   {
/*  29: 87 */     short result = (short)(int)value;
/*  30: 88 */     if (result != value) {
/*  31: 90 */       throw new IllegalArgumentException("Out of range: " + value);
/*  32:    */     }
/*  33: 92 */     return result;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static short saturatedCast(long value)
/*  37:    */   {
/*  38:104 */     if (value > 32767L) {
/*  39:105 */       return 32767;
/*  40:    */     }
/*  41:107 */     if (value < -32768L) {
/*  42:108 */       return -32768;
/*  43:    */     }
/*  44:110 */     return (short)(int)value;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static int compare(short a, short b)
/*  48:    */   {
/*  49:126 */     return a - b;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static boolean contains(short[] array, short target)
/*  53:    */   {
/*  54:139 */     for (short value : array) {
/*  55:140 */       if (value == target) {
/*  56:141 */         return true;
/*  57:    */       }
/*  58:    */     }
/*  59:144 */     return false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static int indexOf(short[] array, short target)
/*  63:    */   {
/*  64:157 */     return indexOf(array, target, 0, array.length);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static int indexOf(short[] array, short target, int start, int end)
/*  68:    */   {
/*  69:163 */     for (int i = start; i < end; i++) {
/*  70:164 */       if (array[i] == target) {
/*  71:165 */         return i;
/*  72:    */       }
/*  73:    */     }
/*  74:168 */     return -1;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static int indexOf(short[] array, short[] target)
/*  78:    */   {
/*  79:183 */     Preconditions.checkNotNull(array, "array");
/*  80:184 */     Preconditions.checkNotNull(target, "target");
/*  81:185 */     if (target.length == 0) {
/*  82:186 */       return 0;
/*  83:    */     }
/*  84:    */     label64:
/*  85:190 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  86:    */     {
/*  87:191 */       for (int j = 0; j < target.length; j++) {
/*  88:192 */         if (array[(i + j)] != target[j]) {
/*  89:    */           break label64;
/*  90:    */         }
/*  91:    */       }
/*  92:196 */       return i;
/*  93:    */     }
/*  94:198 */     return -1;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static int lastIndexOf(short[] array, short target)
/*  98:    */   {
/*  99:211 */     return lastIndexOf(array, target, 0, array.length);
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static int lastIndexOf(short[] array, short target, int start, int end)
/* 103:    */   {
/* 104:217 */     for (int i = end - 1; i >= start; i--) {
/* 105:218 */       if (array[i] == target) {
/* 106:219 */         return i;
/* 107:    */       }
/* 108:    */     }
/* 109:222 */     return -1;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static short min(short... array)
/* 113:    */   {
/* 114:234 */     Preconditions.checkArgument(array.length > 0);
/* 115:235 */     short min = array[0];
/* 116:236 */     for (int i = 1; i < array.length; i++) {
/* 117:237 */       if (array[i] < min) {
/* 118:238 */         min = array[i];
/* 119:    */       }
/* 120:    */     }
/* 121:241 */     return min;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static short max(short... array)
/* 125:    */   {
/* 126:253 */     Preconditions.checkArgument(array.length > 0);
/* 127:254 */     short max = array[0];
/* 128:255 */     for (int i = 1; i < array.length; i++) {
/* 129:256 */       if (array[i] > max) {
/* 130:257 */         max = array[i];
/* 131:    */       }
/* 132:    */     }
/* 133:260 */     return max;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static short[] concat(short[]... arrays)
/* 137:    */   {
/* 138:273 */     int length = 0;
/* 139:274 */     for (short[] array : arrays) {
/* 140:275 */       length += array.length;
/* 141:    */     }
/* 142:277 */     short[] result = new short[length];
/* 143:278 */     int pos = 0;
/* 144:279 */     for (short[] array : arrays)
/* 145:    */     {
/* 146:280 */       System.arraycopy(array, 0, result, pos, array.length);
/* 147:281 */       pos += array.length;
/* 148:    */     }
/* 149:283 */     return result;
/* 150:    */   }
/* 151:    */   
/* 152:    */   @GwtIncompatible("doesn't work")
/* 153:    */   public static byte[] toByteArray(short value)
/* 154:    */   {
/* 155:300 */     return new byte[] { (byte)(value >> 8), (byte)value };
/* 156:    */   }
/* 157:    */   
/* 158:    */   @GwtIncompatible("doesn't work")
/* 159:    */   public static short fromByteArray(byte[] bytes)
/* 160:    */   {
/* 161:319 */     Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(2) });
/* 162:    */     
/* 163:321 */     return fromBytes(bytes[0], bytes[1]);
/* 164:    */   }
/* 165:    */   
/* 166:    */   @GwtIncompatible("doesn't work")
/* 167:    */   public static short fromBytes(byte b1, byte b2)
/* 168:    */   {
/* 169:333 */     return (short)(b1 << 8 | b2 & 0xFF);
/* 170:    */   }
/* 171:    */   
/* 172:    */   private static final class ShortConverter
/* 173:    */     extends Converter<String, Short>
/* 174:    */     implements Serializable
/* 175:    */   {
/* 176:338 */     static final ShortConverter INSTANCE = new ShortConverter();
/* 177:    */     private static final long serialVersionUID = 1L;
/* 178:    */     
/* 179:    */     protected Short doForward(String value)
/* 180:    */     {
/* 181:342 */       return Short.decode(value);
/* 182:    */     }
/* 183:    */     
/* 184:    */     protected String doBackward(Short value)
/* 185:    */     {
/* 186:347 */       return value.toString();
/* 187:    */     }
/* 188:    */     
/* 189:    */     public String toString()
/* 190:    */     {
/* 191:352 */       return "Shorts.stringConverter()";
/* 192:    */     }
/* 193:    */     
/* 194:    */     private Object readResolve()
/* 195:    */     {
/* 196:356 */       return INSTANCE;
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   @Beta
/* 201:    */   public static Converter<String, Short> stringConverter()
/* 202:    */   {
/* 203:369 */     return ShortConverter.INSTANCE;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static short[] ensureCapacity(short[] array, int minLength, int padding)
/* 207:    */   {
/* 208:390 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 209:391 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 210:392 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 211:    */   }
/* 212:    */   
/* 213:    */   private static short[] copyOf(short[] original, int length)
/* 214:    */   {
/* 215:399 */     short[] copy = new short[length];
/* 216:400 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 217:401 */     return copy;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static String join(String separator, short... array)
/* 221:    */   {
/* 222:414 */     Preconditions.checkNotNull(separator);
/* 223:415 */     if (array.length == 0) {
/* 224:416 */       return "";
/* 225:    */     }
/* 226:420 */     StringBuilder builder = new StringBuilder(array.length * 6);
/* 227:421 */     builder.append(array[0]);
/* 228:422 */     for (int i = 1; i < array.length; i++) {
/* 229:423 */       builder.append(separator).append(array[i]);
/* 230:    */     }
/* 231:425 */     return builder.toString();
/* 232:    */   }
/* 233:    */   
/* 234:    */   public static Comparator<short[]> lexicographicalComparator()
/* 235:    */   {
/* 236:445 */     return LexicographicalComparator.INSTANCE;
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static enum LexicographicalComparator
/* 240:    */     implements Comparator<short[]>
/* 241:    */   {
/* 242:449 */     INSTANCE;
/* 243:    */     
/* 244:    */     private LexicographicalComparator() {}
/* 245:    */     
/* 246:    */     public int compare(short[] left, short[] right)
/* 247:    */     {
/* 248:453 */       int minLength = Math.min(left.length, right.length);
/* 249:454 */       for (int i = 0; i < minLength; i++)
/* 250:    */       {
/* 251:455 */         int result = Shorts.compare(left[i], right[i]);
/* 252:456 */         if (result != 0) {
/* 253:457 */           return result;
/* 254:    */         }
/* 255:    */       }
/* 256:460 */       return left.length - right.length;
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   public static short[] toArray(Collection<? extends Number> collection)
/* 261:    */   {
/* 262:480 */     if ((collection instanceof ShortArrayAsList)) {
/* 263:481 */       return ((ShortArrayAsList)collection).toShortArray();
/* 264:    */     }
/* 265:484 */     Object[] boxedArray = collection.toArray();
/* 266:485 */     int len = boxedArray.length;
/* 267:486 */     short[] array = new short[len];
/* 268:487 */     for (int i = 0; i < len; i++) {
/* 269:489 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).shortValue();
/* 270:    */     }
/* 271:491 */     return array;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static List<Short> asList(short... backingArray)
/* 275:    */   {
/* 276:509 */     if (backingArray.length == 0) {
/* 277:510 */       return Collections.emptyList();
/* 278:    */     }
/* 279:512 */     return new ShortArrayAsList(backingArray);
/* 280:    */   }
/* 281:    */   
/* 282:    */   @GwtCompatible
/* 283:    */   private static class ShortArrayAsList
/* 284:    */     extends AbstractList<Short>
/* 285:    */     implements RandomAccess, Serializable
/* 286:    */   {
/* 287:    */     final short[] array;
/* 288:    */     final int start;
/* 289:    */     final int end;
/* 290:    */     private static final long serialVersionUID = 0L;
/* 291:    */     
/* 292:    */     ShortArrayAsList(short[] array)
/* 293:    */     {
/* 294:523 */       this(array, 0, array.length);
/* 295:    */     }
/* 296:    */     
/* 297:    */     ShortArrayAsList(short[] array, int start, int end)
/* 298:    */     {
/* 299:527 */       this.array = array;
/* 300:528 */       this.start = start;
/* 301:529 */       this.end = end;
/* 302:    */     }
/* 303:    */     
/* 304:    */     public int size()
/* 305:    */     {
/* 306:533 */       return this.end - this.start;
/* 307:    */     }
/* 308:    */     
/* 309:    */     public boolean isEmpty()
/* 310:    */     {
/* 311:537 */       return false;
/* 312:    */     }
/* 313:    */     
/* 314:    */     public Short get(int index)
/* 315:    */     {
/* 316:541 */       Preconditions.checkElementIndex(index, size());
/* 317:542 */       return Short.valueOf(this.array[(this.start + index)]);
/* 318:    */     }
/* 319:    */     
/* 320:    */     public boolean contains(Object target)
/* 321:    */     {
/* 322:547 */       return ((target instanceof Short)) && (Shorts.indexOf(this.array, ((Short)target).shortValue(), this.start, this.end) != -1);
/* 323:    */     }
/* 324:    */     
/* 325:    */     public int indexOf(Object target)
/* 326:    */     {
/* 327:553 */       if ((target instanceof Short))
/* 328:    */       {
/* 329:554 */         int i = Shorts.indexOf(this.array, ((Short)target).shortValue(), this.start, this.end);
/* 330:555 */         if (i >= 0) {
/* 331:556 */           return i - this.start;
/* 332:    */         }
/* 333:    */       }
/* 334:559 */       return -1;
/* 335:    */     }
/* 336:    */     
/* 337:    */     public int lastIndexOf(Object target)
/* 338:    */     {
/* 339:564 */       if ((target instanceof Short))
/* 340:    */       {
/* 341:565 */         int i = Shorts.lastIndexOf(this.array, ((Short)target).shortValue(), this.start, this.end);
/* 342:566 */         if (i >= 0) {
/* 343:567 */           return i - this.start;
/* 344:    */         }
/* 345:    */       }
/* 346:570 */       return -1;
/* 347:    */     }
/* 348:    */     
/* 349:    */     public Short set(int index, Short element)
/* 350:    */     {
/* 351:574 */       Preconditions.checkElementIndex(index, size());
/* 352:575 */       short oldValue = this.array[(this.start + index)];
/* 353:    */       
/* 354:577 */       this.array[(this.start + index)] = ((Short)Preconditions.checkNotNull(element)).shortValue();
/* 355:578 */       return Short.valueOf(oldValue);
/* 356:    */     }
/* 357:    */     
/* 358:    */     public List<Short> subList(int fromIndex, int toIndex)
/* 359:    */     {
/* 360:582 */       int size = size();
/* 361:583 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 362:584 */       if (fromIndex == toIndex) {
/* 363:585 */         return Collections.emptyList();
/* 364:    */       }
/* 365:587 */       return new ShortArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 366:    */     }
/* 367:    */     
/* 368:    */     public boolean equals(Object object)
/* 369:    */     {
/* 370:591 */       if (object == this) {
/* 371:592 */         return true;
/* 372:    */       }
/* 373:594 */       if ((object instanceof ShortArrayAsList))
/* 374:    */       {
/* 375:595 */         ShortArrayAsList that = (ShortArrayAsList)object;
/* 376:596 */         int size = size();
/* 377:597 */         if (that.size() != size) {
/* 378:598 */           return false;
/* 379:    */         }
/* 380:600 */         for (int i = 0; i < size; i++) {
/* 381:601 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 382:602 */             return false;
/* 383:    */           }
/* 384:    */         }
/* 385:605 */         return true;
/* 386:    */       }
/* 387:607 */       return super.equals(object);
/* 388:    */     }
/* 389:    */     
/* 390:    */     public int hashCode()
/* 391:    */     {
/* 392:611 */       int result = 1;
/* 393:612 */       for (int i = this.start; i < this.end; i++) {
/* 394:613 */         result = 31 * result + Shorts.hashCode(this.array[i]);
/* 395:    */       }
/* 396:615 */       return result;
/* 397:    */     }
/* 398:    */     
/* 399:    */     public String toString()
/* 400:    */     {
/* 401:619 */       StringBuilder builder = new StringBuilder(size() * 6);
/* 402:620 */       builder.append('[').append(this.array[this.start]);
/* 403:621 */       for (int i = this.start + 1; i < this.end; i++) {
/* 404:622 */         builder.append(", ").append(this.array[i]);
/* 405:    */       }
/* 406:624 */       return ']';
/* 407:    */     }
/* 408:    */     
/* 409:    */     short[] toShortArray()
/* 410:    */     {
/* 411:629 */       int size = size();
/* 412:630 */       short[] result = new short[size];
/* 413:631 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 414:632 */       return result;
/* 415:    */     }
/* 416:    */   }
/* 417:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Shorts
 * JD-Core Version:    0.7.0.1
 */
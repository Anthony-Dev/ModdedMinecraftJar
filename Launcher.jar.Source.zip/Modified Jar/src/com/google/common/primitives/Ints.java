/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.Comparator;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.RandomAccess;
/*  16:    */ import javax.annotation.CheckForNull;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ public final class Ints
/*  20:    */ {
/*  21:    */   public static final int BYTES = 4;
/*  22:    */   public static final int MAX_POWER_OF_TWO = 1073741824;
/*  23:    */   
/*  24:    */   public static int hashCode(int value)
/*  25:    */   {
/*  26: 76 */     return value;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static int checkedCast(long value)
/*  30:    */   {
/*  31: 88 */     int result = (int)value;
/*  32: 89 */     if (result != value) {
/*  33: 91 */       throw new IllegalArgumentException("Out of range: " + value);
/*  34:    */     }
/*  35: 93 */     return result;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static int saturatedCast(long value)
/*  39:    */   {
/*  40:105 */     if (value > 2147483647L) {
/*  41:106 */       return 2147483647;
/*  42:    */     }
/*  43:108 */     if (value < -2147483648L) {
/*  44:109 */       return -2147483648;
/*  45:    */     }
/*  46:111 */     return (int)value;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static int compare(int a, int b)
/*  50:    */   {
/*  51:127 */     return a > b ? 1 : a < b ? -1 : 0;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static boolean contains(int[] array, int target)
/*  55:    */   {
/*  56:140 */     for (int value : array) {
/*  57:141 */       if (value == target) {
/*  58:142 */         return true;
/*  59:    */       }
/*  60:    */     }
/*  61:145 */     return false;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static int indexOf(int[] array, int target)
/*  65:    */   {
/*  66:158 */     return indexOf(array, target, 0, array.length);
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static int indexOf(int[] array, int target, int start, int end)
/*  70:    */   {
/*  71:164 */     for (int i = start; i < end; i++) {
/*  72:165 */       if (array[i] == target) {
/*  73:166 */         return i;
/*  74:    */       }
/*  75:    */     }
/*  76:169 */     return -1;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static int indexOf(int[] array, int[] target)
/*  80:    */   {
/*  81:184 */     Preconditions.checkNotNull(array, "array");
/*  82:185 */     Preconditions.checkNotNull(target, "target");
/*  83:186 */     if (target.length == 0) {
/*  84:187 */       return 0;
/*  85:    */     }
/*  86:    */     label64:
/*  87:191 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  88:    */     {
/*  89:192 */       for (int j = 0; j < target.length; j++) {
/*  90:193 */         if (array[(i + j)] != target[j]) {
/*  91:    */           break label64;
/*  92:    */         }
/*  93:    */       }
/*  94:197 */       return i;
/*  95:    */     }
/*  96:199 */     return -1;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int lastIndexOf(int[] array, int target)
/* 100:    */   {
/* 101:212 */     return lastIndexOf(array, target, 0, array.length);
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static int lastIndexOf(int[] array, int target, int start, int end)
/* 105:    */   {
/* 106:218 */     for (int i = end - 1; i >= start; i--) {
/* 107:219 */       if (array[i] == target) {
/* 108:220 */         return i;
/* 109:    */       }
/* 110:    */     }
/* 111:223 */     return -1;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static int min(int... array)
/* 115:    */   {
/* 116:235 */     Preconditions.checkArgument(array.length > 0);
/* 117:236 */     int min = array[0];
/* 118:237 */     for (int i = 1; i < array.length; i++) {
/* 119:238 */       if (array[i] < min) {
/* 120:239 */         min = array[i];
/* 121:    */       }
/* 122:    */     }
/* 123:242 */     return min;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static int max(int... array)
/* 127:    */   {
/* 128:254 */     Preconditions.checkArgument(array.length > 0);
/* 129:255 */     int max = array[0];
/* 130:256 */     for (int i = 1; i < array.length; i++) {
/* 131:257 */       if (array[i] > max) {
/* 132:258 */         max = array[i];
/* 133:    */       }
/* 134:    */     }
/* 135:261 */     return max;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static int[] concat(int[]... arrays)
/* 139:    */   {
/* 140:274 */     int length = 0;
/* 141:275 */     for (int[] array : arrays) {
/* 142:276 */       length += array.length;
/* 143:    */     }
/* 144:278 */     int[] result = new int[length];
/* 145:279 */     int pos = 0;
/* 146:280 */     for (int[] array : arrays)
/* 147:    */     {
/* 148:281 */       System.arraycopy(array, 0, result, pos, array.length);
/* 149:282 */       pos += array.length;
/* 150:    */     }
/* 151:284 */     return result;
/* 152:    */   }
/* 153:    */   
/* 154:    */   @GwtIncompatible("doesn't work")
/* 155:    */   public static byte[] toByteArray(int value)
/* 156:    */   {
/* 157:300 */     return new byte[] { (byte)(value >> 24), (byte)(value >> 16), (byte)(value >> 8), (byte)value };
/* 158:    */   }
/* 159:    */   
/* 160:    */   @GwtIncompatible("doesn't work")
/* 161:    */   public static int fromByteArray(byte[] bytes)
/* 162:    */   {
/* 163:321 */     Preconditions.checkArgument(bytes.length >= 4, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(4) });
/* 164:    */     
/* 165:323 */     return fromBytes(bytes[0], bytes[1], bytes[2], bytes[3]);
/* 166:    */   }
/* 167:    */   
/* 168:    */   @GwtIncompatible("doesn't work")
/* 169:    */   public static int fromBytes(byte b1, byte b2, byte b3, byte b4)
/* 170:    */   {
/* 171:335 */     return b1 << 24 | (b2 & 0xFF) << 16 | (b3 & 0xFF) << 8 | b4 & 0xFF;
/* 172:    */   }
/* 173:    */   
/* 174:    */   private static final class IntConverter
/* 175:    */     extends Converter<String, Integer>
/* 176:    */     implements Serializable
/* 177:    */   {
/* 178:340 */     static final IntConverter INSTANCE = new IntConverter();
/* 179:    */     private static final long serialVersionUID = 1L;
/* 180:    */     
/* 181:    */     protected Integer doForward(String value)
/* 182:    */     {
/* 183:344 */       return Integer.decode(value);
/* 184:    */     }
/* 185:    */     
/* 186:    */     protected String doBackward(Integer value)
/* 187:    */     {
/* 188:349 */       return value.toString();
/* 189:    */     }
/* 190:    */     
/* 191:    */     public String toString()
/* 192:    */     {
/* 193:354 */       return "Ints.stringConverter()";
/* 194:    */     }
/* 195:    */     
/* 196:    */     private Object readResolve()
/* 197:    */     {
/* 198:358 */       return INSTANCE;
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   @Beta
/* 203:    */   public static Converter<String, Integer> stringConverter()
/* 204:    */   {
/* 205:371 */     return IntConverter.INSTANCE;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public static int[] ensureCapacity(int[] array, int minLength, int padding)
/* 209:    */   {
/* 210:392 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 211:393 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 212:394 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static int[] copyOf(int[] original, int length)
/* 216:    */   {
/* 217:401 */     int[] copy = new int[length];
/* 218:402 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 219:403 */     return copy;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static String join(String separator, int... array)
/* 223:    */   {
/* 224:416 */     Preconditions.checkNotNull(separator);
/* 225:417 */     if (array.length == 0) {
/* 226:418 */       return "";
/* 227:    */     }
/* 228:422 */     StringBuilder builder = new StringBuilder(array.length * 5);
/* 229:423 */     builder.append(array[0]);
/* 230:424 */     for (int i = 1; i < array.length; i++) {
/* 231:425 */       builder.append(separator).append(array[i]);
/* 232:    */     }
/* 233:427 */     return builder.toString();
/* 234:    */   }
/* 235:    */   
/* 236:    */   public static Comparator<int[]> lexicographicalComparator()
/* 237:    */   {
/* 238:446 */     return LexicographicalComparator.INSTANCE;
/* 239:    */   }
/* 240:    */   
/* 241:    */   private static enum LexicographicalComparator
/* 242:    */     implements Comparator<int[]>
/* 243:    */   {
/* 244:450 */     INSTANCE;
/* 245:    */     
/* 246:    */     private LexicographicalComparator() {}
/* 247:    */     
/* 248:    */     public int compare(int[] left, int[] right)
/* 249:    */     {
/* 250:454 */       int minLength = Math.min(left.length, right.length);
/* 251:455 */       for (int i = 0; i < minLength; i++)
/* 252:    */       {
/* 253:456 */         int result = Ints.compare(left[i], right[i]);
/* 254:457 */         if (result != 0) {
/* 255:458 */           return result;
/* 256:    */         }
/* 257:    */       }
/* 258:461 */       return left.length - right.length;
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   public static int[] toArray(Collection<? extends Number> collection)
/* 263:    */   {
/* 264:481 */     if ((collection instanceof IntArrayAsList)) {
/* 265:482 */       return ((IntArrayAsList)collection).toIntArray();
/* 266:    */     }
/* 267:485 */     Object[] boxedArray = collection.toArray();
/* 268:486 */     int len = boxedArray.length;
/* 269:487 */     int[] array = new int[len];
/* 270:488 */     for (int i = 0; i < len; i++) {
/* 271:490 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).intValue();
/* 272:    */     }
/* 273:492 */     return array;
/* 274:    */   }
/* 275:    */   
/* 276:    */   public static List<Integer> asList(int... backingArray)
/* 277:    */   {
/* 278:510 */     if (backingArray.length == 0) {
/* 279:511 */       return Collections.emptyList();
/* 280:    */     }
/* 281:513 */     return new IntArrayAsList(backingArray);
/* 282:    */   }
/* 283:    */   
/* 284:    */   @GwtCompatible
/* 285:    */   private static class IntArrayAsList
/* 286:    */     extends AbstractList<Integer>
/* 287:    */     implements RandomAccess, Serializable
/* 288:    */   {
/* 289:    */     final int[] array;
/* 290:    */     final int start;
/* 291:    */     final int end;
/* 292:    */     private static final long serialVersionUID = 0L;
/* 293:    */     
/* 294:    */     IntArrayAsList(int[] array)
/* 295:    */     {
/* 296:524 */       this(array, 0, array.length);
/* 297:    */     }
/* 298:    */     
/* 299:    */     IntArrayAsList(int[] array, int start, int end)
/* 300:    */     {
/* 301:528 */       this.array = array;
/* 302:529 */       this.start = start;
/* 303:530 */       this.end = end;
/* 304:    */     }
/* 305:    */     
/* 306:    */     public int size()
/* 307:    */     {
/* 308:534 */       return this.end - this.start;
/* 309:    */     }
/* 310:    */     
/* 311:    */     public boolean isEmpty()
/* 312:    */     {
/* 313:538 */       return false;
/* 314:    */     }
/* 315:    */     
/* 316:    */     public Integer get(int index)
/* 317:    */     {
/* 318:542 */       Preconditions.checkElementIndex(index, size());
/* 319:543 */       return Integer.valueOf(this.array[(this.start + index)]);
/* 320:    */     }
/* 321:    */     
/* 322:    */     public boolean contains(Object target)
/* 323:    */     {
/* 324:548 */       return ((target instanceof Integer)) && (Ints.indexOf(this.array, ((Integer)target).intValue(), this.start, this.end) != -1);
/* 325:    */     }
/* 326:    */     
/* 327:    */     public int indexOf(Object target)
/* 328:    */     {
/* 329:554 */       if ((target instanceof Integer))
/* 330:    */       {
/* 331:555 */         int i = Ints.indexOf(this.array, ((Integer)target).intValue(), this.start, this.end);
/* 332:556 */         if (i >= 0) {
/* 333:557 */           return i - this.start;
/* 334:    */         }
/* 335:    */       }
/* 336:560 */       return -1;
/* 337:    */     }
/* 338:    */     
/* 339:    */     public int lastIndexOf(Object target)
/* 340:    */     {
/* 341:565 */       if ((target instanceof Integer))
/* 342:    */       {
/* 343:566 */         int i = Ints.lastIndexOf(this.array, ((Integer)target).intValue(), this.start, this.end);
/* 344:567 */         if (i >= 0) {
/* 345:568 */           return i - this.start;
/* 346:    */         }
/* 347:    */       }
/* 348:571 */       return -1;
/* 349:    */     }
/* 350:    */     
/* 351:    */     public Integer set(int index, Integer element)
/* 352:    */     {
/* 353:575 */       Preconditions.checkElementIndex(index, size());
/* 354:576 */       int oldValue = this.array[(this.start + index)];
/* 355:    */       
/* 356:578 */       this.array[(this.start + index)] = ((Integer)Preconditions.checkNotNull(element)).intValue();
/* 357:579 */       return Integer.valueOf(oldValue);
/* 358:    */     }
/* 359:    */     
/* 360:    */     public List<Integer> subList(int fromIndex, int toIndex)
/* 361:    */     {
/* 362:583 */       int size = size();
/* 363:584 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 364:585 */       if (fromIndex == toIndex) {
/* 365:586 */         return Collections.emptyList();
/* 366:    */       }
/* 367:588 */       return new IntArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 368:    */     }
/* 369:    */     
/* 370:    */     public boolean equals(Object object)
/* 371:    */     {
/* 372:592 */       if (object == this) {
/* 373:593 */         return true;
/* 374:    */       }
/* 375:595 */       if ((object instanceof IntArrayAsList))
/* 376:    */       {
/* 377:596 */         IntArrayAsList that = (IntArrayAsList)object;
/* 378:597 */         int size = size();
/* 379:598 */         if (that.size() != size) {
/* 380:599 */           return false;
/* 381:    */         }
/* 382:601 */         for (int i = 0; i < size; i++) {
/* 383:602 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 384:603 */             return false;
/* 385:    */           }
/* 386:    */         }
/* 387:606 */         return true;
/* 388:    */       }
/* 389:608 */       return super.equals(object);
/* 390:    */     }
/* 391:    */     
/* 392:    */     public int hashCode()
/* 393:    */     {
/* 394:612 */       int result = 1;
/* 395:613 */       for (int i = this.start; i < this.end; i++) {
/* 396:614 */         result = 31 * result + Ints.hashCode(this.array[i]);
/* 397:    */       }
/* 398:616 */       return result;
/* 399:    */     }
/* 400:    */     
/* 401:    */     public String toString()
/* 402:    */     {
/* 403:620 */       StringBuilder builder = new StringBuilder(size() * 5);
/* 404:621 */       builder.append('[').append(this.array[this.start]);
/* 405:622 */       for (int i = this.start + 1; i < this.end; i++) {
/* 406:623 */         builder.append(", ").append(this.array[i]);
/* 407:    */       }
/* 408:625 */       return ']';
/* 409:    */     }
/* 410:    */     
/* 411:    */     int[] toIntArray()
/* 412:    */     {
/* 413:630 */       int size = size();
/* 414:631 */       int[] result = new int[size];
/* 415:632 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 416:633 */       return result;
/* 417:    */     }
/* 418:    */   }
/* 419:    */   
/* 420:639 */   private static final byte[] asciiDigits = new byte[''];
/* 421:    */   
/* 422:    */   static
/* 423:    */   {
/* 424:642 */     Arrays.fill(asciiDigits, (byte)-1);
/* 425:643 */     for (int i = 0; i <= 9; i++) {
/* 426:644 */       asciiDigits[(48 + i)] = ((byte)i);
/* 427:    */     }
/* 428:646 */     for (int i = 0; i <= 26; i++)
/* 429:    */     {
/* 430:647 */       asciiDigits[(65 + i)] = ((byte)(10 + i));
/* 431:648 */       asciiDigits[(97 + i)] = ((byte)(10 + i));
/* 432:    */     }
/* 433:    */   }
/* 434:    */   
/* 435:    */   private static int digit(char c)
/* 436:    */   {
/* 437:653 */     return c < '' ? asciiDigits[c] : -1;
/* 438:    */   }
/* 439:    */   
/* 440:    */   @CheckForNull
/* 441:    */   @Beta
/* 442:    */   @GwtIncompatible("TODO")
/* 443:    */   public static Integer tryParse(String string)
/* 444:    */   {
/* 445:680 */     return tryParse(string, 10);
/* 446:    */   }
/* 447:    */   
/* 448:    */   @CheckForNull
/* 449:    */   @GwtIncompatible("TODO")
/* 450:    */   static Integer tryParse(String string, int radix)
/* 451:    */   {
/* 452:708 */     if (((String)Preconditions.checkNotNull(string)).isEmpty()) {
/* 453:709 */       return null;
/* 454:    */     }
/* 455:711 */     if ((radix < 2) || (radix > 36)) {
/* 456:712 */       throw new IllegalArgumentException("radix must be between MIN_RADIX and MAX_RADIX but was " + radix);
/* 457:    */     }
/* 458:715 */     boolean negative = string.charAt(0) == '-';
/* 459:716 */     int index = negative ? 1 : 0;
/* 460:717 */     if (index == string.length()) {
/* 461:718 */       return null;
/* 462:    */     }
/* 463:720 */     int digit = digit(string.charAt(index++));
/* 464:721 */     if ((digit < 0) || (digit >= radix)) {
/* 465:722 */       return null;
/* 466:    */     }
/* 467:724 */     int accum = -digit;
/* 468:    */     
/* 469:726 */     int cap = -2147483648 / radix;
/* 470:728 */     while (index < string.length())
/* 471:    */     {
/* 472:729 */       digit = digit(string.charAt(index++));
/* 473:730 */       if ((digit < 0) || (digit >= radix) || (accum < cap)) {
/* 474:731 */         return null;
/* 475:    */       }
/* 476:733 */       accum *= radix;
/* 477:734 */       if (accum < -2147483648 + digit) {
/* 478:735 */         return null;
/* 479:    */       }
/* 480:737 */       accum -= digit;
/* 481:    */     }
/* 482:740 */     if (negative) {
/* 483:741 */       return Integer.valueOf(accum);
/* 484:    */     }
/* 485:742 */     if (accum == -2147483648) {
/* 486:743 */       return null;
/* 487:    */     }
/* 488:745 */     return Integer.valueOf(-accum);
/* 489:    */   }
/* 490:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Ints
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Converter;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.AbstractList;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.RandomAccess;
/*  14:    */ 
/*  15:    */ @GwtCompatible
/*  16:    */ public final class Longs
/*  17:    */ {
/*  18:    */   public static final int BYTES = 8;
/*  19:    */   public static final long MAX_POWER_OF_TWO = 4611686018427387904L;
/*  20:    */   
/*  21:    */   public static int hashCode(long value)
/*  22:    */   {
/*  23: 78 */     return (int)(value ^ value >>> 32);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static int compare(long a, long b)
/*  27:    */   {
/*  28: 94 */     return a > b ? 1 : a < b ? -1 : 0;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static boolean contains(long[] array, long target)
/*  32:    */   {
/*  33:107 */     for (long value : array) {
/*  34:108 */       if (value == target) {
/*  35:109 */         return true;
/*  36:    */       }
/*  37:    */     }
/*  38:112 */     return false;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static int indexOf(long[] array, long target)
/*  42:    */   {
/*  43:125 */     return indexOf(array, target, 0, array.length);
/*  44:    */   }
/*  45:    */   
/*  46:    */   private static int indexOf(long[] array, long target, int start, int end)
/*  47:    */   {
/*  48:131 */     for (int i = start; i < end; i++) {
/*  49:132 */       if (array[i] == target) {
/*  50:133 */         return i;
/*  51:    */       }
/*  52:    */     }
/*  53:136 */     return -1;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static int indexOf(long[] array, long[] target)
/*  57:    */   {
/*  58:151 */     Preconditions.checkNotNull(array, "array");
/*  59:152 */     Preconditions.checkNotNull(target, "target");
/*  60:153 */     if (target.length == 0) {
/*  61:154 */       return 0;
/*  62:    */     }
/*  63:    */     label65:
/*  64:158 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  65:    */     {
/*  66:159 */       for (int j = 0; j < target.length; j++) {
/*  67:160 */         if (array[(i + j)] != target[j]) {
/*  68:    */           break label65;
/*  69:    */         }
/*  70:    */       }
/*  71:164 */       return i;
/*  72:    */     }
/*  73:166 */     return -1;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static int lastIndexOf(long[] array, long target)
/*  77:    */   {
/*  78:179 */     return lastIndexOf(array, target, 0, array.length);
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static int lastIndexOf(long[] array, long target, int start, int end)
/*  82:    */   {
/*  83:185 */     for (int i = end - 1; i >= start; i--) {
/*  84:186 */       if (array[i] == target) {
/*  85:187 */         return i;
/*  86:    */       }
/*  87:    */     }
/*  88:190 */     return -1;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static long min(long... array)
/*  92:    */   {
/*  93:202 */     Preconditions.checkArgument(array.length > 0);
/*  94:203 */     long min = array[0];
/*  95:204 */     for (int i = 1; i < array.length; i++) {
/*  96:205 */       if (array[i] < min) {
/*  97:206 */         min = array[i];
/*  98:    */       }
/*  99:    */     }
/* 100:209 */     return min;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static long max(long... array)
/* 104:    */   {
/* 105:221 */     Preconditions.checkArgument(array.length > 0);
/* 106:222 */     long max = array[0];
/* 107:223 */     for (int i = 1; i < array.length; i++) {
/* 108:224 */       if (array[i] > max) {
/* 109:225 */         max = array[i];
/* 110:    */       }
/* 111:    */     }
/* 112:228 */     return max;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static long[] concat(long[]... arrays)
/* 116:    */   {
/* 117:241 */     int length = 0;
/* 118:242 */     for (long[] array : arrays) {
/* 119:243 */       length += array.length;
/* 120:    */     }
/* 121:245 */     long[] result = new long[length];
/* 122:246 */     int pos = 0;
/* 123:247 */     for (long[] array : arrays)
/* 124:    */     {
/* 125:248 */       System.arraycopy(array, 0, result, pos, array.length);
/* 126:249 */       pos += array.length;
/* 127:    */     }
/* 128:251 */     return result;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static byte[] toByteArray(long value)
/* 132:    */   {
/* 133:268 */     byte[] result = new byte[8];
/* 134:269 */     for (int i = 7; i >= 0; i--)
/* 135:    */     {
/* 136:270 */       result[i] = ((byte)(int)(value & 0xFF));
/* 137:271 */       value >>= 8;
/* 138:    */     }
/* 139:273 */     return result;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static long fromByteArray(byte[] bytes)
/* 143:    */   {
/* 144:290 */     Preconditions.checkArgument(bytes.length >= 8, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(8) });
/* 145:    */     
/* 146:292 */     return fromBytes(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static long fromBytes(byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8)
/* 150:    */   {
/* 151:305 */     return (b1 & 0xFF) << 56 | (b2 & 0xFF) << 48 | (b3 & 0xFF) << 40 | (b4 & 0xFF) << 32 | (b5 & 0xFF) << 24 | (b6 & 0xFF) << 16 | (b7 & 0xFF) << 8 | b8 & 0xFF;
/* 152:    */   }
/* 153:    */   
/* 154:    */   @Beta
/* 155:    */   public static Long tryParse(String string)
/* 156:    */   {
/* 157:337 */     if (((String)Preconditions.checkNotNull(string)).isEmpty()) {
/* 158:338 */       return null;
/* 159:    */     }
/* 160:340 */     boolean negative = string.charAt(0) == '-';
/* 161:341 */     int index = negative ? 1 : 0;
/* 162:342 */     if (index == string.length()) {
/* 163:343 */       return null;
/* 164:    */     }
/* 165:345 */     int digit = string.charAt(index++) - '0';
/* 166:346 */     if ((digit < 0) || (digit > 9)) {
/* 167:347 */       return null;
/* 168:    */     }
/* 169:349 */     long accum = -digit;
/* 170:350 */     while (index < string.length())
/* 171:    */     {
/* 172:351 */       digit = string.charAt(index++) - '0';
/* 173:352 */       if ((digit < 0) || (digit > 9) || (accum < -922337203685477580L)) {
/* 174:353 */         return null;
/* 175:    */       }
/* 176:355 */       accum *= 10L;
/* 177:356 */       if (accum < -9223372036854775808L + digit) {
/* 178:357 */         return null;
/* 179:    */       }
/* 180:359 */       accum -= digit;
/* 181:    */     }
/* 182:362 */     if (negative) {
/* 183:363 */       return Long.valueOf(accum);
/* 184:    */     }
/* 185:364 */     if (accum == -9223372036854775808L) {
/* 186:365 */       return null;
/* 187:    */     }
/* 188:367 */     return Long.valueOf(-accum);
/* 189:    */   }
/* 190:    */   
/* 191:    */   private static final class LongConverter
/* 192:    */     extends Converter<String, Long>
/* 193:    */     implements Serializable
/* 194:    */   {
/* 195:372 */     static final LongConverter INSTANCE = new LongConverter();
/* 196:    */     private static final long serialVersionUID = 1L;
/* 197:    */     
/* 198:    */     protected Long doForward(String value)
/* 199:    */     {
/* 200:376 */       return Long.decode(value);
/* 201:    */     }
/* 202:    */     
/* 203:    */     protected String doBackward(Long value)
/* 204:    */     {
/* 205:381 */       return value.toString();
/* 206:    */     }
/* 207:    */     
/* 208:    */     public String toString()
/* 209:    */     {
/* 210:386 */       return "Longs.stringConverter()";
/* 211:    */     }
/* 212:    */     
/* 213:    */     private Object readResolve()
/* 214:    */     {
/* 215:390 */       return INSTANCE;
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   @Beta
/* 220:    */   public static Converter<String, Long> stringConverter()
/* 221:    */   {
/* 222:403 */     return LongConverter.INSTANCE;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static long[] ensureCapacity(long[] array, int minLength, int padding)
/* 226:    */   {
/* 227:424 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 228:425 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 229:426 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static long[] copyOf(long[] original, int length)
/* 233:    */   {
/* 234:433 */     long[] copy = new long[length];
/* 235:434 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 236:435 */     return copy;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static String join(String separator, long... array)
/* 240:    */   {
/* 241:448 */     Preconditions.checkNotNull(separator);
/* 242:449 */     if (array.length == 0) {
/* 243:450 */       return "";
/* 244:    */     }
/* 245:454 */     StringBuilder builder = new StringBuilder(array.length * 10);
/* 246:455 */     builder.append(array[0]);
/* 247:456 */     for (int i = 1; i < array.length; i++) {
/* 248:457 */       builder.append(separator).append(array[i]);
/* 249:    */     }
/* 250:459 */     return builder.toString();
/* 251:    */   }
/* 252:    */   
/* 253:    */   public static Comparator<long[]> lexicographicalComparator()
/* 254:    */   {
/* 255:479 */     return LexicographicalComparator.INSTANCE;
/* 256:    */   }
/* 257:    */   
/* 258:    */   private static enum LexicographicalComparator
/* 259:    */     implements Comparator<long[]>
/* 260:    */   {
/* 261:483 */     INSTANCE;
/* 262:    */     
/* 263:    */     private LexicographicalComparator() {}
/* 264:    */     
/* 265:    */     public int compare(long[] left, long[] right)
/* 266:    */     {
/* 267:487 */       int minLength = Math.min(left.length, right.length);
/* 268:488 */       for (int i = 0; i < minLength; i++)
/* 269:    */       {
/* 270:489 */         int result = Longs.compare(left[i], right[i]);
/* 271:490 */         if (result != 0) {
/* 272:491 */           return result;
/* 273:    */         }
/* 274:    */       }
/* 275:494 */       return left.length - right.length;
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   public static long[] toArray(Collection<? extends Number> collection)
/* 280:    */   {
/* 281:514 */     if ((collection instanceof LongArrayAsList)) {
/* 282:515 */       return ((LongArrayAsList)collection).toLongArray();
/* 283:    */     }
/* 284:518 */     Object[] boxedArray = collection.toArray();
/* 285:519 */     int len = boxedArray.length;
/* 286:520 */     long[] array = new long[len];
/* 287:521 */     for (int i = 0; i < len; i++) {
/* 288:523 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).longValue();
/* 289:    */     }
/* 290:525 */     return array;
/* 291:    */   }
/* 292:    */   
/* 293:    */   public static List<Long> asList(long... backingArray)
/* 294:    */   {
/* 295:543 */     if (backingArray.length == 0) {
/* 296:544 */       return Collections.emptyList();
/* 297:    */     }
/* 298:546 */     return new LongArrayAsList(backingArray);
/* 299:    */   }
/* 300:    */   
/* 301:    */   @GwtCompatible
/* 302:    */   private static class LongArrayAsList
/* 303:    */     extends AbstractList<Long>
/* 304:    */     implements RandomAccess, Serializable
/* 305:    */   {
/* 306:    */     final long[] array;
/* 307:    */     final int start;
/* 308:    */     final int end;
/* 309:    */     private static final long serialVersionUID = 0L;
/* 310:    */     
/* 311:    */     LongArrayAsList(long[] array)
/* 312:    */     {
/* 313:557 */       this(array, 0, array.length);
/* 314:    */     }
/* 315:    */     
/* 316:    */     LongArrayAsList(long[] array, int start, int end)
/* 317:    */     {
/* 318:561 */       this.array = array;
/* 319:562 */       this.start = start;
/* 320:563 */       this.end = end;
/* 321:    */     }
/* 322:    */     
/* 323:    */     public int size()
/* 324:    */     {
/* 325:567 */       return this.end - this.start;
/* 326:    */     }
/* 327:    */     
/* 328:    */     public boolean isEmpty()
/* 329:    */     {
/* 330:571 */       return false;
/* 331:    */     }
/* 332:    */     
/* 333:    */     public Long get(int index)
/* 334:    */     {
/* 335:575 */       Preconditions.checkElementIndex(index, size());
/* 336:576 */       return Long.valueOf(this.array[(this.start + index)]);
/* 337:    */     }
/* 338:    */     
/* 339:    */     public boolean contains(Object target)
/* 340:    */     {
/* 341:581 */       return ((target instanceof Long)) && (Longs.indexOf(this.array, ((Long)target).longValue(), this.start, this.end) != -1);
/* 342:    */     }
/* 343:    */     
/* 344:    */     public int indexOf(Object target)
/* 345:    */     {
/* 346:587 */       if ((target instanceof Long))
/* 347:    */       {
/* 348:588 */         int i = Longs.indexOf(this.array, ((Long)target).longValue(), this.start, this.end);
/* 349:589 */         if (i >= 0) {
/* 350:590 */           return i - this.start;
/* 351:    */         }
/* 352:    */       }
/* 353:593 */       return -1;
/* 354:    */     }
/* 355:    */     
/* 356:    */     public int lastIndexOf(Object target)
/* 357:    */     {
/* 358:598 */       if ((target instanceof Long))
/* 359:    */       {
/* 360:599 */         int i = Longs.lastIndexOf(this.array, ((Long)target).longValue(), this.start, this.end);
/* 361:600 */         if (i >= 0) {
/* 362:601 */           return i - this.start;
/* 363:    */         }
/* 364:    */       }
/* 365:604 */       return -1;
/* 366:    */     }
/* 367:    */     
/* 368:    */     public Long set(int index, Long element)
/* 369:    */     {
/* 370:608 */       Preconditions.checkElementIndex(index, size());
/* 371:609 */       long oldValue = this.array[(this.start + index)];
/* 372:    */       
/* 373:611 */       this.array[(this.start + index)] = ((Long)Preconditions.checkNotNull(element)).longValue();
/* 374:612 */       return Long.valueOf(oldValue);
/* 375:    */     }
/* 376:    */     
/* 377:    */     public List<Long> subList(int fromIndex, int toIndex)
/* 378:    */     {
/* 379:616 */       int size = size();
/* 380:617 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 381:618 */       if (fromIndex == toIndex) {
/* 382:619 */         return Collections.emptyList();
/* 383:    */       }
/* 384:621 */       return new LongArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 385:    */     }
/* 386:    */     
/* 387:    */     public boolean equals(Object object)
/* 388:    */     {
/* 389:625 */       if (object == this) {
/* 390:626 */         return true;
/* 391:    */       }
/* 392:628 */       if ((object instanceof LongArrayAsList))
/* 393:    */       {
/* 394:629 */         LongArrayAsList that = (LongArrayAsList)object;
/* 395:630 */         int size = size();
/* 396:631 */         if (that.size() != size) {
/* 397:632 */           return false;
/* 398:    */         }
/* 399:634 */         for (int i = 0; i < size; i++) {
/* 400:635 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 401:636 */             return false;
/* 402:    */           }
/* 403:    */         }
/* 404:639 */         return true;
/* 405:    */       }
/* 406:641 */       return super.equals(object);
/* 407:    */     }
/* 408:    */     
/* 409:    */     public int hashCode()
/* 410:    */     {
/* 411:645 */       int result = 1;
/* 412:646 */       for (int i = this.start; i < this.end; i++) {
/* 413:647 */         result = 31 * result + Longs.hashCode(this.array[i]);
/* 414:    */       }
/* 415:649 */       return result;
/* 416:    */     }
/* 417:    */     
/* 418:    */     public String toString()
/* 419:    */     {
/* 420:653 */       StringBuilder builder = new StringBuilder(size() * 10);
/* 421:654 */       builder.append('[').append(this.array[this.start]);
/* 422:655 */       for (int i = this.start + 1; i < this.end; i++) {
/* 423:656 */         builder.append(", ").append(this.array[i]);
/* 424:    */       }
/* 425:658 */       return ']';
/* 426:    */     }
/* 427:    */     
/* 428:    */     long[] toLongArray()
/* 429:    */     {
/* 430:663 */       int size = size();
/* 431:664 */       long[] result = new long[size];
/* 432:665 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 433:666 */       return result;
/* 434:    */     }
/* 435:    */   }
/* 436:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Longs
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import java.util.regex.Matcher;
/*  16:    */ import java.util.regex.Pattern;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class Doubles
/*  21:    */ {
/*  22:    */   public static final int BYTES = 8;
/*  23:    */   
/*  24:    */   public static int hashCode(double value)
/*  25:    */   {
/*  26: 74 */     return Double.valueOf(value).hashCode();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static int compare(double a, double b)
/*  30:    */   {
/*  31: 96 */     return Double.compare(a, b);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static boolean isFinite(double value)
/*  35:    */   {
/*  36:107 */     return ((-1.0D / 0.0D) < value ? 1 : 0) & (value < (1.0D / 0.0D) ? 1 : 0);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static boolean contains(double[] array, double target)
/*  40:    */   {
/*  41:121 */     for (double value : array) {
/*  42:122 */       if (value == target) {
/*  43:123 */         return true;
/*  44:    */       }
/*  45:    */     }
/*  46:126 */     return false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static int indexOf(double[] array, double target)
/*  50:    */   {
/*  51:140 */     return indexOf(array, target, 0, array.length);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static int indexOf(double[] array, double target, int start, int end)
/*  55:    */   {
/*  56:146 */     for (int i = start; i < end; i++) {
/*  57:147 */       if (array[i] == target) {
/*  58:148 */         return i;
/*  59:    */       }
/*  60:    */     }
/*  61:151 */     return -1;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static int indexOf(double[] array, double[] target)
/*  65:    */   {
/*  66:169 */     Preconditions.checkNotNull(array, "array");
/*  67:170 */     Preconditions.checkNotNull(target, "target");
/*  68:171 */     if (target.length == 0) {
/*  69:172 */       return 0;
/*  70:    */     }
/*  71:    */     label65:
/*  72:176 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  73:    */     {
/*  74:177 */       for (int j = 0; j < target.length; j++) {
/*  75:178 */         if (array[(i + j)] != target[j]) {
/*  76:    */           break label65;
/*  77:    */         }
/*  78:    */       }
/*  79:182 */       return i;
/*  80:    */     }
/*  81:184 */     return -1;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static int lastIndexOf(double[] array, double target)
/*  85:    */   {
/*  86:198 */     return lastIndexOf(array, target, 0, array.length);
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static int lastIndexOf(double[] array, double target, int start, int end)
/*  90:    */   {
/*  91:204 */     for (int i = end - 1; i >= start; i--) {
/*  92:205 */       if (array[i] == target) {
/*  93:206 */         return i;
/*  94:    */       }
/*  95:    */     }
/*  96:209 */     return -1;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static double min(double... array)
/* 100:    */   {
/* 101:222 */     Preconditions.checkArgument(array.length > 0);
/* 102:223 */     double min = array[0];
/* 103:224 */     for (int i = 1; i < array.length; i++) {
/* 104:225 */       min = Math.min(min, array[i]);
/* 105:    */     }
/* 106:227 */     return min;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static double max(double... array)
/* 110:    */   {
/* 111:240 */     Preconditions.checkArgument(array.length > 0);
/* 112:241 */     double max = array[0];
/* 113:242 */     for (int i = 1; i < array.length; i++) {
/* 114:243 */       max = Math.max(max, array[i]);
/* 115:    */     }
/* 116:245 */     return max;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static double[] concat(double[]... arrays)
/* 120:    */   {
/* 121:258 */     int length = 0;
/* 122:259 */     for (double[] array : arrays) {
/* 123:260 */       length += array.length;
/* 124:    */     }
/* 125:262 */     double[] result = new double[length];
/* 126:263 */     int pos = 0;
/* 127:264 */     for (double[] array : arrays)
/* 128:    */     {
/* 129:265 */       System.arraycopy(array, 0, result, pos, array.length);
/* 130:266 */       pos += array.length;
/* 131:    */     }
/* 132:268 */     return result;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static final class DoubleConverter
/* 136:    */     extends Converter<String, Double>
/* 137:    */     implements Serializable
/* 138:    */   {
/* 139:273 */     static final DoubleConverter INSTANCE = new DoubleConverter();
/* 140:    */     private static final long serialVersionUID = 1L;
/* 141:    */     
/* 142:    */     protected Double doForward(String value)
/* 143:    */     {
/* 144:277 */       return Double.valueOf(value);
/* 145:    */     }
/* 146:    */     
/* 147:    */     protected String doBackward(Double value)
/* 148:    */     {
/* 149:282 */       return value.toString();
/* 150:    */     }
/* 151:    */     
/* 152:    */     public String toString()
/* 153:    */     {
/* 154:287 */       return "Doubles.stringConverter()";
/* 155:    */     }
/* 156:    */     
/* 157:    */     private Object readResolve()
/* 158:    */     {
/* 159:291 */       return INSTANCE;
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   @Beta
/* 164:    */   public static Converter<String, Double> stringConverter()
/* 165:    */   {
/* 166:304 */     return DoubleConverter.INSTANCE;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static double[] ensureCapacity(double[] array, int minLength, int padding)
/* 170:    */   {
/* 171:325 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 172:326 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 173:327 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private static double[] copyOf(double[] original, int length)
/* 177:    */   {
/* 178:334 */     double[] copy = new double[length];
/* 179:335 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 180:336 */     return copy;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static String join(String separator, double... array)
/* 184:    */   {
/* 185:354 */     Preconditions.checkNotNull(separator);
/* 186:355 */     if (array.length == 0) {
/* 187:356 */       return "";
/* 188:    */     }
/* 189:360 */     StringBuilder builder = new StringBuilder(array.length * 12);
/* 190:361 */     builder.append(array[0]);
/* 191:362 */     for (int i = 1; i < array.length; i++) {
/* 192:363 */       builder.append(separator).append(array[i]);
/* 193:    */     }
/* 194:365 */     return builder.toString();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static Comparator<double[]> lexicographicalComparator()
/* 198:    */   {
/* 199:385 */     return LexicographicalComparator.INSTANCE;
/* 200:    */   }
/* 201:    */   
/* 202:    */   private static enum LexicographicalComparator
/* 203:    */     implements Comparator<double[]>
/* 204:    */   {
/* 205:389 */     INSTANCE;
/* 206:    */     
/* 207:    */     private LexicographicalComparator() {}
/* 208:    */     
/* 209:    */     public int compare(double[] left, double[] right)
/* 210:    */     {
/* 211:393 */       int minLength = Math.min(left.length, right.length);
/* 212:394 */       for (int i = 0; i < minLength; i++)
/* 213:    */       {
/* 214:395 */         int result = Doubles.compare(left[i], right[i]);
/* 215:396 */         if (result != 0) {
/* 216:397 */           return result;
/* 217:    */         }
/* 218:    */       }
/* 219:400 */       return left.length - right.length;
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   public static double[] toArray(Collection<? extends Number> collection)
/* 224:    */   {
/* 225:420 */     if ((collection instanceof DoubleArrayAsList)) {
/* 226:421 */       return ((DoubleArrayAsList)collection).toDoubleArray();
/* 227:    */     }
/* 228:424 */     Object[] boxedArray = collection.toArray();
/* 229:425 */     int len = boxedArray.length;
/* 230:426 */     double[] array = new double[len];
/* 231:427 */     for (int i = 0; i < len; i++) {
/* 232:429 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).doubleValue();
/* 233:    */     }
/* 234:431 */     return array;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static List<Double> asList(double... backingArray)
/* 238:    */   {
/* 239:452 */     if (backingArray.length == 0) {
/* 240:453 */       return Collections.emptyList();
/* 241:    */     }
/* 242:455 */     return new DoubleArrayAsList(backingArray);
/* 243:    */   }
/* 244:    */   
/* 245:    */   @GwtCompatible
/* 246:    */   private static class DoubleArrayAsList
/* 247:    */     extends AbstractList<Double>
/* 248:    */     implements RandomAccess, Serializable
/* 249:    */   {
/* 250:    */     final double[] array;
/* 251:    */     final int start;
/* 252:    */     final int end;
/* 253:    */     private static final long serialVersionUID = 0L;
/* 254:    */     
/* 255:    */     DoubleArrayAsList(double[] array)
/* 256:    */     {
/* 257:466 */       this(array, 0, array.length);
/* 258:    */     }
/* 259:    */     
/* 260:    */     DoubleArrayAsList(double[] array, int start, int end)
/* 261:    */     {
/* 262:470 */       this.array = array;
/* 263:471 */       this.start = start;
/* 264:472 */       this.end = end;
/* 265:    */     }
/* 266:    */     
/* 267:    */     public int size()
/* 268:    */     {
/* 269:476 */       return this.end - this.start;
/* 270:    */     }
/* 271:    */     
/* 272:    */     public boolean isEmpty()
/* 273:    */     {
/* 274:480 */       return false;
/* 275:    */     }
/* 276:    */     
/* 277:    */     public Double get(int index)
/* 278:    */     {
/* 279:484 */       Preconditions.checkElementIndex(index, size());
/* 280:485 */       return Double.valueOf(this.array[(this.start + index)]);
/* 281:    */     }
/* 282:    */     
/* 283:    */     public boolean contains(Object target)
/* 284:    */     {
/* 285:490 */       return ((target instanceof Double)) && (Doubles.indexOf(this.array, ((Double)target).doubleValue(), this.start, this.end) != -1);
/* 286:    */     }
/* 287:    */     
/* 288:    */     public int indexOf(Object target)
/* 289:    */     {
/* 290:496 */       if ((target instanceof Double))
/* 291:    */       {
/* 292:497 */         int i = Doubles.indexOf(this.array, ((Double)target).doubleValue(), this.start, this.end);
/* 293:498 */         if (i >= 0) {
/* 294:499 */           return i - this.start;
/* 295:    */         }
/* 296:    */       }
/* 297:502 */       return -1;
/* 298:    */     }
/* 299:    */     
/* 300:    */     public int lastIndexOf(Object target)
/* 301:    */     {
/* 302:507 */       if ((target instanceof Double))
/* 303:    */       {
/* 304:508 */         int i = Doubles.lastIndexOf(this.array, ((Double)target).doubleValue(), this.start, this.end);
/* 305:509 */         if (i >= 0) {
/* 306:510 */           return i - this.start;
/* 307:    */         }
/* 308:    */       }
/* 309:513 */       return -1;
/* 310:    */     }
/* 311:    */     
/* 312:    */     public Double set(int index, Double element)
/* 313:    */     {
/* 314:517 */       Preconditions.checkElementIndex(index, size());
/* 315:518 */       double oldValue = this.array[(this.start + index)];
/* 316:    */       
/* 317:520 */       this.array[(this.start + index)] = ((Double)Preconditions.checkNotNull(element)).doubleValue();
/* 318:521 */       return Double.valueOf(oldValue);
/* 319:    */     }
/* 320:    */     
/* 321:    */     public List<Double> subList(int fromIndex, int toIndex)
/* 322:    */     {
/* 323:525 */       int size = size();
/* 324:526 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 325:527 */       if (fromIndex == toIndex) {
/* 326:528 */         return Collections.emptyList();
/* 327:    */       }
/* 328:530 */       return new DoubleArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 329:    */     }
/* 330:    */     
/* 331:    */     public boolean equals(Object object)
/* 332:    */     {
/* 333:534 */       if (object == this) {
/* 334:535 */         return true;
/* 335:    */       }
/* 336:537 */       if ((object instanceof DoubleArrayAsList))
/* 337:    */       {
/* 338:538 */         DoubleArrayAsList that = (DoubleArrayAsList)object;
/* 339:539 */         int size = size();
/* 340:540 */         if (that.size() != size) {
/* 341:541 */           return false;
/* 342:    */         }
/* 343:543 */         for (int i = 0; i < size; i++) {
/* 344:544 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 345:545 */             return false;
/* 346:    */           }
/* 347:    */         }
/* 348:548 */         return true;
/* 349:    */       }
/* 350:550 */       return super.equals(object);
/* 351:    */     }
/* 352:    */     
/* 353:    */     public int hashCode()
/* 354:    */     {
/* 355:554 */       int result = 1;
/* 356:555 */       for (int i = this.start; i < this.end; i++) {
/* 357:556 */         result = 31 * result + Doubles.hashCode(this.array[i]);
/* 358:    */       }
/* 359:558 */       return result;
/* 360:    */     }
/* 361:    */     
/* 362:    */     public String toString()
/* 363:    */     {
/* 364:562 */       StringBuilder builder = new StringBuilder(size() * 12);
/* 365:563 */       builder.append('[').append(this.array[this.start]);
/* 366:564 */       for (int i = this.start + 1; i < this.end; i++) {
/* 367:565 */         builder.append(", ").append(this.array[i]);
/* 368:    */       }
/* 369:567 */       return ']';
/* 370:    */     }
/* 371:    */     
/* 372:    */     double[] toDoubleArray()
/* 373:    */     {
/* 374:572 */       int size = size();
/* 375:573 */       double[] result = new double[size];
/* 376:574 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 377:575 */       return result;
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   @GwtIncompatible("regular expressions")
/* 382:588 */   static final Pattern FLOATING_POINT_PATTERN = ;
/* 383:    */   
/* 384:    */   @GwtIncompatible("regular expressions")
/* 385:    */   private static Pattern fpPattern()
/* 386:    */   {
/* 387:592 */     String decimal = "(?:\\d++(?:\\.\\d*+)?|\\.\\d++)";
/* 388:593 */     String completeDec = decimal + "(?:[eE][+-]?\\d++)?[fFdD]?";
/* 389:594 */     String hex = "(?:\\p{XDigit}++(?:\\.\\p{XDigit}*+)?|\\.\\p{XDigit}++)";
/* 390:595 */     String completeHex = "0[xX]" + hex + "[pP][+-]?\\d++[fFdD]?";
/* 391:596 */     String fpPattern = "[+-]?(?:NaN|Infinity|" + completeDec + "|" + completeHex + ")";
/* 392:597 */     return Pattern.compile(fpPattern);
/* 393:    */   }
/* 394:    */   
/* 395:    */   @Nullable
/* 396:    */   @GwtIncompatible("regular expressions")
/* 397:    */   @Beta
/* 398:    */   public static Double tryParse(String string)
/* 399:    */   {
/* 400:623 */     if (FLOATING_POINT_PATTERN.matcher(string).matches()) {
/* 401:    */       try
/* 402:    */       {
/* 403:627 */         return Double.valueOf(Double.parseDouble(string));
/* 404:    */       }
/* 405:    */       catch (NumberFormatException e) {}
/* 406:    */     }
/* 407:633 */     return null;
/* 408:    */   }
/* 409:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.primitives.Doubles
 * JD-Core Version:    0.7.0.1
 */
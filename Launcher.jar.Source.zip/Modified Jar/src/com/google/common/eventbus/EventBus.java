/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Throwables;
/*   7:    */ import com.google.common.cache.CacheBuilder;
/*   8:    */ import com.google.common.cache.CacheLoader;
/*   9:    */ import com.google.common.cache.LoadingCache;
/*  10:    */ import com.google.common.collect.HashMultimap;
/*  11:    */ import com.google.common.collect.Multimap;
/*  12:    */ import com.google.common.collect.SetMultimap;
/*  13:    */ import com.google.common.reflect.TypeToken;
/*  14:    */ import com.google.common.reflect.TypeToken.TypeSet;
/*  15:    */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*  16:    */ import java.lang.reflect.InvocationTargetException;
/*  17:    */ import java.util.Collection;
/*  18:    */ import java.util.LinkedList;
/*  19:    */ import java.util.Map;
/*  20:    */ import java.util.Map.Entry;
/*  21:    */ import java.util.Queue;
/*  22:    */ import java.util.Set;
/*  23:    */ import java.util.concurrent.locks.Lock;
/*  24:    */ import java.util.concurrent.locks.ReadWriteLock;
/*  25:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*  26:    */ import java.util.logging.Level;
/*  27:    */ import java.util.logging.Logger;
/*  28:    */ 
/*  29:    */ @Beta
/*  30:    */ public class EventBus
/*  31:    */ {
/*  32:121 */   private static final LoadingCache<Class<?>, Set<Class<?>>> flattenHierarchyCache = CacheBuilder.newBuilder().weakKeys().build(new CacheLoader()
/*  33:    */   {
/*  34:    */     public Set<Class<?>> load(Class<?> concreteClass)
/*  35:    */     {
/*  36:128 */       return TypeToken.of(concreteClass).getTypes().rawTypes();
/*  37:    */     }
/*  38:121 */   });
/*  39:138 */   private final SetMultimap<Class<?>, EventSubscriber> subscribersByType = HashMultimap.create();
/*  40:140 */   private final ReadWriteLock subscribersByTypeLock = new ReentrantReadWriteLock();
/*  41:147 */   private final SubscriberFindingStrategy finder = new AnnotatedSubscriberFinder();
/*  42:150 */   private final ThreadLocal<Queue<EventWithSubscriber>> eventsToDispatch = new ThreadLocal()
/*  43:    */   {
/*  44:    */     protected Queue<EventBus.EventWithSubscriber> initialValue()
/*  45:    */     {
/*  46:153 */       return new LinkedList();
/*  47:    */     }
/*  48:    */   };
/*  49:158 */   private final ThreadLocal<Boolean> isDispatching = new ThreadLocal()
/*  50:    */   {
/*  51:    */     protected Boolean initialValue()
/*  52:    */     {
/*  53:161 */       return Boolean.valueOf(false);
/*  54:    */     }
/*  55:    */   };
/*  56:    */   private SubscriberExceptionHandler subscriberExceptionHandler;
/*  57:    */   
/*  58:    */   public EventBus()
/*  59:    */   {
/*  60:171 */     this("default");
/*  61:    */   }
/*  62:    */   
/*  63:    */   public EventBus(String identifier)
/*  64:    */   {
/*  65:181 */     this(new LoggingSubscriberExceptionHandler(identifier));
/*  66:    */   }
/*  67:    */   
/*  68:    */   public EventBus(SubscriberExceptionHandler subscriberExceptionHandler)
/*  69:    */   {
/*  70:191 */     this.subscriberExceptionHandler = ((SubscriberExceptionHandler)Preconditions.checkNotNull(subscriberExceptionHandler));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void register(Object object)
/*  74:    */   {
/*  75:203 */     Multimap<Class<?>, EventSubscriber> methodsInListener = this.finder.findAllSubscribers(object);
/*  76:    */     
/*  77:205 */     this.subscribersByTypeLock.writeLock().lock();
/*  78:    */     try
/*  79:    */     {
/*  80:207 */       this.subscribersByType.putAll(methodsInListener);
/*  81:    */     }
/*  82:    */     finally
/*  83:    */     {
/*  84:209 */       this.subscribersByTypeLock.writeLock().unlock();
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void unregister(Object object)
/*  89:    */   {
/*  90:220 */     Multimap<Class<?>, EventSubscriber> methodsInListener = this.finder.findAllSubscribers(object);
/*  91:222 */     for (Map.Entry<Class<?>, Collection<EventSubscriber>> entry : methodsInListener.asMap().entrySet())
/*  92:    */     {
/*  93:223 */       Class<?> eventType = (Class)entry.getKey();
/*  94:224 */       Collection<EventSubscriber> eventMethodsInListener = (Collection)entry.getValue();
/*  95:    */       
/*  96:226 */       this.subscribersByTypeLock.writeLock().lock();
/*  97:    */       try
/*  98:    */       {
/*  99:228 */         Set<EventSubscriber> currentSubscribers = this.subscribersByType.get(eventType);
/* 100:229 */         if (!currentSubscribers.containsAll(eventMethodsInListener)) {
/* 101:230 */           throw new IllegalArgumentException("missing event subscriber for an annotated method. Is " + object + " registered?");
/* 102:    */         }
/* 103:233 */         currentSubscribers.removeAll(eventMethodsInListener);
/* 104:    */       }
/* 105:    */       finally
/* 106:    */       {
/* 107:235 */         this.subscribersByTypeLock.writeLock().unlock();
/* 108:    */       }
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void post(Object event)
/* 113:    */   {
/* 114:252 */     Set<Class<?>> dispatchTypes = flattenHierarchy(event.getClass());
/* 115:    */     
/* 116:254 */     boolean dispatched = false;
/* 117:255 */     for (Class<?> eventType : dispatchTypes)
/* 118:    */     {
/* 119:256 */       this.subscribersByTypeLock.readLock().lock();
/* 120:    */       try
/* 121:    */       {
/* 122:258 */         Set<EventSubscriber> wrappers = this.subscribersByType.get(eventType);
/* 123:260 */         if (!wrappers.isEmpty())
/* 124:    */         {
/* 125:261 */           dispatched = true;
/* 126:262 */           for (EventSubscriber wrapper : wrappers) {
/* 127:263 */             enqueueEvent(event, wrapper);
/* 128:    */           }
/* 129:    */         }
/* 130:    */       }
/* 131:    */       finally
/* 132:    */       {
/* 133:267 */         this.subscribersByTypeLock.readLock().unlock();
/* 134:    */       }
/* 135:    */     }
/* 136:271 */     if ((!dispatched) && (!(event instanceof DeadEvent))) {
/* 137:272 */       post(new DeadEvent(this, event));
/* 138:    */     }
/* 139:275 */     dispatchQueuedEvents();
/* 140:    */   }
/* 141:    */   
/* 142:    */   void enqueueEvent(Object event, EventSubscriber subscriber)
/* 143:    */   {
/* 144:284 */     ((Queue)this.eventsToDispatch.get()).offer(new EventWithSubscriber(event, subscriber));
/* 145:    */   }
/* 146:    */   
/* 147:    */   void dispatchQueuedEvents()
/* 148:    */   {
/* 149:295 */     if (((Boolean)this.isDispatching.get()).booleanValue()) {
/* 150:296 */       return;
/* 151:    */     }
/* 152:299 */     this.isDispatching.set(Boolean.valueOf(true));
/* 153:    */     try
/* 154:    */     {
/* 155:301 */       Queue<EventWithSubscriber> events = (Queue)this.eventsToDispatch.get();
/* 156:    */       EventWithSubscriber eventWithSubscriber;
/* 157:303 */       while ((eventWithSubscriber = (EventWithSubscriber)events.poll()) != null) {
/* 158:304 */         dispatch(eventWithSubscriber.event, eventWithSubscriber.subscriber);
/* 159:    */       }
/* 160:    */     }
/* 161:    */     finally
/* 162:    */     {
/* 163:307 */       this.isDispatching.remove();
/* 164:308 */       this.eventsToDispatch.remove();
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   void dispatch(Object event, EventSubscriber wrapper)
/* 169:    */   {
/* 170:    */     try
/* 171:    */     {
/* 172:322 */       wrapper.handleEvent(event);
/* 173:    */     }
/* 174:    */     catch (InvocationTargetException e)
/* 175:    */     {
/* 176:    */       try
/* 177:    */       {
/* 178:325 */         this.subscriberExceptionHandler.handleException(e.getCause(), new SubscriberExceptionContext(this, event, wrapper.getSubscriber(), wrapper.getMethod()));
/* 179:    */       }
/* 180:    */       catch (Throwable t)
/* 181:    */       {
/* 182:334 */         Logger.getLogger(EventBus.class.getName()).log(Level.SEVERE, String.format("Exception %s thrown while handling exception: %s", new Object[] { t, e.getCause() }), t);
/* 183:    */       }
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   @VisibleForTesting
/* 188:    */   Set<Class<?>> flattenHierarchy(Class<?> concreteClass)
/* 189:    */   {
/* 190:    */     try
/* 191:    */     {
/* 192:354 */       return (Set)flattenHierarchyCache.getUnchecked(concreteClass);
/* 193:    */     }
/* 194:    */     catch (UncheckedExecutionException e)
/* 195:    */     {
/* 196:356 */       throw Throwables.propagate(e.getCause());
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   private static final class LoggingSubscriberExceptionHandler
/* 201:    */     implements SubscriberExceptionHandler
/* 202:    */   {
/* 203:    */     private final Logger logger;
/* 204:    */     
/* 205:    */     public LoggingSubscriberExceptionHandler(String identifier)
/* 206:    */     {
/* 207:377 */       this.logger = Logger.getLogger(EventBus.class.getName() + "." + (String)Preconditions.checkNotNull(identifier));
/* 208:    */     }
/* 209:    */     
/* 210:    */     public void handleException(Throwable exception, SubscriberExceptionContext context)
/* 211:    */     {
/* 212:384 */       this.logger.log(Level.SEVERE, "Could not dispatch event: " + context.getSubscriber() + " to " + context.getSubscriberMethod(), exception.getCause());
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */   static class EventWithSubscriber
/* 217:    */   {
/* 218:    */     final Object event;
/* 219:    */     final EventSubscriber subscriber;
/* 220:    */     
/* 221:    */     public EventWithSubscriber(Object event, EventSubscriber subscriber)
/* 222:    */     {
/* 223:395 */       this.event = Preconditions.checkNotNull(event);
/* 224:396 */       this.subscriber = ((EventSubscriber)Preconditions.checkNotNull(subscriber));
/* 225:    */     }
/* 226:    */   }
/* 227:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.EventBus
 * JD-Core Version:    0.7.0.1
 */
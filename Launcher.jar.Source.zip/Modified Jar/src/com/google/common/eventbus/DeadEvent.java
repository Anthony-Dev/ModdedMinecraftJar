/*  1:   */ package com.google.common.eventbus;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @Beta
/*  7:   */ public class DeadEvent
/*  8:   */ {
/*  9:   */   private final Object source;
/* 10:   */   private final Object event;
/* 11:   */   
/* 12:   */   public DeadEvent(Object source, Object event)
/* 13:   */   {
/* 14:47 */     this.source = Preconditions.checkNotNull(source);
/* 15:48 */     this.event = Preconditions.checkNotNull(event);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Object getSource()
/* 19:   */   {
/* 20:58 */     return this.source;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Object getEvent()
/* 24:   */   {
/* 25:68 */     return this.event;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.DeadEvent
 * JD-Core Version:    0.7.0.1
 */
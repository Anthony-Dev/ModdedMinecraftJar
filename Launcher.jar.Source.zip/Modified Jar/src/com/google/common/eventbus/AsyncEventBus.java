/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ public class AsyncEventBus
/*  10:    */   extends EventBus
/*  11:    */ {
/*  12:    */   private final Executor executor;
/*  13: 38 */   private final ConcurrentLinkedQueue<EventBus.EventWithSubscriber> eventsToDispatch = new ConcurrentLinkedQueue();
/*  14:    */   
/*  15:    */   public AsyncEventBus(String identifier, Executor executor)
/*  16:    */   {
/*  17: 51 */     super(identifier);
/*  18: 52 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  19:    */   }
/*  20:    */   
/*  21:    */   public AsyncEventBus(Executor executor, SubscriberExceptionHandler subscriberExceptionHandler)
/*  22:    */   {
/*  23: 67 */     super(subscriberExceptionHandler);
/*  24: 68 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  25:    */   }
/*  26:    */   
/*  27:    */   public AsyncEventBus(Executor executor)
/*  28:    */   {
/*  29: 80 */     super("default");
/*  30: 81 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  31:    */   }
/*  32:    */   
/*  33:    */   void enqueueEvent(Object event, EventSubscriber subscriber)
/*  34:    */   {
/*  35: 86 */     this.eventsToDispatch.offer(new EventBus.EventWithSubscriber(event, subscriber));
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected void dispatchQueuedEvents()
/*  39:    */   {
/*  40:    */     for (;;)
/*  41:    */     {
/*  42: 97 */       EventBus.EventWithSubscriber eventWithSubscriber = (EventBus.EventWithSubscriber)this.eventsToDispatch.poll();
/*  43: 98 */       if (eventWithSubscriber == null) {
/*  44:    */         break;
/*  45:    */       }
/*  46:102 */       dispatch(eventWithSubscriber.event, eventWithSubscriber.subscriber);
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   void dispatch(final Object event, final EventSubscriber subscriber)
/*  51:    */   {
/*  52:111 */     Preconditions.checkNotNull(event);
/*  53:112 */     Preconditions.checkNotNull(subscriber);
/*  54:113 */     this.executor.execute(new Runnable()
/*  55:    */     {
/*  56:    */       public void run()
/*  57:    */       {
/*  58:117 */         AsyncEventBus.this.dispatch(event, subscriber);
/*  59:    */       }
/*  60:    */     });
/*  61:    */   }
/*  62:    */ }


/* Location:           C:\Users\Anthony\Desktop\launcher.jar
 * Qualified Name:     com.google.common.eventbus.AsyncEventBus
 * JD-Core Version:    0.7.0.1
 */